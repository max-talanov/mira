# Source-zero pre-arm followed by DAC ramp

Read-only simulation experiment. No KiCad edits. Main full_cc.cir unchanged by this experiment.

Circuit: official unchanged TI OPA197 macro; expressly approximate LEVEL1 2N7002 and ADG switch/parasitic network from full_cc.cir. Shunt100k, ILIM-DAC2.5V through13.5ohm ILIM-mux plus4k/1k divider, Ccomp100p. All return/per-line1M bypass bleeders DNP; R3110 and source1M retained. Qinj disabled. RDUT100ohm in parallel with10pF; selected BL/NL each50pF-to-ground; source-node200pF. Current i(Vdut) is through the RESISTIVE DUT branch; i(Vcdut) separately measures the10pF DUT capacitor branch.

Controls turn on at t=5us. Source remains0V for another30us; ramp begins at t=35us. Write pulse lasts2ms. Ramp goes0->10V in1us,10us,100us,1ms. Timing delays and off feedback remain physical-model assumptions. Simulation maximum step20ns; no measured PCB parasitics are available.

Expected regulated source/DUT current after ramp is5.4845169uA. Nominal settled result is5.4846973uA. These are model results, not a specification of physical hardware.

| Source ramp duration | Peak resistive DUT current | Late-ramp resistive DUT current | Last entry into +/-1% band, measured from source-ramp start | Excess positive DUT charge above target |
|---|---:|---:|---:|---:|
|1us|6.050mA|approximately1.03mA|110.72us|3.461nC|
|10us|2.955mA|56.74uA|23.53us|2.398nC|
|100us|1.005mA|10.835uA|100.22us|2.313nC|
|1ms|319.46uA|6.020uA|1000.03us|2.207nC|

The excess-charge integration window includes pre-arm and the full ramp plus300us of recovery, and excludes final write-pulse shutdown. Late-ramp mean is the last20% of the voltage ramp. Other performance measures and exact values are in ramp_sequence_results.json.

## Engineering implication

This sequence reduces peak current relative to an abrupt10V source switch in the same assumed model, but it does not establish safe microamp current compliance. Slowing the ramp alone does not remove the excess transient charge.

At source0V with the current loop already enabled, the positive current command is physically unattainable. Before the DAC ramp the op amp is saturated at approximately14.978V, gate approximately14.961V, and sense approximately1.05uV. Therefore Q3101 is precharged fully on. The subsequent source ramp starts from an already saturated controller; its transition out of saturation creates a transient even with the1ms ramp.

The resistive DUT branch also carries current used to charge capacitance on the return-side line/drain nodes. This current is not included in the source-shunt current until it subsequently passes through Q3101. It must not be dismissed as the separately measured C_DUT displacement current: it actually traverses the resistive DUT branch. During the slow1ms ramp, late-ramp excess approximately0.535uA is consistent with roughly53.5pF charging at10V/ms. A100us ramp gives approximately5.35uA of the same charging component.

Thus the present hardware/software coupling (source gate, gate-drive isolation and feedback selection all derived from WRITE_PULSE) does not make this sequence a robust replacement for a transient-current design. A genuine controlled precharge would require independently holding Q3101 gate off/tracking while smoothly charging source/return capacitances, then handing over to current control without saturation. Even that must account for DUT changes releasing already stored capacitive energy, and requires actual parasitic/model/bench verification.

The exact peaks depend on the assumed MOS surface model, gate capacitances, switches and PCB/socket capacitance. The demonstrated controller saturation at zero source and the existence of a charging path through the resistive DUT are topological facts; the peak numerical values are model-dependent.

Files: ramp_sequence.cir (default10us ramp), ramp_sequence_1us.cir, ramp_sequence_10us.cir, ramp_sequence_100us.cir, ramp_sequence_1ms.cir; corresponding logs/raw/waveforms; ramp_sequence_results.json.
