from pathlib import Path
import re, subprocess, json, concurrent.futures
import numpy as np
D=Path(__file__).resolve().parent
BASE=(D/'full_cc.cir').read_text()
OUT=D/'sweep';OUT.mkdir(exist_ok=True)

def make_case(name, pars, width=1e-3, stop=1.01e-3, dc=False):
 s=BASE
 for k,v in dict(pars,PW=width,TSTOP=stop,PERIOD=stop*2).items():
  lines=s.splitlines(); n=0
  for i,line in enumerate(lines):
   if line.startswith('.param '):
    lines[i],found=re.subn(r'(?<![\w])'+re.escape(k)+r'=\S+',k+'='+str(v),line,count=1)
    n+=found
  s='\n'.join(lines)+'\n'
  assert n==1,(k,v,n)
 # 20 ns max step on ms test; edges trigger internal breakpoints.
 s=s.replace('.tran 1n {TSTOP} 0 2n','.tran 20n {TSTOP} 0 20n')
 s=s.replace('write full_cc.raw all\n','')
 s=s.replace('wrdata full_cc_waveforms.txt','wrdata '+str(OUT/(name+'.txt')))
 if dc:
  for src,node,val in [('VSOURCE_CTL','source_ctl',3.3),('VGATE_CTL','gate_ctl',3.3),('VSENSE_CTL','sense_ctl',3.3),('VTRACK_CTL','track_ctl',0),('VCLAMP_CTL','clamp_ctl',0)]:
   s,n=re.subn(r'^'+src+r' .*?\)(?=\n)',f'{src} {node} 0 {val}',s,flags=re.M|re.S,count=1)
   assert n,src
  s=re.sub(r'^IQ_.*$', '', s, flags=re.M)
  s=re.sub(r'^\.tran.*?\n(?=\.control)', '', s, flags=re.M|re.S)
  s=s.replace('run\n','op\n').replace('write full_cc.raw all\n','')
 p=OUT/(name+'.cir');p.write_text(s)
 # Relative .include moves one folder deeper.
 s=p.read_text().replace('.include ../models/', '.include ../../models/')
 p.write_text(s)
 subprocess.run(['/usr/bin/ngspice','-n','-D','ngbehavior=ps','-b','-o',str(OUT/(name+'.log')),str(p)],cwd=D,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 x=np.loadtxt(OUT/(name+'.txt'),skiprows=1)
 if x.ndim==1:x=x[None,:]
 # ngspice op: same wrdata columns, scale may be the single op value.
 target=pars.get('VILIM',2.5)/(5+13.5/1000)*(1/(pars['RSH']+13.5)+1e-6)
 if dc:
  return dict(name=name,parameters=pars,target_A=target,Idut_A=float(x[-1,1]),Iq_A=float(x[-1,2]),sense_V=float(x[-1,3]),rawout_V=float(x[-1,5]),gate_V=float(x[-1,6]),actual_target_error_pct=float(100*(x[-1,1]/target-1)))
 t=x[:,0];on=5e-6;off=on+width;m=(t>=on)&(t<off);tail=(t>=off-min(20e-6,width*.2))&(t<off-min(1e-6,width*.1))
 def settling(y):
  ix=np.where((t>=on)&(t<off-.2e-6))[0];bad=np.where(np.abs(y[ix]/target-1)>.01)[0]
  return None if not len(ix) or (len(bad) and bad[-1]==len(ix)-1) else float((t[ix[bad[-1]+1] if len(bad) else ix[0]]-on)*1e6)
 # Voltage across direct DUT capacitor. Trapezoid derivative not robust aroundbreakpoints; total charge from endpoints is exact C*dV.
 c=pars.get('CDUT',10e-12);vd=x[:,10]-x[:,11];iv=x[:,14]
 return dict(name=name,parameters=pars,target_A=target,Idut_tail_A=float(x[tail,1].mean()),Iq_tail_A=float(x[tail,2].mean()),Idut_peak_A=float(x[m,1].max()),Iq_peak_A=float(x[m,2].max()),Icapacitor_peak_A=float(iv[m].max()),Idut_settle_1pct_us=settling(x[:,1]),Idut_excess_charge_C=float(np.trapezoid(np.maximum(x[m,1]-target,0),t[m])),Idut_charge_C=float(np.trapezoid(x[m,1],t[m])),direct_Cdut_net_charge_C=float(c*(vd[np.where(m)[0][-1]]-vd[np.where(m)[0][0]])),sense_tail_V=float(x[tail,3].mean()),rawout_tail_V=float(x[tail,5].mean()),gate_tail_V=float(x[tail,6].mean()),gate_peak_V=float(x[m,6].max()),gate_off_peak_V=float(x[(t>=off)&(t<off+1e-6),6].max()),Idut_off_peak_A=float(x[(t>=off)&(t<off+1e-6),1].max()),Idut_min_A=float(x[:,1].min()),Iq_min_A=float(x[:,2].min()),clamp_peak_A=float(x[:,13].max()))

if __name__ == "__main__":
 cases=[(f'dc_{r:g}',dict(RSH=r),True) for r in [100,1e3,1e4,1e5]]
 cases += [(f'ms_{r:g}',dict(RSH=r),False) for r in [100,1e3,1e4,1e5]]
 cases += [('dc_old_100k',dict(RSH=1e5,BLEED=1),True)]
 res=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  fs={ex.submit(make_case,n,p,dc=d):n for n,p,d in cases}
  for f in concurrent.futures.as_completed(fs):
   try:
    v=f.result();res.append(v);print(json.dumps(v),flush=True)
   except Exception as e:print('ERROR',fs[f],str(e),flush=True)
 (OUT/'results.json').write_text(json.dumps(res,indent=2))
