# CC loop AC stability estimate

This is a small-signal model estimate at an established regulating operating point. The original project, original full_cc.cir, and official TI OPA197 model are unchanged.

Input injection: Vtest fb_amp fb DC0 AC1; U3102 -IN=fb_amp. C3104 and all external feedback stay on fb. L=-V(fb)/V(fb_amp). Phase margins are computed at every 0dB crossing using unwrapped phase. 10Hz..100MHz,300points/decade.

**Fixed switch states:** source/sense/gate ON; tracking/clamp OFF. For final AC cases the three ON and one OFF switch states use explicit Ron/Roff resistors, because the first plain-SW ps-mode trial showed incorrect AC isolation despite correct DC ON bias. Those initial data are explicitly invalid and excluded. Final resistor-state DC points match the intended ON-switch DC bias.

**Model limitations:** OPA197 vendor model unchanged; MOSFET is disclosed Level1 VTO2V,KP0.14A/V²,RD2Ω,RS0.2Ω. Nominal Cgs27.5p/Cgd3.5p/Cds3.3p,CSENSE150p. High-C corner Cgs46.5p (Ciss50p),CSENSE500p; remaining values as full_cc. These are sensitivity assumptions, not manufacturer worst-case values. Input injection is an approximate return ratio, not rigorous bilateral double injection.

**Operating point:** source10V,RDUT100Ω,VILIM_DAC2.5V,setpoint0.49865V,OPA supply0..15V,BLEED0,charge injection0. The OP is already regulating; this analysis says nothing about large-signal startup/settling and switching spikes.

**Result:** 76 valid cases, each one descending0dBcrossing. No additional0dBcrossings between10Hz and100MHz. C100p is more stable than33/10/3.3/.01p in all tested settings. Rg330 reduces stability. C470p/Rg100 is the best additional high-C candidate tested, with worst estimated PM44.03degrees; this does not establish a guaranteed hardware margin. Check large-signal transient timing before adopting470p.

## Nominal Rg100: phase margin [degrees]

|RSH|100p|33p|10p|3.3p|0.01p|
|---|---:|---:|---:|---:|---:|
|100Ω|56.13|54.71|54.34|54.25|54.20|
|1000Ω|42.03|36.31|34.18|33.55|33.24|
|10000Ω|44.33|30.39|24.13|22.13|21.11|
|100000Ω|58.31|38.65|27.16|23.28|21.29|

## High-C corner: phase margin [degrees]

|RSH|100p/Rg100|220p/Rg100|470p/Rg100|100p/Rg33|100p/Rg10|
|---|---:|---:|---:|---:|---:|
|100Ω|38.65|42.36|49.66|44.03|45.85|
|1000Ω|23.29|31.46|44.03|27.71|29.21|
|10000Ω|27.15|41.52|56.82|29.73|30.61|
|100000Ω|43.47|58.56|66.86|44.77|45.22|

Full crossover frequency, phase, direction, and gain-margin data: ac_loop_results.json plus ac_compromise_results.json; flattened ac_all_crossings.csv. Conditions and hashes: ac_loop_manifest.json.

Reproduce the first60cases: python ac_loop_sweep.py. All76 generated ac_*.cir files are standalone and runnable with ngspice -n -D ngbehavior=ps -b -o FILE.log FILE.cir from this simulation directory.
