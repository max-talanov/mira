from pathlib import Path
import json,numpy as np
D=Path(__file__).resolve().parent/'sweep'
for fn in ['results.json','corner_results.json']:
 p=D/fn;r=json.loads(p.read_text())
 for v in r:
  if v['name'].startswith('dc_'):continue
  x=np.loadtxt(D/(v['name']+'.txt'),skiprows=1);t=x[:,0]
  width=1e-3 if v['name'].startswith('ms_') else (100e-6 if v['name'].startswith('q') else 10e-6)
  on=5e-6;off=on+width;m=(t>=on)&(t<off);tail=(t>=off-min(20e-6,width*.2))&(t<off-min(1e-6,width*.1));offmask=(t>=off)&(t<off+1e-6)
  ires=x[:,1];icap=x[:,14];itotal=ires+icap
  v.update(Idut_tail_A=float(ires[tail].mean()),Iq_tail_A=float(x[tail,2].mean()),sense_tail_V=float(x[tail,3].mean()),rawout_tail_V=float(x[tail,5].mean()),gate_tail_V=float(x[tail,6].mean()),gate_off_peak_V=float(x[offmask,6].max()),Idut_off_peak_A=float(ires[offmask].max()),Icapacitor_peak_A=float(icap[m].max()),Icapacitor_min_A=float(icap[m].min()),I_DUT_total_peak_A=float(itotal[m].max()),I_DUT_total_excess_charge_C=float(np.trapezoid(np.maximum(itotal[m]-v['target_A'],0),t[m])),Icapacitor_charge_positive_C=float(np.trapezoid(np.maximum(icap[m],0),t[m])),Idut_min_A=float(ires.min()),Iq_min_A=float(x[:,2].min()),clamp_peak_A=float(x[:,13].max()))
 p.write_text(json.dumps(r,indent=2))
 print(fn)
 for v in r:print(v['name'],*(f'{k}={v.get(k)}' for k in ['Idut_tail_A','Idut_settle_1pct_us','I_DUT_total_peak_A','gate_off_peak_V','clamp_peak_A']))
