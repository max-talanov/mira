"""Postprocess full_cc wrdata output. Actual last-band-entry, not first crossing.

Usage: python analyze_cc.py full_cc_waveforms.txt --width-us 10
The equivalent-current target includes U3104 RON and R3110=1M.
"""
import argparse
import json
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('waveform')
p.add_argument('--ton-us',type=float,default=5)
p.add_argument('--width-us',type=float,default=10)
p.add_argument('--ilim',type=float,default=2.5)
p.add_argument('--rsh',type=float,default=100000)
p.add_argument('--ron',type=float,default=13.5)
p.add_argument('--out')
a=p.parse_args()
x=np.loadtxt(a.waveform,skiprows=1)
t=x[:,0]; on=a.ton_us*1e-6; off=on+a.width_us*1e-6
target=a.ilim/(5+a.ron/1000)*(1/(a.rsh+a.ron)+1e-6)
in_pulse=(t>=on)&(t<off)
vset=a.ilim/(5+a.ron/1000)

def settling(y,reference,tolerance):
    # Require the waveform to remain in band through the entire pulse tail.
    ix=np.where((t>=on)&(t<off-0.2e-6))[0]
    err=np.abs(y[ix]-reference)>abs(reference)*tolerance
    bad=np.flatnonzero(err)
    if not len(ix) or (len(bad) and bad[-1]==len(ix)-1):return None
    k=ix[bad[-1]+1] if len(bad) else ix[0]
    return float((t[k]-on)*1e6)

result={
 'assumptions':'TI OPA197 macro; approximate LEVEL1 MOS and switch/parasitic model; not hardware validation',
 'target_equivalent_Q_current_A':target,
 'pulse_width_us':a.width_us,
 'Idut_peak_A':float(x[(t>=on)&(t<=off+0.5e-6),1].max()),
 'Iq_peak_A':float(x[(t>=on)&(t<=off+0.5e-6),2].max()),
 'Idut_tail_mean_A':float(x[(t>=off-2e-6)&(t<off-1e-6),1].mean()),
 'Iq_tail_mean_A':float(x[(t>=off-2e-6)&(t<off-1e-6),2].mean()),
 'Idut_settle_1pct_us':settling(x[:,1],target,.01),
 'Idut_settle_5pct_us':settling(x[:,1],target,.05),
 'sense_settle_1pct_us':settling(x[:,3],vset,.01),
 'DUT_excess_charge_C':float(np.trapezoid(np.maximum(x[in_pulse,1]-target,0),t[in_pulse])),
 'DUT_net_charge_C':float(np.trapezoid(x[in_pulse,1],t[in_pulse])),
 'gate_max_V':float(x[:,6].max()),
 'clamp_peak_A':float(x[:,13].max()),
 'gate_off_peak_0p5us_V':float(x[(t>=off)&(t<=off+.5e-6),6].max()),
}
text=json.dumps(result,indent=2)
print(text)
if a.out:
 from pathlib import Path
 Path(a.out).write_text(text+'\n')
