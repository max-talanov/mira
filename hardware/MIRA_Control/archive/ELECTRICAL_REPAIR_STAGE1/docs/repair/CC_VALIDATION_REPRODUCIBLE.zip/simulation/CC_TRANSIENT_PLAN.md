# CC-loop transient and AC verification plan

Read-only review of `after.net.xml` and the 3100/2600 circuit. This is a simulation plan, not a claim that the physical loop has passed. Do not modify schematics from this file.

## Native topology to retain

- OPA197 U3102: +15 V/GND. +IN=MAT_ILIM_SENSE, -IN=MAT_CC_FB, OUT=MAT_CC_GATE_RAW.
- U2603C ADG5434: D=FB; S_A=CC_SENSE; S_B=RAW_OUT; IN=WRITE_PULSE. OFF is a local voltage follower, ON senses the raw shunt/source node.
- C3104=100 pF from RAW_OUT to FB, after the SPDT. It is not a capacitor from gate to sense.
- U2604D ADG5412: S=RAW_OUT, D→R3103=100 ohm→gate; IN=WRITE_PULSE.
- Q3102: drain=gate, source=GND; gate=NOT WRITE_PULSE through U3103 (3.3 V supply). R3104=100 kohm from Q3101 gate to GND.
- Q3101 source=CC_SENSE; source current returns via ADG5408 U3104 selected shunt plus R3110=1 Mohm in parallel. Shunts are 100 ohm, 1k, 10k, 100k.
- In a write, SOURCE_SAFE=WRITE_PULSE controls U2604A. U2604C return switch is controlled by WRITE_SAFE, not WRITE_PULSE; it can stay closed between pulses.
- ILIM divider R3101=4k, R3102=1k, C3103=1nF must remain in the model. Its actual upstream source/select circuit matters for setpoint changes. No artificial ideal voltage clamp on FB or CC_SENSE.
- ADC changes are expected to remove 30 kohm DC loads. Model actual buffer input capacitance/bias at raw sense; do not leave old 30k and do not replace the raw node by a zero-ohm ideal ADC driver.

## Essential DC bypass paths

DO NOT omit R2602=1 Mohm from MAT_RETURN to GND. The selected BL also has a 1 Mohm-to-ground bleeder (BL0: R2210), and the selected NL has a 1 Mohm-to-ground bleeder (NL0: R2718). The return-side line bleeder and R2602 bypass the regulated Q3101/shunt branch. Source-side bleeders load the source independently of the DUT.

Consequently, DUT conduction current is not identical to shunt/Q3101 current. At approximately 10 V on a return node, two 1 Mohm paths alone can carry approximately 20 uA. This is material on a 100k-shunt/10uA setting. Keep their distributed node locations; do not silently fold them into R3110.

At Vsense=0.97 V, nominal shunt-mux RON=13.5 ohm and R3110=1 Mohm, Q3101 source current estimates are:

| Shunt | (Rsh+RON)||1M | I_source at 0.97 V |
|---|---:|---:|
| 100 | 113.487 ohm | 8.547 mA |
| 1k | 1012.474 ohm | 958.05 uA |
| 10k | 9914.224 ohm | 97.839 uA |
| 100k | 90920.248 ohm | 10.669 uA |

These are estimates of the source branch only, not a complete DUT compliance specification. RON is signal/temperature dependent. Regulating CC_SENSE includes current through R3110 in addition to the selected shunt.

A separate linear DC nodal calculation illustrates the bypass issue. Assumptions: source10V, source Rout0.5ohm plus actual4.7ohm, DUT100ohm, published typical switch RON, VSENSE0.97V, ideal regulating sink, and1M bleeders at MAT_SOURCE, selected BL, selected NL and MAT_RETURN. All calculated drain voltages remain above9V except the100ohm-shunt case(8.24V), so this is not a headroom-loss artifact.

| Shunt | Regulated Q branch | Actual resistive DUT current | Excess relative to Q branch |
|---|---:|---:|---:|
|100ohm|8.5472mA|8.5641mA|0.197%|
|1k|958.05uA|977.69uA|2.050%|
|10k|97.839uA|117.795uA|20.396%|
|100k|10.669uA|30.656uA|187.344%|

This is an analytic DC estimate, not a MOS/op-amp transient simulation. It demonstrates that correcting loop stability alone cannot establish accurate DUT current compliance with the bypass bleeders installed.

## Physical source/DUT chain

For a representative service write include U2602 source selector, U2604A source gate, one U2603 polarity switch, U2601 BL bank selector, one U2217..U2220 BL selector, DUT, U2706 NL selector, second U2603 polarity switch, U2604C return gate, and Q3101. Eight series switches precede Q3101; the ninth switch is the shunt mux. Add the real 4.7 ohm output resistor from the service source sheet.

Polarity changes exchange BL and NL but leave Q3101 as a positive low-side sink. All source voltages in supported write tests are >=0. A negative SOURCE test is a deliberate rejection case: the body diode/reverse channel bypasses signed current regulation.

## Device/model and parasitic assumptions

Use the official OPA197 macro and an official vendor 2N7002 model if available. Verify pin order explicitly. Do not hide Q3101/Q3102 body diodes. Do not add fixed capacitances on top of a nonlinear MOS model without first checking which capacitances that model already includes.

Official typical values at +/-15 V, with relevant published high-temperature maxima:

| Device | RON typical / 125 C max | Timing typical / relevant 125 C max | Typical capacitance / charge |
|---|---|---|---|
| ADG5408 | 13.5 / 22 ohm | EN ON 140/242 ns; OFF 130/198 ns; transition 170/292 ns | source-off15pF, drain-off102pF, on133pF; Qinj115pC |
| ADG5412 | 9.8 / 16 ohm | ON170/262 ns; OFF120/182 ns | off terminal18pF, on60pF; Qinj240pC |
| ADG5434 | 13.5 / 22 ohm | transition157/272 ns; BBM min21ns/typ45ns | source-off14pF, drain-off24pF, on53pF; Qinj130pC |
| 2N7002 Nexperia | RDS@VGS4.5=5.3ohm max; @10V=5ohm max | use nonlinear model | Ciss31typ/50max pF; Crss3.5typ/10max pF at VDS10V |

A table capacitance measured at a common terminal is not necessarily an extra capacitor of that value on BOTH terminals of every on switch. Avoid double-counting. For a reduced model, use a documented equivalent lumped capacitance and sweep it; an exact distributed model is preferable.

Recommended exploratory sweeps (assumptions, not device guarantees):

- RON: typical, quoted full-temperature max, and correlated low-stress minimum 0.5x typical. The last is not a manufacturer min guarantee.
- Q3101 effective input/Miller capacitance: vendor nonlinear default; then additional gate-to-drain parasitic 0/3/10 pF and board gate-ground0/20/100pF. For a fixed-cap reduced model use total effective gate loading50/150/300pF and a1nF stress case. Low setpoint + large load resistance can increase drain gain/Miller loading substantially.
- Raw CC_SENSE effective shunt-ground capacitance:150/300pF nominal exploration,1nF stress. Include shunt-mux common-drain capacitance, selected SPDT terminal capacitance, ADC buffer input and layout. A buffered ADC removes DC loading, not input capacitance.
- Post-source-gate node capacitance:50/200/1000pF; board/socket/DUT terminal-ground20/100/500pF. Add DUT differential capacitance1/10/100pF and1nF explicit stress. Keep upstream source capacitance separate from post-gate capacitance.
- Upstream DAC/buffer effective Rout:0.1/0.5/5 ohm in addition to real4.7ohm; selected-source shunt capacitance0/100pF/1nF. AD5761R's1nF load specification and0.5ohm DC output impedance do not prove an ideal zero-impedance wideband source.
- Charge injection: first run zero injection to establish the deterministic loop; then inject +/-Qtyp and +/-2Qtyp at each switched sensitive node, with10/30/100ns pulse shapes and area exactly Q. These are sensitivity assumptions, NOT guaranteed maxima. Include gate-isolation D terminal, feedback SPDT D terminal and source-gate node. Vendor switch macromodels may omit this effect.

## Rough small-signal assessment

For a stiff drain and negligible Cgd, the MOS source-follower low-frequency plant is approximately beta_MOS = gm*Rs/(1+gm*Rs), bounded below unity. The effective source-node resistance is approximately Rs||(1/gm), so the passive Rs*C pole below is not a prediction of the powered closed-loop bandwidth.

Passive raw-node pole estimates (useful during OFF/BBM/reconnection), for Csense150..300pF:

| Shunt | Passive pole range |
|---|---:|
| 100 | 4.67..9.35MHz |
| 1k | 0.524..1.048MHz |
| 10k | 53.5..107kHz |
| 100k | 5.83..11.67kHz |

R3103 plus ADG5412 RON is approximately110ohm. A50/150/300pF equivalent gate load gives a simple gate pole around29/9.6/4.8MHz. These poles are not enough to calculate phase margin: nonlinear Cgd, drain impedance, feedback SPDT, OPA output impedance and C3104 must be included together.

C3104=100pF is a direct high-frequency negative-feedback path. Its effect depends on the source-node impedance and cannot be described as a fixed dominant integrator. Leave it connected after the SPDT. AC return-ratio analysis must include both the capacitive local path and the source-sense path. Break the loop at the op-amp input with a proper return-ratio method; do not break only the gate path and accidentally exclude C3104 feedback. Only evaluate AC margins at a regulated, unsaturated DC operating point; open circuit/headroom loss requires transient recovery testing instead.

OPA197 unity GBW is approximately10MHz and slew approximately20V/us (typical). This does not certify the assembled loop. Target engineering checks: phase margin>=45deg and gain margin>=6dB for explored regulated cases, preferably>=60deg phase margin; report assumptions and actual achieved margins, not just a binary pass.

## Minimum transient matrix

1. All four shunts; Vsupply0.5/2/5/10V; ILIM sense0/1mV/10mV/0.1V/0.97V. Use sensible combinations with an achievable regulated operating point and separate headroom-loss cases.
2. DUT resistance1ohm/100ohm/1k/10k/100k/1M/1G. Include deliberate shorts and open circuit. Add compliance-boundary cases just below/at/above available source voltage at the desired current.
3. Particularly important: low ILIM sense10mV on100ohm shunt with load10k..100k; high Miller/drain-gain sensitivity. Also100k shunt + approximately10uA, load100ohm..1k: bypass bleeders can dominate actual DUT error.
4. Pulse widths0.1/1/10us and1ms; OFF times0.1/1/10us and1ms. Confirm a1ms pulse case and explicitly state any shorter widths that do not settle. Do not presume supported minimum width.
5. Mid-pulse DUT transition1M→100ohm and100ohm→1M, with1/10/100ns transition edge. This models a forming/switching event and is more revealing than only switching a resistive load on at t=0.
6. Source ramp0→10V, source step2→10V, ILIM step0.97→0.01V, pulse enabled during those steps as a deliberate robustness case. Normal protocol should settle DACs before pulse.
7. Gate/feedback/source timing corners: all typical; earliest source+latest gate; earliest gate+latest feedback; fastest clamp+slowest gate-open at falling edge; latest clamp+earliest charge injection; feedback BBM21/45/100ns (100ns sensitivity, no specified max). Sweep relative source/gate/feedback delays0..300ns, not just one common ideal control edge.
8. Include fast logic inverter2..10ns and Q3102 turn-on/turn-off5..50ns sensitivity, using real3.3V gate drive and MOS model. Verify maximum Vgate, VGS, VDS, and current/energy in R3103/U2604D/Q3102 during overlap.
9. Initial charge: post-gate nodes/DUT caps initially0V and10V; repeated pulses with OFF shorter than the real bleeder RC. An ideal reset-to-zero capacitor initial condition between every pulse conceals residual-charge failures.
10. Asynchronous fault halfway through pulse: WRITE_PULSE drops while WRITE_SAFE return can remain briefly high, then fully drops. Check source isolation, gate clamp and both propagation orders. Separately mark analog-rail power-loss behavior as unverified if switch macros do not model unpowered operation.

## Measurements and reporting

- Current through the DUT resistive/memristive branch; capacitive DUT current reported separately; Q3101 drain/source current; shunt current; R3110 current; every return-side bleeder current.
- Peak DUT conduction current, peak capacitive current, steady-state DUT-current error, maximum overshoot, settling time to +/-1% and +/-5%, residual/ringing amplitude and frequency, minimum useful pulse width.
- Integrate excess positive current above intended limit, Q_excess = integral max(I_DUT-I_limit,0)dt; also report total DUT pulse charge. This prevents a short but huge initial spike from disappearing in an average-current claim.
- Peak source voltage across the DUT, source/drain node voltages, all VGS/VDS, voltage at OPA inputs, op-amp saturation duration/recovery, time until gate<0.3V after OFF.
- Gate-clamp overlap pulse current and energy in100ohm R3103. Source/gate switches should not be claimed free of overlap merely because their stable OFF states are correct.
- Treat charge-injection and parasitic sweeps separately from vendor-model nominal results. A model without these effects passing is not proof that the real socket/DUT sees no current spike.

## Official references

- https://www.ti.com/lit/ds/symlink/opa197.pdf
- https://assets.nexperia.com/documents/data-sheet/2N7002.pdf
- https://www.analog.com/media/en/technical-documentation/data-sheets/adg5408_5409.pdf
- https://www.analog.com/media/en/technical-documentation/data-sheets/adg5412_5413.pdf
- https://www.analog.com/media/en/technical-documentation/data-sheets/adg5433_5434.pdf
- https://www.analog.com/media/en/technical-documentation/data-sheets/AD5761R_5721R.pdf

