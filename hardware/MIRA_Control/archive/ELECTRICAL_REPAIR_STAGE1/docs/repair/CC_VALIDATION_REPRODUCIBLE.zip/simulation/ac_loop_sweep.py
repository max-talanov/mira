"""Read-only AC input-injection loop estimate from full_cc.cir.
TI OPA197 library and original full_cc.cir remain unchanged.
"""
from pathlib import Path
import re,subprocess,json,concurrent.futures
import numpy as np
D=Path(__file__).resolve().parent
BASE=(D/'full_cc.cir').read_text()

def build(rsh,ccomp,corner="nominal",rgate=100):
 s=BASE.split('.save ')[0]
 for key,value in {'RSH':rsh,'CCOMP':ccomp,'Qscale':0}.items():
  s,n=re.subn(r'(?<![\w])'+key+r'=\S+',key+'='+str(value),s,count=1)
  assert n==1,key
 for src,node,val in [('VSOURCE_CTL','source_ctl',3.3),('VGATE_CTL','gate_ctl',3.3),('VSENSE_CTL','sense_ctl',3.3),('VTRACK_CTL','track_ctl',0),('VCLAMP_CTL','clamp_ctl',0)]:
  s,n=re.subn(r'^'+src+r' .*?\)(?=\n)',f'{src} {node} 0 DC {val}',s,flags=re.M|re.S,count=1)
  assert n,src
 s=re.sub(r'^IQ_.*$', '', s, flags=re.M)
 # Fixed switching states are represented directly by their ON/OFF resistances.
 # ngspice42 ps-mode plain SW AC state did not match DC state in first trial.
 # This linear network preserves intended steady-state Ron/Roff values.
 for old,new in {
  'S_U2604A selected source_node source_ctl 0 SW5412':'R_AC_SOURCE selected source_node {R5412}',
  'S_U2603C_SA fb cc sense_ctl 0 SW5434':'R_AC_SENSE fb cc {R5434}',
  'S_U2603C_SB fb rawout track_ctl 0 SW5434':'R_AC_TRACK fb rawout {ROFF}',
  'S_U2604D rawout gate_sw gate_ctl 0 SW5412':'R_AC_GATE rawout gate_sw {R5412}',
 }.items():
  assert old in s,old
  s=s.replace(old,new)
 s=s.replace('R3103 gate_sw gate 100',f'R3103 gate_sw gate {rgate}')
 if corner=='cap_high':
  s=s.replace('CSENSE=150p','CSENSE=500p').replace('C_Q1_GS gate cc 27.5p','C_Q1_GS gate cc 46.5p')
 s=s.replace('XU3102 setpoint fb p15 0 rawout OPAx197','Vtest fb_amp fb DC 0 AC 1\nXU3102 setpoint fb_amp p15 0 rawout OPAx197')
 assert 'Vtest fb_amp fb' in s
 name='ac_'+corner+'_rg'+str(rgate)+'_r'+str(int(rsh))+'_c'+str(round(ccomp*1e12,2)).replace('.','d')+'p'
 s+='\n* Loop gain test: external compensation and sense wiring remain on fb.\n* Input-injection ratio is an approximate return ratio, not rigorous\n* Middlebrook voltage/current double-injection for this multi-loop network.\n.save v(fb) v(fb_amp) v(setpoint) v(rawout) v(gate) v(cc) v(q_drain) i(Vdut) i(Vq)\n.control\nset numdgt=15\nset filetype=ascii\nset wr_singlescale\nset wr_vecnames\nop\nwrdata {name}_op.txt v(fb) v(fb_amp) v(setpoint) v(rawout) v(gate) v(cc) v(q_drain) i(Vdut) i(Vq)\nac dec 300 10 100meg\nlet loopgain = -v(fb)/v(fb_amp)\nlet lg_real = real(loopgain)\nlet lg_imag = imag(loopgain)\nlet amp_real = real(v(fb_amp))\nlet amp_imag = imag(v(fb_amp))\nlet fb_real = real(v(fb))\nlet fb_imag = imag(v(fb))\nwrdata {name}.txt lg_real lg_imag amp_real amp_imag fb_real fb_imag\nwrite {name}.raw all\nquit\n.endc\n.end\n'.format(name=name)
 p=D/(name+'.cir');p.write_text(s)
 return name,p

def analyze(name,rsh,ccomp):
 x=np.loadtxt(D/(name+'.txt'),skiprows=1)
 f=x[:,0];z=x[:,1]+1j*x[:,2]
 db=20*np.log10(np.abs(z));phase=np.unwrap(np.angle(z))*180/np.pi
 # Normalize low frequency around 0 degrees. Negative feedback is positive loopgain.
 phase-=360*round(phase[0]/360)
 lf=np.log10(f)
 crossings=[]
 for i in np.flatnonzero(db[:-1]*db[1:]<=0):
  a=-db[i]/(db[i+1]-db[i]);freq=10**(lf[i]+a*(lf[i+1]-lf[i]));ph=phase[i]+a*(phase[i+1]-phase[i]);
  crossings.append({'frequency_Hz':float(freq),'phase_deg':float(ph),'phase_margin_deg':float(180+ph),'direction':'descending' if db[i+1]<db[i] else 'ascending'})
 phase_crossings=[]
 for branch in range(-8,8):
  target=-180+360*branch
  for i in np.flatnonzero((phase[:-1]-target)*(phase[1:]-target)<=0):
   a=(target-phase[i])/(phase[i+1]-phase[i]);freq=10**(lf[i]+a*(lf[i+1]-lf[i]));gain=db[i]+a*(db[i+1]-db[i]);
   phase_crossings.append({'frequency_Hz':float(freq),'phase_deg':target,'gain_dB':float(gain),'gain_margin_dB':float(-gain)})
 op=np.loadtxt(D/(name+'_op.txt'),skiprows=1).tolist()
 return {'name':name,'RSH_ohm':rsh,'CCOMP_F':ccomp,'DC':dict(zip(['scale','fb_V','fb_amp_V','setpoint_V','rawout_V','gate_V','cc_V','q_drain_V','Idut_A','Iq_A'],op)),
 'low_frequency_loop_gain_dB':float(db[0]),'low_frequency_phase_deg':float(phase[0]),'unity_gain_crossings':crossings,'negative_real_axis_crossings':phase_crossings,
 'frequency_max_Hz':float(f[-1]),'minimum_amp_node_magnitude_V':float(np.min(np.hypot(x[:,3],x[:,4])))}

def run(r,c,corner="nominal",rgate=100):
 name,p=build(r,c,corner,rgate)
 subprocess.run(['/usr/bin/ngspice','-n','-D','ngbehavior=ps','-b','-o',str(D/(name+'.log')),str(p)],cwd=D,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 result=analyze(name,r,c);result.update(capacitance_corner=corner,gate_resistor_ohm=rgate);print(json.dumps(result),flush=True);return result

if __name__=='__main__':
 cases=[(r,c,corner,rgate) for corner,rgate in [('nominal',100),('cap_high',100),('cap_high',330)] for r in [100,1e3,1e4,1e5] for c in [100e-12,33e-12,10e-12,3.3e-12,.01e-12]]
 result=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  fs={ex.submit(run,r,c,corner,rgate):(r,c,corner,rgate) for r,c,corner,rgate in cases}
  for future in concurrent.futures.as_completed(fs):
   try:result.append(future.result())
   except Exception as e:print('ERROR',fs[future],str(e),flush=True)
 result.sort(key=lambda x:(x['capacitance_corner'],x['gate_resistor_ohm'],x['RSH_ohm'],-x['CCOMP_F']))
 (D/'ac_loop_results.json').write_text(json.dumps(result,indent=2))
