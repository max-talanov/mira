from pathlib import Path
import json,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path(__file__).resolve().parent
x=np.loadtxt(D/'sweep/ms_100000.txt',skiprows=1);t=x[:,0]*1e6-5
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25})
f,a=plt.subplots(3,1,figsize=(10,9),constrained_layout=True)
a[0].plot(t,x[:,1]*1e3,label='Резистивная ветвь DUT');a[0].plot(t,x[:,14]*1e3,label='Прямая ёмкость DUT');a[0].plot(t,(x[:,1]+x[:,14])*1e3,ls='--',label='Суммарный ток DUT');a[0].set(xlim=(0,.6),ylabel='Ток, мА',title='Пусковой ток ветвей');a[0].legend(loc='upper right')
a[1].plot(t,x[:,1]*1e6,label='Резистивный ток DUT');a[1].axhline(5.4845168955,color='k',ls=':',label='Уставка DC');a[1].set(xlim=(0,80),ylim=(-.7,7.5),ylabel='Ток, мкА',title='Позднее установление проводимого тока');a[1].legend(loc='lower right')
a[2].plot(t,x[:,3],label='VSENSE');a[2].plot(t,x[:,5],label='Выход ОУ',ls='--');a[2].plot(t,x[:,6],label='Затвор');a[2].set(xlim=(0,80),xlabel='Время от фронта WRITE_PULSE, мкс',ylabel='Напряжение, В',title='VSENSE достигает уставки раньше тока DUT');a[2].legend(loc='lower right')
f.savefig(D/'CC_STARTUP_COUNTEREXAMPLE.png',dpi=180);f.savefig(D/'CC_STARTUP_COUNTEREXAMPLE.pdf');plt.close(f)
# Compact numerical material: all current and PM values remain explicitly model estimates.
r=json.loads((D/'sweep/results.json').read_text());r.sort(key=lambda z:z['parameters']['RSH'])
rr={z['name']:z for z in r}
summary={'status':'BLOCKING','references':'Existing pre-renumber references','transient_model':{'vendor_amplifier':'Unchanged TI OPAx197 Final1.3 23JUN2022','MOSFET':'Explicit approximate LEVEL1: VTO2, KP0.14, RD2, RS0.2; nonlinear/temperature/subthreshold behavior not qualified','source_V':10,'ILIM_DAC_V':2.5,'DUT_ohm':100,'DUT_parallel_pF':10,'return_ground_cap_pF':50,'source_ground_cap_pF':200,'sense_cap_pF':150,'Ccomp_pF':100,'Rgate_ohm':100,'RON_mux_typ_ohm':13.5,'temperature_C':25},'DC_and_1ms':[],'old_return_bleeders':rr['dc_old_100k'],'source_ramp_results_file':'ramp_sequence_results.json','AC_results_files':['ac_loop_results.json','ac_compromise_results.json'],'no_electrical_compensation_change':True}
for sh in[100,1e3,1e4,1e5]:
 z=rr[f'ms_{sh:g}'];o=rr[f'dc_{sh:g}'];summary['DC_and_1ms'].append({'RSH_ohm':sh,'DC_DUT_A':o['Idut_A'],'DC_Q_A':o['Iq_A'],'actual_DUT_settle_1pct_us':z['Idut_settle_1pct_us'],'resistive_DUT_peak_A':z['Idut_peak_A'],'direct_DUT_cap_peak_A':z['Icapacitor_peak_A'],'total_DUT_peak_A':z['I_DUT_total_peak_A'],'resistive_DUT_excess_charge_C':z['Idut_excess_charge_C'],'total_DUT_excess_charge_C':z['I_DUT_total_excess_charge_C']})
(D/'CC_ENGINEERING_DECISION.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('CC report plot and numerical JSON written')
