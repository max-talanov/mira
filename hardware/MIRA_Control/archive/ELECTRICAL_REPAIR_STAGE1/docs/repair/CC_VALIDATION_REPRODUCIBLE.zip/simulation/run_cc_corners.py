from run_cc_sweeps import make_case, OUT
import json,concurrent.futures
cases=[]
for cap in [100e-12,33e-12,10e-12]:
 for sh in [100,1e5]:
  cases.append((f"c{cap:g}_sh{sh:g}",dict(RSH=sh,CCOMP=cap),10e-6,20e-6))
for q in [-1,1]:
 for sh in [100,1e5]:
  cases.append((f"q{q}_sh{sh:g}",dict(RSH=sh,Qscale=q),100e-6,110e-6))
res=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 fs={ex.submit(make_case,n,p,width=w,stop=s):n for n,p,w,s in cases}
 for f in concurrent.futures.as_completed(fs):
  try:
   v=f.result();res.append(v);print(json.dumps(v),flush=True)
  except Exception as e:print("ERROR",fs[f],e,flush=True)
(OUT/"corner_results.json").write_text(json.dumps(res,indent=2))
