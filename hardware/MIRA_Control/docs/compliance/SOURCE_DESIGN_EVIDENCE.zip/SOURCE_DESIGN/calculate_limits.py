from pathlib import Path
import json,math
p=Path(__file__).resolve().parent
rows=[]
Kp=33e3/100e3;Ki=1/(100e3*4.7e-9)
for r in [100,1000,10000,100000]:
 vtarget=5*1000/(4000+1000+18.2)
 k=r/(r+74+100)
 tau=(1+Kp*k)/(Ki*k)
 init=Kp*k/(1+Kp*k)
 t1=tau*math.log((1-init)/.01)
 rows.append({'RSH_ohm':r,'nominal_fullscale_A':1/r,'DAC5V_setpoint_V_typ_series18p2':vtarget,'uncalibrated_FS_A_typ':vtarget/r,'Vsource_max_FS_nom_ceiling11p9_overhead74':min(10,11.9-1-74/r),'ideal_CC_100ohm_t1pct_s':t1,'ideal_CC_100ohm_tau_s':tau,'physical_shunt_current_FS_W':(1/r)**2*r})
charge=[]
for c in [50e-12,300e-12,2e-9]:
 for i in [1e-6,10e-6,100e-6,1e-3,10e-3]:
  charge.append({'Cpost_F':c,'Vstep_V':10,'I_source_A':i,'t_min_charge_s':c*10/i,'stored_Q_C':c*10,'stored_energy_J':.5*c*100})
out={'status':'CALCULATIONS_ONLY_NOT_FINAL_MACROMODEL_OR_HARDWARE_VALIDATION','Ri_ohm':100e3,'Cint_F':4.7e-9,'Rzero_ohm':33e3,'Kp':Kp,'Ki_per_s':Ki,'Rback_ohm':22e3,'Rctrl_ohm':1000,'upper_clamp_nom_V':11.9,'upper_clamp_allocated_design_band_V':[11.87,11.93],'ranges':rows,'charge_budget_examples':charge,'off_100k_2n_10V_to_1mV_s':(100e3+27)*2e-9*math.log(1e4),'minimum_no_load_ramp_10V_Iset0p1_s':10/(Ki*.1),'AW_outward_error_min_V':-1,'AW_steady_raw_above_cmd_max_V':22e3/100e3,'OPA13_IQ_typ_A':.013,'OPA13_IQ_max25_A':13*.0013,'OPA13_idle_power_typ_W':13*.001*30,'OPA13_idle_power_max25_W':13*.0013*30,'error_budget_note':'Must include DAC, divider/matched networks, INA VOSI+VOSO/G, OPA offsets including AW gain, all switch leakages and multiple-cell/sneak currents. No final percentage accuracy declared.'}
(p/'CAPABILITY_CALCULATIONS.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
