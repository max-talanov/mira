# MIRA source-side CV/CC design evidence

This directory is a curated engineering handoff, not manufacturing approval.

- `ENGINEERING_STATUS_RU.md`: 13 OPA channels and 2 INA821 topology, changes, analytical limits, calibration and validation status.
- `CAPABILITY_CALCULATIONS.json` and `calculate_limits.py`: reproducible static calculations.
- `ratio_corner_analysis.json`: exact resistor-only error corners; not a full tolerance qualification.
- `final_candidate.cir`: actual manufacturer-macro topology including 22 kΩ back-calculation,an 11.9 V ceiling,a 220 Ω capacitor reset resistor; a successful full manufacturer-macro transient was NOT obtained.
- `models`: official numeric component models, notices and provenance.

From this directory run `ngspice -n -D ngbehavior=ps -b -o final_candidate.log final_candidate.cir`. Numerical failure is a recorded limitation, not a physical pass/fail conclusion.

The authoritative reduced-component engineering sweeps are delivered separately under final13_release. These are not TI vendor model or bench verification.

`CHARGE_TIME_BOUND.png` shows only the physical charge-time bound C×ΔV/I; it does not certify controller settling or peak current.

`MANUFACTURER_TEST_STATUS.json` and `FAILED_MANUFACTURER_TRANSIENT.log` record the exact final manufacturer-component test. It reached 5 ms OFF and aborted at the enable edge. The incomplete waveform was intentionally removed and is not a result demonstrating operation.
