from pathlib import Path
import subprocess,argparse,json,time
P=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--timeout',type=float,default=45);a=ap.parse_args()
R=[]
for q in sorted((P/'CASES').glob('*.cir')):
 w=q.with_name(q.stem+'.wave.txt');w.unlink(missing_ok=True);log=q.with_name(q.stem+'.rerun.log');t0=time.time();r={'case':q.name,'completed':False}
 try:
  z=subprocess.run(['ngspice','-n','-D','ngbehavior=ps','-b','-o',log.name,q.name],cwd=q.parent,timeout=a.timeout,capture_output=True,text=True)
  text=log.read_text() if log.exists() else z.stdout+z.stderr
  # Saved case metadata supplies the expected final time; solver exit alone is insufficient.
  import re
  target=float(re.search(r'TSTOP=(\S+)',q.read_text()).group(1));last=None
  if w.exists():
   lines=w.read_text().splitlines()
   if len(lines)>1:last=float(lines[-1].split()[0])
  r.update(completed=last is not None and last>=target-1e-10 and 'aborted' not in text,last_time_s=last,returncode=z.returncode)
 except subprocess.TimeoutExpired:r['note']='Timeout; no qualification claim'
 r['seconds']=time.time()-t0;R.append(r);print(json.dumps(r),flush=True)
(P/'RERUN_STATUS.json').write_text(json.dumps(R,indent=2))
