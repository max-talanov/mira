#!/usr/bin/env python3
"""Independent comparison of KiCad-native XML nets against declared circuit.
Does not import the schematic generator or reuse its parsing/net graph code.
"""
import hashlib, json, sys, xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
XML=BASE/'verification/MIRA_Power_RevB.net.xml'; DESIGN=BASE/'design_source/build/complete_design.json'; ERC=BASE/'verification/ERC.json'
OUT=BASE/'docs'
blocks=json.loads(DESIGN.read_text()); rows=[p for b in blocks for p in b['parts']]
parts={p['ref']:p for p in rows}; root=ET.parse(XML).getroot()
comps={c.get('ref'):c for c in root.find('components') if not c.get('ref','').startswith('#')}
libparts={(x.get('lib'),x.get('part')):x for x in root.find('libparts')}
actual={}; nodes={}; nodeattrs={}; failures=[]; checks=[]

def check(name, condition, details=None):
 item={'check':name,'passed':bool(condition)}
 if details is not None:item['details']=details
 checks.append(item)
 if not condition:failures.append(item)

def net(ref,pin):return actual.get((ref,str(pin)))
def expect(ref,pins,tag):
 bad={str(k):{'expected':v,'actual':net(ref,k)} for k,v in pins.items() if net(ref,k)!=v}
 check(tag,not bad,bad if bad else {'ref':ref,'pins_checked':len(pins)})

for n in root.find('nets'):
 name=n.get('name'); members=[]
 for x in n:
  key=(x.get('ref'),x.get('pin'))
  if key[0].startswith('#'):continue
  if key in actual:failures.append({'check':'pin_occurs_on_multiple_nets','pin':key})
  actual[key]=name;nodeattrs[key]=dict(x.attrib);members.append(key)
 nodes[name]=members
check('unique_declared_references',len(parts)==len(rows))
check('exact_component_reference_set',set(parts)==set(comps),{'missing':sorted(set(parts)-set(comps)),'extra':sorted(set(comps)-set(parts))})
metadata_bad=[];pincoverage_bad=[];mapping_bad=[];nc=[]
for ref,p in parts.items():
 c=comps.get(ref)
 if c is None:continue
 f={x.get('name'):x.text or '' for x in c.findall('./fields/field')}
 for key,a,e in [('MPN',f.get('MPN'),p['mpn']),('value',c.findtext('value'),p['value']),('footprint',c.findtext('footprint'),p['footprint']),('manufacturer',f.get('Manufacturer'),p['manufacturer'])]:
  if a!=e:metadata_bad.append({'ref':ref,'field':key,'actual':a,'expected':e})
 ls=c.find('libsource');lp=libparts[(ls.get('lib'),ls.get('part'))]
 physical=[x.get('num') for x in lp.findall('./pins/pin')]
 if set(physical)!=set(p['pins']) or len(physical)!=len(set(physical)):
  pincoverage_bad.append({'ref':ref,'actual':physical,'expected':sorted(p['pins'])})
 for pin,expected in p['pins'].items():
  a=net(ref,pin)
  if expected is None:
   okay=a is None or (a.startswith('unconnected-') and nodes[a]==[(ref,pin)])
   nc.append({'ref':ref,'pin':pin,'native_net':a,'valid':okay})
  else:okay=a==expected
  if not okay:mapping_bad.append({'ref':ref,'pin':pin,'expected':expected,'actual':a})
extra_nodes=[{'ref':r,'pin':p,'net':n} for (r,p),n in actual.items() if r not in parts or p not in parts[r]['pins']]
check('MPN_value_manufacturer_footprint_preserved',not metadata_bad,metadata_bad)
check('all_physical_symbol_pins_present_once',not pincoverage_bad,pincoverage_bad)
check('all_declared_pin_to_net_assignments_exact',not mapping_bad,mapping_bad)
check('no_undeclared_physical_nodes',not extra_nodes,extra_nodes)
check('all_intentional_NC_pins_isolated',all(x['valid'] for x in nc),{'NC_pins':len(nc)})
singletons=[{'net':n,'pins':v} for n,v in nodes.items() if len(v)<2 and not n.startswith('unconnected-')]
check('no_unintended_singleton_or_empty_named_nets',not singletons,singletons)

# Physical pin expectations entered independently from TI/ST/AOS/Infineon datasheets.
expect('U101',{1:'EFUSE_IN',2:'EFUSE_IN',3:'EFUSE_IN',4:'EFUSE_BGATE',5:'EFUSE_DRV',6:'FUSED24',7:'EFUSE_UVLO',8:'EFUSE_OVP',9:'GND',10:'EFUSE_DVDT',11:'EFUSE_ILIM',13:'EFUSE_RESET_N',15:'FLT_INPUT_N',16:'EFUSE_PGTH',17:'PG_INPUT',18:'EFUSE_OUT',19:'EFUSE_OUT',20:'EFUSE_OUT',21:'GND'},'TPS26631_PWP20_plus_EP21_pin_map')
expect('Q101',{1:'EFUSE_BGATE',2:'EFUSE_IN',3:'FUSED24'},'IRFR3410_G1_D2_S3')
expect('Q102',{1:'EFUSE_DRV',2:'FUSED24',3:'EFUSE_BGATE'},'input_BSS138_source_is_fused_input')
expect('U901',{1:'CB_N15',2:'N15_RAW',3:'FB_N15',4:'EN_N15',5:'BUS24',6:'SW_N15'},'negative_LMR51610_local_ground_pin_map')
expect('U1001',{2:'FPGA5V5',6:'SW_CORE',7:'SW_CORE',11:'FPGA5V5',12:'GND',13:'FB_CORE',14:'SS_CORE',15:'EN_CORE',16:'PGR_CORE',17:'VREG5_CORE',18:'MODE_CORE'},'TPS568215_voltage_domain_and_output_pins')
check('TPS568215_no_invented_EP19',set(parts['U1001']['pins'])==set(map(str,range(1,19))))
expect('U1601',{1:'REFIN_VTT',2:'DDR1V35',3:'VTT',4:'GND',5:'VTT',6:'DDR_VREF',7:'EN_VTT',8:'GND',9:'PGR_VTT',10:'AON',11:'GND'},'TPS51200_bias_and_tracking_domains')
expect('U1901',{1:'I_N15_UNFILTERED',2:'I_N15_INV',3:'I_N15_NONINV',4:'N15_RAW',5:'GND',6:'V_N15_INV',7:'V_N15_UNFILTERED',8:'AON'},'OPA2991_negative_current_and_voltage_sign')

# Every high-current input branch must originate after the shared shunt.
branches={'U301':5,'U401':5,'U501':20,'U601':20,'U701':5,'U801':5,'U901':5}
check('all_seven_24V_converter_inputs_after_shared_shunt',all(net(r,p)=='BUS24' for r,p in branches.items()),{r:net(r,p) for r,p in branches.items()})
check('AON_enable_independent_of_managed_logic',net('U301',4)=='BUS24')
shunts=[]
for p in rows:
 if p['kind']=='R' and p['mpn'].startswith('WSL'):
  a,z=net(p['ref'],1),net(p['ref'],2)
  shunts.append({'ref':p['ref'],'mpn':p['mpn'],'raw_net':a,'load_net':z,'distinct':bool(a and z and a!=z)})
check('all_16_shunts_remain_distinct_not_merged',len(shunts)==16 and all(s['distinct'] for s in shunts),shunts)
check('one_shared_input_shunt',sum({s['raw_net'],s['load_net']}=={'BUS24_PRE_SHUNT','BUS24'} for s in shunts)==1)
expect('U3001',{1:'IAMP_INPUT',2:'GND',3:'BUS24_PRE_SHUNT',4:'BUS24',5:'AON'},'INA293A1_input_sense_polarity')
for p in rows:
 if p['mpn']=='INA301A1IDGKR':
  expect(p['ref'],{1:'AON',4:'GND',5:'GND',6:'OC_OK_N'},'INA301_bias_reset_fault_'+p['ref'])
  pair={net(p['ref'],8),net(p['ref'],7)}
  check('INA301_corresponds_to_existing_shunt_'+p['ref'],sum({s['raw_net'],s['load_net']}==pair for s in shunts)==1)

mux_pins=[9,8,7,6,5,4,3,2,23,22,21,20,19,18,17,16]
tags=['INPUT','AON','USB','SYS','FPGA','ANA6','P15','N15','CORE','AUX18','AUX25','IO33','DDR','PHY','ANA5','ANA33']
muxmap=[]
for i,(pin,tag) in enumerate(zip(mux_pins,tags)):
 expect('U3401',{pin:'MON_I_'+tag},'current_mux_address_'+str(i))
 expect('U3402',{pin:'MON_V_'+tag},'voltage_mux_address_'+str(i))
 muxmap.append({'address':i,'physical_pin':pin,'tag':tag,'current_net':net('U3401',pin),'voltage_net':net('U3402',pin)})
for ref in ('U3401','U3402'):expect(ref,{10:'MUX_A0',11:'MUX_A1',12:'GND',13:'MUX_A3',14:'MUX_A2',15:'MUX_DISABLE',24:'AON'},'shared_mux_controls_'+ref)
mcupins={1:'PWR_KILL_GPIO',2:'MATRIX_KILL_GPIO',3:'ALL_RAILS_PG',6:'AON',7:'AON',8:'AON',9:'GND',10:'EN_REQ_USB',12:'PM_RESET_N',13:'PWR_ARM_PULSE',14:'MATRIX_ARM_PULSE',15:'PM_WDI',16:'PM_WDO_N',17:'ADC_I',18:'ADC_V',19:'ADC_VTT',20:'PROG_V_P15',21:'EN_REQ_SYS',22:'EN_REQ_FPGA',23:'EN_REQ_ANA',24:'EN_REQ_P15',25:'EN_REQ_N15',26:'EN_REQ_CORE',27:'EN_REQ_AUX18',28:'EN_REQ_AUX25',29:'EN_REQ_IO33',30:'EN_REQ_DDR',31:'EN_REQ_PHY',32:'EN_REQ_VTT',33:'EN_REQ_ANA5',34:'EN_REQ_ANA33',35:'MUX_A0',36:'MUX_A1',37:'MUX_A2',38:'MUX_A3',39:'MUX_DISABLE',40:'PM_UART_TX',41:'PM_UART_RX',42:'PG_INPUT',43:'FLT_INPUT_N',44:'OC_OK_N',45:'PM_SWDIO_MCU',46:'PM_SWCLK_MCU',47:'GLOBAL_PWR_PERMIT',48:'MATRIX_PERMIT',49:'HOST_WDO_N',50:'PG_USB',51:'PG_SYS',52:'PG_FPGA',53:'PG_ANA',54:'PG_P15',55:'PG_N15',56:'PGR_CORE',57:'PGR_AUX18',58:'PGR_AUX25',59:'PGR_IO33',60:'PGR_DDR',61:'PGR_PHY',62:'PGR_VTT',63:'PGR_ANA5',64:'PGR_ANA33'}
expect('U2001',mcupins,'STM32G0B1_GP_all_61_assigned_physical_pins')
check('matrix_latch_reaches_controller_and_power_switches',net('U2201',9)=='MATRIX_PERMIT' and net('U2001',48)=='MATRIX_PERMIT' and len([p for p in rows if p['mpn']=='AO3400A' and net(p['ref'],1)=='MATRIX_PERMIT'])>=3)
check('no_stale_MATRIX_PWR_PERMIT_net','MATRIX_PWR_PERMIT' not in nodes)

# Standard symbol reuse must not silently swap physical package lead numbers.
standard=[]
for p in rows:
 expected=None
 if p['mpn'] in ('BSS138NH6327XTSA2','AO3400A','AO3401A'):expected={'1':'G','2':'S','3':'D'}
 if p['mpn']=='IRFR3410TRPBF':expected={'1':'G','2':'D','3':'S'}
 if p['mpn']=='BAT54S,215':expected={'1':'A1','2':'K2','3':'COM'}
 if p['mpn']=='BAT54A,215':
  # Standard KiCad BAT54A suppresses pin names. Its common-anode graphic
  # was inspected separately; verify exact manufacturer pin-to-net map.
  expect(p['ref'],{1:'AON_RESET_N',2:'PM_WDO_N',3:'PM_RESET_N'},'BAT54A_common_anode_reset_OR')
 if expected:
  observed={pin:nodeattrs.get((p['ref'],pin),{}).get('pinfunction') for pin in expected}
  if p['mpn']=='BAT54S,215':
   observed={k:({'A':'A1','K':'K2'}.get(v,v)) for k,v in observed.items()}
  ok=observed==expected
  standard.append({'ref':p['ref'],'mpn':p['mpn'],'expected_pinfunctions':expected,'native_pinfunctions':observed,'passed':ok})
check('standard_MOSFET_and_BAT54_symbols_keep_package_pin_functions',all(x['passed'] for x in standard),standard)
viol=[]
if ERC.exists():
 e=json.loads(ERC.read_text());viol=[v for s in e.get('sheets',[]) for v in s.get('violations',[])]
 check('native_KiCad_ERC_zero_violations',not viol,{'version':e.get('kicad_version'),'sheet_count':len(e.get('sheets',[])),'violations':len(viol)})
report={'status':'PASS' if not failures else 'FAIL','date':'2026-09-08','method':'Independent Python stdlib XML parser, exact comparison of every physical pin plus separately entered datasheet/domain expectations; no generator imports.','inputs':{str(p.relative_to(BASE)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in (XML,DESIGN,ERC)},'counts':{'components':len(parts),'physical_pins':sum(len(p['pins']) for p in rows),'native_nodes':len(actual),'intentional_NC_pins':len(nc),'native_nets':len(nodes),'signal_power_nets':sum(not n.startswith('unconnected-') for n in nodes),'shunts':len(shunts),'checks':len(checks),'failures':len(failures)},'checks':checks,'failures':failures,'mux_channel_map':muxmap,'MCU_physical_pin_assignment':{str(k):v for k,v in mcupins.items()},'limitations':['Netlist/metadata equivalence and named physical pin expectations do not prove analog stability, hardware timing, thermal behavior or physical routing.','KiCad PWR_FLAG symbols are non-BOM validation declarations and omitted from component matching.','Intentional NC pins must be omitted from nets or isolated on exactly one native unconnected net.']}
OUT.mkdir(exist_ok=True);(OUT/'netlist_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'counts':report['counts'],'failures':failures},ensure_ascii=False,indent=2))
sys.exit(bool(failures))
