"""Audit the delivered hierarchy's physical pin sets against bundled footprints.

Follow referenced sheets only (ignore any obsolete unreferenced scratch sheets).
This verifies structural pin/pad correspondence, footprint/model availability,
and >=0.20mm copper gaps; it does not substitute for circuit or PCB DRC review.
"""
from pathlib import Path
import csv
import hashlib
import json
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE.parent / 'tools'))
from sexpr import child, children, load, properties, value
from audit_footprints import audit


def sortpins(pins):
    return sorted(pins, key=lambda s: (not s.isdigit(), int(s) if s.isdigit() else s))


def check(project):
    todo = [project / (project.name + '.kicad_sch')]
    seen = set()
    rows = []
    file_hashes = {}
    fp_cache = {}
    while todo:
        path = todo.pop()
        if path in seen:
            continue
        seen.add(path)
        doc = load(path)
        file_hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        defs = {s[1]: s for s in children(child(doc, 'lib_symbols'), 'symbol')}
        for sheet in children(doc, 'sheet'):
            todo.append(path.parent / properties(sheet)['Sheetfile'])
        for placed in children(doc, 'symbol'):
            if str(value(placed, 'on_board', 'yes')) == 'no':
                continue
            props = properties(placed)
            ref = props['Reference']
            if ref.startswith('#'):
                continue
            footprint = props.get('Footprint', '')
            entry = {'reference':ref, 'mpn':props.get('MPN', ''), 'sheet':path.name,
                     'footprint':footprint, 'issues':[]}
            if ':' not in footprint:
                entry['issues'].append('No qualified footprint library/name')
                rows.append(entry)
                continue
            lib, fpname = footprint.split(':', 1)
            fppath = project / 'libraries' / (lib + '.pretty') / (fpname + '.kicad_mod')
            if not fppath.exists():
                entry['issues'].append('Bundled footprint file missing')
                rows.append(entry)
                continue
            if footprint not in fp_cache:
                fpnode = load(fppath)
                padnums = {str(p[1]) for p in children(fpnode, 'pad') if str(p[1]) and any(str(x).endswith('.Cu') for x in child(p, 'layers')[1:])}
                models = []
                for model in children(fpnode, 'model'):
                    loc = str(model[1])
                    expanded = Path(loc.replace('${KIPRJMOD}', str(project)))
                    models.append({'path':loc, 'exists':expanded.exists(), 'body_envelope_only':'BODY_ENVELOPE' in loc})
                fp_cache[footprint] = {'pad_numbers':padnums, 'clearance':audit(fppath),
                                       'models':models, 'sha256':hashlib.sha256(fppath.read_bytes()).hexdigest()}
            data = fp_cache[footprint]
            definition = defs.get(value(placed, 'lib_id'))
            if definition is None:
                entry['issues'].append('Embedded symbol definition missing')
                rows.append(entry)
                continue
            unit = int(value(placed, 'unit', 1))
            pin_numbers = set()
            for sub in children(definition, 'symbol'):
                suffix = str(sub[1]).rsplit('_', 2)
                if len(suffix) < 3 or int(suffix[-2]) not in (0, unit):
                    continue
                for pin in children(sub, 'pin'):
                    pin_numbers.add(str(value(pin, 'number')))
            entry.update({'symbol_pin_numbers':sortpins(pin_numbers),
                          'footprint_pad_numbers':sortpins(data['pad_numbers']),
                          'minimum_copper_gap_mm':data['clearance']['minimum_copper_gap_mm'],
                          'footprint_sha256':data['sha256'], 'models':data['models']})
            if pin_numbers != data['pad_numbers']:
                entry['issues'].append({'symbol_pins_without_pads':sortpins(pin_numbers-data['pad_numbers']),
                                        'pads_without_symbol_pins':sortpins(data['pad_numbers']-pin_numbers)})
            instance_pins = {str(p[1]) for p in children(placed, 'pin')}
            if instance_pins != pin_numbers:
                entry['issues'].append({'placed_pin_ids_differ_from_definition':sortpins(instance_pins ^ pin_numbers)})
            if not data['clearance']['pass_0p20mm']:
                entry['issues'].append({'copper_clearance_failure':data['clearance']['issues']})
            if not data['models'] or not all(m['exists'] for m in data['models']):
                entry['issues'].append('Bundled model absent or a model path does not resolve')
            rows.append(entry)
    rows.sort(key=lambda r: (''.join(c for c in r['reference'] if not c.isdigit()), int(''.join(c for c in r['reference'] if c.isdigit()) or 0)))
    duplicates = sorted({r['reference'] for r in rows if sum(z['reference']==r['reference'] for z in rows)>1})
    report = {'project':str(project), 'scope':'All referenced schematic sheets; physical symbol pins versus numbered copper pads, bundled models, copper geometry. Same-number EP subdivisions count as one electrical pad. Circuit function and PCB routing remain separate checks.',
              'schematic_sha256':file_hashes, 'sheet_count':len(seen), 'component_count':len(rows),
              'unique_footprint_count':len(fp_cache), 'duplicate_references':duplicates,
              'pass':not duplicates and all(not r['issues'] for r in rows),
              'failed_components':[r['reference'] for r in rows if r['issues']], 'components':rows}
    return report


if __name__ == '__main__':
    project = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else BASE.parent / 'MIRA_Power_RevB'
    report = check(project)
    out = BASE / 'final_pin_pad_audit.json'
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
    with (BASE / 'final_pin_pad_audit.csv').open('w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Reference','MPN','Sheet','Footprint','Symbol pins','Copper pad numbers','Minimum copper gap mm','Pass','Issues'])
        for r in report['components']:
            writer.writerow([r['reference'],r['mpn'],r['sheet'],r['footprint'],','.join(r.get('symbol_pin_numbers',[])),','.join(r.get('footprint_pad_numbers',[])),r.get('minimum_copper_gap_mm',''),not r['issues'],json.dumps(r['issues'],ensure_ascii=False)])
    print(json.dumps({k:v for k,v in report.items() if k not in ('components','schematic_sha256')}, indent=2))
    for row in report['components']:
        if row['issues']:
            print(row['reference'], row['issues'])
    sys.exit(0 if report['pass'] else 1)
