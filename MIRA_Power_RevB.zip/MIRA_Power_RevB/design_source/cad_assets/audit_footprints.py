"""Check actual copper polygons, including rotation/corners/exposed-pad subdivisions.
Rounded corners use 256 segments per quadrant; numerical tolerance is 1e-6 mm.
Same pad-number copper is one electrical pad.
"""
import sys,math,json,itertools,csv
from pathlib import Path
sys.path[:0]=[str(Path(__file__).parent/'vendor'),str(Path(__file__).parents[1]/'tools')]
from sexpr import load,child,children,value
from shapely.geometry import box,Point,LineString,Polygon
from shapely import affinity
from shapely.ops import unary_union
base=Path(__file__).parent

def polygon(p):
 s=child(p,'size');w,h=map(float,s[1:3]);shape=str(p[3])
 if shape=='rect':g=box(-w/2,-h/2,w/2,h/2)
 elif shape=='circle':g=Point(0,0).buffer(w/2,resolution=256)
 elif shape in ['roundrect','oval']:
  r=min(w,h)*(float(value(p,'roundrect_rratio',.25)) if shape=='roundrect' else .5)
  if min(w,h)-2*r<1e-10:
   g=LineString([(-max(0,w/2-r),-max(0,h/2-r)),(max(0,w/2-r),max(0,h/2-r))]).buffer(r,resolution=256)
  else:g=box(-w/2+r,-h/2+r,w/2-r,h/2-r).buffer(r,resolution=256)
 elif shape=='custom':
  geoms=[box(-w/2,-h/2,w/2,h/2)]
  for pr in child(p,'primitives')[1:]:
   if pr[0]!='gr_poly':raise ValueError(f'unsupported custom primitive {pr[0]}')
   pts=[z[1:3] for z in child(pr,'pts')[1:]]
   poly=Polygon(pts);width=float(value(pr,'width',0))
   geoms.append(poly.buffer(width/2) if width else poly)
  g=unary_union(geoms)
 else:raise ValueError(f'unsupported pad shape {shape}')
 at=child(p,'at');x,y=map(float,at[1:3]);angle=float(at[3]) if len(at)>3 and isinstance(at[3],(int,float)) else 0
 return affinity.translate(affinity.rotate(g,angle,origin=(0,0)),x,y)

def audit(f):
 n=load(f);pads=[];skipped=0;issues=[]
 for p in children(n,'pad'):
  layers=child(p,'layers')[1:]
  if not any(str(x).endswith('.Cu') for x in layers):continue
  if not str(p[1]):raise ValueError(f'{f}: anonymous copper pad')
  pads.append((str(p[1]),set(str(x) for x in layers if str(x).endswith('.Cu')),polygon(p)))
 distances=[]
 for a,b in itertools.combinations(pads,2):
  if a[0]==b[0]:skipped+=1;continue
  if not (a[1]&b[1] or '*.Cu' in a[1] or '*.Cu' in b[1]):continue
  d=a[2].distance(b[2]);distances.append((d,a[0],b[0]))
  if d<.2-1e-6:issues.append({'pad1':a[0],'pad2':b[0],'gap_mm':round(d,7)})
 # Any standalone front-copper geometry is included and flagged rather than assigned a guessed net.
 copper_graphics=[x[0] for x in n if isinstance(x,list) and str(x[0]).startswith('fp_') and value(x,'layer') in ['F.Cu','B.Cu']]
 if copper_graphics:issues.append({'unassigned_copper_graphics':copper_graphics})
 least=min(distances) if distances else (None,None,None)
 return {'footprint':f.stem,'minimum_copper_gap_mm':round(least[0],6) if least[0]!=None else None,'closest_pad_pair':least[1:],'same_pad_number_pairs_excluded':skipped,'numbered_copper_shapes':len(pads),'pass_0p20mm':not issues,'issues':issues}

if __name__=='__main__':
 fs=sorted((base/'MIRA_Power.pretty').glob('*.kicad_mod'))
 rows=[audit(f) for f in fs]
 (base/'audit'/'footprint_clearances.json').write_text(json.dumps(rows,indent=2))
 with (base/'audit'/'footprint_clearances.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['Footprint','Minimum copper gap, mm','Closest pads','Pass >=0.20mm','Same pad-number pairs excluded'])
  for r in rows:w.writerow([r['footprint'],r['minimum_copper_gap_mm'],'-'.join(str(x) for x in r['closest_pad_pair']),r['pass_0p20mm'],r['same_pad_number_pairs_excluded']])
 for r in rows:print(r['footprint'],r['minimum_copper_gap_mm'],'PASS' if r['pass_0p20mm'] else r['issues'])
