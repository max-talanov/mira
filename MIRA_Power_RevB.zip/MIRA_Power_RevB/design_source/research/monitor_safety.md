# MIRA power monitor and hardware shutdown recommendations

Research date: 2026-09-08. Scope: 18–36 V protected input, positive output branches, controller, analog telemetry multiplexing, hardware permit latch. Negative rail details belong to the secondary-rail design.

## Selected architecture

- Input current: **INA293A1IDBVR**, analog gain20, −4 to110 V common-mode, SOT-23-5. Input voltage:150 kΩ/10 kΩ divider. They occupy matching channel0 in the two telemetry muxes. This removes the I2C monitor and avoids the current INA228/INA238 procurement issue. No36 V-rated INA226 on the18–36 V input because there is no upper margin.
- Positive output current: one INA301A1IDGKR per monitored output. It contains an analog gain-20 current-sense amplifier and a hardware overcurrent comparator. Its ALERT does not require I2C configuration or MCU code.
- Output voltage: resistor divider after each shunt, followed by RC filtering and voltage multiplexer.
- Telemetry collection: two CD74HC4067PWR analog multiplexers, shared four address GPIOs and shared disable GPIO; one selects current, the other voltage. A TLV9002IDGKR dual opamp buffers their common terminals before two STM32 ADC inputs. Hardware overcurrent signals bypass both multiplexers and the MCU.
- Common overcurrent net asynchronously clears a 74HC74 permit flip-flop. D is high and a positive ARM edge sets Q only when all hardware prerequisites are healthy. Each converter EN is the AND of Q and its MCU request.
- AON converter always starts independently. AON itself is not powered or enabled by the permit latch. Its own converter current limit and primary input protection remain responsible for an AON short.

This saves one digital monitor per output but is intentionally diagnostic telemetry, not a precision near-zero-current instrument. INA301 output swing is about 20 mV typical, 30 mV maximum above ground under the datasheet load condition. With gain 20 and a 10 mΩ shunt, measurements below approximately 100–150 mA are affected by output saturation. With 100 mΩ this becomes approximately 10–15 mA. Calibration cannot recover current that is clipped by the output floor.

## Component comparison

| Device | Channels / voltage | Package | Decision |
|---|---|---|---|
| INA226 | 1 / 36 V | VSSOP-10 | Good output telemetry; unsuitable for input upper-margin requirement; sampled ALERT is not a fast analog comparator. |
| INA228 | 1 / 85 V | VSSOP-10 DGS | Alternative input telemetry;20-bit ADC; no reliance on ALERT for the primary fast protection. |
| INA238 | 1 / 85 V | VSSOP-10 DGS | Cheaper 16-bit input alternative, exact assembly and software variant must be recorded. |
| INA3221 | 3 / 26 V | **VQFN-16, 4×4 mm RGV only in current datasheet** | Cost-effective output I2C telemetry, but requires additional independent fast protection. Not an input monitor. |
| PAC1954 | 4 / 32 V | VQFN-16, 3×3 mm or WLCSP | Economical output telemetry option, but below input maximum and not selected here. Do not confuse it with a 50/85 V device. |
| INA300 | Comparator only / 36 V | VSSOP-10 or WSON-10 | Requires separate telemetry. Selectable response 10/50/100 µs. INA301 has greater functional integration for this design. |
| INA301A1 | Analog current + comparator / 36 V | VSSOP-8 DGK, 0.65 mm pitch | Selected on positive outputs, not the input. |
| TPS2595 family | eFuse / 18 V | WSON-8 | Actual output disconnection and current limiting, but extra component per branch and package/thermal cost. Useful if a branch requires isolation from stored upstream energy; not included as a universal substitute for buck EN. |

## Exact INA301A1 circuit

| Pin | Name | Connection |
|---|---|---|
| 1 | VS | +3V3_AON, local 100 nF to GND |
| 2 | OUT | 1 kΩ series to `MON_I_x`; 10 nF from `MON_I_x` to GND; then current multiplexer channel |
| 3 | LIMIT | 10.0 kΩ, 1%, to local GND for nominal 0.800 V threshold; tune where converter minimum current limit requires |
| 4 | GND | GND, short local return for LIMIT resistor and supply capacitor |
| 5 | RESET | GND: transparent comparator mode; the common 74HC74 provides latch-off |
| 6 | ALERT | Active-low open-drain; common `OC_OK_N`, pulled up once with 10 kΩ to AON |
| 7 | IN− | Kelvin sense at load side of shunt |
| 8 | IN+ | Kelvin sense at source side of shunt |

Do not place the telemetry OUT low-pass filter in the comparator sense path. Avoid long sense wires; put the IC beside its shunt. Do not place large input capacitors or unmatched series sense resistors without checking datasheet input-filter error. Primary schematic can use direct Kelvin inputs.

Rshunt is a metal-element current-sense resistor with explicit MPN, tolerance and power rating, not a generic 0201 resistor. Use 1206/2010/2512 as actual dissipated power and available resistance require. Near load currents below 1 A, suitable 0805/1206 parts can be used after pulse and thermal checks.

For gain 20 and internal LIMIT current 80 µA:

`V_OUT = 20 × R_SHUNT × I`

`I_TRIP_NOM = (80 µA × R_LIMIT)/(20 × R_SHUNT)`

With 10 kΩ R_LIMIT, differential trip is 40 mV:

| Rshunt | Nominal trip | Shunt power at trip | Approximate 30 mV output-floor equivalent |
|---|---:|---:|---:|
| 200 mΩ | 0.20 A | 8 mW | 7.5 mA |
| 100 mΩ | 0.40 A | 16 mW | 15 mA |
| 20 mΩ | 2.0 A | 80 mW | 75 mA |
| 10 mΩ | 4.0 A | 160 mW | 150 mA |
| 5 mΩ | 8.0 A | 320 mW | 300 mA |

These are threshold choices, **not finalized load ratings**. Do not pick 8 A for a 5 A buck automatically: if the buck's minimum current limit is below the comparator threshold, it can remain in hiccup without ever setting the external latch. Select Itrip above the largest permitted steady load plus startup current, and below the lowest actual fault-limited current which must cause latch-off. Coordination with each converter and downstream capacitance is required.

Illustrative worst-case threshold estimate at 25 °C: current source tolerance ±0.375%, R_LIMIT ±1%, gain ±0.1%, shunt ±1%, comparator offset up to 3.5 mV relative to 0.8 V (±0.44%), input offset up to 35 µV relative to 40 mV (±0.088%). Arithmetic worst-case sum approximately ±3.0%, before temperature and shunt TCR. Across temperature the LIMIT current alone reaches ±1%; other drift terms must be added. Use ±5% or calculate the exact component/temperature corner rather than promise exact 2/4/8 A.

Datasheet total comparator propagation is up to 1 µs for a 1 mV input overdrive test; slew-rate-limited example up to 1.5 µs. These are comparator figures, **not total load-disconnection time**. Buck EN reaction, residual inductor current, and output-capacitor discharge remain additional effects. An EN command does not isolate a load from its own output capacitor.

For low FPGA voltages, remember that 40 mV at trip is 4% of a 1.0 V rail. The load voltage divider always measures after shunt. Converter feedback must either sense the load side with a reviewed loop layout, or the shunt/threshold must be reduced to fit the voltage tolerance. Do not silently add shunt drop to a core rail's allowed error.

## Final input INA293A1 connections

| Pin | Name | Connection |
|---|---|---|
|1|OUT|1kΩ series to `MON_I_IN`,10nF from MON_I_IN toGND, then current MUX CH0|
|2|GND|GND|
|3|IN+|Kelvin source side of input shunt|
|4|IN−|Kelvin load side of input shunt|
|5|VS|+3V3_AON,100nF local|

**Use A1, not B1:** INA293B has a different pinout. INA293A1 gain=20V/V; common-mode operating −4..110V; supply2.7..20V. Positive-only output current readout. No comparator in this IC: the input eFuse handles hardware overcurrent.

Input shunt after primary protection/filtering and before splitting to AON/all managed converters. This measures protected-bus consumption including AON, but excludes upstream protection/filter losses. Input-voltage sense `MON_V_IN`: protected bus →150kΩ→MON_V_IN→10kΩ→GND,10nF MON_V_IN-toGND; MUX_V CH0. Scale16 gives1.125V at18V and2.25V at36V. Select voltage-rated upper resistor, preferably0402/0603 or divide150k into series resistors; do not assume an0201 resistor can sustain36V.

Input shunt candidate20mΩ,1%,≥1W metal-element1206/2010:70mV/245mW at3.5A, INA293 OUT1.4V. A10mΩ alternative dissipates122.5mW and generates0.7V at3.5A, but doubles the low-current equivalent floor. With20mΩ, INA293 output swing5mV typical/20mV maximum corresponds to12.5/50mA. Specified gain-accuracy range starts at50mV output, which corresponds to125mA. With10mΩ these figures double. Thus standby-input measurement is qualitative nearzero; do not claim digital-monitor precision.

INA293A1 maximum input offset150µV corresponds to7.5mA with20mΩ. Positive/negative offset and output floor complicate zero calibration. The complete telemetry error includes shunt tolerance/TCR, INA293 gain/offset, mux leakage, buffer offset, and ADC/reference.

The supply comparator/FLT/PG path from the input eFuse provides hardware shutdown. Input eFuse cutoff can collapse AON; reliable input-fault nonvolatile logging requires an independently calculated AON hold-up reservoir.

## Dual CD74HC4067PWR multiplexer

Use **HC**, which operates at 3.3 V; do not substitute HCT requiring 4.5–5.5 V. PWR is TSSOP-24, 0.65 mm pitch. Stock KiCad body dimensions must match the TI PW0024A drawing; datasheet headline body-size text is ambiguous and should not drive footprint generation.

| Signal | Pin |
|---|---:|
| COM | 1 |
| CH0, CH1, CH2, CH3 | 9, 8, 7, 6 |
| CH4, CH5, CH6, CH7 | 5, 4, 3, 2 |
| CH8, CH9, CH10, CH11 | 23, 22, 21, 20 |
| CH12, CH13, CH14, CH15 | 19, 18, 17, 16 |
| S0, S1, S2, S3 | 10, 11, 14, 13 |
| E, high disables all channels | 15 |
| GND | 12 |
| VCC | 24 |

- VCC = AON, 100 nF per mux. All analog input voltages must remain between GND and VCC during normal operation.
- Four address signals shared between the V and I muxes, with 100 kΩ pulldowns so channel 0 is the initial address.
- E shared, 10 kΩ pull-up to AON, so both muxes are initially disconnected until the MCU enables telemetry.
- COM_I and COM_V each go to a TLV9002 unity follower. TLV9002IDGKR pins:1OUT_A,2IN−_A,3IN+_A,4V−=GND,5IN+_B,6IN−_B,7OUT_B,8V+=AON. Connect1to2,7to6; COM_Ito3 andCOM_Vto5.100nF atpin8. Each buffer OUT→100Ω→ADC pin,1nF ADC-toGND. This isolates ADC sampling capacitance from the mux/divider. Use long ADC acquisition time and discard the first sample after a channel change.
- Start with at least 0.5–1 ms settling after a channel change when using high-value voltage dividers and 10 nF channel capacitors; check actual settling by driving known voltages and comparing consecutive samples. A complete 16-channel scan can still easily run tens of times per second.
- Voltage divider examples: 10 kΩ top / 10 kΩ bottom for outputs up to 6 V; 47 kΩ top / 10 kΩ bottom for +15 V. These values are diagnostic defaults, not a precision error budget. 1% resistor ratios, mux leakage, and MCU ADC/reference errors affect measurement. Lower both divider values by a factor of ten if leakage error is unacceptable; use 0.1% matched divider resistors if required later.
- 10 nF from each voltage-mux channel to GND; this filter is before the mux. Current channels use the INA301 OUT filter described above.
- Tie unused channels to GND; make the two muxes use exactly the same channel-to-rail map.
- Positive rails with retained output charge after AON loss can inject through mux/ADC protection diodes. Series dividers limit this current, but board power-down/backfeed behavior must be checked. A rail that can be externally powered while AON is off requires deliberate powered-off isolation or an appropriate fail-safe analog switch. Do not claim the HC4067 has powered-off input protection.

The required 0.20 mm copper-to-copper gap is about actual pad geometry, not pitch alone. For TSSOP/VSSOP with 0.65 mm pitch, a 0.40 mm pad width gives 0.25 mm side-to-side clearance; for DGS 0.50 mm pitch, 0.30 mm pad width gives exactly 0.20 mm. Also check corner-to-corner distances, pad-to-exposed-pad spacing, solder-mask expansion, and the chosen manufacturer's landing recommendation. Do not narrow copper lands below a justified footprint merely to pass a report.

## TPS3851 supervisor and separate reset/watchdog nets

TPS3851H33EDRBR pin map:

| Pin | Name | Recommended connection |
|---|---|---|
| 1 | VDD | AON +100 nF |
| 2 | CWD | No connect for factory 1.6 s watchdog setting |
| 3 | MR_N | 10 kΩ to AON; momentary manual reset switch/TP to GND |
| 4 | GND | GND |
| 5 | SET1 | AON, fixed watchdog enabled; optional development disable jumper to GND only if clearly documented |
| 6 | WDI | MCU `PM_WDI`, 100 kΩ pulldown; software supplies falling edges well inside 1.36 s minimum |
| 7 | WDO_N | `PM_WDO_N`, separate 10 kΩ pull-up to AON |
| 8 | RESET_N | `AON_RESET_N`, separate 10 kΩ pull-up to AON |
| exposed pad | GND | GND copper |

CWD left open and SET1 high produces 1.6 s nominal (1.36–1.84 s) watchdog timeout. Reset delay is 200 ms nominal (170–230 ms). Do not show a timing capacitor if using the factory setting.

Preferred reset option: logic AND `PM_RESET_N = AON_RESET_N AND PM_WDO_N` toMCU NRST, retaining separate WDO net. Parent may select an alternate: AON_RESET_N alone toNRST, WDO only topermit clear andMCU input, with internalIWDG for MCU restart. In the alternate, **external WDO itself does not reset MCU**; recovery requires responsive firmware or separately configuredIWDG. Never describe it as an external-watchdog reset path when it is only an external hardware power-stop path. No latch output is fed back into NRST. In particular, an overcurrent fault disables load power but leaves the MCU running from AON so it can report and accept recovery commands.

When WDO times out, it asserts for tRST and then releases; permit clears. With the preferred combined-reset option MCU restarts immediately. With the alternate separate-NRST option MCU restarts only via internalIWDG or software. Firmware must initialize all requests low, start WDI service and internal IWDG, diagnose state, and wait for a deliberate new ARM command. Reset is not permission to restart every load automatically. Internal IWDG gives additional coverage but does not replace external WDO-to-latch hardware.

## Hardware permit latch and enables

Use a genuine 74HC74-family device operating at 3.3 V (not HCT/ACT). TSSOP-14, 0.65 mm pitch meets clearance with a suitable land width. SN74HC74PWR and Nexperia 74HC74PW are functional examples; verify active exact ordering code and current stock in the BOM procurement snapshot. Standard dual-device pinout:

| Pin | Connection for permit half |
|---|---|
| 1, /1CLR | `SAFE_CLEAR_N` |
| 2, 1D | AON |
| 3, 1CLK | `PWR_ARM_PULSE`, 10 kΩ to GND |
| 4, /1PRE | AON |
| 5, 1Q | `HW_PERMIT` |
| 6, /1Q | `HW_KILL`, active high when not permitted; test/MCU input |
| 7 | GND |
| 14 | AON, 100 nF local |
| 13 /2CLR | GND if unused |
| 12 2D, 11 2CLK | GND if unused |
| 10 /2PRE | AON if unused |
| 8 /2Q, 9 2Q | No connect if unused |

`OC_OK_N`: wired open-drain low-true fault bus from all INA301 ALERT pins, input eFuse FLT if its off-state behavior is suitable, and optional externally accessible manual KILL pushbutton/open-drain input. One 10 kΩ pull-up to AON. Optional MCU-controlled shutdown must be genuinely open drain (or external NMOS) if it shares this bus; never connect a push-pull high output against a fault output.

`SAFE_CLEAR_N = AON_RESET_N AND PM_WDO_N AND OC_OK_N [AND INPUT_READY]`.

- INPUT_READY may be the always-on primary protected-input PGOOD prerequisite; confirm actual primary device pin semantics.
- Do not directly include PGOOD from a managed converter. Such a converter starts with PGOOD low while disabled, which would prevent ARM and create a startup deadlock.
- SW shutdown can pull OC_OK_N low, or use a dedicated fourth AND prerequisite with a safe default.
- A momentary pushbutton from OC_OK_N to GND provides a hardware stop independent of MCU execution. Release does not re-enable: another positive ARM edge is required.
- ARM is held low by an external resistor during MCU reset. A stuck-high ARM cannot generate a new positive edge after a fault; Q remains zero until a real low-to-high edge occurs after clear has been released and recovery timing is met.
- If clear is low, Q remains low regardless of ARM clock. /PRE stays high, so the forbidden simultaneous preset/clear combination is avoided.

Every managed converter: `EN_x = HW_PERMIT AND REQ_x`, with 100 kΩ pulldown on REQ_x and 100 kΩ pulldown at actual converter EN. Use 74HC08/74LVC08 AND gates at AON or validated equivalent. Tie unused logic inputs to defined levels. Do not use an open-drain MCU output without an explicit pull-up where an active-high request is intended.

Do not promise certified fail-safe power-up below the logic IC's minimum supply. Supervisor RESET is undefined below its POR voltage, although EN pulldowns and rising-supply behavior are designed to favor OFF. Validate a slow AON ramp, bounce, and brownout with the actual converter EN thresholds; additional EN clamps may be needed if a converter can enable from a sub-threshold logic output.

## Startup and recovery contract

1. Primary input protection becomes valid. AON converter starts independently.
2. AON supervisor holds controller reset and asynchronous permit clear until AON is valid for the reset delay. Requests and ARM remain low.
3. Firmware starts watchdog service and internal IWDG before ARM; configuresADC andmuxes; verifies input voltage and absence of active hardware faults.
4. Firmware issues one ARM rising edge, returning it low afterward. Q becomes high; no rail turns on yet while its request is low.
5. Firmware raises one request, waits for its PGOOD within a bounded timeout, checks its voltage/current, then continues. Parent/child supply dependencies are encoded in this sequence.
6. Hardware overcurrent clears Q immediately without waiting for mux sampling or firmware. All managed EN signals fall. The MCU remains on AON if the primary input and AON are healthy.
7. Recovery requires clearing requests, identifying/removing fault, verifying OC_OK_N high, and a deliberate ARM edge. No periodic automatic re-arm into a short.
8. Normal shutdown removes requests in dependency order, then clears permit. Stored energy and output-discharge behavior are converter-specific and must be included in the rail design.

## Current-limit coordination update from buck research

- LMR51610 high-side limit1.25A minimum, low-side valley limit0.9A minimum:20mΩ/2A INA301 trip is unsuitable. Use50mΩ/0.8A trip for USB/low-powerAFE outputs with≤0.6A design load; AON100mΩ/0.4A trip with≤0.3A expected load. Local buck protection still owns AON short behavior.
- LM76005 high-side limit6.0A minimum, low-side valley4.5A minimum:10mΩ/4A trip is usable for≤3A SYS. A4A nominalFPGA feed has insufficient overload margin with4A trip;8mΩ/5A trip is not guaranteed before internal valley limiting. Derate its design load (e.g.≤3.2A and4Atrip), compute tighter thresholds, or add qualified hardware undervoltage detection with startup masking.
- Comparators for output undervoltage must be masked while a rail is intentionally off and through a bounded startup interval. Do not OR raw lowPG into the common latch clear.

## Procurement evidence and limits

Final input INA293A1IDBVR procurement evidence from root: DigiKeyUS2,248 stock, $3.35 single/$2.515 at10, https://www.digikey.com/en/products/detail/texas-instruments/INA293A1IDBVR/11502190 .

Search results on the research date showed INA301A1IDGKR at DigiKey, 2,066 units and $3.04 at quantity one, $2.277 at ten. TI product status is ACTIVE. Mouser also had inventory, with differing regional prices. This supports a practical selection, not a guaranteed local-country supply route.

INA228AIDGSR: TI ACTIVE, indicative direct price ~$3.72 at one; DigiKey US/Mouser/TME rendered zero stock, while a regional indexed DigiKey result showed 6,357 and Spirit Electronics showed 218 at $4.46. INA238 likewise had inconsistent regional pages (53–82 in some results and zero in US direct pages). Thus **do not claim an assured stocked source for the input monitor from search snippets alone**; capture the supplier cart for the intended delivery location before ordering. INA228 and INA238 remain technically suitable choices and can share the same PCB geometry with correctly selected firmware.

## Primary sources

- INA293 datasheet:https://www.ti.com/lit/gpn/INA293
- TLV9002 datasheet:https://www.ti.com/lit/ds/symlink/tlv9002.pdf
- INA301 datasheet: https://www.ti.com/lit/ds/symlink/ina301.pdf
- INA301 manufacturer part page: https://www.ti.com/product/INA301/part-details/INA301A1IDGKR
- INA228 datasheet: https://www.ti.com/lit/ds/symlink/ina228.pdf
- INA238 datasheet: https://www.ti.com/lit/ds/symlink/ina238.pdf
- INA226 datasheet: https://www.ti.com/lit/ds/symlink/ina226.pdf
- INA3221 datasheet: https://www.ti.com/lit/ds/symlink/ina3221.pdf
- PAC1954 manufacturer page and datasheet: https://www.microchip.com/en-us/product/pac1954 and https://ww1.microchip.com/downloads/aemDocuments/documents/APID/ProductDocuments/DataSheets/PAC1951-2-3-4-Single-Multi-Channel-Power-Monitor-with-Accumulator-32V-Full-Scale-Range-DS20006539.pdf
- INA300 datasheet: https://www.ti.com/lit/ds/symlink/ina300.pdf
- CD74HC4067 datasheet: https://www.ti.com/lit/ds/symlink/cd74hc4067.pdf
- CD74HC4067 TSSOP pinout manufacturer clarification: https://e2e.ti.com/support/switches-multiplexers-group/switches-multiplexers/f/switches-multiplexers-forum/1573227/cd74hc4067-tssop-and-vqfn-package-pinout-missing
- TPS3851 datasheet: https://www.ti.com/lit/ds/symlink/tps3851.pdf
- 74HC74 datasheet: https://www.ti.com/lit/ds/symlink/sn74hc74.pdf
- TPS2595 datasheet: https://www.ti.com/lit/ds/symlink/tps2595.pdf
- INA301 supplier evidence: https://www.digikey.com/en/products/detail/texas-instruments/INA301A1IDGKR/6571979
- INA228 supplier evidence: https://www.digikey.com/en/products/detail/texas-instruments/INA228AIDGSR/13691042 and https://spiritelectronics.com/shop/amplifiers/ina228aidgsr/
