# Adopted MIRA 24 V buck circuits — build specification

This supersedes `bucks.md`. Parent chose LMR51610XDBVR for three low-current rails and LM76005RNPR for both high-current rails. Load estimates are design budgets, not measured loads. Calculations assume protected input 18–36 V and the selected components, with no simultaneous full-rail power promise beyond the input protection budget.

## LM76005RNPR: identical power stage for SYS and FPGA intermediate

Primary reference: https://www.ti.com/lit/ds/symlink/lm76005.pdf (downloaded locally). Use TI RNP0030B 30-lead WQFN 4×6 mm, 0.5 mm pitch, exposed pad31. All numbers must be represented explicitly in the symbol and footprint.

| Pin | Name | Connection |
|---:|---|---|
|1|SW|local SW node|
|2|SW|local SW node|
|3|SW|local SW node|
|4|SW|local SW node|
|5|SW|local SW node|
|6|BOOT|470 nF to SW|
|7|NC|no connect|
|8|VCC|2.2 µF to GND|
|9|BIAS|local output before shunt, 1 µF to GND|
|10|RT|no connect, internal 400 kHz|
|11|SS/TRK|22 nF to GND|
|12|FB|divider midpoint|
|13|AGND|GND|
|14|AGND|GND|
|15|AGND|GND|
|16|PGOOD|unique PG rail net, 10 kΩ pullup to AON|
|17|SYNC/MODE|GND, automatic PFM|
|18|EN|hardware-gated request, 100 kΩ to GND|
|19|NC|GND per manufacturer|
|20|PVIN|protected/filtered 24 V|
|21|PVIN|protected/filtered 24 V|
|22|PVIN|protected/filtered 24 V|
|23|NC|no connect|
|24|PGND|GND|
|25|PGND|GND|
|26|PGND|GND|
|27|NC|GND per manufacturer|
|28|NC|GND per manufacturer|
|29|NC|GND per manufacturer|
|30|NC|GND per manufacturer|
|31|EP|GND, soldered thermal pad|

EN starts above 1.25 V worst case, full shutdown below0.3 V. SS22 nF gives about11 ms. PG is open drain. Reference nominal1.006 V (range0.987–1.017 V); peak current limit6.0–7.8 A and valley limit4.5–5.8 A. **Do not copy LM76003 NC7/23 grounding or500 kHz default.**

| Function | Value and package | Quantity per high rail | Preferred part/source |
|---|---|---:|---|
| Buck | 60 V,5 A,WQFN30 |1|TI LM76005RNPR|
| Inductor |6.8 µH,±20%,shielded,12 A Isat,6.8 A Irms,42.5 mΩ max |1|Bourns SRP7030CA-6R8M|
| Input storage |4.7 µF,100 V,±10%,X7R,1210 |2|Samsung CL32B475KCVZNWE|
| Input HF bypass |100 nF,100 V,X7R,0603 |1|Murata GRM188R72A104KA35D|
| Output storage |47 µF,16 V,±10%,X5R,1210 |6|Samsung CL32A476KOJNNNE|
| BOOT |470 nF,16 V,X7R,0603 |1|Murata GRM188R71C474KA88D|
| VCC |2.2 µF,10 V,X5R,0603 |1|Samsung CL10A225KP8NNNC|
| BIAS |1 µF,10 V,X5R,0402 |1|Samsung CL05A105KP5NNNC|
| SS |22 nF,16 V,X5R,0201 |1|Murata GRM033R61C223KE84D; validated≥0.20 mm gap|
| Feed-forward |150 pF,C0G,50 V,0201 |1|Murata GRM0335C1H151JA01D, across FB upper resistor|
| FB upper |100 kΩ,1%,0201 |1|Shared|
| FB lower SYS |43.5 kΩ,1%,0201 |1|SYS only|
| FB lower FPGA5 |24.9 kΩ,1%,0201 |1|FPGA5 only|
| EN pulldown |100 kΩ,1%,0201 |1|Shared|
| PG pullup |10 kΩ,1%,0201 |1|Shared|

Regulated values before current shunt: SYS3.319 V typical; FPGA5 5.046 V typical. These modest positive setpoints cover some shunt drop; they are not remote-sensed supplies. Resistive worst-case plus reference tolerance must be checked against final IC rail requirements. Local buck output caps and feedback takeoff are BEFORE shunt; output voltage telemetry is AFTER shunt. Bulk current into other local rail regulators is measured as FPGA5 input loading.

At36 V,400 kHz,6.8 µH: ripple1.102 A for3.3 V,1.583 A for5 V. At−20%L and340 kHz conservative frequency: ripple1.621 A/2.328 A. A4 A FPGA5 load peaks5.164 A, below6 A minimum peak current limit; a3 A SYS load peaks3.811 A. Inductor12 A saturation has margin over7.8 A maximum trip. At4 A, inductor DCR loss≤0.68 W at25 °C; hot copper increases this.

CIN9.4 µF nominal must retain at least6 µF effective at36 V. The highest input-capacitor RMS demand in18–36 V is approximately1.80 A at18 V,5 V4 A out. At18 V and6 µF effective, estimated capacitor-only ripple0.334 V at400 kHz. Split two CIN parts adjacent to the power pins; add local input bulk if converter is physically far from distribution bulk.

COUT282 µF nominal: six47 µF parts. Manufacturer typical curves were recovered from the page JSON and saved as samsung_CL32A476KOJNNNE_curves.json. Design acceptance floor100 µF effective for FPGA5 and120 µF for SYS after DC bias/tolerance/temperature is now supported by the derating estimate below. Feed-forward150 pF selected from TI equations22/23 with actual effective capacitance; final compensation requires board load-step validation. These are fully specified fitted values, not a promise that arbitrary substitute ceramics are equivalent. X5R limits component operating temperature to85 °C.

## LMR51610XDBVR: AON,USB and6 V analog preregulator

Source: https://www.ti.com/lit/ds/symlink/lmr51610.pdf . Pin1CB via100 nF100 V0603 (GRM188R72A104KA35D, same SKU as input HF) to pin6SW; pin2GND; pin3FB; pin4EN; pin5VIN; pin6SW to inductor. Internal400 kHz,2.3 ms startup, noPG. EN rising max1.36 V; cannot float or exceedVIN+0.3 V. HS current limit1.25–1.95 A; LS valley minimum0.9 A. Family part suffixX is400 kHz PFM.

Use one CL32B475KCVZNWE4.7 µF100 V1210 input plus100 nF100 V0603 GRM188R72A104KA35D HF bypass; two CL32A476KOJNNNE47 µF16 V1210 output; one SRP7028A-330M33 µH (2 A Irms/2.5 A Isat) per low rail. Thus bulk capacitor SKUs repeat with high rails. FB bottom20 kΩ for all three. AON top62 kΩ=>3.280 V; USB top105 kΩ=>5.000 V; analog top130 kΩ=>6.000 V. All FB resistors1%0201. AON EN tiedVIN; USB/analog EN hardware-gated,100 kΩ pulldown. The pair estimates36.3 µF effective at6 V after conservative tolerance/temperature allowances, above the22 µF design floor.

At36 V400 kHz: ripple0.227 A(AON),0.326 A(USB),0.379 A(6 V). Conservative −20%L and340 kHz makes6 V ripple0.557 A, peak0.879 A at0.6 A load, below1.25 A minimum HS limit. SRP7028A-330M saturation2.5 A exceeds1.95 A max internal limit. Confirm startup using voltage telemetry; AON supervisor validates MCU supply.

## Protection coordination

At INA301A1 threshold40 mV: low rail20 mΩ/2 A trip is invalid because internal LMR current limit can act first. Use50 mΩ/0.8 A forUSB andanalog;100 mΩ/0.4 A forAON estimate0.3 A. SYS10 mΩ/4 A suits3 A. FPGA5 at4 A expected load cannot use4 A threshold without operating margin;5 A external trip may be beyond the guaranteed minimum valley-current behavior. Suggested nominal9.1 mΩ=>4.40 A, plus properly evaluated tolerances, or derate to≤3.2 A and4 A trip. This choice belongs in the final coordinated protection budget.

## Footprint facts and availability

TI RNP pad width0.25 at0.5 pitch gives0.25 mm adjacent copper gap; pad–EP gaps≥0.35 mm. SOT23 standard0.6 mm lands at0.95 pitch give0.35 mm. Do not shrink/expand generic lands without checking exact clearance. SRP7030CA manufacturer lands: two7.2×2.3 mm rectangles, centers(0,±2.55 mm), inner gap2.8 mm, total copper height7.4 mm. Body7.8×7.6×2.9 mm. See local rendered `srp7030ca_p1.png`. SRP7028A: two2.5×3.5 mm pads with3.4 mm edge gap (8.4 mm total width).

Sources checked2026-09-08:

- LM76005: https://www.digikey.com/en/products/detail/texas-instruments/LM76005RNPR/13174053 (~5000 stock,$6.07/1,$4.645/10).
- LMR51610: https://www.digikey.com/en/products/detail/texas-instruments/LMR51610XDBVR/22106815 (4342 stock,$1.74/1,$1.275/10).
- SRP7030CA: https://www.bourns.com/docs/product-datasheets/srp7030ca.pdf ; https://www.digikey.com/en/products/detail/bourns-inc/SRP7030CA-6R8M/10257224 (1351 stock,$1.70/1,$1.401/10).
- SRP7028A: https://www.bourns.com/docs/product-datasheets/srp7028a.pdf ; https://www.mouser.com/ProductDetail/Bourns/SRP7028A-330M?qs=6oMev5NRZMHRO5mnDhh3Mw%3D%3D (5732 stock).
- 47 µF output: https://product.samsungsem.com/mlcc/CL32A476KOJNNN.do (mass production); https://www.mouser.com/ProductDetail/Samsung-Electro-Mechanics/CL32A476KOJNNNE?qs=d72FGnIDsgQXYP%252BbBe7Sww%3D%3D (128970 stock).
- 4.7 µF input: https://www.digikey.com/en/products/detail/samsung-electro-mechanics/CL32B475KCVZNWE/10480138 (26733 stock,$1.08/1,$0.696/10; manufacturer datasheet linked there).

Do not substitute previously considered MOJNNNE20% output capacitor: only2 pcs shownatDigiKey and LCSCoutofstock. The specified KOJNNNE10% version is widely stocked. Prices exclude delivery and taxes.


## Exact small-MLCC BOM references

Use the already qualified system resistor family for listed resistance values; these MLCC MPNs close the formerly generic small-cap entries:

- 100 nF100 V0603 X7R **Murata GRM188R72A104KA35D**, repeated for input HF and low-rail CB. Manufacturer: https://pim.murata.com/en-us/pim/details/?partNum=GRM188R72A104KA35%23 ; active DigiKey: https://www.digikey.com/en/products/detail/murata-electronics/GRM188R72A104KA35D/702549 . Avoid obsolete GRM188R71C104KA01D and GRM21BR72A104KAC4L; this is the manufacturer-recommended upgrade.
- 470 nF16 V0603 X7R **Murata GRM188R71C474KA88D**. https://pim.murata.com/en-us/pim/details/?partNum=GRM188R71C474KA88D ; https://www.digikey.com/en/products/detail/murata-electronics/GRM188R71C474KA88D/702559 .
- 2.2 µF10 V0603 X5R **Samsung CL10A225KP8NNNC**. https://product.samsungsem.com/mlcc/CL10A225KP8NNN.do ; https://www.digikey.com/en/products/detail/samsung-electro-mechanics/CL10A225KP8NNNC/3886743 .
- 1 µF10 V0402 X5R **Samsung CL05A105KP5NNNC**. https://product.samsungsem.com/mlcc/CL05A105KP5NNN.do ; https://www.digikey.com/en/products/detail/samsung-electro-mechanics/CL05A105KP5NNNC/3886734 .
- 22 nF16 V0201 X5R10% **Murata GRM033R61C223KE84D**. https://pim.murata.com/ja-jp/pim/details/?partNum=GRM033R61C223KE84%23 ; https://www.digikey.com/en/products/detail/murata-electronics/GRM033R61C223KE84D/4213199 (active and buy-now). SS timing is approximately11 ms, not precision timing.
- 150 pF50 V0201 C0G5% **Murata GRM0335C1H151JA01D**. https://pim.murata.com/en-global/pim/details/?partNum=GRM0335C1H151JA01%23 ; https://www.digikey.com/en/products/detail/murata-electronics/GRM0335C1H151JA01D/4904363 .


## Recovered manufacturer DC-bias curve and consequent fitted values

Source: https://product.samsungsem.com/mlcc/CL32A476KOJNNN.do . Raw embedded datasheetData JSON includes DCBias graph at25 °C,120 Hz,0.5 Vrms test. Linear interpolation yields the following typical estimates. Applying0.90 initial tolerance and0.85 temperature factors is a conservative engineering allowance, not a manufacturer guaranteed corner model; aging and AC-amplitude dependence additionally require qualification.

| DC voltage | Typical capacitance change | µF per part typical25 °C | µF per part ×0.90×0.85 |
|---|---:|---:|---:|
|3.3 V|−23.06%|36.16|27.66|
|5.0 V|−41.18%|27.65|21.15|
|6.0 V|−49.55%|23.71|18.14|

Fit six47 µF output capacitors for both LM76005 rails (282 µF nominal), and two47 µF for each LMR51610 low rail (94 µF nominal). This is within LM76005's800–1200 µF maximum-total guideline. It follows TI's warning that nonautomotive, lower-temperature MLCCs may require more parts than the typical filter table assumes. For LM76005 equation22, fx=15.46/(Vout×Cout_effective), so approximate fx spans21.6–28.2 kHz SYS and18.6–24.4 kHz FPGA5 across typical/corner C estimates. Equation23 optimum CFF spans134–102 pF SYS and192–145 pF FPGA5; shared150 pF is a practical repeated fitted value. Confirm loop stability and load steps with final PCB and actual downstream capacitor bank. The prior47 pF CFF and4/1 output-cap counts are superseded.
