# MIRA secondary rails — circuit specification, 2026-09-08

Engineering estimates, not confirmed FPGA/AFE load requirements. Input to local rails is +5V5_FPGA, 5.5 V. The individual output ratings do not imply simultaneous maximum loading; parent power budget limits this bus to 3.0 A operating / 4 A trip. Core sustained estimate 5 A, converter capability 8 A.

## 1. Core: TPS568215RNNR

Select this part over TPS54821 because internal compensation reduces circuitry and stock is better. 18-pin RNN3.5x3.5 HotRod package. TI footprint has >=0.25 mm nominal narrow-pin spacing, but custom/standard footprint must be geometrically checked including broad power pads; do not substitute a generic QFN18.

Pin/net mapping:
- 1 BOOT: 100 nF 16 V X7R 0402 to SW.
- 2,11 VIN: +5V5_FPGA.
- 3,4,5,8,9,10 PGND and 12 AGND: GND. There is NO additional exposed thermal pad pin.
- 6,7 SW: 1.0 uH Bourns SRP7030CA-1R0M to +1V0_CORE_RAW.
- 13 FB: divider +1V0_CORE (load sense) -> 10.0 kΩ 0.1% 0402 -> FB -> 15.0 kΩ 0.1% 0402 -> GND. Nominal 0.6*(1+10/15)=1.000 V.
- 14 SS: 22 nF to GND (0201 if practical rating); datasheet default if open is 1 ms. 22 nF extends startup.
- 15 EN: hardware-gated EN_CORE; 100 kΩ to GND. EN absmax independent of VIN, up to6.5V.
- 16 PGOOD: PG_CORE; 10 kΩ to +3V3_AON.
- 17 VREG5: 4.7 uF 10 V X5R 0603 to GND. Do NOT tie to the 5.5 V bus. Internal LDO mode.
- 18 MODE: VREG5 -> 200 kΩ -> MODE -> 10.0 kΩ -> GND. 400 kHz FCCM, standard current-limit mode.

CIN: 2 x47uF/10V X5R1206 +100nF/16V0402, local low-inductance arrangement adjacent each VIN/PGND side. TI recommends40uF input; effective capacitance at5.5V and ripple rating need validation from chosen manufacturer's DC-bias data. COUT: 6 x47uF/10V X5R1206 (282uF nominal); feedback and bulk cap at load-side output where possible. Parent should avoid placing significant resistance between loop output and main bulk capacitance. Target >=200uF effective at1V. SRP7030CA-1R0M: 1uH, Isat30A, Irms21.8A, DCR5mΩmax, 7.8x7.6x2.9mm. Ripple at5.5V/1V/400kHz approximately2.05A p-p; 8A load peak9.02A; inductor has ample limit margin. Regulation, ripple and transient need bench validation with actual FPGA and final output capacitors.

Important monitoring coordination: at1V, a40mV shunt drop is4%; use feedback after shunt or lower drop. Do not claim fast latch triggers for every overload unless programmed trip is below the converter's minimum achievable protection current under that condition. UV/PG timeout must also latch failures that enter hiccup.

Sources: https://www.ti.com/lit/ds/symlink/tps568215.pdf ; https://www.bourns.com/docs/product-datasheets/srp7030ca.pdf . Stock8,363 and price$3.44 single/$2.587 qty10 observed DigiKey https://www.digikey.com/en/products/detail/texas-instruments/TPS568215RNNR/6560936 . Bourns part available https://www.digikey.com/en/products/detail/bourns-inc/SRP7030CA-1R0M/10257218 ($1.70 listing); 156 immediate units at Mouser search result.

## 2. Repeated local rails: TPS62130ARGTR, five instances

RGT16 3x3 VQFN. TI land pad0.24mm on0.5mm pitch=0.26mm gaps, EP1.68mm, outer-land center1.4mm/length0.6mm =>0.26mm EP gap. Straightforward standard library footprint if it matches these dimensions. All control analog pins referenced to common GND.

- SW1,2,3 -> 2.2uH Bourns SRP5030TA-2R2M -> regulated output.
- PG4 -> independent PG net with10k to3V3_AON.
- FB5 -> divider node.
- AGND6, DEF8, PGND15,16, EP17 -> GND.
- FSW7 -> own output for1.25MHz selection (all outputs>=1.05V, high threshold0.9V maximum).
- SS/TR9 ->10nF GND: about5ms startup.
- AVIN10, PVIN11,12 ->+5V5_FPGA.
- EN13 -> gated individual enable with100k GND.
- VOS14 -> output sense at output capacitor/load.

CIN:10uF/10V X5R0805 closePVIN +100nF/16V0402 atAVIN. COUT2x22uF/10V X5R0805. These nominal2.2uH/44uF values lie in TI validated LC range (22–200uF nominal at2.2uH). If parent uses47uF/10V1206 to unify, one47uF is also listed stable. Small local rails nominal1.0A except2V5,PHY0.5A; 3AIC margin eases startup and shunt trip coordination.

FB bottom all16.0kΩ0.1%0402; upper values:
| Net | R upper | Vnom | Estimated load |
|---|---:|---:|---:|
| +1V8_AUX |20.0k|1.800V|1.0A|
| +2V5_AUX |34.0k|2.500V|0.5A|
| +3V3_IO |49.9k|3.295V|1.0A|
| +1V35_DDR |11.0k|1.350V|1.0A includingVTT source contribution|
| +1V05_PHY |4.99k|1.0495V|0.5A|

EN caution: absolute maximum EN<=VIN+0.3V. Hardware must not leave3.3V onEN when5V5_FPGA is off, including controlled shutdown and collapse. A sequencer alone is insufficient for uncontrolled input fall. Use hardware buffer powered fromlocalVIN or appropriate clamp/limited injection design; parent must resolve this before final schematic. PG/FSW have independent7V absolute ratings.

Source https://www.ti.com/lit/ds/symlink/tps62130a.pdf . DigiKey stock10,059,$2.30/$1.698qty10 https://www.digikey.com/en/products/detail/texas-instruments/TPS62130ARGTR/4307640 . Inductor stock7,321,$1.04 https://www.digikey.com/en/products/detail/bourns-inc/SRP5030TA-2R2M/5429671 ; manufacturer https://www.bourns.com/docs/Product-Datasheets/SRP5030TA.pdf ; 5.5AIrms,6.5Asat typical,35mΩmax (verify exact current curve before footprint release).

## 3. DDR3L VTT / VREF: TPS51200DRCR

DRC10 VSON3x3,0.5mm pitch, must verify selected land's EPclearance>=0.20. Output tracks0.5*DDR rail, not a fixed unrelated voltage.

- 1 REFIN: +1V35_DDR ->10.0k0.1%0402 ->REFIN->10.0k0.1%0402->GND; add100nF/16V0201 toGND.
- 2 VLDOIN:+1V35_DDR;10uF/10V0805 toGND.
- 3 VO:+0V675_VTT;3x10uF/10V0805 toGND; >=20uF effective required.
- 4 PGND,8GND,EP11:GND.
- 5 VOSNS:+0V675_VTT atterminationload, Kelvin sense.
- 6 REFOUT: DDR_VREF;100nF toGND; totalREFOUT capacitance<0.47uF including DDR-sidecaps.
- 7 EN: hardwaregated EN_VTT with100k toGND.
- 9 PGOOD:PG_VTT,10k to3V3_AON.
- 10 VIN:+3V3_AON with1uF/10V0603 toGND. Does not mean VTTenabledbeforeDDR;EN controlled.

Estimated0.5A source/sink, source thermal(1.35−.675)*.5=.338W, sink about.338W. VTT sourcing draws upstreamDDRcurrent; no double-counting that power in total budget. Bias supply requires2.375…3.5V. VTT input1.35V satisfies VLDOIN1.1Vmin. VREFnot aloadpoweroutput. Exactstock115,106,$1.03single/$0.743qty10 https://www.digikey.com/en/products/detail/texas-instruments/TPS51200DRCR/1907875 ; datasheet https://www.ti.com/lit/gpn/TPS51200 .

## 4. ±15V AFE converters: LMR51610XFDBVR, 400kHz FPWM

This choice repeats the same65V,1A SOT23-6 IC forpositive/negative. Rated system output0.20A each. Positive can deliver more, negative derated byIBB duty. VIN=protected18…36V; localVINstress36+15=51V onnegative isbelow65Vrecommended. No built-inPG pin: comparator/ADC supervisors measure outputs.

Positive pinmap:1CB->100nF/16V0402->6SW;2GNDsystemGND;3FBdivider;4ENgatedEN_AFE_P15(100kGND);5VINprotected24;6SW->100uH->+15V_RAW. FB:+15V_RAW ->392k0.1%0402 ->FB ->22.1k0.1%0402 ->GND. Vnom14.990V. 392k has~14.2V acrossit (okay0402;0201workingvoltage25V alsopossiblebut0.1%cost).

CIN positive4.7uF/100V1210 +100nF/100V0603 VIN->GND. COUTpositive2x22uF/25VX7R1210 +100nF/100V0603 +15RAW->GND. Lpositive100uH sameasnegative toreduceBOM; lightload0.2A, ripple0.219Apeak-to-peak at36Vin, currentpeak0.31A. Control-loop checkrequired because100uH largerthan typicalpositiveexample (conservative0.2Arating).

Negative pinmap:1CB->100nF/16V0402->6SW;2GND->NEG_RAW(!);3FBdivider;4EN->levelshiftedlocalEN;5VINprotected24;6SW->100uH->SYSTEM GND(!). FeedbackSYSTEM GND ->392k0.1%0402 ->FB ->22.1k0.1%0402 ->NEG_RAW. Important do not invert resistor positions:FB is+0.8V relativeNEG_RAW.

Negative capacitors:
- 4.7 uF/100 V 1210 +100 nF/100 V 0603 from VIN pin5 to NEG_RAW pin2: main local CIN, across51V worst.
- 100 nF/100 V 0603 from VIN to SYSTEM GND: auxiliary bypass; optional additional2.2uF100V here.
- 3x22uF25VX7R1210+100nF100V0603 fromSYSTEMGND toNEG_RAW (COUT).
- SchottkySS14 orSS16: anodeNEG_RAW,cathodeGND; clampsunwantedpositiveNEGexcursion. SS14reverse40V enough for−15; SS16ifsharedparts.

Inductor both±15: Würth7447709101,100uH,2.5Arated,3.1Asat(30%),110mΩmax,12x12mmclass; available$2.57, source https://www.we-online.com/components/products/datasheet/7447709101.pdf and stock https://www.digikey.com/en/products/detail/w%C3%BCrth-elektronik/7447709101/1638653 . Choose thisratherthanSRR1260-101M because latterIsat1.7AisbelowLMR1.95Amaxpeaklimit. Negative100uH and3x22uF25V are specifically TIrecommended valuesat−15V, not guessed bypositivebuck equations.

NegativeEN optocoupler LTV-356T-A (80VVCEO) mapping1A,2K,3E,4C: hardwaregatedEN_AFE_N15 ->330Ω0402 ->pin1;pin2GND. VIN24 ->51k0402 ->51k0402 ->pin4;pin3->LMREN4;10k0402 EN->NEG_RAW. LED~5–7mA, resistorsratedunder0.025W. OffoptoENpullsNEG_RAW=off. AtinitialVin18VandNEG0, ENdifferential~1.59V>1.36maxthreshold; atVin36andNEG−15 ~4.54V. Optotransistormust be80Vrated:ordinary35Vpartinvalid. Two51kdividevoltagestress andthermal. OptoemitteroutputoffdoesnotconnectMCUto−15. SS14clampandallnegativeGNDreferencesmustbeexplicit. Note propagationdelayofoptoaddsseveralmicroseconds tohardwarestop.

Negative atVin18V,0.2A: idealD=15/(18+15)=.4545,ILavg=.3667A,ripple.2045Ap-p,peak.469A. AtVin36V: D=.2941,ILavg=.2833A,ripple.2647Ap-p,peak.416A. WithLmin80uH andfmin340kHz peakstill<.52A; converterminHSlimit1.25A, minLSvalleylimit.9A. 0.289A externaltriphasmargin; startupcapacitorcharging adds~0.43Aoutputinstantaneousif2.3msramps15Vinto66uFbeforebiasderating, which can cross outputmonitortrip ifcapacitorslocatedAFTERshunt. Main COUTmustbeBEFOREshunt; onlydownstreamloadcapstartupcurrentflowsinshunt.

Source https://www.ti.com/lit/ds/symlink/lmr51610.pdf and TIIBBappnote https://www.ti.com/lit/pdf/slvafp0 . PriceLMR$1.64single/$1.203qty10,stock4972 https://www.digikey.com/en/products/detail/texas-instruments/LMR51610XFDBVR/22286772 . Opto https://optoelectronics.liteon.com/upload/download/ds70-2001-010/ltv-356t%20series%20201610.pdf ; stock14400,$0.46 https://www.digikey.com/en/products/detail/liteon/LTV-356T-A/7322517 .

## 5. Negative output current+voltage, OPA2991IDR dualSOIC8

Supply8=+3V3_AON;4=NEG_RAW. Decouple AON to system GND with 100nF/10V0201 and NEG_RAW to system GND with 100nF/100V0603; device2.7…40V total supply works withnegativeoff because3.3V remains. Currentpositive direction isloadtowardconverter onnegativepowerwire.

NEG_RAW ->100mΩ 1%1206 Kelvinshunt ->NEG_AFE(load). Thus loadnodeislessnegativewhenconsumingpower. MainnegativeoutputcapacitorsBEFOREshunt. AmpA OUT1,IN−2,IN+3:
- NEG_RAW ->10.0k0.1%0402 ->pin2.
- pin1 ->200k0.1%0402 ->pin2.
- NEG_AFE ->10.0k0.1%0402 ->pin3.
- pin3 ->200k0.1%0402 ->SYSTEMGND.
NominalVout=20*(NEG_AFE−NEG_RAW)=2V/A. Nominal0.4Vat0.2A. Currentcommonmodenodeabout−14.3V forNEG−15V,withinRRinputrange.

AmpB OUT7,IN−6,IN+5:
- pin5GND.
- NEG_AFE ->100k0.1%0402 ->pin6.
- pin7 ->10.0k0.1%0402 ->pin6.
NominalVout=−0.1*VNEG_AFE=+1.5Vat−15V.

Eachamplifieroutput->10k0402->protectedADC/MUXinput;BAT54SrailclampbetweenGND/ADCnode/3V3_AON,100nF0201ADCnodeGNDfor~1msfilter. TakecurrentcomparatorBEFORE1msADCfilter, withseparate10k+clamp; optional1nF~10usfilterifrequirednoiseprotection. ParentselectedTLV1701(oroneTLV1704channel) open-drainfaultcomparator: reference3V3_AON->47k->VTH->10k->GND≈0.579V =>0.289Atrip;100nFreferencefilter. ComparatorIN+reference,IN−current =>OUTlowforovercurrent;wiredhardwarefaultlatch. Comparatorinputclampsmustnotcreate1msfaultdelay.

Accuracy warning: discrete0.1%resistorsdoNOTgive0.1%currentaccuracy. Opposite ratio mismatchcanproduce~57mVoutputoffsetat−15V (~28.5mA) plusopampoffset~16mVmax(~8mA). Telemetryrequiresboardcalibrationandtemperaturevalidation; usematchedratioresistornetworkifprecisionbetterthanfewpercentisrequired. Hardwaretripnominal.289Acanmovebyroughly.04Apluscomponent/referenceerrors; remainsabove.2Aloadandbelowconverterlimit. Thisisacceptableprototypeprotection/diagnosticsbutnotaprecisioninstrumentguarantee.

Source https://www.ti.com/lit/ds/symlink/opa2991.pdf ; price$2.53/$1.879qty10,stock9497 https://www.digikey.com/en/products/detail/texas-instruments/OPA2991IDR/11502354 .

## 6. Low-noise analog LDOs — TPS7A9101DSKR x2

TPS7A20 is300mA, not500mA; insufficientfor5VA0.4Aand3.3VA0.2Aloadcascade. TPS7A91is1A,0.8…5.2Voutput,1.4…6.5Vin,4.7uVrmsnoise. DSK10WSON2.5x2.5:land0.25wideat0.5pitch;EPwidth1.2,landx±1.15length0.6=>EPgap0.25. Lowcost$2.38singlelist,notTPS7A94premium.

PinsOUT1/2;FB3;GND4;PG5;SS_CTRL6;EN7;NR/SS8;IN9/10;EP11GND. BothSS_CTRL6GND;NR/SS100nF0201GND (~13msstartup). INlocal10uFminimum (choose22uF10V0805or47uF10V1206withvalidatedbias); OUT22uF10V0805minimum10uFeffective,option47uF10V1206repeat. CFF10nF0201inparallelwithupperFBresistorfornoise;EN100kGND,gatedEN;PG10k3V3_AON.

ANA6 (+6V) ->LDO5V:upper10.5k0.1%0402,lower2.00k0.1%0402 =>5.000V. Nominaldirect5VAloads0.4Aplus0.2AtosecondLDO=.6Athroughthispart,roughly 0.60W at 6V input.
+5VA ->LDO3.3V:upper49.9k0.1%0402,lower16.0k0.1%0402 =>3.295V,repeatlocalbuckdivider. At.2Athermal~.34W. Regulatorsneedgroundthermalviasandcopperarea. Parentcanuseaseparate3.8Vbuckinputiftheanalogloadgrows;currentratingnotyetconfirmed.

Source https://www.ti.com/lit/ds/symlink/tps7a91.pdf . https://www.digikey.com/en/products/detail/texas-instruments/TPS7A9101DSKR/6599968 ; shortreelvariantTPS7A9101DSKTstock80,$2.77 https://www.digikey.com/en/products/detail/texas-instruments/TPS7A9101DSKT/6588889 .

## Assembly and verified scope

0201meansimperial0603metric. Use0201forregularlowvoltagepulls,signalsand100nFwheremanufacturerdefinesampleeffectivecapacitance. Use0402for0.1%feedback/differentialresistorsbecausecommonandcosteffective;0402/0603/1210forhigherworkingvoltagesandenergycaps. Uniform47uF10V1206canreduceBOMtypesbuttradeoffboardareaandbiasderating. Largerinductorsarejustifiedbysaturationratingduringfaults,notratedloadalone. NoPCBhasbeenrouted;0.20mmconstraintmustalsoapplytolands,thermalpadcorners,maskselectionandrouting,notmerelypackagepitch.

PrimarydatasheetPDFs/textareinnew_design/research/datasheets/. Marketfiguresareobservedlistings2026-09-08,maychange,anddonotpromiseimportavailabilityintousercountry.


## Final implemented capacitor and footprint choices (2026-09-08)

`new_design/build/secondary_rails.py` implements blocks 8–19 with 176 components. The final MPN selections below supersede earlier package/value suggestions in this research.

- Shared 47 µF output/input MLCC: Samsung **CL32A476KOJNNNE**, 16 V X5R 1210, shared with the primary bucks. Six in parallel serve CORE_RAW; two serve core VIN. DC bias near 6 V leaves about 50% nominal capacitance. Confirm thermal and tolerance derating in the PCB review.
- Shared high-voltage input MLCC: Samsung **CL32B475KCVZNWE**, 4.7 µF 100 V X7R 1210. It replaces the earlier 2.2 µF NRND Murata part. Negative input MLCC connects BUS24 to N15_RAW.
- ±15 V output MLCC: Samsung **CL32B226KAJNFNE**, 22 µF 25 V X7R 1210, active. DigiKey showed 6,821 in stock, $0.87 single/$0.546 at ten: https://www.digikey.com/en/products/detail/samsung-electro-mechanics/CL32B226KAJNFNE/3889049 . Manufacturer https://product.samsungsem.com/mlcc/CL32B226KAJNFN.do . This suffix is standard termination, not soft termination. The closely named CL32B226KAJNNNE had zero stock, so it was not selected.
- Samsung DC-bias graph for CL32B226KAJNFN gives about −68.5% at 15 V: approximately 6.9 µF per part at room temperature before initial tolerance. Positive two-cap bank ≈13.8 µF; negative three-cap bank ≈20.8 µF. Negative estimated switching ripple is about 11 mV at 0.2 A, 18 V input, before ESR/layout and tolerance effects. Verify control-loop stability and load steps on the prototype. Raw manufacturer curve data is retained as `datasheets/CL32B226KAJNFN_curves.json`.
- LTV-356T-A uses verified manufacturer land pattern **LTV356T_SOP4_P2.54mm_Mfr**: lead pitch **2.54 mm**, body about 3.85 × 4.40 mm. A generic 1.27 mm SO4 footprint is incorrect. Manufacturer document: `../cad_assets/audit/ltv356t_mfr.pdf`.
- The three inductor footprints are `L_Bourns_SRP7030CA_7.8x7.6mm`, `L_Bourns_SRP5030TA_5.7x5.2mm`, and `L_Wurth_7447709101_12x12mm`.
- Negative current comparator signal is **OC_I_N15**, protected with its own 10 kΩ series resistor and BAT54S clamps, without the ADC channel's 1 ms RC filter. Comparator implementation belongs to the monitor/control owner.

Implementation audit: all 176 component references are unique, all IC pin maps have complete pin-number/name correspondence, all parts carry a finite MPN and footprint. This is a circuit-level check, not a measured proof of stability, sequencing, EMC or thermal performance.
