"""Small dependency-free KiCad S-expression reader/writer.

Quoted strings stay ordinary strings; unquoted tokens are Atom instances so the
writer can preserve meaning. Useful for symbol extraction and inspection.
"""
from __future__ import annotations
import re
from pathlib import Path

class Atom(str):
    pass

TOKEN = re.compile(r'\s*(?:(\()|(\))|"((?:[^"\\]|\\.)*)"|([^\s()]+))', re.DOTALL)

def loads(text):
    stack = []
    roots = []
    end = 0
    for m in TOKEN.finditer(text):
        if text[end:m.start()].strip():
            raise ValueError(f'Invalid input at character {end}')
        end = m.end()
        op, cl, quoted, bare = m.groups()
        if op:
            node = []
            (stack[-1] if stack else roots).append(node)
            stack.append(node)
        elif cl:
            if not stack:
                raise ValueError('Unmatched closing parenthesis')
            stack.pop()
        else:
            if not stack:
                raise ValueError('Token outside root expression')
            if quoted is not None:
                value = re.sub(r'\\([\\"nrt])', lambda z: {'n':'\n','r':'\r','t':'\t'}.get(z[1],z[1]), quoted)
            else:
                try:
                    value = float(bare) if '.' in bare or 'e' in bare.lower() else int(bare)
                except ValueError:
                    value = Atom(bare)
            stack[-1].append(value)
    if stack or text[end:].strip():
        raise ValueError('Incomplete expression')
    return roots[0] if len(roots) == 1 else roots

def load(path):
    return loads(Path(path).read_text(encoding='utf-8-sig'))

def quote(value):
    return '"' + str(value).replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r').replace('\t','\\t') + '"'

def dumps(node, indent=0):
    if not isinstance(node,list):
        if isinstance(node,Atom): return str(node)
        if isinstance(node,str): return quote(node)
        if isinstance(node,bool): return 'yes' if node else 'no'
        return str(node)
    if not any(isinstance(v,list) for v in node):
        return '('+' '.join(dumps(v) for v in node)+')'
    head=[]
    body=[]
    for v in node:
        if not isinstance(v,list) and not body: head.append(dumps(v))
        else: body.append(dumps(v,indent+1))
    pad='  '*(indent+1)
    return '('+' '.join(head)+'\n'+pad+('\n'+pad).join(body)+'\n'+'  '*indent+')'

def children(node,key):
    return [x for x in node if isinstance(x,list) and x and x[0]==key]

def child(node,key,default=None):
    return next(iter(children(node,key)),default)

def value(node,key,default=None):
    ch=child(node,key)
    return ch[1] if ch and len(ch)>1 else default

def properties(node):
    return {x[1]:x[2] for x in children(node,'property')}

if __name__ == '__main__':
    import sys
    n=load(sys.argv[1])
    print(f'{n[0]}: {len(n)-1} root fields; {len(children(n,"symbol"))} placed symbols')
