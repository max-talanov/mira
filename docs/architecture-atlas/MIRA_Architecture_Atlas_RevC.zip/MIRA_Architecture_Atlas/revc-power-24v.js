"use strict";

const input = document.getElementById("load-current");
const state = document.getElementById("fuse-state");
const exportButton = document.getElementById("export");
const source_V = 24;
const fuse_ohm = 0.0125;
const ledForward_V = 2;
const ledSeries_ohm = 10000;
const monitor_ohm = 32000;

function calculate() {
  const nominalLoad_A = input.valueAsNumber;
  const load_ohm = source_V / nominalLoad_A;
  const intact = state.value === "intact";
  const fused_V = intact
    ? (source_V + fuse_ohm * ledForward_V / ledSeries_ohm)
      / (1 + fuse_ohm * (1 / load_ohm + 1 / monitor_ohm + 1 / ledSeries_ohm))
    : 0;
  const load_A = fused_V / load_ohm;
  const fuse_A = intact
    ? load_A + fused_V / monitor_ohm + (fused_V - ledForward_V) / ledSeries_ohm
    : 0;
  return {
    board: "Power", connector: "J301", fuse: "F301", mpn: "0451005.NRL",
    state: state.value, nominalLoad_A, load_ohm, fuse_ohm,
    raw_V: source_V, fused_V, drop_V: source_V - fused_V, load_A, fuse_A,
    input_led: true, open_led: !intact, fused_led: intact
  };
}

function render() {
  const result = input.validity.valid ? calculate() : null;
  const output = (id, value) => { document.getElementById(id).textContent = result ? value : "—"; };
  const format = (key, unit) => result ? `${result[key].toFixed(6)} ${unit}` : "";
  output("raw", format("raw_V", "В"));
  output("fused", format("fused_V", "В"));
  output("drop", format("drop_V", "В"));
  output("load", format("load_A", "А"));
  output("current", format("fuse_A", "А"));
  output("resistance", format("load_ohm", "Ω"));
  output("input-led", result?.input_led ? "Горит" : "Погашен");
  output("open-led", result?.open_led ? "Горит" : "Погашен");
  output("fused-led", result?.fused_led ? "Горит" : "Погашен");
  exportButton.disabled = !result;
}

input.addEventListener("input", render);
state.addEventListener("change", render);
exportButton.addEventListener("click", () => {
  const result = calculate();
  const url = URL.createObjectURL(new Blob([JSON.stringify(result, null, 2) + "\n"], {type: "application/json"}));
  const link = document.createElement("a");
  link.href = url;
  link.download = `mira-power-24v-${result.state}.json`;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
});

const parts = {
  connector: ["Power / J301", "Клеммник на B.Cu. Контакт 1 — +24V_RAW, контакт 2 — GND. Кабель выходит вдоль +Y. Винты доступны снизу."],
  fuse: ["Power / F301", "Littelfuse 0451005.NRL на F.Cu. Площадка 1 — +24V_RAW, площадка 2 — +24V_FUSED."]
};
for (const button of document.querySelectorAll("[data-part]")) {
  button.addEventListener("click", () => {
    const [title, description] = parts[button.dataset.part];
    document.getElementById("part-title").textContent = title;
    document.getElementById("part-text").textContent = description;
    document.getElementById("part").showModal();
  });
}
render();
