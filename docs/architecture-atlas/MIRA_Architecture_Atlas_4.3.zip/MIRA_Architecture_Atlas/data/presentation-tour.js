/* Editable guided presentation. Exact source identifiers; illustrative signals, manual navigation only. */
window.MIRA_TOUR={
  "version": 1,
  "title": "MIRA — от питания до результата",
  "chapters": [
    {
      "id": "whole",
      "title": "Весь цикл MIRA",
      "summary": "Сначала увидим, как энергия, команды и измерения связывают устройство в один цикл."
    },
    {
      "id": "power-entry",
      "title": "Питание входит в устройство",
      "summary": "От разъёма24В через защиту и фильтр к питающим ветвям."
    },
    {
      "id": "power-control",
      "title": "Сначала запускается контроль",
      "summary": "Дежурное питание, контроллер и аппаратные разрешения готовят безопасный запуск."
    },
    {
      "id": "power-domains",
      "title": "Питание доходит до всех доменов",
      "summary": "Преобразователи создают нужные напряжения, а мониторинг подтверждает готовность."
    },
    {
      "id": "bootstrap",
      "title": "MCU и ПЛИС готовятся к работе",
      "summary": "Питание, тактирование, память и конфигурация превращают микросхемы в рабочую систему."
    },
    {
      "id": "host-link",
      "title": "Компьютер передаёт команду",
      "summary": "Ethernet и USB доставляют цифровой запрос; MCU и ПЛИС распределяют работу."
    },
    {
      "id": "setpoints",
      "title": "Цифровая команда становится напряжением",
      "summary": "ЦАП и буферы задают обычные и служебные аналоговые уровни."
    },
    {
      "id": "matrix-route",
      "title": "Команда выбирает путь в матрице",
      "summary": "Зафиксированная конфигурация управляет банками ключей, строками и возвратными путями."
    },
    {
      "id": "readout",
      "title": "Отклик становится числом",
      "summary": "Ток матрицы проходит через измерительный тракт и АЦП в ПЛИС."
    },
    {
      "id": "write-safety",
      "title": "Запись и аппаратная защита",
      "summary": "Ограничение тока и аппаратные запреты удерживают воздействие в заданных условиях."
    },
    {
      "id": "results",
      "title": "Результат возвращается на компьютер",
      "summary": "ПЛИС собирает отсчёты и передаёт их обратно по выбранному интерфейсу."
    }
  ],
  "steps": [
    {
      "sceneId": "system",
      "title": "От питания до результата: весь цикл MIRA",
      "lead": "У MIRA два взаимосвязанных пути: энергия даёт узлам работать, а команда запускает воздействие и измерение.",
      "body": [
        "На общей карте верхняя ветвь показывает питание. В средней части компьютер связан с интерфейсом и ПЛИС; рядом находится MCU, который координирует эксперимент. Справа цифровые уставки превращаются в аналоговое воздействие на матрицу.",
        "Снизу возвращается ответ: электрический отклик поступает в измерительный тракт, становится цифровыми отсчётами и доходит обратно до компьютера. Аппаратная защита сопровождает этот цикл и может снять разрешение на опасное воздействие. Пройдём весь путь по порядку, раскрывая нужные блоки прямо на этой карте."
      ],
      "why": "Связи верхнего уровня объясняют функции; точные цепи и выводы рассматриваем внутри соответствующих листов.",
      "path": [
        "Питание",
        "Команда компьютера",
        "Воздействие на матрицу",
        "Измерение",
        "Результат на компьютере"
      ],
      "nodeIds": [
        "power",
        "host",
        "links",
        "fpga",
        "drive",
        "matrix",
        "readout"
      ],
      "edgeIds": [
        "host_links",
        "links_fpga",
        "fpga_drive",
        "drive_matrix",
        "matrix_readout",
        "readout_fpga"
      ],
      "id": "main-01",
      "chapterId": "whole",
      "kind": "main",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e",
          "control_net_8543c7028353",
          "control_net_8baeadc9d1f8",
          "control_net_7f616706cf93",
          "control_net_2889fbee2814",
          "control_net_90accaec6322",
          "control_net_bae01a82acc2",
          "control_net_fd8710ab620d",
          "control_net_43c57dc0fd8c",
          "control_net_8d6768741a17",
          "control_net_d7baf045ad36",
          "control_net_beae8f10af57",
          "control_net_08cafd4a06b1",
          "control_net_d2e352168d81",
          "control_net_339e997cde5d",
          "control_net_78c06670fbe2",
          "control_net_ecfae2e6bc3f",
          "control_net_de495400ab4d",
          "control_net_a25f83c5766f",
          "control_net_957e25b7b62b",
          "control_net_6c5bac16ddbe",
          "control_net_b00353d4bc57",
          "control_net_a555576805ce",
          "control_net_795fcecf8d80",
          "control_net_5357ea4931e2",
          "control_net_e3f04569205d",
          "control_net_d3cbff2509ef",
          "control_net_aa72e4d066e3",
          "control_net_9a9cf021ea69",
          "control_net_8ae61bd6427a",
          "control_net_c2ddd031305c",
          "control_net_9a9241c5281b",
          "control_net_a21df6263907",
          "control_net_728a06da1431",
          "control_net_8247058ba4d6",
          "control_net_0b4fec439a85",
          "control_net_053310f9940f",
          "control_net_6a631d5bc074",
          "control_net_05e96fc05120",
          "control_net_c3b76f2a4b40",
          "control_net_d65f00f0a2d4",
          "control_net_3be7162ce896",
          "control_net_3d36f9d91f43",
          "control_net_a1f3e5011080",
          "control_net_b97070122e98"
        ]
      }
    },
    {
      "sceneId": "power",
      "title": "Питание — самостоятельная система управления",
      "lead": "От внешних 24 В до разрешения на эксперимент есть несколько независимых проверок.",
      "body": [
        "Входная защита принимает энергию, основные преобразователи создают промежуточные напряжения, а вторичные ветви питают конкретные домены Control. При этом дежурная ветвь AON нужна раньше основной нагрузки: от неё работает контроллер питания и аппаратные блокировки.",
        "Контроллер запрашивает включение, логика проверяет разрешение, а измерительные цепи возвращают фактические напряжения и токи. Поэтому команда «включить» и подтверждение «питание готово» — разные события. Следующие эпизоды последовательно раскрывают эти пути."
      ],
      "why": "Энергия, команда и обратная связь идут разными путями.",
      "path": [
        "24 В",
        "POWER_INPUT",
        "PRIMARY_POWER",
        "SECONDARY_POWER",
        "POWER_CONTROL"
      ],
      "nodeIds": [
        "input",
        "primary"
      ],
      "edgeIds": [
        "input_primary"
      ],
      "id": "main-02",
      "chapterId": "power-entry",
      "kind": "main",
      "source": {
        "sheetId": "power_POWER_SYSTEM",
        "sheetName": "POWER_SYSTEM",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1"
        ]
      }
    },
    {
      "sceneId": "power-input",
      "title": "Сначала ограничить последствия ошибки на входе",
      "lead": "Источник подключается к нагрузкам через предохранитель, eFuse и фильтр.",
      "body": [
        "J101 принимает внешнее питание. Затем F201 и D205 участвуют в защите входной ветви, U301 управляет пропусканием питания, а локальный фильтр подготавливает шину для преобразователей. На верхнем уровне это одна функция: получить защищённые 24 В.",
        "Внутри важно различать задачи: плавкий предохранитель, ограничение импульса, электронное отключение и фильтрация не заменяют друг друга. Листовые имена сохраняются из KiCad, поэтому любой этап рассказа можно сопоставить с исходной схемой."
      ],
      "why": "Разные неисправности требуют разных механизмов защиты.",
      "path": [
        "J101",
        "F201 / D205",
        "U301",
        "Фильтр",
        "BUS24"
      ],
      "nodeIds": [
        "sheet100",
        "sheet200",
        "sheet300",
        "sheet400"
      ],
      "edgeIds": [
        "sheet300_sheet400"
      ],
      "id": "main-03",
      "chapterId": "power-entry",
      "kind": "main",
      "source": {
        "sheetId": "power_POWER_INPUT",
        "sheetName": "POWER_INPUT",
        "board": "power",
        "netIds": [
          "power_net_a837894762cd"
        ]
      }
    },
    {
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "title": "Электронная защита управляет входным током",
      "lead": "U301 пропускает питание дальше только в рамках своей защитной функции.",
      "body": [
        "U301 TPS26631 получает +24V_FUSED и формирует EFUSE_OUT. Его обвязка задаёт условия входной защиты; внешние транзисторы Q301 и Q302 участвуют в управлении и защите входной цепи. В рассказе мы видим, как энергия проходит через управляемый участок.",
        "Состояние возвращается отдельными сигналами PG_INPUT и FLT_INPUT_N. Это позволяет контроллеру отличать готовый вход от аварии, вместо того чтобы судить только по наличию 24 В на разъёме. Точные пороги и задержки определяются схемой и компонентами, а не анимацией."
      ],
      "why": "Источник должен сообщать о готовности и о неисправности.",
      "path": [
        "+24V_FUSED",
        "U301",
        "EFUSE_OUT",
        "PG_INPUT / FLT_INPUT_N"
      ],
      "nodeIds": [
        "reverse",
        "efuse",
        "enable"
      ],
      "edgeIds": [
        "efuse_reverse",
        "efuse_enable"
      ],
      "id": "main-04",
      "chapterId": "power-entry",
      "kind": "main",
      "source": {
        "sheetId": "power_300_INPUT_EFUSE_PROTECTION",
        "sheetName": "300_INPUT_EFUSE_PROTECTION",
        "board": "power",
        "netIds": [
          "power_net_a837894762cd",
          "power_net_3dcac14084cf",
          "power_net_3937c8c839ac",
          "power_net_0118a5d9fdb8",
          "power_net_fc972acc08ff",
          "power_net_9517f7952aef",
          "power_net_35045b6a457d"
        ]
      }
    },
    {
      "sceneId": "power_500_AON_3V3_BUCK",
      "title": "Дежурное питание появляется первым",
      "lead": "AON поддерживает логику, которая решит, можно ли включить остальную плату.",
      "body": [
        "U501 формирует AON непосредственно из BUS24. Это питание для контроллера последовательности, измерений, сторожевых схем и блокировок. Здесь нет отдельной команды включения в функциональном тракте: дежурная часть должна получить возможность контролировать запуск.",
        "Индуктивность, конденсаторы и обратная связь помогают преобразователю удерживать выход. Через AON энергия приходит к управляющим узлам раньше основных нагрузок. Поэтому при выключенных доменах ПЛИС и аналогового тракта система контроля всё ещё имеет собственное питание."
      ],
      "why": "Нельзя поручить запуск логике, которая сама ещё не запитана.",
      "path": [
        "BUS24",
        "U501",
        "Фильтр и обратная связь",
        "AON",
        "Контроль запуска"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "main-05",
      "chapterId": "power-control",
      "kind": "main",
      "source": {
        "sheetId": "power_500_AON_3V3_BUCK",
        "sheetName": "500_AON_3V3_BUCK",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_67006db669b3",
          "power_net_bfbd5cdcdcfd",
          "power_net_c7b4c78d37bb",
          "power_net_478d89e5a433",
          "power_net_abd71ae65884"
        ]
      }
    },
    {
      "sceneId": "power_2400_PM_CONTROLLER",
      "title": "Контроллер питания организует последовательность",
      "lead": "U2401 видит состояния шин и отправляет запросы на их включение.",
      "body": [
        "U2401 STM32G0B1 питается от AON. К нему приходят измерения ADC_I/ADC_V, сигналы готовности и аварии; от него выходят EN_REQ_* для отдельных преобразователей. Так контроллер связывает наблюдение за энергией с командным управлением.",
        "Схема предоставляет эти интерфейсы для программы последовательного запуска. Конкретный алгоритм ожиданий и обработки ошибок должен выполняться прошивкой; диаграмма показывает аппаратный путь, а не утверждает, что готовая прошивка уже проверена. Далее запросы проходят через аппаратные вентили."
      ],
      "why": "Запрос контроллера становится силовой командой только после проверки разрешения.",
      "path": [
        "AON",
        "U2401",
        "EN_REQ_*",
        "Логика разрешений",
        "CMD_*"
      ],
      "nodeIds": [
        "controller",
        "support"
      ],
      "edgeIds": [
        "controller_support"
      ],
      "id": "main-06",
      "chapterId": "power-control",
      "kind": "main",
      "source": {
        "sheetId": "power_2400_PM_CONTROLLER",
        "sheetName": "2400_PM_CONTROLLER",
        "board": "power",
        "netIds": [
          "power_net_67006db669b3"
        ]
      }
    },
    {
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "title": "Аппаратное разрешение можно снять независимо",
      "lead": "Общее питание и воздействие на матрицу имеют собственные разрешения.",
      "body": [
        "U2601/U2602 проверяют условия блокировок, а двойная защёлка U2603 хранит состояние разрешений. Сюда входят внешние остановы и MATRIX_INHIBIT_N. На выходе отдельно используются GLOBAL_PWR_PERMIT и MATRIX_PERMIT.",
        "Защёлка делает останов событием с памятью: исчезновение краткой причины само по себе не превращается в новое разрешение. Для восстановления предусмотрены отдельные управляющие пути. Для зрителя главное — воздействие на матрицу требует не только команды эксперимента, но и разрешённого состояния защиты."
      ],
      "why": "После аварии не должно возникать непреднамеренного продолжения.",
      "path": [
        "Останов / блокировки",
        "Проверка условий",
        "U2603",
        "GLOBAL_PWR_PERMIT",
        "MATRIX_PERMIT"
      ],
      "nodeIds": [
        "stop",
        "qualify",
        "memory",
        "output"
      ],
      "edgeIds": [
        "stop_qualify",
        "qualify_memory",
        "stop_output"
      ],
      "id": "main-07",
      "chapterId": "power-control",
      "kind": "main",
      "source": {
        "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
        "sheetName": "2600_PM_PERMIT_INTERLOCKS",
        "board": "power",
        "netIds": [
          "power_net_d27f47724845",
          "power_net_e9a19d60b5ab",
          "power_net_8828c890966d",
          "power_net_0d67fdbc5a0d",
          "power_net_bc6b8848cad9"
        ]
      }
    },
    {
      "sceneId": "power-primary",
      "title": "Из 24 В получаются основные ветви",
      "lead": "Одна входная шина разделяется на цифровое и аналоговое питание.",
      "body": [
        "PRIMARY_POWER объединяет семь преобразований: дежурную ветвь AON, USB5, SYS3V3, промежуточное FPGA5V5, аналоговое ANA6 и двухполярные P15/N15. У этих выходов разные потребители и разные условия включения.",
        "Мы сначала раскрываем AON, поскольку от него зависит сам контроль запуска. Остальные ветви получают команды через аппаратную логику разрешений. На этой обзорной диаграмме блоки показывают состав раздела; отсутствие линии между двумя преобразователями не означает, что один питает другой."
      ],
      "why": "Разделение доменов позволяет запускать и контролировать их отдельно.",
      "path": [
        "BUS24",
        "AON",
        "SYS3V3 / USB5",
        "FPGA5V5",
        "ANA6 / P15 / N15"
      ],
      "nodeIds": [
        "sheet500",
        "sheet700",
        "sheet800",
        "sheet900",
        "sheet1000",
        "sheet1100"
      ],
      "edgeIds": [],
      "id": "main-08",
      "chapterId": "power-domains",
      "kind": "main",
      "source": {
        "sheetId": "power_PRIMARY_POWER",
        "sheetName": "PRIMARY_POWER",
        "board": "power",
        "netIds": []
      }
    },
    {
      "sceneId": "power-secondary",
      "title": "У каждой цифровой нагрузки — свой домен",
      "lead": "FPGA5V5 разветвляется на питание ядра, вспомогательных цепей и интерфейсов.",
      "body": [
        "Здесь собраны CORE1V0, AUX1V8, AUX2V5, IO3V3, DDR1V35, PHY1V05 и VTT. Они обслуживают разные части цифровой системы. Отдельно сюда включены ANA5 и ANA3V3, получаемые по аналоговой цепочке от ANA6.",
        "Набор блоков показывает состав раздела, а точный вход каждого преобразователя раскрывается внутри листа. Например, VTT питается от DDR1V35, а не напрямую от FPGA5V5. Сохранённые имена KiCad позволяют пройти от функционального назначения к конкретной цепи без переименования проекта."
      ],
      "why": "Одинаковая роль «питание» не означает одинаковые напряжение и источник.",
      "path": [
        "FPGA5V5",
        "CORE / AUX / IO",
        "DDR / PHY",
        "DDR1V35 → VTT",
        "ANA6 → ANA5 → ANA3V3"
      ],
      "nodeIds": [
        "sheet1200",
        "sheet1300",
        "sheet1400",
        "sheet1500",
        "sheet1600",
        "sheet1700",
        "sheet1900",
        "sheet2000"
      ],
      "edgeIds": [],
      "id": "main-09",
      "chapterId": "power-domains",
      "kind": "main",
      "source": {
        "sheetId": "power_SECONDARY_POWER",
        "sheetName": "SECONDARY_POWER",
        "board": "power",
        "netIds": []
      }
    },
    {
      "sceneId": "power-monitoring",
      "title": "Обратный путь: что происходит с питанием на самом деле",
      "lead": "Энергетические ветви возвращают измерения и аварийные признаки.",
      "body": [
        "POWER_MONITOR группирует измерение входа, системных, цифровых и аналоговых доменов. Каждый участок формирует наблюдаемые сигналы; мультиплексоры выбирают нужную пару, а буфер передаёт её к АЦП контроллера питания.",
        "Параллельно существует аппаратная линия защиты по току. Поэтому результаты измерений для программы и быстрый признак неисправности не обязаны проходить одним путём. Такой обратный контур помогает контроллеру отличать выполненную команду от действительно исправного питания."
      ],
      "why": "Питание нужно не только выдавать, но и наблюдать.",
      "path": [
        "Шины питания",
        "Измерительные усилители",
        "Мультиплексоры",
        "Буфер",
        "АЦП U2401"
      ],
      "nodeIds": [
        "sheet3500",
        "sheet3900",
        "sheet4000"
      ],
      "edgeIds": [
        "sheet3500_sheet3900",
        "sheet3900_sheet4000"
      ],
      "id": "main-10",
      "chapterId": "power-domains",
      "kind": "main",
      "source": {
        "sheetId": "power_POWER_MONITOR",
        "sheetName": "POWER_MONITOR",
        "board": "power",
        "netIds": [
          "power_net_d2e17a0e1422",
          "power_net_df57fc034b72",
          "power_net_ca640db2f885",
          "power_net_e14830d3e0bb",
          "power_net_0673bddb62dd",
          "power_net_80ed0592af12",
          "power_net_217501fd4a1b",
          "power_net_8165c7e0e80c",
          "power_net_97db96dcc04b",
          "power_net_b8fd52d3ecf7",
          "power_net_b5187ab6f19a",
          "power_net_2074a83eb788",
          "power_net_882de840965a",
          "power_net_e4e50653a8a5",
          "power_net_7071622db9df"
        ]
      }
    },
    {
      "sceneId": "power_3000_PM_RAIL_READY",
      "title": "Готовность шин собирается в общий признак",
      "lead": "ALL_RAILS_PG относится к фактическим состояниям питания.",
      "body": [
        "U3001, U3017 и U3018 объединяют признаки готовности разных групп напряжений. Промежуточные PG_GROUP_* позволяют собрать итоговый ALL_RAILS_PG из предусмотренного набора входов.",
        "Это обратное подтверждение, а не команда включения. Если контроллер уже запросил домены, он всё равно должен отличать такой запрос от появления допустимых напряжений. На следующем листе отдельно собирается готовность самих команд — эти два смысла важно не смешивать."
      ],
      "why": "Отправить запрос ещё не значит получить исправный результат.",
      "path": [
        "PG_* / PGR_*",
        "PG_GROUP_*",
        "U3018",
        "ALL_RAILS_PG"
      ],
      "nodeIds": [
        "0",
        "1",
        "2"
      ],
      "edgeIds": [
        "0_2",
        "1_2"
      ],
      "id": "main-11",
      "chapterId": "power-domains",
      "kind": "main",
      "source": {
        "sheetId": "power_3000_PM_RAIL_READY",
        "sheetName": "3000_PM_RAIL_READY",
        "board": "power",
        "netIds": [
          "power_net_5b1bf737eaa4",
          "power_net_0c68cab570db",
          "power_net_534223a3e24d",
          "power_net_9d522f9a0fb2"
        ]
      }
    },
    {
      "sceneId": "power_3100_PM_COMMAND_READY",
      "title": "Состояние команд проверяется отдельно",
      "lead": "ALL_COMMANDS_ON показывает состояние предусмотренной группы управляющих линий.",
      "body": [
        "U3101–U3103 объединяют командные признаки в CMD_GROUP_* и итоговый ALL_COMMANDS_ON. Схема отвечает на вопрос о командах запуска, а не измеряет выходные напряжения преобразователей.",
        "Рядом с предыдущим эпизодом становится понятна разница: команды могут быть выданы, пока питание ещё устанавливается, либо напряжение может отсутствовать из-за неисправности. Программная последовательность должна учитывать оба вида обратной информации, используя предусмотренные аппаратные сигналы."
      ],
      "why": "Команды и фактические напряжения нужно проверять раздельно.",
      "path": [
        "CMD_*",
        "CMD_GROUP_*",
        "U3103",
        "ALL_COMMANDS_ON"
      ],
      "nodeIds": [
        "0",
        "1",
        "2"
      ],
      "edgeIds": [
        "0_2",
        "1_2"
      ],
      "id": "main-12",
      "chapterId": "power-domains",
      "kind": "main",
      "source": {
        "sheetId": "power_3100_PM_COMMAND_READY",
        "sheetName": "3100_PM_COMMAND_READY",
        "board": "power",
        "netIds": [
          "power_net_39d8ddb40bfa",
          "power_net_722d31de17d3",
          "power_net_4053a009016f",
          "power_net_78f1e98d41b3"
        ]
      }
    },
    {
      "sceneId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "title": "Что приходит через J400",
      "lead": "На входе Control напряжения питания сопровождаются сигналами готовности и разрешения.",
      "body": [
        "J400 связывает плату с системой Power. Через U400 принимаются сигналы PM_UART_TX_POWER, ALL_RAILS_PG_POWER и GLOBAL_PWR_PERMIT_POWER; их дальнейшие цепи относятся уже к стороне Host. U401 отдельно участвует в передаче разрешения матрицы из входного домена.",
        "Это место удобно показать перед запуском управляющей логики: сначала есть источник питания, затем определённые уровни состояний и только затем разрешённая операция. При отключённых доменах приёмники помогают не соединять их напрямую через сигнальные выводы. Точное соответствие межплатных контактов проверяется по разъёмам, а не по одной обзорной стрелке."
      ],
      "why": "Питание и логические разрешения — разные условия готовности устройства.",
      "path": [
        "J400",
        "U400 / U401",
        "Состояние питания",
        "Разрешение матрицы"
      ],
      "nodeIds": [
        "connector",
        "host",
        "permit"
      ],
      "edgeIds": [
        "connector_host",
        "connector_permit"
      ],
      "id": "main-13",
      "chapterId": "bootstrap",
      "kind": "main",
      "source": {
        "sheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "sheetName": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_44af6a0dc05c",
          "control_net_9bddf3e35643",
          "control_net_225bd2a08dfb",
          "control_net_8108fd43e4b2"
        ]
      }
    },
    {
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "title": "Как запускается STM32",
      "lead": "Перед выполнением команд MCU нужны устойчивое питание, тактовый источник и определённое состояние сброса.",
      "body": [
        "U100 — STM32H745IIT6. Основной тактовый узел Y100 связан с цепями MCU_HSE_CLK и MCU_HSE_XO, а Y101 обеспечивает низкочастотный генератор MCU_LSE_IN / MCU_LSE_OUT. SW100 и цепь HOST_RESET_N позволяют перезапустить контроллер; MCU_BOOT0 определяет выбор загрузочного состояния.",
        "Конденсаторы питающих выводов поддерживают локальные токи переключения и внутренний регулятор MCU_VCAP. Через J100 доступны отладочные линии MCU_SWDIO, MCU_SWCLK и MCU_SWO. На диаграмме полезно по очереди выделить питание, тактирование и сброс: это три разных условия нормального старта одного процессора."
      ],
      "why": "Без определённого запуска даже исправная программа не получает надёжной основы для работы.",
      "path": [
        "SYS3V3",
        "Тактирование Y100",
        "Сброс HOST_RESET_N",
        "Запуск U100"
      ],
      "nodeIds": [
        "supply",
        "fast",
        "host",
        "start"
      ],
      "edgeIds": [
        "supply_host_4",
        "fast_host_0",
        "start_host_2"
      ],
      "id": "main-14",
      "chapterId": "bootstrap",
      "kind": "main",
      "source": {
        "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "sheetName": "100_MCU_POWER_CLOCKS_AND_DEBUG",
        "board": "control",
        "netIds": [
          "control_net_7a4e5a463be4",
          "control_net_a38bef0f0104",
          "control_net_9529eebe621c",
          "control_net_0cbb519cdc03",
          "control_net_90c4fa851afd",
          "control_net_d9a5590f95c8",
          "control_net_90afbe6c9420"
        ]
      }
    },
    {
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "title": "Как ПЛИС получает свою схему",
      "lead": "Конфигурационная память хранит описание логики, которое U500 загружает при старте.",
      "body": [
        "U600 хранит конфигурационный образ. Его данные идут в U500 по FPGA_CFG_CLK, FPGA_CFG_CS_N и FPGA_CFG_D0–FPGA_CFG_D3. После загрузки внутри ПЛИС появляются именно те блоки, которые были заложены в проект: контроллер матрицы, интерфейсы и обработка потоков.",
        "J600 даёт независимый путь JTAG для программирования и восстановления. SW600 или буфер U601 могут запросить повторную конфигурацию через FPGA_PROGRAM_N. FB600 и локальные конденсаторы фильтруют питание внутреннего контроля XADC. Наличие всех этих цепей позволяет загрузить и обслужить ПЛИС; оно не подтверждает готовность конкретной конфигурации."
      ],
      "why": "Нужен отдельный путь восстановления на случай, если основной образ не запускается.",
      "path": [
        "Flash U600",
        "FPGA_CFG_*",
        "U500",
        "JTAG / FPGA_PROGRAM_N"
      ],
      "nodeIds": [
        "flash",
        "fpga",
        "recover"
      ],
      "edgeIds": [
        "flash_fpga_0",
        "recover_fpga_2"
      ],
      "id": "main-15",
      "chapterId": "bootstrap",
      "kind": "main",
      "source": {
        "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "sheetName": "600_FPGA_CONFIGURATION_AND_XADC",
        "board": "control",
        "netIds": [
          "control_net_52c8c7557923",
          "control_net_834296c71f70",
          "control_net_3591ba357658",
          "control_net_6bc6649476ec",
          "control_net_9e71347ab99c",
          "control_net_92af7290af48",
          "control_net_4701afd22aa9"
        ]
      }
    },
    {
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "title": "Где FPGA буферизует измерения",
      "lead": "Внешняя DDR3L позволяет временно удерживать быстрый поток, пока он ожидает обработки или отправки.",
      "body": [
        "U800 — DDR3L объёмом 512 MiB с 16-битной шиной данных. U500 обменивается с ней адресами, командами и данными DDR_DQ; стробы DDR_DQS помогают принимать данные в нужные моменты. Генератор Y800 даёт дифференциальную тактовую опору по FPGA_SYSCLK_P / FPGA_SYSCLK_N.",
        "Цепи VTT и DDR_VREF задают необходимые уровни для интерфейса памяти. Для практической работы в проекте ПЛИС должен быть настроен контроллер DDR3L с корректными ограничениями платы. На функциональном уровне смысл прост: измерение может идти своим темпом, а отправка результатов — своим, пока буфер не переполняется."
      ],
      "why": "Буфер сглаживает разницу скоростей, но не отменяет необходимость управления потоком.",
      "path": [
        "Y800",
        "Контроллер в U500",
        "DDR_DQ / DDR_DQS",
        "Память U800"
      ],
      "nodeIds": [
        "clock",
        "fpga",
        "memory"
      ],
      "edgeIds": [
        "clock_fpga_0",
        "fpga_memory_1",
        "fpga_memory_2"
      ],
      "id": "main-16",
      "chapterId": "bootstrap",
      "kind": "main",
      "source": {
        "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "sheetName": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "board": "control",
        "netIds": [
          "control_net_c31eb8fe07d3",
          "control_net_d44f364a5830",
          "control_net_3bfe72ccfc41",
          "control_net_21a5e9f13f7f",
          "control_net_58af204d8c23",
          "control_net_cccff17550b9",
          "control_net_f4bfe5cdab56",
          "control_net_4bb6a512cc3a",
          "control_net_19bcc72c5488",
          "control_net_185955b3a706",
          "control_net_d109bb25230c",
          "control_net_d9ef0a17e785",
          "control_net_fd2bad63a67c",
          "control_net_bb3aaa71ba05",
          "control_net_907e4adf7ca2",
          "control_net_ebaa690e703b",
          "control_net_92d89f9df56c",
          "control_net_c4d0ccc3d16d",
          "control_net_5220b4a56b5c",
          "control_net_d7ba445b9916",
          "control_net_395f29bc0592",
          "control_net_be534772f175",
          "control_net_42df6ae20837",
          "control_net_075227a69d18",
          "control_net_707df60aeb98",
          "control_net_abae69816039",
          "control_net_4baca15034bf",
          "control_net_4143ff0aef6d",
          "control_net_3ddfecb0df47",
          "control_net_1d61ccb9d017",
          "control_net_6943e9712d9c",
          "control_net_6dc2bebc3e2e",
          "control_net_ac8599a8c0cd",
          "control_net_c5d6e41ef012",
          "control_net_49b164ada644",
          "control_net_63a08f54a8af",
          "control_net_a46672b578ec",
          "control_net_85a84369e22a",
          "control_net_010b6b6f67c9",
          "control_net_d514c816e952",
          "control_net_3a2594a1e1f9",
          "control_net_9bc7997904a8",
          "control_net_6e031edce63d",
          "control_net_17b46c5249cb",
          "control_net_4ff8255e049a",
          "control_net_18e1c9509d79",
          "control_net_d2bff6eceb03",
          "control_net_dc796dddd274",
          "control_net_184f5bb728b0",
          "control_net_0065f370787e",
          "control_net_710e1e095743",
          "control_net_3a720de9ef0a"
        ]
      }
    },
    {
      "sceneId": "system",
      "title": "Компьютер формулирует эксперимент",
      "lead": "Оператор задаёт действие: подготовить уровни, выбрать коммутацию, выполнить воздействие и получить результат.",
      "body": [
        "Запрос сначала остаётся цифровыми данными. Кабель не передаёт в матрицу «готовый импульс»: он доставляет команды и параметры в интерфейсную часть платы. Дальше проект ПЛИС и программа MCU должны разобрать запрос и организовать требуемые аппаратные действия.",
        "Здесь различаются относительно редкие команды управления и поток измерений. Их формат, очереди и сетевой протокол относятся к логике ПЛИС и прошивке; схема предоставляет физические интерфейсы. Сейчас проследим, что происходит с сигналом после входа в разъём Ethernet, а затем посмотрим альтернативный путь USB."
      ],
      "why": "Так компьютер задаёт цель эксперимента, а точное исполнение остаётся рядом с матрицей.",
      "path": [
        "Компьютер",
        "Запрос",
        "Интерфейс платы",
        "ПЛИС"
      ],
      "nodeIds": [
        "host",
        "links",
        "fpga"
      ],
      "edgeIds": [
        "host_links",
        "links_fpga"
      ],
      "storyId": "ethernet-rx",
      "storyStep": 0,
      "id": "main-17",
      "chapterId": "host-link",
      "kind": "main",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e"
        ]
      }
    },
    {
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "title": "Ethernet: сигнал входит через разъём",
      "lead": "На входе ещё физический сигнал кабеля; цифровые слова ПЛИС появятся позже.",
      "body": [
        "На J900 приходят четыре дифференциальные пары Ethernet. Для пары A это ETH_A_P и ETH_A_N. Через T900 сигнал передаётся на сторону платы, где соответствующая пара называется MDI_A_P и MDI_A_N. Импульсы на рисунке условные: они объясняют путь, а не воспроизводят точную форму кодирования Ethernet.",
        "Трансформатор нужен для гальванической развязки кабельной и внутренней стороны. Он не разбирает команды эксперимента и не создаёт IP-пакеты. Его задача на этом участке — передать физический сигнал к PHYU902; уже PHY займётся восстановлением цифровых данных."
      ],
      "why": "Поэтому разъём, развязка и цифровой приёмник выделены отдельными функциональными ступенями.",
      "path": [
        "J900",
        "ETH_A_P · ETH_A_N",
        "T900",
        "MDI_A_P · MDI_A_N",
        "U902"
      ],
      "nodeIds": [
        "connector",
        "isolation",
        "phy"
      ],
      "edgeIds": [
        "connector_isolation_0",
        "isolation_phy_1"
      ],
      "storyId": "local-control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "storyStep": 1,
      "id": "main-18",
      "chapterId": "host-link",
      "kind": "main",
      "source": {
        "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "sheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_eb689a40d9d8",
          "control_net_a0be4ca78cf4",
          "control_net_783e9d027a80",
          "control_net_e72d81f71514",
          "control_net_75386a9fba9e",
          "control_net_40965b12abcc",
          "control_net_46a7e4543439",
          "control_net_a5f76ff3f3d9",
          "control_net_e227481650c4",
          "control_net_2b9e82ff1f9a",
          "control_net_b7668147936d",
          "control_net_f14d9beef5b0",
          "control_net_bdf65fc018f7",
          "control_net_c7652af8ac7f",
          "control_net_c06d53ceafd7",
          "control_net_c72c6f1d768f"
        ]
      }
    },
    {
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "title": "PHY передаёт цифровые данные в ПЛИС",
      "lead": "U902 восстанавливает приём и выдаёт данные вместе с тактом и признаком их действительности.",
      "body": [
        "После трансформатора пары MDI приходят в PHYU902. На другой стороне PHY находится цифровой интерфейс к U500: линии PHY_RXD0…PHY_RXD3 несут данные, PHY_RXC задаёт такт, а PHY_RX_CTL сопровождает приём. Это уже другой вид сигнала, чем на разъёме; в презентации подсвечивается именно этот переход.",
        "Внутри ПЛИС должны работать MAC и дальнейшая обработка кадров, а при необходимости — сетевой стек и логика команд. Их наличие и конкретный протокол определяются загруженным проектом и прошивкой, а не одним PHY. Цепи PHY_MDC и PHY_MDIO дают отдельный путь настройки и чтения состояния PHY."
      ],
      "why": "PHY занимается физическим соединением, а смысл принятых данных обрабатывается в цифровой логике.",
      "path": [
        "MDI_A_P · MDI_A_N",
        "U902",
        "PHY_RXD0 · PHY_RXC",
        "U500"
      ],
      "nodeIds": [
        "isolation",
        "phy",
        "fpga"
      ],
      "edgeIds": [
        "isolation_phy_1",
        "phy_fpga_2"
      ],
      "storyId": "local-control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "storyStep": 3,
      "id": "main-19",
      "chapterId": "host-link",
      "kind": "main",
      "source": {
        "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "sheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_e227481650c4",
          "control_net_2b9e82ff1f9a",
          "control_net_b7668147936d",
          "control_net_f14d9beef5b0",
          "control_net_bdf65fc018f7",
          "control_net_c7652af8ac7f",
          "control_net_c06d53ceafd7",
          "control_net_c72c6f1d768f",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_cc90c66f0af7",
          "control_net_5682aa39e237",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc"
        ]
      }
    },
    {
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "title": "USB: от кабеля к 32-битным словам",
      "lead": "USB-мост преобразует внешний последовательный интерфейс в параллельный поток, удобный для FPGA.",
      "body": [
        "J700 принимает кабель USB Type-C. Защитные устройства ограничивают внешние разряды, а U706 определяет ориентацию подключения и коммутирует активные SuperSpeed-пары к FT_RX_P / FT_RX_N и FT_TX_P / FT_TX_N. USB 2.0 линии USB_DP / USB_DM подключены к мосту отдельно.",
        "U707 — FT601: со стороны кабеля он обслуживает USB, со стороны U500 предоставляет 32-битную синхронную FIFO-шину FT_D0–FT_D31 и сигналы управления обменом. Программа компьютера и логика FPGA должны договориться о формате команд, длинах блоков и управлении потоком. Этот же тракт можно использовать для возвращения буферизованных результатов."
      ],
      "why": "USB-мост снимает с FPGA часть протокольной работы, но формат прикладных данных остаётся задачей проекта.",
      "path": [
        "J700",
        "Защита и ориентация",
        "FT601 U707",
        "FT_D0–FT_D31",
        "U500"
      ],
      "nodeIds": [
        "connector",
        "orientation",
        "bridge",
        "fpga"
      ],
      "edgeIds": [
        "connector_orientation",
        "orientation_bridge",
        "bridge_fpga"
      ],
      "id": "main-20",
      "chapterId": "host-link",
      "kind": "main",
      "source": {
        "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "sheetName": "700_FPGA_USB3_FIFO_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_8a18244b5094",
          "control_net_cd5767d1244a",
          "control_net_4a77ae0a5e9e",
          "control_net_81e7ad5ba413",
          "control_net_dfb816a62c27",
          "control_net_7293b201db23",
          "control_net_c17cad38b3b9",
          "control_net_bb9ef2893216",
          "control_net_3e4cca7b1d3b",
          "control_net_9cc415b59d1d",
          "control_net_3fea9522f27f",
          "control_net_4e0bed631879",
          "control_net_ee1064f82d57",
          "control_net_90ccce2c8039",
          "control_net_4ab70b5a5d2e",
          "control_net_5d12a42f13a7",
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_0aa940b07213",
          "control_net_5f4121b0067b",
          "control_net_45ad74d728ee",
          "control_net_34a5458782a9",
          "control_net_a0ccf5710062",
          "control_net_77550a265a38",
          "control_net_95229f960617",
          "control_net_76c093c7625c",
          "control_net_0c2767ceedce",
          "control_net_e4fd6a071815",
          "control_net_81564ca10d04",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2"
        ]
      }
    },
    {
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "title": "MCU и ПЛИС согласуют работу",
      "lead": "Быстрый интерфейс и точные аппаратные действия нужно связать с управляющей программой.",
      "body": [
        "Отдельная ветвь U900/U901 обслуживает связь между доменами MCU и ПЛИС. На ней видны такт, выбор устройства, передача команд и ответов: MCU_FPGA_SCK_F, MCU_FPGA_CS_N_F, MCU_FPGA_MOSI_F и MCU_FPGA_MISO_F. FPGA_IRQ_F позволяет сообщить о событии по отдельному сигналу.",
        "По этой связи программа может передавать параметры и узнавать состояние выполнения. Конкретные команды и распределение вычислений должны быть реализованы программно. Физически буферы отделяют интерфейс от различий и отключения питающих доменов; поэтому эта ветвь показана отдельно от потока Ethernet."
      ],
      "why": "Командная связь не должна превращаться в обход правил питания и аппаратных разрешений.",
      "path": [
        "MCU",
        "U900 · U901",
        "MCU_FPGA_MOSI_F",
        "U500",
        "MCU_FPGA_MISO_F"
      ],
      "nodeIds": [
        "management",
        "fpga"
      ],
      "edgeIds": [
        "management_fpga_5"
      ],
      "id": "main-21",
      "chapterId": "host-link",
      "kind": "main",
      "source": {
        "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "sheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_028458bc6a66",
          "control_net_189baa4e46d2",
          "control_net_d586ee5fe950",
          "control_net_ff9ff859ce5e",
          "control_net_101ecb817b3a",
          "control_net_b754ba5a60da"
        ]
      }
    },
    {
      "sceneId": "control",
      "title": "От команды к электрическому опыту и обратно",
      "lead": "На плате Control цифровая команда превращается в воздействие на матрицу, а её электрический отклик — в цифровой результат.",
      "body": [
        "Вход INTERCONNECT приносит питание и разрешения от платы Power. MCU координирует работу, а FPGA должна задавать точную последовательность: установить аналоговые значения, выбрать соединения матрицы, выполнить операцию и принять измерение. Это разделение позволяет менять сценарий эксперимента, сохраняя аппаратные ограничения.",
        "Путь к матрице проходит через DAC и MATRIX. Обратный путь идёт через ADC к FPGA и затем к компьютеру. PROTECTION наблюдает за током источника и состоянием операции; при аварии аппаратные разрешения снимаются независимо от того, успела ли управляющая программа обработать событие."
      ],
      "why": "Для полного цикла нужны и собранная схема, и согласованные прошивка MCU, конфигурация FPGA и программа компьютера.",
      "path": [
        "Питание и разрешения",
        "MCU / FPGA",
        "DAC → MATRIX",
        "ADC → FPGA",
        "Компьютер"
      ],
      "nodeIds": [
        "host",
        "fpga",
        "sources",
        "routing"
      ],
      "edgeIds": [
        "host_fpga",
        "fpga_sources",
        "fpga_routing"
      ],
      "id": "main-22",
      "chapterId": "host-link",
      "kind": "main",
      "source": {
        "sheetId": "control_MIRA_Control",
        "sheetName": "MIRA_Control",
        "board": "control",
        "netIds": [
          "control_net_e7c041fd6c4f",
          "control_net_f9eaf352353a",
          "control_net_9aff4b2212a6",
          "control_net_e84839bbf71f",
          "control_net_625cef89ab64",
          "control_net_e8d1c7605faf",
          "control_net_cdd2b08d9db8",
          "control_net_028458bc6a66",
          "control_net_189baa4e46d2",
          "control_net_ff9ff859ce5e",
          "control_net_101ecb817b3a",
          "control_net_8543c7028353",
          "control_net_8baeadc9d1f8",
          "control_net_7f616706cf93",
          "control_net_0d0a126b05bc",
          "control_net_2889fbee2814",
          "control_net_a2017f4fe37b",
          "control_net_90accaec6322",
          "control_net_bae01a82acc2",
          "control_net_fd8710ab620d",
          "control_net_30006651dbc3",
          "control_net_889281b6cc29",
          "control_net_429d3a1721ef",
          "control_net_d2248f535667",
          "control_net_a0f26e09322b",
          "control_net_770516324e4c",
          "control_net_d846a1ae0de8",
          "control_net_0831bf7686e1",
          "control_net_2690ba9f85c2",
          "control_net_1060da4e1062",
          "control_net_8e945f7df341",
          "control_net_f05b5740e1a9",
          "control_net_103f84ec6132",
          "control_net_c6ecade8f839",
          "control_net_8e9184bc5c46",
          "control_net_ba2ab40384c6",
          "control_net_c254fca78b2c",
          "control_net_f16f12a0707d",
          "control_net_d095506d8145",
          "control_net_df16aaaa5404",
          "control_net_2a00cc654f3d",
          "control_net_5130997c4fe8",
          "control_net_c4621dfd0ac4"
        ]
      }
    },
    {
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "title": "Как FPGA задаёт значения ЦАП",
      "lead": "Последовательная шина передаёт числа, а отдельные сигналы выбирают адресата и момент применения.",
      "body": [
        "На U500 выведены DAC_SPI_SCK, DAC_SPI_MOSI и DAC_SPI_MISO. Сигналы CS_BL0–CS_BL3 выбирают банки битовых линий; CS_CTRL и CS_HV относятся к сервисным и высоковольтным уставкам. Таким образом, общая шина не означает одновременное изменение всех источников.",
        "DAC_LDAC_N и DAC_RESET_N управляют применением и сбросом в пределах возможностей выбранных ЦАП. Подтягивающие резисторы удерживают линии выбора, сброса и загрузки в определённых состояниях, пока ПЛИС ещё не сконфигурирована. Последовательность безопасного обновления должен задавать проект управления."
      ],
      "why": "Во время старта уставки не должны случайно изменяться из-за неопределённых управляющих уровней.",
      "path": [
        "U500",
        "CS_BL* / CS_CTRL / CS_HV",
        "DAC_SPI_*",
        "LDAC / RESET"
      ],
      "nodeIds": [
        "fpga",
        "bias"
      ],
      "edgeIds": [
        "fpga_bias"
      ],
      "id": "main-23",
      "chapterId": "setpoints",
      "kind": "main",
      "source": {
        "sheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "sheetName": "1200_DAC_FPGA_CONTROL_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_8543c7028353",
          "control_net_0d0a126b05bc",
          "control_net_a2017f4fe37b",
          "control_net_90accaec6322",
          "control_net_bae01a82acc2",
          "control_net_fd8710ab620d",
          "control_net_fad82bf41bcf",
          "control_net_596ada6680f2"
        ]
      }
    },
    {
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "title": "32 независимых напряжения битовых линий",
      "lead": "Четыре одинаковых банка позволяют задавать разные аналоговые значения для BL0–BL31.",
      "body": [
        "ЦАП U1000, U1003, U1006 и U1009 создают по восемь напряжений. Их выходы BL_DAC_RAW* поступают на буферные усилители: например, первый банк обслуживают U1001 и U1002. После буферов цепи BL_DAC0–BL_DAC31 уходят к коммутации матрицы.",
        "Буфер отделяет выход ЦАП от следующей нагрузки и поддерживает заданное напряжение в пределах возможностей тракта. На диаграмме четыре параллельных канала означают четыре группы по восемь линий, а не четыре последовательные ступени. Какие из этих напряжений фактически попадут на матрицу, определяется состоянием ключей MATRIX."
      ],
      "why": "Независимая уставка каждого столбца полезна только вместе с контролируемой коммутацией.",
      "path": [
        "Четыре ЦАП",
        "BL_DAC_RAW*",
        "Буферы",
        "BL_DAC0–BL_DAC31"
      ],
      "nodeIds": [
        "dac0",
        "buffer0"
      ],
      "edgeIds": [
        "dac0_buffer0_0"
      ],
      "id": "main-24",
      "chapterId": "setpoints",
      "kind": "main",
      "source": {
        "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "sheetName": "1000_DAC_BL0_31_AND_BUFFERS",
        "board": "control",
        "netIds": [
          "control_net_47af455af6dc",
          "control_net_b90f47fe887d",
          "control_net_a0db919ee83d",
          "control_net_d6647a4628c8",
          "control_net_8be92a53ce8b",
          "control_net_78ba9d6b88dd",
          "control_net_e1f6195edd21",
          "control_net_561ae5f25bce"
        ]
      }
    },
    {
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "title": "Отдельные уставки для READ, SET, RESET и FORMING",
      "lead": "Сервисные операции используют собственные напряжения и ограничения тока, отличные от банка VMM.",
      "body": [
        "U1100 формирует сервисные уставки, среди которых VREAD_DAC, VSET_DAC, VRESET_DAC и ILIM_SET_DAC / ILIM_RESET_DAC / ILIM_FORM_DAC. Буферы U1101 и U1102 передают их в следующие ступени. Отдельный ЦАП U1103 и усилитель U1104 образуют ветвь FORMING с цепью VFORM_DAC_RAW.",
        "Дальше селекторы выбирают нужный источник и ограничение, а регулятор превращает уставку в управляемое воздействие. Число в ЦАП не задаёт длительность импульса: время, адрес и разрешение формируются матричной логикой. Поэтому напряжение, токовый предел и длительность следует показывать как три согласованных параметра операции."
      ],
      "why": "Разные режимы требуют разных условий воздействия, но должны пользоваться общей безопасной последовательностью.",
      "path": [
        "U1100: сервисные уставки",
        "Буферы",
        "U1103 / U1104: FORMING",
        "Регулируемый источник"
      ],
      "nodeIds": [
        "commands",
        "buffer",
        "forming",
        "formbuffer"
      ],
      "edgeIds": [
        "commands_buffer",
        "forming_formbuffer"
      ],
      "id": "main-25",
      "chapterId": "setpoints",
      "kind": "main",
      "source": {
        "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
        "sheetName": "1100_DAC_SERVICE_AND_FORMING",
        "board": "control",
        "netIds": [
          "control_net_e7bd9de88b26",
          "control_net_5f3aa6ac02ea",
          "control_net_872644d0a844",
          "control_net_5c53c9973c60",
          "control_net_245f41faaafc",
          "control_net_c1240dda3ce7",
          "control_net_3c3ad73203dc",
          "control_net_a29863c03d26",
          "control_net_5980e068f72a"
        ]
      }
    },
    {
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "title": "Проверка согласованности матричной операции",
      "lead": "Запрос FPGA проходит через фиксацию, сравнение и аппаратные разрешения до включения исполнительных путей.",
      "body": [
        "U500 выдаёт поля режима, адреса и полярности в цепях MAT_*_REQ. Регистры фиксации удерживают активный запрос, а U1329 и U1330 участвуют в сравнении. Идея этого узла — обнаружить изменение управляющих полей относительно состояния, с которым операция была подготовлена.",
        "Логика разрешений объединяет запросы с условиями готовности и аварии, а декодирование формирует выбранные режимы и безопасные управляющие сигналы. Например, MAT_CONFIG_LATCH относится к фиксации конфигурации, а MAT_PULSE — ко времени воздействия. Отдельные шаги загрузки, фиксации и запуска позволяют не путать перестройку схемы с выполнением импульса."
      ],
      "why": "Изменившийся адрес во время воздействия должен рассматриваться как нарушение условий операции.",
      "path": [
        "MAT_*_REQ",
        "Фиксация",
        "Сравнение",
        "Разрешение",
        "MAT_*_SAFE"
      ],
      "nodeIds": [
        "fpga",
        "capture",
        "compare",
        "permissions",
        "decode"
      ],
      "edgeIds": [
        "fpga_capture",
        "capture_compare",
        "compare_permissions",
        "permissions_decode"
      ],
      "id": "main-26",
      "chapterId": "matrix-route",
      "kind": "main",
      "source": {
        "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "sheetName": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "board": "control",
        "netIds": [
          "control_net_2690ba9f85c2",
          "control_net_1060da4e1062",
          "control_net_8e945f7df341",
          "control_net_103f84ec6132",
          "control_net_c6ecade8f839",
          "control_net_8e9184bc5c46",
          "control_net_ba2ab40384c6",
          "control_net_c254fca78b2c",
          "control_net_f16f12a0707d",
          "control_net_d095506d8145",
          "control_net_df16aaaa5404",
          "control_net_2a00cc654f3d",
          "control_net_5130997c4fe8",
          "control_net_5f9f5680becf",
          "control_net_6e69a2fb065e",
          "control_net_8e443662774e",
          "control_net_93d867935f6d",
          "control_net_942f92e36dcb",
          "control_net_c3b957dc2a05",
          "control_net_53c8d7c2e621",
          "control_net_68c0b1b9f3d9",
          "control_net_4cbb94b58c81",
          "control_net_5a48e06ad240",
          "control_net_11d0bca5a9c3",
          "control_net_5adbbaca70af",
          "control_net_5d5a8a88fb46",
          "control_net_3f65bb4e6c1b",
          "control_net_24511a425a2f",
          "control_net_558e432b5f50",
          "control_net_12757af1d119",
          "control_net_7a2e58dd0886",
          "control_net_b0ef82a04563",
          "control_net_b544695cd7b3",
          "control_net_49fde52ce0ed",
          "control_net_2e40141f478d",
          "control_net_87fe3b573357",
          "control_net_a263c7c6e291",
          "control_net_d846a1ae0de8",
          "control_net_0831bf7686e1",
          "control_net_390c067b3ead",
          "control_net_ae0baa487445",
          "control_net_4680bd4e9f98"
        ]
      }
    },
    {
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "title": "Как сохраняется 80-битное состояние ключей",
      "lead": "Последовательная загрузка даёт много управляющих выходов при небольшом числе линий от FPGA.",
      "body": [
        "Цепочка регистров U1400–U1409 принимает образ состояния ключей. MAT_SPI_MOSI передаёт биты, MAT_SPI_SCK задаёт моменты их сдвига, а межрегистровые цепи MAT_CHAIN_* продолжают поток между группами. Поэтому восемьдесят состояний не требуют восьмидесяти отдельных проводов от ПЛИС.",
        "MAT_CONFIG_LATCH относится к фиксации подготовленного состояния на выходах. Сигналы MAT_ALLOWED и MAT_OE_N участвуют в допуске выходов к работе. Во время рассказа полезно сначала показать бегущий последовательный поток, а затем одновременное применение образа: это разные стадии, которые должны согласовываться с разрешением матричной операции."
      ],
      "why": "Полностью подготовленный образ удобнее применять как одно состояние, чем перестраивать активные ключи по одному.",
      "path": [
        "MAT_SPI_MOSI",
        "U1400–U1409",
        "MAT_CONFIG_LATCH",
        "Выходы ключей"
      ],
      "nodeIds": [
        "first",
        "second",
        "last"
      ],
      "edgeIds": [
        "first_second",
        "second_last"
      ],
      "id": "main-27",
      "chapterId": "matrix-route",
      "kind": "main",
      "source": {
        "sheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "sheetName": "1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "board": "control",
        "netIds": [
          "control_net_2e40141f478d",
          "control_net_d0ee9c0888fb",
          "control_net_770516324e4c",
          "control_net_5c0da047cc8c",
          "control_net_c73ef0628409",
          "control_net_9f906a4c978b"
        ]
      }
    },
    {
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "title": "Куда идут 32 битовые линии",
      "lead": "Четыре банка ключей связывают BL0–BL31 с нужными аналоговыми путями.",
      "body": [
        "Группы U1500–U1515 обслуживают по восемь битовых линий; дополнительные селекторы U1516–U1519 участвуют в сервисном выборе. Ключи позволяют использовать подготовленные напряжения BL_DAC*, фиксировать выбранные линии или подключать сервисный путь в соответствии с режимом.",
        "Общие цепи MAT_BL_A0–MAT_BL_A2 и MAT_SERVICE_SAFE встречаются в нескольких банках, потому что несут общие команды выбора и разрешения. Связи между банками на диаграмме не означают, что полезный аналоговый сигнал последовательно проходит через все четыре банка. Это параллельные группы, сходящиеся на разъёме матрицы."
      ],
      "why": "Раздельные банки сокращают масштаб одного узла, сохраняя независимую работу линий.",
      "path": [
        "BL_DAC*",
        "Ключи четырёх банков",
        "Выбранный сервисный путь",
        "BL0–BL31"
      ],
      "nodeIds": [
        "bank0",
        "bank1"
      ],
      "edgeIds": [
        "bank0_bank1"
      ],
      "id": "main-28",
      "chapterId": "matrix-route",
      "kind": "main",
      "source": {
        "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
        "sheetName": "1500_MATRIX_BL0_31_SWITCHING",
        "board": "control",
        "netIds": [
          "control_net_209d9624cc4d",
          "control_net_11d0bca5a9c3",
          "control_net_5adbbaca70af",
          "control_net_5d5a8a88fb46"
        ]
      }
    },
    {
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "title": "Выбор источника, банка и полярности",
      "lead": "Сервисное воздействие должно попасть в нужную группу линий с нужным знаком и корректным возвратным путём.",
      "body": [
        "U1601 выбирает сервисный источник, U1600 — банк назначения, а U1602 участвует в выборе полярности. Эти функции разделены: выбор напряжения не заменяет выбор адреса, а смена полярности меняет направление электрического воздействия на выбранный элемент.",
        "U1603 обслуживает возврат READ и сброс состояния регулятора при отключённом источнике. Цепи MAT_BL_SERVICE и MAT_RETURN помогают проследить сервисный и возвратный пути; MAT_SERVICE_SAFE относится к разрешению этого режима. Именно здесь удобно объяснить, почему недостаточно одной стрелки «напряжение в матрицу»: электрическому воздействию нужен замкнутый и контролируемый маршрут."
      ],
      "why": "Источник, адрес и возвратный путь должны составлять одну согласованную конфигурацию.",
      "path": [
        "Сервисный источник",
        "Банк BL",
        "Полярность",
        "MAT_RETURN"
      ],
      "nodeIds": [
        "source",
        "bank",
        "polarity",
        "return"
      ],
      "edgeIds": [
        "source_bank",
        "bank_polarity",
        "polarity_return"
      ],
      "id": "main-29",
      "chapterId": "matrix-route",
      "kind": "main",
      "source": {
        "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "sheetName": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "board": "control",
        "netIds": [
          "control_net_209d9624cc4d",
          "control_net_2c4dffd5842a",
          "control_net_45e2821ea470"
        ]
      }
    },
    {
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "title": "Выбранные строки и измерительные линии",
      "lead": "WL выбирают условия на строках, а NL определяют, какой отклик пойдёт в измерительный тракт.",
      "body": [
        "U1700 и U1701 управляют выбранными строками WL. U1702 и U1703 фиксируют неактивные NL в предусмотренных состояниях, чтобы они не оставались произвольно плавающими. U1705 выбирает измеряемую линию NL, а U1704 участвует в проверке управляющих команд.",
        "Дальше выбранный ток передаётся к узлу TIA. Здесь важно показывать одновременно активную линию и судьбу остальных: одна выбранная ветвь не означает, что все соседние выводы можно оставить без определённого режима. Общая конфигурация BL, WL и NL задаёт реальную электрическую задачу, которую мы затем измеряем."
      ],
      "why": "Поведение невыбранных линий влияет на эксперимент так же, как выбор измеряемого канала.",
      "path": [
        "Управление WL",
        "Фиксация NL",
        "Выбор U1705",
        "Измерительный тракт"
      ],
      "nodeIds": [
        "word",
        "selection",
        "permit",
        "clamp"
      ],
      "edgeIds": [
        "clamp_selection",
        "selection_permit"
      ],
      "id": "main-30",
      "chapterId": "matrix-route",
      "kind": "main",
      "source": {
        "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "sheetName": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "board": "control",
        "netIds": [
          "control_net_919f25939ba9",
          "control_net_79947d226d73",
          "control_net_d380ae123eb3",
          "control_net_5212ff00c1ac",
          "control_net_072af1a28ea6",
          "control_net_e8ccb5161adb",
          "control_net_3762f1a58fed",
          "control_net_e4379a2b0f61",
          "control_net_fdc5577f6544"
        ]
      }
    },
    {
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "title": "Граница платы и экспериментальной матрицы",
      "lead": "Здесь аналоговые пути сходятся на разъёме, к которому подключается матрица или её адаптер.",
      "body": [
        "J1800 является точкой подключения матрицы. К нему приходят битовые линии BL, строки WL и измерительные линии NL из предыдущих ступеней коммутации. На этом месте удобно проследить одну выбранную линию от источника до разъёма и одну обратную — от матрицы к измерению.",
        "J1801 и J1802 относятся к выбору смещения адаптера; цепи MAT_ADAPTER_CASE и MAT_ADAPTER_VSUB задают соответствующие подключения. Набор и электрические свойства подключаемой матрицы определяют допустимые режимы опыта. Поэтому состояние адаптера и его смещения нужно учитывать вместе с программными уставками, адресом и ограничением тока."
      ],
      "why": "Разъём соединяет универсальный измерительный тракт с конкретным экспериментальным объектом.",
      "path": [
        "BL / WL / NL",
        "J1800",
        "Матрица",
        "Смещение адаптера"
      ],
      "nodeIds": [
        "socket",
        "bias"
      ],
      "edgeIds": [
        "socket_bias"
      ],
      "id": "main-31",
      "chapterId": "matrix-route",
      "kind": "main",
      "source": {
        "sheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "sheetName": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "board": "control",
        "netIds": [
          "control_net_6380a00471f5",
          "control_net_b538393eaff5"
        ]
      }
    },
    {
      "sceneId": "system",
      "title": "Чтение: напряжение проходит в матрицу, отклик возвращается",
      "lead": "Для чтения нужны и заданный аналоговый уровень, и уже подготовленная коммутация.",
      "body": [
        "ПЛИС отправляет уставки в блок DAC и задаёт конфигурацию маршрутов. Ключи соединяют требуемый источник с выбранными линиями матрицы; сам ЦАП не выбирает ячейку. После применения конфигурации на исследуемой цепи появляется заданное воздействие.",
        "В ответ течёт ток, который зависит от подключённой структуры и её состояния. Этот ток нельзя отправить непосредственно в цифровую память: сначала измерительный тракт преобразует его в подходящее напряжение, затем АЦП формирует число. Сейчас приблизим этот участок и проследим MAT_TIA_IN до цифрового результата."
      ],
      "why": "Чтение связывает три подготовленные части: источник уровня, маршрут к матрице и измерение.",
      "path": [
        "DAC",
        "Коммутация",
        "MATRIX",
        "MAT_TIA_IN",
        "ADC"
      ],
      "nodeIds": [
        "drive",
        "fpga",
        "matrix",
        "readout"
      ],
      "edgeIds": [
        "drive_matrix",
        "fpga_matrix",
        "matrix_readout"
      ],
      "storyId": "matrix-read",
      "storyStep": 3,
      "id": "main-32",
      "chapterId": "readout",
      "kind": "main",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_43c57dc0fd8c",
          "control_net_8d6768741a17",
          "control_net_d7baf045ad36",
          "control_net_beae8f10af57",
          "control_net_08cafd4a06b1",
          "control_net_d2e352168d81",
          "control_net_339e997cde5d",
          "control_net_78c06670fbe2",
          "control_net_ecfae2e6bc3f",
          "control_net_de495400ab4d",
          "control_net_a25f83c5766f",
          "control_net_957e25b7b62b",
          "control_net_6c5bac16ddbe",
          "control_net_b00353d4bc57",
          "control_net_a555576805ce",
          "control_net_795fcecf8d80",
          "control_net_5357ea4931e2",
          "control_net_e3f04569205d",
          "control_net_d3cbff2509ef",
          "control_net_aa72e4d066e3",
          "control_net_9a9cf021ea69",
          "control_net_8ae61bd6427a",
          "control_net_c2ddd031305c",
          "control_net_9a9241c5281b",
          "control_net_a21df6263907",
          "control_net_728a06da1431",
          "control_net_8247058ba4d6",
          "control_net_0b4fec439a85",
          "control_net_053310f9940f",
          "control_net_6a631d5bc074",
          "control_net_05e96fc05120",
          "control_net_c3b76f2a4b40",
          "control_net_30006651dbc3",
          "control_net_889281b6cc29",
          "control_net_429d3a1721ef",
          "control_net_d2248f535667",
          "control_net_a0f26e09322b",
          "control_net_770516324e4c",
          "control_net_d846a1ae0de8",
          "control_net_0831bf7686e1",
          "control_net_f05b5740e1a9",
          "control_net_c4621dfd0ac4",
          "control_net_d65f00f0a2d4"
        ]
      }
    },
    {
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "title": "Как ток матрицы становится измеряемым напряжением",
      "lead": "Преобразователь ток–напряжение связывает выбранную линию матрицы с входом измерительной системы.",
      "body": [
        "U1900 принимает ток через MAT_TIA_IN и формирует напряжение MAT_TIA_OUT. Селектор U1901 выбирает чувствительность токового преобразования, чтобы один тракт мог обслуживать разные уровни отклика. Изменение чувствительности меняет масштаб будущего результата, поэтому его состояние должно быть известно управляющей части.",
        "U1902 выбирает точку контроля, а U1903 позволяет наблюдать соответствующие сигналы с дополнительной буферизацией. Помимо отклика матрицы, в контрольном пути присутствуют MAT_CC_SENSE_BUF и MAT_ILIM_SENSE_BUF. Выбранный аналоговый сигнал затем идёт на MAT_MONITOR_RAW к листу АЦП, где превращается в цифровые отсчёты."
      ],
      "why": "Перед оцифровкой ток нужно преобразовать и привести к подходящему измерительному диапазону.",
      "path": [
        "MAT_TIA_IN",
        "U1900 / U1901",
        "MAT_TIA_OUT",
        "U1902",
        "MAT_MONITOR_RAW"
      ],
      "nodeIds": [
        "current",
        "range",
        "monitor",
        "buffer"
      ],
      "edgeIds": [
        "current_range",
        "current_monitor",
        "monitor_buffer"
      ],
      "id": "main-33",
      "chapterId": "readout",
      "kind": "main",
      "source": {
        "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "sheetName": "1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "board": "control",
        "netIds": [
          "control_net_d65f00f0a2d4",
          "control_net_f993730bd850",
          "control_net_fc57b8202dba",
          "control_net_7eb34b3468da"
        ]
      }
    },
    {
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "title": "Как подготовленное напряжение становится отсчётом",
      "lead": "АЦП получает дифференциальный сигнал и точную опору, а FPGA управляет моментом преобразования и чтением.",
      "body": [
        "Опорный узел U2000 / U2001 формирует MAT_ADC_REF и уровень MAT_ADC_CM. Буфер U2002 принимает выбранный контрольный сигнал; U2003 готовит дифференциальные входы MAT_ADC_INP и MAT_ADC_INN. АЦП U2004 преобразует эту разность напряжений в число относительно своей опоры.",
        "Команда MAT_ADC_CNV задаёт момент преобразования, а MAT_ADC_SDO возвращает отсчёт к U500; рядом используются MAT_ADC_SCK и MAT_ADC_SDI. Программируемая логика должна согласовать выбор канала, установление аналогового сигнала, запуск АЦП и чтение результата. После этого число можно снабдить меткой канала и параметрами опыта и отправить компьютеру."
      ],
      "why": "Точное измерение требует согласованного времени, опоры и формата результата, а не только самого АЦП.",
      "path": [
        "MAT_MONITOR_RAW",
        "U2002 / U2003",
        "MAT_ADC_INP / INN",
        "U2004",
        "MAT_ADC_SDO → U500"
      ],
      "nodeIds": [
        "reference",
        "monitor",
        "differential",
        "adc"
      ],
      "edgeIds": [
        "monitor_differential",
        "differential_adc",
        "reference_adc"
      ],
      "id": "main-34",
      "chapterId": "readout",
      "kind": "main",
      "source": {
        "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "sheetName": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "board": "control",
        "netIds": [
          "control_net_18acc164b68f",
          "control_net_a636afc1774d",
          "control_net_87a4861c654c",
          "control_net_d96556e65ebd"
        ]
      }
    },
    {
      "sceneId": "system",
      "title": "Измерение стало цифровыми отсчётами",
      "lead": "После АЦП информация об отклике снова находится в цифровом тракте.",
      "body": [
        "Отсчёты приходят из блока ADC в ПЛИС. Здесь их можно связать с номером операции, выбранным каналом и временем получения. Аппаратные линии задают возможность такого обмена; порядок выборок, формат результата и контроль ошибок определяются логикой проекта.",
        "Для непрерывного потока может использоваться буферизация в памяти ПЛИС. Она разделяет ритм измерений и ритм внешнего интерфейса, но не устраняет ограничений пропускной способности. Дальше готовые данные должны быть собраны в предусмотренный протоколом ответ и отправлены оператору."
      ],
      "why": "Результат полезен только вместе с контекстом: что измерялось, в каком режиме и было ли завершение нормальным.",
      "path": [
        "ADC",
        "Цифровые отсчёты",
        "FPGA",
        "Буфер и описание операции"
      ],
      "nodeIds": [
        "readout",
        "fpga"
      ],
      "edgeIds": [
        "readout_fpga"
      ],
      "storyId": "ethernet-tx",
      "storyStep": 1,
      "id": "main-35",
      "chapterId": "readout",
      "kind": "main",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_3be7162ce896",
          "control_net_3d36f9d91f43",
          "control_net_a1f3e5011080",
          "control_net_b97070122e98"
        ]
      }
    },
    {
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "title": "Как источник ограничивает напряжение и ток записи",
      "lead": "Источник сравнивает желаемое воздействие с фактическим и регулирует выход до аппаратного отключения при аварии.",
      "body": [
        "Узел задания уставок выбирает ограничения напряжения и тока. Измерительный узел с U2104 и U2109 отслеживает состояние источника, а регулятор формирует управляющее воздействие. U2101 относится к выходному драйверу; цепи MAT_DRV_CMD и MAT_SOURCE позволяют увидеть путь команды и выход источника.",
        "Сброс и ограничение состояния регулятора нужны при выключении и смене режима, чтобы накопленное управляющее состояние не переносилось неконтролируемо в следующую операцию. Конкретные допустимые диапазоны, длительности и устойчивость этого контура требуют расчёта и проверки реального устройства; диаграмма показывает его функциональный принцип."
      ],
      "why": "Установка напряжения не должна отменять ограничение тока при изменении сопротивления исследуемого элемента.",
      "path": [
        "Выбор U2100 / U2103",
        "Измерение тока",
        "Регулирование",
        "U2101",
        "MAT_SOURCE"
      ],
      "nodeIds": [
        "commands",
        "sense",
        "control",
        "drive"
      ],
      "edgeIds": [
        "commands_control",
        "sense_control",
        "control_drive"
      ],
      "id": "main-36",
      "chapterId": "write-safety",
      "kind": "main",
      "source": {
        "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "sheetName": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "board": "control",
        "netIds": [
          "control_net_87568f65b103",
          "control_net_ee356dd4a609",
          "control_net_5b5c009b1508",
          "control_net_81a816b03060",
          "control_net_edfd1164669d",
          "control_net_13ff4635cb1b"
        ]
      }
    },
    {
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "title": "Что происходит при аварии матрицы",
      "lead": "Аппаратная цепь может снять разрешение, не ожидая решения управляющей программы.",
      "body": [
        "Компаратор U2200 формирует MAT_CMP_RAW при обнаружении соответствующего условия. Следующая логика объединяет причины отключения и выдаёт MAT_TRIP. Триггер U2202 фиксирует аварийное состояние MAT_FAULT_Q, после чего выходные цепи снимают разрешения.",
        "На границе с остальной системой важны MAT_FAULT_N и MATRIX_INHIBIT_N: они связывают локальную аварию с запретом матричной операции и системой питания. После остановки программа может сообщить компьютеру о причине, но восстановление не должно происходить от одного исчезновения сигнала компаратора. Сначала требуется безопасное состояние и предусмотренная команда очистки."
      ],
      "why": "Фиксация аварии не даёт автоматически возобновить опасное воздействие после краткого нарушения.",
      "path": [
        "U2200",
        "MAT_TRIP",
        "U2202",
        "MAT_FAULT_N",
        "MATRIX_INHIBIT_N"
      ],
      "nodeIds": [
        "compare",
        "qualify",
        "remember",
        "inhibit"
      ],
      "edgeIds": [
        "compare_qualify",
        "qualify_remember",
        "remember_inhibit"
      ],
      "id": "main-37",
      "chapterId": "write-safety",
      "kind": "main",
      "source": {
        "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "sheetName": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_7b06e5d6a4d9",
          "control_net_9269f101a22a",
          "control_net_d44a94d9b4fd"
        ]
      }
    },
    {
      "sceneId": "system",
      "title": "Начинается обратный путь к компьютеру",
      "lead": "Теперь поток направлен от измерительного тракта через ПЛИС к внешнему интерфейсу.",
      "body": [
        "ПЛИС собирает результаты операции и сопровождающее состояние. В нормальном завершении это измеренные значения; при остановке также важно передать причину запрета или аварии. Как именно упакованы эти поля, задаёт программная часть устройства.",
        "Обратный поток проходит через те же интерфейсные микросхемы, но использует исходящие сигналы. На общей карте он выделен в направлении компьютера. Посмотрим отдельно EthernetTX и USBFIFO: у каждого интерфейса есть собственный физический способ вывести цифровые слова за пределы платы."
      ],
      "why": "Презентация возвращается к тому же интерфейсу, через который начался разговор с устройством.",
      "path": [
        "ADC",
        "FPGA",
        "Ethernet / USB",
        "Компьютер"
      ],
      "nodeIds": [
        "readout",
        "fpga",
        "links",
        "host"
      ],
      "edgeIds": [
        "readout_fpga",
        "links_fpga",
        "host_links"
      ],
      "storyId": "ethernet-tx",
      "storyStep": 2,
      "edgeDirections": {
        "links_fpga": "reverse",
        "host_links": "reverse"
      },
      "id": "main-38",
      "chapterId": "results",
      "kind": "main",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e",
          "control_net_3be7162ce896",
          "control_net_3d36f9d91f43",
          "control_net_a1f3e5011080",
          "control_net_b97070122e98"
        ]
      }
    },
    {
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "title": "Ethernet: из ПЛИС обратно в кабель",
      "lead": "При передаче U500 отдаёт данные PHY, а PHY формирует сигнал для кабельных пар.",
      "body": [
        "Исходящее направление идёт по PHY_TXD0…PHY_TXD3 вместе с PHY_TXC и PHY_TX_CTL от U500 к U902. PHY преобразует цифровую передачу в физический сигнал на стороне MDI. Через T900 этот сигнал передаётся к J900 и уходит в сетевой кабель.",
        "Получение полезного ответа на компьютере требует совместимой реализации MAC, сетевого обмена и формата данных на обеих сторонах. Схема показывает аппаратный маршрут, а не подтверждает готовность TCP, UDP или приложения. Здесь важно увидеть направление: цифровой результат покидает ПЛИС и доходит до внешнего разъёма."
      ],
      "why": "Приём и передача используют разные цифровые линии PHY_RX и PHY_TX, хотя относятся к одному сетевому соединению.",
      "path": [
        "U500",
        "PHY_TXD0 · PHY_TXC",
        "U902",
        "T900",
        "J900"
      ],
      "nodeIds": [
        "fpga",
        "phy",
        "isolation",
        "connector"
      ],
      "edgeIds": [
        "fpga_phy_3",
        "isolation_phy_1",
        "connector_isolation_0"
      ],
      "edgeDirections": {
        "isolation_phy_1": "reverse",
        "connector_isolation_0": "reverse"
      },
      "id": "main-39",
      "chapterId": "results",
      "kind": "main",
      "source": {
        "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "sheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_eb689a40d9d8",
          "control_net_a0be4ca78cf4",
          "control_net_783e9d027a80",
          "control_net_e72d81f71514",
          "control_net_75386a9fba9e",
          "control_net_40965b12abcc",
          "control_net_46a7e4543439",
          "control_net_a5f76ff3f3d9",
          "control_net_e227481650c4",
          "control_net_2b9e82ff1f9a",
          "control_net_b7668147936d",
          "control_net_f14d9beef5b0",
          "control_net_bdf65fc018f7",
          "control_net_c7652af8ac7f",
          "control_net_c06d53ceafd7",
          "control_net_c72c6f1d768f",
          "control_net_842a1bd896e7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_af615c537cb1",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e"
        ]
      }
    },
    {
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "title": "USB: ПЛИС отдаёт слова в мост FIFO",
      "lead": "В USB-варианте цифровые слова уходят из ПЛИС в FT601, а затем к разъёму USB-C.",
      "body": [
        "U500 и U707 обмениваются данными через параллельный FIFO-интерфейс. При выдаче результата ПЛИС использует предусмотренные линии данных и рукопожатия, чтобы передать очередные слова мосту. Мост FT601 обслуживает USB-часть обмена, а не анализ мемристорной матрицы.",
        "Далее сигнал проходит через узлы высокоскоростного USB и разъём J700. Ориентация кабеля и защита внешних линий — отдельные функции около разъёма. На компьютере программу чтения и формат результата нужно согласовать с логикой ПЛИС; выбор USB вместо Ethernet меняет транспорт, но не сам измерительный путь."
      ],
      "why": "FIFO развязывает передачу цифровых слов и сложность физического протокола USB.",
      "path": [
        "U500",
        "FIFO",
        "U707 · FT601",
        "USB-C",
        "Компьютер"
      ],
      "nodeIds": [
        "fpga",
        "bridge",
        "orientation",
        "connector"
      ],
      "edgeIds": [
        "bridge_fpga",
        "orientation_bridge",
        "connector_orientation"
      ],
      "edgeDirections": {
        "bridge_fpga": "reverse",
        "orientation_bridge": "reverse",
        "connector_orientation": "reverse"
      },
      "id": "main-40",
      "chapterId": "results",
      "kind": "main",
      "source": {
        "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "sheetName": "700_FPGA_USB3_FIFO_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_8a18244b5094",
          "control_net_cd5767d1244a",
          "control_net_4a77ae0a5e9e",
          "control_net_81e7ad5ba413",
          "control_net_dfb816a62c27",
          "control_net_7293b201db23",
          "control_net_c17cad38b3b9",
          "control_net_bb9ef2893216",
          "control_net_3e4cca7b1d3b",
          "control_net_9cc415b59d1d",
          "control_net_3fea9522f27f",
          "control_net_4e0bed631879",
          "control_net_ee1064f82d57",
          "control_net_90ccce2c8039",
          "control_net_4ab70b5a5d2e",
          "control_net_5d12a42f13a7",
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_0aa940b07213",
          "control_net_5f4121b0067b",
          "control_net_45ad74d728ee",
          "control_net_34a5458782a9",
          "control_net_a0ccf5710062",
          "control_net_77550a265a38",
          "control_net_95229f960617",
          "control_net_76c093c7625c",
          "control_net_0c2767ceedce",
          "control_net_e4fd6a071815",
          "control_net_81564ca10d04",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2"
        ]
      }
    },
    {
      "sceneId": "system",
      "title": "Цикл замкнулся: оператор получает результат",
      "lead": "Мы прошли весь аппаратный маршрут от источника питания до ответа компьютеру.",
      "body": [
        "Сначала защищённое питание запустило контроль и рабочие домены. Затем MCU и ПЛИС подготовили управление, приняли запрос и задали аналоговые уровни и коммутацию матрицы. Отклик прошёл через TIA и АЦП и вернулся в цифровой тракт.",
        "При чтении результат описывает электрический отклик; при записи после воздействия можно выполнить проверочное чтение. Аппаратная защита остаётся действующей частью обоих режимов. Полученные данные и состояние операции возвращаются оператору по выбранному интерфейсу — после этого можно изменить параметры и запустить следующий эксперимент."
      ],
      "why": "Главная идея MIRA — управляемый эксперимент: задать условия, применить их к матрице, измерить ответ и проверить результат.",
      "path": [
        "Питание",
        "Подготовка",
        "Команда",
        "Матрица",
        "Измерение",
        "Компьютер"
      ],
      "nodeIds": [
        "power",
        "mcu",
        "fpga",
        "drive",
        "matrix",
        "readout",
        "links",
        "host"
      ],
      "edgeIds": [
        "mcu_fpga",
        "fpga_drive",
        "drive_matrix",
        "matrix_readout",
        "readout_fpga",
        "links_fpga",
        "host_links"
      ],
      "edgeDirections": {
        "links_fpga": "reverse",
        "host_links": "reverse"
      },
      "id": "main-41",
      "chapterId": "results",
      "kind": "main",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e",
          "control_net_9aff4b2212a6",
          "control_net_e84839bbf71f",
          "control_net_625cef89ab64",
          "control_net_e8d1c7605faf",
          "control_net_cdd2b08d9db8",
          "control_net_028458bc6a66",
          "control_net_189baa4e46d2",
          "control_net_ff9ff859ce5e",
          "control_net_101ecb817b3a",
          "control_net_8543c7028353",
          "control_net_8baeadc9d1f8",
          "control_net_7f616706cf93",
          "control_net_2889fbee2814",
          "control_net_90accaec6322",
          "control_net_bae01a82acc2",
          "control_net_fd8710ab620d",
          "control_net_43c57dc0fd8c",
          "control_net_8d6768741a17",
          "control_net_d7baf045ad36",
          "control_net_beae8f10af57",
          "control_net_08cafd4a06b1",
          "control_net_d2e352168d81",
          "control_net_339e997cde5d",
          "control_net_78c06670fbe2",
          "control_net_ecfae2e6bc3f",
          "control_net_de495400ab4d",
          "control_net_a25f83c5766f",
          "control_net_957e25b7b62b",
          "control_net_6c5bac16ddbe",
          "control_net_b00353d4bc57",
          "control_net_a555576805ce",
          "control_net_795fcecf8d80",
          "control_net_5357ea4931e2",
          "control_net_e3f04569205d",
          "control_net_d3cbff2509ef",
          "control_net_aa72e4d066e3",
          "control_net_9a9cf021ea69",
          "control_net_8ae61bd6427a",
          "control_net_c2ddd031305c",
          "control_net_9a9241c5281b",
          "control_net_a21df6263907",
          "control_net_728a06da1431",
          "control_net_8247058ba4d6",
          "control_net_0b4fec439a85",
          "control_net_053310f9940f",
          "control_net_6a631d5bc074",
          "control_net_05e96fc05120",
          "control_net_c3b76f2a4b40",
          "control_net_d65f00f0a2d4",
          "control_net_3be7162ce896",
          "control_net_3d36f9d91f43",
          "control_net_a1f3e5011080",
          "control_net_b97070122e98"
        ]
      }
    },
    {
      "sceneId": "power_100_INPUT_CONNECTOR",
      "title": "Внешние 24 В входят через J101",
      "lead": "Пока мы показываем точку входа энергии, ещё до основной защиты.",
      "body": [
        "Разъём J101 принимает внешний источник постоянного тока. На этом участке питание называется +24V_RAW: это исходная входная цепь, которую далее предстоит защитить и распределить.",
        "D101 и D102 с резисторами образуют местную индикацию полярности. Она помогает увидеть состояние входа, но не является разрешением на работу матрицы. Следующая часть принимает ту же энергию и ограничивает последствия аварии."
      ],
      "why": "Наличие напряжения на разъёме ещё не означает готовность платы.",
      "path": [
        "Источник 24 В",
        "J101",
        "+24V_RAW",
        "Входная защита"
      ],
      "nodeIds": [
        "connector",
        "indicators"
      ],
      "edgeIds": [
        "connector_indicators"
      ],
      "id": "detail-power_100_INPUT_CONNECTOR",
      "chapterId": "power-entry",
      "kind": "detail",
      "source": {
        "sheetId": "power_100_INPUT_CONNECTOR",
        "sheetName": "100_INPUT_CONNECTOR",
        "board": "power",
        "netIds": [
          "power_net_6741c8732f40"
        ]
      }
    },
    {
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "title": "Предохранитель и ограничитель импульса",
      "lead": "Входная энергия получает первый барьер перед электронной защитой.",
      "body": [
        "F201 стоит в силовой входной ветви; после него цепь называется +24V_FUSED. Ограничитель D205 SMBJ36CA связан с этой защищаемой шиной и участвует в подавлении кратковременного повышения напряжения.",
        "Отдельная индикация показывает напряжение после предохранителя и состояние его обрыва. Важно не объединять эти функции в одну «умную защиту»: здесь есть пассивные элементы, а управляемое ограничение и сигналы состояния появляются на следующем листе."
      ],
      "why": "Пассивная защита работает без команды микроконтроллера.",
      "path": [
        "+24V_RAW",
        "F201",
        "+24V_FUSED",
        "D205",
        "eFuse"
      ],
      "nodeIds": [
        "fuse",
        "transient",
        "indicate"
      ],
      "edgeIds": [
        "fuse_transient",
        "fuse_indicate",
        "transient_indicate"
      ],
      "id": "detail-power_200_INPUT_FUSE_PROTECTION",
      "chapterId": "power-entry",
      "kind": "detail",
      "source": {
        "sheetId": "power_200_INPUT_FUSE_PROTECTION",
        "sheetName": "200_INPUT_FUSE_PROTECTION",
        "board": "power",
        "netIds": [
          "power_net_e5a2750417c1",
          "power_net_6741c8732f40"
        ]
      }
    },
    {
      "sceneId": "power_400_INPUT_FILTER_SENSE",
      "title": "Фильтр превращает вход в общую силовую шину",
      "lead": "После eFuse питание ещё проходит локальную фильтрацию и измерительный участок.",
      "body": [
        "L401 и конденсаторы сглаживают высокочастотные помехи на EFUSE_OUT. Затем шунт R401 создаёт небольшое измеряемое падение напряжения, связанное с током входной ветви. Дальше нагрузкам доступна шина BUS24.",
        "Сам шунт не вычисляет мощность: измерительный тракт на других листах считывает его сигнал. Так силовой путь и наблюдение за ним остаются связаны физически, но выполняют разные задачи. От BUS24 уже можно запускать отдельные преобразователи."
      ],
      "why": "Распределять питание полезно вместе с возможностью его измерить.",
      "path": [
        "EFUSE_OUT",
        "L401 и конденсаторы",
        "Шунт R401",
        "BUS24"
      ],
      "nodeIds": [
        "filter",
        "sense"
      ],
      "edgeIds": [
        "filter_sense"
      ],
      "id": "detail-power_400_INPUT_FILTER_SENSE",
      "chapterId": "power-entry",
      "kind": "detail",
      "source": {
        "sheetId": "power_400_INPUT_FILTER_SENSE",
        "sheetName": "400_INPUT_FILTER_SENSE",
        "board": "power",
        "netIds": [
          "power_net_8174cad108e5"
        ]
      }
    },
    {
      "sceneId": "power-supervisor",
      "title": "Кто принимает решение о запуске",
      "lead": "Контроллер и аппаратная логика вместе формируют безопасную последовательность.",
      "body": [
        "POWER_CONTROL содержит управляющий STM32, сторожевые схемы, блокировки, вентили команд и проверку готовности. Программная часть может выдавать запросы включения, но физическая команда проходит ещё и через независимое аппаратное разрешение.",
        "Обратный путь тоже разделён: реальные напряжения проверяются отдельно от наличия самих команд. Авария или останов могут снять разрешение без ожидания обычного цикла программы. Раскрывая этот раздел, мы объясняем, почему питание не включается одной общей кнопкой."
      ],
      "why": "Управление не должно быть единственной линией защиты.",
      "path": [
        "AON",
        "Контроллер",
        "Запросы включения",
        "Аппаратное разрешение",
        "Проверка готовности"
      ],
      "nodeIds": [
        "sheet2400",
        "sheet2600",
        "sheet2700",
        "sheet3000"
      ],
      "edgeIds": [
        "sheet2400_sheet2600",
        "sheet2400_sheet2700",
        "sheet2400_sheet3000"
      ],
      "id": "detail-power-supervisor",
      "chapterId": "power-control",
      "kind": "detail",
      "source": {
        "sheetId": "power_POWER_CONTROL",
        "sheetName": "POWER_CONTROL",
        "board": "power",
        "netIds": [
          "power_net_0ee4f5245d75",
          "power_net_2965499926c8",
          "power_net_95f2aea4f265",
          "power_net_b80a0b0c471f",
          "power_net_47f67f61993c",
          "power_net_ed26aaa81531",
          "power_net_e46274585def",
          "power_net_cfa48b7bd3ef",
          "power_net_0c8e0f29b47d",
          "power_net_e1dd2bfabf3b",
          "power_net_99aaef80128f",
          "power_net_61199f10a0d6",
          "power_net_fcfa30509d75",
          "power_net_b81a8e339338",
          "power_net_ae3b1a85f32f",
          "power_net_ac83bbc60cc7",
          "power_net_c9b6c7228333",
          "power_net_9ab95937734d",
          "power_net_6d982403b080",
          "power_net_6ad422db16ac",
          "power_net_4aeb4892b398",
          "power_net_47577a24d67e",
          "power_net_8828c890966d",
          "power_net_35045b6a457d",
          "power_net_cfb766cbb94f",
          "power_net_2cbf74589b12",
          "power_net_86751620b7fb",
          "power_net_5a1f578d112a",
          "power_net_c19f5798f458",
          "power_net_c876bbd15aa2",
          "power_net_83fb386e92c5",
          "power_net_5a10e16f7ce2",
          "power_net_1f6f0734f873",
          "power_net_afa5c4d57041",
          "power_net_f4716909bd0c",
          "power_net_c66ec173184e"
        ]
      }
    },
    {
      "sceneId": "power_2500_PM_WATCHDOGS",
      "title": "Сторожевые схемы замечают потерю активности",
      "lead": "Контроллеры должны регулярно подтверждать, что продолжают работать.",
      "body": [
        "U2501 следит за доменом контроллера питания, а U2502 — за основным контроллером. Они получают предусмотренные сигналы работоспособности и формируют отдельные реакции на нарушение контроля. Местные контакты ручного сброса входят в эту же функцию обслуживания.",
        "Сигналы PM_WDO_N и AON_RESET_N связаны с объединением запросов сброса. Такой путь не требует, чтобы зависшая программа сама правильно сообщила о своей неисправности. Контроль активности дополняет измерение напряжения: питание может быть исправным, а программа — перестать отвечать."
      ],
      "why": "Исправное напряжение не гарантирует работоспособность программы.",
      "path": [
        "Контроллеры",
        "Импульсы активности",
        "U2501 / U2502",
        "Сброс / запрет"
      ],
      "nodeIds": [
        "pm",
        "host",
        "reset"
      ],
      "edgeIds": [
        "pm_reset"
      ],
      "id": "detail-power_2500_PM_WATCHDOGS",
      "chapterId": "power-control",
      "kind": "detail",
      "source": {
        "sheetId": "power_2500_PM_WATCHDOGS",
        "sheetName": "2500_PM_WATCHDOGS",
        "board": "power",
        "netIds": [
          "power_net_b4c478ffb022",
          "power_net_47577a24d67e"
        ]
      }
    },
    {
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "title": "Запросы основных шин проходят через разрешение",
      "lead": "EN_REQ_* и GLOBAL_PWR_PERMIT должны действовать совместно.",
      "body": [
        "U2701/U2702 объединяют запросы контроллера с общим аппаратным разрешением. Из EN_REQ_USB, EN_REQ_SYS, EN_REQ_FPGA и других запросов получаются соответствующие CMD_* для узлов питания.",
        "Резисторы задают определённое состояние управляющих линий по умолчанию. Это важно в начале запуска и при сбросе, когда выводы микроконтроллера ещё не управляют системой. Поэтому команда конкретного преобразователя является результатом двух условий, а не прямым продолжением одного вывода STM32."
      ],
      "why": "Запрос и разрешение должны проверяться в аппаратуре.",
      "path": [
        "EN_REQ_*",
        "GLOBAL_PWR_PERMIT",
        "U2701 / U2702",
        "CMD_*",
        "Преобразователи"
      ],
      "nodeIds": [
        "first",
        "second",
        "default"
      ],
      "edgeIds": [
        "first_default",
        "second_default"
      ],
      "id": "detail-power_2700_PM_ENABLE_GATES_PRIMARY",
      "chapterId": "power-control",
      "kind": "detail",
      "source": {
        "sheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "sheetName": "2700_PM_ENABLE_GATES_PRIMARY",
        "board": "power",
        "netIds": [
          "power_net_f4716909bd0c",
          "power_net_c19f5798f458",
          "power_net_c66ec173184e",
          "power_net_83fb386e92c5",
          "power_net_6649c6cdd008",
          "power_net_9020238d369a",
          "power_net_7f7616523bf4",
          "power_net_6220152fdd65",
          "power_net_c876bbd15aa2",
          "power_net_5a10e16f7ce2",
          "power_net_1f6f0734f873",
          "power_net_afa5c4d57041",
          "power_net_35be90fefcdd",
          "power_net_afd79c7e6e58",
          "power_net_3db57ce8c78a",
          "power_net_9693d69e08e6"
        ]
      }
    },
    {
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "title": "Вспомогательные домены включаются по тем же правилам",
      "lead": "Память, PHY и аналоговые выходы получают отдельные управляемые команды.",
      "body": [
        "U2801/U2802 обрабатывают запросы AUX2V5, IO3V3, DDR, PHY, VTT и малошумящих аналоговых шин. Общий принцип тот же: запрос EN_REQ_* пропускается только вместе с GLOBAL_PWR_PERMIT.",
        "Раздельные CMD_* позволяют программе задавать последовательность доменов, а аппаратному запрету — остановить их независимо от последовательности программы. Подтяжки задают начальные состояния. На этом уровне мы объясняем маршруты команд; сами требуемые временные интервалы ещё определяются алгоритмом запуска."
      ],
      "why": "Разные нагрузки можно включать отдельно, сохраняя общий аппаратный запрет.",
      "path": [
        "EN_REQ_DDR / EN_REQ_PHY",
        "GLOBAL_PWR_PERMIT",
        "U2801 / U2802",
        "CMD_DDR / CMD_PHY"
      ],
      "nodeIds": [
        "first",
        "second",
        "default"
      ],
      "edgeIds": [
        "first_default",
        "second_default"
      ],
      "id": "detail-power_2800_PM_ENABLE_GATES_AUXILIARY",
      "chapterId": "power-control",
      "kind": "detail",
      "source": {
        "sheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "sheetName": "2800_PM_ENABLE_GATES_AUXILIARY",
        "board": "power",
        "netIds": [
          "power_net_d1fe7a20e661",
          "power_net_1b4ac01010f8",
          "power_net_5dc0cb853f29",
          "power_net_69d4e38b1bd0",
          "power_net_05ab23d96f3d",
          "power_net_0faf4b6ebbf5",
          "power_net_04b2f0a4c78b",
          "power_net_d07b46e16a3e",
          "power_net_2c93a597633f",
          "power_net_12bae3231aaa",
          "power_net_b527a6b82695",
          "power_net_ae048a8edaa8",
          "power_net_664171b20ecf",
          "power_net_55bbd3deed41"
        ]
      }
    },
    {
      "sceneId": "power_600_USB_5V",
      "title": "USB получает собственное питание",
      "lead": "Ветка USB5 формируется от платы, а не изображает питание от компьютера.",
      "body": [
        "U601 преобразует BUS24 в USB5 для интерфейса USB. Выходная фильтрация и обратная связь поддерживают напряжение этой ветви, а отдельный управляющий участок принимает CMD_USB и формирует EN_USB.",
        "На диаграмме важно различить два кабельных смысла: USB переносит данные между компьютером и Control, а здесь мы видим питание самого интерфейса. Включение этой ветви подчиняется общей последовательности питания, поэтому наличие подключённого кабеля не заменяет готовность домена."
      ],
      "why": "Передача данных требует запитанного интерфейса на стороне платы.",
      "path": [
        "BUS24",
        "CMD_USB → EN_USB",
        "U601",
        "USB5",
        "Интерфейс USB"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_600_USB_5V",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_600_USB_5V",
        "sheetName": "600_USB_5V",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_4413b84fafe0",
          "power_net_17beae47ec7a"
        ]
      }
    },
    {
      "sceneId": "power_700_SYS_3V3",
      "title": "Основной контроллер получает SYS3V3",
      "lead": "Системная ветвь запускает домен, управляющий экспериментом.",
      "body": [
        "U701 понижает BUS24 до SYS3V3. Отдельный участок принимает CMD_SYS и управляет EN_SYS, поэтому основной контроллер включается в согласованной последовательности, а не непосредственно вместе с внешними 24 В.",
        "Фильтр, выходные конденсаторы и обратная связь поддерживают питание нагрузки. По этой ветви энергия уходит к домену основного контроллера Control; по отдельным сигнальным линиям система затем получает информацию о готовности. Само напряжение питания и команда запуска остаются разными соединениями."
      ],
      "why": "Контроллеру нужны и устойчивое питание, и понятные условия старта.",
      "path": [
        "BUS24",
        "CMD_SYS / EN_SYS",
        "U701",
        "SYS3V3",
        "MCU Control"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_700_SYS_3V3",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_700_SYS_3V3",
        "sheetName": "700_SYS_3V3",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_e7486b382586",
          "power_net_182b119f7233"
        ]
      }
    },
    {
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "title": "ПЛИС получает промежуточную шину",
      "lead": "FPGA5V5 служит источником для нескольких более низких напряжений.",
      "body": [
        "U801 превращает BUS24 в FPGA5V5. Команда CMD_FPGA через EN_FPGA разрешает это преобразование. Полученный выход ещё не является единственным питанием ПЛИС: ядру, вспомогательным цепям, выводам, DDR и PHY нужны свои домены.",
        "Промежуточная ступень позволяет распределить задачи между одним преобразованием 24 В и несколькими локальными ветвями. Дальше мы раскрываем SECONDARY_POWER и прослеживаем, какой выход обслуживает конкретную часть цифровой системы."
      ],
      "why": "Один корпус ПЛИС использует несколько электрических доменов.",
      "path": [
        "BUS24",
        "U801",
        "FPGA5V5",
        "SECONDARY_POWER"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_800_FPGA_INTERMEDIATE_5V5",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_800_FPGA_INTERMEDIATE_5V5",
        "sheetName": "800_FPGA_INTERMEDIATE_5V5",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_20b613e14cd0",
          "power_net_cd1e0a0c9a0e"
        ]
      }
    },
    {
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "title": "Аналоговый тракт получает отдельный предстабилизатор",
      "lead": "ANA6 — промежуточная ступень перед малошумящими выходами.",
      "body": [
        "U901 получает BUS24 и формирует ANA6. Его включение задаётся CMD_ANA через EN_ANA. Эта ветвь предназначена для последующих аналоговых стабилизаторов, а не для непосредственной передачи измерительного сигнала.",
        "После импульсного преобразования напряжение можно дополнительно стабилизировать в ANA5 и ANA3V3. Такая цепочка разделяет эффективное понижение входного питания и подготовку питания для чувствительных аналоговых узлов. На самой диаграмме мы видим энергию и управление этой энергией."
      ],
      "why": "Чувствительным измерениям нужен отдельный путь подготовки питания.",
      "path": [
        "BUS24",
        "CMD_ANA / EN_ANA",
        "U901",
        "ANA6",
        "Малошумящие LDO"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_900_ANALOG_PREREGULATOR_6V",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_900_ANALOG_PREREGULATOR_6V",
        "sheetName": "900_ANALOG_PREREGULATOR_6V",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_44a5bd51b5f3",
          "power_net_bbc855740138"
        ]
      }
    },
    {
      "sceneId": "power_1000_AFE_POSITIVE_15V",
      "title": "Положительное питание для аналоговых узлов",
      "lead": "Ветка P15 обеспечивает положительную сторону двухполярного питания.",
      "body": [
        "U1001 преобразует BUS24 в P15, а команда CMD_P15 через EN_P15 управляет включением. Выход связан с аналоговым трактом и с отдельными ключами питания программирования матрицы.",
        "Здесь ещё не выбираются конкретная ячейка и форма воздействия. Сначала создаётся источник энергии; дальше аналоговая часть и коммутаторы определяют, где и когда его использовать. Такое разделение помогает отличить питание усилителя от сигнала, который усилитель формирует."
      ],
      "why": "Питание аналогового тракта и воздействие на матрицу — разные уровни.",
      "path": [
        "BUS24",
        "U1001",
        "P15",
        "Аналоговый тракт / ключи записи"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1000_AFE_POSITIVE_15V",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1000_AFE_POSITIVE_15V",
        "sheetName": "1000_AFE_POSITIVE_15V",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_35be90fefcdd",
          "power_net_a18264aeba79",
          "power_net_6cbfb60c2369",
          "power_net_967875cada1d",
          "power_net_1924d0e843c7",
          "power_net_6217d5a17f1f",
          "power_net_d150669ccf6b"
        ]
      }
    },
    {
      "sceneId": "power_1100_AFE_NEGATIVE_15V",
      "title": "Отрицательная ветвь требует своего управления",
      "lead": "N15 создаётся инвертирующим преобразованием входной энергии.",
      "body": [
        "U1102 формирует отрицательную шину N15 по инвертирующей схеме. Её локальные управляющие уровни связаны с отрицательным доменом, поэтому команда CMD_N15 передаётся через U1101 к EN_N15.",
        "Это не просто второе такое же положительное питание с другим названием: относительно общего провода его потенциал отрицательный. В дальнейшем P15 и N15 дают аналоговым узлам возможность работать по обе стороны нуля, а коммутаторы отдельно разрешают подачу питания программирования."
      ],
      "why": "Команда должна быть корректно передана между разными электрическими уровнями.",
      "path": [
        "BUS24",
        "CMD_N15 → U1101",
        "U1102",
        "N15"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1100_AFE_NEGATIVE_15V",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1100_AFE_NEGATIVE_15V",
        "sheetName": "1100_AFE_NEGATIVE_15V",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_afd79c7e6e58",
          "power_net_85fba6457595",
          "power_net_c215e379dc64",
          "power_net_50ecae0bf119",
          "power_net_1f3c8d72605a",
          "power_net_34b1e1d7c8f5"
        ]
      }
    },
    {
      "sceneId": "power_1200_POWER_MONITOR",
      "title": "Питание внутренней логики ПЛИС",
      "lead": "Несмотря на имя листа, здесь формируется CORE1V0.",
      "body": [
        "U1201 преобразует FPGA5V5 в CORE1V0. Это энергетический домен внутренней логики и блочной памяти U500. Управляющие цепи CMD_CORE и EN_CORE включают его в общую последовательность запуска.",
        "Отдельный преобразователь нужен потому, что питание ядра отличается от питания выводов ПЛИС. Фильтрация и обратная связь работают вокруг своей нагрузки, а состояние ветви контролируется системой питания. Заголовок 1200_POWER_MONITOR сохранён из KiCad, но назначение показано русским пояснением."
      ],
      "why": "Ядро ПЛИС и её внешние выводы нельзя считать одним доменом.",
      "path": [
        "FPGA5V5",
        "CMD_CORE / EN_CORE",
        "U1201",
        "CORE1V0",
        "Ядро U500"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1200_POWER_MONITOR",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1200_POWER_MONITOR",
        "sheetName": "1200_POWER_MONITOR",
        "board": "power",
        "netIds": [
          "power_net_cd1e0a0c9a0e",
          "power_net_ef7fb27c478f",
          "power_net_717170b9d0c3"
        ]
      }
    },
    {
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "title": "Вспомогательные цепи ПЛИС получают 1,8 В",
      "lead": "AUX1V8 является отдельной управляемой ветвью.",
      "body": [
        "U1301 получает FPGA5V5 и формирует AUX1V8. Команда CMD_AUX18 через EN_AUX18 разрешает работу преобразователя. Его выход относится к вспомогательным цепям ПЛИС, а не к общей шине всех внешних сигналов.",
        "Раздельное питание позволяет соблюдать условия запуска конкретных доменов. На диаграмме главный путь проходит от входа к преобразователю и выходу; боковая ветвь показывает, почему энергия появляется только после разрешённой команды."
      ],
      "why": "Назначение домена определяет его собственные питание и контроль.",
      "path": [
        "FPGA5V5",
        "CMD_AUX18 / EN_AUX18",
        "U1301",
        "AUX1V8"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1300_FPGA_AUX_1V8",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1300_FPGA_AUX_1V8",
        "sheetName": "1300_FPGA_AUX_1V8",
        "board": "power",
        "netIds": [
          "power_net_cd1e0a0c9a0e",
          "power_net_e70ca4a7b1de",
          "power_net_72aaeb0dd85a"
        ]
      }
    },
    {
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "title": "Отдельная вспомогательная ветвь 2,5 В",
      "lead": "AUX2V5 создаётся независимо от AUX1V8.",
      "body": [
        "U1401 понижает FPGA5V5 до AUX2V5. Команда CMD_AUX25 через EN_AUX25 управляет этой ветвью отдельно от остальных цифровых источников. Выходная фильтрация и обратная связь поддерживают нужный домен.",
        "На общем экране две AUX-ветви могут выглядеть похожими, но их нельзя объединить только из-за похожих названий. Они имеют разные выходные уровни, свои команды и собственные измерения. При подробном просмотре сохраняются реальные обозначения каждого соединения."
      ],
      "why": "Похожие функциональные блоки могут обслуживать разные электрические уровни.",
      "path": [
        "FPGA5V5",
        "CMD_AUX25 / EN_AUX25",
        "U1401",
        "AUX2V5"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1400_FPGA_AUX_2V5",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1400_FPGA_AUX_2V5",
        "sheetName": "1400_FPGA_AUX_2V5",
        "board": "power",
        "netIds": [
          "power_net_cd1e0a0c9a0e",
          "power_net_4a44013bf2b3",
          "power_net_38cd986dd59a"
        ]
      }
    },
    {
      "sceneId": "power_1500_FPGA_IO_3V3",
      "title": "Питание выводов определяет внешние уровни ПЛИС",
      "lead": "IO3V3 относится к домену ввода-вывода.",
      "body": [
        "U1501 формирует IO3V3 из FPGA5V5. Цепи CMD_IO33 и EN_IO33 включают эту ветвь по разрешению. Она обеспечивает соответствующий домен внешних соединений U500.",
        "Поэтому наличие CORE1V0 само по себе не означает готовность внешних интерфейсов: внутренней логике и выводам нужны разные питания. Затем система контроля должна подтвердить состояние этих ветвей, прежде чем считать цифровую часть готовой к обмену."
      ],
      "why": "Внутренняя обработка и внешние сигналы зависят от разных доменов.",
      "path": [
        "FPGA5V5",
        "U1501",
        "IO3V3",
        "Выводы U500"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1500_FPGA_IO_3V3",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1500_FPGA_IO_3V3",
        "sheetName": "1500_FPGA_IO_3V3",
        "board": "power",
        "netIds": [
          "power_net_cd1e0a0c9a0e",
          "power_net_6c6a12e16365",
          "power_net_33017e9a066b"
        ]
      }
    },
    {
      "sceneId": "power_1600_DDR_1V35",
      "title": "Память DDR получает свой источник",
      "lead": "DDR1V35 питает память и связанную цепь терминации.",
      "body": [
        "U1601 преобразует FPGA5V5 в DDR1V35. Команда CMD_DDR через EN_DDR управляет запуском ветви. Это питание памяти DDR3L, используемой цифровой частью для хранения рабочих данных.",
        "От DDR1V35 также зависит следующий источник VTT и опорного напряжения. Поэтому показ начинается с основной шины памяти, затем переходит к её поддержке. Быстрые сигналы адреса и данных идут уже на Control; здесь прослеживается только энергетическая подготовка памяти."
      ],
      "why": "До обмена данными должны быть готовы питание и опорные уровни памяти.",
      "path": [
        "FPGA5V5",
        "CMD_DDR / EN_DDR",
        "U1601",
        "DDR1V35",
        "DDR / VTT"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1600_DDR_1V35",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1600_DDR_1V35",
        "sheetName": "1600_DDR_1V35",
        "board": "power",
        "netIds": [
          "power_net_cd1e0a0c9a0e",
          "power_net_f3a748e4fa19",
          "power_net_978b64498138"
        ]
      }
    },
    {
      "sceneId": "power_1700_PHY_1V05",
      "title": "Физический интерфейс Ethernet получает питание ядра",
      "lead": "PHY1V05 обслуживает физический преобразователь Ethernet.",
      "body": [
        "U1701 получает FPGA5V5 и формирует PHY1V05. Цепи CMD_PHY и EN_PHY разрешают эту ветвь в последовательности запуска. Это питание части Ethernet PHY, которая далее будет работать с физическими сигналами линии.",
        "Сетевой кабель сам по себе не делает интерфейс готовым. Нужны питание, тактовая опора и снятие предусмотренного сброса; на следующих диаграммах Control эти условия соединяются с основным трактом данных от RJ45 к ПЛИС."
      ],
      "why": "У передачи пакетов есть электрические предпосылки.",
      "path": [
        "FPGA5V5",
        "CMD_PHY / EN_PHY",
        "U1701",
        "PHY1V05",
        "Ethernet PHY"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1700_PHY_1V05",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1700_PHY_1V05",
        "sheetName": "1700_PHY_1V05",
        "board": "power",
        "netIds": [
          "power_net_cd1e0a0c9a0e",
          "power_net_d1b6d8a1c1d4",
          "power_net_086f4f3255c8"
        ]
      }
    },
    {
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "title": "Поддержка DDR должна следовать за её питанием",
      "lead": "VTT и DDR_VREF связаны с уровнем DDR1V35.",
      "body": [
        "U1801 принимает DDR1V35 и создаёт питание терминации VTT, а также опорное DDR_VREF. В отличие от обычного источника для статической нагрузки, ветвь терминации должна работать с током в обоих направлениях.",
        "Так поддерживаются электрические уровни интерфейса памяти. Команда CMD_VTT через EN_VTT управляет включением, а PGR_VTT сообщает о состоянии. На этом шаге важно увидеть связь с основной шиной DDR: терминация не выбирает произвольный независимый уровень."
      ],
      "why": "Быстрым линиям памяти нужна согласованная электрическая опора.",
      "path": [
        "DDR1V35",
        "U1801",
        "VTT",
        "DDR_VREF",
        "Линии DDR"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1800_DDR_VTT_REFERENCE",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1800_DDR_VTT_REFERENCE",
        "sheetName": "1800_DDR_VTT_REFERENCE",
        "board": "power",
        "netIds": [
          "power_net_f3a748e4fa19",
          "power_net_e295c6eba3ce",
          "power_net_0ee4f5245d75",
          "power_net_ae048a8edaa8",
          "power_net_a494eb253ace",
          "power_net_49a6d57a88bc"
        ]
      }
    },
    {
      "sceneId": "power_1900_ANALOG_5V",
      "title": "Из ANA6 получается малошумящее питание 5 В",
      "lead": "Линейная ступень подготавливает аналоговый домен.",
      "body": [
        "U1901 стабилизирует ANA6 в ANA5. Включение связано с CMD_ANA5 и EN_ANA5, а фильтрующие элементы и обратная связь обслуживают отдельный аналоговый выход.",
        "Роль этой ступени — подготовить питание для чувствительных аналоговых узлов после предварительного преобразования. Оно не переносит результат измерения; сигнал будет идти по другой цепи. Далее ANA5 используется и как источник следующей линейной ступени ANA3V3."
      ],
      "why": "Качество питания и точность измерительного тракта связаны, но это разные пути.",
      "path": [
        "ANA6",
        "U1901",
        "ANA5",
        "Аналоговые узлы / следующий LDO"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_1900_ANALOG_5V",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_1900_ANALOG_5V",
        "sheetName": "1900_ANALOG_5V",
        "board": "power",
        "netIds": [
          "power_net_bbc855740138",
          "power_net_99aaef80128f",
          "power_net_664171b20ecf",
          "power_net_f5932d689562",
          "power_net_4716fe94234d",
          "power_net_d033005e565e",
          "power_net_f8cf954155c7"
        ]
      }
    },
    {
      "sceneId": "power_2000_ANALOG_3V3",
      "title": "Аналоговый домен 3,3 В завершается отдельной ступенью",
      "lead": "ANA3V3 получают из ANA5, сохраняя отдельный аналоговый путь.",
      "body": [
        "U2001 понижает и стабилизирует ANA5 до ANA3V3. Управление приходит по CMD_ANA33 к EN_ANA33. На входе этой ступени уже находится подготовленное аналоговое питание, а не исходные 24 В.",
        "Поэтому вся цепочка читается последовательно: BUS24, ANA6, ANA5, ANA3V3. Её потребители и измерение рассматриваются на соответствующих листах. Отдельное имя цепи помогает не перепутать аналоговые 3,3 В с SYS3V3 или IO3V3, несмотря на одинаковый номинальный уровень."
      ],
      "why": "Одинаковое напряжение не делает разные домены одной общей цепью.",
      "path": [
        "ANA5",
        "CMD_ANA33 / EN_ANA33",
        "U2001",
        "ANA3V3"
      ],
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "id": "detail-power_2000_ANALOG_3V3",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_2000_ANALOG_3V3",
        "sheetName": "2000_ANALOG_3V3",
        "board": "power",
        "netIds": [
          "power_net_f5932d689562",
          "power_net_2fb6eec8140e",
          "power_net_a207f0246008"
        ]
      }
    },
    {
      "sceneId": "power-program",
      "title": "Питание записи допускается к нагрузке отдельно",
      "lead": "Наличие P15/N15 ещё не означает разрешённое программирование.",
      "body": [
        "PROGRAM_SWITCHES содержит положительный и отрицательный силовые ключи и выходной разъём J2301. Они формируют PROG_P15 и PROG_N15 из уже созданных аналоговых источников.",
        "Именно здесь видно дополнительное условие: воздействие на матрицу требует MATRIX_PERMIT. Выбор конкретной ячейки и формы импульса происходит на Control, а Power даёт или снимает энергетическую возможность такого действия. Это отдельный барьер между готовым источником и нагрузкой."
      ],
      "why": "Разрешение эксперимента должно управлять и доступной энергией.",
      "path": [
        "P15 / N15",
        "MATRIX_PERMIT",
        "Силовые ключи",
        "PROG_P15 / PROG_N15",
        "J2301"
      ],
      "nodeIds": [
        "sheet2100",
        "sheet2200",
        "sheet2300"
      ],
      "edgeIds": [
        "sheet2100_sheet2200"
      ],
      "id": "detail-power-program",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_PROGRAM_SWITCHES",
        "sheetName": "PROGRAM_SWITCHES",
        "board": "power",
        "netIds": [
          "power_net_46ab17b8adeb"
        ]
      }
    },
    {
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "title": "Положительная шина записи подключается ключами",
      "lead": "Q2102/Q2103 связывают P15 с PROG_P15 по разрешению.",
      "body": [
        "Встречно включённые PMOS Q2102/Q2103 образуют управляемый силовой участок положительной ветви. Команда MATRIX_PERMIT связана с его управляющими цепями; оптопара U2101 передаёт управление в нужную часть схемы.",
        "Другие транзисторы и ограничители обеспечивают управление затвором и его разряд. Поэтому выключение — тоже активная часть схемы, а не просто исчезновение программной команды. Дальше PROG_P15 уходит к интерфейсу питания программирования."
      ],
      "why": "Силовой ключ должен иметь определённые условия и включения, и выключения.",
      "path": [
        "P15",
        "MATRIX_PERMIT",
        "Q2102 / Q2103",
        "PROG_P15"
      ],
      "nodeIds": [
        "control",
        "switch",
        "stop"
      ],
      "edgeIds": [
        "switch_control",
        "switch_stop"
      ],
      "id": "detail-power_2100_PROGRAM_POSITIVE",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_2100_PROGRAM_POSITIVE",
        "sheetName": "2100_PROGRAM_POSITIVE",
        "board": "power",
        "netIds": [
          "power_net_46ab17b8adeb",
          "power_net_4ec3a13ab6a0",
          "power_net_877d9e8f0cbb",
          "power_net_5a1f578d112a"
        ]
      }
    },
    {
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "title": "Отрицательная шина записи имеет собственный ключ",
      "lead": "Отрицательный силовой домен требует отдельной передачи управления.",
      "body": [
        "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи. Оптопары U2201–U2203 участвуют в передаче команд, управлении выключенным состоянием и разрядом.",
        "Ограничители затворов и выходной зажим работают в локальных цепях MATRIX_N_GATE и MATRIX_N_SOURCE. Их задача — удержать управляемое состояние отрицательного силового участка. Само воздействие на выбранную ячейку появится только после согласования питания с маршрутом на Control."
      ],
      "why": "Отрицательное питание нельзя коммутировать как обычный логический сигнал.",
      "path": [
        "N15",
        "Развязанное управление",
        "Q2201 / Q2202",
        "PROG_N15"
      ],
      "nodeIds": [
        "control",
        "switch",
        "clamp"
      ],
      "edgeIds": [
        "switch_control",
        "switch_clamp"
      ],
      "id": "detail-power_2200_PROGRAM_NEGATIVE",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_2200_PROGRAM_NEGATIVE",
        "sheetName": "2200_PROGRAM_NEGATIVE",
        "board": "power",
        "netIds": [
          "power_net_cb68ff534fc3",
          "power_net_646f65822b1f",
          "power_net_55db14645113",
          "power_net_77d673a9c74f"
        ]
      }
    },
    {
      "sceneId": "power_2300_PROGRAM_INTERFACE",
      "title": "Питание программирования выходит через J2301",
      "lead": "Разъём связывает подготовленную силовую часть с её потребителем.",
      "body": [
        "На J2301 выведены PROG_P15, общий провод и PROG_N15. Это результат работы двух силовых ключей, а не прямое подключение исходных аналоговых шин.",
        "Рядом делитель и фильтрация готовят сигнал контроля положительной программирующей ветви. На этом шаге можно показать границу Power и внешней нагрузки. Точное соответствие контактов между платами нужно сверять по исходным разъёмам; функциональная стрелка сама по себе распиновку не задаёт."
      ],
      "why": "Граница между платами должна сохранять ясные имена питания и общего провода.",
      "path": [
        "Ключи P15 / N15",
        "PROG_P15 / PROG_N15",
        "J2301",
        "Нагрузка программирования"
      ],
      "nodeIds": [
        "connector",
        "monitor"
      ],
      "edgeIds": [
        "connector_monitor"
      ],
      "id": "detail-power_2300_PROGRAM_INTERFACE",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_2300_PROGRAM_INTERFACE",
        "sheetName": "2300_PROGRAM_INTERFACE",
        "board": "power",
        "netIds": [
          "power_net_7267dc19b659"
        ]
      }
    },
    {
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "title": "Отрицательные величины подготавливаются для измерения",
      "lead": "Отрицательная шина не может напрямую стать входом обычного положительного АЦП.",
      "body": [
        "U3401 преобразует сигналы отрицательной ветви AFE и её шунта в подходящие положительные измерительные сигналы. Одновременно готовится информация для аппаратной защиты по току.",
        "Ограничители D3401–D3403 защищают измерительные входы, а MON_V_N15 уходит в общую телеметрию. В результате силовой домен остаётся отрицательным, но система контроля получает представление о его состоянии в своём измерительном диапазоне."
      ],
      "why": "Перед оцифровкой сигнал должен соответствовать диапазону измерительного входа.",
      "path": [
        "N15 и шунт",
        "U3401",
        "Преобразование уровня",
        "MON_V_N15",
        "Телеметрия"
      ],
      "nodeIds": [
        "sense",
        "clamp"
      ],
      "edgeIds": [
        "sense_clamp"
      ],
      "id": "detail-power_3400_NEGATIVE_RAIL_MONITOR",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
        "sheetName": "3400_NEGATIVE_RAIL_MONITOR",
        "board": "power",
        "netIds": [
          "power_net_de6034a2bdb7",
          "power_net_28c7570b1cac"
        ]
      }
    },
    {
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "title": "Контроль начинается с входа и системных ветвей",
      "lead": "Вход, AON, USB и SYS наблюдаются раздельно.",
      "body": [
        "U3501–U3504 измеряют входную ветвь, дежурное питание, USB5 и SYS3V3. Такие точки позволяют увидеть, где именно возникла нагрузка: до основных преобразователей или в конкретном домене.",
        "Часть измерительных усилителей связана с общей аварийной цепью OC_OK_N. Поэтому информация о превышении тока может участвовать в аппаратном запрете, пока выбранные аналоговые измерения отдельно отправляются через мультиплексоры в контроллер."
      ],
      "why": "Общий ток входа и ток отдельного потребителя дают разную информацию.",
      "path": [
        "Вход / AON / USB / SYS",
        "U3501–U3504",
        "Измерения",
        "OC_OK_N"
      ],
      "nodeIds": [
        "aon",
        "usb",
        "system"
      ],
      "edgeIds": [
        "aon_usb",
        "usb_system"
      ],
      "id": "detail-power_3500_MONITOR_INPUT_AON_USB_SYS",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "sheetName": "3500_MONITOR_INPUT_AON_USB_SYS",
        "board": "power",
        "netIds": [
          "power_net_4aeb4892b398"
        ]
      }
    },
    {
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "title": "Промежуточные и аналоговые ветви тоже измеряются",
      "lead": "FPGA5V5, ANA6 и положительное AFE имеют свои точки наблюдения.",
      "body": [
        "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную аналоговую шину. Это позволяет рассматривать состояние источника до вторичных преобразователей и до аналоговой нагрузки.",
        "Аппаратные признаки участвуют в OC_OK_N, а аналоговые представления напряжений и токов идут в общий выбор телеметрии. Если расход энергии изменился, такой набор точек помогает локализовать ветвь, не полагаясь только на итоговый ток всего устройства."
      ],
      "why": "Измерение до и после преобразования помогает различать источник и нагрузку.",
      "path": [
        "FPGA5V5 / ANA6 / P15",
        "U3601–U3603",
        "Телеметрия",
        "OC_OK_N"
      ],
      "nodeIds": [
        "fpga",
        "analog",
        "positive"
      ],
      "edgeIds": [
        "fpga_analog",
        "analog_positive"
      ],
      "id": "detail-power_3600_MONITOR_FPGA_ANA_AFE",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
        "sheetName": "3600_MONITOR_FPGA_ANA_AFE",
        "board": "power",
        "netIds": [
          "power_net_4aeb4892b398"
        ]
      }
    },
    {
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "title": "Питания внутри цифровой части видны по отдельности",
      "lead": "Ядро, вспомогательные цепи и выводы ПЛИС имеют разные измерения.",
      "body": [
        "U3701–U3704 наблюдают CORE1V0, AUX1V8, AUX2V5 и IO3V3. Благодаря этому программа получает не одно общее «питание ПЛИС», а состояние конкретных электрических доменов.",
        "Их аппаратные признаки связаны с общей линией OC_OK_N. Выбор пары тока и напряжения для подробного чтения выполняется дальше. На этом шаге полезно сопоставить четыре источника из SECONDARY_POWER с четырьмя наблюдаемыми нагрузками."
      ],
      "why": "Раздельное питание должно сопровождаться раздельным наблюдением.",
      "path": [
        "CORE / AUX / IO",
        "U3701–U3704",
        "Измерения доменов",
        "OC_OK_N"
      ],
      "nodeIds": [
        "core",
        "aux18",
        "aux25",
        "io"
      ],
      "edgeIds": [
        "core_aux18",
        "core_aux25",
        "core_io"
      ],
      "id": "detail-power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "sheetName": "3700_MONITOR_FPGA_CORE_AUX_IO",
        "board": "power",
        "netIds": [
          "power_net_4aeb4892b398"
        ]
      }
    },
    {
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "title": "Остальные нагрузки завершают карту измерений",
      "lead": "Память, Ethernet PHY и малошумящие шины входят в тот же контур контроля.",
      "body": [
        "U3801–U3804 измеряют DDR1V35, PHY1V05, ANA5 и ANA3V3. Здесь объединены не сигналы данных этих подсистем, а сведения об их энергопотреблении и напряжении питания.",
        "Результаты направляются в телеметрию, а признаки перегрузки участвуют в OC_OK_N. Так измерение матрицы на Control и измерение её источников питания на Power остаются разными задачами: первое описывает эксперимент, второе — состояние аппаратуры."
      ],
      "why": "Результат эксперимента и состояние питания нужно интерпретировать отдельно.",
      "path": [
        "DDR / PHY / ANA5 / ANA3V3",
        "U3801–U3804",
        "Телеметрия",
        "Защита по току"
      ],
      "nodeIds": [
        "ddr",
        "ana5",
        "phy",
        "ana33"
      ],
      "edgeIds": [
        "ddr_ana5",
        "ddr_phy",
        "ddr_ana33"
      ],
      "id": "detail-power_3800_MONITOR_DDR_PHY_ANALOG",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "sheetName": "3800_MONITOR_DDR_PHY_ANALOG",
        "board": "power",
        "netIds": [
          "power_net_4aeb4892b398"
        ]
      }
    },
    {
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "title": "Контроллер выбирает согласованную пару измерений",
      "lead": "Два мультиплексора одновременно выбирают ток и напряжение одного домена.",
      "body": [
        "U3901 выбирает канал тока, а U3902 — соответствующий канал напряжения. Общие MUX_A0–MUX_A3 задают один из предусмотренных адресов; MUX_DISABLE управляет отключением выбора.",
        "Это экономит число входов АЦП, сохраняя возможность последовательно опросить домены питания. Важно показывать оба выбранных пути вместе: ток одной шины и напряжение другой дали бы неверную пару для интерпретации. После выбора сигналы ещё проходят буферизацию."
      ],
      "why": "Адрес измерения должен одинаково относиться к току и напряжению.",
      "path": [
        "Измерения 16 доменов",
        "MUX_A0–MUX_A3",
        "U3901 / U3902",
        "MUX_I_COM / MUX_V_COM"
      ],
      "nodeIds": [
        "current",
        "voltage"
      ],
      "edgeIds": [
        "current_voltage"
      ],
      "id": "detail-power_3900_TELEMETRY_MULTIPLEXERS",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
        "sheetName": "3900_TELEMETRY_MULTIPLEXERS",
        "board": "power",
        "netIds": [
          "power_net_b8fd52d3ecf7",
          "power_net_97db96dcc04b",
          "power_net_2074a83eb788",
          "power_net_7071622db9df",
          "power_net_b5187ab6f19a"
        ]
      }
    },
    {
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "title": "Перед входами АЦП стоят буферы",
      "lead": "Выбранные аналоговые измерения нужно передать контроллеру без лишней нагрузки на выборку.",
      "body": [
        "U4001 буферизует MUX_I_COM и MUX_V_COM после измерительных мультиплексоров. Затем предусмотренные выходные цепи ведут к ADC_I и ADC_V контроллера питания.",
        "Подтяжки и локальные фильтры определяют поведение связанных управляющих и измерительных узлов. Буфер не выбирает домен и не принимает решение об аварии: он подготавливает уже выбранный аналоговый сигнал к чтению. Само число появится в АЦП U2401."
      ],
      "why": "Источник измерения и вход АЦП не всегда стоит соединять напрямую.",
      "path": [
        "MUX_I_COM / MUX_V_COM",
        "U4001",
        "ADC_I / ADC_V",
        "АЦП U2401"
      ],
      "nodeIds": [
        "buffer",
        "default"
      ],
      "edgeIds": [
        "buffer_default"
      ],
      "id": "detail-power_4000_TELEMETRY_ADC_BUFFERS",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
        "sheetName": "4000_TELEMETRY_ADC_BUFFERS",
        "board": "power",
        "netIds": [
          "power_net_a13f4f0d6d68",
          "power_net_1980cbe8a6c0"
        ]
      }
    },
    {
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "title": "Аналоговые напряжения сравниваются с допустимыми уровнями",
      "lead": "Готовность можно получить аппаратным сравнением, а не только программным чтением АЦП.",
      "body": [
        "U2901 сравнивает подготовленные измерения USB, ANA6 и двухполярного AFE с порогами от AON. На выходе появляются сигналы PG_USB, PG_ANA, PG_P15 и PG_N15.",
        "Так схема формирует отдельные логические признаки состояния напряжений. Они дополняют непрерывную телеметрию: для последовательности запуска удобно иметь ответ «условие выполнено», а для диагностики — само измеренное значение. Далее признаки собираются в общую готовность."
      ],
      "why": "Измеренное число и аппаратный признак допустимого диапазона решают разные задачи.",
      "path": [
        "Напряжения шин",
        "Пороги от AON",
        "U2901",
        "PG_*"
      ],
      "nodeIds": [
        "threshold",
        "compare"
      ],
      "edgeIds": [
        "threshold_compare"
      ],
      "id": "detail-power_2900_PM_ANALOG_POWER_GOOD",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_2900_PM_ANALOG_POWER_GOOD",
        "sheetName": "2900_PM_ANALOG_POWER_GOOD",
        "board": "power",
        "netIds": [
          "power_net_ae3b1a85f32f",
          "power_net_e46274585def",
          "power_net_61199f10a0d6",
          "power_net_0c8e0f29b47d",
          "power_net_d3607cfa6b03",
          "power_net_de65996f492f",
          "power_net_9ec66895516f",
          "power_net_6a587efc79ba"
        ]
      }
    },
    {
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "title": "Отрицательная ветвь имеет независимую проверку тока",
      "lead": "Подготовленный сигнал тока сравнивается с аппаратным порогом.",
      "body": [
        "U3201 получает OC_I_N15 и сравнивает его с порогом, сформированным от AON. Результат связан с общей цепью OC_OK_N, участвующей в аппаратной безопасности питания.",
        "Этот путь дополняет обычный опрос напряжения и тока через мультиплексоры. Для реакции на нарушение не нужно сначала выбирать нужный канал АЦП и ждать, пока программа его обработает. Конкретные пороги и время реакции определяются реальной схемой, а не условной скоростью анимации."
      ],
      "why": "Аварийный признак должен иметь путь, независимый от циклического опроса.",
      "path": [
        "Ток N15",
        "OC_I_N15",
        "U3201",
        "OC_OK_N",
        "Блокировка"
      ],
      "nodeIds": [
        "threshold",
        "compare"
      ],
      "edgeIds": [
        "threshold_compare"
      ],
      "id": "detail-power_3200_PM_NEGATIVE_OVERCURRENT",
      "chapterId": "power-domains",
      "kind": "detail",
      "source": {
        "sheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "sheetName": "3200_PM_NEGATIVE_OVERCURRENT",
        "board": "power",
        "netIds": [
          "power_net_4aeb4892b398",
          "power_net_cfd922d13086"
        ]
      }
    },
    {
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "title": "Power сообщает основному контроллеру своё состояние",
      "lead": "UART, watchdog и разрешения пересекают границу управляющих доменов.",
      "body": [
        "J3301 предоставляет SWD для обслуживания контроллера питания. J3302 предназначен для связи с основным контроллером, а U3301 участвует в передаче сигналов в его домен.",
        "Через этот интерфейс предусмотрены UART, сторожевой контроль и признаки ALL_RAILS_PG_HOST, GLOBAL_PWR_PERMIT_HOST и MATRIX_PERMIT_HOST. Так основной контроллер получает не только энергию, но и информацию о том, можно ли начинать эксперимент. Конкретный обмен сообщениями должен выполнять соответствующий программный протокол."
      ],
      "why": "Управляющие платы обмениваются состояниями отдельно от силового питания.",
      "path": [
        "U2401",
        "UART / watchdog / разрешения",
        "J3302 и U3301",
        "Основной MCU"
      ],
      "nodeIds": [
        "debug",
        "host",
        "isolate"
      ],
      "edgeIds": [
        "debug_host",
        "host_isolate"
      ],
      "id": "detail-power_3300_PM_DEBUG_HOST_INTERFACE",
      "chapterId": "power-control",
      "kind": "detail",
      "source": {
        "sheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "sheetName": "3300_PM_DEBUG_HOST_INTERFACE",
        "board": "power",
        "netIds": [
          "power_net_ccf5ee78cf75",
          "power_net_9426b571f348",
          "power_net_89bfaea42e83",
          "power_net_be4d01cedfad",
          "power_net_65bf7e1e53cf"
        ]
      }
    },
    {
      "sceneId": "control-boundary",
      "title": "Граница двух плат: питание вместе с разрешениями",
      "lead": "Связь с Power переносит не только напряжения: Control также узнаёт, можно ли уже начинать работу.",
      "body": [
        "В разделе INTERCONNECT находится лист 400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE. Его разъём J400 принимает питания и сигналы контроля. Поэтому соединение плат следует рассматривать как согласованный интерфейс: наличие напряжения само по себе ещё не означает готовность к воздействию на матрицу.",
        "Приёмники U400 и U401 передают состояния в нужные домены платы Control. Дальше MCU получает сведения о готовности питания, а матричный тракт — отдельное разрешение MATRIX_PERMIT. Такой порядок помогает удерживать исполнительные цепи выключенными, пока питание и контроль не готовы."
      ],
      "why": "Разрешение работы должно приходить из проверенного состояния питания, а не возникать случайно при включении.",
      "path": [
        "Power",
        "J400",
        "Приёмники состояний",
        "MCU / MATRIX"
      ],
      "nodeIds": [
        "sheet400"
      ],
      "edgeIds": [],
      "id": "detail-control-boundary",
      "chapterId": "bootstrap",
      "kind": "detail",
      "source": {
        "sheetId": "control_INTERCONNECT",
        "sheetName": "INTERCONNECT",
        "board": "control",
        "netIds": []
      }
    },
    {
      "sceneId": "control-host",
      "title": "MCU: координация, рабочая память и хранение",
      "lead": "Контроллер объединяет настройку опыта, состояние системы и данные, которым не требуется наносекундное расписание.",
      "body": [
        "Раздел MCU объединяет три задачи. На листе 100 показаны питание, тактирование, сброс и отладка STM32H745 U100. Лист 200 добавляет оперативную память SDRAM U200, а лист 300 — постоянную QSPI-память и съёмную microSD.",
        "Эта группа может хранить параметры эксперимента, готовить задания ПЛИС и обрабатывать состояния питания. Какие именно вычисления выполняются на STM32, определяет прошивка. Аппаратная схема предоставляет процессор, память и линии обмена, но сама по себе ещё не реализует модель нейронов или алгоритм обучения."
      ],
      "why": "Объёмные задачи управления удобно отделить от точного времени переключения матрицы.",
      "path": [
        "Запуск U100",
        "Рабочая SDRAM",
        "Постоянные данные",
        "Задания FPGA"
      ],
      "nodeIds": [
        "sheet100",
        "sheet200",
        "sheet300"
      ],
      "edgeIds": [],
      "id": "detail-control-host",
      "chapterId": "bootstrap",
      "kind": "detail",
      "source": {
        "sheetId": "control_MCU",
        "sheetName": "MCU",
        "board": "control",
        "netIds": []
      }
    },
    {
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "title": "Где MCU держит рабочие данные",
      "lead": "Внешняя SDRAM увеличивает объём памяти для текущего состояния и буферов контроллера.",
      "body": [
        "U100 обращается к U200 по интерфейсу FMC. Адреса, команды и тактирование проходят через группу последовательных резисторов; 16 линий FMC_D0–FMC_D15 образуют шину данных. U200 — SDRAM объёмом 64 MiB, поэтому она подходит для рабочего состояния, которое должно быстро читаться и изменяться.",
        "Резисторы в сигнальных линиях помогают управлять переходными процессами, а локальные конденсаторы поддерживают питание памяти SYS3V3. Эта память энергозависима: после выключения её содержимое не сохраняется. Если данные нужны в следующем запуске, программная часть должна перенести их в постоянный накопитель."
      ],
      "why": "Оперативная память решает задачу объёма и скорости, но не заменяет постоянное хранение.",
      "path": [
        "U100",
        "FMC: адреса и команды",
        "FMC_D0–FMC_D15",
        "SDRAM U200"
      ],
      "nodeIds": [
        "host",
        "bus",
        "memory"
      ],
      "edgeIds": [
        "host_bus_0",
        "bus_memory_1",
        "host_memory_2"
      ],
      "id": "detail-control_200_MCU_FMC_AND_SDRAM",
      "chapterId": "bootstrap",
      "kind": "detail",
      "source": {
        "sheetId": "control_200_MCU_FMC_AND_SDRAM",
        "sheetName": "200_MCU_FMC_AND_SDRAM",
        "board": "control",
        "netIds": [
          "control_net_bf2f5ebca199",
          "control_net_f87a72a8ece7",
          "control_net_57814f35c37d",
          "control_net_88e82b098d8a",
          "control_net_576d489f596c",
          "control_net_64e3b30cda92",
          "control_net_5a1408d6925c",
          "control_net_e03d15dc4157",
          "control_net_478ea3ad984d",
          "control_net_51ade1c12a34",
          "control_net_497868960a10",
          "control_net_cf0d706ad175",
          "control_net_df9972435b68",
          "control_net_57fd38ae982f",
          "control_net_3a8f32a74ef2",
          "control_net_8726d2dae752",
          "control_net_66b853d97583",
          "control_net_1828c29d5fa6",
          "control_net_25457d3dd391",
          "control_net_cb5d34db7f7a",
          "control_net_802aa4569b27",
          "control_net_3974126e88cb",
          "control_net_f2ad5b3a1b23",
          "control_net_1fb2e0bffca2",
          "control_net_b56b3c253467",
          "control_net_812a5aa5142f",
          "control_net_ea2e71d8ad65",
          "control_net_29b779eba1df",
          "control_net_a3f957371c3f",
          "control_net_22d2ed5a92b0",
          "control_net_e61f684e2b30",
          "control_net_50fec45c4cfe",
          "control_net_8e2c742867a9",
          "control_net_0d875c33a31d",
          "control_net_a7ff225fafcc",
          "control_net_7fb3e667afc3",
          "control_net_88a82b0ea167",
          "control_net_6a7ba2287274",
          "control_net_1ab10b21ce8a",
          "control_net_ac77da14ad01",
          "control_net_c768cd02e6fd",
          "control_net_9cec32a3a290",
          "control_net_50162c30e639",
          "control_net_bf332d53cb7b",
          "control_net_5ff18f95d1df",
          "control_net_ba4358c26b16",
          "control_net_30b951256d65",
          "control_net_05f1cce27675",
          "control_net_dbb7c66b055c",
          "control_net_71220214496a",
          "control_net_e8c9dc419d80",
          "control_net_c3d2e7b446eb",
          "control_net_3f3c225eebe4",
          "control_net_4fca7f1d1465",
          "control_net_1643db7ef9f9",
          "control_net_a3813a077889",
          "control_net_cfc4efe0cd4a",
          "control_net_4ddbefaae88b",
          "control_net_c16e9f400334",
          "control_net_98b1a2522dce",
          "control_net_5c8668fc4b07",
          "control_net_a0420c81d318"
        ]
      }
    },
    {
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "title": "Что остаётся после выключения",
      "lead": "Постоянная QSPI-память и microSD обслуживают другой жизненный цикл данных, чем SDRAM.",
      "body": [
        "U300 — QSPI NOR Flash, связанная с MCU цепями MCU_QSPI_CLK и линиями ввода-вывода. Разъём J300 подключает microSD через MCU_SD_CLK, MCU_SD_CMD и MCU_SD_D0–MCU_SD_D3; отдельная цепь MCU_SD_CD_N сообщает о наличии карты.",
        "На карте или во Flash программная часть может хранить параметры, образы и журналы экспериментов. Что именно записывается и как защищаются файлы при выключении, задаётся прошивкой. Защита U301–U303 относится к внешним сигналам microSD: доступный пользователю разъём нуждается в защите от разрядов, которых нет внутри обычной межмикросхемной связи."
      ],
      "why": "Рабочие данные, постоянные настройки и съёмные файлы лучше показывать как разные функции.",
      "path": [
        "MCU",
        "QSPI U300",
        "microSD J300",
        "Сохранение данных"
      ],
      "nodeIds": [
        "host",
        "flash",
        "card"
      ],
      "edgeIds": [
        "host_flash",
        "host_card"
      ],
      "id": "detail-control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "chapterId": "bootstrap",
      "kind": "detail",
      "source": {
        "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "sheetName": "300_MCU_QSPI_MICROSD_AND_CONTROL",
        "board": "control",
        "netIds": [
          "control_net_1ae330a90d69",
          "control_net_dbb8a4cebc4d",
          "control_net_a6d0f4299492",
          "control_net_0afe468f72ab",
          "control_net_c17cd2b70efc",
          "control_net_bfc714f087e0",
          "control_net_94be9f57dcd4",
          "control_net_adae77af0ed0",
          "control_net_3792d8c5e55e",
          "control_net_24c9b5fda4e5",
          "control_net_0a220a15306e",
          "control_net_119d91accf55",
          "control_net_7f80f60475c4"
        ]
      }
    },
    {
      "sceneId": "control-fpga",
      "title": "FPGA: точное время и быстрые потоки",
      "lead": "Вокруг ПЛИС собраны её питание, загрузка, память и два внешних пути обмена с компьютером.",
      "body": [
        "Раздел FPGA раскрывает пять связанных областей: питание U500, загрузку конфигурации, USB, внешнюю DDR3L и Ethernet. ПЛИС не начинает работать как готовый процессор сразу после подачи питания: сначала её программируемая логика должна получить конфигурацию.",
        "После загрузки проект ПЛИС может объединить приём команд, расписание матричной операции и приём данных АЦП. USB и Ethernet предоставляют физические интерфейсы; обработку кадров, пакетов и команд нужно реализовать в логике или программной части проекта. DDR3L может служить буфером между измерением и передачей наружу."
      ],
      "why": "Быстрое измерение и медленный либо неравномерный обмен с компьютером удобно разделить буфером.",
      "path": [
        "Питание U500",
        "Загрузка конфигурации",
        "USB / Ethernet",
        "DDR3L",
        "Матричный тракт"
      ],
      "nodeIds": [
        "sheet500",
        "sheet600",
        "sheet700",
        "sheet800",
        "sheet900"
      ],
      "edgeIds": [
        "sheet600_sheet700",
        "sheet600_sheet900",
        "sheet700_sheet900"
      ],
      "id": "detail-control-fpga",
      "chapterId": "bootstrap",
      "kind": "detail",
      "source": {
        "sheetId": "control_FPGA",
        "sheetName": "FPGA",
        "board": "control",
        "netIds": [
          "control_net_3591ba357658",
          "control_net_834296c71f70",
          "control_net_52c8c7557923",
          "control_net_92af7290af48",
          "control_net_9e71347ab99c",
          "control_net_3d9d791e8355",
          "control_net_75501c77d10a",
          "control_net_352fe6713403"
        ]
      }
    },
    {
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "title": "Почему у FPGA несколько питаний",
      "lead": "Ядро логики и внешние банки ПЛИС потребляют разные напряжения и создают разные импульсные нагрузки.",
      "body": [
        "На этом листе U500 показана через её питающие домены. CORE1V0 относится к внутреннему ядру; AUX1V8, IO3V3 и DDR1V35 обслуживают вспомогательные цепи и соответствующие интерфейсы. Их нельзя заменить одним общим напряжением только потому, что они питают одну микросхему.",
        "Группы конденсаторов стоят рядом с нужными доменами и поддерживают быстрые изменения тока на выводах питания. На диаграмме это вспомогательная часть основной ПЛИС: она не переносит полезные данные, но позволяет логике и входам-выходам работать в своих электрических режимах. Последовательность готовности этих шин относится к системе Power."
      ],
      "why": "Быстрая цифровая логика требует как правильного уровня напряжения, так и локального запаса заряда.",
      "path": [
        "CORE1V0",
        "AUX1V8 / IO3V3",
        "Конденсаторы",
        "U500"
      ],
      "nodeIds": [
        "core",
        "reservoir",
        "aux"
      ],
      "edgeIds": [
        "reservoir_core_0",
        "aux_core_1"
      ],
      "id": "detail-control_500_FPGA_POWER_AND_DECOUPLING",
      "chapterId": "bootstrap",
      "kind": "detail",
      "source": {
        "sheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
        "sheetName": "500_FPGA_POWER_AND_DECOUPLING",
        "board": "control",
        "netIds": [
          "control_net_4bfa9adb9035",
          "control_net_6f005443ad9c",
          "control_net_fc6dfc0c018d",
          "control_net_a0d28f360159"
        ]
      }
    },
    {
      "sceneId": "control-sources",
      "title": "От цифрового числа к аналоговой уставке",
      "lead": "Раздел DAC формирует напряжения, с которыми дальше работает коммутация и источник записи.",
      "body": [
        "ПЛИС передаёт значения по последовательному интерфейсу на листе 1200. Четыре многоканальных ЦАП на листе 1000 создают 32 независимые уставки битовых линий. Лист 1100 отдельно формирует сервисные напряжения и ограничения, включая READ, SET, RESET и FORMING.",
        "Эти выходы ещё не означают, что напряжение уже подано на нужную ячейку. MATRIX выбирает соединение, а тракт PROTECTION регулирует источник записи и контролирует его ток. Поэтому на показе полезно сначала установить уставку, затем раскрыть коммутацию и только после этого говорить о воздействии на матрицу."
      ],
      "why": "Создание напряжения, выбор адреса и разрешение воздействия — три разные операции.",
      "path": [
        "Числовые уставки",
        "DAC_SPI_*",
        "ЦАП и буферы",
        "MATRIX / PROTECTION"
      ],
      "nodeIds": [
        "sheet1000",
        "sheet1100",
        "sheet1200"
      ],
      "edgeIds": [
        "sheet1000_sheet1200",
        "sheet1100_sheet1200",
        "sheet1000_sheet1100"
      ],
      "id": "detail-control-sources",
      "chapterId": "setpoints",
      "kind": "detail",
      "source": {
        "sheetId": "control_DAC",
        "sheetName": "DAC",
        "board": "control",
        "netIds": [
          "control_net_90accaec6322",
          "control_net_8543c7028353",
          "control_net_7f616706cf93",
          "control_net_fd8710ab620d",
          "control_net_a2017f4fe37b",
          "control_net_bae01a82acc2",
          "control_net_2889fbee2814",
          "control_net_8baeadc9d1f8",
          "control_net_0d0a126b05bc",
          "control_net_596ada6680f2",
          "control_net_fe5724fe2bab",
          "control_net_168076ddc771",
          "control_net_fad82bf41bcf"
        ]
      }
    },
    {
      "sceneId": "control-routing",
      "title": "MATRIX: сначала конфигурация, затем воздействие",
      "lead": "Матрица получает не произвольные напряжения, а заранее выбранную и разрешённую комбинацию соединений.",
      "body": [
        "Раздел MATRIX объединяет проверку запроса, 80-битный образ ключей, коммутацию BL, выбор сервисного источника, драйверы WL и выбор NL. Эти функции вместе определяют, куда подаётся воздействие и откуда забирается измеряемый ток.",
        "Сначала управление загружает и фиксирует состояние, затем аппаратные условия разрешают выбранный режим. Входы защиты могут снять разрешение. Такой порядок нужен потому, что изменение адреса или полярности во время активного импульса создаёт уже другой эксперимент; аппаратная логика должна отличать подготовку соединений от выполнения операции."
      ],
      "why": "Безопасность здесь связана не только с величиной напряжения, но и с согласованностью соединений во времени.",
      "path": [
        "Запрос",
        "Фиксация образа",
        "Коммутация BL / WL / NL",
        "Разрешение",
        "Матрица"
      ],
      "nodeIds": [
        "sheet1300",
        "sheet1400",
        "sheet1500",
        "sheet1600",
        "sheet1700",
        "sheet1800"
      ],
      "edgeIds": [
        "sheet1400_sheet1500",
        "sheet1500_sheet1800",
        "sheet1400_sheet1700",
        "sheet1700_sheet1800",
        "sheet1300_sheet1600",
        "sheet1300_sheet1400",
        "sheet1300_sheet1700",
        "sheet1500_sheet1600",
        "sheet1300_sheet1500",
        "sheet1600_sheet1700",
        "sheet1500_sheet1700"
      ],
      "id": "detail-control-routing",
      "chapterId": "matrix-route",
      "kind": "detail",
      "source": {
        "sheetId": "control_MATRIX",
        "sheetName": "MATRIX",
        "board": "control",
        "netIds": [
          "control_net_57236d4b4e50",
          "control_net_70c03a238d66",
          "control_net_7e66df34c1cb",
          "control_net_e2ace5299f00",
          "control_net_f498b034d47c",
          "control_net_dfebfa8ce954",
          "control_net_8cec06d0a68e",
          "control_net_91367f0adb00",
          "control_net_4e889b41bce9",
          "control_net_4f58db14a2f0",
          "control_net_8ae298951006",
          "control_net_c7a227845fc4",
          "control_net_aa8081055225",
          "control_net_38aa1b871436",
          "control_net_30da3c89e6b0",
          "control_net_27e11deab85a",
          "control_net_77dec07465d1",
          "control_net_76168421ae64",
          "control_net_01c0ad0ef8f8",
          "control_net_5e01c47f5c29",
          "control_net_35c00105d395",
          "control_net_48fcc210d1f6",
          "control_net_31367ce75c40",
          "control_net_282ba042f616",
          "control_net_acd932993b7b",
          "control_net_2f56e21bf1c8",
          "control_net_e9062516eb43",
          "control_net_d24d5fdebd2d",
          "control_net_e542c28a3215",
          "control_net_c20b4b863473",
          "control_net_adcb6c1bfe2e",
          "control_net_2595b3f207c1",
          "control_net_3e8175ead30c",
          "control_net_699b10c0cb1f",
          "control_net_928a45524bd4",
          "control_net_51b3012894bb",
          "control_net_853be9b7ad24",
          "control_net_48cbd08d5e88",
          "control_net_5e93332cd041",
          "control_net_45c19501bad5",
          "control_net_db3c5d849c82",
          "control_net_37fa60099550",
          "control_net_b211580c8101",
          "control_net_4aefa7bda0e0",
          "control_net_2bbd0dc06c6f",
          "control_net_c8a58330532e",
          "control_net_24fd3915e934",
          "control_net_a3db8189ec60",
          "control_net_287cfdf7ef3f",
          "control_net_ac7e9e00c8b3",
          "control_net_42dd32d2dba8",
          "control_net_ad6ab5928142",
          "control_net_cc7e68c63366",
          "control_net_c771f664cff1",
          "control_net_d948d4dd3369",
          "control_net_fbc93a9a1f13",
          "control_net_bb256500c151",
          "control_net_724ff3a3348c",
          "control_net_323da0f3bc1f",
          "control_net_39c83bb6d20e",
          "control_net_dcf3a56694f7",
          "control_net_a275f9d9677f",
          "control_net_aad969376bf0",
          "control_net_e85cee5f43f2",
          "control_net_410ce51ce77b",
          "control_net_5b7588c91934",
          "control_net_96843655892a",
          "control_net_ef57e67af6ee",
          "control_net_a38212b18dab",
          "control_net_cb9a53bc7e2d",
          "control_net_b1a7be433721",
          "control_net_5a6f03bbf06c",
          "control_net_f237bfeb4d31",
          "control_net_7deb95e626ac",
          "control_net_dee259c78870",
          "control_net_30db039e0318",
          "control_net_538bdbb480c1",
          "control_net_9aa6ed5fa484",
          "control_net_af268a134ce7",
          "control_net_2661b7e1d1d8",
          "control_net_7443657d6bc7",
          "control_net_8c1f7a16a91f",
          "control_net_9037a6d55684",
          "control_net_e59cadbe90ef",
          "control_net_77eb74275447",
          "control_net_331bcbe5832b",
          "control_net_da64d12ab5ef",
          "control_net_668f023fd21c",
          "control_net_15a5f03664b6",
          "control_net_0066c578f4fd",
          "control_net_ae5aa8c25d68",
          "control_net_76481426c5c9",
          "control_net_36b8e2744fa2",
          "control_net_06c41da37048",
          "control_net_093450c5090e",
          "control_net_a3c1624fed4f",
          "control_net_6597f27cfc2b",
          "control_net_52153a3ca99d",
          "control_net_45ab5f0aea68",
          "control_net_09be2b97e593",
          "control_net_1f62e25a43f4",
          "control_net_6cd7e17461df",
          "control_net_582519679d90",
          "control_net_03726fa80526",
          "control_net_18924996523a",
          "control_net_86b7951f0b9b",
          "control_net_6f8884418f43",
          "control_net_be1982fe6067",
          "control_net_b2b91481bc2e",
          "control_net_a335d291d1da",
          "control_net_df58d9efe6ea",
          "control_net_c04b6da19edd",
          "control_net_c494e5a21fb7",
          "control_net_5ef23046b636",
          "control_net_747cc492238d",
          "control_net_945cddbc767f",
          "control_net_3762f1a58fed",
          "control_net_b0ea7c0c27c3",
          "control_net_edac321adbf1",
          "control_net_5212ff00c1ac",
          "control_net_3c196a06fe86",
          "control_net_d380ae123eb3",
          "control_net_79947d226d73",
          "control_net_fca0e6b6f6af",
          "control_net_e8ccb5161adb",
          "control_net_072af1a28ea6",
          "control_net_e4379a2b0f61",
          "control_net_919f25939ba9",
          "control_net_53c8d7c2e621",
          "control_net_69c914a4b819",
          "control_net_209d9624cc4d",
          "control_net_24511a425a2f",
          "control_net_3f65bb4e6c1b",
          "control_net_1548c2f283f9",
          "control_net_17e2493797cd",
          "control_net_5a48e06ad240",
          "control_net_c3b957dc2a05",
          "control_net_d0ee9c0888fb",
          "control_net_c73ef0628409",
          "control_net_2e40141f478d",
          "control_net_f05b5740e1a9",
          "control_net_770516324e4c",
          "control_net_671137df6d42",
          "control_net_0831bf7686e1",
          "control_net_3f3c0536dd7c",
          "control_net_12757af1d119",
          "control_net_7a2e58dd0886",
          "control_net_558e432b5f50",
          "control_net_e35a26b2e235",
          "control_net_c3af5f92c044",
          "control_net_435ce00e5df8",
          "control_net_42857bff9d0c",
          "control_net_5adbbaca70af",
          "control_net_11d0bca5a9c3",
          "control_net_5d5a8a88fb46",
          "control_net_93f6dc0512af"
        ]
      }
    },
    {
      "sceneId": "control_PROTECTION",
      "title": "Два уровня защиты матрицы",
      "lead": "Регулирование удерживает воздействие в заданных пределах, а аварийный узел может полностью остановить операцию.",
      "body": [
        "Лист 2100 формирует регулируемый источник записи: выбирает уставки напряжения и тока, измеряет ток и воздействует на выходной драйвер. Это рабочая обратная связь, которая действует во время штатной операции.",
        "Лист 2200 отдельно сравнивает контрольные сигналы, объединяет причины отключения и фиксирует аварию. Так ограничение и аварийная остановка не смешиваются в один программный флаг. Фиксация нужна, чтобы причина не исчезла бесследно сразу после снятия воздействия; возврат к работе должен быть осознанной частью последовательности управления."
      ],
      "why": "Ограничение тока и аппаратное отключение решают разные задачи и дополняют друг друга.",
      "path": [
        "Уставки",
        "Регулятор 2100",
        "Контроль тока",
        "Авария 2200",
        "Запрет"
      ],
      "nodeIds": [
        "sheet2100",
        "sheet2200"
      ],
      "edgeIds": [
        "sheet2100_sheet2200"
      ],
      "id": "detail-control_PROTECTION",
      "chapterId": "write-safety",
      "kind": "detail",
      "source": {
        "sheetId": "control_PROTECTION",
        "sheetName": "PROTECTION",
        "board": "control",
        "netIds": [
          "control_net_7eb34b3468da"
        ]
      }
    },
    {
      "sceneId": "control-readout",
      "title": "Обратный путь: от тока матрицы к числу",
      "lead": "Результат эксперимента начинается как электрический отклик, который нужно подготовить для АЦП.",
      "body": [
        "Раздел ADC объединяет лист 1900 с преобразованием тока в напряжение и выбором контролируемого сигнала, а также лист 2000 с точными опорными уровнями, входным драйвером и АЦП. Между листами выбранный сигнал передаётся по MAT_MONITOR_RAW.",
        "Такая последовательность нужна потому, что АЦП измеряет напряжение в определённых пределах, а матрица отдаёт ток. Усиление, диапазон, смещение и опора определяют, какое физическое значение будет соответствовать полученному числу. После преобразования цифровые отсчёты возвращаются в FPGA и могут быть буферизованы для передачи на компьютер."
      ],
      "why": "Число АЦП становится результатом измерения только вместе с известным диапазоном и калибровкой тракта.",
      "path": [
        "Ток матрицы",
        "TIA и выбор сигнала",
        "MAT_MONITOR_RAW",
        "АЦП",
        "FPGA"
      ],
      "nodeIds": [
        "sheet1900",
        "sheet2000"
      ],
      "edgeIds": [
        "sheet1900_sheet2000"
      ],
      "id": "detail-control-readout",
      "chapterId": "readout",
      "kind": "detail",
      "source": {
        "sheetId": "control_ADC",
        "sheetName": "ADC",
        "board": "control",
        "netIds": [
          "control_net_a2221a9e6733"
        ]
      }
    }
  ],
  "controls": "Шаги и главы переключаются только вручную. Анимация показывает условный сигнал на выбранном пути.",
  "hardwarePolicy": "Схемы показывают аппаратные соединения. MAC, протоколы связи, алгоритмы MCU и формат команд должны быть реализованы в проекте ПЛИС и прошивке; анимация не подтверждает их готовность."
};
