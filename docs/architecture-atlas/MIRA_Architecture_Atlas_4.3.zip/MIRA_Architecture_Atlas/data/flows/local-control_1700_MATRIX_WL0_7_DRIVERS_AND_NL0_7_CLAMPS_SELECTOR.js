/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "title": "Как работает: Выбор строк и измерительных линий",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "steps": [
    {
      "title": "Выбираются WL",
      "text": "Ключи word-line соединяют выбранное состояние управления с восемью линиями WL. Номера цепей соответствуют контактам матрицы.",
      "body": "Ключи word-line соединяют выбранное состояние управления с восемью линиями WL. Номера цепей соответствуют контактам матрицы.",
      "nodes": [
        "word",
        "permit"
      ],
      "edges": [],
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "netIds": [
        "control_net_b2b91481bc2e",
        "control_net_82b64e8aa612",
        "control_net_945cddbc767f",
        "control_net_03726fa80526",
        "control_net_edac321adbf1",
        "control_net_3c196a06fe86",
        "control_net_1f62e25a43f4",
        "control_net_e5381212c338",
        "control_net_17238824eeb6",
        "control_net_2e82cb98585d",
        "control_net_c494e5a21fb7",
        "control_net_6f8884418f43",
        "control_net_5ef23046b636",
        "control_net_52153a3ca99d",
        "control_net_18924996523a",
        "control_net_209d9624cc4d",
        "control_net_3f3c0536dd7c",
        "control_net_fdc5577f6544",
        "control_net_6f005443ad9c",
        "control_net_fca0e6b6f6af",
        "control_net_6597f27cfc2b",
        "control_net_a7cc6914d74e",
        "control_net_45ab5f0aea68",
        "control_net_b0ea7c0c27c3",
        "control_net_747cc492238d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1700",
          "pin": "11",
          "netId": "control_net_b2b91481bc2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1704",
          "pin": "1",
          "netId": "control_net_b2b91481bc2e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "12",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "9",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "2",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "12",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "2",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "19",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "19",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "9",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "13",
          "netId": "control_net_945cddbc767f",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1705",
          "pin": "1",
          "netId": "control_net_945cddbc767f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "1",
          "netId": "control_net_03726fa80526",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1700",
          "pin": "1",
          "netId": "control_net_03726fa80526",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "3",
          "netId": "control_net_edac321adbf1",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1701",
          "pin": "1",
          "netId": "control_net_edac321adbf1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1707",
          "pin": "1",
          "netId": "control_net_3c196a06fe86",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "18",
          "netId": "control_net_3c196a06fe86",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "20",
          "netId": "control_net_1f62e25a43f4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1706",
          "pin": "1",
          "netId": "control_net_1f62e25a43f4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1701",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1707",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "15",
          "netId": "control_net_17238824eeb6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1700",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "16",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "16",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1703",
          "pin": "1",
          "netId": "control_net_c494e5a21fb7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "8",
          "netId": "control_net_c494e5a21fb7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1702",
          "pin": "1",
          "netId": "control_net_6f8884418f43",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "10",
          "netId": "control_net_6f8884418f43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1713",
          "pin": "1",
          "netId": "control_net_5ef23046b636",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "13",
          "netId": "control_net_5ef23046b636",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "20",
          "netId": "control_net_52153a3ca99d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1714",
          "pin": "1",
          "netId": "control_net_52153a3ca99d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1708",
          "pin": "1",
          "netId": "control_net_18924996523a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "1",
          "netId": "control_net_18924996523a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "2",
          "netId": "control_net_3f3c0536dd7c",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1732",
          "pin": "1",
          "netId": "control_net_fdc5577f6544",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "4",
          "netId": "control_net_fdc5577f6544",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1709",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "8",
          "netId": "control_net_fca0e6b6f6af",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1711",
          "pin": "1",
          "netId": "control_net_fca0e6b6f6af",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "10",
          "netId": "control_net_6597f27cfc2b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1710",
          "pin": "1",
          "netId": "control_net_6597f27cfc2b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "15",
          "netId": "control_net_a7cc6914d74e",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "11",
          "netId": "control_net_45ab5f0aea68",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1712",
          "pin": "1",
          "netId": "control_net_45ab5f0aea68",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "3",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1709",
          "pin": "1",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "18",
          "netId": "control_net_747cc492238d",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1715",
          "pin": "1",
          "netId": "control_net_747cc492238d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Неактивные NL получают заданное состояние",
      "text": "Ключи ограничения определяют состояние невыбранных нейронных линий. Это отдельная функция от выбора измеряемого канала.",
      "body": "Ключи ограничения определяют состояние невыбранных нейронных линий. Это отдельная функция от выбора измеряемого канала.",
      "nodes": [
        "clamp",
        "permit"
      ],
      "edges": [],
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "netIds": [
        "control_net_e4379a2b0f61",
        "control_net_df58d9efe6ea",
        "control_net_6cd7e17461df",
        "control_net_072af1a28ea6",
        "control_net_209d9624cc4d",
        "control_net_3f3c0536dd7c",
        "control_net_fdc5577f6544",
        "control_net_6f005443ad9c",
        "control_net_d380ae123eb3",
        "control_net_86b7951f0b9b",
        "control_net_919f25939ba9",
        "control_net_5212ff00c1ac",
        "control_net_c04b6da19edd",
        "control_net_e8ccb5161adb",
        "control_net_a335d291d1da",
        "control_net_e5381212c338",
        "control_net_0c44846c1393",
        "control_net_2e82cb98585d",
        "control_net_79947d226d73",
        "control_net_3762f1a58fed",
        "control_net_09be2b97e593",
        "control_net_be1982fe6067",
        "control_net_582519679d90",
        "control_net_7f9326fe10ba"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1719",
          "pin": "1",
          "netId": "control_net_e4379a2b0f61",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "15",
          "netId": "control_net_e4379a2b0f61",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1720",
          "pin": "1",
          "netId": "control_net_df58d9efe6ea",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "9",
          "netId": "control_net_df58d9efe6ea",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1724",
          "pin": "1",
          "netId": "control_net_6cd7e17461df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "1",
          "netId": "control_net_6cd7e17461df",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1729",
          "pin": "1",
          "netId": "control_net_072af1a28ea6",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "10",
          "netId": "control_net_072af1a28ea6",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "2",
          "netId": "control_net_3f3c0536dd7c",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1732",
          "pin": "1",
          "netId": "control_net_fdc5577f6544",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "4",
          "netId": "control_net_fdc5577f6544",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1709",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "7",
          "netId": "control_net_d380ae123eb3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1723",
          "pin": "1",
          "netId": "control_net_d380ae123eb3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1728",
          "pin": "1",
          "netId": "control_net_86b7951f0b9b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "9",
          "netId": "control_net_86b7951f0b9b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "2",
          "netId": "control_net_919f25939ba9",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1725",
          "pin": "1",
          "netId": "control_net_919f25939ba9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "7",
          "netId": "control_net_5212ff00c1ac",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1731",
          "pin": "1",
          "netId": "control_net_5212ff00c1ac",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "8",
          "netId": "control_net_c04b6da19edd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1730",
          "pin": "1",
          "netId": "control_net_c04b6da19edd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1727",
          "pin": "1",
          "netId": "control_net_e8ccb5161adb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "15",
          "netId": "control_net_e8ccb5161adb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "16",
          "netId": "control_net_a335d291d1da",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1726",
          "pin": "1",
          "netId": "control_net_a335d291d1da",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1707",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "12",
          "netId": "control_net_0c44846c1393",
          "name": "NIC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1717",
          "pin": "2",
          "netId": "control_net_79947d226d73",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "2",
          "netId": "control_net_79947d226d73",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1721",
          "pin": "1",
          "netId": "control_net_3762f1a58fed",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "10",
          "netId": "control_net_3762f1a58fed",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "16",
          "netId": "control_net_09be2b97e593",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1718",
          "pin": "1",
          "netId": "control_net_09be2b97e593",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "8",
          "netId": "control_net_be1982fe6067",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1722",
          "pin": "1",
          "netId": "control_net_be1982fe6067",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "1",
          "netId": "control_net_582519679d90",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1716",
          "pin": "1",
          "netId": "control_net_582519679d90",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "12",
          "netId": "control_net_7f9326fe10ba",
          "name": "NIC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Один NL направляется в измерение",
      "text": "Аналоговый селектор подключает выбранную нейронную линию к тракту чтения. Активный путь зависит от адресных и разрешающих сигналов.",
      "body": "Аналоговый селектор подключает выбранную нейронную линию к тракту чтения. Активный путь зависит от адресных и разрешающих сигналов.",
      "nodes": [
        "selection",
        "permit"
      ],
      "edges": [
        "selection_permit"
      ],
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "netIds": [
        "control_net_fdc5577f6544"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1732",
          "pin": "1",
          "netId": "control_net_fdc5577f6544",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "4",
          "netId": "control_net_fdc5577f6544",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1705",
          "pin": "2",
          "netId": "control_net_fdc5577f6544",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Выбираются WL",
      "text": "Ключи word-line соединяют выбранное состояние управления с восемью линиями WL. Номера цепей соответствуют контактам матрицы.",
      "body": "Ключи word-line соединяют выбранное состояние управления с восемью линиями WL. Номера цепей соответствуют контактам матрицы.",
      "nodes": [
        "word",
        "permit"
      ],
      "edges": [],
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "netIds": [
        "control_net_b2b91481bc2e",
        "control_net_82b64e8aa612",
        "control_net_945cddbc767f",
        "control_net_03726fa80526",
        "control_net_edac321adbf1",
        "control_net_3c196a06fe86",
        "control_net_1f62e25a43f4",
        "control_net_e5381212c338",
        "control_net_17238824eeb6",
        "control_net_2e82cb98585d",
        "control_net_c494e5a21fb7",
        "control_net_6f8884418f43",
        "control_net_5ef23046b636",
        "control_net_52153a3ca99d",
        "control_net_18924996523a",
        "control_net_209d9624cc4d",
        "control_net_3f3c0536dd7c",
        "control_net_fdc5577f6544",
        "control_net_6f005443ad9c",
        "control_net_fca0e6b6f6af",
        "control_net_6597f27cfc2b",
        "control_net_a7cc6914d74e",
        "control_net_45ab5f0aea68",
        "control_net_b0ea7c0c27c3",
        "control_net_747cc492238d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1700",
          "pin": "11",
          "netId": "control_net_b2b91481bc2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1704",
          "pin": "1",
          "netId": "control_net_b2b91481bc2e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "12",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "9",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "2",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "12",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "2",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "19",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "19",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "9",
          "netId": "control_net_82b64e8aa612",
          "name": "S_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "13",
          "netId": "control_net_945cddbc767f",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1705",
          "pin": "1",
          "netId": "control_net_945cddbc767f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "1",
          "netId": "control_net_03726fa80526",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1700",
          "pin": "1",
          "netId": "control_net_03726fa80526",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "3",
          "netId": "control_net_edac321adbf1",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1701",
          "pin": "1",
          "netId": "control_net_edac321adbf1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1707",
          "pin": "1",
          "netId": "control_net_3c196a06fe86",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "18",
          "netId": "control_net_3c196a06fe86",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "20",
          "netId": "control_net_1f62e25a43f4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1706",
          "pin": "1",
          "netId": "control_net_1f62e25a43f4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1701",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1707",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "15",
          "netId": "control_net_17238824eeb6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1700",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "16",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "16",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1703",
          "pin": "1",
          "netId": "control_net_c494e5a21fb7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "8",
          "netId": "control_net_c494e5a21fb7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1702",
          "pin": "1",
          "netId": "control_net_6f8884418f43",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "10",
          "netId": "control_net_6f8884418f43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1713",
          "pin": "1",
          "netId": "control_net_5ef23046b636",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "13",
          "netId": "control_net_5ef23046b636",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "20",
          "netId": "control_net_52153a3ca99d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1714",
          "pin": "1",
          "netId": "control_net_52153a3ca99d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1708",
          "pin": "1",
          "netId": "control_net_18924996523a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "1",
          "netId": "control_net_18924996523a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "2",
          "netId": "control_net_3f3c0536dd7c",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1732",
          "pin": "1",
          "netId": "control_net_fdc5577f6544",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "4",
          "netId": "control_net_fdc5577f6544",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1709",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "8",
          "netId": "control_net_fca0e6b6f6af",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1711",
          "pin": "1",
          "netId": "control_net_fca0e6b6f6af",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "10",
          "netId": "control_net_6597f27cfc2b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1710",
          "pin": "1",
          "netId": "control_net_6597f27cfc2b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "15",
          "netId": "control_net_a7cc6914d74e",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "11",
          "netId": "control_net_45ab5f0aea68",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1712",
          "pin": "1",
          "netId": "control_net_45ab5f0aea68",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "3",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1709",
          "pin": "1",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "18",
          "netId": "control_net_747cc492238d",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1715",
          "pin": "1",
          "netId": "control_net_747cc492238d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Неактивные NL получают заданное состояние",
      "text": "Ключи ограничения определяют состояние невыбранных нейронных линий. Это отдельная функция от выбора измеряемого канала.",
      "body": "Ключи ограничения определяют состояние невыбранных нейронных линий. Это отдельная функция от выбора измеряемого канала.",
      "nodes": [
        "clamp",
        "permit"
      ],
      "edges": [],
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "netIds": [
        "control_net_e4379a2b0f61",
        "control_net_df58d9efe6ea",
        "control_net_6cd7e17461df",
        "control_net_072af1a28ea6",
        "control_net_209d9624cc4d",
        "control_net_3f3c0536dd7c",
        "control_net_fdc5577f6544",
        "control_net_6f005443ad9c",
        "control_net_d380ae123eb3",
        "control_net_86b7951f0b9b",
        "control_net_919f25939ba9",
        "control_net_5212ff00c1ac",
        "control_net_c04b6da19edd",
        "control_net_e8ccb5161adb",
        "control_net_a335d291d1da",
        "control_net_e5381212c338",
        "control_net_0c44846c1393",
        "control_net_2e82cb98585d",
        "control_net_79947d226d73",
        "control_net_3762f1a58fed",
        "control_net_09be2b97e593",
        "control_net_be1982fe6067",
        "control_net_582519679d90",
        "control_net_7f9326fe10ba"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1719",
          "pin": "1",
          "netId": "control_net_e4379a2b0f61",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "15",
          "netId": "control_net_e4379a2b0f61",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1720",
          "pin": "1",
          "netId": "control_net_df58d9efe6ea",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "9",
          "netId": "control_net_df58d9efe6ea",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1724",
          "pin": "1",
          "netId": "control_net_6cd7e17461df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "1",
          "netId": "control_net_6cd7e17461df",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1729",
          "pin": "1",
          "netId": "control_net_072af1a28ea6",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "10",
          "netId": "control_net_072af1a28ea6",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "2",
          "netId": "control_net_3f3c0536dd7c",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1732",
          "pin": "1",
          "netId": "control_net_fdc5577f6544",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "4",
          "netId": "control_net_fdc5577f6544",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1709",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "7",
          "netId": "control_net_d380ae123eb3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1723",
          "pin": "1",
          "netId": "control_net_d380ae123eb3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1728",
          "pin": "1",
          "netId": "control_net_86b7951f0b9b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "9",
          "netId": "control_net_86b7951f0b9b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "2",
          "netId": "control_net_919f25939ba9",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1725",
          "pin": "1",
          "netId": "control_net_919f25939ba9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "7",
          "netId": "control_net_5212ff00c1ac",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1731",
          "pin": "1",
          "netId": "control_net_5212ff00c1ac",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "8",
          "netId": "control_net_c04b6da19edd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1730",
          "pin": "1",
          "netId": "control_net_c04b6da19edd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1727",
          "pin": "1",
          "netId": "control_net_e8ccb5161adb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "15",
          "netId": "control_net_e8ccb5161adb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "16",
          "netId": "control_net_a335d291d1da",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1726",
          "pin": "1",
          "netId": "control_net_a335d291d1da",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1707",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "12",
          "netId": "control_net_0c44846c1393",
          "name": "NIC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1717",
          "pin": "2",
          "netId": "control_net_79947d226d73",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "2",
          "netId": "control_net_79947d226d73",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1721",
          "pin": "1",
          "netId": "control_net_3762f1a58fed",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "10",
          "netId": "control_net_3762f1a58fed",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "16",
          "netId": "control_net_09be2b97e593",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1718",
          "pin": "1",
          "netId": "control_net_09be2b97e593",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "8",
          "netId": "control_net_be1982fe6067",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1722",
          "pin": "1",
          "netId": "control_net_be1982fe6067",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "1",
          "netId": "control_net_582519679d90",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1716",
          "pin": "1",
          "netId": "control_net_582519679d90",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "12",
          "netId": "control_net_7f9326fe10ba",
          "name": "NIC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Один NL направляется в измерение",
      "text": "Аналоговый селектор подключает выбранную нейронную линию к тракту чтения. Активный путь зависит от адресных и разрешающих сигналов.",
      "body": "Аналоговый селектор подключает выбранную нейронную линию к тракту чтения. Активный путь зависит от адресных и разрешающих сигналов.",
      "nodes": [
        "selection",
        "permit"
      ],
      "edges": [
        "selection_permit"
      ],
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "netIds": [
        "control_net_fdc5577f6544"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1732",
          "pin": "1",
          "netId": "control_net_fdc5577f6544",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1704",
          "pin": "4",
          "netId": "control_net_fdc5577f6544",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1705",
          "pin": "2",
          "netId": "control_net_fdc5577f6544",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
