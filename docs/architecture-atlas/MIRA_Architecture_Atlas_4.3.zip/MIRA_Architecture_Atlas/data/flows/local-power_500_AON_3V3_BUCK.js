/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_500_AON_3V3_BUCK",
  "title": "Как работает: Дежурное питание контроля",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_500_AON_3V3_BUCK",
  "steps": [
    {
      "title": "Дежурная ветвь получает BUS24",
      "text": "Шина BUS24 питает дежурный преобразователь. Эта ветвь обеспечивает питание надзора до включения остальных запросов.",
      "body": "Шина BUS24 питает дежурный преобразователь. Эта ветвь обеспечивает питание надзора до включения остальных запросов.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_500_AON_3V3_BUCK",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует AON",
      "text": "Регулятор и цепь обратной связи формируют выходную шину AON. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину AON. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_500_AON_3V3_BUCK",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_bfbd5cdcdcfd",
        "power_net_c7b4c78d37bb",
        "power_net_478d89e5a433",
        "power_net_abd71ae65884"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R504",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R503",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R501",
          "pin": "1",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R502",
          "pin": "2",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "3",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R501",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R503",
          "pin": "1",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L501",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C504",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C505",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C502",
          "pin": "1",
          "netId": "power_net_478d89e5a433",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "1",
          "netId": "power_net_478d89e5a433",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C502",
          "pin": "2",
          "netId": "power_net_abd71ae65884",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L501",
          "pin": "1",
          "netId": "power_net_abd71ae65884",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "6",
          "netId": "power_net_abd71ae65884",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования AON питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования AON питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_500_AON_3V3_BUCK",
      "netIds": [
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R504",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R503",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Дежурная ветвь получает BUS24",
      "text": "Шина BUS24 питает дежурный преобразователь. Эта ветвь обеспечивает питание надзора до включения остальных запросов.",
      "body": "Шина BUS24 питает дежурный преобразователь. Эта ветвь обеспечивает питание надзора до включения остальных запросов.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_500_AON_3V3_BUCK",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует AON",
      "text": "Регулятор и цепь обратной связи формируют выходную шину AON. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину AON. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_500_AON_3V3_BUCK",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_bfbd5cdcdcfd",
        "power_net_c7b4c78d37bb",
        "power_net_478d89e5a433",
        "power_net_abd71ae65884"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R504",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R503",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R501",
          "pin": "1",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R502",
          "pin": "2",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "3",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R501",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R503",
          "pin": "1",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L501",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C504",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C505",
          "pin": "2",
          "netId": "power_net_c7b4c78d37bb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C502",
          "pin": "1",
          "netId": "power_net_478d89e5a433",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "1",
          "netId": "power_net_478d89e5a433",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C502",
          "pin": "2",
          "netId": "power_net_abd71ae65884",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L501",
          "pin": "1",
          "netId": "power_net_abd71ae65884",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "6",
          "netId": "power_net_abd71ae65884",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования AON питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования AON питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_500_AON_3V3_BUCK",
      "netIds": [
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R504",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R503",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
