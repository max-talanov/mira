/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control-routing",
  "title": "Как работает: Фиксация и коммутация операции",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control-routing",
  "steps": [
    {
      "title": "Проверка согласованности операции",
      "text": "U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "body": "U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "nodes": [
        "sheet1300",
        "sheet1600"
      ],
      "edges": [
        "sheet1300_sheet1600"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_53c8d7c2e621",
        "control_net_69c914a4b819",
        "control_net_209d9624cc4d",
        "control_net_24511a425a2f",
        "control_net_3f65bb4e6c1b",
        "control_net_1548c2f283f9",
        "control_net_17e2493797cd",
        "control_net_5a48e06ad240",
        "control_net_c3b957dc2a05"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "9",
          "netId": "control_net_69c914a4b819",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "16",
          "netId": "control_net_24511a425a2f",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "1",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "2",
          "netId": "control_net_1548c2f283f9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "16",
          "netId": "control_net_1548c2f283f9",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "11",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "20",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "1",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "10",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "80-битное состояние ключей",
      "text": "U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "body": "U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "nodes": [
        "sheet1400",
        "sheet1500"
      ],
      "edges": [
        "sheet1400_sheet1500"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_57236d4b4e50",
        "control_net_70c03a238d66",
        "control_net_7e66df34c1cb",
        "control_net_e2ace5299f00",
        "control_net_f498b034d47c",
        "control_net_dfebfa8ce954",
        "control_net_8cec06d0a68e",
        "control_net_91367f0adb00",
        "control_net_4e889b41bce9",
        "control_net_4f58db14a2f0",
        "control_net_8ae298951006",
        "control_net_c7a227845fc4",
        "control_net_aa8081055225",
        "control_net_38aa1b871436",
        "control_net_30da3c89e6b0",
        "control_net_27e11deab85a",
        "control_net_77dec07465d1",
        "control_net_76168421ae64",
        "control_net_01c0ad0ef8f8",
        "control_net_5e01c47f5c29",
        "control_net_35c00105d395",
        "control_net_48fcc210d1f6",
        "control_net_31367ce75c40",
        "control_net_282ba042f616",
        "control_net_acd932993b7b",
        "control_net_2f56e21bf1c8",
        "control_net_e9062516eb43",
        "control_net_d24d5fdebd2d",
        "control_net_e542c28a3215",
        "control_net_c20b4b863473",
        "control_net_adcb6c1bfe2e",
        "control_net_2595b3f207c1",
        "control_net_3e8175ead30c",
        "control_net_699b10c0cb1f",
        "control_net_928a45524bd4",
        "control_net_51b3012894bb",
        "control_net_853be9b7ad24",
        "control_net_48cbd08d5e88",
        "control_net_5e93332cd041",
        "control_net_45c19501bad5",
        "control_net_db3c5d849c82",
        "control_net_37fa60099550",
        "control_net_b211580c8101",
        "control_net_4aefa7bda0e0",
        "control_net_2bbd0dc06c6f",
        "control_net_c8a58330532e",
        "control_net_24fd3915e934",
        "control_net_a3db8189ec60",
        "control_net_287cfdf7ef3f",
        "control_net_ac7e9e00c8b3",
        "control_net_42dd32d2dba8",
        "control_net_ad6ab5928142",
        "control_net_cc7e68c63366",
        "control_net_c771f664cff1",
        "control_net_d948d4dd3369",
        "control_net_fbc93a9a1f13",
        "control_net_bb256500c151",
        "control_net_724ff3a3348c",
        "control_net_323da0f3bc1f",
        "control_net_39c83bb6d20e",
        "control_net_dcf3a56694f7",
        "control_net_a275f9d9677f",
        "control_net_aad969376bf0",
        "control_net_e85cee5f43f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1405",
          "pin": "3",
          "netId": "control_net_57236d4b4e50",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "8",
          "netId": "control_net_57236d4b4e50",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "4",
          "netId": "control_net_70c03a238d66",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "1",
          "netId": "control_net_70c03a238d66",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "2",
          "netId": "control_net_7e66df34c1cb",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "2",
          "netId": "control_net_e2ace5299f00",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "9",
          "netId": "control_net_e2ace5299f00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "6",
          "netId": "control_net_f498b034d47c",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "5",
          "netId": "control_net_dfebfa8ce954",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "16",
          "netId": "control_net_dfebfa8ce954",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "1",
          "netId": "control_net_91367f0adb00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "15",
          "netId": "control_net_8ae298951006",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "1",
          "netId": "control_net_8ae298951006",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "7",
          "netId": "control_net_c7a227845fc4",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "8",
          "netId": "control_net_c7a227845fc4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "4",
          "netId": "control_net_aa8081055225",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "3",
          "netId": "control_net_30da3c89e6b0",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "16",
          "netId": "control_net_27e11deab85a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "5",
          "netId": "control_net_76168421ae64",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "1",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "16",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "15",
          "netId": "control_net_5e01c47f5c29",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "1",
          "netId": "control_net_5e01c47f5c29",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "6",
          "netId": "control_net_48fcc210d1f6",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "7",
          "netId": "control_net_282ba042f616",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "9",
          "netId": "control_net_acd932993b7b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "15",
          "netId": "control_net_2f56e21bf1c8",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "5",
          "netId": "control_net_e9062516eb43",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "16",
          "netId": "control_net_e9062516eb43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "6",
          "netId": "control_net_d24d5fdebd2d",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "3",
          "netId": "control_net_c20b4b863473",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "8",
          "netId": "control_net_c20b4b863473",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "1",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "16",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "8",
          "netId": "control_net_2595b3f207c1",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "5",
          "netId": "control_net_3e8175ead30c",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "15",
          "netId": "control_net_928a45524bd4",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "6",
          "netId": "control_net_45c19501bad5",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "9",
          "netId": "control_net_45c19501bad5",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "15",
          "netId": "control_net_db3c5d849c82",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "1",
          "netId": "control_net_db3c5d849c82",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "1",
          "netId": "control_net_b211580c8101",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "1",
          "netId": "control_net_4aefa7bda0e0",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "7",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "8",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "7",
          "netId": "control_net_c8a58330532e",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "4",
          "netId": "control_net_a3db8189ec60",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "1",
          "netId": "control_net_ad6ab5928142",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "16",
          "netId": "control_net_ad6ab5928142",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "3",
          "netId": "control_net_cc7e68c63366",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "2",
          "netId": "control_net_d948d4dd3369",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "4",
          "netId": "control_net_fbc93a9a1f13",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "1",
          "netId": "control_net_fbc93a9a1f13",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "3",
          "netId": "control_net_bb256500c151",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "8",
          "netId": "control_net_bb256500c151",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "2",
          "netId": "control_net_323da0f3bc1f",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "9",
          "netId": "control_net_323da0f3bc1f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "6",
          "netId": "control_net_39c83bb6d20e",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "9",
          "netId": "control_net_39c83bb6d20e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "2",
          "netId": "control_net_dcf3a56694f7",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "9",
          "netId": "control_net_dcf3a56694f7",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "7",
          "netId": "control_net_a275f9d9677f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "4",
          "netId": "control_net_aad969376bf0",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "5",
          "netId": "control_net_e85cee5f43f2",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Коммутация битовых линий матрицы",
      "text": "Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "body": "Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "nodes": [
        "sheet1500",
        "sheet1400"
      ],
      "edges": [
        "sheet1400_sheet1500"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_57236d4b4e50",
        "control_net_70c03a238d66",
        "control_net_7e66df34c1cb",
        "control_net_e2ace5299f00",
        "control_net_f498b034d47c",
        "control_net_dfebfa8ce954",
        "control_net_8cec06d0a68e",
        "control_net_91367f0adb00",
        "control_net_4e889b41bce9",
        "control_net_4f58db14a2f0",
        "control_net_8ae298951006",
        "control_net_c7a227845fc4",
        "control_net_aa8081055225",
        "control_net_38aa1b871436",
        "control_net_30da3c89e6b0",
        "control_net_27e11deab85a",
        "control_net_77dec07465d1",
        "control_net_76168421ae64",
        "control_net_01c0ad0ef8f8",
        "control_net_5e01c47f5c29",
        "control_net_35c00105d395",
        "control_net_48fcc210d1f6",
        "control_net_31367ce75c40",
        "control_net_282ba042f616",
        "control_net_acd932993b7b",
        "control_net_2f56e21bf1c8",
        "control_net_e9062516eb43",
        "control_net_d24d5fdebd2d",
        "control_net_e542c28a3215",
        "control_net_c20b4b863473",
        "control_net_adcb6c1bfe2e",
        "control_net_2595b3f207c1",
        "control_net_3e8175ead30c",
        "control_net_699b10c0cb1f",
        "control_net_928a45524bd4",
        "control_net_51b3012894bb",
        "control_net_853be9b7ad24",
        "control_net_48cbd08d5e88",
        "control_net_5e93332cd041",
        "control_net_45c19501bad5",
        "control_net_db3c5d849c82",
        "control_net_37fa60099550",
        "control_net_b211580c8101",
        "control_net_4aefa7bda0e0",
        "control_net_2bbd0dc06c6f",
        "control_net_c8a58330532e",
        "control_net_24fd3915e934",
        "control_net_a3db8189ec60",
        "control_net_287cfdf7ef3f",
        "control_net_ac7e9e00c8b3",
        "control_net_42dd32d2dba8",
        "control_net_ad6ab5928142",
        "control_net_cc7e68c63366",
        "control_net_c771f664cff1",
        "control_net_d948d4dd3369",
        "control_net_fbc93a9a1f13",
        "control_net_bb256500c151",
        "control_net_724ff3a3348c",
        "control_net_323da0f3bc1f",
        "control_net_39c83bb6d20e",
        "control_net_dcf3a56694f7",
        "control_net_a275f9d9677f",
        "control_net_aad969376bf0",
        "control_net_e85cee5f43f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1405",
          "pin": "3",
          "netId": "control_net_57236d4b4e50",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "8",
          "netId": "control_net_57236d4b4e50",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "4",
          "netId": "control_net_70c03a238d66",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "1",
          "netId": "control_net_70c03a238d66",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "2",
          "netId": "control_net_7e66df34c1cb",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "2",
          "netId": "control_net_e2ace5299f00",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "9",
          "netId": "control_net_e2ace5299f00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "6",
          "netId": "control_net_f498b034d47c",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "5",
          "netId": "control_net_dfebfa8ce954",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "16",
          "netId": "control_net_dfebfa8ce954",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "1",
          "netId": "control_net_91367f0adb00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "15",
          "netId": "control_net_8ae298951006",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "1",
          "netId": "control_net_8ae298951006",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "7",
          "netId": "control_net_c7a227845fc4",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "8",
          "netId": "control_net_c7a227845fc4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "4",
          "netId": "control_net_aa8081055225",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "3",
          "netId": "control_net_30da3c89e6b0",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "16",
          "netId": "control_net_27e11deab85a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "5",
          "netId": "control_net_76168421ae64",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "1",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "16",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "15",
          "netId": "control_net_5e01c47f5c29",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "1",
          "netId": "control_net_5e01c47f5c29",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "6",
          "netId": "control_net_48fcc210d1f6",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "7",
          "netId": "control_net_282ba042f616",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "9",
          "netId": "control_net_acd932993b7b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "15",
          "netId": "control_net_2f56e21bf1c8",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "5",
          "netId": "control_net_e9062516eb43",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "16",
          "netId": "control_net_e9062516eb43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "6",
          "netId": "control_net_d24d5fdebd2d",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "3",
          "netId": "control_net_c20b4b863473",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "8",
          "netId": "control_net_c20b4b863473",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "1",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "16",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "8",
          "netId": "control_net_2595b3f207c1",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "5",
          "netId": "control_net_3e8175ead30c",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "15",
          "netId": "control_net_928a45524bd4",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "6",
          "netId": "control_net_45c19501bad5",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "9",
          "netId": "control_net_45c19501bad5",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "15",
          "netId": "control_net_db3c5d849c82",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "1",
          "netId": "control_net_db3c5d849c82",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "1",
          "netId": "control_net_b211580c8101",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "1",
          "netId": "control_net_4aefa7bda0e0",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "7",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "8",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "7",
          "netId": "control_net_c8a58330532e",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "4",
          "netId": "control_net_a3db8189ec60",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "1",
          "netId": "control_net_ad6ab5928142",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "16",
          "netId": "control_net_ad6ab5928142",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "3",
          "netId": "control_net_cc7e68c63366",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "2",
          "netId": "control_net_d948d4dd3369",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "4",
          "netId": "control_net_fbc93a9a1f13",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "1",
          "netId": "control_net_fbc93a9a1f13",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "3",
          "netId": "control_net_bb256500c151",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "8",
          "netId": "control_net_bb256500c151",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "2",
          "netId": "control_net_323da0f3bc1f",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "9",
          "netId": "control_net_323da0f3bc1f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "6",
          "netId": "control_net_39c83bb6d20e",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "9",
          "netId": "control_net_39c83bb6d20e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "2",
          "netId": "control_net_dcf3a56694f7",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "9",
          "netId": "control_net_dcf3a56694f7",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "7",
          "netId": "control_net_a275f9d9677f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "4",
          "netId": "control_net_aad969376bf0",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "5",
          "netId": "control_net_e85cee5f43f2",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбор источника, банка и полярности",
      "text": "Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "body": "Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "nodes": [
        "sheet1600",
        "sheet1300"
      ],
      "edges": [
        "sheet1300_sheet1600"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_53c8d7c2e621",
        "control_net_69c914a4b819",
        "control_net_209d9624cc4d",
        "control_net_24511a425a2f",
        "control_net_3f65bb4e6c1b",
        "control_net_1548c2f283f9",
        "control_net_17e2493797cd",
        "control_net_5a48e06ad240",
        "control_net_c3b957dc2a05"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "9",
          "netId": "control_net_69c914a4b819",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "16",
          "netId": "control_net_24511a425a2f",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "1",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "2",
          "netId": "control_net_1548c2f283f9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "16",
          "netId": "control_net_1548c2f283f9",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "11",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "20",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "1",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "10",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбор строк и измерительных линий",
      "text": "U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата. Связь с соседним узлом показана цепями MAT_WL_ON_5, MAT_WL_ON_7, MAT_WL_ON_6, MAT_NL_ZERO_1.",
      "body": "U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата. Связь с соседним узлом показана цепями MAT_WL_ON_5, MAT_WL_ON_7, MAT_WL_ON_6, MAT_NL_ZERO_1.",
      "nodes": [
        "sheet1700",
        "sheet1400"
      ],
      "edges": [
        "sheet1400_sheet1700"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_6597f27cfc2b",
        "control_net_52153a3ca99d",
        "control_net_45ab5f0aea68",
        "control_net_09be2b97e593",
        "control_net_1f62e25a43f4",
        "control_net_6cd7e17461df",
        "control_net_582519679d90",
        "control_net_03726fa80526",
        "control_net_18924996523a",
        "control_net_86b7951f0b9b",
        "control_net_6f8884418f43",
        "control_net_be1982fe6067",
        "control_net_b2b91481bc2e",
        "control_net_a335d291d1da",
        "control_net_df58d9efe6ea",
        "control_net_c04b6da19edd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1408",
          "pin": "5",
          "netId": "control_net_6597f27cfc2b",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "10",
          "netId": "control_net_6597f27cfc2b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "7",
          "netId": "control_net_52153a3ca99d",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "20",
          "netId": "control_net_52153a3ca99d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "6",
          "netId": "control_net_45ab5f0aea68",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "11",
          "netId": "control_net_45ab5f0aea68",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "16",
          "netId": "control_net_09be2b97e593",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "3",
          "netId": "control_net_1f62e25a43f4",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "20",
          "netId": "control_net_1f62e25a43f4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "1",
          "netId": "control_net_6cd7e17461df",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "1",
          "netId": "control_net_582519679d90",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "15",
          "netId": "control_net_03726fa80526",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "1",
          "netId": "control_net_03726fa80526",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "4",
          "netId": "control_net_18924996523a",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "1",
          "netId": "control_net_18924996523a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "9",
          "netId": "control_net_86b7951f0b9b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "1",
          "netId": "control_net_6f8884418f43",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "10",
          "netId": "control_net_6f8884418f43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "8",
          "netId": "control_net_be1982fe6067",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "2",
          "netId": "control_net_b2b91481bc2e",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "11",
          "netId": "control_net_b2b91481bc2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "16",
          "netId": "control_net_a335d291d1da",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "9",
          "netId": "control_net_df58d9efe6ea",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "8",
          "netId": "control_net_c04b6da19edd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подключение экспериментальной матрицы",
      "text": "J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня. Связь с соседним узлом показана цепями BL5, BL12, BL7, BL8.",
      "body": "J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня. Связь с соседним узлом показана цепями BL5, BL12, BL7, BL8.",
      "nodes": [
        "sheet1800",
        "sheet1500"
      ],
      "edges": [
        "sheet1500_sheet1800"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_410ce51ce77b",
        "control_net_5b7588c91934",
        "control_net_96843655892a",
        "control_net_ef57e67af6ee",
        "control_net_a38212b18dab",
        "control_net_cb9a53bc7e2d",
        "control_net_b1a7be433721",
        "control_net_5a6f03bbf06c",
        "control_net_f237bfeb4d31",
        "control_net_7deb95e626ac",
        "control_net_dee259c78870",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_9aa6ed5fa484",
        "control_net_af268a134ce7",
        "control_net_2661b7e1d1d8",
        "control_net_7443657d6bc7",
        "control_net_8c1f7a16a91f",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_77eb74275447",
        "control_net_331bcbe5832b",
        "control_net_da64d12ab5ef",
        "control_net_668f023fd21c",
        "control_net_15a5f03664b6",
        "control_net_0066c578f4fd",
        "control_net_ae5aa8c25d68",
        "control_net_76481426c5c9",
        "control_net_36b8e2744fa2",
        "control_net_06c41da37048",
        "control_net_093450c5090e",
        "control_net_a3c1624fed4f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1503",
          "pin": "15",
          "netId": "control_net_410ce51ce77b",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "59",
          "netId": "control_net_410ce51ce77b",
          "name": "BL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "52",
          "netId": "control_net_5b7588c91934",
          "name": "BL12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "7",
          "netId": "control_net_96843655892a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "57",
          "netId": "control_net_96843655892a",
          "name": "BL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "2",
          "netId": "control_net_ef57e67af6ee",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "56",
          "netId": "control_net_ef57e67af6ee",
          "name": "BL8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "7",
          "netId": "control_net_a38212b18dab",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "53",
          "netId": "control_net_a38212b18dab",
          "name": "BL11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "23",
          "netId": "control_net_cb9a53bc7e2d",
          "name": "BL22",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "10",
          "netId": "control_net_b1a7be433721",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "54",
          "netId": "control_net_b1a7be433721",
          "name": "BL10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "28",
          "netId": "control_net_5a6f03bbf06c",
          "name": "BL27",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "21",
          "netId": "control_net_f237bfeb4d31",
          "name": "BL20",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "2",
          "netId": "control_net_7deb95e626ac",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "29",
          "netId": "control_net_7deb95e626ac",
          "name": "BL28",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "15",
          "netId": "control_net_dee259c78870",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "55",
          "netId": "control_net_dee259c78870",
          "name": "BL9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "2",
          "netId": "control_net_30db039e0318",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "60",
          "netId": "control_net_30db039e0318",
          "name": "BL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "7",
          "netId": "control_net_538bdbb480c1",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "7",
          "netId": "control_net_538bdbb480c1",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "61",
          "netId": "control_net_538bdbb480c1",
          "name": "BL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "49",
          "netId": "control_net_9aa6ed5fa484",
          "name": "BL15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "2",
          "netId": "control_net_af268a134ce7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "2",
          "netId": "control_net_af268a134ce7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "64",
          "netId": "control_net_af268a134ce7",
          "name": "BL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "50",
          "netId": "control_net_2661b7e1d1d8",
          "name": "BL14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "10",
          "netId": "control_net_7443657d6bc7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "10",
          "netId": "control_net_7443657d6bc7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "62",
          "netId": "control_net_7443657d6bc7",
          "name": "BL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "15",
          "netId": "control_net_8c1f7a16a91f",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "18",
          "netId": "control_net_8c1f7a16a91f",
          "name": "BL17",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "15",
          "netId": "control_net_9037a6d55684",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "30",
          "netId": "control_net_9037a6d55684",
          "name": "BL29",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "10",
          "netId": "control_net_e59cadbe90ef",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "31",
          "netId": "control_net_e59cadbe90ef",
          "name": "BL30",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "10",
          "netId": "control_net_77eb74275447",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "58",
          "netId": "control_net_77eb74275447",
          "name": "BL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "15",
          "netId": "control_net_331bcbe5832b",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "15",
          "netId": "control_net_331bcbe5832b",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "63",
          "netId": "control_net_331bcbe5832b",
          "name": "BL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "51",
          "netId": "control_net_da64d12ab5ef",
          "name": "BL13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "27",
          "netId": "control_net_668f023fd21c",
          "name": "BL26",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "10",
          "netId": "control_net_15a5f03664b6",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "19",
          "netId": "control_net_15a5f03664b6",
          "name": "BL18",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "24",
          "netId": "control_net_0066c578f4fd",
          "name": "BL23",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "7",
          "netId": "control_net_ae5aa8c25d68",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "32",
          "netId": "control_net_ae5aa8c25d68",
          "name": "BL31",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "2",
          "netId": "control_net_76481426c5c9",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "17",
          "netId": "control_net_76481426c5c9",
          "name": "BL16",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "22",
          "netId": "control_net_36b8e2744fa2",
          "name": "BL21",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "26",
          "netId": "control_net_06c41da37048",
          "name": "BL25",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "7",
          "netId": "control_net_093450c5090e",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "20",
          "netId": "control_net_093450c5090e",
          "name": "BL19",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "25",
          "netId": "control_net_a3c1624fed4f",
          "name": "BL24",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Проверка согласованности операции",
      "text": "U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "body": "U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "nodes": [
        "sheet1300",
        "sheet1600"
      ],
      "edges": [
        "sheet1300_sheet1600"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_53c8d7c2e621",
        "control_net_69c914a4b819",
        "control_net_209d9624cc4d",
        "control_net_24511a425a2f",
        "control_net_3f65bb4e6c1b",
        "control_net_1548c2f283f9",
        "control_net_17e2493797cd",
        "control_net_5a48e06ad240",
        "control_net_c3b957dc2a05"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "9",
          "netId": "control_net_69c914a4b819",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "16",
          "netId": "control_net_24511a425a2f",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "1",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "2",
          "netId": "control_net_1548c2f283f9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "16",
          "netId": "control_net_1548c2f283f9",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "11",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "20",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "1",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "10",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "80-битное состояние ключей",
      "text": "U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "body": "U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "nodes": [
        "sheet1400",
        "sheet1500"
      ],
      "edges": [
        "sheet1400_sheet1500"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_57236d4b4e50",
        "control_net_70c03a238d66",
        "control_net_7e66df34c1cb",
        "control_net_e2ace5299f00",
        "control_net_f498b034d47c",
        "control_net_dfebfa8ce954",
        "control_net_8cec06d0a68e",
        "control_net_91367f0adb00",
        "control_net_4e889b41bce9",
        "control_net_4f58db14a2f0",
        "control_net_8ae298951006",
        "control_net_c7a227845fc4",
        "control_net_aa8081055225",
        "control_net_38aa1b871436",
        "control_net_30da3c89e6b0",
        "control_net_27e11deab85a",
        "control_net_77dec07465d1",
        "control_net_76168421ae64",
        "control_net_01c0ad0ef8f8",
        "control_net_5e01c47f5c29",
        "control_net_35c00105d395",
        "control_net_48fcc210d1f6",
        "control_net_31367ce75c40",
        "control_net_282ba042f616",
        "control_net_acd932993b7b",
        "control_net_2f56e21bf1c8",
        "control_net_e9062516eb43",
        "control_net_d24d5fdebd2d",
        "control_net_e542c28a3215",
        "control_net_c20b4b863473",
        "control_net_adcb6c1bfe2e",
        "control_net_2595b3f207c1",
        "control_net_3e8175ead30c",
        "control_net_699b10c0cb1f",
        "control_net_928a45524bd4",
        "control_net_51b3012894bb",
        "control_net_853be9b7ad24",
        "control_net_48cbd08d5e88",
        "control_net_5e93332cd041",
        "control_net_45c19501bad5",
        "control_net_db3c5d849c82",
        "control_net_37fa60099550",
        "control_net_b211580c8101",
        "control_net_4aefa7bda0e0",
        "control_net_2bbd0dc06c6f",
        "control_net_c8a58330532e",
        "control_net_24fd3915e934",
        "control_net_a3db8189ec60",
        "control_net_287cfdf7ef3f",
        "control_net_ac7e9e00c8b3",
        "control_net_42dd32d2dba8",
        "control_net_ad6ab5928142",
        "control_net_cc7e68c63366",
        "control_net_c771f664cff1",
        "control_net_d948d4dd3369",
        "control_net_fbc93a9a1f13",
        "control_net_bb256500c151",
        "control_net_724ff3a3348c",
        "control_net_323da0f3bc1f",
        "control_net_39c83bb6d20e",
        "control_net_dcf3a56694f7",
        "control_net_a275f9d9677f",
        "control_net_aad969376bf0",
        "control_net_e85cee5f43f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1405",
          "pin": "3",
          "netId": "control_net_57236d4b4e50",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "8",
          "netId": "control_net_57236d4b4e50",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "4",
          "netId": "control_net_70c03a238d66",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "1",
          "netId": "control_net_70c03a238d66",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "2",
          "netId": "control_net_7e66df34c1cb",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "2",
          "netId": "control_net_e2ace5299f00",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "9",
          "netId": "control_net_e2ace5299f00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "6",
          "netId": "control_net_f498b034d47c",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "5",
          "netId": "control_net_dfebfa8ce954",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "16",
          "netId": "control_net_dfebfa8ce954",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "1",
          "netId": "control_net_91367f0adb00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "15",
          "netId": "control_net_8ae298951006",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "1",
          "netId": "control_net_8ae298951006",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "7",
          "netId": "control_net_c7a227845fc4",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "8",
          "netId": "control_net_c7a227845fc4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "4",
          "netId": "control_net_aa8081055225",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "3",
          "netId": "control_net_30da3c89e6b0",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "16",
          "netId": "control_net_27e11deab85a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "5",
          "netId": "control_net_76168421ae64",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "1",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "16",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "15",
          "netId": "control_net_5e01c47f5c29",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "1",
          "netId": "control_net_5e01c47f5c29",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "6",
          "netId": "control_net_48fcc210d1f6",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "7",
          "netId": "control_net_282ba042f616",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "9",
          "netId": "control_net_acd932993b7b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "15",
          "netId": "control_net_2f56e21bf1c8",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "5",
          "netId": "control_net_e9062516eb43",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "16",
          "netId": "control_net_e9062516eb43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "6",
          "netId": "control_net_d24d5fdebd2d",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "3",
          "netId": "control_net_c20b4b863473",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "8",
          "netId": "control_net_c20b4b863473",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "1",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "16",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "8",
          "netId": "control_net_2595b3f207c1",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "5",
          "netId": "control_net_3e8175ead30c",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "15",
          "netId": "control_net_928a45524bd4",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "6",
          "netId": "control_net_45c19501bad5",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "9",
          "netId": "control_net_45c19501bad5",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "15",
          "netId": "control_net_db3c5d849c82",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "1",
          "netId": "control_net_db3c5d849c82",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "1",
          "netId": "control_net_b211580c8101",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "1",
          "netId": "control_net_4aefa7bda0e0",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "7",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "8",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "7",
          "netId": "control_net_c8a58330532e",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "4",
          "netId": "control_net_a3db8189ec60",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "1",
          "netId": "control_net_ad6ab5928142",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "16",
          "netId": "control_net_ad6ab5928142",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "3",
          "netId": "control_net_cc7e68c63366",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "2",
          "netId": "control_net_d948d4dd3369",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "4",
          "netId": "control_net_fbc93a9a1f13",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "1",
          "netId": "control_net_fbc93a9a1f13",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "3",
          "netId": "control_net_bb256500c151",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "8",
          "netId": "control_net_bb256500c151",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "2",
          "netId": "control_net_323da0f3bc1f",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "9",
          "netId": "control_net_323da0f3bc1f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "6",
          "netId": "control_net_39c83bb6d20e",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "9",
          "netId": "control_net_39c83bb6d20e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "2",
          "netId": "control_net_dcf3a56694f7",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "9",
          "netId": "control_net_dcf3a56694f7",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "7",
          "netId": "control_net_a275f9d9677f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "4",
          "netId": "control_net_aad969376bf0",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "5",
          "netId": "control_net_e85cee5f43f2",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Коммутация битовых линий матрицы",
      "text": "Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "body": "Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение. Связь с соседним узлом показана цепями MAT_BL_ZERO_11, MAT_BL_VMM_28, MAT_BL_VMM_10, MAT_BL_ZERO_10.",
      "nodes": [
        "sheet1500",
        "sheet1400"
      ],
      "edges": [
        "sheet1400_sheet1500"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_57236d4b4e50",
        "control_net_70c03a238d66",
        "control_net_7e66df34c1cb",
        "control_net_e2ace5299f00",
        "control_net_f498b034d47c",
        "control_net_dfebfa8ce954",
        "control_net_8cec06d0a68e",
        "control_net_91367f0adb00",
        "control_net_4e889b41bce9",
        "control_net_4f58db14a2f0",
        "control_net_8ae298951006",
        "control_net_c7a227845fc4",
        "control_net_aa8081055225",
        "control_net_38aa1b871436",
        "control_net_30da3c89e6b0",
        "control_net_27e11deab85a",
        "control_net_77dec07465d1",
        "control_net_76168421ae64",
        "control_net_01c0ad0ef8f8",
        "control_net_5e01c47f5c29",
        "control_net_35c00105d395",
        "control_net_48fcc210d1f6",
        "control_net_31367ce75c40",
        "control_net_282ba042f616",
        "control_net_acd932993b7b",
        "control_net_2f56e21bf1c8",
        "control_net_e9062516eb43",
        "control_net_d24d5fdebd2d",
        "control_net_e542c28a3215",
        "control_net_c20b4b863473",
        "control_net_adcb6c1bfe2e",
        "control_net_2595b3f207c1",
        "control_net_3e8175ead30c",
        "control_net_699b10c0cb1f",
        "control_net_928a45524bd4",
        "control_net_51b3012894bb",
        "control_net_853be9b7ad24",
        "control_net_48cbd08d5e88",
        "control_net_5e93332cd041",
        "control_net_45c19501bad5",
        "control_net_db3c5d849c82",
        "control_net_37fa60099550",
        "control_net_b211580c8101",
        "control_net_4aefa7bda0e0",
        "control_net_2bbd0dc06c6f",
        "control_net_c8a58330532e",
        "control_net_24fd3915e934",
        "control_net_a3db8189ec60",
        "control_net_287cfdf7ef3f",
        "control_net_ac7e9e00c8b3",
        "control_net_42dd32d2dba8",
        "control_net_ad6ab5928142",
        "control_net_cc7e68c63366",
        "control_net_c771f664cff1",
        "control_net_d948d4dd3369",
        "control_net_fbc93a9a1f13",
        "control_net_bb256500c151",
        "control_net_724ff3a3348c",
        "control_net_323da0f3bc1f",
        "control_net_39c83bb6d20e",
        "control_net_dcf3a56694f7",
        "control_net_a275f9d9677f",
        "control_net_aad969376bf0",
        "control_net_e85cee5f43f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1405",
          "pin": "3",
          "netId": "control_net_57236d4b4e50",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "8",
          "netId": "control_net_57236d4b4e50",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "4",
          "netId": "control_net_70c03a238d66",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "1",
          "netId": "control_net_70c03a238d66",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "2",
          "netId": "control_net_7e66df34c1cb",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "2",
          "netId": "control_net_e2ace5299f00",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "9",
          "netId": "control_net_e2ace5299f00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "6",
          "netId": "control_net_f498b034d47c",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "5",
          "netId": "control_net_dfebfa8ce954",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "16",
          "netId": "control_net_dfebfa8ce954",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "1",
          "netId": "control_net_91367f0adb00",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "15",
          "netId": "control_net_8ae298951006",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "1",
          "netId": "control_net_8ae298951006",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "7",
          "netId": "control_net_c7a227845fc4",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "8",
          "netId": "control_net_c7a227845fc4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "4",
          "netId": "control_net_aa8081055225",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "3",
          "netId": "control_net_30da3c89e6b0",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "16",
          "netId": "control_net_27e11deab85a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "5",
          "netId": "control_net_76168421ae64",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "1",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "16",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "15",
          "netId": "control_net_5e01c47f5c29",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "1",
          "netId": "control_net_5e01c47f5c29",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "6",
          "netId": "control_net_48fcc210d1f6",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "7",
          "netId": "control_net_282ba042f616",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "9",
          "netId": "control_net_acd932993b7b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "15",
          "netId": "control_net_2f56e21bf1c8",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "5",
          "netId": "control_net_e9062516eb43",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "16",
          "netId": "control_net_e9062516eb43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "6",
          "netId": "control_net_d24d5fdebd2d",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "3",
          "netId": "control_net_c20b4b863473",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "8",
          "netId": "control_net_c20b4b863473",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "1",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "16",
          "netId": "control_net_adcb6c1bfe2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "8",
          "netId": "control_net_2595b3f207c1",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "5",
          "netId": "control_net_3e8175ead30c",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "15",
          "netId": "control_net_928a45524bd4",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "6",
          "netId": "control_net_45c19501bad5",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "9",
          "netId": "control_net_45c19501bad5",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "15",
          "netId": "control_net_db3c5d849c82",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "1",
          "netId": "control_net_db3c5d849c82",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "1",
          "netId": "control_net_b211580c8101",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "1",
          "netId": "control_net_4aefa7bda0e0",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "7",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "8",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "7",
          "netId": "control_net_c8a58330532e",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "4",
          "netId": "control_net_a3db8189ec60",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "1",
          "netId": "control_net_ad6ab5928142",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "16",
          "netId": "control_net_ad6ab5928142",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "3",
          "netId": "control_net_cc7e68c63366",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "2",
          "netId": "control_net_d948d4dd3369",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "4",
          "netId": "control_net_fbc93a9a1f13",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "1",
          "netId": "control_net_fbc93a9a1f13",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "3",
          "netId": "control_net_bb256500c151",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "8",
          "netId": "control_net_bb256500c151",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "2",
          "netId": "control_net_323da0f3bc1f",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "9",
          "netId": "control_net_323da0f3bc1f",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "6",
          "netId": "control_net_39c83bb6d20e",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "9",
          "netId": "control_net_39c83bb6d20e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "2",
          "netId": "control_net_dcf3a56694f7",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "9",
          "netId": "control_net_dcf3a56694f7",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "7",
          "netId": "control_net_a275f9d9677f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "4",
          "netId": "control_net_aad969376bf0",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "5",
          "netId": "control_net_e85cee5f43f2",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбор источника, банка и полярности",
      "text": "Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "body": "Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике. Связь с соседним узлом показана цепями MAT_SRC_A1, MAT_WRITE_SAFE, MAT_SERVICE_SAFE, MAT_BL_A4.",
      "nodes": [
        "sheet1600",
        "sheet1300"
      ],
      "edges": [
        "sheet1300_sheet1600"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_53c8d7c2e621",
        "control_net_69c914a4b819",
        "control_net_209d9624cc4d",
        "control_net_24511a425a2f",
        "control_net_3f65bb4e6c1b",
        "control_net_1548c2f283f9",
        "control_net_17e2493797cd",
        "control_net_5a48e06ad240",
        "control_net_c3b957dc2a05"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "9",
          "netId": "control_net_69c914a4b819",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "16",
          "netId": "control_net_24511a425a2f",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "1",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1319",
          "pin": "2",
          "netId": "control_net_1548c2f283f9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "16",
          "netId": "control_net_1548c2f283f9",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "11",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "20",
          "netId": "control_net_17e2493797cd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "1",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "10",
          "netId": "control_net_5a48e06ad240",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбор строк и измерительных линий",
      "text": "U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата. Связь с соседним узлом показана цепями MAT_WL_ON_5, MAT_WL_ON_7, MAT_WL_ON_6, MAT_NL_ZERO_1.",
      "body": "U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата. Связь с соседним узлом показана цепями MAT_WL_ON_5, MAT_WL_ON_7, MAT_WL_ON_6, MAT_NL_ZERO_1.",
      "nodes": [
        "sheet1700",
        "sheet1400"
      ],
      "edges": [
        "sheet1400_sheet1700"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_6597f27cfc2b",
        "control_net_52153a3ca99d",
        "control_net_45ab5f0aea68",
        "control_net_09be2b97e593",
        "control_net_1f62e25a43f4",
        "control_net_6cd7e17461df",
        "control_net_582519679d90",
        "control_net_03726fa80526",
        "control_net_18924996523a",
        "control_net_86b7951f0b9b",
        "control_net_6f8884418f43",
        "control_net_be1982fe6067",
        "control_net_b2b91481bc2e",
        "control_net_a335d291d1da",
        "control_net_df58d9efe6ea",
        "control_net_c04b6da19edd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1408",
          "pin": "5",
          "netId": "control_net_6597f27cfc2b",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "10",
          "netId": "control_net_6597f27cfc2b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "7",
          "netId": "control_net_52153a3ca99d",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "20",
          "netId": "control_net_52153a3ca99d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "6",
          "netId": "control_net_45ab5f0aea68",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "11",
          "netId": "control_net_45ab5f0aea68",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "16",
          "netId": "control_net_09be2b97e593",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "3",
          "netId": "control_net_1f62e25a43f4",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "20",
          "netId": "control_net_1f62e25a43f4",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "1",
          "netId": "control_net_6cd7e17461df",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "1",
          "netId": "control_net_582519679d90",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "15",
          "netId": "control_net_03726fa80526",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "1",
          "netId": "control_net_03726fa80526",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "4",
          "netId": "control_net_18924996523a",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1701",
          "pin": "1",
          "netId": "control_net_18924996523a",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "9",
          "netId": "control_net_86b7951f0b9b",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "1",
          "netId": "control_net_6f8884418f43",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "10",
          "netId": "control_net_6f8884418f43",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "8",
          "netId": "control_net_be1982fe6067",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "2",
          "netId": "control_net_b2b91481bc2e",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1700",
          "pin": "11",
          "netId": "control_net_b2b91481bc2e",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "16",
          "netId": "control_net_a335d291d1da",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1702",
          "pin": "9",
          "netId": "control_net_df58d9efe6ea",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1703",
          "pin": "8",
          "netId": "control_net_c04b6da19edd",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подключение экспериментальной матрицы",
      "text": "J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня. Связь с соседним узлом показана цепями BL5, BL12, BL7, BL8.",
      "body": "J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня. Связь с соседним узлом показана цепями BL5, BL12, BL7, BL8.",
      "nodes": [
        "sheet1800",
        "sheet1500"
      ],
      "edges": [
        "sheet1500_sheet1800"
      ],
      "sceneId": "control-routing",
      "netIds": [
        "control_net_410ce51ce77b",
        "control_net_5b7588c91934",
        "control_net_96843655892a",
        "control_net_ef57e67af6ee",
        "control_net_a38212b18dab",
        "control_net_cb9a53bc7e2d",
        "control_net_b1a7be433721",
        "control_net_5a6f03bbf06c",
        "control_net_f237bfeb4d31",
        "control_net_7deb95e626ac",
        "control_net_dee259c78870",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_9aa6ed5fa484",
        "control_net_af268a134ce7",
        "control_net_2661b7e1d1d8",
        "control_net_7443657d6bc7",
        "control_net_8c1f7a16a91f",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_77eb74275447",
        "control_net_331bcbe5832b",
        "control_net_da64d12ab5ef",
        "control_net_668f023fd21c",
        "control_net_15a5f03664b6",
        "control_net_0066c578f4fd",
        "control_net_ae5aa8c25d68",
        "control_net_76481426c5c9",
        "control_net_36b8e2744fa2",
        "control_net_06c41da37048",
        "control_net_093450c5090e",
        "control_net_a3c1624fed4f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1503",
          "pin": "15",
          "netId": "control_net_410ce51ce77b",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "59",
          "netId": "control_net_410ce51ce77b",
          "name": "BL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "52",
          "netId": "control_net_5b7588c91934",
          "name": "BL12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "7",
          "netId": "control_net_96843655892a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "57",
          "netId": "control_net_96843655892a",
          "name": "BL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "2",
          "netId": "control_net_ef57e67af6ee",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "56",
          "netId": "control_net_ef57e67af6ee",
          "name": "BL8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "7",
          "netId": "control_net_a38212b18dab",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "53",
          "netId": "control_net_a38212b18dab",
          "name": "BL11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "23",
          "netId": "control_net_cb9a53bc7e2d",
          "name": "BL22",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "10",
          "netId": "control_net_b1a7be433721",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "54",
          "netId": "control_net_b1a7be433721",
          "name": "BL10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "28",
          "netId": "control_net_5a6f03bbf06c",
          "name": "BL27",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "21",
          "netId": "control_net_f237bfeb4d31",
          "name": "BL20",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "2",
          "netId": "control_net_7deb95e626ac",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "29",
          "netId": "control_net_7deb95e626ac",
          "name": "BL28",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1506",
          "pin": "15",
          "netId": "control_net_dee259c78870",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "55",
          "netId": "control_net_dee259c78870",
          "name": "BL9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "2",
          "netId": "control_net_30db039e0318",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "60",
          "netId": "control_net_30db039e0318",
          "name": "BL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "7",
          "netId": "control_net_538bdbb480c1",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "7",
          "netId": "control_net_538bdbb480c1",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "61",
          "netId": "control_net_538bdbb480c1",
          "name": "BL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "49",
          "netId": "control_net_9aa6ed5fa484",
          "name": "BL15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "2",
          "netId": "control_net_af268a134ce7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "2",
          "netId": "control_net_af268a134ce7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "64",
          "netId": "control_net_af268a134ce7",
          "name": "BL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "50",
          "netId": "control_net_2661b7e1d1d8",
          "name": "BL14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "10",
          "netId": "control_net_7443657d6bc7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "10",
          "netId": "control_net_7443657d6bc7",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "62",
          "netId": "control_net_7443657d6bc7",
          "name": "BL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "15",
          "netId": "control_net_8c1f7a16a91f",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "18",
          "netId": "control_net_8c1f7a16a91f",
          "name": "BL17",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "15",
          "netId": "control_net_9037a6d55684",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "30",
          "netId": "control_net_9037a6d55684",
          "name": "BL29",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "10",
          "netId": "control_net_e59cadbe90ef",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "31",
          "netId": "control_net_e59cadbe90ef",
          "name": "BL30",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1503",
          "pin": "10",
          "netId": "control_net_77eb74275447",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "58",
          "netId": "control_net_77eb74275447",
          "name": "BL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1500",
          "pin": "15",
          "netId": "control_net_331bcbe5832b",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1502",
          "pin": "15",
          "netId": "control_net_331bcbe5832b",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "63",
          "netId": "control_net_331bcbe5832b",
          "name": "BL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "51",
          "netId": "control_net_da64d12ab5ef",
          "name": "BL13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "27",
          "netId": "control_net_668f023fd21c",
          "name": "BL26",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "10",
          "netId": "control_net_15a5f03664b6",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "19",
          "netId": "control_net_15a5f03664b6",
          "name": "BL18",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "24",
          "netId": "control_net_0066c578f4fd",
          "name": "BL23",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1513",
          "pin": "7",
          "netId": "control_net_ae5aa8c25d68",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "32",
          "netId": "control_net_ae5aa8c25d68",
          "name": "BL31",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "2",
          "netId": "control_net_76481426c5c9",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "17",
          "netId": "control_net_76481426c5c9",
          "name": "BL16",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "22",
          "netId": "control_net_36b8e2744fa2",
          "name": "BL21",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "26",
          "netId": "control_net_06c41da37048",
          "name": "BL25",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1508",
          "pin": "7",
          "netId": "control_net_093450c5090e",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "20",
          "netId": "control_net_093450c5090e",
          "name": "BL19",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "25",
          "netId": "control_net_a3c1624fed4f",
          "name": "BL24",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
