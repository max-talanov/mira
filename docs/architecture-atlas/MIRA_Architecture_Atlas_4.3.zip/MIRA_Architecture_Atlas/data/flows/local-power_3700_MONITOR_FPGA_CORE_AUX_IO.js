/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3700_MONITOR_FPGA_CORE_AUX_IO",
  "title": "Как работает: Контроль питания ядра и выводов ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
  "steps": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "core"
      ],
      "edges": [],
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "netIds": [
        "power_net_006931c58e47",
        "power_net_e111331b3c9a",
        "power_net_072a5b0d730e",
        "power_net_67006db669b3",
        "power_net_ef7fb27c478f",
        "power_net_fe627c4721c2",
        "power_net_4aeb4892b398",
        "power_net_717170b9d0c3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3704",
          "pin": "1",
          "netId": "power_net_006931c58e47",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3703",
          "pin": "1",
          "netId": "power_net_006931c58e47",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3704",
          "pin": "2",
          "netId": "power_net_e111331b3c9a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "2",
          "netId": "power_net_e111331b3c9a",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3701",
          "pin": "1",
          "netId": "power_net_072a5b0d730e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3701",
          "pin": "3",
          "netId": "power_net_072a5b0d730e",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3701",
          "pin": "1",
          "netId": "power_net_072a5b0d730e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3702",
          "pin": "1",
          "netId": "power_net_072a5b0d730e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3702",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3701",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3701",
          "pin": "2",
          "netId": "power_net_ef7fb27c478f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "7",
          "netId": "power_net_ef7fb27c478f",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "3",
          "netId": "power_net_fe627c4721c2",
          "name": "LIMIT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3703",
          "pin": "1",
          "netId": "power_net_fe627c4721c2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "8",
          "netId": "power_net_717170b9d0c3",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "core",
        "aux18",
        "aux25",
        "io"
      ],
      "edges": [
        "core_aux18",
        "core_aux25",
        "core_io",
        "aux18_aux25",
        "aux18_io",
        "aux25_io"
      ],
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3704",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3702",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3703",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "core",
        "aux18",
        "aux25",
        "io"
      ],
      "edges": [
        "core_aux18",
        "core_aux25",
        "core_io",
        "aux18_aux25",
        "aux18_io",
        "aux25_io"
      ],
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3704",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3702",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3703",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "core"
      ],
      "edges": [],
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "netIds": [
        "power_net_006931c58e47",
        "power_net_e111331b3c9a",
        "power_net_072a5b0d730e",
        "power_net_67006db669b3",
        "power_net_ef7fb27c478f",
        "power_net_fe627c4721c2",
        "power_net_4aeb4892b398",
        "power_net_717170b9d0c3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3704",
          "pin": "1",
          "netId": "power_net_006931c58e47",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3703",
          "pin": "1",
          "netId": "power_net_006931c58e47",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3704",
          "pin": "2",
          "netId": "power_net_e111331b3c9a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "2",
          "netId": "power_net_e111331b3c9a",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3701",
          "pin": "1",
          "netId": "power_net_072a5b0d730e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3701",
          "pin": "3",
          "netId": "power_net_072a5b0d730e",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3701",
          "pin": "1",
          "netId": "power_net_072a5b0d730e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3702",
          "pin": "1",
          "netId": "power_net_072a5b0d730e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3702",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3701",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3701",
          "pin": "2",
          "netId": "power_net_ef7fb27c478f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "7",
          "netId": "power_net_ef7fb27c478f",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "3",
          "netId": "power_net_fe627c4721c2",
          "name": "LIMIT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3703",
          "pin": "1",
          "netId": "power_net_fe627c4721c2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "8",
          "netId": "power_net_717170b9d0c3",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "core",
        "aux18",
        "aux25",
        "io"
      ],
      "edges": [
        "core_aux18",
        "core_aux25",
        "core_io",
        "aux18_aux25",
        "aux18_io",
        "aux25_io"
      ],
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3704",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3702",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3703",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "core",
        "aux18",
        "aux25",
        "io"
      ],
      "edges": [
        "core_aux18",
        "core_aux25",
        "core_io",
        "aux18_aux25",
        "aux18_io",
        "aux25_io"
      ],
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3704",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3702",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3703",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
