/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3500_MONITOR_INPUT_AON_USB_SYS",
  "title": "Как работает: Контроль входа и системного питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
  "steps": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "input"
      ],
      "edges": [],
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_0fe4a14369c8",
        "power_net_8174cad108e5",
        "power_net_46d0d8d77ef1",
        "power_net_80ed0592af12",
        "power_net_e14830d3e0bb",
        "power_net_2edfdc10f209"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C3502",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3501",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "1",
          "netId": "power_net_0fe4a14369c8",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3504",
          "pin": "1",
          "netId": "power_net_0fe4a14369c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "3",
          "netId": "power_net_8174cad108e5",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3501",
          "pin": "2",
          "netId": "power_net_46d0d8d77ef1",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3503",
          "pin": "1",
          "netId": "power_net_80ed0592af12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3502",
          "pin": "2",
          "netId": "power_net_80ed0592af12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3501",
          "pin": "3",
          "netId": "power_net_80ed0592af12",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3501",
          "pin": "1",
          "netId": "power_net_80ed0592af12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3503",
          "pin": "1",
          "netId": "power_net_e14830d3e0bb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3504",
          "pin": "2",
          "netId": "power_net_e14830d3e0bb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3501",
          "pin": "1",
          "netId": "power_net_2edfdc10f209",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3502",
          "pin": "1",
          "netId": "power_net_2edfdc10f209",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "input",
        "aon",
        "usb",
        "system"
      ],
      "edges": [
        "aon_usb",
        "aon_system",
        "usb_system"
      ],
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3503",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3504",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3502",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "input",
        "aon",
        "usb",
        "system"
      ],
      "edges": [
        "aon_usb",
        "aon_system",
        "usb_system"
      ],
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3503",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3504",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3502",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "input"
      ],
      "edges": [],
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_0fe4a14369c8",
        "power_net_8174cad108e5",
        "power_net_46d0d8d77ef1",
        "power_net_80ed0592af12",
        "power_net_e14830d3e0bb",
        "power_net_2edfdc10f209"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C3502",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3501",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "1",
          "netId": "power_net_0fe4a14369c8",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3504",
          "pin": "1",
          "netId": "power_net_0fe4a14369c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "3",
          "netId": "power_net_8174cad108e5",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3501",
          "pin": "2",
          "netId": "power_net_46d0d8d77ef1",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3503",
          "pin": "1",
          "netId": "power_net_80ed0592af12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3502",
          "pin": "2",
          "netId": "power_net_80ed0592af12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3501",
          "pin": "3",
          "netId": "power_net_80ed0592af12",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3501",
          "pin": "1",
          "netId": "power_net_80ed0592af12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3503",
          "pin": "1",
          "netId": "power_net_e14830d3e0bb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3504",
          "pin": "2",
          "netId": "power_net_e14830d3e0bb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3501",
          "pin": "1",
          "netId": "power_net_2edfdc10f209",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3502",
          "pin": "1",
          "netId": "power_net_2edfdc10f209",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "input",
        "aon",
        "usb",
        "system"
      ],
      "edges": [
        "aon_usb",
        "aon_system",
        "usb_system"
      ],
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3503",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3504",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3502",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "input",
        "aon",
        "usb",
        "system"
      ],
      "edges": [
        "aon_usb",
        "aon_system",
        "usb_system"
      ],
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3503",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3504",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3502",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
