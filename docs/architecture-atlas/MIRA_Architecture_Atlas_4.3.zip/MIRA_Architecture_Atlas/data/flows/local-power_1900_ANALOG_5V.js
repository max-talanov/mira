/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_1900_ANALOG_5V",
  "title": "Как работает: Малошумящее аналоговое питание 5 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_1900_ANALOG_5V",
  "steps": [
    {
      "title": "На вход приходит ANA6",
      "text": "Шина ANA6 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина ANA6 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "9",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "10",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_664171b20ecf",
        "power_net_f8cf954155c7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1901",
          "pin": "1",
          "netId": "power_net_664171b20ecf",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "7",
          "netId": "power_net_f8cf954155c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1901",
          "pin": "2",
          "netId": "power_net_f8cf954155c7",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1901",
          "pin": "1",
          "netId": "power_net_f8cf954155c7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует ANA5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину ANA5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину ANA5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_99aaef80128f",
        "power_net_664171b20ecf",
        "power_net_f5932d689562",
        "power_net_4716fe94234d",
        "power_net_d033005e565e",
        "power_net_f8cf954155c7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "5",
          "netId": "power_net_99aaef80128f",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1902",
          "pin": "1",
          "netId": "power_net_99aaef80128f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1906",
          "pin": "1",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1905",
          "pin": "2",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "2",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1904",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1903",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1905",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1903",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "3",
          "netId": "power_net_d033005e565e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1904",
          "pin": "2",
          "netId": "power_net_d033005e565e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1904",
          "pin": "1",
          "netId": "power_net_d033005e565e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1903",
          "pin": "2",
          "netId": "power_net_d033005e565e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "7",
          "netId": "power_net_f8cf954155c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования ANA5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования ANA5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_f5932d689562"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1906",
          "pin": "1",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1905",
          "pin": "2",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит ANA6",
      "text": "Шина ANA6 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина ANA6 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "9",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "10",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_664171b20ecf",
        "power_net_f8cf954155c7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1901",
          "pin": "1",
          "netId": "power_net_664171b20ecf",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "7",
          "netId": "power_net_f8cf954155c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1901",
          "pin": "2",
          "netId": "power_net_f8cf954155c7",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1901",
          "pin": "1",
          "netId": "power_net_f8cf954155c7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует ANA5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину ANA5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину ANA5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_99aaef80128f",
        "power_net_664171b20ecf",
        "power_net_f5932d689562",
        "power_net_4716fe94234d",
        "power_net_d033005e565e",
        "power_net_f8cf954155c7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "5",
          "netId": "power_net_99aaef80128f",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1902",
          "pin": "1",
          "netId": "power_net_99aaef80128f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1906",
          "pin": "1",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1905",
          "pin": "2",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "2",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1904",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1903",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1905",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1903",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "3",
          "netId": "power_net_d033005e565e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1904",
          "pin": "2",
          "netId": "power_net_d033005e565e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1904",
          "pin": "1",
          "netId": "power_net_d033005e565e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1903",
          "pin": "2",
          "netId": "power_net_d033005e565e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "7",
          "netId": "power_net_f8cf954155c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования ANA5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования ANA5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1900_ANALOG_5V",
      "netIds": [
        "power_net_f5932d689562"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1906",
          "pin": "1",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1905",
          "pin": "2",
          "netId": "power_net_f5932d689562",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
