/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "ethernet-local-rx",
  "title": "Ethernet: подробный приём",
  "description": "Посмотрите, как сигнал в кабеле превращается в параллельные цифровые данные.",
  "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "steps": [
    {
      "title": "Сигнал на разъёме",
      "text": "Кабельный сигнал поступает в разъём RJ45 J900. Здесь это аналоговый сигнал физического уровня.",
      "body": "Кабельный сигнал поступает в разъём RJ45 J900. Здесь это аналоговый сигнал физического уровня.",
      "nodes": [
        "connector"
      ],
      "edges": [],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_352fe6713403",
        "control_net_d0b95aef42d1",
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9",
        "control_net_a66b4051999a",
        "control_net_bd3f491e3f16"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "SH",
          "netId": "control_net_352fe6713403",
          "name": "Shield",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R921",
          "pin": "2",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C937",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "2",
          "netId": "control_net_d0b95aef42d1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "10",
          "netId": "control_net_a66b4051999a",
          "name": "Green_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "12",
          "netId": "control_net_bd3f491e3f16",
          "name": "Yellow_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Прохождение гальванической развязки",
      "text": "T900 передаёт сигнал физического уровня магнитной связью между стороной кабеля и стороной PHY.",
      "body": "T900 передаёт сигнал физического уровня магнитной связью между стороной кабеля и стороной PHY.",
      "nodes": [
        "connector",
        "isolation"
      ],
      "edges": [
        "connector_isolation_0"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "24",
          "netId": "control_net_eb689a40d9d8",
          "name": "MXA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "22",
          "netId": "control_net_a0be4ca78cf4",
          "name": "MXA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "21",
          "netId": "control_net_783e9d027a80",
          "name": "MXB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "18",
          "netId": "control_net_e72d81f71514",
          "name": "MXC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "16",
          "netId": "control_net_75386a9fba9e",
          "name": "MXC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "19",
          "netId": "control_net_40965b12abcc",
          "name": "MXB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "15",
          "netId": "control_net_46a7e4543439",
          "name": "MXD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "13",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "MXD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Приём физического сигнала",
      "text": "U902 принимает физический сигнал и выдаёт цифровые данные. Учебная анимация условно показывает кабельный сигнал без воспроизведения его точного кодирования.",
      "body": "U902 принимает физический сигнал и выдаёт цифровые данные. Учебная анимация условно показывает кабельный сигнал без воспроизведения его точного кодирования.",
      "nodes": [
        "isolation",
        "phy"
      ],
      "edges": [
        "isolation_phy_1"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_e227481650c4",
        "control_net_2b9e82ff1f9a",
        "control_net_b7668147936d",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_c7652af8ac7f",
        "control_net_c06d53ceafd7",
        "control_net_c72c6f1d768f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U902",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TD_P_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TDC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "8",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TD_M_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "9",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TDC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TD_P_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TDA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "2",
          "netId": "control_net_f14d9beef5b0",
          "name": "TD_M_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "3",
          "netId": "control_net_f14d9beef5b0",
          "name": "TDA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TD_P_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TDB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "5",
          "netId": "control_net_c7652af8ac7f",
          "name": "TD_M_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "6",
          "netId": "control_net_c7652af8ac7f",
          "name": "TDB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TD_P_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TDD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "11",
          "netId": "control_net_c72c6f1d768f",
          "name": "TD_M_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "12",
          "netId": "control_net_c72c6f1d768f",
          "name": "TDD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Передача цифровых данных приёма",
      "text": "PHY_RXC, PHY_RX_CTL и PHY_RXD0…3 соединяют PHY с U500. Выберите линию, чтобы увидеть конкретные выводы и представление сигналов.",
      "body": "PHY_RXC, PHY_RX_CTL и PHY_RXD0…3 соединяют PHY с U500. Выберите линию, чтобы увидеть конкретные выводы и представление сигналов.",
      "nodes": [
        "phy",
        "fpga"
      ],
      "edges": [
        "phy_fpga_2"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R910",
          "pin": "1",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R909",
          "pin": "2",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R912",
          "pin": "1",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R911",
          "pin": "2",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обработка кадра",
      "text": "Выбранная реализация MAC и протоколов внутри системы на ПЛИС обрабатывает принятый кадр.",
      "body": "Выбранная реализация MAC и протоколов внутри системы на ПЛИС обрабатывает принятый кадр.",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_d586ee5fe950",
        "control_net_14e361774b31",
        "control_net_20b74826bb9f",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_ff9ff859ce5e",
        "control_net_c9c89af3970f",
        "control_net_101ecb817b3a",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_a4fbe32e37cd",
        "control_net_e0b8d44e15a9",
        "control_net_c491c2114b69",
        "control_net_8441e3506dc3",
        "control_net_feb9c68fc359",
        "control_net_b754ba5a60da",
        "control_net_af615c537cb1",
        "control_net_e83c3c7df2de",
        "control_net_3e9631f7c6ff",
        "control_net_7289e1b08835",
        "control_net_e773796fd1f6",
        "control_net_5cb04db620b0",
        "control_net_06de98680544",
        "control_net_66a9597ad7c2",
        "control_net_d00f8c30fd72",
        "control_net_e53226ed313e",
        "control_net_e7865782b189",
        "control_net_e39e2c0118dc",
        "control_net_0d1a4f8df7dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_6f005443ad9c",
        "control_net_882df4161e30"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA11",
          "netId": "control_net_d586ee5fe950",
          "name": "IO_L9N_T1_DQS_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "1",
          "netId": "control_net_c9c89af3970f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T14",
          "netId": "control_net_a4fbe32e37cd",
          "name": "IO_L15P_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T15",
          "netId": "control_net_e0b8d44e15a9",
          "name": "IO_L15N_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T16",
          "netId": "control_net_c491c2114b69",
          "name": "IO_L17P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U15",
          "netId": "control_net_8441e3506dc3",
          "name": "IO_L14P_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U16",
          "netId": "control_net_feb9c68fc359",
          "name": "IO_L17N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V10",
          "netId": "control_net_b754ba5a60da",
          "name": "IO_L10P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V14",
          "netId": "control_net_e83c3c7df2de",
          "name": "IO_L13N_T2_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V15",
          "netId": "control_net_3e9631f7c6ff",
          "name": "IO_L14N_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W10",
          "netId": "control_net_7289e1b08835",
          "name": "IO_L10N_T1_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W12",
          "netId": "control_net_5cb04db620b0",
          "name": "IO_L12N_T1_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W15",
          "netId": "control_net_66a9597ad7c2",
          "name": "IO_L16P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W16",
          "netId": "control_net_d00f8c30fd72",
          "name": "IO_L16N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y11",
          "netId": "control_net_e53226ed313e",
          "name": "IO_L11P_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y12",
          "netId": "control_net_e7865782b189",
          "name": "IO_L11N_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C904",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C902",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C900",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C905",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C901",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C903",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "2",
          "netId": "control_net_882df4161e30",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Сигнал на разъёме",
      "text": "Кабельный сигнал поступает в разъём RJ45 J900. Здесь это аналоговый сигнал физического уровня.",
      "body": "Кабельный сигнал поступает в разъём RJ45 J900. Здесь это аналоговый сигнал физического уровня.",
      "nodes": [
        "connector"
      ],
      "edges": [],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_352fe6713403",
        "control_net_d0b95aef42d1",
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9",
        "control_net_a66b4051999a",
        "control_net_bd3f491e3f16"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "SH",
          "netId": "control_net_352fe6713403",
          "name": "Shield",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R921",
          "pin": "2",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C937",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "2",
          "netId": "control_net_d0b95aef42d1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "10",
          "netId": "control_net_a66b4051999a",
          "name": "Green_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "12",
          "netId": "control_net_bd3f491e3f16",
          "name": "Yellow_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Прохождение гальванической развязки",
      "text": "T900 передаёт сигнал физического уровня магнитной связью между стороной кабеля и стороной PHY.",
      "body": "T900 передаёт сигнал физического уровня магнитной связью между стороной кабеля и стороной PHY.",
      "nodes": [
        "connector",
        "isolation"
      ],
      "edges": [
        "connector_isolation_0"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "24",
          "netId": "control_net_eb689a40d9d8",
          "name": "MXA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "22",
          "netId": "control_net_a0be4ca78cf4",
          "name": "MXA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "21",
          "netId": "control_net_783e9d027a80",
          "name": "MXB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "18",
          "netId": "control_net_e72d81f71514",
          "name": "MXC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "16",
          "netId": "control_net_75386a9fba9e",
          "name": "MXC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "19",
          "netId": "control_net_40965b12abcc",
          "name": "MXB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "15",
          "netId": "control_net_46a7e4543439",
          "name": "MXD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "13",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "MXD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Приём физического сигнала",
      "text": "U902 принимает физический сигнал и выдаёт цифровые данные. Учебная анимация условно показывает кабельный сигнал без воспроизведения его точного кодирования.",
      "body": "U902 принимает физический сигнал и выдаёт цифровые данные. Учебная анимация условно показывает кабельный сигнал без воспроизведения его точного кодирования.",
      "nodes": [
        "isolation",
        "phy"
      ],
      "edges": [
        "isolation_phy_1"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_e227481650c4",
        "control_net_2b9e82ff1f9a",
        "control_net_b7668147936d",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_c7652af8ac7f",
        "control_net_c06d53ceafd7",
        "control_net_c72c6f1d768f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U902",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TD_P_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TDC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "8",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TD_M_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "9",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TDC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TD_P_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TDA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "2",
          "netId": "control_net_f14d9beef5b0",
          "name": "TD_M_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "3",
          "netId": "control_net_f14d9beef5b0",
          "name": "TDA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TD_P_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TDB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "5",
          "netId": "control_net_c7652af8ac7f",
          "name": "TD_M_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "6",
          "netId": "control_net_c7652af8ac7f",
          "name": "TDB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TD_P_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TDD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "11",
          "netId": "control_net_c72c6f1d768f",
          "name": "TD_M_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "12",
          "netId": "control_net_c72c6f1d768f",
          "name": "TDD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Передача цифровых данных приёма",
      "text": "PHY_RXC, PHY_RX_CTL и PHY_RXD0…3 соединяют PHY с U500. Выберите линию, чтобы увидеть конкретные выводы и представление сигналов.",
      "body": "PHY_RXC, PHY_RX_CTL и PHY_RXD0…3 соединяют PHY с U500. Выберите линию, чтобы увидеть конкретные выводы и представление сигналов.",
      "nodes": [
        "phy",
        "fpga"
      ],
      "edges": [
        "phy_fpga_2"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R910",
          "pin": "1",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R909",
          "pin": "2",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R912",
          "pin": "1",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R911",
          "pin": "2",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обработка кадра",
      "text": "Выбранная реализация MAC и протоколов внутри системы на ПЛИС обрабатывает принятый кадр.",
      "body": "Выбранная реализация MAC и протоколов внутри системы на ПЛИС обрабатывает принятый кадр.",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_d586ee5fe950",
        "control_net_14e361774b31",
        "control_net_20b74826bb9f",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_ff9ff859ce5e",
        "control_net_c9c89af3970f",
        "control_net_101ecb817b3a",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_a4fbe32e37cd",
        "control_net_e0b8d44e15a9",
        "control_net_c491c2114b69",
        "control_net_8441e3506dc3",
        "control_net_feb9c68fc359",
        "control_net_b754ba5a60da",
        "control_net_af615c537cb1",
        "control_net_e83c3c7df2de",
        "control_net_3e9631f7c6ff",
        "control_net_7289e1b08835",
        "control_net_e773796fd1f6",
        "control_net_5cb04db620b0",
        "control_net_06de98680544",
        "control_net_66a9597ad7c2",
        "control_net_d00f8c30fd72",
        "control_net_e53226ed313e",
        "control_net_e7865782b189",
        "control_net_e39e2c0118dc",
        "control_net_0d1a4f8df7dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_6f005443ad9c",
        "control_net_882df4161e30"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA11",
          "netId": "control_net_d586ee5fe950",
          "name": "IO_L9N_T1_DQS_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "1",
          "netId": "control_net_c9c89af3970f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T14",
          "netId": "control_net_a4fbe32e37cd",
          "name": "IO_L15P_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T15",
          "netId": "control_net_e0b8d44e15a9",
          "name": "IO_L15N_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T16",
          "netId": "control_net_c491c2114b69",
          "name": "IO_L17P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U15",
          "netId": "control_net_8441e3506dc3",
          "name": "IO_L14P_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U16",
          "netId": "control_net_feb9c68fc359",
          "name": "IO_L17N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V10",
          "netId": "control_net_b754ba5a60da",
          "name": "IO_L10P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V14",
          "netId": "control_net_e83c3c7df2de",
          "name": "IO_L13N_T2_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V15",
          "netId": "control_net_3e9631f7c6ff",
          "name": "IO_L14N_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W10",
          "netId": "control_net_7289e1b08835",
          "name": "IO_L10N_T1_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W12",
          "netId": "control_net_5cb04db620b0",
          "name": "IO_L12N_T1_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W15",
          "netId": "control_net_66a9597ad7c2",
          "name": "IO_L16P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W16",
          "netId": "control_net_d00f8c30fd72",
          "name": "IO_L16N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y11",
          "netId": "control_net_e53226ed313e",
          "name": "IO_L11P_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y12",
          "netId": "control_net_e7865782b189",
          "name": "IO_L11N_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C904",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C902",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C900",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C905",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C901",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C903",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "2",
          "netId": "control_net_882df4161e30",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
