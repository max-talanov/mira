/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "matrix-write",
  "title": "Запрограммировать ячейку матрицы",
  "description": "Посмотрите, как ограничивается воздействие записи и фиксируется коммутация. Конкретные параметры импульса зависят от исследуемой ячейки.",
  "sceneId": "system",
  "steps": [
    {
      "title": "Подготовка ограничений напряжения и тока",
      "text": "Запрошенные условия записи преобразуются в уставки ЦАП для общего источника.",
      "body": "Запрошенные условия записи преобразуются в уставки ЦАП для общего источника.",
      "nodes": [
        "fpga",
        "drive"
      ],
      "edges": [
        "fpga_drive"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "5",
          "netId": "control_net_90accaec6322",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка операции",
      "text": "Аппаратные разрешения должны соответствовать зафиксированному запросу.",
      "body": "Аппаратные разрешения должны соответствовать зафиксированному запросу.",
      "nodes": [
        "safety",
        "fpga",
        "matrix"
      ],
      "edges": [
        "fpga_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подача воздействия записи",
      "text": "Выбранная коммутация подключает регулируемый источник для запрошенной операции.",
      "body": "Выбранная коммутация подключает регулируемый источник для запрошенной операции.",
      "nodes": [
        "drive",
        "matrix"
      ],
      "edges": [
        "drive_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль операции",
      "text": "Независимая защита продолжает контролировать ток источника и состояние конфигурации.",
      "body": "Независимая защита продолжает контролировать ток источника и состояние конфигурации.",
      "nodes": [
        "matrix",
        "safety"
      ],
      "edges": [
        "matrix_safety"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d4a1fffbf6b9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Завершение и проверка",
      "text": "После записи операцией чтения можно измерить полученное состояние.",
      "body": "После записи операцией чтения можно измерить полученное состояние.",
      "nodes": [
        "matrix",
        "readout",
        "fpga"
      ],
      "edges": [
        "matrix_readout",
        "readout_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d65f00f0a2d4",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Подготовка ограничений напряжения и тока",
      "text": "Запрошенные условия записи преобразуются в уставки ЦАП для общего источника.",
      "body": "Запрошенные условия записи преобразуются в уставки ЦАП для общего источника.",
      "nodes": [
        "fpga",
        "drive"
      ],
      "edges": [
        "fpga_drive"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "5",
          "netId": "control_net_90accaec6322",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка операции",
      "text": "Аппаратные разрешения должны соответствовать зафиксированному запросу.",
      "body": "Аппаратные разрешения должны соответствовать зафиксированному запросу.",
      "nodes": [
        "safety",
        "fpga",
        "matrix"
      ],
      "edges": [
        "fpga_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подача воздействия записи",
      "text": "Выбранная коммутация подключает регулируемый источник для запрошенной операции.",
      "body": "Выбранная коммутация подключает регулируемый источник для запрошенной операции.",
      "nodes": [
        "drive",
        "matrix"
      ],
      "edges": [
        "drive_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль операции",
      "text": "Независимая защита продолжает контролировать ток источника и состояние конфигурации.",
      "body": "Независимая защита продолжает контролировать ток источника и состояние конфигурации.",
      "nodes": [
        "matrix",
        "safety"
      ],
      "edges": [
        "matrix_safety"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d4a1fffbf6b9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Завершение и проверка",
      "text": "После записи операцией чтения можно измерить полученное состояние.",
      "body": "После записи операцией чтения можно измерить полученное состояние.",
      "nodes": [
        "matrix",
        "readout",
        "fpga"
      ],
      "edges": [
        "matrix_readout",
        "readout_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d65f00f0a2d4",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
