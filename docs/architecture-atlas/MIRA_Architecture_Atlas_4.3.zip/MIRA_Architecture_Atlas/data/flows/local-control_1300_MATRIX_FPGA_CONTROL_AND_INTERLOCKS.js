/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "title": "Как работает: Проверка согласованности операции",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "steps": [
    {
      "title": "Приходит запрос операции",
      "text": "ПЛИС выставляет запрашиваемые режимы, адреса и управляющие сигналы. До разрешения коммутации запрос должен пройти аппаратную проверку.",
      "body": "ПЛИС выставляет запрашиваемые режимы, адреса и управляющие сигналы. До разрешения коммутации запрос должен пройти аппаратную проверку.",
      "nodes": [
        "fpga",
        "capture"
      ],
      "edges": [
        "fpga_capture"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "E3",
          "netId": "control_net_2690ba9f85c2",
          "name": "IO_L6N_T0_VREF_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "9",
          "netId": "control_net_2690ba9f85c2",
          "name": "D7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F1",
          "netId": "control_net_1060da4e1062",
          "name": "IO_L5N_T0_AD13N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "7",
          "netId": "control_net_1060da4e1062",
          "name": "D5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F3",
          "netId": "control_net_8e945f7df341",
          "name": "IO_L6P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "8",
          "netId": "control_net_8e945f7df341",
          "name": "D6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G1",
          "netId": "control_net_103f84ec6132",
          "name": "IO_L5P_T0_AD13P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "6",
          "netId": "control_net_103f84ec6132",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G2",
          "netId": "control_net_c6ecade8f839",
          "name": "IO_L8N_T1_AD14N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "5",
          "netId": "control_net_c6ecade8f839",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G3",
          "netId": "control_net_8e9184bc5c46",
          "name": "IO_L11N_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "4",
          "netId": "control_net_8e9184bc5c46",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H2",
          "netId": "control_net_ba2ab40384c6",
          "name": "IO_L8P_T1_AD14P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "4",
          "netId": "control_net_ba2ab40384c6",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H4",
          "netId": "control_net_c254fca78b2c",
          "name": "IO_L12P_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "5",
          "netId": "control_net_c254fca78b2c",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J1",
          "netId": "control_net_f16f12a0707d",
          "name": "IO_L7N_T1_AD6N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "3",
          "netId": "control_net_f16f12a0707d",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J2",
          "netId": "control_net_d095506d8145",
          "name": "IO_L9N_T1_DQS_AD7N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "2",
          "netId": "control_net_d095506d8145",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J5",
          "netId": "control_net_df16aaaa5404",
          "name": "IO_L10P_T1_AD15P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "3",
          "netId": "control_net_df16aaaa5404",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K1",
          "netId": "control_net_2a00cc654f3d",
          "name": "IO_L7P_T1_AD6P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "2",
          "netId": "control_net_2a00cc654f3d",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K2",
          "netId": "control_net_5130997c4fe8",
          "name": "IO_L9P_T1_DQS_AD7P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "6",
          "netId": "control_net_5130997c4fe8",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Параметры фиксируются",
      "text": "Регистры удерживают поля активной операции. Компараторы сопоставляют текущий запрос с зафиксированными полями и выявляют изменение конфигурации.",
      "body": "Регистры удерживают поля активной операции. Компараторы сопоставляют текущий запрос с зафиксированными полями и выявляют изменение конфигурации.",
      "nodes": [
        "capture",
        "compare"
      ],
      "edges": [
        "capture_compare"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_5f9f5680becf",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_942f92e36dcb",
        "control_net_c3b957dc2a05",
        "control_net_53c8d7c2e621",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_5a48e06ad240",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46",
        "control_net_3f65bb4e6c1b",
        "control_net_24511a425a2f",
        "control_net_558e432b5f50",
        "control_net_12757af1d119",
        "control_net_7a2e58dd0886",
        "control_net_b0ef82a04563"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1328",
          "pin": "12",
          "netId": "control_net_5f9f5680becf",
          "name": "Q7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "18",
          "netId": "control_net_5f9f5680becf",
          "name": "Q7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "13",
          "netId": "control_net_6e69a2fb065e",
          "name": "Q6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "16",
          "netId": "control_net_6e69a2fb065e",
          "name": "Q6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "14",
          "netId": "control_net_8e443662774e",
          "name": "Q5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "14",
          "netId": "control_net_8e443662774e",
          "name": "Q5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "8",
          "netId": "control_net_93d867935f6d",
          "name": "D6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "15",
          "netId": "control_net_93d867935f6d",
          "name": "P6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "9",
          "netId": "control_net_2690ba9f85c2",
          "name": "D7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "17",
          "netId": "control_net_2690ba9f85c2",
          "name": "P7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "7",
          "netId": "control_net_1060da4e1062",
          "name": "D5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "13",
          "netId": "control_net_1060da4e1062",
          "name": "P5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "8",
          "netId": "control_net_8e945f7df341",
          "name": "D6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "15",
          "netId": "control_net_8e945f7df341",
          "name": "P6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "6",
          "netId": "control_net_103f84ec6132",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "11",
          "netId": "control_net_103f84ec6132",
          "name": "P4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "5",
          "netId": "control_net_c6ecade8f839",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "8",
          "netId": "control_net_c6ecade8f839",
          "name": "P3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "4",
          "netId": "control_net_8e9184bc5c46",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "6",
          "netId": "control_net_8e9184bc5c46",
          "name": "P2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "4",
          "netId": "control_net_ba2ab40384c6",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "6",
          "netId": "control_net_ba2ab40384c6",
          "name": "P2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "5",
          "netId": "control_net_c254fca78b2c",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "8",
          "netId": "control_net_c254fca78b2c",
          "name": "P3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "3",
          "netId": "control_net_f16f12a0707d",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "4",
          "netId": "control_net_f16f12a0707d",
          "name": "P1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "2",
          "netId": "control_net_d095506d8145",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "2",
          "netId": "control_net_d095506d8145",
          "name": "P0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "3",
          "netId": "control_net_df16aaaa5404",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "4",
          "netId": "control_net_df16aaaa5404",
          "name": "P1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "2",
          "netId": "control_net_2a00cc654f3d",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "2",
          "netId": "control_net_2a00cc654f3d",
          "name": "P0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "6",
          "netId": "control_net_5130997c4fe8",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "11",
          "netId": "control_net_5130997c4fe8",
          "name": "P4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "7",
          "netId": "control_net_942f92e36dcb",
          "name": "D5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "13",
          "netId": "control_net_942f92e36dcb",
          "name": "P5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "19",
          "netId": "control_net_c3b957dc2a05",
          "name": "Q0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "3",
          "netId": "control_net_c3b957dc2a05",
          "name": "Q0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "18",
          "netId": "control_net_53c8d7c2e621",
          "name": "Q1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "5",
          "netId": "control_net_53c8d7c2e621",
          "name": "Q1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "17",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "Q2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "7",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "Q2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "16",
          "netId": "control_net_4cbb94b58c81",
          "name": "Q3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "9",
          "netId": "control_net_4cbb94b58c81",
          "name": "Q3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "15",
          "netId": "control_net_5a48e06ad240",
          "name": "Q4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "12",
          "netId": "control_net_5a48e06ad240",
          "name": "Q4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "14",
          "netId": "control_net_11d0bca5a9c3",
          "name": "Q5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "14",
          "netId": "control_net_11d0bca5a9c3",
          "name": "Q5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "13",
          "netId": "control_net_5adbbaca70af",
          "name": "Q6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "Q6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "12",
          "netId": "control_net_5d5a8a88fb46",
          "name": "Q7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "18",
          "netId": "control_net_5d5a8a88fb46",
          "name": "Q7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "19",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "Q0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "3",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "Q0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "18",
          "netId": "control_net_24511a425a2f",
          "name": "Q1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "5",
          "netId": "control_net_24511a425a2f",
          "name": "Q1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "17",
          "netId": "control_net_558e432b5f50",
          "name": "Q2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "7",
          "netId": "control_net_558e432b5f50",
          "name": "Q2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "16",
          "netId": "control_net_12757af1d119",
          "name": "Q3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "9",
          "netId": "control_net_12757af1d119",
          "name": "Q3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "15",
          "netId": "control_net_7a2e58dd0886",
          "name": "Q4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "12",
          "netId": "control_net_7a2e58dd0886",
          "name": "Q4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "9",
          "netId": "control_net_b0ef82a04563",
          "name": "D7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "17",
          "netId": "control_net_b0ef82a04563",
          "name": "P7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверяется разрешение",
      "text": "Логика объединяет питание, режим и аппаратные блокировки. Учебный сценарий показывает связи условий, не устанавливая все входы в единицу.",
      "body": "Логика объединяет питание, режим и аппаратные блокировки. Учебный сценарий показывает связи условий, не устанавливая все входы в единицу.",
      "nodes": [
        "compare",
        "permissions"
      ],
      "edges": [
        "compare_permissions"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_5f9f5680becf",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_942f92e36dcb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1304",
          "pin": "6",
          "netId": "control_net_5f9f5680becf",
          "name": "C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "18",
          "netId": "control_net_5f9f5680becf",
          "name": "Q7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1316",
          "pin": "2",
          "netId": "control_net_6e69a2fb065e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "16",
          "netId": "control_net_6e69a2fb065e",
          "name": "Q6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1310",
          "pin": "2",
          "netId": "control_net_8e443662774e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "14",
          "netId": "control_net_8e443662774e",
          "name": "Q5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1314",
          "pin": "4",
          "netId": "control_net_93d867935f6d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1325",
          "pin": "1",
          "netId": "control_net_93d867935f6d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "15",
          "netId": "control_net_93d867935f6d",
          "name": "P6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1308",
          "pin": "4",
          "netId": "control_net_942f92e36dcb",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1323",
          "pin": "1",
          "netId": "control_net_942f92e36dcb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1324",
          "pin": "1",
          "netId": "control_net_942f92e36dcb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "13",
          "netId": "control_net_942f92e36dcb",
          "name": "P5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Формируются сигналы маршрутизации",
      "text": "Дешифрация удерживаемых полей выбирает разрешённые направления и безопасные состояния коммутации.",
      "body": "Дешифрация удерживаемых полей выбирает разрешённые направления и безопасные состояния коммутации.",
      "nodes": [
        "permissions",
        "decode"
      ],
      "edges": [
        "permissions_decode"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_b544695cd7b3",
        "control_net_49fde52ce0ed",
        "control_net_2e40141f478d",
        "control_net_87fe3b573357",
        "control_net_6e69a2fb065e",
        "control_net_a263c7c6e291",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_390c067b3ead",
        "control_net_ae0baa487445",
        "control_net_4680bd4e9f98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1305",
          "pin": "2",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1316",
          "pin": "1",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1310",
          "pin": "1",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1311",
          "pin": "1",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1348",
          "pin": "4",
          "netId": "control_net_b544695cd7b3",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1304",
          "pin": "4",
          "netId": "control_net_49fde52ce0ed",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1302",
          "pin": "2",
          "netId": "control_net_49fde52ce0ed",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1344",
          "pin": "1",
          "netId": "control_net_49fde52ce0ed",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1348",
          "pin": "1",
          "netId": "control_net_49fde52ce0ed",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1349",
          "pin": "1",
          "netId": "control_net_49fde52ce0ed",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1301",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1331",
          "pin": "4",
          "netId": "control_net_2e40141f478d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1301",
          "pin": "2",
          "netId": "control_net_87fe3b573357",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1336",
          "pin": "4",
          "netId": "control_net_87fe3b573357",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1316",
          "pin": "2",
          "netId": "control_net_6e69a2fb065e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1338",
          "pin": "2",
          "netId": "control_net_6e69a2fb065e",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1317",
          "pin": "2",
          "netId": "control_net_a263c7c6e291",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1338",
          "pin": "4",
          "netId": "control_net_a263c7c6e291",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1344",
          "pin": "6",
          "netId": "control_net_a263c7c6e291",
          "name": "C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1310",
          "pin": "2",
          "netId": "control_net_8e443662774e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1337",
          "pin": "2",
          "netId": "control_net_8e443662774e",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1344",
          "pin": "3",
          "netId": "control_net_8e443662774e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1314",
          "pin": "4",
          "netId": "control_net_93d867935f6d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1325",
          "pin": "1",
          "netId": "control_net_93d867935f6d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1333",
          "pin": "1",
          "netId": "control_net_93d867935f6d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1318",
          "pin": "2",
          "netId": "control_net_d846a1ae0de8",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1345",
          "pin": "2",
          "netId": "control_net_d846a1ae0de8",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1302",
          "pin": "2",
          "netId": "control_net_0831bf7686e1",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1331",
          "pin": "2",
          "netId": "control_net_0831bf7686e1",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1311",
          "pin": "2",
          "netId": "control_net_390c067b3ead",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1337",
          "pin": "4",
          "netId": "control_net_390c067b3ead",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1309",
          "pin": "4",
          "netId": "control_net_ae0baa487445",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1323",
          "pin": "2",
          "netId": "control_net_ae0baa487445",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1334",
          "pin": "1",
          "netId": "control_net_ae0baa487445",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1326",
          "pin": "4",
          "netId": "control_net_4680bd4e9f98",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1335",
          "pin": "1",
          "netId": "control_net_4680bd4e9f98",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Приходит запрос операции",
      "text": "ПЛИС выставляет запрашиваемые режимы, адреса и управляющие сигналы. До разрешения коммутации запрос должен пройти аппаратную проверку.",
      "body": "ПЛИС выставляет запрашиваемые режимы, адреса и управляющие сигналы. До разрешения коммутации запрос должен пройти аппаратную проверку.",
      "nodes": [
        "fpga",
        "capture"
      ],
      "edges": [
        "fpga_capture"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "E3",
          "netId": "control_net_2690ba9f85c2",
          "name": "IO_L6N_T0_VREF_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "9",
          "netId": "control_net_2690ba9f85c2",
          "name": "D7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F1",
          "netId": "control_net_1060da4e1062",
          "name": "IO_L5N_T0_AD13N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "7",
          "netId": "control_net_1060da4e1062",
          "name": "D5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F3",
          "netId": "control_net_8e945f7df341",
          "name": "IO_L6P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "8",
          "netId": "control_net_8e945f7df341",
          "name": "D6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G1",
          "netId": "control_net_103f84ec6132",
          "name": "IO_L5P_T0_AD13P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "6",
          "netId": "control_net_103f84ec6132",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G2",
          "netId": "control_net_c6ecade8f839",
          "name": "IO_L8N_T1_AD14N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "5",
          "netId": "control_net_c6ecade8f839",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G3",
          "netId": "control_net_8e9184bc5c46",
          "name": "IO_L11N_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "4",
          "netId": "control_net_8e9184bc5c46",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H2",
          "netId": "control_net_ba2ab40384c6",
          "name": "IO_L8P_T1_AD14P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "4",
          "netId": "control_net_ba2ab40384c6",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H4",
          "netId": "control_net_c254fca78b2c",
          "name": "IO_L12P_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "5",
          "netId": "control_net_c254fca78b2c",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J1",
          "netId": "control_net_f16f12a0707d",
          "name": "IO_L7N_T1_AD6N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "3",
          "netId": "control_net_f16f12a0707d",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J2",
          "netId": "control_net_d095506d8145",
          "name": "IO_L9N_T1_DQS_AD7N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "2",
          "netId": "control_net_d095506d8145",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J5",
          "netId": "control_net_df16aaaa5404",
          "name": "IO_L10P_T1_AD15P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "3",
          "netId": "control_net_df16aaaa5404",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K1",
          "netId": "control_net_2a00cc654f3d",
          "name": "IO_L7P_T1_AD6P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "2",
          "netId": "control_net_2a00cc654f3d",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K2",
          "netId": "control_net_5130997c4fe8",
          "name": "IO_L9P_T1_DQS_AD7P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "6",
          "netId": "control_net_5130997c4fe8",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Параметры фиксируются",
      "text": "Регистры удерживают поля активной операции. Компараторы сопоставляют текущий запрос с зафиксированными полями и выявляют изменение конфигурации.",
      "body": "Регистры удерживают поля активной операции. Компараторы сопоставляют текущий запрос с зафиксированными полями и выявляют изменение конфигурации.",
      "nodes": [
        "capture",
        "compare"
      ],
      "edges": [
        "capture_compare"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_5f9f5680becf",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_942f92e36dcb",
        "control_net_c3b957dc2a05",
        "control_net_53c8d7c2e621",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_5a48e06ad240",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46",
        "control_net_3f65bb4e6c1b",
        "control_net_24511a425a2f",
        "control_net_558e432b5f50",
        "control_net_12757af1d119",
        "control_net_7a2e58dd0886",
        "control_net_b0ef82a04563"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1328",
          "pin": "12",
          "netId": "control_net_5f9f5680becf",
          "name": "Q7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "18",
          "netId": "control_net_5f9f5680becf",
          "name": "Q7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "13",
          "netId": "control_net_6e69a2fb065e",
          "name": "Q6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "16",
          "netId": "control_net_6e69a2fb065e",
          "name": "Q6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "14",
          "netId": "control_net_8e443662774e",
          "name": "Q5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "14",
          "netId": "control_net_8e443662774e",
          "name": "Q5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "8",
          "netId": "control_net_93d867935f6d",
          "name": "D6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "15",
          "netId": "control_net_93d867935f6d",
          "name": "P6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "9",
          "netId": "control_net_2690ba9f85c2",
          "name": "D7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "17",
          "netId": "control_net_2690ba9f85c2",
          "name": "P7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "7",
          "netId": "control_net_1060da4e1062",
          "name": "D5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "13",
          "netId": "control_net_1060da4e1062",
          "name": "P5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "8",
          "netId": "control_net_8e945f7df341",
          "name": "D6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "15",
          "netId": "control_net_8e945f7df341",
          "name": "P6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "6",
          "netId": "control_net_103f84ec6132",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "11",
          "netId": "control_net_103f84ec6132",
          "name": "P4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "5",
          "netId": "control_net_c6ecade8f839",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "8",
          "netId": "control_net_c6ecade8f839",
          "name": "P3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "4",
          "netId": "control_net_8e9184bc5c46",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "6",
          "netId": "control_net_8e9184bc5c46",
          "name": "P2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "4",
          "netId": "control_net_ba2ab40384c6",
          "name": "D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "6",
          "netId": "control_net_ba2ab40384c6",
          "name": "P2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "5",
          "netId": "control_net_c254fca78b2c",
          "name": "D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "8",
          "netId": "control_net_c254fca78b2c",
          "name": "P3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "3",
          "netId": "control_net_f16f12a0707d",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "4",
          "netId": "control_net_f16f12a0707d",
          "name": "P1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "2",
          "netId": "control_net_d095506d8145",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "2",
          "netId": "control_net_d095506d8145",
          "name": "P0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "3",
          "netId": "control_net_df16aaaa5404",
          "name": "D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "4",
          "netId": "control_net_df16aaaa5404",
          "name": "P1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "2",
          "netId": "control_net_2a00cc654f3d",
          "name": "D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "2",
          "netId": "control_net_2a00cc654f3d",
          "name": "P0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "6",
          "netId": "control_net_5130997c4fe8",
          "name": "D4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "11",
          "netId": "control_net_5130997c4fe8",
          "name": "P4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "7",
          "netId": "control_net_942f92e36dcb",
          "name": "D5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "13",
          "netId": "control_net_942f92e36dcb",
          "name": "P5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "19",
          "netId": "control_net_c3b957dc2a05",
          "name": "Q0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "3",
          "netId": "control_net_c3b957dc2a05",
          "name": "Q0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "18",
          "netId": "control_net_53c8d7c2e621",
          "name": "Q1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "5",
          "netId": "control_net_53c8d7c2e621",
          "name": "Q1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "17",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "Q2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "7",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "Q2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "16",
          "netId": "control_net_4cbb94b58c81",
          "name": "Q3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "9",
          "netId": "control_net_4cbb94b58c81",
          "name": "Q3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "15",
          "netId": "control_net_5a48e06ad240",
          "name": "Q4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "12",
          "netId": "control_net_5a48e06ad240",
          "name": "Q4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "14",
          "netId": "control_net_11d0bca5a9c3",
          "name": "Q5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "14",
          "netId": "control_net_11d0bca5a9c3",
          "name": "Q5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "13",
          "netId": "control_net_5adbbaca70af",
          "name": "Q6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "Q6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1327",
          "pin": "12",
          "netId": "control_net_5d5a8a88fb46",
          "name": "Q7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1329",
          "pin": "18",
          "netId": "control_net_5d5a8a88fb46",
          "name": "Q7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "19",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "Q0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "3",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "Q0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "18",
          "netId": "control_net_24511a425a2f",
          "name": "Q1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "5",
          "netId": "control_net_24511a425a2f",
          "name": "Q1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "17",
          "netId": "control_net_558e432b5f50",
          "name": "Q2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "7",
          "netId": "control_net_558e432b5f50",
          "name": "Q2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "16",
          "netId": "control_net_12757af1d119",
          "name": "Q3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "9",
          "netId": "control_net_12757af1d119",
          "name": "Q3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "15",
          "netId": "control_net_7a2e58dd0886",
          "name": "Q4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "12",
          "netId": "control_net_7a2e58dd0886",
          "name": "Q4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1328",
          "pin": "9",
          "netId": "control_net_b0ef82a04563",
          "name": "D7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "17",
          "netId": "control_net_b0ef82a04563",
          "name": "P7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверяется разрешение",
      "text": "Логика объединяет питание, режим и аппаратные блокировки. Учебный сценарий показывает связи условий, не устанавливая все входы в единицу.",
      "body": "Логика объединяет питание, режим и аппаратные блокировки. Учебный сценарий показывает связи условий, не устанавливая все входы в единицу.",
      "nodes": [
        "compare",
        "permissions"
      ],
      "edges": [
        "compare_permissions"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_5f9f5680becf",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_942f92e36dcb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1304",
          "pin": "6",
          "netId": "control_net_5f9f5680becf",
          "name": "C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "18",
          "netId": "control_net_5f9f5680becf",
          "name": "Q7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1316",
          "pin": "2",
          "netId": "control_net_6e69a2fb065e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "16",
          "netId": "control_net_6e69a2fb065e",
          "name": "Q6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1310",
          "pin": "2",
          "netId": "control_net_8e443662774e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "14",
          "netId": "control_net_8e443662774e",
          "name": "Q5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1314",
          "pin": "4",
          "netId": "control_net_93d867935f6d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1325",
          "pin": "1",
          "netId": "control_net_93d867935f6d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "15",
          "netId": "control_net_93d867935f6d",
          "name": "P6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1308",
          "pin": "4",
          "netId": "control_net_942f92e36dcb",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1323",
          "pin": "1",
          "netId": "control_net_942f92e36dcb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1324",
          "pin": "1",
          "netId": "control_net_942f92e36dcb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1330",
          "pin": "13",
          "netId": "control_net_942f92e36dcb",
          "name": "P5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Формируются сигналы маршрутизации",
      "text": "Дешифрация удерживаемых полей выбирает разрешённые направления и безопасные состояния коммутации.",
      "body": "Дешифрация удерживаемых полей выбирает разрешённые направления и безопасные состояния коммутации.",
      "nodes": [
        "permissions",
        "decode"
      ],
      "edges": [
        "permissions_decode"
      ],
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "netIds": [
        "control_net_b544695cd7b3",
        "control_net_49fde52ce0ed",
        "control_net_2e40141f478d",
        "control_net_87fe3b573357",
        "control_net_6e69a2fb065e",
        "control_net_a263c7c6e291",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_390c067b3ead",
        "control_net_ae0baa487445",
        "control_net_4680bd4e9f98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1305",
          "pin": "2",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1316",
          "pin": "1",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1310",
          "pin": "1",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1311",
          "pin": "1",
          "netId": "control_net_b544695cd7b3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1348",
          "pin": "4",
          "netId": "control_net_b544695cd7b3",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1304",
          "pin": "4",
          "netId": "control_net_49fde52ce0ed",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1302",
          "pin": "2",
          "netId": "control_net_49fde52ce0ed",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1344",
          "pin": "1",
          "netId": "control_net_49fde52ce0ed",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1348",
          "pin": "1",
          "netId": "control_net_49fde52ce0ed",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1349",
          "pin": "1",
          "netId": "control_net_49fde52ce0ed",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1301",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1331",
          "pin": "4",
          "netId": "control_net_2e40141f478d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1301",
          "pin": "2",
          "netId": "control_net_87fe3b573357",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1336",
          "pin": "4",
          "netId": "control_net_87fe3b573357",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1316",
          "pin": "2",
          "netId": "control_net_6e69a2fb065e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1338",
          "pin": "2",
          "netId": "control_net_6e69a2fb065e",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1317",
          "pin": "2",
          "netId": "control_net_a263c7c6e291",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1338",
          "pin": "4",
          "netId": "control_net_a263c7c6e291",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1344",
          "pin": "6",
          "netId": "control_net_a263c7c6e291",
          "name": "C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1310",
          "pin": "2",
          "netId": "control_net_8e443662774e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1337",
          "pin": "2",
          "netId": "control_net_8e443662774e",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1344",
          "pin": "3",
          "netId": "control_net_8e443662774e",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1314",
          "pin": "4",
          "netId": "control_net_93d867935f6d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1325",
          "pin": "1",
          "netId": "control_net_93d867935f6d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1333",
          "pin": "1",
          "netId": "control_net_93d867935f6d",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1318",
          "pin": "2",
          "netId": "control_net_d846a1ae0de8",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1345",
          "pin": "2",
          "netId": "control_net_d846a1ae0de8",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1302",
          "pin": "2",
          "netId": "control_net_0831bf7686e1",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1331",
          "pin": "2",
          "netId": "control_net_0831bf7686e1",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1311",
          "pin": "2",
          "netId": "control_net_390c067b3ead",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1337",
          "pin": "4",
          "netId": "control_net_390c067b3ead",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1309",
          "pin": "4",
          "netId": "control_net_ae0baa487445",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1323",
          "pin": "2",
          "netId": "control_net_ae0baa487445",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1334",
          "pin": "1",
          "netId": "control_net_ae0baa487445",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1326",
          "pin": "4",
          "netId": "control_net_4680bd4e9f98",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1335",
          "pin": "1",
          "netId": "control_net_4680bd4e9f98",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
