/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control-host",
  "title": "Как работает: Основной контроллер",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control-host",
  "steps": [
    {
      "title": "Основной контроллер · запуск и отладка",
      "text": "U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.",
      "body": "U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.",
      "nodes": [
        "sheet100"
      ],
      "edges": [],
      "sceneId": "control-host",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_6d1eda208f89",
        "control_net_e478289ae762",
        "control_net_750a12d376b8",
        "control_net_834cc395c2cf",
        "control_net_1ff0abfccce6",
        "control_net_0cbb519cdc03",
        "control_net_9529eebe621c",
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369",
        "control_net_7a4e5a463be4",
        "control_net_eb78380551ed",
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_c9cd9704b4c3",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420",
        "control_net_3a8a8e9ba9d6",
        "control_net_0d904964f307",
        "control_net_9610b0f12f0e",
        "control_net_71b2a4afb8e1",
        "control_net_c7f569a62e51",
        "control_net_c60541bbd47d",
        "control_net_2b7b5312ecd1",
        "control_net_aceadbfe975f",
        "control_net_60474df9b088",
        "control_net_232acd2cd7a1",
        "control_net_94510af104c3",
        "control_net_54fcb5cad2ac",
        "control_net_e357d45256d6",
        "control_net_5ba854809135",
        "control_net_b6b1c8d164dd",
        "control_net_45181b2521d7",
        "control_net_acf154ccf8d8",
        "control_net_a31a5a2328d9",
        "control_net_b1b80df60d11",
        "control_net_7b7c4f86e406",
        "control_net_5e6a93f92943",
        "control_net_86ac6e45ea88",
        "control_net_0482bc5f18f2",
        "control_net_d7f9459071b9",
        "control_net_cbe2968fbe5f",
        "control_net_a59f90994d29",
        "control_net_5b2506cefd28",
        "control_net_a36112a179b8",
        "control_net_43a6e40b99d4",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_f361f86a0d52",
        "control_net_52b9946b1a9a",
        "control_net_26f00eadb626",
        "control_net_2fe4bf982c96",
        "control_net_ea106f84a091",
        "control_net_d56008be3974",
        "control_net_cc52e369d852",
        "control_net_11ba6105da7e",
        "control_net_c994a6a8c44b",
        "control_net_2e6bb9b818c2",
        "control_net_7938ecff8bfa",
        "control_net_904833ad65a5",
        "control_net_59caeaac06c7",
        "control_net_b198f3103c1b",
        "control_net_1f69faa028f4",
        "control_net_fd3e2e0fadee",
        "control_net_07f2de16aeaf",
        "control_net_b7f24c7efff4",
        "control_net_bf2f5ebca199",
        "control_net_66b853d97583",
        "control_net_f87a72a8ece7",
        "control_net_802aa4569b27",
        "control_net_497868960a10",
        "control_net_f2ad5b3a1b23",
        "control_net_cb5d34db7f7a",
        "control_net_25457d3dd391",
        "control_net_e03d15dc4157",
        "control_net_8726d2dae752",
        "control_net_3a8f32a74ef2",
        "control_net_cf0d706ad175",
        "control_net_57fd38ae982f",
        "control_net_51ade1c12a34",
        "control_net_576d489f596c",
        "control_net_5a1408d6925c",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318",
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_1828c29d5fa6",
        "control_net_64e3b30cda92",
        "control_net_88e82b098d8a",
        "control_net_57814f35c37d",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_df9972435b68",
        "control_net_3974126e88cb",
        "control_net_478ea3ad984d",
        "control_net_2daa98d25e56",
        "control_net_a856887f830b",
        "control_net_f64354686773",
        "control_net_cb711dcd1752",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_c3283ba17c11",
        "control_net_0afe468f72ab",
        "control_net_bfc714f087e0",
        "control_net_c17cd2b70efc",
        "control_net_1611e906fec8",
        "control_net_94be9f57dcd4",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_119d91accf55",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_7f80f60475c4",
        "control_net_86b00c304637",
        "control_net_8377a92cc3c5",
        "control_net_a38bef0f0104"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VTREF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "3V3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "ENABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "2",
          "netId": "control_net_6d1eda208f89",
          "name": "SWDIO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "4",
          "netId": "control_net_e478289ae762",
          "name": "SWCLK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "6",
          "netId": "control_net_750a12d376b8",
          "name": "SWO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "7",
          "netId": "control_net_834cc395c2cf",
          "name": "KEY",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "8",
          "netId": "control_net_1ff0abfccce6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "10",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "1",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "2",
          "netId": "control_net_03fabe1e0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "1",
          "netId": "control_net_78e8fc2cd369",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "32",
          "netId": "control_net_eb78380551ed",
          "name": "PH1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "15",
          "netId": "control_net_c9cd9704b4c3",
          "name": "VLXSMPS",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "2",
          "netId": "control_net_3a8a8e9ba9d6",
          "name": "PE3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "3",
          "netId": "control_net_0d904964f307",
          "name": "PE4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "4",
          "netId": "control_net_9610b0f12f0e",
          "name": "PE5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "5",
          "netId": "control_net_71b2a4afb8e1",
          "name": "PE6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "9",
          "netId": "control_net_c7f569a62e51",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "26",
          "netId": "control_net_c60541bbd47d",
          "name": "PF6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "27",
          "netId": "control_net_2b7b5312ecd1",
          "name": "PF7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "28",
          "netId": "control_net_aceadbfe975f",
          "name": "PF8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "29",
          "netId": "control_net_60474df9b088",
          "name": "PF9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "30",
          "netId": "control_net_232acd2cd7a1",
          "name": "PF10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "35",
          "netId": "control_net_94510af104c3",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "36",
          "netId": "control_net_54fcb5cad2ac",
          "name": "PC2_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "37",
          "netId": "control_net_e357d45256d6",
          "name": "PC3_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "42",
          "netId": "control_net_5ba854809135",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "78",
          "netId": "control_net_b6b1c8d164dd",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "79",
          "netId": "control_net_45181b2521d7",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "85",
          "netId": "control_net_acf154ccf8d8",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "86",
          "netId": "control_net_a31a5a2328d9",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "87",
          "netId": "control_net_b1b80df60d11",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "88",
          "netId": "control_net_7b7c4f86e406",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "101",
          "netId": "control_net_5e6a93f92943",
          "name": "PJ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "102",
          "netId": "control_net_86ac6e45ea88",
          "name": "PJ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "103",
          "netId": "control_net_0482bc5f18f2",
          "name": "PJ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "104",
          "netId": "control_net_d7f9459071b9",
          "name": "PJ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "107",
          "netId": "control_net_cbe2968fbe5f",
          "name": "PK0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "108",
          "netId": "control_net_a59f90994d29",
          "name": "PK1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "109",
          "netId": "control_net_5b2506cefd28",
          "name": "PK2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "111",
          "netId": "control_net_a36112a179b8",
          "name": "PG3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "117",
          "netId": "control_net_43a6e40b99d4",
          "name": "PG7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "130",
          "netId": "control_net_f361f86a0d52",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "131",
          "netId": "control_net_52b9946b1a9a",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "139",
          "netId": "control_net_26f00eadb626",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "146",
          "netId": "control_net_2fe4bf982c96",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "147",
          "netId": "control_net_ea106f84a091",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "148",
          "netId": "control_net_d56008be3974",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "149",
          "netId": "control_net_cc52e369d852",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "150",
          "netId": "control_net_11ba6105da7e",
          "name": "PD7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "153",
          "netId": "control_net_c994a6a8c44b",
          "name": "PG9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "154",
          "netId": "control_net_2e6bb9b818c2",
          "name": "PG10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "155",
          "netId": "control_net_7938ecff8bfa",
          "name": "PG11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "156",
          "netId": "control_net_904833ad65a5",
          "name": "PG12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "157",
          "netId": "control_net_59caeaac06c7",
          "name": "PG13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "158",
          "netId": "control_net_b198f3103c1b",
          "name": "PG14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "163",
          "netId": "control_net_1f69faa028f4",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "164",
          "netId": "control_net_fd3e2e0fadee",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "168",
          "netId": "control_net_07f2de16aeaf",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "169",
          "netId": "control_net_b7f24c7efff4",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "1",
          "netId": "control_net_2daa98d25e56",
          "name": "PE2_/_QSPI_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "41",
          "netId": "control_net_a856887f830b",
          "name": "PA0_/_RESET_FPGA_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "43",
          "netId": "control_net_f64354686773",
          "name": "PA2_/_HOST_UART_TX",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "56",
          "netId": "control_net_c3283ba17c11",
          "name": "PB1_/_HOST_ALIVE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "96",
          "netId": "control_net_1611e906fec8",
          "name": "PD13_/_QSPI_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "165",
          "netId": "control_net_86b00c304637",
          "name": "PB6_/_QSPI_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "166",
          "netId": "control_net_8377a92cc3c5",
          "name": "PB7_/_HOST_WDI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "3",
          "netId": "control_net_a38bef0f0104",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Оперативная память контроллера",
      "text": "Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.",
      "body": "Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.",
      "nodes": [
        "sheet200"
      ],
      "edges": [],
      "sceneId": "control-host",
      "netIds": [
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369",
        "control_net_7a4e5a463be4",
        "control_net_eb78380551ed",
        "control_net_0cbb519cdc03",
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_9529eebe621c",
        "control_net_90c4fa851afd",
        "control_net_c9cd9704b4c3",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420",
        "control_net_3a8a8e9ba9d6",
        "control_net_0d904964f307",
        "control_net_9610b0f12f0e",
        "control_net_71b2a4afb8e1",
        "control_net_c7f569a62e51",
        "control_net_c60541bbd47d",
        "control_net_2b7b5312ecd1",
        "control_net_aceadbfe975f",
        "control_net_60474df9b088",
        "control_net_232acd2cd7a1",
        "control_net_94510af104c3",
        "control_net_54fcb5cad2ac",
        "control_net_e357d45256d6",
        "control_net_5ba854809135",
        "control_net_b6b1c8d164dd",
        "control_net_45181b2521d7",
        "control_net_acf154ccf8d8",
        "control_net_a31a5a2328d9",
        "control_net_b1b80df60d11",
        "control_net_7b7c4f86e406",
        "control_net_5e6a93f92943",
        "control_net_86ac6e45ea88",
        "control_net_0482bc5f18f2",
        "control_net_d7f9459071b9",
        "control_net_cbe2968fbe5f",
        "control_net_a59f90994d29",
        "control_net_5b2506cefd28",
        "control_net_a36112a179b8",
        "control_net_43a6e40b99d4",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_f361f86a0d52",
        "control_net_52b9946b1a9a",
        "control_net_26f00eadb626",
        "control_net_2fe4bf982c96",
        "control_net_ea106f84a091",
        "control_net_d56008be3974",
        "control_net_cc52e369d852",
        "control_net_11ba6105da7e",
        "control_net_c994a6a8c44b",
        "control_net_2e6bb9b818c2",
        "control_net_7938ecff8bfa",
        "control_net_904833ad65a5",
        "control_net_59caeaac06c7",
        "control_net_b198f3103c1b",
        "control_net_1f69faa028f4",
        "control_net_fd3e2e0fadee",
        "control_net_07f2de16aeaf",
        "control_net_b7f24c7efff4",
        "control_net_bf2f5ebca199",
        "control_net_66b853d97583",
        "control_net_f87a72a8ece7",
        "control_net_802aa4569b27",
        "control_net_497868960a10",
        "control_net_f2ad5b3a1b23",
        "control_net_cb5d34db7f7a",
        "control_net_25457d3dd391",
        "control_net_e03d15dc4157",
        "control_net_8726d2dae752",
        "control_net_3a8f32a74ef2",
        "control_net_cf0d706ad175",
        "control_net_57fd38ae982f",
        "control_net_51ade1c12a34",
        "control_net_576d489f596c",
        "control_net_5a1408d6925c",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318",
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_1828c29d5fa6",
        "control_net_64e3b30cda92",
        "control_net_88e82b098d8a",
        "control_net_57814f35c37d",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_df9972435b68",
        "control_net_3974126e88cb",
        "control_net_478ea3ad984d",
        "control_net_2daa98d25e56",
        "control_net_a856887f830b",
        "control_net_f64354686773",
        "control_net_cb711dcd1752",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_c3283ba17c11",
        "control_net_0afe468f72ab",
        "control_net_bfc714f087e0",
        "control_net_c17cd2b70efc",
        "control_net_1611e906fec8",
        "control_net_94be9f57dcd4",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_119d91accf55",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_7f80f60475c4",
        "control_net_86b00c304637",
        "control_net_8377a92cc3c5",
        "control_net_22d2ed5a92b0",
        "control_net_e61f684e2b30",
        "control_net_50fec45c4cfe",
        "control_net_8e2c742867a9",
        "control_net_0d875c33a31d",
        "control_net_a3f957371c3f",
        "control_net_ea2e71d8ad65",
        "control_net_29b779eba1df",
        "control_net_1fb2e0bffca2",
        "control_net_a7ff225fafcc",
        "control_net_b56b3c253467",
        "control_net_7fb3e667afc3",
        "control_net_88a82b0ea167",
        "control_net_6a7ba2287274",
        "control_net_1ab10b21ce8a",
        "control_net_ac77da14ad01",
        "control_net_c768cd02e6fd",
        "control_net_9cec32a3a290",
        "control_net_50162c30e639",
        "control_net_bf332d53cb7b",
        "control_net_5ff18f95d1df",
        "control_net_812a5aa5142f",
        "control_net_ba4358c26b16",
        "control_net_60eebb274bde"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "32",
          "netId": "control_net_eb78380551ed",
          "name": "PH1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "9",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "27",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "43",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "49",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "15",
          "netId": "control_net_c9cd9704b4c3",
          "name": "VLXSMPS",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "2",
          "netId": "control_net_3a8a8e9ba9d6",
          "name": "PE3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "3",
          "netId": "control_net_0d904964f307",
          "name": "PE4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "4",
          "netId": "control_net_9610b0f12f0e",
          "name": "PE5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "5",
          "netId": "control_net_71b2a4afb8e1",
          "name": "PE6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "9",
          "netId": "control_net_c7f569a62e51",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "26",
          "netId": "control_net_c60541bbd47d",
          "name": "PF6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "27",
          "netId": "control_net_2b7b5312ecd1",
          "name": "PF7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "28",
          "netId": "control_net_aceadbfe975f",
          "name": "PF8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "29",
          "netId": "control_net_60474df9b088",
          "name": "PF9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "30",
          "netId": "control_net_232acd2cd7a1",
          "name": "PF10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "35",
          "netId": "control_net_94510af104c3",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "36",
          "netId": "control_net_54fcb5cad2ac",
          "name": "PC2_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "37",
          "netId": "control_net_e357d45256d6",
          "name": "PC3_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "42",
          "netId": "control_net_5ba854809135",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "78",
          "netId": "control_net_b6b1c8d164dd",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "79",
          "netId": "control_net_45181b2521d7",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "85",
          "netId": "control_net_acf154ccf8d8",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "86",
          "netId": "control_net_a31a5a2328d9",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "87",
          "netId": "control_net_b1b80df60d11",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "88",
          "netId": "control_net_7b7c4f86e406",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "101",
          "netId": "control_net_5e6a93f92943",
          "name": "PJ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "102",
          "netId": "control_net_86ac6e45ea88",
          "name": "PJ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "103",
          "netId": "control_net_0482bc5f18f2",
          "name": "PJ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "104",
          "netId": "control_net_d7f9459071b9",
          "name": "PJ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "107",
          "netId": "control_net_cbe2968fbe5f",
          "name": "PK0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "108",
          "netId": "control_net_a59f90994d29",
          "name": "PK1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "109",
          "netId": "control_net_5b2506cefd28",
          "name": "PK2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "111",
          "netId": "control_net_a36112a179b8",
          "name": "PG3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "117",
          "netId": "control_net_43a6e40b99d4",
          "name": "PG7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "130",
          "netId": "control_net_f361f86a0d52",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "131",
          "netId": "control_net_52b9946b1a9a",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "139",
          "netId": "control_net_26f00eadb626",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "146",
          "netId": "control_net_2fe4bf982c96",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "147",
          "netId": "control_net_ea106f84a091",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "148",
          "netId": "control_net_d56008be3974",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "149",
          "netId": "control_net_cc52e369d852",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "150",
          "netId": "control_net_11ba6105da7e",
          "name": "PD7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "153",
          "netId": "control_net_c994a6a8c44b",
          "name": "PG9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "154",
          "netId": "control_net_2e6bb9b818c2",
          "name": "PG10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "155",
          "netId": "control_net_7938ecff8bfa",
          "name": "PG11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "156",
          "netId": "control_net_904833ad65a5",
          "name": "PG12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "157",
          "netId": "control_net_59caeaac06c7",
          "name": "PG13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "158",
          "netId": "control_net_b198f3103c1b",
          "name": "PG14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "163",
          "netId": "control_net_1f69faa028f4",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "164",
          "netId": "control_net_fd3e2e0fadee",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "168",
          "netId": "control_net_07f2de16aeaf",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "169",
          "netId": "control_net_b7f24c7efff4",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "8",
          "netId": "control_net_e8c9dc419d80",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "10",
          "netId": "control_net_c3d2e7b446eb",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "11",
          "netId": "control_net_3f3c225eebe4",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "13",
          "netId": "control_net_4fca7f1d1465",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "42",
          "netId": "control_net_1643db7ef9f9",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "44",
          "netId": "control_net_a3813a077889",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "45",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "47",
          "netId": "control_net_4ddbefaae88b",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "48",
          "netId": "control_net_c16e9f400334",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "50",
          "netId": "control_net_98b1a2522dce",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "51",
          "netId": "control_net_5c8668fc4b07",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "53",
          "netId": "control_net_a0420c81d318",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "2",
          "netId": "control_net_30b951256d65",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "4",
          "netId": "control_net_05f1cce27675",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "5",
          "netId": "control_net_dbb7c66b055c",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "7",
          "netId": "control_net_71220214496a",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "1",
          "netId": "control_net_2daa98d25e56",
          "name": "PE2_/_QSPI_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "41",
          "netId": "control_net_a856887f830b",
          "name": "PA0_/_RESET_FPGA_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "43",
          "netId": "control_net_f64354686773",
          "name": "PA2_/_HOST_UART_TX",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "56",
          "netId": "control_net_c3283ba17c11",
          "name": "PB1_/_HOST_ALIVE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "96",
          "netId": "control_net_1611e906fec8",
          "name": "PD13_/_QSPI_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "165",
          "netId": "control_net_86b00c304637",
          "name": "PB6_/_QSPI_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "166",
          "netId": "control_net_8377a92cc3c5",
          "name": "PB7_/_HOST_WDI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "15",
          "netId": "control_net_22d2ed5a92b0",
          "name": "DQML",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "16",
          "netId": "control_net_e61f684e2b30",
          "name": "WE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "17",
          "netId": "control_net_50fec45c4cfe",
          "name": "CAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "18",
          "netId": "control_net_8e2c742867a9",
          "name": "RAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "19",
          "netId": "control_net_0d875c33a31d",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "20",
          "netId": "control_net_a3f957371c3f",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "21",
          "netId": "control_net_ea2e71d8ad65",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "22",
          "netId": "control_net_29b779eba1df",
          "name": "A10",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "23",
          "netId": "control_net_1fb2e0bffca2",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "24",
          "netId": "control_net_a7ff225fafcc",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "25",
          "netId": "control_net_b56b3c253467",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "26",
          "netId": "control_net_7fb3e667afc3",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "29",
          "netId": "control_net_88a82b0ea167",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "30",
          "netId": "control_net_6a7ba2287274",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "31",
          "netId": "control_net_1ab10b21ce8a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "32",
          "netId": "control_net_ac77da14ad01",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "33",
          "netId": "control_net_c768cd02e6fd",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "34",
          "netId": "control_net_9cec32a3a290",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "35",
          "netId": "control_net_50162c30e639",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "36",
          "netId": "control_net_bf332d53cb7b",
          "name": "A12",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "37",
          "netId": "control_net_5ff18f95d1df",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "38",
          "netId": "control_net_812a5aa5142f",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "39",
          "netId": "control_net_ba4358c26b16",
          "name": "DQMH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "40",
          "netId": "control_net_60eebb274bde",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Память и управление платой",
      "text": "U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.",
      "body": "U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.",
      "nodes": [
        "sheet300"
      ],
      "edges": [],
      "sceneId": "control-host",
      "netIds": [
        "control_net_f8ba31d3ca5d",
        "control_net_e9412c7c775b",
        "control_net_90c4fa851afd",
        "control_net_1ae330a90d69",
        "control_net_f71e7f09f53c",
        "control_net_dbb8a4cebc4d",
        "control_net_db8bb0491f21",
        "control_net_7c39dc0aa14d",
        "control_net_a6d0f4299492",
        "control_net_3b1f11e0f454",
        "control_net_cecba30ce2a4",
        "control_net_93c2464e4d4b",
        "control_net_c5c0c804ee45",
        "control_net_3c2ea5987a7b",
        "control_net_e5dd58f5bdde",
        "control_net_94be9f57dcd4",
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369",
        "control_net_7a4e5a463be4",
        "control_net_eb78380551ed",
        "control_net_0cbb519cdc03",
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_9529eebe621c",
        "control_net_c9cd9704b4c3",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420",
        "control_net_3a8a8e9ba9d6",
        "control_net_0d904964f307",
        "control_net_9610b0f12f0e",
        "control_net_71b2a4afb8e1",
        "control_net_c7f569a62e51",
        "control_net_c60541bbd47d",
        "control_net_2b7b5312ecd1",
        "control_net_aceadbfe975f",
        "control_net_60474df9b088",
        "control_net_232acd2cd7a1",
        "control_net_94510af104c3",
        "control_net_54fcb5cad2ac",
        "control_net_e357d45256d6",
        "control_net_5ba854809135",
        "control_net_b6b1c8d164dd",
        "control_net_45181b2521d7",
        "control_net_acf154ccf8d8",
        "control_net_a31a5a2328d9",
        "control_net_b1b80df60d11",
        "control_net_7b7c4f86e406",
        "control_net_5e6a93f92943",
        "control_net_86ac6e45ea88",
        "control_net_0482bc5f18f2",
        "control_net_d7f9459071b9",
        "control_net_cbe2968fbe5f",
        "control_net_a59f90994d29",
        "control_net_5b2506cefd28",
        "control_net_a36112a179b8",
        "control_net_43a6e40b99d4",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_f361f86a0d52",
        "control_net_52b9946b1a9a",
        "control_net_26f00eadb626",
        "control_net_2fe4bf982c96",
        "control_net_ea106f84a091",
        "control_net_d56008be3974",
        "control_net_cc52e369d852",
        "control_net_11ba6105da7e",
        "control_net_c994a6a8c44b",
        "control_net_2e6bb9b818c2",
        "control_net_7938ecff8bfa",
        "control_net_904833ad65a5",
        "control_net_59caeaac06c7",
        "control_net_b198f3103c1b",
        "control_net_1f69faa028f4",
        "control_net_fd3e2e0fadee",
        "control_net_07f2de16aeaf",
        "control_net_b7f24c7efff4",
        "control_net_bf2f5ebca199",
        "control_net_66b853d97583",
        "control_net_f87a72a8ece7",
        "control_net_802aa4569b27",
        "control_net_497868960a10",
        "control_net_f2ad5b3a1b23",
        "control_net_cb5d34db7f7a",
        "control_net_25457d3dd391",
        "control_net_e03d15dc4157",
        "control_net_8726d2dae752",
        "control_net_3a8f32a74ef2",
        "control_net_cf0d706ad175",
        "control_net_57fd38ae982f",
        "control_net_51ade1c12a34",
        "control_net_576d489f596c",
        "control_net_5a1408d6925c",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318",
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_1828c29d5fa6",
        "control_net_64e3b30cda92",
        "control_net_88e82b098d8a",
        "control_net_57814f35c37d",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_df9972435b68",
        "control_net_3974126e88cb",
        "control_net_478ea3ad984d",
        "control_net_2daa98d25e56",
        "control_net_a856887f830b",
        "control_net_f64354686773",
        "control_net_cb711dcd1752",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_c3283ba17c11",
        "control_net_0afe468f72ab",
        "control_net_bfc714f087e0",
        "control_net_c17cd2b70efc",
        "control_net_1611e906fec8",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_119d91accf55",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_7f80f60475c4",
        "control_net_86b00c304637",
        "control_net_8377a92cc3c5",
        "control_net_6142364b688a",
        "control_net_8228e1434880",
        "control_net_2f35b14c7892",
        "control_net_ac6272a32078"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U301",
          "pin": "1",
          "netId": "control_net_f8ba31d3ca5d",
          "name": "IO1_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "6",
          "netId": "control_net_f8ba31d3ca5d",
          "name": "IO1_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "3",
          "netId": "control_net_e9412c7c775b",
          "name": "IO2_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "4",
          "netId": "control_net_e9412c7c775b",
          "name": "IO2_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "2",
          "netId": "control_net_f71e7f09f53c",
          "name": "DO_/_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "3",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "WP_N_/_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "5",
          "netId": "control_net_db8bb0491f21",
          "name": "DI_/_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "6",
          "netId": "control_net_7c39dc0aa14d",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "7",
          "netId": "control_net_a6d0f4299492",
          "name": "HOLD_N_/_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "1",
          "netId": "control_net_3b1f11e0f454",
          "name": "DAT2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "2",
          "netId": "control_net_cecba30ce2a4",
          "name": "DAT3_/_CD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "3",
          "netId": "control_net_93c2464e4d4b",
          "name": "CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "5",
          "netId": "control_net_c5c0c804ee45",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "7",
          "netId": "control_net_3c2ea5987a7b",
          "name": "DAT0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "8",
          "netId": "control_net_e5dd58f5bdde",
          "name": "DAT1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "9",
          "netId": "control_net_94be9f57dcd4",
          "name": "DETECT1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "32",
          "netId": "control_net_eb78380551ed",
          "name": "PH1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "15",
          "netId": "control_net_c9cd9704b4c3",
          "name": "VLXSMPS",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "2",
          "netId": "control_net_3a8a8e9ba9d6",
          "name": "PE3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "3",
          "netId": "control_net_0d904964f307",
          "name": "PE4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "4",
          "netId": "control_net_9610b0f12f0e",
          "name": "PE5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "5",
          "netId": "control_net_71b2a4afb8e1",
          "name": "PE6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "9",
          "netId": "control_net_c7f569a62e51",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "26",
          "netId": "control_net_c60541bbd47d",
          "name": "PF6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "27",
          "netId": "control_net_2b7b5312ecd1",
          "name": "PF7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "28",
          "netId": "control_net_aceadbfe975f",
          "name": "PF8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "29",
          "netId": "control_net_60474df9b088",
          "name": "PF9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "30",
          "netId": "control_net_232acd2cd7a1",
          "name": "PF10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "35",
          "netId": "control_net_94510af104c3",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "36",
          "netId": "control_net_54fcb5cad2ac",
          "name": "PC2_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "37",
          "netId": "control_net_e357d45256d6",
          "name": "PC3_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "42",
          "netId": "control_net_5ba854809135",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "78",
          "netId": "control_net_b6b1c8d164dd",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "79",
          "netId": "control_net_45181b2521d7",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "85",
          "netId": "control_net_acf154ccf8d8",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "86",
          "netId": "control_net_a31a5a2328d9",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "87",
          "netId": "control_net_b1b80df60d11",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "88",
          "netId": "control_net_7b7c4f86e406",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "101",
          "netId": "control_net_5e6a93f92943",
          "name": "PJ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "102",
          "netId": "control_net_86ac6e45ea88",
          "name": "PJ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "103",
          "netId": "control_net_0482bc5f18f2",
          "name": "PJ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "104",
          "netId": "control_net_d7f9459071b9",
          "name": "PJ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "107",
          "netId": "control_net_cbe2968fbe5f",
          "name": "PK0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "108",
          "netId": "control_net_a59f90994d29",
          "name": "PK1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "109",
          "netId": "control_net_5b2506cefd28",
          "name": "PK2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "111",
          "netId": "control_net_a36112a179b8",
          "name": "PG3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "117",
          "netId": "control_net_43a6e40b99d4",
          "name": "PG7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "130",
          "netId": "control_net_f361f86a0d52",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "131",
          "netId": "control_net_52b9946b1a9a",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "139",
          "netId": "control_net_26f00eadb626",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "146",
          "netId": "control_net_2fe4bf982c96",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "147",
          "netId": "control_net_ea106f84a091",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "148",
          "netId": "control_net_d56008be3974",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "149",
          "netId": "control_net_cc52e369d852",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "150",
          "netId": "control_net_11ba6105da7e",
          "name": "PD7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "153",
          "netId": "control_net_c994a6a8c44b",
          "name": "PG9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "154",
          "netId": "control_net_2e6bb9b818c2",
          "name": "PG10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "155",
          "netId": "control_net_7938ecff8bfa",
          "name": "PG11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "156",
          "netId": "control_net_904833ad65a5",
          "name": "PG12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "157",
          "netId": "control_net_59caeaac06c7",
          "name": "PG13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "158",
          "netId": "control_net_b198f3103c1b",
          "name": "PG14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "163",
          "netId": "control_net_1f69faa028f4",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "164",
          "netId": "control_net_fd3e2e0fadee",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "168",
          "netId": "control_net_07f2de16aeaf",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "169",
          "netId": "control_net_b7f24c7efff4",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "1",
          "netId": "control_net_2daa98d25e56",
          "name": "PE2_/_QSPI_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "41",
          "netId": "control_net_a856887f830b",
          "name": "PA0_/_RESET_FPGA_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "43",
          "netId": "control_net_f64354686773",
          "name": "PA2_/_HOST_UART_TX",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "56",
          "netId": "control_net_c3283ba17c11",
          "name": "PB1_/_HOST_ALIVE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "96",
          "netId": "control_net_1611e906fec8",
          "name": "PD13_/_QSPI_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "165",
          "netId": "control_net_86b00c304637",
          "name": "PB6_/_QSPI_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "166",
          "netId": "control_net_8377a92cc3c5",
          "name": "PB7_/_HOST_WDI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "1",
          "netId": "control_net_6142364b688a",
          "name": "IO1_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "6",
          "netId": "control_net_6142364b688a",
          "name": "IO1_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "3",
          "netId": "control_net_8228e1434880",
          "name": "IO2_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "4",
          "netId": "control_net_8228e1434880",
          "name": "IO2_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "1",
          "netId": "control_net_2f35b14c7892",
          "name": "IO1_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "6",
          "netId": "control_net_2f35b14c7892",
          "name": "IO1_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "3",
          "netId": "control_net_ac6272a32078",
          "name": "IO2_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "4",
          "netId": "control_net_ac6272a32078",
          "name": "IO2_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Основной контроллер · запуск и отладка",
      "text": "U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.",
      "body": "U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.",
      "nodes": [
        "sheet100"
      ],
      "edges": [],
      "sceneId": "control-host",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_6d1eda208f89",
        "control_net_e478289ae762",
        "control_net_750a12d376b8",
        "control_net_834cc395c2cf",
        "control_net_1ff0abfccce6",
        "control_net_0cbb519cdc03",
        "control_net_9529eebe621c",
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369",
        "control_net_7a4e5a463be4",
        "control_net_eb78380551ed",
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_c9cd9704b4c3",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420",
        "control_net_3a8a8e9ba9d6",
        "control_net_0d904964f307",
        "control_net_9610b0f12f0e",
        "control_net_71b2a4afb8e1",
        "control_net_c7f569a62e51",
        "control_net_c60541bbd47d",
        "control_net_2b7b5312ecd1",
        "control_net_aceadbfe975f",
        "control_net_60474df9b088",
        "control_net_232acd2cd7a1",
        "control_net_94510af104c3",
        "control_net_54fcb5cad2ac",
        "control_net_e357d45256d6",
        "control_net_5ba854809135",
        "control_net_b6b1c8d164dd",
        "control_net_45181b2521d7",
        "control_net_acf154ccf8d8",
        "control_net_a31a5a2328d9",
        "control_net_b1b80df60d11",
        "control_net_7b7c4f86e406",
        "control_net_5e6a93f92943",
        "control_net_86ac6e45ea88",
        "control_net_0482bc5f18f2",
        "control_net_d7f9459071b9",
        "control_net_cbe2968fbe5f",
        "control_net_a59f90994d29",
        "control_net_5b2506cefd28",
        "control_net_a36112a179b8",
        "control_net_43a6e40b99d4",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_f361f86a0d52",
        "control_net_52b9946b1a9a",
        "control_net_26f00eadb626",
        "control_net_2fe4bf982c96",
        "control_net_ea106f84a091",
        "control_net_d56008be3974",
        "control_net_cc52e369d852",
        "control_net_11ba6105da7e",
        "control_net_c994a6a8c44b",
        "control_net_2e6bb9b818c2",
        "control_net_7938ecff8bfa",
        "control_net_904833ad65a5",
        "control_net_59caeaac06c7",
        "control_net_b198f3103c1b",
        "control_net_1f69faa028f4",
        "control_net_fd3e2e0fadee",
        "control_net_07f2de16aeaf",
        "control_net_b7f24c7efff4",
        "control_net_bf2f5ebca199",
        "control_net_66b853d97583",
        "control_net_f87a72a8ece7",
        "control_net_802aa4569b27",
        "control_net_497868960a10",
        "control_net_f2ad5b3a1b23",
        "control_net_cb5d34db7f7a",
        "control_net_25457d3dd391",
        "control_net_e03d15dc4157",
        "control_net_8726d2dae752",
        "control_net_3a8f32a74ef2",
        "control_net_cf0d706ad175",
        "control_net_57fd38ae982f",
        "control_net_51ade1c12a34",
        "control_net_576d489f596c",
        "control_net_5a1408d6925c",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318",
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_1828c29d5fa6",
        "control_net_64e3b30cda92",
        "control_net_88e82b098d8a",
        "control_net_57814f35c37d",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_df9972435b68",
        "control_net_3974126e88cb",
        "control_net_478ea3ad984d",
        "control_net_2daa98d25e56",
        "control_net_a856887f830b",
        "control_net_f64354686773",
        "control_net_cb711dcd1752",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_c3283ba17c11",
        "control_net_0afe468f72ab",
        "control_net_bfc714f087e0",
        "control_net_c17cd2b70efc",
        "control_net_1611e906fec8",
        "control_net_94be9f57dcd4",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_119d91accf55",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_7f80f60475c4",
        "control_net_86b00c304637",
        "control_net_8377a92cc3c5",
        "control_net_a38bef0f0104"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VTREF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "3V3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "ENABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "2",
          "netId": "control_net_6d1eda208f89",
          "name": "SWDIO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "4",
          "netId": "control_net_e478289ae762",
          "name": "SWCLK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "6",
          "netId": "control_net_750a12d376b8",
          "name": "SWO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "7",
          "netId": "control_net_834cc395c2cf",
          "name": "KEY",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "8",
          "netId": "control_net_1ff0abfccce6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "10",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "1",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "2",
          "netId": "control_net_03fabe1e0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "1",
          "netId": "control_net_78e8fc2cd369",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "32",
          "netId": "control_net_eb78380551ed",
          "name": "PH1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "15",
          "netId": "control_net_c9cd9704b4c3",
          "name": "VLXSMPS",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "2",
          "netId": "control_net_3a8a8e9ba9d6",
          "name": "PE3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "3",
          "netId": "control_net_0d904964f307",
          "name": "PE4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "4",
          "netId": "control_net_9610b0f12f0e",
          "name": "PE5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "5",
          "netId": "control_net_71b2a4afb8e1",
          "name": "PE6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "9",
          "netId": "control_net_c7f569a62e51",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "26",
          "netId": "control_net_c60541bbd47d",
          "name": "PF6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "27",
          "netId": "control_net_2b7b5312ecd1",
          "name": "PF7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "28",
          "netId": "control_net_aceadbfe975f",
          "name": "PF8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "29",
          "netId": "control_net_60474df9b088",
          "name": "PF9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "30",
          "netId": "control_net_232acd2cd7a1",
          "name": "PF10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "35",
          "netId": "control_net_94510af104c3",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "36",
          "netId": "control_net_54fcb5cad2ac",
          "name": "PC2_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "37",
          "netId": "control_net_e357d45256d6",
          "name": "PC3_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "42",
          "netId": "control_net_5ba854809135",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "78",
          "netId": "control_net_b6b1c8d164dd",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "79",
          "netId": "control_net_45181b2521d7",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "85",
          "netId": "control_net_acf154ccf8d8",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "86",
          "netId": "control_net_a31a5a2328d9",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "87",
          "netId": "control_net_b1b80df60d11",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "88",
          "netId": "control_net_7b7c4f86e406",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "101",
          "netId": "control_net_5e6a93f92943",
          "name": "PJ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "102",
          "netId": "control_net_86ac6e45ea88",
          "name": "PJ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "103",
          "netId": "control_net_0482bc5f18f2",
          "name": "PJ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "104",
          "netId": "control_net_d7f9459071b9",
          "name": "PJ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "107",
          "netId": "control_net_cbe2968fbe5f",
          "name": "PK0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "108",
          "netId": "control_net_a59f90994d29",
          "name": "PK1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "109",
          "netId": "control_net_5b2506cefd28",
          "name": "PK2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "111",
          "netId": "control_net_a36112a179b8",
          "name": "PG3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "117",
          "netId": "control_net_43a6e40b99d4",
          "name": "PG7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "130",
          "netId": "control_net_f361f86a0d52",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "131",
          "netId": "control_net_52b9946b1a9a",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "139",
          "netId": "control_net_26f00eadb626",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "146",
          "netId": "control_net_2fe4bf982c96",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "147",
          "netId": "control_net_ea106f84a091",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "148",
          "netId": "control_net_d56008be3974",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "149",
          "netId": "control_net_cc52e369d852",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "150",
          "netId": "control_net_11ba6105da7e",
          "name": "PD7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "153",
          "netId": "control_net_c994a6a8c44b",
          "name": "PG9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "154",
          "netId": "control_net_2e6bb9b818c2",
          "name": "PG10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "155",
          "netId": "control_net_7938ecff8bfa",
          "name": "PG11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "156",
          "netId": "control_net_904833ad65a5",
          "name": "PG12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "157",
          "netId": "control_net_59caeaac06c7",
          "name": "PG13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "158",
          "netId": "control_net_b198f3103c1b",
          "name": "PG14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "163",
          "netId": "control_net_1f69faa028f4",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "164",
          "netId": "control_net_fd3e2e0fadee",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "168",
          "netId": "control_net_07f2de16aeaf",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "169",
          "netId": "control_net_b7f24c7efff4",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "1",
          "netId": "control_net_2daa98d25e56",
          "name": "PE2_/_QSPI_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "41",
          "netId": "control_net_a856887f830b",
          "name": "PA0_/_RESET_FPGA_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "43",
          "netId": "control_net_f64354686773",
          "name": "PA2_/_HOST_UART_TX",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "56",
          "netId": "control_net_c3283ba17c11",
          "name": "PB1_/_HOST_ALIVE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "96",
          "netId": "control_net_1611e906fec8",
          "name": "PD13_/_QSPI_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "165",
          "netId": "control_net_86b00c304637",
          "name": "PB6_/_QSPI_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "166",
          "netId": "control_net_8377a92cc3c5",
          "name": "PB7_/_HOST_WDI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "3",
          "netId": "control_net_a38bef0f0104",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Оперативная память контроллера",
      "text": "Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.",
      "body": "Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.",
      "nodes": [
        "sheet200"
      ],
      "edges": [],
      "sceneId": "control-host",
      "netIds": [
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369",
        "control_net_7a4e5a463be4",
        "control_net_eb78380551ed",
        "control_net_0cbb519cdc03",
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_9529eebe621c",
        "control_net_90c4fa851afd",
        "control_net_c9cd9704b4c3",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420",
        "control_net_3a8a8e9ba9d6",
        "control_net_0d904964f307",
        "control_net_9610b0f12f0e",
        "control_net_71b2a4afb8e1",
        "control_net_c7f569a62e51",
        "control_net_c60541bbd47d",
        "control_net_2b7b5312ecd1",
        "control_net_aceadbfe975f",
        "control_net_60474df9b088",
        "control_net_232acd2cd7a1",
        "control_net_94510af104c3",
        "control_net_54fcb5cad2ac",
        "control_net_e357d45256d6",
        "control_net_5ba854809135",
        "control_net_b6b1c8d164dd",
        "control_net_45181b2521d7",
        "control_net_acf154ccf8d8",
        "control_net_a31a5a2328d9",
        "control_net_b1b80df60d11",
        "control_net_7b7c4f86e406",
        "control_net_5e6a93f92943",
        "control_net_86ac6e45ea88",
        "control_net_0482bc5f18f2",
        "control_net_d7f9459071b9",
        "control_net_cbe2968fbe5f",
        "control_net_a59f90994d29",
        "control_net_5b2506cefd28",
        "control_net_a36112a179b8",
        "control_net_43a6e40b99d4",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_f361f86a0d52",
        "control_net_52b9946b1a9a",
        "control_net_26f00eadb626",
        "control_net_2fe4bf982c96",
        "control_net_ea106f84a091",
        "control_net_d56008be3974",
        "control_net_cc52e369d852",
        "control_net_11ba6105da7e",
        "control_net_c994a6a8c44b",
        "control_net_2e6bb9b818c2",
        "control_net_7938ecff8bfa",
        "control_net_904833ad65a5",
        "control_net_59caeaac06c7",
        "control_net_b198f3103c1b",
        "control_net_1f69faa028f4",
        "control_net_fd3e2e0fadee",
        "control_net_07f2de16aeaf",
        "control_net_b7f24c7efff4",
        "control_net_bf2f5ebca199",
        "control_net_66b853d97583",
        "control_net_f87a72a8ece7",
        "control_net_802aa4569b27",
        "control_net_497868960a10",
        "control_net_f2ad5b3a1b23",
        "control_net_cb5d34db7f7a",
        "control_net_25457d3dd391",
        "control_net_e03d15dc4157",
        "control_net_8726d2dae752",
        "control_net_3a8f32a74ef2",
        "control_net_cf0d706ad175",
        "control_net_57fd38ae982f",
        "control_net_51ade1c12a34",
        "control_net_576d489f596c",
        "control_net_5a1408d6925c",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318",
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_1828c29d5fa6",
        "control_net_64e3b30cda92",
        "control_net_88e82b098d8a",
        "control_net_57814f35c37d",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_df9972435b68",
        "control_net_3974126e88cb",
        "control_net_478ea3ad984d",
        "control_net_2daa98d25e56",
        "control_net_a856887f830b",
        "control_net_f64354686773",
        "control_net_cb711dcd1752",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_c3283ba17c11",
        "control_net_0afe468f72ab",
        "control_net_bfc714f087e0",
        "control_net_c17cd2b70efc",
        "control_net_1611e906fec8",
        "control_net_94be9f57dcd4",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_119d91accf55",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_7f80f60475c4",
        "control_net_86b00c304637",
        "control_net_8377a92cc3c5",
        "control_net_22d2ed5a92b0",
        "control_net_e61f684e2b30",
        "control_net_50fec45c4cfe",
        "control_net_8e2c742867a9",
        "control_net_0d875c33a31d",
        "control_net_a3f957371c3f",
        "control_net_ea2e71d8ad65",
        "control_net_29b779eba1df",
        "control_net_1fb2e0bffca2",
        "control_net_a7ff225fafcc",
        "control_net_b56b3c253467",
        "control_net_7fb3e667afc3",
        "control_net_88a82b0ea167",
        "control_net_6a7ba2287274",
        "control_net_1ab10b21ce8a",
        "control_net_ac77da14ad01",
        "control_net_c768cd02e6fd",
        "control_net_9cec32a3a290",
        "control_net_50162c30e639",
        "control_net_bf332d53cb7b",
        "control_net_5ff18f95d1df",
        "control_net_812a5aa5142f",
        "control_net_ba4358c26b16",
        "control_net_60eebb274bde"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "32",
          "netId": "control_net_eb78380551ed",
          "name": "PH1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "9",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "27",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "43",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "49",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "15",
          "netId": "control_net_c9cd9704b4c3",
          "name": "VLXSMPS",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "2",
          "netId": "control_net_3a8a8e9ba9d6",
          "name": "PE3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "3",
          "netId": "control_net_0d904964f307",
          "name": "PE4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "4",
          "netId": "control_net_9610b0f12f0e",
          "name": "PE5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "5",
          "netId": "control_net_71b2a4afb8e1",
          "name": "PE6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "9",
          "netId": "control_net_c7f569a62e51",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "26",
          "netId": "control_net_c60541bbd47d",
          "name": "PF6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "27",
          "netId": "control_net_2b7b5312ecd1",
          "name": "PF7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "28",
          "netId": "control_net_aceadbfe975f",
          "name": "PF8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "29",
          "netId": "control_net_60474df9b088",
          "name": "PF9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "30",
          "netId": "control_net_232acd2cd7a1",
          "name": "PF10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "35",
          "netId": "control_net_94510af104c3",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "36",
          "netId": "control_net_54fcb5cad2ac",
          "name": "PC2_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "37",
          "netId": "control_net_e357d45256d6",
          "name": "PC3_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "42",
          "netId": "control_net_5ba854809135",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "78",
          "netId": "control_net_b6b1c8d164dd",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "79",
          "netId": "control_net_45181b2521d7",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "85",
          "netId": "control_net_acf154ccf8d8",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "86",
          "netId": "control_net_a31a5a2328d9",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "87",
          "netId": "control_net_b1b80df60d11",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "88",
          "netId": "control_net_7b7c4f86e406",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "101",
          "netId": "control_net_5e6a93f92943",
          "name": "PJ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "102",
          "netId": "control_net_86ac6e45ea88",
          "name": "PJ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "103",
          "netId": "control_net_0482bc5f18f2",
          "name": "PJ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "104",
          "netId": "control_net_d7f9459071b9",
          "name": "PJ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "107",
          "netId": "control_net_cbe2968fbe5f",
          "name": "PK0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "108",
          "netId": "control_net_a59f90994d29",
          "name": "PK1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "109",
          "netId": "control_net_5b2506cefd28",
          "name": "PK2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "111",
          "netId": "control_net_a36112a179b8",
          "name": "PG3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "117",
          "netId": "control_net_43a6e40b99d4",
          "name": "PG7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "130",
          "netId": "control_net_f361f86a0d52",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "131",
          "netId": "control_net_52b9946b1a9a",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "139",
          "netId": "control_net_26f00eadb626",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "146",
          "netId": "control_net_2fe4bf982c96",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "147",
          "netId": "control_net_ea106f84a091",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "148",
          "netId": "control_net_d56008be3974",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "149",
          "netId": "control_net_cc52e369d852",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "150",
          "netId": "control_net_11ba6105da7e",
          "name": "PD7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "153",
          "netId": "control_net_c994a6a8c44b",
          "name": "PG9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "154",
          "netId": "control_net_2e6bb9b818c2",
          "name": "PG10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "155",
          "netId": "control_net_7938ecff8bfa",
          "name": "PG11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "156",
          "netId": "control_net_904833ad65a5",
          "name": "PG12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "157",
          "netId": "control_net_59caeaac06c7",
          "name": "PG13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "158",
          "netId": "control_net_b198f3103c1b",
          "name": "PG14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "163",
          "netId": "control_net_1f69faa028f4",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "164",
          "netId": "control_net_fd3e2e0fadee",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "168",
          "netId": "control_net_07f2de16aeaf",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "169",
          "netId": "control_net_b7f24c7efff4",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "8",
          "netId": "control_net_e8c9dc419d80",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "10",
          "netId": "control_net_c3d2e7b446eb",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "11",
          "netId": "control_net_3f3c225eebe4",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "13",
          "netId": "control_net_4fca7f1d1465",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "42",
          "netId": "control_net_1643db7ef9f9",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "44",
          "netId": "control_net_a3813a077889",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "45",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "47",
          "netId": "control_net_4ddbefaae88b",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "48",
          "netId": "control_net_c16e9f400334",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "50",
          "netId": "control_net_98b1a2522dce",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "51",
          "netId": "control_net_5c8668fc4b07",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "53",
          "netId": "control_net_a0420c81d318",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "2",
          "netId": "control_net_30b951256d65",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "4",
          "netId": "control_net_05f1cce27675",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "5",
          "netId": "control_net_dbb7c66b055c",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "7",
          "netId": "control_net_71220214496a",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "1",
          "netId": "control_net_2daa98d25e56",
          "name": "PE2_/_QSPI_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "41",
          "netId": "control_net_a856887f830b",
          "name": "PA0_/_RESET_FPGA_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "43",
          "netId": "control_net_f64354686773",
          "name": "PA2_/_HOST_UART_TX",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "56",
          "netId": "control_net_c3283ba17c11",
          "name": "PB1_/_HOST_ALIVE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "96",
          "netId": "control_net_1611e906fec8",
          "name": "PD13_/_QSPI_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "165",
          "netId": "control_net_86b00c304637",
          "name": "PB6_/_QSPI_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "166",
          "netId": "control_net_8377a92cc3c5",
          "name": "PB7_/_HOST_WDI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "15",
          "netId": "control_net_22d2ed5a92b0",
          "name": "DQML",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "16",
          "netId": "control_net_e61f684e2b30",
          "name": "WE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "17",
          "netId": "control_net_50fec45c4cfe",
          "name": "CAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "18",
          "netId": "control_net_8e2c742867a9",
          "name": "RAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "19",
          "netId": "control_net_0d875c33a31d",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "20",
          "netId": "control_net_a3f957371c3f",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "21",
          "netId": "control_net_ea2e71d8ad65",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "22",
          "netId": "control_net_29b779eba1df",
          "name": "A10",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "23",
          "netId": "control_net_1fb2e0bffca2",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "24",
          "netId": "control_net_a7ff225fafcc",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "25",
          "netId": "control_net_b56b3c253467",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "26",
          "netId": "control_net_7fb3e667afc3",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "29",
          "netId": "control_net_88a82b0ea167",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "30",
          "netId": "control_net_6a7ba2287274",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "31",
          "netId": "control_net_1ab10b21ce8a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "32",
          "netId": "control_net_ac77da14ad01",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "33",
          "netId": "control_net_c768cd02e6fd",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "34",
          "netId": "control_net_9cec32a3a290",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "35",
          "netId": "control_net_50162c30e639",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "36",
          "netId": "control_net_bf332d53cb7b",
          "name": "A12",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "37",
          "netId": "control_net_5ff18f95d1df",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "38",
          "netId": "control_net_812a5aa5142f",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "39",
          "netId": "control_net_ba4358c26b16",
          "name": "DQMH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "40",
          "netId": "control_net_60eebb274bde",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Память и управление платой",
      "text": "U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.",
      "body": "U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.",
      "nodes": [
        "sheet300"
      ],
      "edges": [],
      "sceneId": "control-host",
      "netIds": [
        "control_net_f8ba31d3ca5d",
        "control_net_e9412c7c775b",
        "control_net_90c4fa851afd",
        "control_net_1ae330a90d69",
        "control_net_f71e7f09f53c",
        "control_net_dbb8a4cebc4d",
        "control_net_db8bb0491f21",
        "control_net_7c39dc0aa14d",
        "control_net_a6d0f4299492",
        "control_net_3b1f11e0f454",
        "control_net_cecba30ce2a4",
        "control_net_93c2464e4d4b",
        "control_net_c5c0c804ee45",
        "control_net_3c2ea5987a7b",
        "control_net_e5dd58f5bdde",
        "control_net_94be9f57dcd4",
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369",
        "control_net_7a4e5a463be4",
        "control_net_eb78380551ed",
        "control_net_0cbb519cdc03",
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_9529eebe621c",
        "control_net_c9cd9704b4c3",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420",
        "control_net_3a8a8e9ba9d6",
        "control_net_0d904964f307",
        "control_net_9610b0f12f0e",
        "control_net_71b2a4afb8e1",
        "control_net_c7f569a62e51",
        "control_net_c60541bbd47d",
        "control_net_2b7b5312ecd1",
        "control_net_aceadbfe975f",
        "control_net_60474df9b088",
        "control_net_232acd2cd7a1",
        "control_net_94510af104c3",
        "control_net_54fcb5cad2ac",
        "control_net_e357d45256d6",
        "control_net_5ba854809135",
        "control_net_b6b1c8d164dd",
        "control_net_45181b2521d7",
        "control_net_acf154ccf8d8",
        "control_net_a31a5a2328d9",
        "control_net_b1b80df60d11",
        "control_net_7b7c4f86e406",
        "control_net_5e6a93f92943",
        "control_net_86ac6e45ea88",
        "control_net_0482bc5f18f2",
        "control_net_d7f9459071b9",
        "control_net_cbe2968fbe5f",
        "control_net_a59f90994d29",
        "control_net_5b2506cefd28",
        "control_net_a36112a179b8",
        "control_net_43a6e40b99d4",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_f361f86a0d52",
        "control_net_52b9946b1a9a",
        "control_net_26f00eadb626",
        "control_net_2fe4bf982c96",
        "control_net_ea106f84a091",
        "control_net_d56008be3974",
        "control_net_cc52e369d852",
        "control_net_11ba6105da7e",
        "control_net_c994a6a8c44b",
        "control_net_2e6bb9b818c2",
        "control_net_7938ecff8bfa",
        "control_net_904833ad65a5",
        "control_net_59caeaac06c7",
        "control_net_b198f3103c1b",
        "control_net_1f69faa028f4",
        "control_net_fd3e2e0fadee",
        "control_net_07f2de16aeaf",
        "control_net_b7f24c7efff4",
        "control_net_bf2f5ebca199",
        "control_net_66b853d97583",
        "control_net_f87a72a8ece7",
        "control_net_802aa4569b27",
        "control_net_497868960a10",
        "control_net_f2ad5b3a1b23",
        "control_net_cb5d34db7f7a",
        "control_net_25457d3dd391",
        "control_net_e03d15dc4157",
        "control_net_8726d2dae752",
        "control_net_3a8f32a74ef2",
        "control_net_cf0d706ad175",
        "control_net_57fd38ae982f",
        "control_net_51ade1c12a34",
        "control_net_576d489f596c",
        "control_net_5a1408d6925c",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318",
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_1828c29d5fa6",
        "control_net_64e3b30cda92",
        "control_net_88e82b098d8a",
        "control_net_57814f35c37d",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_df9972435b68",
        "control_net_3974126e88cb",
        "control_net_478ea3ad984d",
        "control_net_2daa98d25e56",
        "control_net_a856887f830b",
        "control_net_f64354686773",
        "control_net_cb711dcd1752",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_c3283ba17c11",
        "control_net_0afe468f72ab",
        "control_net_bfc714f087e0",
        "control_net_c17cd2b70efc",
        "control_net_1611e906fec8",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_119d91accf55",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_7f80f60475c4",
        "control_net_86b00c304637",
        "control_net_8377a92cc3c5",
        "control_net_6142364b688a",
        "control_net_8228e1434880",
        "control_net_2f35b14c7892",
        "control_net_ac6272a32078"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U301",
          "pin": "1",
          "netId": "control_net_f8ba31d3ca5d",
          "name": "IO1_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "6",
          "netId": "control_net_f8ba31d3ca5d",
          "name": "IO1_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "3",
          "netId": "control_net_e9412c7c775b",
          "name": "IO2_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "4",
          "netId": "control_net_e9412c7c775b",
          "name": "IO2_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "2",
          "netId": "control_net_f71e7f09f53c",
          "name": "DO_/_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "3",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "WP_N_/_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "5",
          "netId": "control_net_db8bb0491f21",
          "name": "DI_/_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "6",
          "netId": "control_net_7c39dc0aa14d",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "7",
          "netId": "control_net_a6d0f4299492",
          "name": "HOLD_N_/_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "1",
          "netId": "control_net_3b1f11e0f454",
          "name": "DAT2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "2",
          "netId": "control_net_cecba30ce2a4",
          "name": "DAT3_/_CD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "3",
          "netId": "control_net_93c2464e4d4b",
          "name": "CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "5",
          "netId": "control_net_c5c0c804ee45",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "7",
          "netId": "control_net_3c2ea5987a7b",
          "name": "DAT0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "8",
          "netId": "control_net_e5dd58f5bdde",
          "name": "DAT1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "9",
          "netId": "control_net_94be9f57dcd4",
          "name": "DETECT1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "32",
          "netId": "control_net_eb78380551ed",
          "name": "PH1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "15",
          "netId": "control_net_c9cd9704b4c3",
          "name": "VLXSMPS",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "2",
          "netId": "control_net_3a8a8e9ba9d6",
          "name": "PE3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "3",
          "netId": "control_net_0d904964f307",
          "name": "PE4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "4",
          "netId": "control_net_9610b0f12f0e",
          "name": "PE5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "5",
          "netId": "control_net_71b2a4afb8e1",
          "name": "PE6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "9",
          "netId": "control_net_c7f569a62e51",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "26",
          "netId": "control_net_c60541bbd47d",
          "name": "PF6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "27",
          "netId": "control_net_2b7b5312ecd1",
          "name": "PF7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "28",
          "netId": "control_net_aceadbfe975f",
          "name": "PF8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "29",
          "netId": "control_net_60474df9b088",
          "name": "PF9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "30",
          "netId": "control_net_232acd2cd7a1",
          "name": "PF10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "35",
          "netId": "control_net_94510af104c3",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "36",
          "netId": "control_net_54fcb5cad2ac",
          "name": "PC2_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "37",
          "netId": "control_net_e357d45256d6",
          "name": "PC3_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "42",
          "netId": "control_net_5ba854809135",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "78",
          "netId": "control_net_b6b1c8d164dd",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "79",
          "netId": "control_net_45181b2521d7",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "85",
          "netId": "control_net_acf154ccf8d8",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "86",
          "netId": "control_net_a31a5a2328d9",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "87",
          "netId": "control_net_b1b80df60d11",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "88",
          "netId": "control_net_7b7c4f86e406",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "101",
          "netId": "control_net_5e6a93f92943",
          "name": "PJ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "102",
          "netId": "control_net_86ac6e45ea88",
          "name": "PJ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "103",
          "netId": "control_net_0482bc5f18f2",
          "name": "PJ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "104",
          "netId": "control_net_d7f9459071b9",
          "name": "PJ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "107",
          "netId": "control_net_cbe2968fbe5f",
          "name": "PK0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "108",
          "netId": "control_net_a59f90994d29",
          "name": "PK1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "109",
          "netId": "control_net_5b2506cefd28",
          "name": "PK2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "111",
          "netId": "control_net_a36112a179b8",
          "name": "PG3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "117",
          "netId": "control_net_43a6e40b99d4",
          "name": "PG7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "130",
          "netId": "control_net_f361f86a0d52",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "131",
          "netId": "control_net_52b9946b1a9a",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "139",
          "netId": "control_net_26f00eadb626",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "146",
          "netId": "control_net_2fe4bf982c96",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "147",
          "netId": "control_net_ea106f84a091",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "148",
          "netId": "control_net_d56008be3974",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "149",
          "netId": "control_net_cc52e369d852",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "150",
          "netId": "control_net_11ba6105da7e",
          "name": "PD7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "153",
          "netId": "control_net_c994a6a8c44b",
          "name": "PG9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "154",
          "netId": "control_net_2e6bb9b818c2",
          "name": "PG10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "155",
          "netId": "control_net_7938ecff8bfa",
          "name": "PG11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "156",
          "netId": "control_net_904833ad65a5",
          "name": "PG12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "157",
          "netId": "control_net_59caeaac06c7",
          "name": "PG13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "158",
          "netId": "control_net_b198f3103c1b",
          "name": "PG14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "163",
          "netId": "control_net_1f69faa028f4",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "164",
          "netId": "control_net_fd3e2e0fadee",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "168",
          "netId": "control_net_07f2de16aeaf",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "169",
          "netId": "control_net_b7f24c7efff4",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "1",
          "netId": "control_net_2daa98d25e56",
          "name": "PE2_/_QSPI_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "41",
          "netId": "control_net_a856887f830b",
          "name": "PA0_/_RESET_FPGA_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "43",
          "netId": "control_net_f64354686773",
          "name": "PA2_/_HOST_UART_TX",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "56",
          "netId": "control_net_c3283ba17c11",
          "name": "PB1_/_HOST_ALIVE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "96",
          "netId": "control_net_1611e906fec8",
          "name": "PD13_/_QSPI_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "165",
          "netId": "control_net_86b00c304637",
          "name": "PB6_/_QSPI_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "166",
          "netId": "control_net_8377a92cc3c5",
          "name": "PB7_/_HOST_WDI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "1",
          "netId": "control_net_6142364b688a",
          "name": "IO1_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "6",
          "netId": "control_net_6142364b688a",
          "name": "IO1_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "3",
          "netId": "control_net_8228e1434880",
          "name": "IO2_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "4",
          "netId": "control_net_8228e1434880",
          "name": "IO2_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "1",
          "netId": "control_net_2f35b14c7892",
          "name": "IO1_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "6",
          "netId": "control_net_2f35b14c7892",
          "name": "IO1_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "3",
          "netId": "control_net_ac6272a32078",
          "name": "IO2_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U303",
          "pin": "4",
          "netId": "control_net_ac6272a32078",
          "name": "IO2_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
