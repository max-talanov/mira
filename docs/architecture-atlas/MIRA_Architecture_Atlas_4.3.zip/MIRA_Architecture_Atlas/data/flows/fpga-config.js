/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "fpga-config",
  "title": "Загрузка конфигурации ПЛИС",
  "description": "Посмотрите, где хранится конфигурация, как проходит запуск и чем загрузка отличается от готовности прикладной логики.",
  "sceneId": "system",
  "steps": [
    {
      "title": "Включение питания ПЛИС",
      "text": "Плата Power подаёт питание ядра, вспомогательных узлов и банков ПЛИС.",
      "body": "Плата Power подаёт питание ядра, вспомогательных узлов и банков ПЛИС.",
      "nodes": [
        "power",
        "fpga"
      ],
      "edges": [
        "power_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U8",
          "netId": "control_net_6f005443ad9c",
          "name": "CFGBVS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U11",
          "netId": "control_net_6f005443ad9c",
          "name": "M0_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Загрузка конфигурационного потока",
      "text": "Интерфейс конфигурации загружает аппаратный проект ПЛИС из локальной flash-памяти. Точный путь показан в модуле конфигурации ПЛИС.",
      "body": "Интерфейс конфигурации загружает аппаратный проект ПЛИС из локальной flash-памяти. Точный путь показан в модуле конфигурации ПЛИС.",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "system",
      "netIds": [
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d",
        "control_net_0626002d4e17",
        "control_net_4417efbf2ab6",
        "control_net_cca629e55469",
        "control_net_a36b4e28f2cd",
        "control_net_17e68319e159",
        "control_net_aefe57c66d3e",
        "control_net_cbd39545f268",
        "control_net_b935f05e6b88",
        "control_net_f71ace5398bb",
        "control_net_b4f02c632f60",
        "control_net_2c428620e257",
        "control_net_8d69d598a971",
        "control_net_a0d28f360159",
        "control_net_6f005443ad9c",
        "control_net_3d9d791e8355",
        "control_net_00eadc59f9af",
        "control_net_6bc6649476ec",
        "control_net_d9edbd0f92ec",
        "control_net_2f8d843708d6",
        "control_net_4701afd22aa9",
        "control_net_c251169eb896",
        "control_net_0b94eea9a209",
        "control_net_75501c77d10a",
        "control_net_61b4ba86f12f",
        "control_net_ba92e944f30f",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_45ad74d728ee",
        "control_net_5f4121b0067b",
        "control_net_4dd63af5135a",
        "control_net_77550a265a38",
        "control_net_d35e6450ec18",
        "control_net_0c2767ceedce",
        "control_net_0aa940b07213",
        "control_net_95229f960617",
        "control_net_ae2900dc7735",
        "control_net_a3e916588f1a",
        "control_net_3591ba357658",
        "control_net_92af7290af48",
        "control_net_90cbd311d743",
        "control_net_76c093c7625c",
        "control_net_e4fd6a071815",
        "control_net_34a5458782a9",
        "control_net_708de604029c",
        "control_net_834296c71f70",
        "control_net_9e71347ab99c",
        "control_net_a0ccf5710062",
        "control_net_52c8c7557923",
        "control_net_fb7db09ec7c3",
        "control_net_e44786acaa30",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_fb2e9fe80e2d",
        "control_net_a6a3fee83c7f",
        "control_net_587cf1488c03",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_55817c8282e0",
        "control_net_ea07dd504c63",
        "control_net_81564ca10d04",
        "control_net_edfa87483431",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_e99ac6514624",
        "control_net_595e8f7ae0b8",
        "control_net_54c1f1eb7696",
        "control_net_f8ec39c4ab9d",
        "control_net_d3f1a4b3a597",
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_91e18b17f805",
        "control_net_c97f66f5a8ca",
        "control_net_246e53b44cf7",
        "control_net_cc4231e43005",
        "control_net_0229dc72e592",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_306a691e0334",
        "control_net_f0400a3868ce",
        "control_net_314c158ce4da",
        "control_net_1dcb8bcb468b",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_5fb1532b0e1e",
        "control_net_010b6b6f67c9",
        "control_net_d709c7f7b65c",
        "control_net_f19cdec7c823",
        "control_net_52a6b9dc2fac",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_ace5c68a2cc9",
        "control_net_c25a7182f56a",
        "control_net_6c708c43c5b9",
        "control_net_4a79582bd184",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_9b62758e037e",
        "control_net_39477ddd3ce1",
        "control_net_ccce32991990",
        "control_net_407e3d055e25",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_3bc7340649bd",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a",
        "control_net_5c5982e822c2",
        "control_net_0304d51af6c1",
        "control_net_9f2f629756c4",
        "control_net_2b95659e74de",
        "control_net_b22642780df7",
        "control_net_40fb51ba3b62",
        "control_net_6b666b9aabd9",
        "control_net_ee84b9bf0bbc",
        "control_net_6d232399d072",
        "control_net_55da05168177",
        "control_net_d44f364a5830",
        "control_net_bb3aaa71ba05",
        "control_net_be534772f175",
        "control_net_16617557f395",
        "control_net_c8980fec1127",
        "control_net_172656434fbc",
        "control_net_5220b4a56b5c",
        "control_net_c31eb8fe07d3",
        "control_net_d109bb25230c",
        "control_net_075227a69d18",
        "control_net_cdfcd01f3692",
        "control_net_e5afe79fa19e",
        "control_net_ebaa690e703b",
        "control_net_c4d0ccc3d16d",
        "control_net_d9ef0a17e785",
        "control_net_395f29bc0592",
        "control_net_d7ba445b9916",
        "control_net_907e4adf7ca2",
        "control_net_ccf3e014a0ef",
        "control_net_42c5791086ec",
        "control_net_d6b5309ee994",
        "control_net_42df6ae20837",
        "control_net_abae69816039",
        "control_net_707df60aeb98",
        "control_net_fd2bad63a67c",
        "control_net_4143ff0aef6d",
        "control_net_090eb35bbabe",
        "control_net_cccff17550b9",
        "control_net_185955b3a706",
        "control_net_9bda4980e75a",
        "control_net_4baca15034bf",
        "control_net_92d89f9df56c",
        "control_net_4bb6a512cc3a",
        "control_net_f4bfe5cdab56",
        "control_net_19bcc72c5488",
        "control_net_3ddfecb0df47",
        "control_net_58af204d8c23",
        "control_net_1d61ccb9d017",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_d586ee5fe950",
        "control_net_14e361774b31",
        "control_net_20b74826bb9f",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_ff9ff859ce5e",
        "control_net_c9c89af3970f",
        "control_net_101ecb817b3a",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_a4fbe32e37cd",
        "control_net_e0b8d44e15a9",
        "control_net_c491c2114b69",
        "control_net_8441e3506dc3",
        "control_net_feb9c68fc359",
        "control_net_b754ba5a60da",
        "control_net_af615c537cb1",
        "control_net_e83c3c7df2de",
        "control_net_3e9631f7c6ff",
        "control_net_7289e1b08835",
        "control_net_e773796fd1f6",
        "control_net_5cb04db620b0",
        "control_net_06de98680544",
        "control_net_66a9597ad7c2",
        "control_net_d00f8c30fd72",
        "control_net_e53226ed313e",
        "control_net_e7865782b189",
        "control_net_e39e2c0118dc",
        "control_net_0d1a4f8df7dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_3230bba6e369",
        "control_net_08fdee08456b",
        "control_net_9872096d1603",
        "control_net_5fd8dcc5fbb4",
        "control_net_dec8aaf78baf",
        "control_net_7208b29a2b1c",
        "control_net_fd223a19128e",
        "control_net_1ac6761e03ed",
        "control_net_937ff9979dc3",
        "control_net_85ba8fc9e715",
        "control_net_ac5068fd8652",
        "control_net_ca03fb089228",
        "control_net_1d078f5152c1",
        "control_net_8543c7028353",
        "control_net_fd8710ab620d",
        "control_net_4dea48708eb3",
        "control_net_efab486ffaed",
        "control_net_7f616706cf93",
        "control_net_8baeadc9d1f8",
        "control_net_da58769d7620",
        "control_net_b467eac10258",
        "control_net_a3c162bcb298",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_fe5724fe2bab",
        "control_net_b02072f17830",
        "control_net_82b207235505",
        "control_net_92cfc687656d",
        "control_net_bae01a82acc2",
        "control_net_168076ddc771",
        "control_net_def0213ce26f",
        "control_net_79395ecc284b",
        "control_net_410016c949d5",
        "control_net_71168801242c",
        "control_net_e542b9e16418",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf",
        "control_net_ef7dcf4c5ac1",
        "control_net_07a2fafb5ee8",
        "control_net_63296c08fb96",
        "control_net_0e6757f456c8",
        "control_net_fe9a6d2314d3",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_2b2d32129563",
        "control_net_63eb0399a909",
        "control_net_6d399f5ab100",
        "control_net_3216c2600ec6",
        "control_net_633521e6d31e",
        "control_net_0fed13c85d5f",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_429d3a1721ef",
        "control_net_30006651dbc3",
        "control_net_d2248f535667",
        "control_net_889281b6cc29",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_f05b5740e1a9",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_b2863a780247",
        "control_net_ba2ab40384c6",
        "control_net_45ba6797a43b",
        "control_net_c254fca78b2c",
        "control_net_1f04a0a6f06f",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_ff273c6660ec",
        "control_net_df16aaaa5404",
        "control_net_6e0242cad116",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_901bc97b19eb",
        "control_net_c86649734604",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_92b42c536ceb",
        "control_net_c4621dfd0ac4",
        "control_net_1a607d7041f2",
        "control_net_b33367a767ed",
        "control_net_47b21cc6bdbe",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98",
        "control_net_9586fff76126",
        "control_net_c57c59e45608",
        "control_net_c6e07c7a7de3",
        "control_net_cf8365500557",
        "control_net_818e010f96a4",
        "control_net_d3b6ad2c162f",
        "control_net_81e90041a4a7",
        "control_net_25ed8ee038f5",
        "control_net_4c0d3001839d",
        "control_net_6756bcf346dd",
        "control_net_8aa3f3702439",
        "control_net_32f74940b307"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A4",
          "netId": "control_net_0626002d4e17",
          "name": "MGTPTXN0_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A6",
          "netId": "control_net_4417efbf2ab6",
          "name": "MGTPTXN2_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B4",
          "netId": "control_net_cca629e55469",
          "name": "MGTPTXP0_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B6",
          "netId": "control_net_a36b4e28f2cd",
          "name": "MGTPTXP2_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C5",
          "netId": "control_net_17e68319e159",
          "name": "MGTPTXN1_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C7",
          "netId": "control_net_aefe57c66d3e",
          "name": "MGTPTXN3_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D5",
          "netId": "control_net_cbd39545f268",
          "name": "MGTPTXP1_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D7",
          "netId": "control_net_b935f05e6b88",
          "name": "MGTPTXP3_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E6",
          "netId": "control_net_f71ace5398bb",
          "name": "MGTREFCLK0N_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E10",
          "netId": "control_net_b4f02c632f60",
          "name": "MGTREFCLK1N_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F6",
          "netId": "control_net_2c428620e257",
          "name": "MGTREFCLK0P_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F10",
          "netId": "control_net_8d69d598a971",
          "name": "MGTREFCLK1P_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B14",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D18",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E15",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F22",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G19",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H16",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J13",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K20",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U8",
          "netId": "control_net_6f005443ad9c",
          "name": "CFGBVS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U11",
          "netId": "control_net_6f005443ad9c",
          "name": "M0_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G11",
          "netId": "control_net_3d9d791e8355",
          "name": "DONE_0",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K10",
          "netId": "control_net_00eadc59f9af",
          "name": "VCCADC_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L12",
          "netId": "control_net_6bc6649476ec",
          "name": "CCLK_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N9",
          "netId": "control_net_d9edbd0f92ec",
          "name": "DXN_0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N10",
          "netId": "control_net_2f8d843708d6",
          "name": "DXP_0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N12",
          "netId": "control_net_4701afd22aa9",
          "name": "PROGRAM_B_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R13",
          "netId": "control_net_c251169eb896",
          "name": "TDI_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T13",
          "netId": "control_net_0b94eea9a209",
          "name": "TMS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U12",
          "netId": "control_net_75501c77d10a",
          "name": "INIT_B_0",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U13",
          "netId": "control_net_61b4ba86f12f",
          "name": "TDO_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V12",
          "netId": "control_net_ba92e944f30f",
          "name": "TCK_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N13",
          "netId": "control_net_45ad74d728ee",
          "name": "IO_L23P_T3_A03_D19_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N14",
          "netId": "control_net_5f4121b0067b",
          "name": "IO_L23N_T3_A02_D18_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N15",
          "netId": "control_net_4dd63af5135a",
          "name": "IO_25_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N17",
          "netId": "control_net_77550a265a38",
          "name": "IO_L21P_T3_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P15",
          "netId": "control_net_0c2767ceedce",
          "name": "IO_L22P_T3_A05_D21_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P16",
          "netId": "control_net_0aa940b07213",
          "name": "IO_L24P_T3_A01_D17_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P17",
          "netId": "control_net_95229f960617",
          "name": "IO_L21N_T3_DQS_A06_D22_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P21",
          "netId": "control_net_3591ba357658",
          "name": "IO_L2P_T0_D02_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P22",
          "netId": "control_net_92af7290af48",
          "name": "IO_L1P_T0_D00_MOSI_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R16",
          "netId": "control_net_76c093c7625c",
          "name": "IO_L22N_T3_A04_D20_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R17",
          "netId": "control_net_e4fd6a071815",
          "name": "IO_L24N_T3_A00_D16_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R18",
          "netId": "control_net_34a5458782a9",
          "name": "IO_L20P_T3_A08_D24_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R21",
          "netId": "control_net_834296c71f70",
          "name": "IO_L2N_T0_D03_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R22",
          "netId": "control_net_9e71347ab99c",
          "name": "IO_L1N_T0_D01_DIN_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T18",
          "netId": "control_net_a0ccf5710062",
          "name": "IO_L20N_T3_A07_D23_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T19",
          "netId": "control_net_52c8c7557923",
          "name": "IO_L6P_T0_FCS_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U22",
          "netId": "control_net_587cf1488c03",
          "name": "IO_L3P_T0_DQS_PUDC_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W19",
          "netId": "control_net_81564ca10d04",
          "name": "IO_L12P_T1_MRCC_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A13",
          "netId": "control_net_e99ac6514624",
          "name": "IO_L10P_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A14",
          "netId": "control_net_595e8f7ae0b8",
          "name": "IO_L10N_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A15",
          "netId": "control_net_54c1f1eb7696",
          "name": "IO_L9P_T1_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A16",
          "netId": "control_net_f8ec39c4ab9d",
          "name": "IO_L9N_T1_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A18",
          "netId": "control_net_d3f1a4b3a597",
          "name": "IO_L17P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A19",
          "netId": "control_net_6943e9712d9c",
          "name": "IO_L17N_T2_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A20",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "IO_L16N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A21",
          "netId": "control_net_ac8599a8c0cd",
          "name": "IO_L21N_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B13",
          "netId": "control_net_91e18b17f805",
          "name": "IO_L8N_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B15",
          "netId": "control_net_c97f66f5a8ca",
          "name": "IO_L7P_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B16",
          "netId": "control_net_246e53b44cf7",
          "name": "IO_L7N_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B17",
          "netId": "control_net_cc4231e43005",
          "name": "IO_L11P_T1_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B18",
          "netId": "control_net_0229dc72e592",
          "name": "IO_L11N_T1_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B20",
          "netId": "control_net_c5d6e41ef012",
          "name": "IO_L16P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B21",
          "netId": "control_net_49b164ada644",
          "name": "IO_L21P_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B22",
          "netId": "control_net_63a08f54a8af",
          "name": "IO_L20N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C13",
          "netId": "control_net_306a691e0334",
          "name": "IO_L8P_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C14",
          "netId": "control_net_f0400a3868ce",
          "name": "IO_L3P_T0_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C15",
          "netId": "control_net_314c158ce4da",
          "name": "IO_L3N_T0_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C17",
          "netId": "control_net_1dcb8bcb468b",
          "name": "IO_L12N_T1_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C18",
          "netId": "control_net_a46672b578ec",
          "name": "IO_L13P_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C19",
          "netId": "control_net_85a84369e22a",
          "name": "IO_L13N_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C20",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D15",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H18",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K14",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_A21_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C22",
          "netId": "control_net_010b6b6f67c9",
          "name": "IO_L20P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D14",
          "netId": "control_net_d709c7f7b65c",
          "name": "IO_L6P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D16",
          "netId": "control_net_f19cdec7c823",
          "name": "IO_L5N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D17",
          "netId": "control_net_52a6b9dc2fac",
          "name": "IO_L12P_T1_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D19",
          "netId": "control_net_d514c816e952",
          "name": "IO_L14N_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D20",
          "netId": "control_net_3a2594a1e1f9",
          "name": "IO_L19P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D21",
          "netId": "control_net_9bc7997904a8",
          "name": "IO_L23N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D22",
          "netId": "control_net_6e031edce63d",
          "name": "IO_L22N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E13",
          "netId": "control_net_ace5c68a2cc9",
          "name": "IO_L4P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E14",
          "netId": "control_net_c25a7182f56a",
          "name": "IO_L4N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E16",
          "netId": "control_net_6c708c43c5b9",
          "name": "IO_L5P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E17",
          "netId": "control_net_4a79582bd184",
          "name": "IO_L2N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E18",
          "netId": "control_net_17b46c5249cb",
          "name": "IO_L15N_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E19",
          "netId": "control_net_4ff8255e049a",
          "name": "IO_L14P_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E21",
          "netId": "control_net_18e1c9509d79",
          "name": "IO_L23P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E22",
          "netId": "control_net_d2bff6eceb03",
          "name": "IO_L22P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F13",
          "netId": "control_net_9b62758e037e",
          "name": "IO_L1P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F14",
          "netId": "control_net_39477ddd3ce1",
          "name": "IO_L1N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F15",
          "netId": "control_net_ccce32991990",
          "name": "IO_0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F16",
          "netId": "control_net_407e3d055e25",
          "name": "IO_L2P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F18",
          "netId": "control_net_dc796dddd274",
          "name": "IO_L15P_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F19",
          "netId": "control_net_184f5bb728b0",
          "name": "IO_L18P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F20",
          "netId": "control_net_0065f370787e",
          "name": "IO_L18N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F21",
          "netId": "control_net_3bc7340649bd",
          "name": "IO_25_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G21",
          "netId": "control_net_710e1e095743",
          "name": "IO_L24P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G22",
          "netId": "control_net_3a720de9ef0a",
          "name": "IO_L24N_T3_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G13",
          "netId": "control_net_5c5982e822c2",
          "name": "IO_L1N_T0_AD0N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G15",
          "netId": "control_net_0304d51af6c1",
          "name": "IO_L2P_T0_AD8P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G16",
          "netId": "control_net_9f2f629756c4",
          "name": "IO_L2N_T0_AD8N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G17",
          "netId": "control_net_2b95659e74de",
          "name": "IO_L4P_T0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G18",
          "netId": "control_net_b22642780df7",
          "name": "IO_L4N_T0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G20",
          "netId": "control_net_40fb51ba3b62",
          "name": "IO_L8N_T1_AD10N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H13",
          "netId": "control_net_6b666b9aabd9",
          "name": "IO_L1P_T0_AD0P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H14",
          "netId": "control_net_ee84b9bf0bbc",
          "name": "IO_L3N_T0_DQS_AD1N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H15",
          "netId": "control_net_6d232399d072",
          "name": "IO_L5N_T0_AD9N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H17",
          "netId": "control_net_55da05168177",
          "name": "IO_L6P_T0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H19",
          "netId": "control_net_d44f364a5830",
          "name": "IO_L12N_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H20",
          "netId": "control_net_bb3aaa71ba05",
          "name": "IO_L8P_T1_AD10P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H22",
          "netId": "control_net_be534772f175",
          "name": "IO_L7N_T1_AD2N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J14",
          "netId": "control_net_16617557f395",
          "name": "IO_L3P_T0_DQS_AD1P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J15",
          "netId": "control_net_c8980fec1127",
          "name": "IO_L5P_T0_AD9P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J16",
          "netId": "control_net_172656434fbc",
          "name": "IO_0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J17",
          "netId": "control_net_5220b4a56b5c",
          "name": "IO_L21N_T3_DQS_A18_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J19",
          "netId": "control_net_c31eb8fe07d3",
          "name": "IO_L12P_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J20",
          "netId": "control_net_d109bb25230c",
          "name": "IO_L11P_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J21",
          "netId": "control_net_075227a69d18",
          "name": "IO_L11N_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J22",
          "netId": "control_net_cdfcd01f3692",
          "name": "IO_L7P_T1_AD2P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K13",
          "netId": "control_net_e5afe79fa19e",
          "name": "IO_L19P_T3_A22_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K16",
          "netId": "control_net_ebaa690e703b",
          "name": "IO_L23N_T3_FWE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K17",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "IO_L21P_T3_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K18",
          "netId": "control_net_d9ef0a17e785",
          "name": "IO_L13P_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K19",
          "netId": "control_net_395f29bc0592",
          "name": "IO_L13N_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K21",
          "netId": "control_net_d7ba445b9916",
          "name": "IO_L9P_T1_DQS_AD3P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K22",
          "netId": "control_net_907e4adf7ca2",
          "name": "IO_L9N_T1_DQS_AD3N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L13",
          "netId": "control_net_ccf3e014a0ef",
          "name": "IO_L20N_T3_A19_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L14",
          "netId": "control_net_42c5791086ec",
          "name": "IO_L22P_T3_A17_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L15",
          "netId": "control_net_d6b5309ee994",
          "name": "IO_L22N_T3_A16_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L16",
          "netId": "control_net_42df6ae20837",
          "name": "IO_L23P_T3_FOE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L18",
          "netId": "control_net_abae69816039",
          "name": "IO_L16N_T2_A27_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L19",
          "netId": "control_net_707df60aeb98",
          "name": "IO_L14P_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L20",
          "netId": "control_net_fd2bad63a67c",
          "name": "IO_L14N_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L21",
          "netId": "control_net_4143ff0aef6d",
          "name": "IO_L10N_T1_AD11N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M13",
          "netId": "control_net_090eb35bbabe",
          "name": "IO_L20P_T3_A20_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M15",
          "netId": "control_net_cccff17550b9",
          "name": "IO_L24P_T3_RS1_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M16",
          "netId": "control_net_185955b3a706",
          "name": "IO_L24N_T3_RS0_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M17",
          "netId": "control_net_9bda4980e75a",
          "name": "IO_25_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M18",
          "netId": "control_net_4baca15034bf",
          "name": "IO_L16P_T2_A28_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M20",
          "netId": "control_net_92d89f9df56c",
          "name": "IO_L18N_T2_A23_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M21",
          "netId": "control_net_4bb6a512cc3a",
          "name": "IO_L10P_T1_AD11P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M22",
          "netId": "control_net_f4bfe5cdab56",
          "name": "IO_L15N_T2_DQS_ADV_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N18",
          "netId": "control_net_19bcc72c5488",
          "name": "IO_L17P_T2_A26_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N19",
          "netId": "control_net_3ddfecb0df47",
          "name": "IO_L17N_T2_A25_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N20",
          "netId": "control_net_58af204d8c23",
          "name": "IO_L18P_T2_A24_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N22",
          "netId": "control_net_1d61ccb9d017",
          "name": "IO_L15P_T2_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA11",
          "netId": "control_net_d586ee5fe950",
          "name": "IO_L9N_T1_DQS_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T14",
          "netId": "control_net_a4fbe32e37cd",
          "name": "IO_L15P_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T15",
          "netId": "control_net_e0b8d44e15a9",
          "name": "IO_L15N_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T16",
          "netId": "control_net_c491c2114b69",
          "name": "IO_L17P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U15",
          "netId": "control_net_8441e3506dc3",
          "name": "IO_L14P_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U16",
          "netId": "control_net_feb9c68fc359",
          "name": "IO_L17N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V10",
          "netId": "control_net_b754ba5a60da",
          "name": "IO_L10P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V14",
          "netId": "control_net_e83c3c7df2de",
          "name": "IO_L13N_T2_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V15",
          "netId": "control_net_3e9631f7c6ff",
          "name": "IO_L14N_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W10",
          "netId": "control_net_7289e1b08835",
          "name": "IO_L10N_T1_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W12",
          "netId": "control_net_5cb04db620b0",
          "name": "IO_L12N_T1_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W15",
          "netId": "control_net_66a9597ad7c2",
          "name": "IO_L16P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W16",
          "netId": "control_net_d00f8c30fd72",
          "name": "IO_L16N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y11",
          "netId": "control_net_e53226ed313e",
          "name": "IO_L11P_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y12",
          "netId": "control_net_e7865782b189",
          "name": "IO_L11N_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA1",
          "netId": "control_net_3230bba6e369",
          "name": "IO_L7P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA3",
          "netId": "control_net_08fdee08456b",
          "name": "IO_L9N_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA4",
          "netId": "control_net_9872096d1603",
          "name": "IO_L11N_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA5",
          "netId": "control_net_5fd8dcc5fbb4",
          "name": "IO_L10P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA6",
          "netId": "control_net_dec8aaf78baf",
          "name": "IO_L18N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA8",
          "netId": "control_net_7208b29a2b1c",
          "name": "IO_L22P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB1",
          "netId": "control_net_fd223a19128e",
          "name": "IO_L7N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB2",
          "netId": "control_net_1ac6761e03ed",
          "name": "IO_L8N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB3",
          "netId": "control_net_937ff9979dc3",
          "name": "IO_L8P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB5",
          "netId": "control_net_85ba8fc9e715",
          "name": "IO_L10N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB6",
          "netId": "control_net_ac5068fd8652",
          "name": "IO_L20N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB7",
          "netId": "control_net_ca03fb089228",
          "name": "IO_L20P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB8",
          "netId": "control_net_1d078f5152c1",
          "name": "IO_L22N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R4",
          "netId": "control_net_4dea48708eb3",
          "name": "IO_L13P_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R6",
          "netId": "control_net_efab486ffaed",
          "name": "IO_L17P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T4",
          "netId": "control_net_da58769d7620",
          "name": "IO_L13N_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T5",
          "netId": "control_net_b467eac10258",
          "name": "IO_L14P_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T6",
          "netId": "control_net_a3c162bcb298",
          "name": "IO_L17N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U3",
          "netId": "control_net_fe5724fe2bab",
          "name": "IO_L6P_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U5",
          "netId": "control_net_b02072f17830",
          "name": "IO_L14N_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U6",
          "netId": "control_net_82b207235505",
          "name": "IO_L16P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U7",
          "netId": "control_net_92cfc687656d",
          "name": "IO_25_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V3",
          "netId": "control_net_168076ddc771",
          "name": "IO_L6N_T0_VREF_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V4",
          "netId": "control_net_def0213ce26f",
          "name": "IO_L12P_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V5",
          "netId": "control_net_79395ecc284b",
          "name": "IO_L16N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V7",
          "netId": "control_net_410016c949d5",
          "name": "IO_L19P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V8",
          "netId": "control_net_71168801242c",
          "name": "IO_L21N_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V9",
          "netId": "control_net_e542b9e16418",
          "name": "IO_L21P_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W4",
          "netId": "control_net_ef7dcf4c5ac1",
          "name": "IO_L12N_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W5",
          "netId": "control_net_07a2fafb5ee8",
          "name": "IO_L15N_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W6",
          "netId": "control_net_63296c08fb96",
          "name": "IO_L15P_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W7",
          "netId": "control_net_0e6757f456c8",
          "name": "IO_L19N_T3_VREF_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W9",
          "netId": "control_net_fe9a6d2314d3",
          "name": "IO_L24P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y3",
          "netId": "control_net_2b2d32129563",
          "name": "IO_L9P_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y4",
          "netId": "control_net_63eb0399a909",
          "name": "IO_L11P_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y6",
          "netId": "control_net_6d399f5ab100",
          "name": "IO_L18P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y7",
          "netId": "control_net_3216c2600ec6",
          "name": "IO_L23N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y8",
          "netId": "control_net_633521e6d31e",
          "name": "IO_L23P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y9",
          "netId": "control_net_0fed13c85d5f",
          "name": "IO_L24N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E3",
          "netId": "control_net_2690ba9f85c2",
          "name": "IO_L6N_T0_VREF_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F1",
          "netId": "control_net_1060da4e1062",
          "name": "IO_L5N_T0_AD13N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F3",
          "netId": "control_net_8e945f7df341",
          "name": "IO_L6P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G1",
          "netId": "control_net_103f84ec6132",
          "name": "IO_L5P_T0_AD13P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G2",
          "netId": "control_net_c6ecade8f839",
          "name": "IO_L8N_T1_AD14N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G3",
          "netId": "control_net_8e9184bc5c46",
          "name": "IO_L11N_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G4",
          "netId": "control_net_b2863a780247",
          "name": "IO_L12N_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H2",
          "netId": "control_net_ba2ab40384c6",
          "name": "IO_L8P_T1_AD14P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H3",
          "netId": "control_net_45ba6797a43b",
          "name": "IO_L11P_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H4",
          "netId": "control_net_c254fca78b2c",
          "name": "IO_L12P_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H5",
          "netId": "control_net_1f04a0a6f06f",
          "name": "IO_L10N_T1_AD15N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J1",
          "netId": "control_net_f16f12a0707d",
          "name": "IO_L7N_T1_AD6N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J2",
          "netId": "control_net_d095506d8145",
          "name": "IO_L9N_T1_DQS_AD7N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J4",
          "netId": "control_net_ff273c6660ec",
          "name": "IO_L13N_T2_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J5",
          "netId": "control_net_df16aaaa5404",
          "name": "IO_L10P_T1_AD15P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J6",
          "netId": "control_net_6e0242cad116",
          "name": "IO_L17N_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K1",
          "netId": "control_net_2a00cc654f3d",
          "name": "IO_L7P_T1_AD6P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K2",
          "netId": "control_net_5130997c4fe8",
          "name": "IO_L9P_T1_DQS_AD7P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K3",
          "netId": "control_net_901bc97b19eb",
          "name": "IO_L14N_T2_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K4",
          "netId": "control_net_c86649734604",
          "name": "IO_L13P_T2_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L3",
          "netId": "control_net_92b42c536ceb",
          "name": "IO_L14P_T2_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L5",
          "netId": "control_net_1a607d7041f2",
          "name": "IO_L18P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L6",
          "netId": "control_net_b33367a767ed",
          "name": "IO_25_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M1",
          "netId": "control_net_47b21cc6bdbe",
          "name": "IO_L15P_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M5",
          "netId": "control_net_9586fff76126",
          "name": "IO_L23N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M6",
          "netId": "control_net_c57c59e45608",
          "name": "IO_L23P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N2",
          "netId": "control_net_c6e07c7a7de3",
          "name": "IO_L22N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N3",
          "netId": "control_net_cf8365500557",
          "name": "IO_L19N_T3_VREF_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N4",
          "netId": "control_net_818e010f96a4",
          "name": "IO_L19P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N5",
          "netId": "control_net_d3b6ad2c162f",
          "name": "IO_L24N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P1",
          "netId": "control_net_81e90041a4a7",
          "name": "IO_L20N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P2",
          "netId": "control_net_25ed8ee038f5",
          "name": "IO_L22P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P4",
          "netId": "control_net_4c0d3001839d",
          "name": "IO_L21N_T3_DQS_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P5",
          "netId": "control_net_6756bcf346dd",
          "name": "IO_L21P_T3_DQS_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P6",
          "netId": "control_net_8aa3f3702439",
          "name": "IO_L24P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R1",
          "netId": "control_net_32f74940b307",
          "name": "IO_L20P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигналы INIT и DONE",
      "text": "Состояние конфигурации передаётся основному контроллеру через буферы между доменами.",
      "body": "Состояние конфигурации передаётся основному контроллеру через буферы между доменами.",
      "nodes": [
        "fpga",
        "mcu"
      ],
      "edges": [
        "mcu_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка готовности программы",
      "text": "Перед экспериментами загруженная прикладная логика должна проверить готовность связи и памяти.",
      "body": "Перед экспериментами загруженная прикладная логика должна проверить готовность связи и памяти.",
      "nodes": [
        "fpga",
        "mcu",
        "links"
      ],
      "edges": [
        "links_fpga",
        "mcu_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Включение питания ПЛИС",
      "text": "Плата Power подаёт питание ядра, вспомогательных узлов и банков ПЛИС.",
      "body": "Плата Power подаёт питание ядра, вспомогательных узлов и банков ПЛИС.",
      "nodes": [
        "power",
        "fpga"
      ],
      "edges": [
        "power_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U8",
          "netId": "control_net_6f005443ad9c",
          "name": "CFGBVS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U11",
          "netId": "control_net_6f005443ad9c",
          "name": "M0_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Загрузка конфигурационного потока",
      "text": "Интерфейс конфигурации загружает аппаратный проект ПЛИС из локальной flash-памяти. Точный путь показан в модуле конфигурации ПЛИС.",
      "body": "Интерфейс конфигурации загружает аппаратный проект ПЛИС из локальной flash-памяти. Точный путь показан в модуле конфигурации ПЛИС.",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "system",
      "netIds": [
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d",
        "control_net_0626002d4e17",
        "control_net_4417efbf2ab6",
        "control_net_cca629e55469",
        "control_net_a36b4e28f2cd",
        "control_net_17e68319e159",
        "control_net_aefe57c66d3e",
        "control_net_cbd39545f268",
        "control_net_b935f05e6b88",
        "control_net_f71ace5398bb",
        "control_net_b4f02c632f60",
        "control_net_2c428620e257",
        "control_net_8d69d598a971",
        "control_net_a0d28f360159",
        "control_net_6f005443ad9c",
        "control_net_3d9d791e8355",
        "control_net_00eadc59f9af",
        "control_net_6bc6649476ec",
        "control_net_d9edbd0f92ec",
        "control_net_2f8d843708d6",
        "control_net_4701afd22aa9",
        "control_net_c251169eb896",
        "control_net_0b94eea9a209",
        "control_net_75501c77d10a",
        "control_net_61b4ba86f12f",
        "control_net_ba92e944f30f",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_45ad74d728ee",
        "control_net_5f4121b0067b",
        "control_net_4dd63af5135a",
        "control_net_77550a265a38",
        "control_net_d35e6450ec18",
        "control_net_0c2767ceedce",
        "control_net_0aa940b07213",
        "control_net_95229f960617",
        "control_net_ae2900dc7735",
        "control_net_a3e916588f1a",
        "control_net_3591ba357658",
        "control_net_92af7290af48",
        "control_net_90cbd311d743",
        "control_net_76c093c7625c",
        "control_net_e4fd6a071815",
        "control_net_34a5458782a9",
        "control_net_708de604029c",
        "control_net_834296c71f70",
        "control_net_9e71347ab99c",
        "control_net_a0ccf5710062",
        "control_net_52c8c7557923",
        "control_net_fb7db09ec7c3",
        "control_net_e44786acaa30",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_fb2e9fe80e2d",
        "control_net_a6a3fee83c7f",
        "control_net_587cf1488c03",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_55817c8282e0",
        "control_net_ea07dd504c63",
        "control_net_81564ca10d04",
        "control_net_edfa87483431",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_e99ac6514624",
        "control_net_595e8f7ae0b8",
        "control_net_54c1f1eb7696",
        "control_net_f8ec39c4ab9d",
        "control_net_d3f1a4b3a597",
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_91e18b17f805",
        "control_net_c97f66f5a8ca",
        "control_net_246e53b44cf7",
        "control_net_cc4231e43005",
        "control_net_0229dc72e592",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_306a691e0334",
        "control_net_f0400a3868ce",
        "control_net_314c158ce4da",
        "control_net_1dcb8bcb468b",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_5fb1532b0e1e",
        "control_net_010b6b6f67c9",
        "control_net_d709c7f7b65c",
        "control_net_f19cdec7c823",
        "control_net_52a6b9dc2fac",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_ace5c68a2cc9",
        "control_net_c25a7182f56a",
        "control_net_6c708c43c5b9",
        "control_net_4a79582bd184",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_9b62758e037e",
        "control_net_39477ddd3ce1",
        "control_net_ccce32991990",
        "control_net_407e3d055e25",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_3bc7340649bd",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a",
        "control_net_5c5982e822c2",
        "control_net_0304d51af6c1",
        "control_net_9f2f629756c4",
        "control_net_2b95659e74de",
        "control_net_b22642780df7",
        "control_net_40fb51ba3b62",
        "control_net_6b666b9aabd9",
        "control_net_ee84b9bf0bbc",
        "control_net_6d232399d072",
        "control_net_55da05168177",
        "control_net_d44f364a5830",
        "control_net_bb3aaa71ba05",
        "control_net_be534772f175",
        "control_net_16617557f395",
        "control_net_c8980fec1127",
        "control_net_172656434fbc",
        "control_net_5220b4a56b5c",
        "control_net_c31eb8fe07d3",
        "control_net_d109bb25230c",
        "control_net_075227a69d18",
        "control_net_cdfcd01f3692",
        "control_net_e5afe79fa19e",
        "control_net_ebaa690e703b",
        "control_net_c4d0ccc3d16d",
        "control_net_d9ef0a17e785",
        "control_net_395f29bc0592",
        "control_net_d7ba445b9916",
        "control_net_907e4adf7ca2",
        "control_net_ccf3e014a0ef",
        "control_net_42c5791086ec",
        "control_net_d6b5309ee994",
        "control_net_42df6ae20837",
        "control_net_abae69816039",
        "control_net_707df60aeb98",
        "control_net_fd2bad63a67c",
        "control_net_4143ff0aef6d",
        "control_net_090eb35bbabe",
        "control_net_cccff17550b9",
        "control_net_185955b3a706",
        "control_net_9bda4980e75a",
        "control_net_4baca15034bf",
        "control_net_92d89f9df56c",
        "control_net_4bb6a512cc3a",
        "control_net_f4bfe5cdab56",
        "control_net_19bcc72c5488",
        "control_net_3ddfecb0df47",
        "control_net_58af204d8c23",
        "control_net_1d61ccb9d017",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_d586ee5fe950",
        "control_net_14e361774b31",
        "control_net_20b74826bb9f",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_ff9ff859ce5e",
        "control_net_c9c89af3970f",
        "control_net_101ecb817b3a",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_a4fbe32e37cd",
        "control_net_e0b8d44e15a9",
        "control_net_c491c2114b69",
        "control_net_8441e3506dc3",
        "control_net_feb9c68fc359",
        "control_net_b754ba5a60da",
        "control_net_af615c537cb1",
        "control_net_e83c3c7df2de",
        "control_net_3e9631f7c6ff",
        "control_net_7289e1b08835",
        "control_net_e773796fd1f6",
        "control_net_5cb04db620b0",
        "control_net_06de98680544",
        "control_net_66a9597ad7c2",
        "control_net_d00f8c30fd72",
        "control_net_e53226ed313e",
        "control_net_e7865782b189",
        "control_net_e39e2c0118dc",
        "control_net_0d1a4f8df7dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_3230bba6e369",
        "control_net_08fdee08456b",
        "control_net_9872096d1603",
        "control_net_5fd8dcc5fbb4",
        "control_net_dec8aaf78baf",
        "control_net_7208b29a2b1c",
        "control_net_fd223a19128e",
        "control_net_1ac6761e03ed",
        "control_net_937ff9979dc3",
        "control_net_85ba8fc9e715",
        "control_net_ac5068fd8652",
        "control_net_ca03fb089228",
        "control_net_1d078f5152c1",
        "control_net_8543c7028353",
        "control_net_fd8710ab620d",
        "control_net_4dea48708eb3",
        "control_net_efab486ffaed",
        "control_net_7f616706cf93",
        "control_net_8baeadc9d1f8",
        "control_net_da58769d7620",
        "control_net_b467eac10258",
        "control_net_a3c162bcb298",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_fe5724fe2bab",
        "control_net_b02072f17830",
        "control_net_82b207235505",
        "control_net_92cfc687656d",
        "control_net_bae01a82acc2",
        "control_net_168076ddc771",
        "control_net_def0213ce26f",
        "control_net_79395ecc284b",
        "control_net_410016c949d5",
        "control_net_71168801242c",
        "control_net_e542b9e16418",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf",
        "control_net_ef7dcf4c5ac1",
        "control_net_07a2fafb5ee8",
        "control_net_63296c08fb96",
        "control_net_0e6757f456c8",
        "control_net_fe9a6d2314d3",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_2b2d32129563",
        "control_net_63eb0399a909",
        "control_net_6d399f5ab100",
        "control_net_3216c2600ec6",
        "control_net_633521e6d31e",
        "control_net_0fed13c85d5f",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_429d3a1721ef",
        "control_net_30006651dbc3",
        "control_net_d2248f535667",
        "control_net_889281b6cc29",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_f05b5740e1a9",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_b2863a780247",
        "control_net_ba2ab40384c6",
        "control_net_45ba6797a43b",
        "control_net_c254fca78b2c",
        "control_net_1f04a0a6f06f",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_ff273c6660ec",
        "control_net_df16aaaa5404",
        "control_net_6e0242cad116",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_901bc97b19eb",
        "control_net_c86649734604",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_92b42c536ceb",
        "control_net_c4621dfd0ac4",
        "control_net_1a607d7041f2",
        "control_net_b33367a767ed",
        "control_net_47b21cc6bdbe",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98",
        "control_net_9586fff76126",
        "control_net_c57c59e45608",
        "control_net_c6e07c7a7de3",
        "control_net_cf8365500557",
        "control_net_818e010f96a4",
        "control_net_d3b6ad2c162f",
        "control_net_81e90041a4a7",
        "control_net_25ed8ee038f5",
        "control_net_4c0d3001839d",
        "control_net_6756bcf346dd",
        "control_net_8aa3f3702439",
        "control_net_32f74940b307"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A4",
          "netId": "control_net_0626002d4e17",
          "name": "MGTPTXN0_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A6",
          "netId": "control_net_4417efbf2ab6",
          "name": "MGTPTXN2_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B4",
          "netId": "control_net_cca629e55469",
          "name": "MGTPTXP0_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B6",
          "netId": "control_net_a36b4e28f2cd",
          "name": "MGTPTXP2_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C5",
          "netId": "control_net_17e68319e159",
          "name": "MGTPTXN1_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C7",
          "netId": "control_net_aefe57c66d3e",
          "name": "MGTPTXN3_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D5",
          "netId": "control_net_cbd39545f268",
          "name": "MGTPTXP1_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D7",
          "netId": "control_net_b935f05e6b88",
          "name": "MGTPTXP3_216",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E6",
          "netId": "control_net_f71ace5398bb",
          "name": "MGTREFCLK0N_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E10",
          "netId": "control_net_b4f02c632f60",
          "name": "MGTREFCLK1N_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F6",
          "netId": "control_net_2c428620e257",
          "name": "MGTREFCLK0P_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F10",
          "netId": "control_net_8d69d598a971",
          "name": "MGTREFCLK1P_216",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B14",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D18",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E15",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F22",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G19",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H16",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J13",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K20",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U8",
          "netId": "control_net_6f005443ad9c",
          "name": "CFGBVS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U11",
          "netId": "control_net_6f005443ad9c",
          "name": "M0_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G11",
          "netId": "control_net_3d9d791e8355",
          "name": "DONE_0",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K10",
          "netId": "control_net_00eadc59f9af",
          "name": "VCCADC_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L12",
          "netId": "control_net_6bc6649476ec",
          "name": "CCLK_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N9",
          "netId": "control_net_d9edbd0f92ec",
          "name": "DXN_0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N10",
          "netId": "control_net_2f8d843708d6",
          "name": "DXP_0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N12",
          "netId": "control_net_4701afd22aa9",
          "name": "PROGRAM_B_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R13",
          "netId": "control_net_c251169eb896",
          "name": "TDI_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T13",
          "netId": "control_net_0b94eea9a209",
          "name": "TMS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U12",
          "netId": "control_net_75501c77d10a",
          "name": "INIT_B_0",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U13",
          "netId": "control_net_61b4ba86f12f",
          "name": "TDO_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V12",
          "netId": "control_net_ba92e944f30f",
          "name": "TCK_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N13",
          "netId": "control_net_45ad74d728ee",
          "name": "IO_L23P_T3_A03_D19_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N14",
          "netId": "control_net_5f4121b0067b",
          "name": "IO_L23N_T3_A02_D18_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N15",
          "netId": "control_net_4dd63af5135a",
          "name": "IO_25_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N17",
          "netId": "control_net_77550a265a38",
          "name": "IO_L21P_T3_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P15",
          "netId": "control_net_0c2767ceedce",
          "name": "IO_L22P_T3_A05_D21_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P16",
          "netId": "control_net_0aa940b07213",
          "name": "IO_L24P_T3_A01_D17_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P17",
          "netId": "control_net_95229f960617",
          "name": "IO_L21N_T3_DQS_A06_D22_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P21",
          "netId": "control_net_3591ba357658",
          "name": "IO_L2P_T0_D02_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P22",
          "netId": "control_net_92af7290af48",
          "name": "IO_L1P_T0_D00_MOSI_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R16",
          "netId": "control_net_76c093c7625c",
          "name": "IO_L22N_T3_A04_D20_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R17",
          "netId": "control_net_e4fd6a071815",
          "name": "IO_L24N_T3_A00_D16_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R18",
          "netId": "control_net_34a5458782a9",
          "name": "IO_L20P_T3_A08_D24_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R21",
          "netId": "control_net_834296c71f70",
          "name": "IO_L2N_T0_D03_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R22",
          "netId": "control_net_9e71347ab99c",
          "name": "IO_L1N_T0_D01_DIN_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T18",
          "netId": "control_net_a0ccf5710062",
          "name": "IO_L20N_T3_A07_D23_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T19",
          "netId": "control_net_52c8c7557923",
          "name": "IO_L6P_T0_FCS_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U22",
          "netId": "control_net_587cf1488c03",
          "name": "IO_L3P_T0_DQS_PUDC_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W19",
          "netId": "control_net_81564ca10d04",
          "name": "IO_L12P_T1_MRCC_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A13",
          "netId": "control_net_e99ac6514624",
          "name": "IO_L10P_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A14",
          "netId": "control_net_595e8f7ae0b8",
          "name": "IO_L10N_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A15",
          "netId": "control_net_54c1f1eb7696",
          "name": "IO_L9P_T1_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A16",
          "netId": "control_net_f8ec39c4ab9d",
          "name": "IO_L9N_T1_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A18",
          "netId": "control_net_d3f1a4b3a597",
          "name": "IO_L17P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A19",
          "netId": "control_net_6943e9712d9c",
          "name": "IO_L17N_T2_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A20",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "IO_L16N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A21",
          "netId": "control_net_ac8599a8c0cd",
          "name": "IO_L21N_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B13",
          "netId": "control_net_91e18b17f805",
          "name": "IO_L8N_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B15",
          "netId": "control_net_c97f66f5a8ca",
          "name": "IO_L7P_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B16",
          "netId": "control_net_246e53b44cf7",
          "name": "IO_L7N_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B17",
          "netId": "control_net_cc4231e43005",
          "name": "IO_L11P_T1_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B18",
          "netId": "control_net_0229dc72e592",
          "name": "IO_L11N_T1_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B20",
          "netId": "control_net_c5d6e41ef012",
          "name": "IO_L16P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B21",
          "netId": "control_net_49b164ada644",
          "name": "IO_L21P_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B22",
          "netId": "control_net_63a08f54a8af",
          "name": "IO_L20N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C13",
          "netId": "control_net_306a691e0334",
          "name": "IO_L8P_T1_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C14",
          "netId": "control_net_f0400a3868ce",
          "name": "IO_L3P_T0_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C15",
          "netId": "control_net_314c158ce4da",
          "name": "IO_L3N_T0_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C17",
          "netId": "control_net_1dcb8bcb468b",
          "name": "IO_L12N_T1_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C18",
          "netId": "control_net_a46672b578ec",
          "name": "IO_L13P_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C19",
          "netId": "control_net_85a84369e22a",
          "name": "IO_L13N_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C20",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D15",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H18",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K14",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_A21_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C22",
          "netId": "control_net_010b6b6f67c9",
          "name": "IO_L20P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D14",
          "netId": "control_net_d709c7f7b65c",
          "name": "IO_L6P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D16",
          "netId": "control_net_f19cdec7c823",
          "name": "IO_L5N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D17",
          "netId": "control_net_52a6b9dc2fac",
          "name": "IO_L12P_T1_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D19",
          "netId": "control_net_d514c816e952",
          "name": "IO_L14N_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D20",
          "netId": "control_net_3a2594a1e1f9",
          "name": "IO_L19P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D21",
          "netId": "control_net_9bc7997904a8",
          "name": "IO_L23N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D22",
          "netId": "control_net_6e031edce63d",
          "name": "IO_L22N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E13",
          "netId": "control_net_ace5c68a2cc9",
          "name": "IO_L4P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E14",
          "netId": "control_net_c25a7182f56a",
          "name": "IO_L4N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E16",
          "netId": "control_net_6c708c43c5b9",
          "name": "IO_L5P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E17",
          "netId": "control_net_4a79582bd184",
          "name": "IO_L2N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E18",
          "netId": "control_net_17b46c5249cb",
          "name": "IO_L15N_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E19",
          "netId": "control_net_4ff8255e049a",
          "name": "IO_L14P_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E21",
          "netId": "control_net_18e1c9509d79",
          "name": "IO_L23P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E22",
          "netId": "control_net_d2bff6eceb03",
          "name": "IO_L22P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F13",
          "netId": "control_net_9b62758e037e",
          "name": "IO_L1P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F14",
          "netId": "control_net_39477ddd3ce1",
          "name": "IO_L1N_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F15",
          "netId": "control_net_ccce32991990",
          "name": "IO_0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F16",
          "netId": "control_net_407e3d055e25",
          "name": "IO_L2P_T0_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F18",
          "netId": "control_net_dc796dddd274",
          "name": "IO_L15P_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F19",
          "netId": "control_net_184f5bb728b0",
          "name": "IO_L18P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F20",
          "netId": "control_net_0065f370787e",
          "name": "IO_L18N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F21",
          "netId": "control_net_3bc7340649bd",
          "name": "IO_25_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G21",
          "netId": "control_net_710e1e095743",
          "name": "IO_L24P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G22",
          "netId": "control_net_3a720de9ef0a",
          "name": "IO_L24N_T3_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G13",
          "netId": "control_net_5c5982e822c2",
          "name": "IO_L1N_T0_AD0N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G15",
          "netId": "control_net_0304d51af6c1",
          "name": "IO_L2P_T0_AD8P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G16",
          "netId": "control_net_9f2f629756c4",
          "name": "IO_L2N_T0_AD8N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G17",
          "netId": "control_net_2b95659e74de",
          "name": "IO_L4P_T0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G18",
          "netId": "control_net_b22642780df7",
          "name": "IO_L4N_T0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G20",
          "netId": "control_net_40fb51ba3b62",
          "name": "IO_L8N_T1_AD10N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H13",
          "netId": "control_net_6b666b9aabd9",
          "name": "IO_L1P_T0_AD0P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H14",
          "netId": "control_net_ee84b9bf0bbc",
          "name": "IO_L3N_T0_DQS_AD1N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H15",
          "netId": "control_net_6d232399d072",
          "name": "IO_L5N_T0_AD9N_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H17",
          "netId": "control_net_55da05168177",
          "name": "IO_L6P_T0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H19",
          "netId": "control_net_d44f364a5830",
          "name": "IO_L12N_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H20",
          "netId": "control_net_bb3aaa71ba05",
          "name": "IO_L8P_T1_AD10P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H22",
          "netId": "control_net_be534772f175",
          "name": "IO_L7N_T1_AD2N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J14",
          "netId": "control_net_16617557f395",
          "name": "IO_L3P_T0_DQS_AD1P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J15",
          "netId": "control_net_c8980fec1127",
          "name": "IO_L5P_T0_AD9P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J16",
          "netId": "control_net_172656434fbc",
          "name": "IO_0_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J17",
          "netId": "control_net_5220b4a56b5c",
          "name": "IO_L21N_T3_DQS_A18_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J19",
          "netId": "control_net_c31eb8fe07d3",
          "name": "IO_L12P_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J20",
          "netId": "control_net_d109bb25230c",
          "name": "IO_L11P_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J21",
          "netId": "control_net_075227a69d18",
          "name": "IO_L11N_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J22",
          "netId": "control_net_cdfcd01f3692",
          "name": "IO_L7P_T1_AD2P_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K13",
          "netId": "control_net_e5afe79fa19e",
          "name": "IO_L19P_T3_A22_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K16",
          "netId": "control_net_ebaa690e703b",
          "name": "IO_L23N_T3_FWE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K17",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "IO_L21P_T3_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K18",
          "netId": "control_net_d9ef0a17e785",
          "name": "IO_L13P_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K19",
          "netId": "control_net_395f29bc0592",
          "name": "IO_L13N_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K21",
          "netId": "control_net_d7ba445b9916",
          "name": "IO_L9P_T1_DQS_AD3P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K22",
          "netId": "control_net_907e4adf7ca2",
          "name": "IO_L9N_T1_DQS_AD3N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L13",
          "netId": "control_net_ccf3e014a0ef",
          "name": "IO_L20N_T3_A19_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L14",
          "netId": "control_net_42c5791086ec",
          "name": "IO_L22P_T3_A17_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L15",
          "netId": "control_net_d6b5309ee994",
          "name": "IO_L22N_T3_A16_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L16",
          "netId": "control_net_42df6ae20837",
          "name": "IO_L23P_T3_FOE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L18",
          "netId": "control_net_abae69816039",
          "name": "IO_L16N_T2_A27_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L19",
          "netId": "control_net_707df60aeb98",
          "name": "IO_L14P_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L20",
          "netId": "control_net_fd2bad63a67c",
          "name": "IO_L14N_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L21",
          "netId": "control_net_4143ff0aef6d",
          "name": "IO_L10N_T1_AD11N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M13",
          "netId": "control_net_090eb35bbabe",
          "name": "IO_L20P_T3_A20_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M15",
          "netId": "control_net_cccff17550b9",
          "name": "IO_L24P_T3_RS1_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M16",
          "netId": "control_net_185955b3a706",
          "name": "IO_L24N_T3_RS0_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M17",
          "netId": "control_net_9bda4980e75a",
          "name": "IO_25_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M18",
          "netId": "control_net_4baca15034bf",
          "name": "IO_L16P_T2_A28_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M20",
          "netId": "control_net_92d89f9df56c",
          "name": "IO_L18N_T2_A23_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M21",
          "netId": "control_net_4bb6a512cc3a",
          "name": "IO_L10P_T1_AD11P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M22",
          "netId": "control_net_f4bfe5cdab56",
          "name": "IO_L15N_T2_DQS_ADV_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N18",
          "netId": "control_net_19bcc72c5488",
          "name": "IO_L17P_T2_A26_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N19",
          "netId": "control_net_3ddfecb0df47",
          "name": "IO_L17N_T2_A25_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N20",
          "netId": "control_net_58af204d8c23",
          "name": "IO_L18P_T2_A24_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N22",
          "netId": "control_net_1d61ccb9d017",
          "name": "IO_L15P_T2_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA11",
          "netId": "control_net_d586ee5fe950",
          "name": "IO_L9N_T1_DQS_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T14",
          "netId": "control_net_a4fbe32e37cd",
          "name": "IO_L15P_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T15",
          "netId": "control_net_e0b8d44e15a9",
          "name": "IO_L15N_T2_DQS_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T16",
          "netId": "control_net_c491c2114b69",
          "name": "IO_L17P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U15",
          "netId": "control_net_8441e3506dc3",
          "name": "IO_L14P_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U16",
          "netId": "control_net_feb9c68fc359",
          "name": "IO_L17N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V10",
          "netId": "control_net_b754ba5a60da",
          "name": "IO_L10P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V14",
          "netId": "control_net_e83c3c7df2de",
          "name": "IO_L13N_T2_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V15",
          "netId": "control_net_3e9631f7c6ff",
          "name": "IO_L14N_T2_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W10",
          "netId": "control_net_7289e1b08835",
          "name": "IO_L10N_T1_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W12",
          "netId": "control_net_5cb04db620b0",
          "name": "IO_L12N_T1_MRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W15",
          "netId": "control_net_66a9597ad7c2",
          "name": "IO_L16P_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W16",
          "netId": "control_net_d00f8c30fd72",
          "name": "IO_L16N_T2_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y11",
          "netId": "control_net_e53226ed313e",
          "name": "IO_L11P_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y12",
          "netId": "control_net_e7865782b189",
          "name": "IO_L11N_T1_SRCC_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA1",
          "netId": "control_net_3230bba6e369",
          "name": "IO_L7P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA3",
          "netId": "control_net_08fdee08456b",
          "name": "IO_L9N_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA4",
          "netId": "control_net_9872096d1603",
          "name": "IO_L11N_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA5",
          "netId": "control_net_5fd8dcc5fbb4",
          "name": "IO_L10P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA6",
          "netId": "control_net_dec8aaf78baf",
          "name": "IO_L18N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA8",
          "netId": "control_net_7208b29a2b1c",
          "name": "IO_L22P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB1",
          "netId": "control_net_fd223a19128e",
          "name": "IO_L7N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB2",
          "netId": "control_net_1ac6761e03ed",
          "name": "IO_L8N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB3",
          "netId": "control_net_937ff9979dc3",
          "name": "IO_L8P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB5",
          "netId": "control_net_85ba8fc9e715",
          "name": "IO_L10N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB6",
          "netId": "control_net_ac5068fd8652",
          "name": "IO_L20N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB7",
          "netId": "control_net_ca03fb089228",
          "name": "IO_L20P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB8",
          "netId": "control_net_1d078f5152c1",
          "name": "IO_L22N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R4",
          "netId": "control_net_4dea48708eb3",
          "name": "IO_L13P_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R6",
          "netId": "control_net_efab486ffaed",
          "name": "IO_L17P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T4",
          "netId": "control_net_da58769d7620",
          "name": "IO_L13N_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T5",
          "netId": "control_net_b467eac10258",
          "name": "IO_L14P_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T6",
          "netId": "control_net_a3c162bcb298",
          "name": "IO_L17N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U3",
          "netId": "control_net_fe5724fe2bab",
          "name": "IO_L6P_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U5",
          "netId": "control_net_b02072f17830",
          "name": "IO_L14N_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U6",
          "netId": "control_net_82b207235505",
          "name": "IO_L16P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U7",
          "netId": "control_net_92cfc687656d",
          "name": "IO_25_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V3",
          "netId": "control_net_168076ddc771",
          "name": "IO_L6N_T0_VREF_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V4",
          "netId": "control_net_def0213ce26f",
          "name": "IO_L12P_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V5",
          "netId": "control_net_79395ecc284b",
          "name": "IO_L16N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V7",
          "netId": "control_net_410016c949d5",
          "name": "IO_L19P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V8",
          "netId": "control_net_71168801242c",
          "name": "IO_L21N_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V9",
          "netId": "control_net_e542b9e16418",
          "name": "IO_L21P_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W4",
          "netId": "control_net_ef7dcf4c5ac1",
          "name": "IO_L12N_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W5",
          "netId": "control_net_07a2fafb5ee8",
          "name": "IO_L15N_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W6",
          "netId": "control_net_63296c08fb96",
          "name": "IO_L15P_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W7",
          "netId": "control_net_0e6757f456c8",
          "name": "IO_L19N_T3_VREF_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W9",
          "netId": "control_net_fe9a6d2314d3",
          "name": "IO_L24P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y3",
          "netId": "control_net_2b2d32129563",
          "name": "IO_L9P_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y4",
          "netId": "control_net_63eb0399a909",
          "name": "IO_L11P_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y6",
          "netId": "control_net_6d399f5ab100",
          "name": "IO_L18P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y7",
          "netId": "control_net_3216c2600ec6",
          "name": "IO_L23N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y8",
          "netId": "control_net_633521e6d31e",
          "name": "IO_L23P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y9",
          "netId": "control_net_0fed13c85d5f",
          "name": "IO_L24N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E3",
          "netId": "control_net_2690ba9f85c2",
          "name": "IO_L6N_T0_VREF_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F1",
          "netId": "control_net_1060da4e1062",
          "name": "IO_L5N_T0_AD13N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F3",
          "netId": "control_net_8e945f7df341",
          "name": "IO_L6P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G1",
          "netId": "control_net_103f84ec6132",
          "name": "IO_L5P_T0_AD13P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G2",
          "netId": "control_net_c6ecade8f839",
          "name": "IO_L8N_T1_AD14N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G3",
          "netId": "control_net_8e9184bc5c46",
          "name": "IO_L11N_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G4",
          "netId": "control_net_b2863a780247",
          "name": "IO_L12N_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H2",
          "netId": "control_net_ba2ab40384c6",
          "name": "IO_L8P_T1_AD14P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H3",
          "netId": "control_net_45ba6797a43b",
          "name": "IO_L11P_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H4",
          "netId": "control_net_c254fca78b2c",
          "name": "IO_L12P_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H5",
          "netId": "control_net_1f04a0a6f06f",
          "name": "IO_L10N_T1_AD15N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J1",
          "netId": "control_net_f16f12a0707d",
          "name": "IO_L7N_T1_AD6N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J2",
          "netId": "control_net_d095506d8145",
          "name": "IO_L9N_T1_DQS_AD7N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J4",
          "netId": "control_net_ff273c6660ec",
          "name": "IO_L13N_T2_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J5",
          "netId": "control_net_df16aaaa5404",
          "name": "IO_L10P_T1_AD15P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J6",
          "netId": "control_net_6e0242cad116",
          "name": "IO_L17N_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K1",
          "netId": "control_net_2a00cc654f3d",
          "name": "IO_L7P_T1_AD6P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K2",
          "netId": "control_net_5130997c4fe8",
          "name": "IO_L9P_T1_DQS_AD7P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K3",
          "netId": "control_net_901bc97b19eb",
          "name": "IO_L14N_T2_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K4",
          "netId": "control_net_c86649734604",
          "name": "IO_L13P_T2_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L3",
          "netId": "control_net_92b42c536ceb",
          "name": "IO_L14P_T2_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L5",
          "netId": "control_net_1a607d7041f2",
          "name": "IO_L18P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L6",
          "netId": "control_net_b33367a767ed",
          "name": "IO_25_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M1",
          "netId": "control_net_47b21cc6bdbe",
          "name": "IO_L15P_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M5",
          "netId": "control_net_9586fff76126",
          "name": "IO_L23N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M6",
          "netId": "control_net_c57c59e45608",
          "name": "IO_L23P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N2",
          "netId": "control_net_c6e07c7a7de3",
          "name": "IO_L22N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N3",
          "netId": "control_net_cf8365500557",
          "name": "IO_L19N_T3_VREF_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N4",
          "netId": "control_net_818e010f96a4",
          "name": "IO_L19P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N5",
          "netId": "control_net_d3b6ad2c162f",
          "name": "IO_L24N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P1",
          "netId": "control_net_81e90041a4a7",
          "name": "IO_L20N_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P2",
          "netId": "control_net_25ed8ee038f5",
          "name": "IO_L22P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P4",
          "netId": "control_net_4c0d3001839d",
          "name": "IO_L21N_T3_DQS_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P5",
          "netId": "control_net_6756bcf346dd",
          "name": "IO_L21P_T3_DQS_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P6",
          "netId": "control_net_8aa3f3702439",
          "name": "IO_L24P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R1",
          "netId": "control_net_32f74940b307",
          "name": "IO_L20P_T3_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигналы INIT и DONE",
      "text": "Состояние конфигурации передаётся основному контроллеру через буферы между доменами.",
      "body": "Состояние конфигурации передаётся основному контроллеру через буферы между доменами.",
      "nodes": [
        "fpga",
        "mcu"
      ],
      "edges": [
        "mcu_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка готовности программы",
      "text": "Перед экспериментами загруженная прикладная логика должна проверить готовность связи и памяти.",
      "body": "Перед экспериментами загруженная прикладная логика должна проверить готовность связи и памяти.",
      "nodes": [
        "fpga",
        "mcu",
        "links"
      ],
      "edges": [
        "links_fpga",
        "mcu_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
