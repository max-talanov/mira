/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "ethernet-tx",
  "title": "Передача результатов на компьютер",
  "description": "Проследите обратный путь измеренных данных через интерфейс связи.",
  "sceneId": "system",
  "steps": [
    {
      "title": "Получение отклика",
      "text": "Измерительный тракт матрицы преобразует электрический отклик в отсчёты АЦП.",
      "body": "Измерительный тракт матрицы преобразует электрический отклик в отсчёты АЦП.",
      "nodes": [
        "matrix",
        "readout"
      ],
      "edges": [
        "matrix_readout"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d65f00f0a2d4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сбор цифровых отсчётов",
      "text": "Логика ПЛИС принимает оцифрованное измерение.",
      "body": "Логика ПЛИС принимает оцифрованное измерение.",
      "nodes": [
        "readout",
        "fpga"
      ],
      "edges": [
        "readout_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Передача данных в интерфейс",
      "text": "Выбранная реализация связи передаёт результаты на физический интерфейс.",
      "body": "Выбранная реализация связи передаёт результаты на физический интерфейс.",
      "nodes": [
        "fpga",
        "links"
      ],
      "edges": [
        "links_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Отображение результата",
      "text": "Компьютер принимает и отображает полученные данные.",
      "body": "Компьютер принимает и отображает полученные данные.",
      "nodes": [
        "links",
        "host"
      ],
      "edges": [
        "host_links"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_3e4cca7b1d3b",
        "control_net_bb9ef2893216",
        "control_net_8a18244b5094",
        "control_net_dfb816a62c27",
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020",
        "control_net_1a636efbadbe",
        "control_net_4a77ae0a5e9e",
        "control_net_cd5767d1244a",
        "control_net_3fea9522f27f",
        "control_net_9cc415b59d1d",
        "control_net_81e7ad5ba413",
        "control_net_df8eca2f9d5c",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_352fe6713403",
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9",
        "control_net_a66b4051999a",
        "control_net_bd3f491e3f16",
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_34a5458782a9",
        "control_net_a0ccf5710062",
        "control_net_77550a265a38",
        "control_net_95229f960617",
        "control_net_76c093c7625c",
        "control_net_0c2767ceedce",
        "control_net_e4fd6a071815",
        "control_net_5f4121b0067b",
        "control_net_45ad74d728ee",
        "control_net_0aa940b07213",
        "control_net_5d12a42f13a7",
        "control_net_e66cd8acd51a",
        "control_net_92e96a7a3b30",
        "control_net_afea1d1e21fd",
        "control_net_81564ca10d04",
        "control_net_b1490930ce10",
        "control_net_3ab09453d63e",
        "control_net_6f005443ad9c",
        "control_net_cb3be8fb391c",
        "control_net_db15969a3ef3",
        "control_net_66452339ef9c",
        "control_net_fbb29cb27034",
        "control_net_62e5d80fdc50",
        "control_net_4ab70b5a5d2e",
        "control_net_90ccce2c8039",
        "control_net_ee1064f82d57",
        "control_net_4e0bed631879",
        "control_net_b6e5a544d44c",
        "control_net_6d1b692341f6",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_01a067f231f5",
        "control_net_08fb6faf20a6",
        "control_net_9a988f0c62fc",
        "control_net_ea07dd504c63",
        "control_net_2e89b83a9cd1",
        "control_net_4a9a6e85b720",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_b7668147936d",
        "control_net_506391066785",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_f6bb2b64e768",
        "control_net_c7652af8ac7f",
        "control_net_e227481650c4",
        "control_net_96c985883507",
        "control_net_2b9e82ff1f9a",
        "control_net_c06d53ceafd7",
        "control_net_ca505632df44",
        "control_net_c72c6f1d768f",
        "control_net_d0a4baabec4c",
        "control_net_eb9eb2217e86",
        "control_net_1c78c5a73725",
        "control_net_b6ac01ebb28c",
        "control_net_06de98680544",
        "control_net_20b74826bb9f",
        "control_net_766c613eb974",
        "control_net_f755d28cb131",
        "control_net_842a1bd896e7",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_5682aa39e237",
        "control_net_14e361774b31",
        "control_net_cc90c66f0af7",
        "control_net_7a2cc9ad1aae",
        "control_net_dbd1a2d49097",
        "control_net_e39e2c0118dc",
        "control_net_8da86f1b7a73",
        "control_net_8df81571784a",
        "control_net_882df4161e30",
        "control_net_0d1a4f8df7dc",
        "control_net_bd5cd984cf36",
        "control_net_efee1e569907",
        "control_net_b1e90866b0af",
        "control_net_a6f01595797b",
        "control_net_9bc8e82b976f",
        "control_net_45dfddf2e1c0",
        "control_net_7d62beb03b56",
        "control_net_732d19ff86ef",
        "control_net_91263f868356",
        "control_net_f804f3303e2d",
        "control_net_1d2540c92513"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J700",
          "pin": "A2",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "SSTX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A3",
          "netId": "control_net_bb9ef2893216",
          "name": "SSTX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A5",
          "netId": "control_net_dfb816a62c27",
          "name": "CC1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "23",
          "netId": "control_net_95ec31f2c17b",
          "name": "DP",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "25",
          "netId": "control_net_93c1caa5f020",
          "name": "DM",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A8",
          "netId": "control_net_1a636efbadbe",
          "name": "SBU1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A10",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "SSRX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A11",
          "netId": "control_net_cd5767d1244a",
          "name": "SSRX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B2",
          "netId": "control_net_3fea9522f27f",
          "name": "SSTX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B3",
          "netId": "control_net_9cc415b59d1d",
          "name": "SSTX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B5",
          "netId": "control_net_81e7ad5ba413",
          "name": "CC2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B8",
          "netId": "control_net_df8eca2f9d5c",
          "name": "SBU2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B10",
          "netId": "control_net_7293b201db23",
          "name": "SSRX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B11",
          "netId": "control_net_c17cad38b3b9",
          "name": "SSRX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "S1",
          "netId": "control_net_352fe6713403",
          "name": "Shield_(4_tabs)",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "SH",
          "netId": "control_net_352fe6713403",
          "name": "Shield",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "24",
          "netId": "control_net_eb689a40d9d8",
          "name": "MXA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "22",
          "netId": "control_net_a0be4ca78cf4",
          "name": "MXA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "21",
          "netId": "control_net_783e9d027a80",
          "name": "MXB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "18",
          "netId": "control_net_e72d81f71514",
          "name": "MXC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "16",
          "netId": "control_net_75386a9fba9e",
          "name": "MXC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "19",
          "netId": "control_net_40965b12abcc",
          "name": "MXB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "15",
          "netId": "control_net_46a7e4543439",
          "name": "MXD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "13",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "MXD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "10",
          "netId": "control_net_a66b4051999a",
          "name": "Green_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "12",
          "netId": "control_net_bd3f491e3f16",
          "name": "Yellow_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "4",
          "netId": "control_net_34a5458782a9",
          "name": "BE_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "5",
          "netId": "control_net_a0ccf5710062",
          "name": "BE_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "6",
          "netId": "control_net_77550a265a38",
          "name": "BE_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "7",
          "netId": "control_net_95229f960617",
          "name": "BE_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "8",
          "netId": "control_net_76c093c7625c",
          "name": "TXE_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "9",
          "netId": "control_net_0c2767ceedce",
          "name": "RXF_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "10",
          "netId": "control_net_e4fd6a071815",
          "name": "SIWU_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "11",
          "netId": "control_net_5f4121b0067b",
          "name": "WR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "12",
          "netId": "control_net_45ad74d728ee",
          "name": "RD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "13",
          "netId": "control_net_0aa940b07213",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "15",
          "netId": "control_net_5d12a42f13a7",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "16",
          "netId": "control_net_e66cd8acd51a",
          "name": "WAKEUP_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "17",
          "netId": "control_net_92e96a7a3b30",
          "name": "GPIO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "18",
          "netId": "control_net_afea1d1e21fd",
          "name": "GPIO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "58",
          "netId": "control_net_81564ca10d04",
          "name": "CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "2",
          "netId": "control_net_b1490930ce10",
          "name": "AVDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "3",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "30",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "33",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "39",
          "netId": "control_net_3ab09453d63e",
          "name": "DV10",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "48",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC33",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "24",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC33",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "38",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC33",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "49",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "59",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "68",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "19",
          "netId": "control_net_6f005443ad9c",
          "name": "VDDIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "22",
          "netId": "control_net_6f005443ad9c",
          "name": "JTAG_TMS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "23",
          "netId": "control_net_6f005443ad9c",
          "name": "JTAG_TDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "30",
          "netId": "control_net_6f005443ad9c",
          "name": "VDDIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "41",
          "netId": "control_net_6f005443ad9c",
          "name": "VDDIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "19",
          "netId": "control_net_cb3be8fb391c",
          "name": "RESERVED",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "21",
          "netId": "control_net_db15969a3ef3",
          "name": "XI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "22",
          "netId": "control_net_66452339ef9c",
          "name": "XO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "27",
          "netId": "control_net_fbb29cb27034",
          "name": "RREF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "28",
          "netId": "control_net_62e5d80fdc50",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "31",
          "netId": "control_net_4ab70b5a5d2e",
          "name": "TODN",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "32",
          "netId": "control_net_90ccce2c8039",
          "name": "TODP",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "34",
          "netId": "control_net_ee1064f82d57",
          "name": "RIDN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "35",
          "netId": "control_net_4e0bed631879",
          "name": "RIDP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "37",
          "netId": "control_net_b6e5a544d44c",
          "name": "VBUS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TD_P_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TDA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "2",
          "netId": "control_net_506391066785",
          "name": "CT_PHY_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "2",
          "netId": "control_net_f14d9beef5b0",
          "name": "TD_M_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "3",
          "netId": "control_net_f14d9beef5b0",
          "name": "TDA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TD_P_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TDB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "5",
          "netId": "control_net_f6bb2b64e768",
          "name": "CT_PHY_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "5",
          "netId": "control_net_c7652af8ac7f",
          "name": "TD_M_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "6",
          "netId": "control_net_c7652af8ac7f",
          "name": "TDB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TD_P_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TDC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "8",
          "netId": "control_net_96c985883507",
          "name": "CT_PHY_C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "8",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TD_M_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "9",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TDC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TD_P_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TDD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "11",
          "netId": "control_net_ca505632df44",
          "name": "CT_PHY_D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "11",
          "netId": "control_net_c72c6f1d768f",
          "name": "TD_M_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "12",
          "netId": "control_net_c72c6f1d768f",
          "name": "TDD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "14",
          "netId": "control_net_d0a4baabec4c",
          "name": "CT_CABLE_D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "17",
          "netId": "control_net_eb9eb2217e86",
          "name": "CT_CABLE_C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "20",
          "netId": "control_net_1c78c5a73725",
          "name": "CT_CABLE_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "23",
          "netId": "control_net_b6ac01ebb28c",
          "name": "CT_CABLE_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "16",
          "netId": "control_net_06de98680544",
          "name": "MDC",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "17",
          "netId": "control_net_20b74826bb9f",
          "name": "MDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "18",
          "netId": "control_net_766c613eb974",
          "name": "CLK_OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "39",
          "netId": "control_net_8da86f1b7a73",
          "name": "GPIO_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "40",
          "netId": "control_net_8df81571784a",
          "name": "GPIO_1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "43",
          "netId": "control_net_882df4161e30",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "44",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "INT/PWDN",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "45",
          "netId": "control_net_bd5cd984cf36",
          "name": "LED_2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "46",
          "netId": "control_net_efee1e569907",
          "name": "LED_1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "47",
          "netId": "control_net_b1e90866b0af",
          "name": "LED_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "12",
          "netId": "control_net_a6f01595797b",
          "name": "RBIAS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "14",
          "netId": "control_net_9bc8e82b976f",
          "name": "XO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "15",
          "netId": "control_net_45dfddf2e1c0",
          "name": "XI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "3",
          "netId": "control_net_7d62beb03b56",
          "name": "VDDA2P5",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "9",
          "netId": "control_net_7d62beb03b56",
          "name": "VDDA2P5",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "6",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "24",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "31",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "42",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "13",
          "netId": "control_net_91263f868356",
          "name": "VDDA1P8",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "21",
          "netId": "control_net_f804f3303e2d",
          "name": "JTAG_TDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "48",
          "netId": "control_net_1d2540c92513",
          "name": "VDDA1P8",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Получение отклика",
      "text": "Измерительный тракт матрицы преобразует электрический отклик в отсчёты АЦП.",
      "body": "Измерительный тракт матрицы преобразует электрический отклик в отсчёты АЦП.",
      "nodes": [
        "matrix",
        "readout"
      ],
      "edges": [
        "matrix_readout"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d65f00f0a2d4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сбор цифровых отсчётов",
      "text": "Логика ПЛИС принимает оцифрованное измерение.",
      "body": "Логика ПЛИС принимает оцифрованное измерение.",
      "nodes": [
        "readout",
        "fpga"
      ],
      "edges": [
        "readout_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Передача данных в интерфейс",
      "text": "Выбранная реализация связи передаёт результаты на физический интерфейс.",
      "body": "Выбранная реализация связи передаёт результаты на физический интерфейс.",
      "nodes": [
        "fpga",
        "links"
      ],
      "edges": [
        "links_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Отображение результата",
      "text": "Компьютер принимает и отображает полученные данные.",
      "body": "Компьютер принимает и отображает полученные данные.",
      "nodes": [
        "links",
        "host"
      ],
      "edges": [
        "host_links"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_3e4cca7b1d3b",
        "control_net_bb9ef2893216",
        "control_net_8a18244b5094",
        "control_net_dfb816a62c27",
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020",
        "control_net_1a636efbadbe",
        "control_net_4a77ae0a5e9e",
        "control_net_cd5767d1244a",
        "control_net_3fea9522f27f",
        "control_net_9cc415b59d1d",
        "control_net_81e7ad5ba413",
        "control_net_df8eca2f9d5c",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_352fe6713403",
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9",
        "control_net_a66b4051999a",
        "control_net_bd3f491e3f16",
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_34a5458782a9",
        "control_net_a0ccf5710062",
        "control_net_77550a265a38",
        "control_net_95229f960617",
        "control_net_76c093c7625c",
        "control_net_0c2767ceedce",
        "control_net_e4fd6a071815",
        "control_net_5f4121b0067b",
        "control_net_45ad74d728ee",
        "control_net_0aa940b07213",
        "control_net_5d12a42f13a7",
        "control_net_e66cd8acd51a",
        "control_net_92e96a7a3b30",
        "control_net_afea1d1e21fd",
        "control_net_81564ca10d04",
        "control_net_b1490930ce10",
        "control_net_3ab09453d63e",
        "control_net_6f005443ad9c",
        "control_net_cb3be8fb391c",
        "control_net_db15969a3ef3",
        "control_net_66452339ef9c",
        "control_net_fbb29cb27034",
        "control_net_62e5d80fdc50",
        "control_net_4ab70b5a5d2e",
        "control_net_90ccce2c8039",
        "control_net_ee1064f82d57",
        "control_net_4e0bed631879",
        "control_net_b6e5a544d44c",
        "control_net_6d1b692341f6",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_01a067f231f5",
        "control_net_08fb6faf20a6",
        "control_net_9a988f0c62fc",
        "control_net_ea07dd504c63",
        "control_net_2e89b83a9cd1",
        "control_net_4a9a6e85b720",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_b7668147936d",
        "control_net_506391066785",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_f6bb2b64e768",
        "control_net_c7652af8ac7f",
        "control_net_e227481650c4",
        "control_net_96c985883507",
        "control_net_2b9e82ff1f9a",
        "control_net_c06d53ceafd7",
        "control_net_ca505632df44",
        "control_net_c72c6f1d768f",
        "control_net_d0a4baabec4c",
        "control_net_eb9eb2217e86",
        "control_net_1c78c5a73725",
        "control_net_b6ac01ebb28c",
        "control_net_06de98680544",
        "control_net_20b74826bb9f",
        "control_net_766c613eb974",
        "control_net_f755d28cb131",
        "control_net_842a1bd896e7",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_5682aa39e237",
        "control_net_14e361774b31",
        "control_net_cc90c66f0af7",
        "control_net_7a2cc9ad1aae",
        "control_net_dbd1a2d49097",
        "control_net_e39e2c0118dc",
        "control_net_8da86f1b7a73",
        "control_net_8df81571784a",
        "control_net_882df4161e30",
        "control_net_0d1a4f8df7dc",
        "control_net_bd5cd984cf36",
        "control_net_efee1e569907",
        "control_net_b1e90866b0af",
        "control_net_a6f01595797b",
        "control_net_9bc8e82b976f",
        "control_net_45dfddf2e1c0",
        "control_net_7d62beb03b56",
        "control_net_732d19ff86ef",
        "control_net_91263f868356",
        "control_net_f804f3303e2d",
        "control_net_1d2540c92513"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J700",
          "pin": "A2",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "SSTX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A3",
          "netId": "control_net_bb9ef2893216",
          "name": "SSTX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A5",
          "netId": "control_net_dfb816a62c27",
          "name": "CC1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "23",
          "netId": "control_net_95ec31f2c17b",
          "name": "DP",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "25",
          "netId": "control_net_93c1caa5f020",
          "name": "DM",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A8",
          "netId": "control_net_1a636efbadbe",
          "name": "SBU1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A10",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "SSRX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A11",
          "netId": "control_net_cd5767d1244a",
          "name": "SSRX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B2",
          "netId": "control_net_3fea9522f27f",
          "name": "SSTX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B3",
          "netId": "control_net_9cc415b59d1d",
          "name": "SSTX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B5",
          "netId": "control_net_81e7ad5ba413",
          "name": "CC2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B8",
          "netId": "control_net_df8eca2f9d5c",
          "name": "SBU2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B10",
          "netId": "control_net_7293b201db23",
          "name": "SSRX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B11",
          "netId": "control_net_c17cad38b3b9",
          "name": "SSRX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "S1",
          "netId": "control_net_352fe6713403",
          "name": "Shield_(4_tabs)",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "SH",
          "netId": "control_net_352fe6713403",
          "name": "Shield",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "24",
          "netId": "control_net_eb689a40d9d8",
          "name": "MXA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "22",
          "netId": "control_net_a0be4ca78cf4",
          "name": "MXA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "21",
          "netId": "control_net_783e9d027a80",
          "name": "MXB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "18",
          "netId": "control_net_e72d81f71514",
          "name": "MXC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "16",
          "netId": "control_net_75386a9fba9e",
          "name": "MXC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "19",
          "netId": "control_net_40965b12abcc",
          "name": "MXB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "15",
          "netId": "control_net_46a7e4543439",
          "name": "MXD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "13",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "MXD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "10",
          "netId": "control_net_a66b4051999a",
          "name": "Green_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "12",
          "netId": "control_net_bd3f491e3f16",
          "name": "Yellow_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "4",
          "netId": "control_net_34a5458782a9",
          "name": "BE_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "5",
          "netId": "control_net_a0ccf5710062",
          "name": "BE_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "6",
          "netId": "control_net_77550a265a38",
          "name": "BE_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "7",
          "netId": "control_net_95229f960617",
          "name": "BE_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "8",
          "netId": "control_net_76c093c7625c",
          "name": "TXE_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "9",
          "netId": "control_net_0c2767ceedce",
          "name": "RXF_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "10",
          "netId": "control_net_e4fd6a071815",
          "name": "SIWU_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "11",
          "netId": "control_net_5f4121b0067b",
          "name": "WR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "12",
          "netId": "control_net_45ad74d728ee",
          "name": "RD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "13",
          "netId": "control_net_0aa940b07213",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "15",
          "netId": "control_net_5d12a42f13a7",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "16",
          "netId": "control_net_e66cd8acd51a",
          "name": "WAKEUP_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "17",
          "netId": "control_net_92e96a7a3b30",
          "name": "GPIO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "18",
          "netId": "control_net_afea1d1e21fd",
          "name": "GPIO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "58",
          "netId": "control_net_81564ca10d04",
          "name": "CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "2",
          "netId": "control_net_b1490930ce10",
          "name": "AVDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "3",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "30",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "33",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "39",
          "netId": "control_net_3ab09453d63e",
          "name": "DV10",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "48",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC33",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "24",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC33",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "38",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC33",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "49",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "59",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "68",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "19",
          "netId": "control_net_6f005443ad9c",
          "name": "VDDIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "22",
          "netId": "control_net_6f005443ad9c",
          "name": "JTAG_TMS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "23",
          "netId": "control_net_6f005443ad9c",
          "name": "JTAG_TDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "30",
          "netId": "control_net_6f005443ad9c",
          "name": "VDDIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "41",
          "netId": "control_net_6f005443ad9c",
          "name": "VDDIO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "19",
          "netId": "control_net_cb3be8fb391c",
          "name": "RESERVED",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "21",
          "netId": "control_net_db15969a3ef3",
          "name": "XI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "22",
          "netId": "control_net_66452339ef9c",
          "name": "XO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "27",
          "netId": "control_net_fbb29cb27034",
          "name": "RREF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "28",
          "netId": "control_net_62e5d80fdc50",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "31",
          "netId": "control_net_4ab70b5a5d2e",
          "name": "TODN",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "32",
          "netId": "control_net_90ccce2c8039",
          "name": "TODP",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "34",
          "netId": "control_net_ee1064f82d57",
          "name": "RIDN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "35",
          "netId": "control_net_4e0bed631879",
          "name": "RIDP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "37",
          "netId": "control_net_b6e5a544d44c",
          "name": "VBUS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TD_P_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TDA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "2",
          "netId": "control_net_506391066785",
          "name": "CT_PHY_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "2",
          "netId": "control_net_f14d9beef5b0",
          "name": "TD_M_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "3",
          "netId": "control_net_f14d9beef5b0",
          "name": "TDA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TD_P_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TDB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "5",
          "netId": "control_net_f6bb2b64e768",
          "name": "CT_PHY_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "5",
          "netId": "control_net_c7652af8ac7f",
          "name": "TD_M_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "6",
          "netId": "control_net_c7652af8ac7f",
          "name": "TDB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TD_P_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TDC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "8",
          "netId": "control_net_96c985883507",
          "name": "CT_PHY_C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "8",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TD_M_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "9",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TDC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TD_P_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TDD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "11",
          "netId": "control_net_ca505632df44",
          "name": "CT_PHY_D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "11",
          "netId": "control_net_c72c6f1d768f",
          "name": "TD_M_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "12",
          "netId": "control_net_c72c6f1d768f",
          "name": "TDD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "14",
          "netId": "control_net_d0a4baabec4c",
          "name": "CT_CABLE_D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "17",
          "netId": "control_net_eb9eb2217e86",
          "name": "CT_CABLE_C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "20",
          "netId": "control_net_1c78c5a73725",
          "name": "CT_CABLE_B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "23",
          "netId": "control_net_b6ac01ebb28c",
          "name": "CT_CABLE_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "16",
          "netId": "control_net_06de98680544",
          "name": "MDC",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "17",
          "netId": "control_net_20b74826bb9f",
          "name": "MDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "18",
          "netId": "control_net_766c613eb974",
          "name": "CLK_OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "39",
          "netId": "control_net_8da86f1b7a73",
          "name": "GPIO_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "40",
          "netId": "control_net_8df81571784a",
          "name": "GPIO_1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "43",
          "netId": "control_net_882df4161e30",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "44",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "INT/PWDN",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "45",
          "netId": "control_net_bd5cd984cf36",
          "name": "LED_2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "46",
          "netId": "control_net_efee1e569907",
          "name": "LED_1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "47",
          "netId": "control_net_b1e90866b0af",
          "name": "LED_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "12",
          "netId": "control_net_a6f01595797b",
          "name": "RBIAS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "14",
          "netId": "control_net_9bc8e82b976f",
          "name": "XO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "15",
          "netId": "control_net_45dfddf2e1c0",
          "name": "XI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "3",
          "netId": "control_net_7d62beb03b56",
          "name": "VDDA2P5",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "9",
          "netId": "control_net_7d62beb03b56",
          "name": "VDDA2P5",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "6",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "24",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "31",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "42",
          "netId": "control_net_732d19ff86ef",
          "name": "VDD1P0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "13",
          "netId": "control_net_91263f868356",
          "name": "VDDA1P8",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "21",
          "netId": "control_net_f804f3303e2d",
          "name": "JTAG_TDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "48",
          "netId": "control_net_1d2540c92513",
          "name": "VDDA1P8",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
