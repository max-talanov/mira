/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_4000_TELEMETRY_ADC_BUFFERS",
  "title": "Как работает: Буферы измерений для контроллера",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
  "steps": [
    {
      "title": "Приходят выбранные измерения",
      "text": "На входы двух повторителей приходят выбранные сигналы тока и напряжения.",
      "body": "На входы двух повторителей приходят выбранные сигналы тока и напряжения.",
      "nodes": [
        "buffer"
      ],
      "edges": [],
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "netIds": [
        "power_net_a13f4f0d6d68",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_1980cbe8a6c0",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U4001",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "2",
          "netId": "power_net_a13f4f0d6d68",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "3",
          "netId": "power_net_882de840965a",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "5",
          "netId": "power_net_e4e50653a8a5",
          "name": "IN+_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "6",
          "netId": "power_net_1980cbe8a6c0",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "7",
          "netId": "power_net_1980cbe8a6c0",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Буферы развязывают выбор и выборку",
      "text": "Повторители передают уровни на входы АЦП контроллера, отделяя аналоговые селекторы от нагрузки выборки.",
      "body": "Повторители передают уровни на входы АЦП контроллера, отделяя аналоговые селекторы от нагрузки выборки.",
      "nodes": [
        "buffer"
      ],
      "edges": [],
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "netIds": [
        "power_net_a13f4f0d6d68",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_1980cbe8a6c0",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U4001",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "2",
          "netId": "power_net_a13f4f0d6d68",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "3",
          "netId": "power_net_882de840965a",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "5",
          "netId": "power_net_e4e50653a8a5",
          "name": "IN+_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "6",
          "netId": "power_net_1980cbe8a6c0",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "7",
          "netId": "power_net_1980cbe8a6c0",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Определены исходные условия",
      "text": "Смещение, развязка выходов и фильтрация задают предусмотренное схемой поведение цепей при запуске и измерении.",
      "body": "Смещение, развязка выходов и фильтрация задают предусмотренное схемой поведение цепей при запуске и измерении.",
      "nodes": [
        "default",
        "buffer"
      ],
      "edges": [
        "buffer_default"
      ],
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "netIds": [
        "power_net_a13f4f0d6d68",
        "power_net_1980cbe8a6c0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R4005",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "2",
          "netId": "power_net_a13f4f0d6d68",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R4006",
          "pin": "1",
          "netId": "power_net_1980cbe8a6c0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "6",
          "netId": "power_net_1980cbe8a6c0",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "7",
          "netId": "power_net_1980cbe8a6c0",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Приходят выбранные измерения",
      "text": "На входы двух повторителей приходят выбранные сигналы тока и напряжения.",
      "body": "На входы двух повторителей приходят выбранные сигналы тока и напряжения.",
      "nodes": [
        "buffer"
      ],
      "edges": [],
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "netIds": [
        "power_net_a13f4f0d6d68",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_1980cbe8a6c0",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U4001",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "2",
          "netId": "power_net_a13f4f0d6d68",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "3",
          "netId": "power_net_882de840965a",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "5",
          "netId": "power_net_e4e50653a8a5",
          "name": "IN+_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "6",
          "netId": "power_net_1980cbe8a6c0",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "7",
          "netId": "power_net_1980cbe8a6c0",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Буферы развязывают выбор и выборку",
      "text": "Повторители передают уровни на входы АЦП контроллера, отделяя аналоговые селекторы от нагрузки выборки.",
      "body": "Повторители передают уровни на входы АЦП контроллера, отделяя аналоговые селекторы от нагрузки выборки.",
      "nodes": [
        "buffer"
      ],
      "edges": [],
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "netIds": [
        "power_net_a13f4f0d6d68",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_1980cbe8a6c0",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U4001",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "2",
          "netId": "power_net_a13f4f0d6d68",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "3",
          "netId": "power_net_882de840965a",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "5",
          "netId": "power_net_e4e50653a8a5",
          "name": "IN+_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "6",
          "netId": "power_net_1980cbe8a6c0",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "7",
          "netId": "power_net_1980cbe8a6c0",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Определены исходные условия",
      "text": "Смещение, развязка выходов и фильтрация задают предусмотренное схемой поведение цепей при запуске и измерении.",
      "body": "Смещение, развязка выходов и фильтрация задают предусмотренное схемой поведение цепей при запуске и измерении.",
      "nodes": [
        "default",
        "buffer"
      ],
      "edges": [
        "buffer_default"
      ],
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "netIds": [
        "power_net_a13f4f0d6d68",
        "power_net_1980cbe8a6c0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R4005",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "1",
          "netId": "power_net_a13f4f0d6d68",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "2",
          "netId": "power_net_a13f4f0d6d68",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R4006",
          "pin": "1",
          "netId": "power_net_1980cbe8a6c0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "6",
          "netId": "power_net_1980cbe8a6c0",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "7",
          "netId": "power_net_1980cbe8a6c0",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
