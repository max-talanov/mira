/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power",
  "title": "Как работает: Плата Power · питание и аппаратная защита",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power",
  "steps": [
    {
      "title": "Вход защищается",
      "text": "Внешний источник проходит входную защиту и фильтрацию, после чего защищённая шина питает основные ветви.",
      "body": "Внешний источник проходит входную защиту и фильтрацию, после чего защищённая шина питает основные ветви.",
      "nodes": [
        "input",
        "primary"
      ],
      "edges": [
        "input_primary"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U701",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Надзор получает дежурное питание",
      "text": "Дежурная ветвь питает диспетчер и аппаратуру безопасности. Они формируют проверенные запросы преобразователей.",
      "body": "Дежурная ветвь питает диспетчер и аппаратуру безопасности. Они формируют проверенные запросы преобразователей.",
      "nodes": [
        "primary",
        "supervisor"
      ],
      "edges": [
        "primary_supervisor",
        "supervisor_primary"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питаются нагрузочные домены",
      "text": "Основные и дополнительные преобразователи формируют раздельные шины нагрузок. Это функциональный порядок объяснения, а не фиксированная прошивочная последовательность.",
      "body": "Основные и дополнительные преобразователи формируют раздельные шины нагрузок. Это функциональный порядок объяснения, а не фиксированная прошивочная последовательность.",
      "nodes": [
        "primary",
        "secondary",
        "supervisor"
      ],
      "edges": [
        "primary_secondary",
        "primary_supervisor",
        "supervisor_primary",
        "supervisor_secondary"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_bbc855740138",
        "power_net_cd1e0a0c9a0e",
        "power_net_f5932d689562",
        "power_net_67006db669b3",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41",
        "power_net_05ab23d96f3d",
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_d07b46e16a3e",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "9",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "10",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "9",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "10",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измерения возвращаются диспетчеру",
      "text": "Измерительные каналы подают выбранные напряжение и ток к диспетчеру. Программирующие шины включаются отдельным разрешением.",
      "body": "Измерительные каналы подают выбранные напряжение и ток к диспетчеру. Программирующие шины включаются отдельным разрешением.",
      "nodes": [
        "monitor",
        "supervisor",
        "program"
      ],
      "edges": [
        "monitor_supervisor",
        "supervisor_program"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_4aeb4892b398",
        "power_net_393e02135991",
        "power_net_f632ebdd7344",
        "power_net_89bfaea42e83",
        "power_net_65bf7e1e53cf",
        "power_net_5a1f578d112a",
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "10",
          "netId": "power_net_4aeb4892b398",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3503",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3504",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3502",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3704",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3603",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3602",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "17",
          "netId": "power_net_393e02135991",
          "name": "PA0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "18",
          "netId": "power_net_f632ebdd7344",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Вход защищается",
      "text": "Внешний источник проходит входную защиту и фильтрацию, после чего защищённая шина питает основные ветви.",
      "body": "Внешний источник проходит входную защиту и фильтрацию, после чего защищённая шина питает основные ветви.",
      "nodes": [
        "input",
        "primary"
      ],
      "edges": [
        "input_primary"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U701",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Надзор получает дежурное питание",
      "text": "Дежурная ветвь питает диспетчер и аппаратуру безопасности. Они формируют проверенные запросы преобразователей.",
      "body": "Дежурная ветвь питает диспетчер и аппаратуру безопасности. Они формируют проверенные запросы преобразователей.",
      "nodes": [
        "primary",
        "supervisor"
      ],
      "edges": [
        "primary_supervisor",
        "supervisor_primary"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питаются нагрузочные домены",
      "text": "Основные и дополнительные преобразователи формируют раздельные шины нагрузок. Это функциональный порядок объяснения, а не фиксированная прошивочная последовательность.",
      "body": "Основные и дополнительные преобразователи формируют раздельные шины нагрузок. Это функциональный порядок объяснения, а не фиксированная прошивочная последовательность.",
      "nodes": [
        "primary",
        "secondary",
        "supervisor"
      ],
      "edges": [
        "primary_secondary",
        "primary_supervisor",
        "supervisor_primary",
        "supervisor_secondary"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_bbc855740138",
        "power_net_cd1e0a0c9a0e",
        "power_net_f5932d689562",
        "power_net_67006db669b3",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41",
        "power_net_05ab23d96f3d",
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_d07b46e16a3e",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "9",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "10",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "9",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "10",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измерения возвращаются диспетчеру",
      "text": "Измерительные каналы подают выбранные напряжение и ток к диспетчеру. Программирующие шины включаются отдельным разрешением.",
      "body": "Измерительные каналы подают выбранные напряжение и ток к диспетчеру. Программирующие шины включаются отдельным разрешением.",
      "nodes": [
        "monitor",
        "supervisor",
        "program"
      ],
      "edges": [
        "monitor_supervisor",
        "supervisor_program"
      ],
      "sceneId": "power",
      "netIds": [
        "power_net_4aeb4892b398",
        "power_net_393e02135991",
        "power_net_f632ebdd7344",
        "power_net_89bfaea42e83",
        "power_net_65bf7e1e53cf",
        "power_net_5a1f578d112a",
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "10",
          "netId": "power_net_4aeb4892b398",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3503",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3504",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3502",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3701",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3704",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3603",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3602",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "17",
          "netId": "power_net_393e02135991",
          "name": "PA0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "18",
          "netId": "power_net_f632ebdd7344",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
