/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2800_PM_ENABLE_GATES_AUXILIARY",
  "title": "Как работает: Разрешения вспомогательных преобразователей",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
  "steps": [
    {
      "title": "Появляются запросы дополнительных ветвей",
      "text": "Запросы нагрузочных преобразователей поступают в отдельные группы аппаратной логики.",
      "body": "Запросы нагрузочных преобразователей поступают в отдельные группы аппаратной логики.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Каждая ветвь получает проверенную команду",
      "text": "Логические элементы квалифицируют запросы соответствующими разрешениями перед передачей к EN преобразователей.",
      "body": "Логические элементы квалифицируют запросы соответствующими разрешениями перед передачей к EN преобразователей.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "При запуске команды определены",
      "text": "Резистивные цепи задают исходное состояние входов и предотвращают неопределённое управление до запуска контроллера.",
      "body": "Резистивные цепи задают исходное состояние входов и предотвращают неопределённое управление до запуска контроллера.",
      "nodes": [
        "default",
        "first",
        "second"
      ],
      "edges": [
        "first_second",
        "first_default",
        "second_default"
      ],
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "netIds": [
        "power_net_8828c890966d",
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_05ab23d96f3d",
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_d07b46e16a3e",
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "2",
          "netId": "power_net_d1fe7a20e661",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2802",
          "pin": "1",
          "netId": "power_net_d1fe7a20e661",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2803",
          "pin": "1",
          "netId": "power_net_1b4ac01010f8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "5",
          "netId": "power_net_1b4ac01010f8",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2804",
          "pin": "1",
          "netId": "power_net_5dc0cb853f29",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "10",
          "netId": "power_net_5dc0cb853f29",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "13",
          "netId": "power_net_69d4e38b1bd0",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2801",
          "pin": "2",
          "netId": "power_net_69d4e38b1bd0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2808",
          "pin": "2",
          "netId": "power_net_05ab23d96f3d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "11",
          "netId": "power_net_05ab23d96f3d",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2805",
          "pin": "1",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "3",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2806",
          "pin": "1",
          "netId": "power_net_04b2f0a4c78b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "6",
          "netId": "power_net_04b2f0a4c78b",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "8",
          "netId": "power_net_d07b46e16a3e",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2807",
          "pin": "1",
          "netId": "power_net_d07b46e16a3e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "2",
          "netId": "power_net_2c93a597633f",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2809",
          "pin": "1",
          "netId": "power_net_2c93a597633f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "5",
          "netId": "power_net_12bae3231aaa",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2810",
          "pin": "1",
          "netId": "power_net_12bae3231aaa",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "10",
          "netId": "power_net_b527a6b82695",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2811",
          "pin": "1",
          "netId": "power_net_b527a6b82695",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "3",
          "netId": "power_net_ae048a8edaa8",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2812",
          "pin": "1",
          "netId": "power_net_ae048a8edaa8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "6",
          "netId": "power_net_664171b20ecf",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2813",
          "pin": "1",
          "netId": "power_net_664171b20ecf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "8",
          "netId": "power_net_55bbd3deed41",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2814",
          "pin": "1",
          "netId": "power_net_55bbd3deed41",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Появляются запросы дополнительных ветвей",
      "text": "Запросы нагрузочных преобразователей поступают в отдельные группы аппаратной логики.",
      "body": "Запросы нагрузочных преобразователей поступают в отдельные группы аппаратной логики.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Каждая ветвь получает проверенную команду",
      "text": "Логические элементы квалифицируют запросы соответствующими разрешениями перед передачей к EN преобразователей.",
      "body": "Логические элементы квалифицируют запросы соответствующими разрешениями перед передачей к EN преобразователей.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "При запуске команды определены",
      "text": "Резистивные цепи задают исходное состояние входов и предотвращают неопределённое управление до запуска контроллера.",
      "body": "Резистивные цепи задают исходное состояние входов и предотвращают неопределённое управление до запуска контроллера.",
      "nodes": [
        "default",
        "first",
        "second"
      ],
      "edges": [
        "first_second",
        "first_default",
        "second_default"
      ],
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "netIds": [
        "power_net_8828c890966d",
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_05ab23d96f3d",
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_d07b46e16a3e",
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "2",
          "netId": "power_net_d1fe7a20e661",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2802",
          "pin": "1",
          "netId": "power_net_d1fe7a20e661",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2803",
          "pin": "1",
          "netId": "power_net_1b4ac01010f8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "5",
          "netId": "power_net_1b4ac01010f8",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2804",
          "pin": "1",
          "netId": "power_net_5dc0cb853f29",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "10",
          "netId": "power_net_5dc0cb853f29",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "13",
          "netId": "power_net_69d4e38b1bd0",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2801",
          "pin": "2",
          "netId": "power_net_69d4e38b1bd0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2808",
          "pin": "2",
          "netId": "power_net_05ab23d96f3d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "11",
          "netId": "power_net_05ab23d96f3d",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2805",
          "pin": "1",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "3",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2806",
          "pin": "1",
          "netId": "power_net_04b2f0a4c78b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "6",
          "netId": "power_net_04b2f0a4c78b",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "8",
          "netId": "power_net_d07b46e16a3e",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2807",
          "pin": "1",
          "netId": "power_net_d07b46e16a3e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "2",
          "netId": "power_net_2c93a597633f",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2809",
          "pin": "1",
          "netId": "power_net_2c93a597633f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "5",
          "netId": "power_net_12bae3231aaa",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2810",
          "pin": "1",
          "netId": "power_net_12bae3231aaa",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "10",
          "netId": "power_net_b527a6b82695",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2811",
          "pin": "1",
          "netId": "power_net_b527a6b82695",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "3",
          "netId": "power_net_ae048a8edaa8",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2812",
          "pin": "1",
          "netId": "power_net_ae048a8edaa8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "6",
          "netId": "power_net_664171b20ecf",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2813",
          "pin": "1",
          "netId": "power_net_664171b20ecf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "8",
          "netId": "power_net_55bbd3deed41",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2814",
          "pin": "1",
          "netId": "power_net_55bbd3deed41",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
