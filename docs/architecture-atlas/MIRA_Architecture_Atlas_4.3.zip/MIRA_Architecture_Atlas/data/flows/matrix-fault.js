/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "matrix-fault",
  "title": "Аппаратная авария",
  "description": "Проследите прямой путь защиты, который действует независимо от обычной обработки данных.",
  "sceneId": "system",
  "steps": [
    {
      "title": "Возникновение опасного условия",
      "text": "Событие превышения тока источника или ошибки конфигурации поступает в аппаратную защиту.",
      "body": "Событие превышения тока источника или ошибки конфигурации поступает в аппаратную защиту.",
      "nodes": [
        "matrix",
        "safety"
      ],
      "edges": [
        "matrix_safety"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d4a1fffbf6b9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Фиксация события",
      "text": "Память аварии удерживает остановку до предусмотренного сброса или повторного взвода.",
      "body": "Память аварии удерживает остановку до предусмотренного сброса или повторного взвода.",
      "nodes": [
        "safety"
      ],
      "edges": [],
      "sceneId": "system",
      "netIds": [
        "control_net_7b06e5d6a4d9",
        "control_net_2d2627aeff69",
        "control_net_720010c527b5",
        "control_net_6f005443ad9c",
        "power_net_0d67fdbc5a0d",
        "power_net_67006db669b3",
        "power_net_6ad422db16ac",
        "power_net_8828c890966d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_5a1f578d112a",
        "power_net_6d982403b080",
        "power_net_bc6b8848cad9",
        "control_net_9269f101a22a",
        "control_net_5a73b1e1ccba",
        "control_net_d44a94d9b4fd",
        "control_net_1a607d7041f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "3",
          "netId": "control_net_5a73b1e1ccba",
          "name": "Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "6",
          "netId": "control_net_1a607d7041f2",
          "name": "CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Снятие разрешения",
      "text": "Сигнал запрета достигает аппаратной границы разрешения питания.",
      "body": "Сигнал запрета достигает аппаратной границы разрешения питания.",
      "nodes": [
        "safety",
        "power"
      ],
      "edges": [
        "safety_power"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_e65fb75085e7"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка перед повторным взводом",
      "text": "Перед осознанным восстановлением основной контроллер может проверить состояние и измеренные параметры.",
      "body": "Перед осознанным восстановлением основной контроллер может проверить состояние и измеренные параметры.",
      "nodes": [
        "power",
        "mcu",
        "safety"
      ],
      "edges": [
        "power_mcu"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_df95db02c560"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Возникновение опасного условия",
      "text": "Событие превышения тока источника или ошибки конфигурации поступает в аппаратную защиту.",
      "body": "Событие превышения тока источника или ошибки конфигурации поступает в аппаратную защиту.",
      "nodes": [
        "matrix",
        "safety"
      ],
      "edges": [
        "matrix_safety"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d4a1fffbf6b9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Фиксация события",
      "text": "Память аварии удерживает остановку до предусмотренного сброса или повторного взвода.",
      "body": "Память аварии удерживает остановку до предусмотренного сброса или повторного взвода.",
      "nodes": [
        "safety"
      ],
      "edges": [],
      "sceneId": "system",
      "netIds": [
        "control_net_7b06e5d6a4d9",
        "control_net_2d2627aeff69",
        "control_net_720010c527b5",
        "control_net_6f005443ad9c",
        "power_net_0d67fdbc5a0d",
        "power_net_67006db669b3",
        "power_net_6ad422db16ac",
        "power_net_8828c890966d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_5a1f578d112a",
        "power_net_6d982403b080",
        "power_net_bc6b8848cad9",
        "control_net_9269f101a22a",
        "control_net_5a73b1e1ccba",
        "control_net_d44a94d9b4fd",
        "control_net_1a607d7041f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "3",
          "netId": "control_net_5a73b1e1ccba",
          "name": "Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "6",
          "netId": "control_net_1a607d7041f2",
          "name": "CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Снятие разрешения",
      "text": "Сигнал запрета достигает аппаратной границы разрешения питания.",
      "body": "Сигнал запрета достигает аппаратной границы разрешения питания.",
      "nodes": [
        "safety",
        "power"
      ],
      "edges": [
        "safety_power"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_e65fb75085e7"
      ],
      "pinStates": [],
      "pinHighlights": [],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка перед повторным взводом",
      "text": "Перед осознанным восстановлением основной контроллер может проверить состояние и измеренные параметры.",
      "body": "Перед осознанным восстановлением основной контроллер может проверить состояние и измеренные параметры.",
      "nodes": [
        "power",
        "mcu",
        "safety"
      ],
      "edges": [
        "power_mcu"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_df95db02c560"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
