/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "title": "Как работает: Преобразование тока матрицы в напряжение",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "steps": [
    {
      "title": "Ток поступает на TIA",
      "text": "Ток выбранного возвратного пути матрицы входит в трансимпедансный усилитель. Обратная связь превращает ток в напряжение.",
      "body": "Ток выбранного возвратного пути матрицы входит в трансимпедансный усилитель. Обратная связь превращает ток в напряжение.",
      "nodes": [
        "current"
      ],
      "edges": [],
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "netIds": [
        "control_net_2e82cb98585d",
        "control_net_e5381212c338",
        "control_net_f993730bd850",
        "control_net_d65f00f0a2d4",
        "control_net_388b6d3f3344"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1901",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "7",
          "netId": "control_net_2e82cb98585d",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1900",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1904",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1902",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "6",
          "netId": "control_net_f993730bd850",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "8",
          "netId": "control_net_388b6d3f3344",
          "name": "FLAG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбирается чувствительность",
      "text": "Коммутация обратной связи задаёт диапазон преобразования. При одном и том же токе выбранный диапазон меняет выходной масштаб.",
      "body": "Коммутация обратной связи задаёт диапазон преобразования. При одном и том же токе выбранный диапазон меняет выходной масштаб.",
      "nodes": [
        "range",
        "current"
      ],
      "edges": [
        "current_range"
      ],
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "netIds": [
        "control_net_d65f00f0a2d4",
        "control_net_f993730bd850"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1901",
          "pin": "8",
          "netId": "control_net_d65f00f0a2d4",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1913",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1912",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1907",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1911",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1910",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1901",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1906",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "6",
          "netId": "control_net_f993730bd850",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1908",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1914",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1904",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1907",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1908",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1902",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1909",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1905",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбирается наблюдаемый сигнал",
      "text": "Селектор подключает измерительный или диагностический сигнал к следующему тракту. Буферы отделяют высокоомные узлы контроля от нагрузки селектора.",
      "body": "Селектор подключает измерительный или диагностический сигнал к следующему тракту. Буферы отделяют высокоомные узлы контроля от нагрузки селектора.",
      "nodes": [
        "buffer",
        "monitor",
        "current"
      ],
      "edges": [
        "current_monitor",
        "monitor_buffer"
      ],
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "netIds": [
        "control_net_f993730bd850",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1902",
          "pin": "4",
          "netId": "control_net_f993730bd850",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "6",
          "netId": "control_net_f993730bd850",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1902",
          "pin": "7",
          "netId": "control_net_fc57b8202dba",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "2",
          "netId": "control_net_fc57b8202dba",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "1",
          "netId": "control_net_fc57b8202dba",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1902",
          "pin": "12",
          "netId": "control_net_7eb34b3468da",
          "name": "S5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "6",
          "netId": "control_net_7eb34b3468da",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "7",
          "netId": "control_net_7eb34b3468da",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Ток поступает на TIA",
      "text": "Ток выбранного возвратного пути матрицы входит в трансимпедансный усилитель. Обратная связь превращает ток в напряжение.",
      "body": "Ток выбранного возвратного пути матрицы входит в трансимпедансный усилитель. Обратная связь превращает ток в напряжение.",
      "nodes": [
        "current"
      ],
      "edges": [],
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "netIds": [
        "control_net_2e82cb98585d",
        "control_net_e5381212c338",
        "control_net_f993730bd850",
        "control_net_d65f00f0a2d4",
        "control_net_388b6d3f3344"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1901",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "7",
          "netId": "control_net_2e82cb98585d",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1900",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1904",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1902",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "6",
          "netId": "control_net_f993730bd850",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "8",
          "netId": "control_net_388b6d3f3344",
          "name": "FLAG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбирается чувствительность",
      "text": "Коммутация обратной связи задаёт диапазон преобразования. При одном и том же токе выбранный диапазон меняет выходной масштаб.",
      "body": "Коммутация обратной связи задаёт диапазон преобразования. При одном и том же токе выбранный диапазон меняет выходной масштаб.",
      "nodes": [
        "range",
        "current"
      ],
      "edges": [
        "current_range"
      ],
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "netIds": [
        "control_net_d65f00f0a2d4",
        "control_net_f993730bd850"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1901",
          "pin": "8",
          "netId": "control_net_d65f00f0a2d4",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1913",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1912",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1907",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1911",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1910",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1901",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1906",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "6",
          "netId": "control_net_f993730bd850",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1908",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1914",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1904",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1907",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1908",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1902",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1909",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1905",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбирается наблюдаемый сигнал",
      "text": "Селектор подключает измерительный или диагностический сигнал к следующему тракту. Буферы отделяют высокоомные узлы контроля от нагрузки селектора.",
      "body": "Селектор подключает измерительный или диагностический сигнал к следующему тракту. Буферы отделяют высокоомные узлы контроля от нагрузки селектора.",
      "nodes": [
        "buffer",
        "monitor",
        "current"
      ],
      "edges": [
        "current_monitor",
        "monitor_buffer"
      ],
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "netIds": [
        "control_net_f993730bd850",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1903",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1902",
          "pin": "4",
          "netId": "control_net_f993730bd850",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "6",
          "netId": "control_net_f993730bd850",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1900",
          "pin": "1",
          "netId": "control_net_f993730bd850",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1902",
          "pin": "7",
          "netId": "control_net_fc57b8202dba",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "2",
          "netId": "control_net_fc57b8202dba",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "1",
          "netId": "control_net_fc57b8202dba",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1902",
          "pin": "12",
          "netId": "control_net_7eb34b3468da",
          "name": "S5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "6",
          "netId": "control_net_7eb34b3468da",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1903",
          "pin": "7",
          "netId": "control_net_7eb34b3468da",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
