/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_1300_FPGA_AUX_1V8",
  "title": "Как работает: Вспомогательное питание ПЛИС 1,8 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_1300_FPGA_AUX_1V8",
  "steps": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1301",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_9693d69e08e6",
        "power_net_91608c5bec4e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1301",
          "pin": "1",
          "netId": "power_net_9693d69e08e6",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1301",
          "pin": "1",
          "netId": "power_net_91608c5bec4e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1301",
          "pin": "2",
          "netId": "power_net_91608c5bec4e",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "13",
          "netId": "power_net_91608c5bec4e",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует AUX1V8",
      "text": "Регулятор и цепь обратной связи формируют выходную шину AUX1V8. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину AUX1V8. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_e70ca4a7b1de",
        "power_net_72aaeb0dd85a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1306",
          "pin": "1",
          "netId": "power_net_e70ca4a7b1de",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1305",
          "pin": "2",
          "netId": "power_net_e70ca4a7b1de",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1304",
          "pin": "1",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1303",
          "pin": "1",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1301",
          "pin": "2",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1305",
          "pin": "1",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "7",
          "netId": "power_net_72aaeb0dd85a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "14",
          "netId": "power_net_72aaeb0dd85a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования AUX1V8 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования AUX1V8 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_e70ca4a7b1de"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1306",
          "pin": "1",
          "netId": "power_net_e70ca4a7b1de",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1301",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_9693d69e08e6",
        "power_net_91608c5bec4e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1301",
          "pin": "1",
          "netId": "power_net_9693d69e08e6",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1301",
          "pin": "1",
          "netId": "power_net_91608c5bec4e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1301",
          "pin": "2",
          "netId": "power_net_91608c5bec4e",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "13",
          "netId": "power_net_91608c5bec4e",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует AUX1V8",
      "text": "Регулятор и цепь обратной связи формируют выходную шину AUX1V8. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину AUX1V8. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_e70ca4a7b1de",
        "power_net_72aaeb0dd85a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1306",
          "pin": "1",
          "netId": "power_net_e70ca4a7b1de",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1305",
          "pin": "2",
          "netId": "power_net_e70ca4a7b1de",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1304",
          "pin": "1",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1303",
          "pin": "1",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1301",
          "pin": "2",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1305",
          "pin": "1",
          "netId": "power_net_72aaeb0dd85a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "7",
          "netId": "power_net_72aaeb0dd85a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "14",
          "netId": "power_net_72aaeb0dd85a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования AUX1V8 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования AUX1V8 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "netIds": [
        "power_net_e70ca4a7b1de"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1306",
          "pin": "1",
          "netId": "power_net_e70ca4a7b1de",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
