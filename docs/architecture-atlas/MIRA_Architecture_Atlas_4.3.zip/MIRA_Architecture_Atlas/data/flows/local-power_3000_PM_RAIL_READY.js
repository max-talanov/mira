/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3000_PM_RAIL_READY",
  "title": "Как работает: Готовность напряжений питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3000_PM_RAIL_READY",
  "steps": [
    {
      "title": "Приходят реальные признаки готовности",
      "text": "Логика получает статусы фактически установившихся основных и дополнительных шин. Эти сигналы отличаются от запросов на включение.",
      "body": "Логика получает статусы фактически установившихся основных и дополнительных шин. Эти сигналы отличаются от запросов на включение.",
      "nodes": [
        "0",
        "1"
      ],
      "edges": [],
      "sceneId": "power_3000_PM_RAIL_READY",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_ae3b1a85f32f",
        "power_net_cfa48b7bd3ef",
        "power_net_a8d89ad05618",
        "power_net_2965499926c8",
        "power_net_e46274585def",
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_07ebf73acc19",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_1d5ba6beca40",
        "power_net_ed26aaa81531",
        "power_net_ac83bbc60cc7",
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2",
        "power_net_0ee4f5245d75",
        "power_net_99aaef80128f",
        "power_net_e4e6344ec79f",
        "power_net_e1dd2bfabf3b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3001",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3001",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "13",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3002",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "2",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "3",
          "netId": "power_net_a8d89ad05618",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "4",
          "netId": "power_net_2965499926c8",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "5",
          "netId": "power_net_e46274585def",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "6",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "8",
          "netId": "power_net_0c68cab570db",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "9",
          "netId": "power_net_61199f10a0d6",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "10",
          "netId": "power_net_0c8e0f29b47d",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "11",
          "netId": "power_net_07ebf73acc19",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "12",
          "netId": "power_net_95f2aea4f265",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "13",
          "netId": "power_net_b80a0b0c471f",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "1",
          "netId": "power_net_fcfa30509d75",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "2",
          "netId": "power_net_b81a8e339338",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "3",
          "netId": "power_net_1d5ba6beca40",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "5",
          "netId": "power_net_ac83bbc60cc7",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "6",
          "netId": "power_net_534223a3e24d",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "8",
          "netId": "power_net_9d522f9a0fb2",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "10",
          "netId": "power_net_99aaef80128f",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "11",
          "netId": "power_net_e4e6344ec79f",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "12",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Условия объединяются",
      "text": "Последующие логические элементы формируют групповые признаки готовности из входных статусов.",
      "body": "Последующие логические элементы формируют групповые признаки готовности из входных статусов.",
      "nodes": [
        "0",
        "1",
        "2"
      ],
      "edges": [
        "0_2",
        "1_2"
      ],
      "sceneId": "power_3000_PM_RAIL_READY",
      "netIds": [
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db",
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3001",
          "pin": "6",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "1",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "8",
          "netId": "power_net_0c68cab570db",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "2",
          "netId": "power_net_0c68cab570db",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "6",
          "netId": "power_net_534223a3e24d",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "4",
          "netId": "power_net_534223a3e24d",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "8",
          "netId": "power_net_9d522f9a0fb2",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "5",
          "netId": "power_net_9d522f9a0fb2",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получается общий статус",
      "text": "Итоговый признак готовности передаётся диспетчеру и связанным узлам. История показывает цепочку условий, а не заменяет таблицу истинности.",
      "body": "Итоговый признак готовности передаётся диспетчеру и связанным узлам. История показывает цепочку условий, а не заменяет таблицу истинности.",
      "nodes": [
        "2"
      ],
      "edges": [],
      "sceneId": "power_3000_PM_RAIL_READY",
      "netIds": [
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db",
        "power_net_50db11744ffa",
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2",
        "power_net_47f67f61993c",
        "power_net_f2716a79f30d",
        "power_net_a034510f2819",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3018",
          "pin": "1",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "2",
          "netId": "power_net_0c68cab570db",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "3",
          "netId": "power_net_50db11744ffa",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "4",
          "netId": "power_net_534223a3e24d",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "5",
          "netId": "power_net_9d522f9a0fb2",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "6",
          "netId": "power_net_47f67f61993c",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "8",
          "netId": "power_net_f2716a79f30d",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "11",
          "netId": "power_net_a034510f2819",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3003",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Приходят реальные признаки готовности",
      "text": "Логика получает статусы фактически установившихся основных и дополнительных шин. Эти сигналы отличаются от запросов на включение.",
      "body": "Логика получает статусы фактически установившихся основных и дополнительных шин. Эти сигналы отличаются от запросов на включение.",
      "nodes": [
        "0",
        "1"
      ],
      "edges": [],
      "sceneId": "power_3000_PM_RAIL_READY",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_ae3b1a85f32f",
        "power_net_cfa48b7bd3ef",
        "power_net_a8d89ad05618",
        "power_net_2965499926c8",
        "power_net_e46274585def",
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_07ebf73acc19",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_1d5ba6beca40",
        "power_net_ed26aaa81531",
        "power_net_ac83bbc60cc7",
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2",
        "power_net_0ee4f5245d75",
        "power_net_99aaef80128f",
        "power_net_e4e6344ec79f",
        "power_net_e1dd2bfabf3b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3001",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3001",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "13",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3002",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "2",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "3",
          "netId": "power_net_a8d89ad05618",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "4",
          "netId": "power_net_2965499926c8",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "5",
          "netId": "power_net_e46274585def",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "6",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "8",
          "netId": "power_net_0c68cab570db",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "9",
          "netId": "power_net_61199f10a0d6",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "10",
          "netId": "power_net_0c8e0f29b47d",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "11",
          "netId": "power_net_07ebf73acc19",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "12",
          "netId": "power_net_95f2aea4f265",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "13",
          "netId": "power_net_b80a0b0c471f",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "1",
          "netId": "power_net_fcfa30509d75",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "2",
          "netId": "power_net_b81a8e339338",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "3",
          "netId": "power_net_1d5ba6beca40",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "5",
          "netId": "power_net_ac83bbc60cc7",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "6",
          "netId": "power_net_534223a3e24d",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "8",
          "netId": "power_net_9d522f9a0fb2",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "10",
          "netId": "power_net_99aaef80128f",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "11",
          "netId": "power_net_e4e6344ec79f",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "12",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Условия объединяются",
      "text": "Последующие логические элементы формируют групповые признаки готовности из входных статусов.",
      "body": "Последующие логические элементы формируют групповые признаки готовности из входных статусов.",
      "nodes": [
        "0",
        "1",
        "2"
      ],
      "edges": [
        "0_2",
        "1_2"
      ],
      "sceneId": "power_3000_PM_RAIL_READY",
      "netIds": [
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db",
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3001",
          "pin": "6",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "1",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "8",
          "netId": "power_net_0c68cab570db",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "2",
          "netId": "power_net_0c68cab570db",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "6",
          "netId": "power_net_534223a3e24d",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "4",
          "netId": "power_net_534223a3e24d",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "8",
          "netId": "power_net_9d522f9a0fb2",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "5",
          "netId": "power_net_9d522f9a0fb2",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получается общий статус",
      "text": "Итоговый признак готовности передаётся диспетчеру и связанным узлам. История показывает цепочку условий, а не заменяет таблицу истинности.",
      "body": "Итоговый признак готовности передаётся диспетчеру и связанным узлам. История показывает цепочку условий, а не заменяет таблицу истинности.",
      "nodes": [
        "2"
      ],
      "edges": [],
      "sceneId": "power_3000_PM_RAIL_READY",
      "netIds": [
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db",
        "power_net_50db11744ffa",
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2",
        "power_net_47f67f61993c",
        "power_net_f2716a79f30d",
        "power_net_a034510f2819",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3018",
          "pin": "1",
          "netId": "power_net_5b1bf737eaa4",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "2",
          "netId": "power_net_0c68cab570db",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "3",
          "netId": "power_net_50db11744ffa",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "4",
          "netId": "power_net_534223a3e24d",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "5",
          "netId": "power_net_9d522f9a0fb2",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "6",
          "netId": "power_net_47f67f61993c",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "8",
          "netId": "power_net_f2716a79f30d",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "11",
          "netId": "power_net_a034510f2819",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3003",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
