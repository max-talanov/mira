/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_1400_FPGA_AUX_2V5",
  "title": "Как работает: Вспомогательное питание 2,5 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_1400_FPGA_AUX_2V5",
  "steps": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1401",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_0faf4b6ebbf5",
        "power_net_8d8d482ee874"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1401",
          "pin": "1",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "13",
          "netId": "power_net_8d8d482ee874",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1401",
          "pin": "2",
          "netId": "power_net_8d8d482ee874",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1401",
          "pin": "1",
          "netId": "power_net_8d8d482ee874",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует AUX2V5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину AUX2V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину AUX2V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_4a44013bf2b3",
        "power_net_38cd986dd59a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1406",
          "pin": "1",
          "netId": "power_net_4a44013bf2b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1405",
          "pin": "2",
          "netId": "power_net_4a44013bf2b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1403",
          "pin": "1",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "7",
          "netId": "power_net_38cd986dd59a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "14",
          "netId": "power_net_38cd986dd59a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1405",
          "pin": "1",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1404",
          "pin": "1",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1401",
          "pin": "2",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования AUX2V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования AUX2V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_4a44013bf2b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1406",
          "pin": "1",
          "netId": "power_net_4a44013bf2b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1401",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_0faf4b6ebbf5",
        "power_net_8d8d482ee874"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1401",
          "pin": "1",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "13",
          "netId": "power_net_8d8d482ee874",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1401",
          "pin": "2",
          "netId": "power_net_8d8d482ee874",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1401",
          "pin": "1",
          "netId": "power_net_8d8d482ee874",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует AUX2V5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину AUX2V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину AUX2V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_4a44013bf2b3",
        "power_net_38cd986dd59a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1406",
          "pin": "1",
          "netId": "power_net_4a44013bf2b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1405",
          "pin": "2",
          "netId": "power_net_4a44013bf2b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1403",
          "pin": "1",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "7",
          "netId": "power_net_38cd986dd59a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "14",
          "netId": "power_net_38cd986dd59a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1405",
          "pin": "1",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1404",
          "pin": "1",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1401",
          "pin": "2",
          "netId": "power_net_38cd986dd59a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования AUX2V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования AUX2V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "netIds": [
        "power_net_4a44013bf2b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1406",
          "pin": "1",
          "netId": "power_net_4a44013bf2b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
