/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_1500_FPGA_IO_3V3",
  "title": "Как работает: Питание выводов ПЛИС 3,3 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_1500_FPGA_IO_3V3",
  "steps": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1501",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_04b2f0a4c78b",
        "power_net_ae3413231f47"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1501",
          "pin": "1",
          "netId": "power_net_04b2f0a4c78b",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "13",
          "netId": "power_net_ae3413231f47",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1501",
          "pin": "1",
          "netId": "power_net_ae3413231f47",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1501",
          "pin": "2",
          "netId": "power_net_ae3413231f47",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует IO3V3",
      "text": "Регулятор и цепь обратной связи формируют выходную шину IO3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину IO3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_6c6a12e16365",
        "power_net_33017e9a066b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1506",
          "pin": "1",
          "netId": "power_net_6c6a12e16365",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1505",
          "pin": "2",
          "netId": "power_net_6c6a12e16365",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "7",
          "netId": "power_net_33017e9a066b",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "14",
          "netId": "power_net_33017e9a066b",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1505",
          "pin": "1",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1503",
          "pin": "1",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1501",
          "pin": "2",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1504",
          "pin": "1",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования IO3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования IO3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_6c6a12e16365"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1506",
          "pin": "1",
          "netId": "power_net_6c6a12e16365",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1501",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_04b2f0a4c78b",
        "power_net_ae3413231f47"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1501",
          "pin": "1",
          "netId": "power_net_04b2f0a4c78b",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "13",
          "netId": "power_net_ae3413231f47",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1501",
          "pin": "1",
          "netId": "power_net_ae3413231f47",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1501",
          "pin": "2",
          "netId": "power_net_ae3413231f47",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует IO3V3",
      "text": "Регулятор и цепь обратной связи формируют выходную шину IO3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину IO3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_6c6a12e16365",
        "power_net_33017e9a066b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1506",
          "pin": "1",
          "netId": "power_net_6c6a12e16365",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1505",
          "pin": "2",
          "netId": "power_net_6c6a12e16365",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "7",
          "netId": "power_net_33017e9a066b",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "14",
          "netId": "power_net_33017e9a066b",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1505",
          "pin": "1",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1503",
          "pin": "1",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1501",
          "pin": "2",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1504",
          "pin": "1",
          "netId": "power_net_33017e9a066b",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования IO3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования IO3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1500_FPGA_IO_3V3",
      "netIds": [
        "power_net_6c6a12e16365"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1506",
          "pin": "1",
          "netId": "power_net_6c6a12e16365",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
