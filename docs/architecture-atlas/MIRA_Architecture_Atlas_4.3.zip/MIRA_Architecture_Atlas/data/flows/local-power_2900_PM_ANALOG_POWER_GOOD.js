/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2900_PM_ANALOG_POWER_GOOD",
  "title": "Как работает: Проверка допустимых напряжений",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
  "steps": [
    {
      "title": "Измеренные напряжения сравниваются с окнами",
      "text": "Делители формируют пороги допустимых напряжений аналоговых шин.",
      "body": "Делители формируют пороги допустимых напряжений аналоговых шин.",
      "nodes": [
        "threshold"
      ],
      "edges": [],
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "netIds": [
        "power_net_d3607cfa6b03",
        "power_net_6a587efc79ba",
        "power_net_9ec66895516f",
        "power_net_67006db669b3",
        "power_net_61199f10a0d6",
        "power_net_de65996f492f",
        "power_net_e46274585def",
        "power_net_0c8e0f29b47d",
        "power_net_ae3b1a85f32f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2901",
          "pin": "2",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2905",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2901",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2908",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2904",
          "pin": "2",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2904",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2903",
          "pin": "2",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2907",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2903",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2901",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2912",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2903",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2904",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2902",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2905",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2910",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2911",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2909",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2911",
          "pin": "1",
          "netId": "power_net_61199f10a0d6",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2902",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2906",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2902",
          "pin": "2",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2910",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2912",
          "pin": "1",
          "netId": "power_net_0c8e0f29b47d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2909",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Компаратор проверяет пределы",
      "text": "Четырёхканальный компаратор преобразует отношения входных напряжений к порогам в цифровые признаки готовности.",
      "body": "Четырёхканальный компаратор преобразует отношения входных напряжений к порогам в цифровые признаки готовности.",
      "nodes": [
        "threshold",
        "compare"
      ],
      "edges": [
        "threshold_compare"
      ],
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "netIds": [
        "power_net_ae3b1a85f32f",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_d3607cfa6b03",
        "power_net_de65996f492f",
        "power_net_9ec66895516f",
        "power_net_6a587efc79ba"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2901",
          "pin": "2",
          "netId": "power_net_ae3b1a85f32f",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2909",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2910",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "14",
          "netId": "power_net_61199f10a0d6",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2911",
          "pin": "1",
          "netId": "power_net_61199f10a0d6",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2912",
          "pin": "1",
          "netId": "power_net_0c8e0f29b47d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "13",
          "netId": "power_net_0c8e0f29b47d",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2901",
          "pin": "2",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "4",
          "netId": "power_net_d3607cfa6b03",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2905",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2901",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "6",
          "netId": "power_net_de65996f492f",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2902",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2906",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2902",
          "pin": "2",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "8",
          "netId": "power_net_9ec66895516f",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2903",
          "pin": "2",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2907",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2903",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "10",
          "netId": "power_net_6a587efc79ba",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2908",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2904",
          "pin": "2",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2904",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Статус идёт в логику готовности",
      "text": "Выходные цепи компаратора продолжаются в узлы готовности питания. Конкретный уровень «норма» читается по именам и полярности исходных цепей.",
      "body": "Выходные цепи компаратора продолжаются в узлы готовности питания. Конкретный уровень «норма» читается по именам и полярности исходных цепей.",
      "nodes": [
        "compare"
      ],
      "edges": [],
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "netIds": [
        "power_net_e46274585def",
        "power_net_ae3b1a85f32f",
        "power_net_67006db669b3",
        "power_net_d3607cfa6b03",
        "power_net_0673bddb62dd",
        "power_net_de65996f492f",
        "power_net_710c162550a1",
        "power_net_9ec66895516f",
        "power_net_68f62ae4eb87",
        "power_net_6a587efc79ba",
        "power_net_de6034a2bdb7",
        "power_net_0c8e0f29b47d",
        "power_net_61199f10a0d6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2901",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "2",
          "netId": "power_net_ae3b1a85f32f",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "4",
          "netId": "power_net_d3607cfa6b03",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "5",
          "netId": "power_net_0673bddb62dd",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "6",
          "netId": "power_net_de65996f492f",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "7",
          "netId": "power_net_710c162550a1",
          "name": "IN2+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "8",
          "netId": "power_net_9ec66895516f",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "9",
          "netId": "power_net_68f62ae4eb87",
          "name": "IN3+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "10",
          "netId": "power_net_6a587efc79ba",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "11",
          "netId": "power_net_de6034a2bdb7",
          "name": "IN4+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "13",
          "netId": "power_net_0c8e0f29b47d",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "14",
          "netId": "power_net_61199f10a0d6",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измеренные напряжения сравниваются с окнами",
      "text": "Делители формируют пороги допустимых напряжений аналоговых шин.",
      "body": "Делители формируют пороги допустимых напряжений аналоговых шин.",
      "nodes": [
        "threshold"
      ],
      "edges": [],
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "netIds": [
        "power_net_d3607cfa6b03",
        "power_net_6a587efc79ba",
        "power_net_9ec66895516f",
        "power_net_67006db669b3",
        "power_net_61199f10a0d6",
        "power_net_de65996f492f",
        "power_net_e46274585def",
        "power_net_0c8e0f29b47d",
        "power_net_ae3b1a85f32f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2901",
          "pin": "2",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2905",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2901",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2908",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2904",
          "pin": "2",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2904",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2903",
          "pin": "2",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2907",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2903",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2901",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2912",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2903",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2904",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2902",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2905",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2910",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2911",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2909",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2911",
          "pin": "1",
          "netId": "power_net_61199f10a0d6",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2902",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2906",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2902",
          "pin": "2",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2910",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2912",
          "pin": "1",
          "netId": "power_net_0c8e0f29b47d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2909",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Компаратор проверяет пределы",
      "text": "Четырёхканальный компаратор преобразует отношения входных напряжений к порогам в цифровые признаки готовности.",
      "body": "Четырёхканальный компаратор преобразует отношения входных напряжений к порогам в цифровые признаки готовности.",
      "nodes": [
        "threshold",
        "compare"
      ],
      "edges": [
        "threshold_compare"
      ],
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "netIds": [
        "power_net_ae3b1a85f32f",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_d3607cfa6b03",
        "power_net_de65996f492f",
        "power_net_9ec66895516f",
        "power_net_6a587efc79ba"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2901",
          "pin": "2",
          "netId": "power_net_ae3b1a85f32f",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2909",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2910",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "14",
          "netId": "power_net_61199f10a0d6",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2911",
          "pin": "1",
          "netId": "power_net_61199f10a0d6",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2912",
          "pin": "1",
          "netId": "power_net_0c8e0f29b47d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "13",
          "netId": "power_net_0c8e0f29b47d",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2901",
          "pin": "2",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "4",
          "netId": "power_net_d3607cfa6b03",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2905",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2901",
          "pin": "1",
          "netId": "power_net_d3607cfa6b03",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "6",
          "netId": "power_net_de65996f492f",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2902",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2906",
          "pin": "1",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2902",
          "pin": "2",
          "netId": "power_net_de65996f492f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "8",
          "netId": "power_net_9ec66895516f",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2903",
          "pin": "2",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2907",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2903",
          "pin": "1",
          "netId": "power_net_9ec66895516f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "10",
          "netId": "power_net_6a587efc79ba",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2908",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2904",
          "pin": "2",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2904",
          "pin": "1",
          "netId": "power_net_6a587efc79ba",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Статус идёт в логику готовности",
      "text": "Выходные цепи компаратора продолжаются в узлы готовности питания. Конкретный уровень «норма» читается по именам и полярности исходных цепей.",
      "body": "Выходные цепи компаратора продолжаются в узлы готовности питания. Конкретный уровень «норма» читается по именам и полярности исходных цепей.",
      "nodes": [
        "compare"
      ],
      "edges": [],
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "netIds": [
        "power_net_e46274585def",
        "power_net_ae3b1a85f32f",
        "power_net_67006db669b3",
        "power_net_d3607cfa6b03",
        "power_net_0673bddb62dd",
        "power_net_de65996f492f",
        "power_net_710c162550a1",
        "power_net_9ec66895516f",
        "power_net_68f62ae4eb87",
        "power_net_6a587efc79ba",
        "power_net_de6034a2bdb7",
        "power_net_0c8e0f29b47d",
        "power_net_61199f10a0d6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2901",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "2",
          "netId": "power_net_ae3b1a85f32f",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "4",
          "netId": "power_net_d3607cfa6b03",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "5",
          "netId": "power_net_0673bddb62dd",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "6",
          "netId": "power_net_de65996f492f",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "7",
          "netId": "power_net_710c162550a1",
          "name": "IN2+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "8",
          "netId": "power_net_9ec66895516f",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "9",
          "netId": "power_net_68f62ae4eb87",
          "name": "IN3+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "10",
          "netId": "power_net_6a587efc79ba",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "11",
          "netId": "power_net_de6034a2bdb7",
          "name": "IN4+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "13",
          "netId": "power_net_0c8e0f29b47d",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "14",
          "netId": "power_net_61199f10a0d6",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
