/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "title": "Как работает: Ethernet · от сигнала в кабеле до ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "steps": [
    {
      "title": "Сигнал входит в разъём",
      "text": "На выводы J900 приходят физические сигналы Ethernet. Для пары A это цепи ETH_A_P и ETH_A_N; остальные пары подписаны своими именами из KiCad.",
      "body": "На выводы J900 приходят физические сигналы Ethernet. Для пары A это цепи ETH_A_P и ETH_A_N; остальные пары подписаны своими именами из KiCad.",
      "nodes": [
        "connector"
      ],
      "edges": [],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_352fe6713403",
        "control_net_d0b95aef42d1",
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9",
        "control_net_a66b4051999a",
        "control_net_bd3f491e3f16"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "SH",
          "netId": "control_net_352fe6713403",
          "name": "Shield",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R921",
          "pin": "2",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C937",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "2",
          "netId": "control_net_d0b95aef42d1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "10",
          "netId": "control_net_a66b4051999a",
          "name": "Green_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "12",
          "netId": "control_net_bd3f491e3f16",
          "name": "Yellow_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Трансформатор передаёт сигнал",
      "text": "T900 переносит сигнал между кабельной и платной сторонами через магнитную связь. После него используются имена MDI_A_P/N и соответствующие цепи остальных пар.",
      "body": "T900 переносит сигнал между кабельной и платной сторонами через магнитную связь. После него используются имена MDI_A_P/N и соответствующие цепи остальных пар.",
      "nodes": [
        "connector",
        "isolation"
      ],
      "edges": [
        "connector_isolation_0"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "24",
          "netId": "control_net_eb689a40d9d8",
          "name": "MXA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "22",
          "netId": "control_net_a0be4ca78cf4",
          "name": "MXA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "21",
          "netId": "control_net_783e9d027a80",
          "name": "MXB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "18",
          "netId": "control_net_e72d81f71514",
          "name": "MXC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "16",
          "netId": "control_net_75386a9fba9e",
          "name": "MXC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "19",
          "netId": "control_net_40965b12abcc",
          "name": "MXB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "15",
          "netId": "control_net_46a7e4543439",
          "name": "MXD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "13",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "MXD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "PHY восстанавливает цифровые данные",
      "text": "U902 преобразует физический сигнал линии в синхронный цифровой интерфейс. Кабельное кодирование и реальные задержки эта учебная история не моделирует.",
      "body": "U902 преобразует физический сигнал линии в синхронный цифровой интерфейс. Кабельное кодирование и реальные задержки эта учебная история не моделирует.",
      "nodes": [
        "isolation",
        "phy"
      ],
      "edges": [
        "isolation_phy_1"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_e227481650c4",
        "control_net_2b9e82ff1f9a",
        "control_net_b7668147936d",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_c7652af8ac7f",
        "control_net_c06d53ceafd7",
        "control_net_c72c6f1d768f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U902",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TD_P_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TDC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "8",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TD_M_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "9",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TDC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TD_P_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TDA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "2",
          "netId": "control_net_f14d9beef5b0",
          "name": "TD_M_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "3",
          "netId": "control_net_f14d9beef5b0",
          "name": "TDA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TD_P_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TDB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "5",
          "netId": "control_net_c7652af8ac7f",
          "name": "TD_M_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "6",
          "netId": "control_net_c7652af8ac7f",
          "name": "TDB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TD_P_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TDD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "11",
          "netId": "control_net_c72c6f1d768f",
          "name": "TD_M_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "12",
          "netId": "control_net_c72c6f1d768f",
          "name": "TDD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Данные доходят до ПЛИС",
      "text": "PHY_RXD0…3, PHY_RXC и PHY_RX_CTL соединяют PHY с U500. В ПЛИС принимаются цифровые данные; обработку кадров выполняет выбранная реализация MAC и протоколов.",
      "body": "PHY_RXD0…3, PHY_RXC и PHY_RX_CTL соединяют PHY с U500. В ПЛИС принимаются цифровые данные; обработку кадров выполняет выбранная реализация MAC и протоколов.",
      "nodes": [
        "phy",
        "fpga"
      ],
      "edges": [
        "phy_fpga_2",
        "fpga_phy_3",
        "fpga_phy_4"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_842a1bd896e7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_af615c537cb1",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_20b74826bb9f",
        "control_net_c9c89af3970f",
        "control_net_06de98680544",
        "control_net_0d1a4f8df7dc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R910",
          "pin": "1",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R909",
          "pin": "2",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R912",
          "pin": "1",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R911",
          "pin": "2",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "17",
          "netId": "control_net_20b74826bb9f",
          "name": "MDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R907",
          "pin": "2",
          "netId": "control_net_20b74826bb9f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "1",
          "netId": "control_net_c9c89af3970f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "16",
          "netId": "control_net_06de98680544",
          "name": "MDC",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "44",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "INT/PWDN",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R908",
          "pin": "2",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обратный тракт и управление",
      "text": "PHY_TXD0…3, PHY_TXC и PHY_TX_CTL обслуживают передачу. PHY_MDC и PHY_MDIO предназначены для управления PHY; они не заменяют поток данных RGMII.",
      "body": "PHY_TXD0…3, PHY_TXC и PHY_TX_CTL обслуживают передачу. PHY_MDC и PHY_MDIO предназначены для управления PHY; они не заменяют поток данных RGMII.",
      "nodes": [
        "fpga",
        "phy"
      ],
      "edges": [
        "phy_fpga_2",
        "fpga_phy_3",
        "fpga_phy_4"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_842a1bd896e7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_af615c537cb1",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_20b74826bb9f",
        "control_net_c9c89af3970f",
        "control_net_06de98680544",
        "control_net_0d1a4f8df7dc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R910",
          "pin": "1",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R909",
          "pin": "2",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R912",
          "pin": "1",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R911",
          "pin": "2",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "17",
          "netId": "control_net_20b74826bb9f",
          "name": "MDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R907",
          "pin": "2",
          "netId": "control_net_20b74826bb9f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "1",
          "netId": "control_net_c9c89af3970f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "16",
          "netId": "control_net_06de98680544",
          "name": "MDC",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "44",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "INT/PWDN",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R908",
          "pin": "2",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Сигнал входит в разъём",
      "text": "На выводы J900 приходят физические сигналы Ethernet. Для пары A это цепи ETH_A_P и ETH_A_N; остальные пары подписаны своими именами из KiCad.",
      "body": "На выводы J900 приходят физические сигналы Ethernet. Для пары A это цепи ETH_A_P и ETH_A_N; остальные пары подписаны своими именами из KiCad.",
      "nodes": [
        "connector"
      ],
      "edges": [],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_352fe6713403",
        "control_net_d0b95aef42d1",
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9",
        "control_net_a66b4051999a",
        "control_net_bd3f491e3f16"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "SH",
          "netId": "control_net_352fe6713403",
          "name": "Shield",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R921",
          "pin": "2",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C937",
          "pin": "1",
          "netId": "control_net_352fe6713403",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C938",
          "pin": "2",
          "netId": "control_net_d0b95aef42d1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "10",
          "netId": "control_net_a66b4051999a",
          "name": "Green_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "12",
          "netId": "control_net_bd3f491e3f16",
          "name": "Yellow_A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Трансформатор передаёт сигнал",
      "text": "T900 переносит сигнал между кабельной и платной сторонами через магнитную связь. После него используются имена MDI_A_P/N и соответствующие цепи остальных пар.",
      "body": "T900 переносит сигнал между кабельной и платной сторонами через магнитную связь. После него используются имена MDI_A_P/N и соответствующие цепи остальных пар.",
      "nodes": [
        "connector",
        "isolation"
      ],
      "edges": [
        "connector_isolation_0"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J900",
          "pin": "1",
          "netId": "control_net_eb689a40d9d8",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "24",
          "netId": "control_net_eb689a40d9d8",
          "name": "MXA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "2",
          "netId": "control_net_a0be4ca78cf4",
          "name": "2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "22",
          "netId": "control_net_a0be4ca78cf4",
          "name": "MXA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "3",
          "netId": "control_net_783e9d027a80",
          "name": "3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "21",
          "netId": "control_net_783e9d027a80",
          "name": "MXB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "4",
          "netId": "control_net_e72d81f71514",
          "name": "4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "18",
          "netId": "control_net_e72d81f71514",
          "name": "MXC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "5",
          "netId": "control_net_75386a9fba9e",
          "name": "5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "16",
          "netId": "control_net_75386a9fba9e",
          "name": "MXC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "6",
          "netId": "control_net_40965b12abcc",
          "name": "6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "19",
          "netId": "control_net_40965b12abcc",
          "name": "MXB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "7",
          "netId": "control_net_46a7e4543439",
          "name": "7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "15",
          "netId": "control_net_46a7e4543439",
          "name": "MXD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J900",
          "pin": "8",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "13",
          "netId": "control_net_a5f76ff3f3d9",
          "name": "MXD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "PHY восстанавливает цифровые данные",
      "text": "U902 преобразует физический сигнал линии в синхронный цифровой интерфейс. Кабельное кодирование и реальные задержки эта учебная история не моделирует.",
      "body": "U902 преобразует физический сигнал линии в синхронный цифровой интерфейс. Кабельное кодирование и реальные задержки эта учебная история не моделирует.",
      "nodes": [
        "isolation",
        "phy"
      ],
      "edges": [
        "isolation_phy_1"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_e227481650c4",
        "control_net_2b9e82ff1f9a",
        "control_net_b7668147936d",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_c7652af8ac7f",
        "control_net_c06d53ceafd7",
        "control_net_c72c6f1d768f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U902",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TD_P_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "7",
          "netId": "control_net_e227481650c4",
          "name": "TDC+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "8",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TD_M_C",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "9",
          "netId": "control_net_2b9e82ff1f9a",
          "name": "TDC-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TD_P_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "1",
          "netId": "control_net_b7668147936d",
          "name": "TDA+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "2",
          "netId": "control_net_f14d9beef5b0",
          "name": "TD_M_A",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "3",
          "netId": "control_net_f14d9beef5b0",
          "name": "TDA-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TD_P_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "4",
          "netId": "control_net_bdf65fc018f7",
          "name": "TDB+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "5",
          "netId": "control_net_c7652af8ac7f",
          "name": "TD_M_B",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "6",
          "netId": "control_net_c7652af8ac7f",
          "name": "TDB-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TD_P_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "10",
          "netId": "control_net_c06d53ceafd7",
          "name": "TDD+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "11",
          "netId": "control_net_c72c6f1d768f",
          "name": "TD_M_D",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_T900",
          "pin": "12",
          "netId": "control_net_c72c6f1d768f",
          "name": "TDD-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Данные доходят до ПЛИС",
      "text": "PHY_RXD0…3, PHY_RXC и PHY_RX_CTL соединяют PHY с U500. В ПЛИС принимаются цифровые данные; обработку кадров выполняет выбранная реализация MAC и протоколов.",
      "body": "PHY_RXD0…3, PHY_RXC и PHY_RX_CTL соединяют PHY с U500. В ПЛИС принимаются цифровые данные; обработку кадров выполняет выбранная реализация MAC и протоколов.",
      "nodes": [
        "phy",
        "fpga"
      ],
      "edges": [
        "phy_fpga_2",
        "fpga_phy_3",
        "fpga_phy_4"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_842a1bd896e7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_af615c537cb1",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_20b74826bb9f",
        "control_net_c9c89af3970f",
        "control_net_06de98680544",
        "control_net_0d1a4f8df7dc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R910",
          "pin": "1",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R909",
          "pin": "2",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R912",
          "pin": "1",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R911",
          "pin": "2",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "17",
          "netId": "control_net_20b74826bb9f",
          "name": "MDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R907",
          "pin": "2",
          "netId": "control_net_20b74826bb9f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "1",
          "netId": "control_net_c9c89af3970f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "16",
          "netId": "control_net_06de98680544",
          "name": "MDC",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "44",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "INT/PWDN",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R908",
          "pin": "2",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обратный тракт и управление",
      "text": "PHY_TXD0…3, PHY_TXC и PHY_TX_CTL обслуживают передачу. PHY_MDC и PHY_MDIO предназначены для управления PHY; они не заменяют поток данных RGMII.",
      "body": "PHY_TXD0…3, PHY_TXC и PHY_TX_CTL обслуживают передачу. PHY_MDC и PHY_MDIO предназначены для управления PHY; они не заменяют поток данных RGMII.",
      "nodes": [
        "fpga",
        "phy"
      ],
      "edges": [
        "phy_fpga_2",
        "fpga_phy_3",
        "fpga_phy_4"
      ],
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "netIds": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_842a1bd896e7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_af615c537cb1",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_20b74826bb9f",
        "control_net_c9c89af3970f",
        "control_net_06de98680544",
        "control_net_0d1a4f8df7dc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R910",
          "pin": "1",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R909",
          "pin": "2",
          "netId": "control_net_5682aa39e237",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R912",
          "pin": "1",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R911",
          "pin": "2",
          "netId": "control_net_e39e2c0118dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA14",
          "netId": "control_net_20b74826bb9f",
          "name": "IO_L5N_T0_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "17",
          "netId": "control_net_20b74826bb9f",
          "name": "MDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R907",
          "pin": "2",
          "netId": "control_net_20b74826bb9f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB11",
          "netId": "control_net_c9c89af3970f",
          "name": "IO_L7P_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R913",
          "pin": "1",
          "netId": "control_net_c9c89af3970f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W14",
          "netId": "control_net_06de98680544",
          "name": "IO_L6P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "16",
          "netId": "control_net_06de98680544",
          "name": "MDC",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y14",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "IO_L6N_T0_VREF_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "44",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "INT/PWDN",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R908",
          "pin": "2",
          "netId": "control_net_0d1a4f8df7dc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
