/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2700_PM_ENABLE_GATES_PRIMARY",
  "title": "Как работает: Разрешения основных преобразователей",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
  "steps": [
    {
      "title": "Появляются запросы основных ветвей",
      "text": "Группы логических элементов принимают запросы преобразователей и аппаратные разрешения.",
      "body": "Группы логических элементов принимают запросы преобразователей и аппаратные разрешения.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проверяется разрешением",
      "text": "Каждый выход управления зависит от соответствующих входных условий. В этой истории подсвечиваются связи, а не задаётся универсальный уровень включения.",
      "body": "Каждый выход управления зависит от соответствующих входных условий. В этой истории подсвечиваются связи, а не задаётся универсальный уровень включения.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Начальные состояния определены",
      "text": "Резисторы задают значения управляющих цепей при запуске, прежде чем контроллер начнёт их активно формировать.",
      "body": "Резисторы задают значения управляющих цепей при запуске, прежде чем контроллер начнёт их активно формировать.",
      "nodes": [
        "default",
        "first",
        "second"
      ],
      "edges": [
        "first_second",
        "first_default",
        "second_default"
      ],
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "netIds": [
        "power_net_8828c890966d",
        "power_net_f4716909bd0c",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65",
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2702",
          "pin": "1",
          "netId": "power_net_f4716909bd0c",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "2",
          "netId": "power_net_f4716909bd0c",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "5",
          "netId": "power_net_c19f5798f458",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2703",
          "pin": "1",
          "netId": "power_net_c19f5798f458",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2704",
          "pin": "1",
          "netId": "power_net_c66ec173184e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "10",
          "netId": "power_net_c66ec173184e",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "13",
          "netId": "power_net_83fb386e92c5",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2701",
          "pin": "2",
          "netId": "power_net_83fb386e92c5",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "3",
          "netId": "power_net_6649c6cdd008",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2705",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "6",
          "netId": "power_net_9020238d369a",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2706",
          "pin": "1",
          "netId": "power_net_9020238d369a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "8",
          "netId": "power_net_7f7616523bf4",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2707",
          "pin": "1",
          "netId": "power_net_7f7616523bf4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "11",
          "netId": "power_net_6220152fdd65",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2708",
          "pin": "2",
          "netId": "power_net_6220152fdd65",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "2",
          "netId": "power_net_c876bbd15aa2",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2710",
          "pin": "1",
          "netId": "power_net_c876bbd15aa2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2711",
          "pin": "1",
          "netId": "power_net_5a10e16f7ce2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "5",
          "netId": "power_net_5a10e16f7ce2",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "10",
          "netId": "power_net_1f6f0734f873",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2712",
          "pin": "1",
          "netId": "power_net_1f6f0734f873",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "13",
          "netId": "power_net_afa5c4d57041",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2709",
          "pin": "2",
          "netId": "power_net_afa5c4d57041",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "3",
          "netId": "power_net_35be90fefcdd",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2713",
          "pin": "1",
          "netId": "power_net_35be90fefcdd",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "6",
          "netId": "power_net_afd79c7e6e58",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2714",
          "pin": "1",
          "netId": "power_net_afd79c7e6e58",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "8",
          "netId": "power_net_3db57ce8c78a",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2715",
          "pin": "1",
          "netId": "power_net_3db57ce8c78a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "11",
          "netId": "power_net_9693d69e08e6",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2716",
          "pin": "2",
          "netId": "power_net_9693d69e08e6",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Появляются запросы основных ветвей",
      "text": "Группы логических элементов принимают запросы преобразователей и аппаратные разрешения.",
      "body": "Группы логических элементов принимают запросы преобразователей и аппаратные разрешения.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проверяется разрешением",
      "text": "Каждый выход управления зависит от соответствующих входных условий. В этой истории подсвечиваются связи, а не задаётся универсальный уровень включения.",
      "body": "Каждый выход управления зависит от соответствующих входных условий. В этой истории подсвечиваются связи, а не задаётся универсальный уровень включения.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "netIds": [
        "power_net_8828c890966d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Начальные состояния определены",
      "text": "Резисторы задают значения управляющих цепей при запуске, прежде чем контроллер начнёт их активно формировать.",
      "body": "Резисторы задают значения управляющих цепей при запуске, прежде чем контроллер начнёт их активно формировать.",
      "nodes": [
        "default",
        "first",
        "second"
      ],
      "edges": [
        "first_second",
        "first_default",
        "second_default"
      ],
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "netIds": [
        "power_net_8828c890966d",
        "power_net_f4716909bd0c",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65",
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2702",
          "pin": "1",
          "netId": "power_net_f4716909bd0c",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "2",
          "netId": "power_net_f4716909bd0c",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "5",
          "netId": "power_net_c19f5798f458",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2703",
          "pin": "1",
          "netId": "power_net_c19f5798f458",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2704",
          "pin": "1",
          "netId": "power_net_c66ec173184e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "10",
          "netId": "power_net_c66ec173184e",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "13",
          "netId": "power_net_83fb386e92c5",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2701",
          "pin": "2",
          "netId": "power_net_83fb386e92c5",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "3",
          "netId": "power_net_6649c6cdd008",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2705",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "6",
          "netId": "power_net_9020238d369a",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2706",
          "pin": "1",
          "netId": "power_net_9020238d369a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "8",
          "netId": "power_net_7f7616523bf4",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2707",
          "pin": "1",
          "netId": "power_net_7f7616523bf4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "11",
          "netId": "power_net_6220152fdd65",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2708",
          "pin": "2",
          "netId": "power_net_6220152fdd65",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "2",
          "netId": "power_net_c876bbd15aa2",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2710",
          "pin": "1",
          "netId": "power_net_c876bbd15aa2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2711",
          "pin": "1",
          "netId": "power_net_5a10e16f7ce2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "5",
          "netId": "power_net_5a10e16f7ce2",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "10",
          "netId": "power_net_1f6f0734f873",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2712",
          "pin": "1",
          "netId": "power_net_1f6f0734f873",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "13",
          "netId": "power_net_afa5c4d57041",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2709",
          "pin": "2",
          "netId": "power_net_afa5c4d57041",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "3",
          "netId": "power_net_35be90fefcdd",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2713",
          "pin": "1",
          "netId": "power_net_35be90fefcdd",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "6",
          "netId": "power_net_afd79c7e6e58",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2714",
          "pin": "1",
          "netId": "power_net_afd79c7e6e58",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "8",
          "netId": "power_net_3db57ce8c78a",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2715",
          "pin": "1",
          "netId": "power_net_3db57ce8c78a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "11",
          "netId": "power_net_9693d69e08e6",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2716",
          "pin": "2",
          "netId": "power_net_9693d69e08e6",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
