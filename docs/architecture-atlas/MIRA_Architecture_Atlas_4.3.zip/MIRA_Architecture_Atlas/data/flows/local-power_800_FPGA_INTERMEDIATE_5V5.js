/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_800_FPGA_INTERMEDIATE_5V5",
  "title": "Как работает: Промежуточное питание ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
  "steps": [
    {
      "title": "На вход приходит BUS24",
      "text": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U801",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_7f7616523bf4",
        "power_net_08c3817ee687"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q801",
          "pin": "1",
          "netId": "power_net_7f7616523bf4",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q801",
          "pin": "2",
          "netId": "power_net_08c3817ee687",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R802",
          "pin": "2",
          "netId": "power_net_08c3817ee687",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "18",
          "netId": "power_net_08c3817ee687",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует FPGA5V5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину FPGA5V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину FPGA5V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_20b613e14cd0",
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C814",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C811",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L801",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C809",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C808",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C810",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "9",
          "netId": "power_net_20b613e14cd0",
          "name": "BIAS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C802",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R805",
          "pin": "1",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C813",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C812",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R803",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R806",
          "pin": "1",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R805",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования FPGA5V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования FPGA5V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R806",
          "pin": "1",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R805",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит BUS24",
      "text": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U801",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_7f7616523bf4",
        "power_net_08c3817ee687"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q801",
          "pin": "1",
          "netId": "power_net_7f7616523bf4",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q801",
          "pin": "2",
          "netId": "power_net_08c3817ee687",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R802",
          "pin": "2",
          "netId": "power_net_08c3817ee687",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "18",
          "netId": "power_net_08c3817ee687",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует FPGA5V5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину FPGA5V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину FPGA5V5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_20b613e14cd0",
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C814",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C811",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L801",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C809",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C808",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C810",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "9",
          "netId": "power_net_20b613e14cd0",
          "name": "BIAS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C802",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R805",
          "pin": "1",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C813",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C812",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R803",
          "pin": "2",
          "netId": "power_net_20b613e14cd0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R806",
          "pin": "1",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R805",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования FPGA5V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования FPGA5V5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R806",
          "pin": "1",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R805",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
