/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_900_ANALOG_PREREGULATOR_6V",
  "title": "Как работает: Предстабилизатор аналогового питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
  "steps": [
    {
      "title": "На вход приходит BUS24",
      "text": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U901",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_6220152fdd65",
        "power_net_b17423d6c3da"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q901",
          "pin": "1",
          "netId": "power_net_6220152fdd65",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R901",
          "pin": "2",
          "netId": "power_net_b17423d6c3da",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q901",
          "pin": "2",
          "netId": "power_net_b17423d6c3da",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "4",
          "netId": "power_net_b17423d6c3da",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует ANA6",
      "text": "Регулятор и цепь обратной связи формируют выходную шину ANA6. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину ANA6. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_44a5bd51b5f3",
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C904",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R902",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R904",
          "pin": "1",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C905",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L901",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R905",
          "pin": "1",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R904",
          "pin": "2",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования ANA6 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования ANA6 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R905",
          "pin": "1",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R904",
          "pin": "2",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит BUS24",
      "text": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U901",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_6220152fdd65",
        "power_net_b17423d6c3da"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q901",
          "pin": "1",
          "netId": "power_net_6220152fdd65",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R901",
          "pin": "2",
          "netId": "power_net_b17423d6c3da",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q901",
          "pin": "2",
          "netId": "power_net_b17423d6c3da",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "4",
          "netId": "power_net_b17423d6c3da",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует ANA6",
      "text": "Регулятор и цепь обратной связи формируют выходную шину ANA6. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину ANA6. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_44a5bd51b5f3",
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C904",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R902",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R904",
          "pin": "1",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C905",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L901",
          "pin": "2",
          "netId": "power_net_44a5bd51b5f3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R905",
          "pin": "1",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R904",
          "pin": "2",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования ANA6 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования ANA6 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "netIds": [
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R905",
          "pin": "1",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R904",
          "pin": "2",
          "netId": "power_net_bbc855740138",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
