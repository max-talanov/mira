/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control-regulation",
  "title": "Как работает: Регулирование напряжения и тока записи",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control-regulation",
  "steps": [
    {
      "title": "Ограничение напряжения и тока записи",
      "text": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
      "body": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
      "nodes": [
        "sheet2100"
      ],
      "edges": [],
      "sceneId": "control-regulation",
      "netIds": [
        "control_net_884dc726c5ee",
        "control_net_eafb3ab75ceb",
        "control_net_1f8df2d46142",
        "control_net_c716783a5090",
        "control_net_55226bb23b92",
        "control_net_c2d31e9a7d3a",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_6f005443ad9c",
        "control_net_e5381212c338",
        "control_net_2e82cb98585d",
        "control_net_c3b957dc2a05",
        "control_net_a6fb2d1ff68e",
        "control_net_ca37f2f49804",
        "control_net_cac6d1065fe3",
        "control_net_e5df7ddd81fb",
        "control_net_53c8d7c2e621",
        "control_net_87568f65b103",
        "control_net_ec1f99fd4e92",
        "control_net_b2576a7cb753",
        "control_net_edfd1164669d",
        "control_net_d61741b3dc08",
        "control_net_940e1a072e47",
        "control_net_dccc00cf1ac5",
        "control_net_f3e0955eaa32",
        "control_net_849e422bddae",
        "control_net_e08ef2a7ed03",
        "control_net_f58cc678464d",
        "control_net_2860e727c5a6",
        "control_net_2b71697338af",
        "control_net_4b7c47b539e3",
        "control_net_5b5c009b1508",
        "control_net_13ff4635cb1b",
        "control_net_2726bce99541",
        "control_net_f162a522d292",
        "control_net_a93f35a82a80",
        "control_net_22ad804f0822",
        "control_net_95b44f3c6099",
        "control_net_18acc164b68f",
        "control_net_e8888f1f4342",
        "control_net_b04095b4354a",
        "control_net_755898631f7c",
        "control_net_a21410d27b0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2103",
          "pin": "4",
          "netId": "control_net_884dc726c5ee",
          "name": "S1A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "13",
          "netId": "control_net_884dc726c5ee",
          "name": "S1B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "5",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "12",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "6",
          "netId": "control_net_1f8df2d46142",
          "name": "S3A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "11",
          "netId": "control_net_1f8df2d46142",
          "name": "S3B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "7",
          "netId": "control_net_c716783a5090",
          "name": "S4A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "10",
          "netId": "control_net_c716783a5090",
          "name": "S4B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "8",
          "netId": "control_net_55226bb23b92",
          "name": "DA",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "9",
          "netId": "control_net_c2d31e9a7d3a",
          "name": "DB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "4",
          "netId": "control_net_c2d31e9a7d3a",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "1",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "16",
          "netId": "control_net_4cbb94b58c81",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "11",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "11",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "14",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "8",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "8",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "4",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "4",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "8",
          "netId": "control_net_e5df7ddd81fb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "1",
          "netId": "control_net_87568f65b103",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "2",
          "netId": "control_net_ec1f99fd4e92",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "3",
          "netId": "control_net_b2576a7cb753",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "7",
          "netId": "control_net_edfd1164669d",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "3",
          "netId": "control_net_d61741b3dc08",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "2",
          "netId": "control_net_940e1a072e47",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "1",
          "netId": "control_net_dccc00cf1ac5",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "10",
          "netId": "control_net_dccc00cf1ac5",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "5",
          "netId": "control_net_f3e0955eaa32",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "6",
          "netId": "control_net_849e422bddae",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "7",
          "netId": "control_net_e08ef2a7ed03",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "12",
          "netId": "control_net_e08ef2a7ed03",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "9",
          "netId": "control_net_f58cc678464d",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "8",
          "netId": "control_net_2860e727c5a6",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "13",
          "netId": "control_net_2b71697338af",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "14",
          "netId": "control_net_4b7c47b539e3",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "4",
          "netId": "control_net_5b5c009b1508",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "1",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "2",
          "netId": "control_net_2726bce99541",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "3",
          "netId": "control_net_f162a522d292",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "7",
          "netId": "control_net_a93f35a82a80",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "3",
          "netId": "control_net_22ad804f0822",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "2",
          "netId": "control_net_95b44f3c6099",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "1",
          "netId": "control_net_95b44f3c6099",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "5",
          "netId": "control_net_18acc164b68f",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "6",
          "netId": "control_net_e8888f1f4342",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "7",
          "netId": "control_net_b04095b4354a",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "9",
          "netId": "control_net_755898631f7c",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "8",
          "netId": "control_net_755898631f7c",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "13",
          "netId": "control_net_a21410d27b0e",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "14",
          "netId": "control_net_a21410d27b0e",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Ограничение напряжения и тока записи",
      "text": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
      "body": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
      "nodes": [
        "sheet2100"
      ],
      "edges": [],
      "sceneId": "control-regulation",
      "netIds": [
        "control_net_884dc726c5ee",
        "control_net_eafb3ab75ceb",
        "control_net_1f8df2d46142",
        "control_net_c716783a5090",
        "control_net_55226bb23b92",
        "control_net_c2d31e9a7d3a",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_6f005443ad9c",
        "control_net_e5381212c338",
        "control_net_2e82cb98585d",
        "control_net_c3b957dc2a05",
        "control_net_a6fb2d1ff68e",
        "control_net_ca37f2f49804",
        "control_net_cac6d1065fe3",
        "control_net_e5df7ddd81fb",
        "control_net_53c8d7c2e621",
        "control_net_87568f65b103",
        "control_net_ec1f99fd4e92",
        "control_net_b2576a7cb753",
        "control_net_edfd1164669d",
        "control_net_d61741b3dc08",
        "control_net_940e1a072e47",
        "control_net_dccc00cf1ac5",
        "control_net_f3e0955eaa32",
        "control_net_849e422bddae",
        "control_net_e08ef2a7ed03",
        "control_net_f58cc678464d",
        "control_net_2860e727c5a6",
        "control_net_2b71697338af",
        "control_net_4b7c47b539e3",
        "control_net_5b5c009b1508",
        "control_net_13ff4635cb1b",
        "control_net_2726bce99541",
        "control_net_f162a522d292",
        "control_net_a93f35a82a80",
        "control_net_22ad804f0822",
        "control_net_95b44f3c6099",
        "control_net_18acc164b68f",
        "control_net_e8888f1f4342",
        "control_net_b04095b4354a",
        "control_net_755898631f7c",
        "control_net_a21410d27b0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2103",
          "pin": "4",
          "netId": "control_net_884dc726c5ee",
          "name": "S1A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "13",
          "netId": "control_net_884dc726c5ee",
          "name": "S1B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "5",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "12",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "6",
          "netId": "control_net_1f8df2d46142",
          "name": "S3A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "11",
          "netId": "control_net_1f8df2d46142",
          "name": "S3B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "7",
          "netId": "control_net_c716783a5090",
          "name": "S4A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "10",
          "netId": "control_net_c716783a5090",
          "name": "S4B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "8",
          "netId": "control_net_55226bb23b92",
          "name": "DA",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "9",
          "netId": "control_net_c2d31e9a7d3a",
          "name": "DB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "4",
          "netId": "control_net_c2d31e9a7d3a",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "1",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "16",
          "netId": "control_net_4cbb94b58c81",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "11",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "11",
          "netId": "control_net_e5381212c338",
          "name": "VS-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "14",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "8",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "8",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "4",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "4",
          "netId": "control_net_2e82cb98585d",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "8",
          "netId": "control_net_e5df7ddd81fb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "1",
          "netId": "control_net_87568f65b103",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "2",
          "netId": "control_net_ec1f99fd4e92",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "3",
          "netId": "control_net_b2576a7cb753",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "7",
          "netId": "control_net_edfd1164669d",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "3",
          "netId": "control_net_d61741b3dc08",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "2",
          "netId": "control_net_940e1a072e47",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "1",
          "netId": "control_net_dccc00cf1ac5",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "10",
          "netId": "control_net_dccc00cf1ac5",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "5",
          "netId": "control_net_f3e0955eaa32",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "6",
          "netId": "control_net_849e422bddae",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "7",
          "netId": "control_net_e08ef2a7ed03",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "12",
          "netId": "control_net_e08ef2a7ed03",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "9",
          "netId": "control_net_f58cc678464d",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "8",
          "netId": "control_net_2860e727c5a6",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "13",
          "netId": "control_net_2b71697338af",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "14",
          "netId": "control_net_4b7c47b539e3",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "4",
          "netId": "control_net_5b5c009b1508",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "1",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "2",
          "netId": "control_net_2726bce99541",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "3",
          "netId": "control_net_f162a522d292",
          "name": "RG",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "7",
          "netId": "control_net_a93f35a82a80",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "3",
          "netId": "control_net_22ad804f0822",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "2",
          "netId": "control_net_95b44f3c6099",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "1",
          "netId": "control_net_95b44f3c6099",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "5",
          "netId": "control_net_18acc164b68f",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "6",
          "netId": "control_net_e8888f1f4342",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "7",
          "netId": "control_net_b04095b4354a",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "9",
          "netId": "control_net_755898631f7c",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "8",
          "netId": "control_net_755898631f7c",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "13",
          "netId": "control_net_a21410d27b0e",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "14",
          "netId": "control_net_a21410d27b0e",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
