/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "power-up",
  "title": "Подать питание",
  "description": "Посмотрите, как питание достигает контроллеров, ПЛИС и аналоговых узлов. Последовательность объясняет работу; точные временные задержки не моделируются.",
  "sceneId": "system",
  "steps": [
    {
      "title": "Подключение источника",
      "text": "Питание поступает во входную защиту платы Power.",
      "body": "Питание поступает во входную защиту платы Power.",
      "nodes": [
        "supply",
        "power"
      ],
      "edges": [
        "supply_power"
      ],
      "sceneId": "system",
      "netIds": [
        "power_net_6741c8732f40"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J101",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запуск контроля питания",
      "text": "Дежурное питание позволяет контроллеру питания проверить условия перед разрешением остальных запросов.",
      "body": "Дежурное питание позволяет контроллеру питания проверить условия перед разрешением остальных запросов.",
      "nodes": [
        "power",
        "safety"
      ],
      "edges": [],
      "sceneId": "system",
      "netIds": [
        "power_net_3937c8c839ac",
        "power_net_3dcac14084cf",
        "power_net_0118a5d9fdb8",
        "power_net_e5a2750417c1",
        "power_net_ebbb4413206b",
        "power_net_212cb9d210a9",
        "power_net_4debf317f2c4",
        "power_net_4277075bbc34",
        "power_net_cc22b913a226",
        "power_net_9517f7952aef",
        "power_net_fc607675ab2d",
        "power_net_35045b6a457d",
        "power_net_cd4425540176",
        "power_net_c9b6c7228333",
        "power_net_a837894762cd",
        "power_net_9ab95937734d",
        "power_net_cfb766cbb94f",
        "power_net_47f67f61993c",
        "power_net_15b0cf67917c",
        "power_net_9389f5dbe1a6",
        "power_net_67006db669b3",
        "power_net_f4716909bd0c",
        "power_net_3f4e1d0f28d6",
        "power_net_2cbf74589b12",
        "power_net_6ad422db16ac",
        "power_net_6d982403b080",
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_393e02135991",
        "power_net_f632ebdd7344",
        "power_net_e5822cf03a94",
        "power_net_4d93f44a0a86",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a",
        "power_net_36bf51cd4ad6",
        "power_net_ccf5ee78cf75",
        "power_net_4aeb4892b398",
        "power_net_25cd945f19a1",
        "power_net_a250a8b7fe30",
        "power_net_8828c890966d",
        "power_net_5a1f578d112a",
        "power_net_86751620b7fb",
        "power_net_ae3b1a85f32f",
        "power_net_cfa48b7bd3ef",
        "power_net_2965499926c8",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ed26aaa81531",
        "power_net_ac83bbc60cc7",
        "power_net_0ee4f5245d75",
        "power_net_99aaef80128f",
        "power_net_e1dd2bfabf3b",
        "control_net_9269f101a22a",
        "control_net_6f005443ad9c",
        "control_net_5a73b1e1ccba",
        "control_net_d44a94d9b4fd",
        "control_net_1a607d7041f2",
        "control_net_7b06e5d6a4d9",
        "control_net_2d2627aeff69",
        "control_net_720010c527b5",
        "power_net_0d67fdbc5a0d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_bc6b8848cad9",
        "power_net_6741c8732f40"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U301",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "3",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "5",
          "netId": "power_net_0118a5d9fdb8",
          "name": "DRV",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "6",
          "netId": "power_net_e5a2750417c1",
          "name": "IN_SYS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "7",
          "netId": "power_net_ebbb4413206b",
          "name": "UVLO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "8",
          "netId": "power_net_212cb9d210a9",
          "name": "OVP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "10",
          "netId": "power_net_4debf317f2c4",
          "name": "dVdT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "11",
          "netId": "power_net_4277075bbc34",
          "name": "ILIM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "12",
          "netId": "power_net_cc22b913a226",
          "name": "MODE",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "13",
          "netId": "power_net_9517f7952aef",
          "name": "SHDN_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "14",
          "netId": "power_net_fc607675ab2d",
          "name": "IMON",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "15",
          "netId": "power_net_35045b6a457d",
          "name": "FLT_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "43",
          "netId": "power_net_35045b6a457d",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "16",
          "netId": "power_net_cd4425540176",
          "name": "PGTH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "17",
          "netId": "power_net_c9b6c7228333",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "42",
          "netId": "power_net_c9b6c7228333",
          "name": "PA10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "18",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "19",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "20",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "PC11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "2",
          "netId": "power_net_cfb766cbb94f",
          "name": "PC12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "4",
          "netId": "power_net_15b0cf67917c",
          "name": "PC14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "5",
          "netId": "power_net_9389f5dbe1a6",
          "name": "PC15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "10",
          "netId": "power_net_f4716909bd0c",
          "name": "PF0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "11",
          "netId": "power_net_3f4e1d0f28d6",
          "name": "PF1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "13",
          "netId": "power_net_6ad422db16ac",
          "name": "PC0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "14",
          "netId": "power_net_6d982403b080",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "15",
          "netId": "power_net_55a52205aaf0",
          "name": "PC2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "16",
          "netId": "power_net_47577a24d67e",
          "name": "PC3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "17",
          "netId": "power_net_393e02135991",
          "name": "PA0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "18",
          "netId": "power_net_f632ebdd7344",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "19",
          "netId": "power_net_e5822cf03a94",
          "name": "PA2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "20",
          "netId": "power_net_4d93f44a0a86",
          "name": "PA3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "21",
          "netId": "power_net_c19f5798f458",
          "name": "PA4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "22",
          "netId": "power_net_c66ec173184e",
          "name": "PA5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "23",
          "netId": "power_net_83fb386e92c5",
          "name": "PA6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "24",
          "netId": "power_net_c876bbd15aa2",
          "name": "PA7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "25",
          "netId": "power_net_5a10e16f7ce2",
          "name": "PC4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "26",
          "netId": "power_net_1f6f0734f873",
          "name": "PC5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "27",
          "netId": "power_net_afa5c4d57041",
          "name": "PB0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "28",
          "netId": "power_net_d1fe7a20e661",
          "name": "PB1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "29",
          "netId": "power_net_1b4ac01010f8",
          "name": "PB2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "30",
          "netId": "power_net_5dc0cb853f29",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "31",
          "netId": "power_net_69d4e38b1bd0",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "32",
          "netId": "power_net_2c93a597633f",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "33",
          "netId": "power_net_12bae3231aaa",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "34",
          "netId": "power_net_b527a6b82695",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "35",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "36",
          "netId": "power_net_97db96dcc04b",
          "name": "PA8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "37",
          "netId": "power_net_2074a83eb788",
          "name": "PA9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "38",
          "netId": "power_net_7071622db9df",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "39",
          "netId": "power_net_b5187ab6f19a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "40",
          "netId": "power_net_36bf51cd4ad6",
          "name": "PD8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "41",
          "netId": "power_net_ccf5ee78cf75",
          "name": "PD9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "45",
          "netId": "power_net_25cd945f19a1",
          "name": "PA13/SWDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "46",
          "netId": "power_net_a250a8b7fe30",
          "name": "PA14/BOOT0/SWCLK",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "49",
          "netId": "power_net_86751620b7fb",
          "name": "PC9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "3",
          "netId": "control_net_5a73b1e1ccba",
          "name": "Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "6",
          "netId": "control_net_1a607d7041f2",
          "name": "CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J101",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Включение основного контроллера",
      "text": "Становятся доступны питание основного контроллера и приёмники сигналов состояния.",
      "body": "Становятся доступны питание основного контроллера и приёмники сигналов состояния.",
      "nodes": [
        "power",
        "mcu"
      ],
      "edges": [
        "power_mcu"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_df95db02c560"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Включение ПЛИС",
      "text": "Управляемые цифровые шины питают ПЛИС и домены интерфейсов.",
      "body": "Управляемые цифровые шины питают ПЛИС и домены интерфейсов.",
      "nodes": [
        "power",
        "fpga"
      ],
      "edges": [
        "power_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U8",
          "netId": "control_net_6f005443ad9c",
          "name": "CFGBVS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U11",
          "netId": "control_net_6f005443ad9c",
          "name": "M0_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подготовка аналоговых узлов",
      "text": "Аналоговые шины питают прецизионные источники и измерительный тракт.",
      "body": "Аналоговые шины питают прецизионные источники и измерительный тракт.",
      "nodes": [
        "power",
        "drive",
        "readout"
      ],
      "edges": [
        "power_drive"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_b4fd0f4101eb",
        "control_net_a05784e4a1d3",
        "control_net_2e82cb98585d",
        "control_net_e5381212c338"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1000",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2003",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2003",
          "pin": "7",
          "netId": "control_net_b4fd0f4101eb",
          "name": "PD",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "7",
          "netId": "control_net_2e82cb98585d",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2101",
          "pin": "7",
          "netId": "control_net_2e82cb98585d",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2101",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность к эксперименту",
      "text": "Для начала операции одновременно нужны программная готовность и аппаратные разрешения.",
      "body": "Для начала операции одновременно нужны программная готовность и аппаратные разрешения.",
      "nodes": [
        "mcu",
        "fpga",
        "safety",
        "matrix"
      ],
      "edges": [
        "mcu_fpga",
        "fpga_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a",
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Подключение источника",
      "text": "Питание поступает во входную защиту платы Power.",
      "body": "Питание поступает во входную защиту платы Power.",
      "nodes": [
        "supply",
        "power"
      ],
      "edges": [
        "supply_power"
      ],
      "sceneId": "system",
      "netIds": [
        "power_net_6741c8732f40"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J101",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запуск контроля питания",
      "text": "Дежурное питание позволяет контроллеру питания проверить условия перед разрешением остальных запросов.",
      "body": "Дежурное питание позволяет контроллеру питания проверить условия перед разрешением остальных запросов.",
      "nodes": [
        "power",
        "safety"
      ],
      "edges": [],
      "sceneId": "system",
      "netIds": [
        "power_net_3937c8c839ac",
        "power_net_3dcac14084cf",
        "power_net_0118a5d9fdb8",
        "power_net_e5a2750417c1",
        "power_net_ebbb4413206b",
        "power_net_212cb9d210a9",
        "power_net_4debf317f2c4",
        "power_net_4277075bbc34",
        "power_net_cc22b913a226",
        "power_net_9517f7952aef",
        "power_net_fc607675ab2d",
        "power_net_35045b6a457d",
        "power_net_cd4425540176",
        "power_net_c9b6c7228333",
        "power_net_a837894762cd",
        "power_net_9ab95937734d",
        "power_net_cfb766cbb94f",
        "power_net_47f67f61993c",
        "power_net_15b0cf67917c",
        "power_net_9389f5dbe1a6",
        "power_net_67006db669b3",
        "power_net_f4716909bd0c",
        "power_net_3f4e1d0f28d6",
        "power_net_2cbf74589b12",
        "power_net_6ad422db16ac",
        "power_net_6d982403b080",
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_393e02135991",
        "power_net_f632ebdd7344",
        "power_net_e5822cf03a94",
        "power_net_4d93f44a0a86",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a",
        "power_net_36bf51cd4ad6",
        "power_net_ccf5ee78cf75",
        "power_net_4aeb4892b398",
        "power_net_25cd945f19a1",
        "power_net_a250a8b7fe30",
        "power_net_8828c890966d",
        "power_net_5a1f578d112a",
        "power_net_86751620b7fb",
        "power_net_ae3b1a85f32f",
        "power_net_cfa48b7bd3ef",
        "power_net_2965499926c8",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ed26aaa81531",
        "power_net_ac83bbc60cc7",
        "power_net_0ee4f5245d75",
        "power_net_99aaef80128f",
        "power_net_e1dd2bfabf3b",
        "control_net_9269f101a22a",
        "control_net_6f005443ad9c",
        "control_net_5a73b1e1ccba",
        "control_net_d44a94d9b4fd",
        "control_net_1a607d7041f2",
        "control_net_7b06e5d6a4d9",
        "control_net_2d2627aeff69",
        "control_net_720010c527b5",
        "power_net_0d67fdbc5a0d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_bc6b8848cad9",
        "power_net_6741c8732f40"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U301",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "3",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "5",
          "netId": "power_net_0118a5d9fdb8",
          "name": "DRV",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "6",
          "netId": "power_net_e5a2750417c1",
          "name": "IN_SYS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "7",
          "netId": "power_net_ebbb4413206b",
          "name": "UVLO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "8",
          "netId": "power_net_212cb9d210a9",
          "name": "OVP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "10",
          "netId": "power_net_4debf317f2c4",
          "name": "dVdT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "11",
          "netId": "power_net_4277075bbc34",
          "name": "ILIM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "12",
          "netId": "power_net_cc22b913a226",
          "name": "MODE",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "13",
          "netId": "power_net_9517f7952aef",
          "name": "SHDN_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "14",
          "netId": "power_net_fc607675ab2d",
          "name": "IMON",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "15",
          "netId": "power_net_35045b6a457d",
          "name": "FLT_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "43",
          "netId": "power_net_35045b6a457d",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "16",
          "netId": "power_net_cd4425540176",
          "name": "PGTH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "17",
          "netId": "power_net_c9b6c7228333",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "42",
          "netId": "power_net_c9b6c7228333",
          "name": "PA10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "18",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "19",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "20",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "PC11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "2",
          "netId": "power_net_cfb766cbb94f",
          "name": "PC12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "4",
          "netId": "power_net_15b0cf67917c",
          "name": "PC14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "5",
          "netId": "power_net_9389f5dbe1a6",
          "name": "PC15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "10",
          "netId": "power_net_f4716909bd0c",
          "name": "PF0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "11",
          "netId": "power_net_3f4e1d0f28d6",
          "name": "PF1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "13",
          "netId": "power_net_6ad422db16ac",
          "name": "PC0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "14",
          "netId": "power_net_6d982403b080",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "15",
          "netId": "power_net_55a52205aaf0",
          "name": "PC2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "16",
          "netId": "power_net_47577a24d67e",
          "name": "PC3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "17",
          "netId": "power_net_393e02135991",
          "name": "PA0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "18",
          "netId": "power_net_f632ebdd7344",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "19",
          "netId": "power_net_e5822cf03a94",
          "name": "PA2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "20",
          "netId": "power_net_4d93f44a0a86",
          "name": "PA3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "21",
          "netId": "power_net_c19f5798f458",
          "name": "PA4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "22",
          "netId": "power_net_c66ec173184e",
          "name": "PA5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "23",
          "netId": "power_net_83fb386e92c5",
          "name": "PA6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "24",
          "netId": "power_net_c876bbd15aa2",
          "name": "PA7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "25",
          "netId": "power_net_5a10e16f7ce2",
          "name": "PC4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "26",
          "netId": "power_net_1f6f0734f873",
          "name": "PC5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "27",
          "netId": "power_net_afa5c4d57041",
          "name": "PB0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "28",
          "netId": "power_net_d1fe7a20e661",
          "name": "PB1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "29",
          "netId": "power_net_1b4ac01010f8",
          "name": "PB2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "30",
          "netId": "power_net_5dc0cb853f29",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "31",
          "netId": "power_net_69d4e38b1bd0",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "32",
          "netId": "power_net_2c93a597633f",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "33",
          "netId": "power_net_12bae3231aaa",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "34",
          "netId": "power_net_b527a6b82695",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "35",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "36",
          "netId": "power_net_97db96dcc04b",
          "name": "PA8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "37",
          "netId": "power_net_2074a83eb788",
          "name": "PA9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "38",
          "netId": "power_net_7071622db9df",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "39",
          "netId": "power_net_b5187ab6f19a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "40",
          "netId": "power_net_36bf51cd4ad6",
          "name": "PD8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "41",
          "netId": "power_net_ccf5ee78cf75",
          "name": "PD9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "45",
          "netId": "power_net_25cd945f19a1",
          "name": "PA13/SWDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "46",
          "netId": "power_net_a250a8b7fe30",
          "name": "PA14/BOOT0/SWCLK",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "49",
          "netId": "power_net_86751620b7fb",
          "name": "PC9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "3",
          "netId": "control_net_5a73b1e1ccba",
          "name": "Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "6",
          "netId": "control_net_1a607d7041f2",
          "name": "CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J101",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Включение основного контроллера",
      "text": "Становятся доступны питание основного контроллера и приёмники сигналов состояния.",
      "body": "Становятся доступны питание основного контроллера и приёмники сигналов состояния.",
      "nodes": [
        "power",
        "mcu"
      ],
      "edges": [
        "power_mcu"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_df95db02c560"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Включение ПЛИС",
      "text": "Управляемые цифровые шины питают ПЛИС и домены интерфейсов.",
      "body": "Управляемые цифровые шины питают ПЛИС и домены интерфейсов.",
      "nodes": [
        "power",
        "fpga"
      ],
      "edges": [
        "power_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U8",
          "netId": "control_net_6f005443ad9c",
          "name": "CFGBVS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U11",
          "netId": "control_net_6f005443ad9c",
          "name": "M0_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подготовка аналоговых узлов",
      "text": "Аналоговые шины питают прецизионные источники и измерительный тракт.",
      "body": "Аналоговые шины питают прецизионные источники и измерительный тракт.",
      "nodes": [
        "power",
        "drive",
        "readout"
      ],
      "edges": [
        "power_drive"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_b4fd0f4101eb",
        "control_net_a05784e4a1d3",
        "control_net_2e82cb98585d",
        "control_net_e5381212c338"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1000",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2003",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VS+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2003",
          "pin": "7",
          "netId": "control_net_b4fd0f4101eb",
          "name": "PD",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "7",
          "netId": "control_net_2e82cb98585d",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2101",
          "pin": "7",
          "netId": "control_net_2e82cb98585d",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "5",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2101",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность к эксперименту",
      "text": "Для начала операции одновременно нужны программная готовность и аппаратные разрешения.",
      "body": "Для начала операции одновременно нужны программная готовность и аппаратные разрешения.",
      "nodes": [
        "mcu",
        "fpga",
        "safety",
        "matrix"
      ],
      "edges": [
        "mcu_fpga",
        "fpga_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a",
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
