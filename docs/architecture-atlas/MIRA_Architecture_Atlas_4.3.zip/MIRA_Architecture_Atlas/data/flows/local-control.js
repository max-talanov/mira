/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control",
  "title": "Как работает: Плата Control · от команды до измерения",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control",
  "steps": [
    {
      "title": "Плата получает питание и разрешения",
      "text": "На границу Control приходят шины питания и сигналы аппаратного разрешения. Хост и ПЛИС выполняют разные задачи управления.",
      "body": "На границу Control приходят шины питания и сигналы аппаратного разрешения. Хост и ПЛИС выполняют разные задачи управления.",
      "nodes": [
        "boundary",
        "host",
        "fpga"
      ],
      "edges": [
        "boundary_host",
        "host_fpga"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_cb711dcd1752",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VTREF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "3V3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "ENABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "9",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "27",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "43",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "49",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "11",
          "netId": "control_net_cb711dcd1752",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "3",
          "netId": "control_net_df95db02c560",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "6",
          "netId": "control_net_7f8e95e35104",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "8",
          "netId": "control_net_9edec24f88a2",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Формируются аналоговые команды",
      "text": "ПЛИС передаёт цифровые уставки; ЦАП формируют напряжения, а общий источник регулирует программирующий тракт.",
      "body": "ПЛИС передаёт цифровые уставки; ЦАП формируют напряжения, а общий источник регулирует программирующий тракт.",
      "nodes": [
        "fpga",
        "sources",
        "regulation"
      ],
      "edges": [
        "fpga_sources",
        "sources_regulation"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_cac6d1065fe3",
        "control_net_03d282e4ab71",
        "control_net_992a28f1c452",
        "control_net_ca37f2f49804",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_a6fb2d1ff68e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "5",
          "netId": "control_net_fd8710ab620d",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигнал идёт через выбранную матрицу",
      "text": "Удерживаемый образ коммутации выбирает маршрут аналогового сигнала через матрицу. Необходимые разрешения действуют независимо от команды.",
      "body": "Удерживаемый образ коммутации выбирает маршрут аналогового сигнала через матрицу. Необходимые разрешения действуют независимо от команды.",
      "nodes": [
        "sources",
        "regulation",
        "routing"
      ],
      "edges": [
        "sources_routing",
        "sources_regulation",
        "regulation_routing"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40",
        "control_net_cac6d1065fe3",
        "control_net_03d282e4ab71",
        "control_net_992a28f1c452",
        "control_net_ca37f2f49804",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_a6fb2d1ff68e",
        "control_net_1d431849abfd",
        "control_net_87568f65b103",
        "control_net_c52050ba11fe",
        "control_net_55226bb23b92",
        "control_net_f0958a0c0c7d",
        "control_net_38a99a3de8c7",
        "control_net_cfdd109d7d0d",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_1c11014d6a17",
        "control_net_a752af94ed43"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "1",
          "netId": "control_net_87568f65b103",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "8",
          "netId": "control_net_55226bb23b92",
          "name": "DA",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "1",
          "netId": "control_net_38a99a3de8c7",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2108",
          "pin": "4",
          "netId": "control_net_cfdd109d7d0d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "4",
          "netId": "control_net_5b5c009b1508",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "7",
          "netId": "control_net_5b5c009b1508",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "6",
          "netId": "control_net_81a816b03060",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Ответ превращается в отсчёты",
      "text": "Измерительный тракт преобразует ток в напряжение и цифровые отсчёты для ПЛИС. Аппаратная защита наблюдает собственные аварийные условия.",
      "body": "Измерительный тракт преобразует ток в напряжение и цифровые отсчёты для ПЛИС. Аппаратная защита наблюдает собственные аварийные условия.",
      "nodes": [
        "routing",
        "readout",
        "fpga",
        "safety"
      ],
      "edges": [
        "fpga_routing",
        "routing_readout",
        "readout_fpga",
        "safety_routing"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_f05b5740e1a9",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_c4621dfd0ac4",
        "control_net_d65f00f0a2d4",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98",
        "control_net_6e0242cad116",
        "control_net_d4a1fffbf6b9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1306",
          "pin": "2",
          "netId": "control_net_30006651dbc3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1312",
          "pin": "2",
          "netId": "control_net_889281b6cc29",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1315",
          "pin": "1",
          "netId": "control_net_889281b6cc29",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1313",
          "pin": "2",
          "netId": "control_net_429d3a1721ef",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E3",
          "netId": "control_net_2690ba9f85c2",
          "name": "IO_L6N_T0_VREF_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F1",
          "netId": "control_net_1060da4e1062",
          "name": "IO_L5N_T0_AD13N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F3",
          "netId": "control_net_8e945f7df341",
          "name": "IO_L6P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G1",
          "netId": "control_net_103f84ec6132",
          "name": "IO_L5P_T0_AD13P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G2",
          "netId": "control_net_c6ecade8f839",
          "name": "IO_L8N_T1_AD14N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G3",
          "netId": "control_net_8e9184bc5c46",
          "name": "IO_L11N_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H2",
          "netId": "control_net_ba2ab40384c6",
          "name": "IO_L8P_T1_AD14P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H4",
          "netId": "control_net_c254fca78b2c",
          "name": "IO_L12P_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J1",
          "netId": "control_net_f16f12a0707d",
          "name": "IO_L7N_T1_AD6N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J2",
          "netId": "control_net_d095506d8145",
          "name": "IO_L9N_T1_DQS_AD7N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J5",
          "netId": "control_net_df16aaaa5404",
          "name": "IO_L10P_T1_AD15P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K1",
          "netId": "control_net_2a00cc654f3d",
          "name": "IO_L7P_T1_AD6P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K2",
          "netId": "control_net_5130997c4fe8",
          "name": "IO_L9P_T1_DQS_AD7P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1901",
          "pin": "8",
          "netId": "control_net_d65f00f0a2d4",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J6",
          "netId": "control_net_6e0242cad116",
          "name": "IO_L17N_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "2",
          "netId": "control_net_d4a1fffbf6b9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Плата получает питание и разрешения",
      "text": "На границу Control приходят шины питания и сигналы аппаратного разрешения. Хост и ПЛИС выполняют разные задачи управления.",
      "body": "На границу Control приходят шины питания и сигналы аппаратного разрешения. Хост и ПЛИС выполняют разные задачи управления.",
      "nodes": [
        "boundary",
        "host",
        "fpga"
      ],
      "edges": [
        "boundary_host",
        "host_fpga"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_90c4fa851afd",
        "control_net_cb711dcd1752",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VTREF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "3V3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "ENABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "9",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "27",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "43",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "49",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDQ",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "4",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U302",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U301",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "VBUS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "46",
          "netId": "control_net_cb711dcd1752",
          "name": "PA3_/_PM_UART_TX_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "11",
          "netId": "control_net_cb711dcd1752",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "127",
          "netId": "control_net_df95db02c560",
          "name": "PA8_/_ALL_RAILS_PG_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "3",
          "netId": "control_net_df95db02c560",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "128",
          "netId": "control_net_7f8e95e35104",
          "name": "PA9_/_GLOBAL_PWR_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "6",
          "netId": "control_net_7f8e95e35104",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "129",
          "netId": "control_net_9edec24f88a2",
          "name": "PA10_/_MATRIX_PERMIT_HOST",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "8",
          "netId": "control_net_9edec24f88a2",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "122",
          "netId": "control_net_e7c041fd6c4f",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "123",
          "netId": "control_net_f9eaf352353a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Формируются аналоговые команды",
      "text": "ПЛИС передаёт цифровые уставки; ЦАП формируют напряжения, а общий источник регулирует программирующий тракт.",
      "body": "ПЛИС передаёт цифровые уставки; ЦАП формируют напряжения, а общий источник регулирует программирующий тракт.",
      "nodes": [
        "fpga",
        "sources",
        "regulation"
      ],
      "edges": [
        "fpga_sources",
        "sources_regulation"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_cac6d1065fe3",
        "control_net_03d282e4ab71",
        "control_net_992a28f1c452",
        "control_net_ca37f2f49804",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_a6fb2d1ff68e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "5",
          "netId": "control_net_fd8710ab620d",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигнал идёт через выбранную матрицу",
      "text": "Удерживаемый образ коммутации выбирает маршрут аналогового сигнала через матрицу. Необходимые разрешения действуют независимо от команды.",
      "body": "Удерживаемый образ коммутации выбирает маршрут аналогового сигнала через матрицу. Необходимые разрешения действуют независимо от команды.",
      "nodes": [
        "sources",
        "regulation",
        "routing"
      ],
      "edges": [
        "sources_routing",
        "sources_regulation",
        "regulation_routing"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40",
        "control_net_cac6d1065fe3",
        "control_net_03d282e4ab71",
        "control_net_992a28f1c452",
        "control_net_ca37f2f49804",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_a6fb2d1ff68e",
        "control_net_1d431849abfd",
        "control_net_87568f65b103",
        "control_net_c52050ba11fe",
        "control_net_55226bb23b92",
        "control_net_f0958a0c0c7d",
        "control_net_38a99a3de8c7",
        "control_net_cfdd109d7d0d",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_1c11014d6a17",
        "control_net_a752af94ed43"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "1",
          "netId": "control_net_87568f65b103",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "8",
          "netId": "control_net_55226bb23b92",
          "name": "DA",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "1",
          "netId": "control_net_38a99a3de8c7",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2108",
          "pin": "4",
          "netId": "control_net_cfdd109d7d0d",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "4",
          "netId": "control_net_5b5c009b1508",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "7",
          "netId": "control_net_5b5c009b1508",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "6",
          "netId": "control_net_81a816b03060",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Ответ превращается в отсчёты",
      "text": "Измерительный тракт преобразует ток в напряжение и цифровые отсчёты для ПЛИС. Аппаратная защита наблюдает собственные аварийные условия.",
      "body": "Измерительный тракт преобразует ток в напряжение и цифровые отсчёты для ПЛИС. Аппаратная защита наблюдает собственные аварийные условия.",
      "nodes": [
        "routing",
        "readout",
        "fpga",
        "safety"
      ],
      "edges": [
        "fpga_routing",
        "routing_readout",
        "readout_fpga",
        "safety_routing"
      ],
      "sceneId": "control",
      "netIds": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_f05b5740e1a9",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_c4621dfd0ac4",
        "control_net_d65f00f0a2d4",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98",
        "control_net_6e0242cad116",
        "control_net_d4a1fffbf6b9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1306",
          "pin": "2",
          "netId": "control_net_30006651dbc3",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1312",
          "pin": "2",
          "netId": "control_net_889281b6cc29",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1315",
          "pin": "1",
          "netId": "control_net_889281b6cc29",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1313",
          "pin": "2",
          "netId": "control_net_429d3a1721ef",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E3",
          "netId": "control_net_2690ba9f85c2",
          "name": "IO_L6N_T0_VREF_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F1",
          "netId": "control_net_1060da4e1062",
          "name": "IO_L5N_T0_AD13N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F3",
          "netId": "control_net_8e945f7df341",
          "name": "IO_L6P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G1",
          "netId": "control_net_103f84ec6132",
          "name": "IO_L5P_T0_AD13P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G2",
          "netId": "control_net_c6ecade8f839",
          "name": "IO_L8N_T1_AD14N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G3",
          "netId": "control_net_8e9184bc5c46",
          "name": "IO_L11N_T1_SRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H2",
          "netId": "control_net_ba2ab40384c6",
          "name": "IO_L8P_T1_AD14P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H4",
          "netId": "control_net_c254fca78b2c",
          "name": "IO_L12P_T1_MRCC_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J1",
          "netId": "control_net_f16f12a0707d",
          "name": "IO_L7N_T1_AD6N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J2",
          "netId": "control_net_d095506d8145",
          "name": "IO_L9N_T1_DQS_AD7N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J5",
          "netId": "control_net_df16aaaa5404",
          "name": "IO_L10P_T1_AD15P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K1",
          "netId": "control_net_2a00cc654f3d",
          "name": "IO_L7P_T1_AD6P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K2",
          "netId": "control_net_5130997c4fe8",
          "name": "IO_L9P_T1_DQS_AD7P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1901",
          "pin": "8",
          "netId": "control_net_d65f00f0a2d4",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J6",
          "netId": "control_net_6e0242cad116",
          "name": "IO_L17N_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "2",
          "netId": "control_net_d4a1fffbf6b9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
