/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3800_MONITOR_DDR_PHY_ANALOG",
  "title": "Как работает: Контроль памяти, PHY и аналоговых шин",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
  "steps": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "ddr"
      ],
      "edges": [],
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "netIds": [
        "power_net_be09322b9714",
        "power_net_071bab851593",
        "power_net_2f3224d5b90a",
        "power_net_10da23b002c4",
        "power_net_f3a748e4fa19",
        "power_net_67006db669b3",
        "power_net_4aeb4892b398",
        "power_net_978b64498138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3801",
          "pin": "3",
          "netId": "power_net_be09322b9714",
          "name": "LIMIT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3805",
          "pin": "1",
          "netId": "power_net_be09322b9714",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3801",
          "pin": "1",
          "netId": "power_net_071bab851593",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3801",
          "pin": "1",
          "netId": "power_net_071bab851593",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3802",
          "pin": "1",
          "netId": "power_net_071bab851593",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3801",
          "pin": "3",
          "netId": "power_net_071bab851593",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3805",
          "pin": "1",
          "netId": "power_net_2f3224d5b90a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3807",
          "pin": "1",
          "netId": "power_net_2f3224d5b90a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3807",
          "pin": "2",
          "netId": "power_net_10da23b002c4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "2",
          "netId": "power_net_10da23b002c4",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3801",
          "pin": "2",
          "netId": "power_net_f3a748e4fa19",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "7",
          "netId": "power_net_f3a748e4fa19",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3803",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3801",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "8",
          "netId": "power_net_978b64498138",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "ddr",
        "ana5",
        "phy",
        "ana33"
      ],
      "edges": [
        "ddr_ana5",
        "ddr_phy",
        "ddr_ana33",
        "ana5_phy",
        "ana5_ana33",
        "phy_ana33"
      ],
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3802",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3804",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3803",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "ddr",
        "ana5",
        "phy",
        "ana33"
      ],
      "edges": [
        "ddr_ana5",
        "ddr_phy",
        "ddr_ana33",
        "ana5_phy",
        "ana5_ana33",
        "phy_ana33"
      ],
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3802",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3804",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3803",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "ddr"
      ],
      "edges": [],
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "netIds": [
        "power_net_be09322b9714",
        "power_net_071bab851593",
        "power_net_2f3224d5b90a",
        "power_net_10da23b002c4",
        "power_net_f3a748e4fa19",
        "power_net_67006db669b3",
        "power_net_4aeb4892b398",
        "power_net_978b64498138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3801",
          "pin": "3",
          "netId": "power_net_be09322b9714",
          "name": "LIMIT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3805",
          "pin": "1",
          "netId": "power_net_be09322b9714",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3801",
          "pin": "1",
          "netId": "power_net_071bab851593",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3801",
          "pin": "1",
          "netId": "power_net_071bab851593",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3802",
          "pin": "1",
          "netId": "power_net_071bab851593",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3801",
          "pin": "3",
          "netId": "power_net_071bab851593",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3805",
          "pin": "1",
          "netId": "power_net_2f3224d5b90a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3807",
          "pin": "1",
          "netId": "power_net_2f3224d5b90a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3807",
          "pin": "2",
          "netId": "power_net_10da23b002c4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "2",
          "netId": "power_net_10da23b002c4",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3801",
          "pin": "2",
          "netId": "power_net_f3a748e4fa19",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "7",
          "netId": "power_net_f3a748e4fa19",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3803",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3801",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "8",
          "netId": "power_net_978b64498138",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "ddr",
        "ana5",
        "phy",
        "ana33"
      ],
      "edges": [
        "ddr_ana5",
        "ddr_phy",
        "ddr_ana33",
        "ana5_phy",
        "ana5_ana33",
        "phy_ana33"
      ],
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3802",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3804",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3803",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "ddr",
        "ana5",
        "phy",
        "ana33"
      ],
      "edges": [
        "ddr_ana5",
        "ddr_phy",
        "ddr_ana33",
        "ana5_phy",
        "ana5_ana33",
        "phy_ana33"
      ],
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3802",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3804",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3801",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3803",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
