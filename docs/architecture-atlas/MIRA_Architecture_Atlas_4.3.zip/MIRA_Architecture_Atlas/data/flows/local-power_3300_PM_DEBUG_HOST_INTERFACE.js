/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3300_PM_DEBUG_HOST_INTERFACE",
  "title": "Как работает: Связь контроллера питания с основным",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
  "steps": [
    {
      "title": "Хост соединяется с диспетчером питания",
      "text": "Разъём хоста переносит UART, признаки активности и статусы между управляющими доменами.",
      "body": "Разъём хоста переносит UART, признаки активности и статусы между управляющими доменами.",
      "nodes": [
        "host"
      ],
      "edges": [],
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "netIds": [
        "power_net_51118e9c1062",
        "power_net_ccf5ee78cf75",
        "power_net_e7486b382586",
        "power_net_9426b571f348",
        "power_net_0418bd5d299f",
        "power_net_89bfaea42e83",
        "power_net_be4d01cedfad",
        "power_net_65bf7e1e53cf"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3305",
          "pin": "1",
          "netId": "power_net_51118e9c1062",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "4",
          "netId": "power_net_51118e9c1062",
          "name": "Pin_4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3305",
          "pin": "2",
          "netId": "power_net_ccf5ee78cf75",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "1",
          "netId": "power_net_e7486b382586",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "3",
          "netId": "power_net_9426b571f348",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "5",
          "netId": "power_net_0418bd5d299f",
          "name": "Pin_5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "6",
          "netId": "power_net_89bfaea42e83",
          "name": "Pin_6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "7",
          "netId": "power_net_be4d01cedfad",
          "name": "Pin_7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "8",
          "netId": "power_net_65bf7e1e53cf",
          "name": "Pin_8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигналы переходят границу питания",
      "text": "Буфер с поддержкой Ioff обслуживает показанные сигналы между доменами. Это помогает разделять их при отключении одной из сторон.",
      "body": "Буфер с поддержкой Ioff обслуживает показанные сигналы между доменами. Это помогает разделять их при отключении одной из сторон.",
      "nodes": [
        "host",
        "isolate"
      ],
      "edges": [
        "host_isolate"
      ],
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "netIds": [
        "power_net_9426b571f348",
        "power_net_89bfaea42e83",
        "power_net_be4d01cedfad",
        "power_net_65bf7e1e53cf"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J3302",
          "pin": "3",
          "netId": "power_net_9426b571f348",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "3",
          "netId": "power_net_9426b571f348",
          "name": "1Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "6",
          "netId": "power_net_89bfaea42e83",
          "name": "Pin_6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "6",
          "netId": "power_net_89bfaea42e83",
          "name": "2Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "7",
          "netId": "power_net_be4d01cedfad",
          "name": "Pin_7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "8",
          "netId": "power_net_be4d01cedfad",
          "name": "3Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "8",
          "netId": "power_net_65bf7e1e53cf",
          "name": "Pin_8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "11",
          "netId": "power_net_65bf7e1e53cf",
          "name": "4Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Диспетчер доступен программатору",
      "text": "Разъём SWD предоставляет отдельный путь программирования и отладки STM32G0. Он не используется как обычный канал телеметрии хоста.",
      "body": "Разъём SWD предоставляет отдельный путь программирования и отладки STM32G0. Он не используется как обычный канал телеметрии хоста.",
      "nodes": [
        "debug"
      ],
      "edges": [],
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "netIds": [
        "power_net_25cd945f19a1",
        "power_net_91efcfd49f40",
        "power_net_67006db669b3",
        "power_net_e1fb36f43732",
        "power_net_2cbf74589b12",
        "power_net_a250a8b7fe30",
        "power_net_ccf5ee78cf75"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3301",
          "pin": "1",
          "netId": "power_net_25cd945f19a1",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3301",
          "pin": "2",
          "netId": "power_net_91efcfd49f40",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "3",
          "netId": "power_net_91efcfd49f40",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "4",
          "netId": "power_net_e1fb36f43732",
          "name": "Pin_4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3302",
          "pin": "2",
          "netId": "power_net_e1fb36f43732",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "5",
          "netId": "power_net_2cbf74589b12",
          "name": "Pin_5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3302",
          "pin": "1",
          "netId": "power_net_a250a8b7fe30",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3303",
          "pin": "1",
          "netId": "power_net_a250a8b7fe30",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3306",
          "pin": "1",
          "netId": "power_net_ccf5ee78cf75",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Хост соединяется с диспетчером питания",
      "text": "Разъём хоста переносит UART, признаки активности и статусы между управляющими доменами.",
      "body": "Разъём хоста переносит UART, признаки активности и статусы между управляющими доменами.",
      "nodes": [
        "host"
      ],
      "edges": [],
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "netIds": [
        "power_net_51118e9c1062",
        "power_net_ccf5ee78cf75",
        "power_net_e7486b382586",
        "power_net_9426b571f348",
        "power_net_0418bd5d299f",
        "power_net_89bfaea42e83",
        "power_net_be4d01cedfad",
        "power_net_65bf7e1e53cf"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3305",
          "pin": "1",
          "netId": "power_net_51118e9c1062",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "4",
          "netId": "power_net_51118e9c1062",
          "name": "Pin_4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3305",
          "pin": "2",
          "netId": "power_net_ccf5ee78cf75",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "1",
          "netId": "power_net_e7486b382586",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "3",
          "netId": "power_net_9426b571f348",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "5",
          "netId": "power_net_0418bd5d299f",
          "name": "Pin_5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "6",
          "netId": "power_net_89bfaea42e83",
          "name": "Pin_6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "7",
          "netId": "power_net_be4d01cedfad",
          "name": "Pin_7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "8",
          "netId": "power_net_65bf7e1e53cf",
          "name": "Pin_8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигналы переходят границу питания",
      "text": "Буфер с поддержкой Ioff обслуживает показанные сигналы между доменами. Это помогает разделять их при отключении одной из сторон.",
      "body": "Буфер с поддержкой Ioff обслуживает показанные сигналы между доменами. Это помогает разделять их при отключении одной из сторон.",
      "nodes": [
        "host",
        "isolate"
      ],
      "edges": [
        "host_isolate"
      ],
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "netIds": [
        "power_net_9426b571f348",
        "power_net_89bfaea42e83",
        "power_net_be4d01cedfad",
        "power_net_65bf7e1e53cf"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J3302",
          "pin": "3",
          "netId": "power_net_9426b571f348",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "3",
          "netId": "power_net_9426b571f348",
          "name": "1Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "6",
          "netId": "power_net_89bfaea42e83",
          "name": "Pin_6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "6",
          "netId": "power_net_89bfaea42e83",
          "name": "2Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "7",
          "netId": "power_net_be4d01cedfad",
          "name": "Pin_7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "8",
          "netId": "power_net_be4d01cedfad",
          "name": "3Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3302",
          "pin": "8",
          "netId": "power_net_65bf7e1e53cf",
          "name": "Pin_8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "11",
          "netId": "power_net_65bf7e1e53cf",
          "name": "4Y",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Диспетчер доступен программатору",
      "text": "Разъём SWD предоставляет отдельный путь программирования и отладки STM32G0. Он не используется как обычный канал телеметрии хоста.",
      "body": "Разъём SWD предоставляет отдельный путь программирования и отладки STM32G0. Он не используется как обычный канал телеметрии хоста.",
      "nodes": [
        "debug"
      ],
      "edges": [],
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "netIds": [
        "power_net_25cd945f19a1",
        "power_net_91efcfd49f40",
        "power_net_67006db669b3",
        "power_net_e1fb36f43732",
        "power_net_2cbf74589b12",
        "power_net_a250a8b7fe30",
        "power_net_ccf5ee78cf75"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3301",
          "pin": "1",
          "netId": "power_net_25cd945f19a1",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3301",
          "pin": "2",
          "netId": "power_net_91efcfd49f40",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "3",
          "netId": "power_net_91efcfd49f40",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "4",
          "netId": "power_net_e1fb36f43732",
          "name": "Pin_4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3302",
          "pin": "2",
          "netId": "power_net_e1fb36f43732",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "5",
          "netId": "power_net_2cbf74589b12",
          "name": "Pin_5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3302",
          "pin": "1",
          "netId": "power_net_a250a8b7fe30",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3303",
          "pin": "1",
          "netId": "power_net_a250a8b7fe30",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3306",
          "pin": "1",
          "netId": "power_net_ccf5ee78cf75",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
