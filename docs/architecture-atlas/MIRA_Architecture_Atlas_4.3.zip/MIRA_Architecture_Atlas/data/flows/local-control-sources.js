/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control-sources",
  "title": "Как работает: Формирование аналоговых уставок",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control-sources",
  "steps": [
    {
      "title": "32 напряжения битовых линий",
      "text": "Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "body": "Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "nodes": [
        "sheet1000",
        "sheet1200"
      ],
      "edges": [
        "sheet1000_sheet1200"
      ],
      "sceneId": "control-sources",
      "netIds": [
        "control_net_90accaec6322",
        "control_net_8543c7028353",
        "control_net_7f616706cf93",
        "control_net_fd8710ab620d",
        "control_net_a2017f4fe37b",
        "control_net_bae01a82acc2",
        "control_net_2889fbee2814",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Уставки READ, WRITE и FORMING",
      "text": "U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING. Связь с соседним узлом показана цепями DAC_SPI_MOSI, DAC_RESET_N, CS_HV, HV_ALERT_N.",
      "body": "U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING. Связь с соседним узлом показана цепями DAC_SPI_MOSI, DAC_RESET_N, CS_HV, HV_ALERT_N.",
      "nodes": [
        "sheet1100",
        "sheet1200"
      ],
      "edges": [
        "sheet1100_sheet1200"
      ],
      "sceneId": "control-sources",
      "netIds": [
        "control_net_7f616706cf93",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_fe5724fe2bab",
        "control_net_2889fbee2814",
        "control_net_168076ddc771",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "12",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "3",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "13",
          "netId": "control_net_596ada6680f2",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "1",
          "netId": "control_net_fe5724fe2bab",
          "name": "ALERT_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U3",
          "netId": "control_net_fe5724fe2bab",
          "name": "IO_L6P_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "10",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "2",
          "netId": "control_net_168076ddc771",
          "name": "CLEAR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V3",
          "netId": "control_net_168076ddc771",
          "name": "IO_L6N_T0_VREF_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "14",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "11",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "5",
          "netId": "control_net_fad82bf41bcf",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Управление аналоговыми источниками",
      "text": "Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "body": "Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "nodes": [
        "sheet1200",
        "sheet1000"
      ],
      "edges": [
        "sheet1000_sheet1200"
      ],
      "sceneId": "control-sources",
      "netIds": [
        "control_net_90accaec6322",
        "control_net_8543c7028353",
        "control_net_7f616706cf93",
        "control_net_fd8710ab620d",
        "control_net_a2017f4fe37b",
        "control_net_bae01a82acc2",
        "control_net_2889fbee2814",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "32 напряжения битовых линий",
      "text": "Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "body": "Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "nodes": [
        "sheet1000",
        "sheet1200"
      ],
      "edges": [
        "sheet1000_sheet1200"
      ],
      "sceneId": "control-sources",
      "netIds": [
        "control_net_90accaec6322",
        "control_net_8543c7028353",
        "control_net_7f616706cf93",
        "control_net_fd8710ab620d",
        "control_net_a2017f4fe37b",
        "control_net_bae01a82acc2",
        "control_net_2889fbee2814",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Уставки READ, WRITE и FORMING",
      "text": "U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING. Связь с соседним узлом показана цепями DAC_SPI_MOSI, DAC_RESET_N, CS_HV, HV_ALERT_N.",
      "body": "U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING. Связь с соседним узлом показана цепями DAC_SPI_MOSI, DAC_RESET_N, CS_HV, HV_ALERT_N.",
      "nodes": [
        "sheet1100",
        "sheet1200"
      ],
      "edges": [
        "sheet1100_sheet1200"
      ],
      "sceneId": "control-sources",
      "netIds": [
        "control_net_7f616706cf93",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_fe5724fe2bab",
        "control_net_2889fbee2814",
        "control_net_168076ddc771",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "12",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "3",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "13",
          "netId": "control_net_596ada6680f2",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "1",
          "netId": "control_net_fe5724fe2bab",
          "name": "ALERT_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U3",
          "netId": "control_net_fe5724fe2bab",
          "name": "IO_L6P_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "10",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "2",
          "netId": "control_net_168076ddc771",
          "name": "CLEAR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V3",
          "netId": "control_net_168076ddc771",
          "name": "IO_L6N_T0_VREF_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "14",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "11",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "5",
          "netId": "control_net_fad82bf41bcf",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Управление аналоговыми источниками",
      "text": "Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "body": "Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс. Связь с соседним узлом показана цепями CS_BL0, CS_BL3, DAC_SPI_MOSI, CS_BL2.",
      "nodes": [
        "sheet1200",
        "sheet1000"
      ],
      "edges": [
        "sheet1000_sheet1200"
      ],
      "sceneId": "control-sources",
      "netIds": [
        "control_net_90accaec6322",
        "control_net_8543c7028353",
        "control_net_7f616706cf93",
        "control_net_fd8710ab620d",
        "control_net_a2017f4fe37b",
        "control_net_bae01a82acc2",
        "control_net_2889fbee2814",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
