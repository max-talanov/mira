/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3100_PM_COMMAND_READY",
  "title": "Как работает: Готовность команд включения",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3100_PM_COMMAND_READY",
  "steps": [
    {
      "title": "Приходят команды и условия режима",
      "text": "Этот узел рассматривает готовность запрошенного рабочего режима, используя показанные в схеме управляющие условия.",
      "body": "Этот узел рассматривает готовность запрошенного рабочего режима, используя показанные в схеме управляющие условия.",
      "nodes": [
        "0"
      ],
      "edges": [],
      "sceneId": "power_3100_PM_COMMAND_READY",
      "netIds": [
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_0b769e0e6017",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65",
        "power_net_39d8ddb40bfa",
        "power_net_722d31de17d3",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_470eacd6abf6",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3101",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "2",
          "netId": "power_net_9020238d369a",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "3",
          "netId": "power_net_0b769e0e6017",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "4",
          "netId": "power_net_7f7616523bf4",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "5",
          "netId": "power_net_6220152fdd65",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "6",
          "netId": "power_net_39d8ddb40bfa",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "8",
          "netId": "power_net_722d31de17d3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "9",
          "netId": "power_net_35be90fefcdd",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "10",
          "netId": "power_net_afd79c7e6e58",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "11",
          "netId": "power_net_470eacd6abf6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "12",
          "netId": "power_net_3db57ce8c78a",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "13",
          "netId": "power_net_9693d69e08e6",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3101",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Группы условий объединяются",
      "text": "Аппаратная логика объединяет соответствующие признаки в промежуточные результаты.",
      "body": "Аппаратная логика объединяет соответствующие признаки в промежуточные результаты.",
      "nodes": [
        "0",
        "1"
      ],
      "edges": [],
      "sceneId": "power_3100_PM_COMMAND_READY",
      "netIds": [
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_f70e9d908b4d",
        "power_net_d07b46e16a3e",
        "power_net_05ab23d96f3d",
        "power_net_4053a009016f",
        "power_net_78f1e98d41b3",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_a17d09b057f5",
        "power_net_55bbd3deed41",
        "power_net_67006db669b3",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_0b769e0e6017",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65",
        "power_net_39d8ddb40bfa",
        "power_net_722d31de17d3",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_470eacd6abf6",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3102",
          "pin": "1",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "2",
          "netId": "power_net_04b2f0a4c78b",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "3",
          "netId": "power_net_f70e9d908b4d",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "4",
          "netId": "power_net_d07b46e16a3e",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "5",
          "netId": "power_net_05ab23d96f3d",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "6",
          "netId": "power_net_4053a009016f",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "8",
          "netId": "power_net_78f1e98d41b3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "9",
          "netId": "power_net_ae048a8edaa8",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "10",
          "netId": "power_net_664171b20ecf",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "11",
          "netId": "power_net_a17d09b057f5",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "12",
          "netId": "power_net_55bbd3deed41",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3101",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3102",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "13",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "2",
          "netId": "power_net_9020238d369a",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "3",
          "netId": "power_net_0b769e0e6017",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "4",
          "netId": "power_net_7f7616523bf4",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "5",
          "netId": "power_net_6220152fdd65",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "6",
          "netId": "power_net_39d8ddb40bfa",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "8",
          "netId": "power_net_722d31de17d3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "9",
          "netId": "power_net_35be90fefcdd",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "10",
          "netId": "power_net_afd79c7e6e58",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "11",
          "netId": "power_net_470eacd6abf6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "12",
          "netId": "power_net_3db57ce8c78a",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "13",
          "netId": "power_net_9693d69e08e6",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность режима выходит из узла",
      "text": "Финальный результат продолжает путь к разрешению работы. Командная готовность и фактическая готовность шин имеют разные назначения.",
      "body": "Финальный результат продолжает путь к разрешению работы. Командная готовность и фактическая готовность шин имеют разные назначения.",
      "nodes": [
        "1",
        "2"
      ],
      "edges": [
        "1_2"
      ],
      "sceneId": "power_3100_PM_COMMAND_READY",
      "netIds": [
        "power_net_4053a009016f",
        "power_net_78f1e98d41b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3103",
          "pin": "4",
          "netId": "power_net_4053a009016f",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "6",
          "netId": "power_net_4053a009016f",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3103",
          "pin": "5",
          "netId": "power_net_78f1e98d41b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "8",
          "netId": "power_net_78f1e98d41b3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Приходят команды и условия режима",
      "text": "Этот узел рассматривает готовность запрошенного рабочего режима, используя показанные в схеме управляющие условия.",
      "body": "Этот узел рассматривает готовность запрошенного рабочего режима, используя показанные в схеме управляющие условия.",
      "nodes": [
        "0"
      ],
      "edges": [],
      "sceneId": "power_3100_PM_COMMAND_READY",
      "netIds": [
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_0b769e0e6017",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65",
        "power_net_39d8ddb40bfa",
        "power_net_722d31de17d3",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_470eacd6abf6",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3101",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "2",
          "netId": "power_net_9020238d369a",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "3",
          "netId": "power_net_0b769e0e6017",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "4",
          "netId": "power_net_7f7616523bf4",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "5",
          "netId": "power_net_6220152fdd65",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "6",
          "netId": "power_net_39d8ddb40bfa",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "8",
          "netId": "power_net_722d31de17d3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "9",
          "netId": "power_net_35be90fefcdd",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "10",
          "netId": "power_net_afd79c7e6e58",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "11",
          "netId": "power_net_470eacd6abf6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "12",
          "netId": "power_net_3db57ce8c78a",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "13",
          "netId": "power_net_9693d69e08e6",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3101",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Группы условий объединяются",
      "text": "Аппаратная логика объединяет соответствующие признаки в промежуточные результаты.",
      "body": "Аппаратная логика объединяет соответствующие признаки в промежуточные результаты.",
      "nodes": [
        "0",
        "1"
      ],
      "edges": [],
      "sceneId": "power_3100_PM_COMMAND_READY",
      "netIds": [
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_f70e9d908b4d",
        "power_net_d07b46e16a3e",
        "power_net_05ab23d96f3d",
        "power_net_4053a009016f",
        "power_net_78f1e98d41b3",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_a17d09b057f5",
        "power_net_55bbd3deed41",
        "power_net_67006db669b3",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_0b769e0e6017",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65",
        "power_net_39d8ddb40bfa",
        "power_net_722d31de17d3",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_470eacd6abf6",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3102",
          "pin": "1",
          "netId": "power_net_0faf4b6ebbf5",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "2",
          "netId": "power_net_04b2f0a4c78b",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "3",
          "netId": "power_net_f70e9d908b4d",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "4",
          "netId": "power_net_d07b46e16a3e",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "5",
          "netId": "power_net_05ab23d96f3d",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "6",
          "netId": "power_net_4053a009016f",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "8",
          "netId": "power_net_78f1e98d41b3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "9",
          "netId": "power_net_ae048a8edaa8",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "10",
          "netId": "power_net_664171b20ecf",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "11",
          "netId": "power_net_a17d09b057f5",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "12",
          "netId": "power_net_55bbd3deed41",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3101",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3102",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "13",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "2",
          "netId": "power_net_9020238d369a",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "3",
          "netId": "power_net_0b769e0e6017",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "4",
          "netId": "power_net_7f7616523bf4",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "5",
          "netId": "power_net_6220152fdd65",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "6",
          "netId": "power_net_39d8ddb40bfa",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "8",
          "netId": "power_net_722d31de17d3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "9",
          "netId": "power_net_35be90fefcdd",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "10",
          "netId": "power_net_afd79c7e6e58",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "11",
          "netId": "power_net_470eacd6abf6",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "12",
          "netId": "power_net_3db57ce8c78a",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "13",
          "netId": "power_net_9693d69e08e6",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность режима выходит из узла",
      "text": "Финальный результат продолжает путь к разрешению работы. Командная готовность и фактическая готовность шин имеют разные назначения.",
      "body": "Финальный результат продолжает путь к разрешению работы. Командная готовность и фактическая готовность шин имеют разные назначения.",
      "nodes": [
        "1",
        "2"
      ],
      "edges": [
        "1_2"
      ],
      "sceneId": "power_3100_PM_COMMAND_READY",
      "netIds": [
        "power_net_4053a009016f",
        "power_net_78f1e98d41b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3103",
          "pin": "4",
          "netId": "power_net_4053a009016f",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "6",
          "netId": "power_net_4053a009016f",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3103",
          "pin": "5",
          "netId": "power_net_78f1e98d41b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3102",
          "pin": "8",
          "netId": "power_net_78f1e98d41b3",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
