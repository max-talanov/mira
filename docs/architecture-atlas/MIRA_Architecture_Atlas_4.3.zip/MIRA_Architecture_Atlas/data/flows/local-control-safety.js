/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control-safety",
  "title": "Как работает: Остановка и фиксация аварий матрицы",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control-safety",
  "steps": [
    {
      "title": "Аппаратная остановка матрицы",
      "text": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
      "body": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
      "nodes": [
        "sheet2200"
      ],
      "edges": [],
      "sceneId": "control-safety",
      "netIds": [
        "control_net_7b06e5d6a4d9",
        "control_net_69c914a4b819",
        "control_net_8272957c8fdb",
        "control_net_6f005443ad9c",
        "control_net_d4a1fffbf6b9",
        "control_net_9269f101a22a",
        "control_net_5a73b1e1ccba",
        "control_net_d44a94d9b4fd",
        "control_net_1a607d7041f2",
        "control_net_2d2627aeff69",
        "control_net_720010c527b5"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2201",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2201",
          "pin": "2",
          "netId": "control_net_69c914a4b819",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2201",
          "pin": "4",
          "netId": "control_net_8272957c8fdb",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "1",
          "netId": "control_net_8272957c8fdb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2201",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "2",
          "netId": "control_net_d4a1fffbf6b9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "4",
          "netId": "control_net_9269f101a22a",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "3",
          "netId": "control_net_5a73b1e1ccba",
          "name": "Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "6",
          "netId": "control_net_1a607d7041f2",
          "name": "CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Аппаратная остановка матрицы",
      "text": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
      "body": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
      "nodes": [
        "sheet2200"
      ],
      "edges": [],
      "sceneId": "control-safety",
      "netIds": [
        "control_net_7b06e5d6a4d9",
        "control_net_69c914a4b819",
        "control_net_8272957c8fdb",
        "control_net_6f005443ad9c",
        "control_net_d4a1fffbf6b9",
        "control_net_9269f101a22a",
        "control_net_5a73b1e1ccba",
        "control_net_d44a94d9b4fd",
        "control_net_1a607d7041f2",
        "control_net_2d2627aeff69",
        "control_net_720010c527b5"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2201",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2201",
          "pin": "2",
          "netId": "control_net_69c914a4b819",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2201",
          "pin": "4",
          "netId": "control_net_8272957c8fdb",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "1",
          "netId": "control_net_8272957c8fdb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2201",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "2",
          "netId": "control_net_d4a1fffbf6b9",
          "name": "B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "4",
          "netId": "control_net_9269f101a22a",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "3",
          "netId": "control_net_5a73b1e1ccba",
          "name": "Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2202",
          "pin": "6",
          "netId": "control_net_1a607d7041f2",
          "name": "CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
