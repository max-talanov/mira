/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2000_ANALOG_3V3",
  "title": "Как работает: Малошумящее аналоговое питание 3,3 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2000_ANALOG_3V3",
  "steps": [
    {
      "title": "На вход приходит ANA5",
      "text": "Шина ANA5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина ANA5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_f5932d689562"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2001",
          "pin": "9",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "10",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_55bbd3deed41",
        "power_net_8a3bb3e9fe35"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q2001",
          "pin": "1",
          "netId": "power_net_55bbd3deed41",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2001",
          "pin": "2",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2001",
          "pin": "1",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "7",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует ANA3V3",
      "text": "Регулятор и цепь обратной связи формируют выходную шину ANA3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину ANA3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_2fb6eec8140e",
        "power_net_a207f0246008"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2006",
          "pin": "1",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2005",
          "pin": "2",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2004",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2003",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2003",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2005",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "2",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования ANA3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования ANA3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_2fb6eec8140e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2006",
          "pin": "1",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2005",
          "pin": "2",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит ANA5",
      "text": "Шина ANA5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина ANA5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_f5932d689562"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2001",
          "pin": "9",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "10",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_55bbd3deed41",
        "power_net_8a3bb3e9fe35"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q2001",
          "pin": "1",
          "netId": "power_net_55bbd3deed41",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2001",
          "pin": "2",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2001",
          "pin": "1",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "7",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует ANA3V3",
      "text": "Регулятор и цепь обратной связи формируют выходную шину ANA3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину ANA3V3. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_2fb6eec8140e",
        "power_net_a207f0246008"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2006",
          "pin": "1",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2005",
          "pin": "2",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2004",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2003",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2003",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2005",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "2",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования ANA3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования ANA3V3 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_2000_ANALOG_3V3",
      "netIds": [
        "power_net_2fb6eec8140e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2006",
          "pin": "1",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2005",
          "pin": "2",
          "netId": "power_net_2fb6eec8140e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
