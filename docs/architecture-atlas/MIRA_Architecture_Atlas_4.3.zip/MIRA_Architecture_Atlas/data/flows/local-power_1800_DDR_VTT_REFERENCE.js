/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_1800_DDR_VTT_REFERENCE",
  "title": "Как работает: Питание и опора терминации DDR",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_1800_DDR_VTT_REFERENCE",
  "steps": [
    {
      "title": "На вход приходит DDR1V35",
      "text": "Шина DDR1V35 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина DDR1V35 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_f3a748e4fa19"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1801",
          "pin": "2",
          "netId": "power_net_f3a748e4fa19",
          "name": "VLDOIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_ae048a8edaa8",
        "power_net_49a6d57a88bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1801",
          "pin": "1",
          "netId": "power_net_ae048a8edaa8",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "7",
          "netId": "power_net_49a6d57a88bc",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1801",
          "pin": "1",
          "netId": "power_net_49a6d57a88bc",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1801",
          "pin": "2",
          "netId": "power_net_49a6d57a88bc",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует VTT",
      "text": "Регулятор и цепь обратной связи формируют выходную шину VTT. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину VTT. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_e295c6eba3ce",
        "power_net_0ee4f5245d75",
        "power_net_ae048a8edaa8",
        "power_net_a494eb253ace",
        "power_net_49a6d57a88bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C1806",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "3",
          "netId": "power_net_e295c6eba3ce",
          "name": "VO",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "5",
          "netId": "power_net_e295c6eba3ce",
          "name": "VOSNS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1805",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1807",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1804",
          "pin": "1",
          "netId": "power_net_0ee4f5245d75",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1802",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "REFIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1803",
          "pin": "2",
          "netId": "power_net_a494eb253ace",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1802",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "7",
          "netId": "power_net_49a6d57a88bc",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования VTT питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования VTT питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_e295c6eba3ce"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C1806",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1805",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1807",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит DDR1V35",
      "text": "Шина DDR1V35 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина DDR1V35 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_f3a748e4fa19"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1801",
          "pin": "2",
          "netId": "power_net_f3a748e4fa19",
          "name": "VLDOIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_ae048a8edaa8",
        "power_net_49a6d57a88bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1801",
          "pin": "1",
          "netId": "power_net_ae048a8edaa8",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "7",
          "netId": "power_net_49a6d57a88bc",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1801",
          "pin": "1",
          "netId": "power_net_49a6d57a88bc",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1801",
          "pin": "2",
          "netId": "power_net_49a6d57a88bc",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует VTT",
      "text": "Регулятор и цепь обратной связи формируют выходную шину VTT. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину VTT. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_e295c6eba3ce",
        "power_net_0ee4f5245d75",
        "power_net_ae048a8edaa8",
        "power_net_a494eb253ace",
        "power_net_49a6d57a88bc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C1806",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "3",
          "netId": "power_net_e295c6eba3ce",
          "name": "VO",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "5",
          "netId": "power_net_e295c6eba3ce",
          "name": "VOSNS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1805",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1807",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1804",
          "pin": "1",
          "netId": "power_net_0ee4f5245d75",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1802",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "REFIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1803",
          "pin": "2",
          "netId": "power_net_a494eb253ace",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1802",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "7",
          "netId": "power_net_49a6d57a88bc",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования VTT питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования VTT питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "netIds": [
        "power_net_e295c6eba3ce"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C1806",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1805",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1807",
          "pin": "1",
          "netId": "power_net_e295c6eba3ce",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
