/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1100_DAC_SERVICE_AND_FORMING",
  "title": "Как работает: Уставки READ, WRITE и FORMING",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
  "steps": [
    {
      "title": "Задаются служебные уровни",
      "text": "Служебный ЦАП формирует уставки READ, SET, RESET и ограничения тока, используемые следующими аналоговыми узлами.",
      "body": "Служебный ЦАП формирует уставки READ, SET, RESET и ограничения тока, используемые следующими аналоговыми узлами.",
      "nodes": [
        "commands"
      ],
      "edges": [],
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_2e82cb98585d",
        "control_net_5f3aa6ac02ea",
        "control_net_872644d0a844",
        "control_net_b4fd0f4101eb",
        "control_net_fad82bf41bcf",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_5c53c9973c60",
        "control_net_245f41faaafc",
        "control_net_c1240dda3ce7",
        "control_net_e7bd9de88b26",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_a657e0110c0a",
        "control_net_3c3ad73203dc",
        "control_net_a29863c03d26"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1103",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1101",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1102",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1100",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1102",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1106",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1105",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "1",
          "netId": "control_net_5f3aa6ac02ea",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "2",
          "netId": "control_net_872644d0a844",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1100",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1101",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "5",
          "netId": "control_net_fad82bf41bcf",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1100",
          "pin": "2",
          "netId": "control_net_fad82bf41bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "9",
          "netId": "control_net_5c53c9973c60",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "10",
          "netId": "control_net_245f41faaafc",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "11",
          "netId": "control_net_c1240dda3ce7",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "12",
          "netId": "control_net_e7bd9de88b26",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1101",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1102",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1104",
          "pin": "1",
          "netId": "control_net_a657e0110c0a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "18",
          "netId": "control_net_a657e0110c0a",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "19",
          "netId": "control_net_3c3ad73203dc",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "20",
          "netId": "control_net_a29863c03d26",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Уставки буферизуются",
      "text": "Повторители передают служебные аналоговые команды к выбору источника и регулятору. Конкретное напряжение определяется кодом ЦАП и схемой.",
      "body": "Повторители передают служебные аналоговые команды к выбору источника и регулятору. Конкретное напряжение определяется кодом ЦАП и схемой.",
      "nodes": [
        "commands",
        "buffer"
      ],
      "edges": [
        "commands_buffer"
      ],
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "netIds": [
        "control_net_e7bd9de88b26",
        "control_net_5f3aa6ac02ea",
        "control_net_872644d0a844",
        "control_net_5c53c9973c60",
        "control_net_245f41faaafc",
        "control_net_c1240dda3ce7",
        "control_net_3c3ad73203dc",
        "control_net_a29863c03d26"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1102",
          "pin": "3",
          "netId": "control_net_e7bd9de88b26",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "12",
          "netId": "control_net_e7bd9de88b26",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "1",
          "netId": "control_net_5f3aa6ac02ea",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "5",
          "netId": "control_net_5f3aa6ac02ea",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "2",
          "netId": "control_net_872644d0a844",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "3",
          "netId": "control_net_872644d0a844",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "9",
          "netId": "control_net_5c53c9973c60",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1102",
          "pin": "12",
          "netId": "control_net_5c53c9973c60",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "10",
          "netId": "control_net_245f41faaafc",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1102",
          "pin": "10",
          "netId": "control_net_245f41faaafc",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "11",
          "netId": "control_net_c1240dda3ce7",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1102",
          "pin": "5",
          "netId": "control_net_c1240dda3ce7",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "19",
          "netId": "control_net_3c3ad73203dc",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "12",
          "netId": "control_net_3c3ad73203dc",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "20",
          "netId": "control_net_a29863c03d26",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "10",
          "netId": "control_net_a29863c03d26",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "FORMING получает отдельный тракт",
      "text": "Отдельный ЦАП и усилитель формируют команду FORMING. Она поступает к последующему аналоговому тракту, а не напрямую к каждой ячейке.",
      "body": "Отдельный ЦАП и усилитель формируют команду FORMING. Она поступает к последующему аналоговому тракту, а не напрямую к каждой ячейке.",
      "nodes": [
        "forming",
        "formbuffer"
      ],
      "edges": [
        "forming_formbuffer"
      ],
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "netIds": [
        "control_net_5980e068f72a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1104",
          "pin": "3",
          "netId": "control_net_5980e068f72a",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "7",
          "netId": "control_net_5980e068f72a",
          "name": "VOUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Задаются служебные уровни",
      "text": "Служебный ЦАП формирует уставки READ, SET, RESET и ограничения тока, используемые следующими аналоговыми узлами.",
      "body": "Служебный ЦАП формирует уставки READ, SET, RESET и ограничения тока, используемые следующими аналоговыми узлами.",
      "nodes": [
        "commands"
      ],
      "edges": [],
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_2e82cb98585d",
        "control_net_5f3aa6ac02ea",
        "control_net_872644d0a844",
        "control_net_b4fd0f4101eb",
        "control_net_fad82bf41bcf",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_5c53c9973c60",
        "control_net_245f41faaafc",
        "control_net_c1240dda3ce7",
        "control_net_e7bd9de88b26",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_a657e0110c0a",
        "control_net_3c3ad73203dc",
        "control_net_a29863c03d26"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1103",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1101",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1102",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1100",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1102",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1106",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1105",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "1",
          "netId": "control_net_5f3aa6ac02ea",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "2",
          "netId": "control_net_872644d0a844",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1100",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1101",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "5",
          "netId": "control_net_fad82bf41bcf",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1100",
          "pin": "2",
          "netId": "control_net_fad82bf41bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "9",
          "netId": "control_net_5c53c9973c60",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "10",
          "netId": "control_net_245f41faaafc",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "11",
          "netId": "control_net_c1240dda3ce7",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "12",
          "netId": "control_net_e7bd9de88b26",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1101",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1102",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1104",
          "pin": "1",
          "netId": "control_net_a657e0110c0a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "18",
          "netId": "control_net_a657e0110c0a",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "19",
          "netId": "control_net_3c3ad73203dc",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "20",
          "netId": "control_net_a29863c03d26",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Уставки буферизуются",
      "text": "Повторители передают служебные аналоговые команды к выбору источника и регулятору. Конкретное напряжение определяется кодом ЦАП и схемой.",
      "body": "Повторители передают служебные аналоговые команды к выбору источника и регулятору. Конкретное напряжение определяется кодом ЦАП и схемой.",
      "nodes": [
        "commands",
        "buffer"
      ],
      "edges": [
        "commands_buffer"
      ],
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "netIds": [
        "control_net_e7bd9de88b26",
        "control_net_5f3aa6ac02ea",
        "control_net_872644d0a844",
        "control_net_5c53c9973c60",
        "control_net_245f41faaafc",
        "control_net_c1240dda3ce7",
        "control_net_3c3ad73203dc",
        "control_net_a29863c03d26"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1102",
          "pin": "3",
          "netId": "control_net_e7bd9de88b26",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "12",
          "netId": "control_net_e7bd9de88b26",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "1",
          "netId": "control_net_5f3aa6ac02ea",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "5",
          "netId": "control_net_5f3aa6ac02ea",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "2",
          "netId": "control_net_872644d0a844",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "3",
          "netId": "control_net_872644d0a844",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "9",
          "netId": "control_net_5c53c9973c60",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1102",
          "pin": "12",
          "netId": "control_net_5c53c9973c60",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "10",
          "netId": "control_net_245f41faaafc",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1102",
          "pin": "10",
          "netId": "control_net_245f41faaafc",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "11",
          "netId": "control_net_c1240dda3ce7",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1102",
          "pin": "5",
          "netId": "control_net_c1240dda3ce7",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "19",
          "netId": "control_net_3c3ad73203dc",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "12",
          "netId": "control_net_3c3ad73203dc",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "20",
          "netId": "control_net_a29863c03d26",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1101",
          "pin": "10",
          "netId": "control_net_a29863c03d26",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "FORMING получает отдельный тракт",
      "text": "Отдельный ЦАП и усилитель формируют команду FORMING. Она поступает к последующему аналоговому тракту, а не напрямую к каждой ячейке.",
      "body": "Отдельный ЦАП и усилитель формируют команду FORMING. Она поступает к последующему аналоговому тракту, а не напрямую к каждой ячейке.",
      "nodes": [
        "forming",
        "formbuffer"
      ],
      "edges": [
        "forming_formbuffer"
      ],
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "netIds": [
        "control_net_5980e068f72a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1104",
          "pin": "3",
          "netId": "control_net_5980e068f72a",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1103",
          "pin": "7",
          "netId": "control_net_5980e068f72a",
          "name": "VOUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
