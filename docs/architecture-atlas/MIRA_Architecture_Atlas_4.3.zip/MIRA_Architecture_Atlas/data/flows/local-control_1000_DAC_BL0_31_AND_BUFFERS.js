/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1000_DAC_BL0_31_AND_BUFFERS",
  "title": "Как работает: 32 напряжения битовых линий",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
  "steps": [
    {
      "title": "ЦАП получают цифровые уставки",
      "text": "Четыре восьмиканальных ЦАП формируют 32 независимо задаваемых аналоговых напряжения. Значения кодов выбираются программой эксперимента.",
      "body": "Четыре восьмиканальных ЦАП формируют 32 независимо задаваемых аналоговых напряжения. Значения кодов выбираются программой эксперимента.",
      "nodes": [
        "dac0",
        "dac1",
        "dac2",
        "dac3"
      ],
      "edges": [],
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "netIds": [
        "control_net_b4fd0f4101eb",
        "control_net_f27be3e2a370",
        "control_net_2e82cb98585d",
        "control_net_b382ee5d9c95",
        "control_net_6629c66bc5c3",
        "control_net_6f005443ad9c",
        "control_net_fd8710ab620d",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_fb6a011f184f",
        "control_net_f636a6adf1a1",
        "control_net_6954c1b0f1fe",
        "control_net_ceb3c2b7a415",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_6045e4b58bcf",
        "control_net_5cc4301e4849",
        "control_net_d29f038dfa81",
        "control_net_bae01a82acc2",
        "control_net_8543c7028353",
        "control_net_d356a1f28598",
        "control_net_47af455af6dc",
        "control_net_561ae5f25bce",
        "control_net_90accaec6322",
        "control_net_e1f6195edd21",
        "control_net_b90f47fe887d",
        "control_net_8be92a53ce8b",
        "control_net_d6647a4628c8",
        "control_net_05e0a792cc72",
        "control_net_a0db919ee83d",
        "control_net_78ba9d6b88dd",
        "control_net_781dd31d2aeb",
        "control_net_4ff0e756cbd5",
        "control_net_be4660552802",
        "control_net_45414159a6d3",
        "control_net_3604545d058f",
        "control_net_1de6960dfbf7",
        "control_net_bbe57577edac",
        "control_net_2efabf58bf8f",
        "control_net_8f0753af8e50",
        "control_net_6f08013fa83c",
        "control_net_d7416d0b6780",
        "control_net_100f8cbfb278",
        "control_net_392b5704c213",
        "control_net_8b109f39f0b2",
        "control_net_6c1729627b24",
        "control_net_65f84fe93731"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1001",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1040",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1014",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1039",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1000",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1013",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1027",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1026",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "18",
          "netId": "control_net_f27be3e2a370",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1017",
          "pin": "1",
          "netId": "control_net_f27be3e2a370",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1006",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1019",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1005",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1018",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1044",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1031",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1032",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1045",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "1",
          "netId": "control_net_b382ee5d9c95",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "2",
          "netId": "control_net_6629c66bc5c3",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1002",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1016",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1015",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1012",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1033",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1000",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1003",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1011",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1001",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1013",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1034",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1024",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1029",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1041",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1022",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1035",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1042",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1028",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1002",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1023",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "5",
          "netId": "control_net_fd8710ab620d",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1022",
          "pin": "2",
          "netId": "control_net_fd8710ab620d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "9",
          "netId": "control_net_fb6a011f184f",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "10",
          "netId": "control_net_f636a6adf1a1",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "11",
          "netId": "control_net_6954c1b0f1fe",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "12",
          "netId": "control_net_ceb3c2b7a415",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1012",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1001",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1034",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1023",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1013",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1024",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1035",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1002",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1030",
          "pin": "1",
          "netId": "control_net_6045e4b58bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "18",
          "netId": "control_net_6045e4b58bcf",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "19",
          "netId": "control_net_5cc4301e4849",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "20",
          "netId": "control_net_d29f038dfa81",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1011",
          "pin": "2",
          "netId": "control_net_bae01a82acc2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "5",
          "netId": "control_net_bae01a82acc2",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1033",
          "pin": "2",
          "netId": "control_net_8543c7028353",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "18",
          "netId": "control_net_d356a1f28598",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1043",
          "pin": "1",
          "netId": "control_net_d356a1f28598",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "1",
          "netId": "control_net_47af455af6dc",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "2",
          "netId": "control_net_561ae5f25bce",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1000",
          "pin": "2",
          "netId": "control_net_90accaec6322",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "5",
          "netId": "control_net_90accaec6322",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "9",
          "netId": "control_net_e1f6195edd21",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "10",
          "netId": "control_net_b90f47fe887d",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "11",
          "netId": "control_net_8be92a53ce8b",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "12",
          "netId": "control_net_d6647a4628c8",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1004",
          "pin": "1",
          "netId": "control_net_05e0a792cc72",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "18",
          "netId": "control_net_05e0a792cc72",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "19",
          "netId": "control_net_a0db919ee83d",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "20",
          "netId": "control_net_78ba9d6b88dd",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "1",
          "netId": "control_net_781dd31d2aeb",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "2",
          "netId": "control_net_4ff0e756cbd5",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "9",
          "netId": "control_net_be4660552802",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "10",
          "netId": "control_net_45414159a6d3",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "11",
          "netId": "control_net_3604545d058f",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "12",
          "netId": "control_net_1de6960dfbf7",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "19",
          "netId": "control_net_bbe57577edac",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "20",
          "netId": "control_net_2efabf58bf8f",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "1",
          "netId": "control_net_8f0753af8e50",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "2",
          "netId": "control_net_6f08013fa83c",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "9",
          "netId": "control_net_d7416d0b6780",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "10",
          "netId": "control_net_100f8cbfb278",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "11",
          "netId": "control_net_392b5704c213",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "12",
          "netId": "control_net_8b109f39f0b2",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "19",
          "netId": "control_net_6c1729627b24",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "20",
          "netId": "control_net_65f84fe93731",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Напряжения проходят через буферы",
      "text": "Каждая группа выходов ЦАП поступает на повторители. Буферы передают аналоговый уровень дальше, развязывая выход ЦАП и последующую нагрузку.",
      "body": "Каждая группа выходов ЦАП поступает на повторители. Буферы передают аналоговый уровень дальше, развязывая выход ЦАП и последующую нагрузку.",
      "nodes": [
        "dac0",
        "buffer0",
        "dac1",
        "buffer1"
      ],
      "edges": [
        "dac0_buffer0_0",
        "dac1_buffer1_1"
      ],
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "netIds": [
        "control_net_47af455af6dc",
        "control_net_b90f47fe887d",
        "control_net_a0db919ee83d",
        "control_net_d6647a4628c8",
        "control_net_8be92a53ce8b",
        "control_net_78ba9d6b88dd",
        "control_net_e1f6195edd21",
        "control_net_561ae5f25bce",
        "control_net_45414159a6d3",
        "control_net_be4660552802",
        "control_net_bbe57577edac",
        "control_net_4ff0e756cbd5",
        "control_net_3604545d058f",
        "control_net_781dd31d2aeb",
        "control_net_1de6960dfbf7",
        "control_net_2efabf58bf8f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1001",
          "pin": "5",
          "netId": "control_net_47af455af6dc",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "1",
          "netId": "control_net_47af455af6dc",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "10",
          "netId": "control_net_b90f47fe887d",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "10",
          "netId": "control_net_b90f47fe887d",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1001",
          "pin": "12",
          "netId": "control_net_a0db919ee83d",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "19",
          "netId": "control_net_a0db919ee83d",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "3",
          "netId": "control_net_d6647a4628c8",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "12",
          "netId": "control_net_d6647a4628c8",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "5",
          "netId": "control_net_8be92a53ce8b",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "11",
          "netId": "control_net_8be92a53ce8b",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1001",
          "pin": "10",
          "netId": "control_net_78ba9d6b88dd",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "20",
          "netId": "control_net_78ba9d6b88dd",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "12",
          "netId": "control_net_e1f6195edd21",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "9",
          "netId": "control_net_e1f6195edd21",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "2",
          "netId": "control_net_561ae5f25bce",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1001",
          "pin": "3",
          "netId": "control_net_561ae5f25bce",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "10",
          "netId": "control_net_45414159a6d3",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "10",
          "netId": "control_net_45414159a6d3",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "12",
          "netId": "control_net_be4660552802",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "9",
          "netId": "control_net_be4660552802",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "12",
          "netId": "control_net_bbe57577edac",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "19",
          "netId": "control_net_bbe57577edac",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "3",
          "netId": "control_net_4ff0e756cbd5",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "2",
          "netId": "control_net_4ff0e756cbd5",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "5",
          "netId": "control_net_3604545d058f",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "11",
          "netId": "control_net_3604545d058f",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "1",
          "netId": "control_net_781dd31d2aeb",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "5",
          "netId": "control_net_781dd31d2aeb",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "12",
          "netId": "control_net_1de6960dfbf7",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "3",
          "netId": "control_net_1de6960dfbf7",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "20",
          "netId": "control_net_2efabf58bf8f",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "10",
          "netId": "control_net_2efabf58bf8f",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Все 32 канала идут к коммутации",
      "text": "Остальные два банка устроены аналогично. Цепи BL_DAC0…31 продолжаются в тракт коммутации матрицы; здесь ячейки ещё не выбираются.",
      "body": "Остальные два банка устроены аналогично. Цепи BL_DAC0…31 продолжаются в тракт коммутации матрицы; здесь ячейки ещё не выбираются.",
      "nodes": [
        "dac2",
        "buffer2",
        "dac3",
        "buffer3"
      ],
      "edges": [
        "dac2_buffer2_2",
        "dac3_buffer3_3"
      ],
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "netIds": [
        "control_net_ceb3c2b7a415",
        "control_net_6629c66bc5c3",
        "control_net_b382ee5d9c95",
        "control_net_fb6a011f184f",
        "control_net_f636a6adf1a1",
        "control_net_6954c1b0f1fe",
        "control_net_5cc4301e4849",
        "control_net_d29f038dfa81",
        "control_net_8f0753af8e50",
        "control_net_6f08013fa83c",
        "control_net_d7416d0b6780",
        "control_net_100f8cbfb278",
        "control_net_392b5704c213",
        "control_net_8b109f39f0b2",
        "control_net_6c1729627b24",
        "control_net_65f84fe93731"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1008",
          "pin": "3",
          "netId": "control_net_ceb3c2b7a415",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "12",
          "netId": "control_net_ceb3c2b7a415",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "3",
          "netId": "control_net_6629c66bc5c3",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "2",
          "netId": "control_net_6629c66bc5c3",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "1",
          "netId": "control_net_b382ee5d9c95",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "5",
          "netId": "control_net_b382ee5d9c95",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "9",
          "netId": "control_net_fb6a011f184f",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1008",
          "pin": "12",
          "netId": "control_net_fb6a011f184f",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "10",
          "netId": "control_net_f636a6adf1a1",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1008",
          "pin": "10",
          "netId": "control_net_f636a6adf1a1",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "11",
          "netId": "control_net_6954c1b0f1fe",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1008",
          "pin": "5",
          "netId": "control_net_6954c1b0f1fe",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "19",
          "netId": "control_net_5cc4301e4849",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "12",
          "netId": "control_net_5cc4301e4849",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "20",
          "netId": "control_net_d29f038dfa81",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "10",
          "netId": "control_net_d29f038dfa81",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "5",
          "netId": "control_net_8f0753af8e50",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "1",
          "netId": "control_net_8f0753af8e50",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "2",
          "netId": "control_net_6f08013fa83c",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "3",
          "netId": "control_net_6f08013fa83c",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "9",
          "netId": "control_net_d7416d0b6780",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "12",
          "netId": "control_net_d7416d0b6780",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "10",
          "netId": "control_net_100f8cbfb278",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "10",
          "netId": "control_net_100f8cbfb278",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "11",
          "netId": "control_net_392b5704c213",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "5",
          "netId": "control_net_392b5704c213",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "12",
          "netId": "control_net_8b109f39f0b2",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "3",
          "netId": "control_net_8b109f39f0b2",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "19",
          "netId": "control_net_6c1729627b24",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "12",
          "netId": "control_net_6c1729627b24",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "20",
          "netId": "control_net_65f84fe93731",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "10",
          "netId": "control_net_65f84fe93731",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "ЦАП получают цифровые уставки",
      "text": "Четыре восьмиканальных ЦАП формируют 32 независимо задаваемых аналоговых напряжения. Значения кодов выбираются программой эксперимента.",
      "body": "Четыре восьмиканальных ЦАП формируют 32 независимо задаваемых аналоговых напряжения. Значения кодов выбираются программой эксперимента.",
      "nodes": [
        "dac0",
        "dac1",
        "dac2",
        "dac3"
      ],
      "edges": [],
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "netIds": [
        "control_net_b4fd0f4101eb",
        "control_net_f27be3e2a370",
        "control_net_2e82cb98585d",
        "control_net_b382ee5d9c95",
        "control_net_6629c66bc5c3",
        "control_net_6f005443ad9c",
        "control_net_fd8710ab620d",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_fb6a011f184f",
        "control_net_f636a6adf1a1",
        "control_net_6954c1b0f1fe",
        "control_net_ceb3c2b7a415",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_6045e4b58bcf",
        "control_net_5cc4301e4849",
        "control_net_d29f038dfa81",
        "control_net_bae01a82acc2",
        "control_net_8543c7028353",
        "control_net_d356a1f28598",
        "control_net_47af455af6dc",
        "control_net_561ae5f25bce",
        "control_net_90accaec6322",
        "control_net_e1f6195edd21",
        "control_net_b90f47fe887d",
        "control_net_8be92a53ce8b",
        "control_net_d6647a4628c8",
        "control_net_05e0a792cc72",
        "control_net_a0db919ee83d",
        "control_net_78ba9d6b88dd",
        "control_net_781dd31d2aeb",
        "control_net_4ff0e756cbd5",
        "control_net_be4660552802",
        "control_net_45414159a6d3",
        "control_net_3604545d058f",
        "control_net_1de6960dfbf7",
        "control_net_bbe57577edac",
        "control_net_2efabf58bf8f",
        "control_net_8f0753af8e50",
        "control_net_6f08013fa83c",
        "control_net_d7416d0b6780",
        "control_net_100f8cbfb278",
        "control_net_392b5704c213",
        "control_net_8b109f39f0b2",
        "control_net_6c1729627b24",
        "control_net_65f84fe93731"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C1001",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1040",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1014",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1039",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1000",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1013",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1027",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1026",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "3",
          "netId": "control_net_b4fd0f4101eb",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "18",
          "netId": "control_net_f27be3e2a370",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1017",
          "pin": "1",
          "netId": "control_net_f27be3e2a370",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1006",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1019",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1005",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1018",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1044",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1031",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1032",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1045",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "1",
          "netId": "control_net_b382ee5d9c95",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "2",
          "netId": "control_net_6629c66bc5c3",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1002",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1016",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1015",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1012",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1033",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1000",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1003",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1011",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1001",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1013",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1034",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1024",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1029",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1041",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1022",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1035",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1042",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1028",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "4",
          "netId": "control_net_6f005443ad9c",
          "name": "VLOGIC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "8",
          "netId": "control_net_6f005443ad9c",
          "name": "GAIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1002",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1023",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "5",
          "netId": "control_net_fd8710ab620d",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1022",
          "pin": "2",
          "netId": "control_net_fd8710ab620d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "9",
          "netId": "control_net_fb6a011f184f",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "10",
          "netId": "control_net_f636a6adf1a1",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "11",
          "netId": "control_net_6954c1b0f1fe",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "12",
          "netId": "control_net_ceb3c2b7a415",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1012",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1001",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1034",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "15",
          "netId": "control_net_0d0a126b05bc",
          "name": "LDAC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1023",
          "pin": "2",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1013",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1024",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1035",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "17",
          "netId": "control_net_a2017f4fe37b",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1002",
          "pin": "2",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1030",
          "pin": "1",
          "netId": "control_net_6045e4b58bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "18",
          "netId": "control_net_6045e4b58bcf",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "19",
          "netId": "control_net_5cc4301e4849",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "20",
          "netId": "control_net_d29f038dfa81",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1011",
          "pin": "2",
          "netId": "control_net_bae01a82acc2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "5",
          "netId": "control_net_bae01a82acc2",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "5",
          "netId": "control_net_8543c7028353",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1033",
          "pin": "2",
          "netId": "control_net_8543c7028353",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "18",
          "netId": "control_net_d356a1f28598",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1043",
          "pin": "1",
          "netId": "control_net_d356a1f28598",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "1",
          "netId": "control_net_47af455af6dc",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "2",
          "netId": "control_net_561ae5f25bce",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1000",
          "pin": "2",
          "netId": "control_net_90accaec6322",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "5",
          "netId": "control_net_90accaec6322",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "9",
          "netId": "control_net_e1f6195edd21",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "10",
          "netId": "control_net_b90f47fe887d",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "11",
          "netId": "control_net_8be92a53ce8b",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "12",
          "netId": "control_net_d6647a4628c8",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1004",
          "pin": "1",
          "netId": "control_net_05e0a792cc72",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "18",
          "netId": "control_net_05e0a792cc72",
          "name": "VREF",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "19",
          "netId": "control_net_a0db919ee83d",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "20",
          "netId": "control_net_78ba9d6b88dd",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "1",
          "netId": "control_net_781dd31d2aeb",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "2",
          "netId": "control_net_4ff0e756cbd5",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "9",
          "netId": "control_net_be4660552802",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "10",
          "netId": "control_net_45414159a6d3",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "11",
          "netId": "control_net_3604545d058f",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "12",
          "netId": "control_net_1de6960dfbf7",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "19",
          "netId": "control_net_bbe57577edac",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "20",
          "netId": "control_net_2efabf58bf8f",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "1",
          "netId": "control_net_8f0753af8e50",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "2",
          "netId": "control_net_6f08013fa83c",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "9",
          "netId": "control_net_d7416d0b6780",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "10",
          "netId": "control_net_100f8cbfb278",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "11",
          "netId": "control_net_392b5704c213",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "12",
          "netId": "control_net_8b109f39f0b2",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "19",
          "netId": "control_net_6c1729627b24",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "20",
          "netId": "control_net_65f84fe93731",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Напряжения проходят через буферы",
      "text": "Каждая группа выходов ЦАП поступает на повторители. Буферы передают аналоговый уровень дальше, развязывая выход ЦАП и последующую нагрузку.",
      "body": "Каждая группа выходов ЦАП поступает на повторители. Буферы передают аналоговый уровень дальше, развязывая выход ЦАП и последующую нагрузку.",
      "nodes": [
        "dac0",
        "buffer0",
        "dac1",
        "buffer1"
      ],
      "edges": [
        "dac0_buffer0_0",
        "dac1_buffer1_1"
      ],
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "netIds": [
        "control_net_47af455af6dc",
        "control_net_b90f47fe887d",
        "control_net_a0db919ee83d",
        "control_net_d6647a4628c8",
        "control_net_8be92a53ce8b",
        "control_net_78ba9d6b88dd",
        "control_net_e1f6195edd21",
        "control_net_561ae5f25bce",
        "control_net_45414159a6d3",
        "control_net_be4660552802",
        "control_net_bbe57577edac",
        "control_net_4ff0e756cbd5",
        "control_net_3604545d058f",
        "control_net_781dd31d2aeb",
        "control_net_1de6960dfbf7",
        "control_net_2efabf58bf8f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1001",
          "pin": "5",
          "netId": "control_net_47af455af6dc",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "1",
          "netId": "control_net_47af455af6dc",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "10",
          "netId": "control_net_b90f47fe887d",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "10",
          "netId": "control_net_b90f47fe887d",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1001",
          "pin": "12",
          "netId": "control_net_a0db919ee83d",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "19",
          "netId": "control_net_a0db919ee83d",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "3",
          "netId": "control_net_d6647a4628c8",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "12",
          "netId": "control_net_d6647a4628c8",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "5",
          "netId": "control_net_8be92a53ce8b",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "11",
          "netId": "control_net_8be92a53ce8b",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1001",
          "pin": "10",
          "netId": "control_net_78ba9d6b88dd",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "20",
          "netId": "control_net_78ba9d6b88dd",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1002",
          "pin": "12",
          "netId": "control_net_e1f6195edd21",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "9",
          "netId": "control_net_e1f6195edd21",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "2",
          "netId": "control_net_561ae5f25bce",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1001",
          "pin": "3",
          "netId": "control_net_561ae5f25bce",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "10",
          "netId": "control_net_45414159a6d3",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "10",
          "netId": "control_net_45414159a6d3",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "12",
          "netId": "control_net_be4660552802",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "9",
          "netId": "control_net_be4660552802",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "12",
          "netId": "control_net_bbe57577edac",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "19",
          "netId": "control_net_bbe57577edac",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "3",
          "netId": "control_net_4ff0e756cbd5",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "2",
          "netId": "control_net_4ff0e756cbd5",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "5",
          "netId": "control_net_3604545d058f",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "11",
          "netId": "control_net_3604545d058f",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "1",
          "netId": "control_net_781dd31d2aeb",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "5",
          "netId": "control_net_781dd31d2aeb",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "12",
          "netId": "control_net_1de6960dfbf7",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1005",
          "pin": "3",
          "netId": "control_net_1de6960dfbf7",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1003",
          "pin": "20",
          "netId": "control_net_2efabf58bf8f",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1004",
          "pin": "10",
          "netId": "control_net_2efabf58bf8f",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Все 32 канала идут к коммутации",
      "text": "Остальные два банка устроены аналогично. Цепи BL_DAC0…31 продолжаются в тракт коммутации матрицы; здесь ячейки ещё не выбираются.",
      "body": "Остальные два банка устроены аналогично. Цепи BL_DAC0…31 продолжаются в тракт коммутации матрицы; здесь ячейки ещё не выбираются.",
      "nodes": [
        "dac2",
        "buffer2",
        "dac3",
        "buffer3"
      ],
      "edges": [
        "dac2_buffer2_2",
        "dac3_buffer3_3"
      ],
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "netIds": [
        "control_net_ceb3c2b7a415",
        "control_net_6629c66bc5c3",
        "control_net_b382ee5d9c95",
        "control_net_fb6a011f184f",
        "control_net_f636a6adf1a1",
        "control_net_6954c1b0f1fe",
        "control_net_5cc4301e4849",
        "control_net_d29f038dfa81",
        "control_net_8f0753af8e50",
        "control_net_6f08013fa83c",
        "control_net_d7416d0b6780",
        "control_net_100f8cbfb278",
        "control_net_392b5704c213",
        "control_net_8b109f39f0b2",
        "control_net_6c1729627b24",
        "control_net_65f84fe93731"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1008",
          "pin": "3",
          "netId": "control_net_ceb3c2b7a415",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "12",
          "netId": "control_net_ceb3c2b7a415",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "3",
          "netId": "control_net_6629c66bc5c3",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "2",
          "netId": "control_net_6629c66bc5c3",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "1",
          "netId": "control_net_b382ee5d9c95",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "5",
          "netId": "control_net_b382ee5d9c95",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "9",
          "netId": "control_net_fb6a011f184f",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1008",
          "pin": "12",
          "netId": "control_net_fb6a011f184f",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "10",
          "netId": "control_net_f636a6adf1a1",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1008",
          "pin": "10",
          "netId": "control_net_f636a6adf1a1",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "11",
          "netId": "control_net_6954c1b0f1fe",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1008",
          "pin": "5",
          "netId": "control_net_6954c1b0f1fe",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "19",
          "netId": "control_net_5cc4301e4849",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "12",
          "netId": "control_net_5cc4301e4849",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1006",
          "pin": "20",
          "netId": "control_net_d29f038dfa81",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1007",
          "pin": "10",
          "netId": "control_net_d29f038dfa81",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "5",
          "netId": "control_net_8f0753af8e50",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "1",
          "netId": "control_net_8f0753af8e50",
          "name": "VOUT1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "2",
          "netId": "control_net_6f08013fa83c",
          "name": "VOUT0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "3",
          "netId": "control_net_6f08013fa83c",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "9",
          "netId": "control_net_d7416d0b6780",
          "name": "VOUT7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "12",
          "netId": "control_net_d7416d0b6780",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "10",
          "netId": "control_net_100f8cbfb278",
          "name": "VOUT6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "10",
          "netId": "control_net_100f8cbfb278",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "11",
          "netId": "control_net_392b5704c213",
          "name": "VOUT5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "5",
          "netId": "control_net_392b5704c213",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "12",
          "netId": "control_net_8b109f39f0b2",
          "name": "VOUT4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1011",
          "pin": "3",
          "netId": "control_net_8b109f39f0b2",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "19",
          "netId": "control_net_6c1729627b24",
          "name": "VOUT3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "12",
          "netId": "control_net_6c1729627b24",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1009",
          "pin": "20",
          "netId": "control_net_65f84fe93731",
          "name": "VOUT2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1010",
          "pin": "10",
          "netId": "control_net_65f84fe93731",
          "name": "+IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
