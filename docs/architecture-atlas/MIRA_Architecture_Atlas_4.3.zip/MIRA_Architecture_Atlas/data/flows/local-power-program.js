/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power-program",
  "title": "Как работает: Питание программирования",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power-program",
  "steps": [
    {
      "title": "Коммутация положительного питания записи",
      "text": "Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "body": "Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "nodes": [
        "sheet2100",
        "sheet2200"
      ],
      "edges": [
        "sheet2100_sheet2200"
      ],
      "sceneId": "power-program",
      "netIds": [
        "power_net_46ab17b8adeb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2203",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Коммутация отрицательного питания записи",
      "text": "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "body": "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "nodes": [
        "sheet2200",
        "sheet2100"
      ],
      "edges": [
        "sheet2100_sheet2200"
      ],
      "sceneId": "power-program",
      "netIds": [
        "power_net_46ab17b8adeb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2203",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разъём питания программирования",
      "text": "J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.",
      "body": "J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.",
      "nodes": [
        "sheet2300"
      ],
      "edges": [],
      "sceneId": "power-program",
      "netIds": [
        "power_net_7267dc19b659",
        "power_net_84243fac5530"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J2301",
          "pin": "1",
          "netId": "power_net_7267dc19b659",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2301",
          "pin": "3",
          "netId": "power_net_84243fac5530",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Коммутация положительного питания записи",
      "text": "Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "body": "Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "nodes": [
        "sheet2100",
        "sheet2200"
      ],
      "edges": [
        "sheet2100_sheet2200"
      ],
      "sceneId": "power-program",
      "netIds": [
        "power_net_46ab17b8adeb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2203",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Коммутация отрицательного питания записи",
      "text": "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "body": "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом. Связь с соседним узлом показана цепями MATRIX_OPTO_K.",
      "nodes": [
        "sheet2200",
        "sheet2100"
      ],
      "edges": [
        "sheet2100_sheet2200"
      ],
      "sceneId": "power-program",
      "netIds": [
        "power_net_46ab17b8adeb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2203",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разъём питания программирования",
      "text": "J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.",
      "body": "J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.",
      "nodes": [
        "sheet2300"
      ],
      "edges": [],
      "sceneId": "power-program",
      "netIds": [
        "power_net_7267dc19b659",
        "power_net_84243fac5530"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J2301",
          "pin": "1",
          "netId": "power_net_7267dc19b659",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2301",
          "pin": "3",
          "netId": "power_net_84243fac5530",
          "name": "Pin_3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
