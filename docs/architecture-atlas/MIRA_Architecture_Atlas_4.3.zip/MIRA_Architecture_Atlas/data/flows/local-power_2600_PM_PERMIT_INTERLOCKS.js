/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2600_PM_PERMIT_INTERLOCKS",
  "title": "Как работает: Аппаратные разрешения и блокировки",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
  "steps": [
    {
      "title": "Приходят внешние условия безопасности",
      "text": "Внешние контакты и аппаратные блокировки поступают в узел разрешений. Любое условие рассматривается по реальной цепи исходника.",
      "body": "Внешние контакты и аппаратные блокировки поступают в узел разрешений. Любое условие рассматривается по реальной цепи исходника.",
      "nodes": [
        "stop",
        "qualify"
      ],
      "edges": [
        "stop_qualify"
      ],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_d27f47724845",
        "power_net_e9a19d60b5ab"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J2602",
          "pin": "2",
          "netId": "power_net_d27f47724845",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "12",
          "netId": "power_net_d27f47724845",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "12",
          "netId": "power_net_e9a19d60b5ab",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2601",
          "pin": "2",
          "netId": "power_net_e9a19d60b5ab",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Логика проверяет совокупность условий",
      "text": "Аппаратные элементы требуют выполнения соответствующих условий перед выдачей разрешения. Простого программного запроса недостаточно.",
      "body": "Аппаратные элементы требуют выполнения соответствующих условий перед выдачей разрешения. Простого программного запроса недостаточно.",
      "nodes": [
        "qualify",
        "memory"
      ],
      "edges": [
        "qualify_memory"
      ],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_8828c890966d",
        "power_net_0d67fdbc5a0d",
        "power_net_bc6b8848cad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "8",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "8",
          "netId": "power_net_bc6b8848cad9",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Состояние удерживается триггерами",
      "text": "Триггеры хранят состояние разрешения или отключения до предусмотренного перевзвода.",
      "body": "Триггеры хранят состояние разрешения или отключения до предусмотренного перевзвода.",
      "nodes": [
        "memory"
      ],
      "edges": [],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_6d982403b080",
        "power_net_0d67fdbc5a0d",
        "power_net_67006db669b3",
        "power_net_6ad422db16ac",
        "power_net_8828c890966d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_5a1f578d112a",
        "power_net_bc6b8848cad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2607",
          "pin": "1",
          "netId": "power_net_6d982403b080",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2603",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2606",
          "pin": "1",
          "netId": "power_net_6ad422db16ac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешение выходит за границу узла",
      "text": "Транзисторный интерфейс передаёт сигналы разрешения и запрета другим частям системы питания.",
      "body": "Транзисторный интерфейс передаёт сигналы разрешения и запрета другим частям системы питания.",
      "nodes": [
        "memory",
        "output"
      ],
      "edges": [],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_9ab95937734d",
        "power_net_e9a19d60b5ab",
        "power_net_67006db669b3",
        "power_net_d27f47724845",
        "power_net_6d982403b080",
        "power_net_cfb766cbb94f",
        "power_net_0d67fdbc5a0d",
        "power_net_6ad422db16ac",
        "power_net_8828c890966d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_5a1f578d112a",
        "power_net_bc6b8848cad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2601",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2601",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2602",
          "pin": "1",
          "netId": "power_net_e9a19d60b5ab",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2601",
          "pin": "3",
          "netId": "power_net_e9a19d60b5ab",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2605",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2603",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2602",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2605",
          "pin": "1",
          "netId": "power_net_d27f47724845",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2602",
          "pin": "3",
          "netId": "power_net_d27f47724845",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2607",
          "pin": "1",
          "netId": "power_net_6d982403b080",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2604",
          "pin": "1",
          "netId": "power_net_cfb766cbb94f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2602",
          "pin": "1",
          "netId": "power_net_cfb766cbb94f",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2606",
          "pin": "1",
          "netId": "power_net_6ad422db16ac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Приходят внешние условия безопасности",
      "text": "Внешние контакты и аппаратные блокировки поступают в узел разрешений. Любое условие рассматривается по реальной цепи исходника.",
      "body": "Внешние контакты и аппаратные блокировки поступают в узел разрешений. Любое условие рассматривается по реальной цепи исходника.",
      "nodes": [
        "stop",
        "qualify"
      ],
      "edges": [
        "stop_qualify"
      ],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_d27f47724845",
        "power_net_e9a19d60b5ab"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_J2602",
          "pin": "2",
          "netId": "power_net_d27f47724845",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "12",
          "netId": "power_net_d27f47724845",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "12",
          "netId": "power_net_e9a19d60b5ab",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2601",
          "pin": "2",
          "netId": "power_net_e9a19d60b5ab",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Логика проверяет совокупность условий",
      "text": "Аппаратные элементы требуют выполнения соответствующих условий перед выдачей разрешения. Простого программного запроса недостаточно.",
      "body": "Аппаратные элементы требуют выполнения соответствующих условий перед выдачей разрешения. Простого программного запроса недостаточно.",
      "nodes": [
        "qualify",
        "memory"
      ],
      "edges": [
        "qualify_memory"
      ],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_8828c890966d",
        "power_net_0d67fdbc5a0d",
        "power_net_bc6b8848cad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "8",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "8",
          "netId": "power_net_bc6b8848cad9",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Состояние удерживается триггерами",
      "text": "Триггеры хранят состояние разрешения или отключения до предусмотренного перевзвода.",
      "body": "Триггеры хранят состояние разрешения или отключения до предусмотренного перевзвода.",
      "nodes": [
        "memory"
      ],
      "edges": [],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_6d982403b080",
        "power_net_0d67fdbc5a0d",
        "power_net_67006db669b3",
        "power_net_6ad422db16ac",
        "power_net_8828c890966d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_5a1f578d112a",
        "power_net_bc6b8848cad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2607",
          "pin": "1",
          "netId": "power_net_6d982403b080",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2603",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2606",
          "pin": "1",
          "netId": "power_net_6ad422db16ac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешение выходит за границу узла",
      "text": "Транзисторный интерфейс передаёт сигналы разрешения и запрета другим частям системы питания.",
      "body": "Транзисторный интерфейс передаёт сигналы разрешения и запрета другим частям системы питания.",
      "nodes": [
        "memory",
        "output"
      ],
      "edges": [],
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "netIds": [
        "power_net_9ab95937734d",
        "power_net_e9a19d60b5ab",
        "power_net_67006db669b3",
        "power_net_d27f47724845",
        "power_net_6d982403b080",
        "power_net_cfb766cbb94f",
        "power_net_0d67fdbc5a0d",
        "power_net_6ad422db16ac",
        "power_net_8828c890966d",
        "power_net_317f7ca2e7ff",
        "power_net_3b9ee406a281",
        "power_net_5a1f578d112a",
        "power_net_bc6b8848cad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2601",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2601",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2602",
          "pin": "1",
          "netId": "power_net_e9a19d60b5ab",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2601",
          "pin": "3",
          "netId": "power_net_e9a19d60b5ab",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2605",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2603",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "4",
          "netId": "power_net_67006db669b3",
          "name": "1PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "2PRE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "12",
          "netId": "power_net_67006db669b3",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "14",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2602",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2605",
          "pin": "1",
          "netId": "power_net_d27f47724845",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2602",
          "pin": "3",
          "netId": "power_net_d27f47724845",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2607",
          "pin": "1",
          "netId": "power_net_6d982403b080",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2604",
          "pin": "1",
          "netId": "power_net_cfb766cbb94f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2602",
          "pin": "1",
          "netId": "power_net_cfb766cbb94f",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "1",
          "netId": "power_net_0d67fdbc5a0d",
          "name": "1CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2606",
          "pin": "1",
          "netId": "power_net_6ad422db16ac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "6",
          "netId": "power_net_317f7ca2e7ff",
          "name": "1Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "8",
          "netId": "power_net_3b9ee406a281",
          "name": "2Q_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "13",
          "netId": "power_net_bc6b8848cad9",
          "name": "2CLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
