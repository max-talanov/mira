/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power-primary",
  "title": "Как работает: Формирование основных напряжений",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power-primary",
  "steps": [
    {
      "title": "Дежурное питание контроля",
      "text": "U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.",
      "body": "U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.",
      "nodes": [
        "sheet500"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_478d89e5a433",
        "power_net_bfbd5cdcdcfd",
        "power_net_46d0d8d77ef1",
        "power_net_abd71ae65884"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U501",
          "pin": "1",
          "netId": "power_net_478d89e5a433",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "3",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "6",
          "netId": "power_net_abd71ae65884",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание USB 5 В",
      "text": "U601 преобразует BUS24 в USB5 для интерфейса USB платы.",
      "body": "U601 преобразует BUS24 в USB5 для интерфейса USB платы.",
      "nodes": [
        "sheet600"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_258477dfa0e7",
        "power_net_3b6d6f34935e",
        "power_net_7cbabff32742",
        "power_net_46d0d8d77ef1",
        "power_net_337fb5fa8fe7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U601",
          "pin": "1",
          "netId": "power_net_258477dfa0e7",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "3",
          "netId": "power_net_3b6d6f34935e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "4",
          "netId": "power_net_7cbabff32742",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "6",
          "netId": "power_net_337fb5fa8fe7",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание контроллера 3,3 В",
      "text": "U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.",
      "body": "U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.",
      "nodes": [
        "sheet700"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_4841c007890a",
        "power_net_e9f3329b3263",
        "power_net_1ea84087196f",
        "power_net_c3fa8d82d379",
        "power_net_182b119f7233",
        "power_net_40a542f475fe",
        "power_net_1f7d40ccf183",
        "power_net_67f8b3236d09",
        "power_net_cfa48b7bd3ef",
        "power_net_02417181d3e9",
        "power_net_46d0d8d77ef1",
        "power_net_a05083c8f20a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U701",
          "pin": "1",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "2",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "3",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "4",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "5",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "6",
          "netId": "power_net_e9f3329b3263",
          "name": "BOOT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "7",
          "netId": "power_net_1ea84087196f",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "8",
          "netId": "power_net_c3fa8d82d379",
          "name": "VCC",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "9",
          "netId": "power_net_182b119f7233",
          "name": "BIAS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "10",
          "netId": "power_net_40a542f475fe",
          "name": "RT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "11",
          "netId": "power_net_1f7d40ccf183",
          "name": "SS/TRK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "12",
          "netId": "power_net_67f8b3236d09",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "16",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "18",
          "netId": "power_net_02417181d3e9",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "23",
          "netId": "power_net_a05083c8f20a",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Промежуточное питание ПЛИС",
      "text": "U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.",
      "body": "U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.",
      "nodes": [
        "sheet800"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_97f323bfddf7",
        "power_net_243bfdfe27c1",
        "power_net_f84fdc18b2a1",
        "power_net_02ddea88c03c",
        "power_net_20b613e14cd0",
        "power_net_0661cc4eb426",
        "power_net_a895f7a76079",
        "power_net_0fe1da6e5f9e",
        "power_net_2965499926c8",
        "power_net_08c3817ee687",
        "power_net_46d0d8d77ef1",
        "power_net_032acd3b6ad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U801",
          "pin": "1",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "2",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "3",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "4",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "5",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "6",
          "netId": "power_net_243bfdfe27c1",
          "name": "BOOT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "7",
          "netId": "power_net_f84fdc18b2a1",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "8",
          "netId": "power_net_02ddea88c03c",
          "name": "VCC",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "9",
          "netId": "power_net_20b613e14cd0",
          "name": "BIAS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "10",
          "netId": "power_net_0661cc4eb426",
          "name": "RT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "11",
          "netId": "power_net_a895f7a76079",
          "name": "SS/TRK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "12",
          "netId": "power_net_0fe1da6e5f9e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "16",
          "netId": "power_net_2965499926c8",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "18",
          "netId": "power_net_08c3817ee687",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "23",
          "netId": "power_net_032acd3b6ad9",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Предстабилизатор аналогового питания",
      "text": "U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.",
      "body": "U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.",
      "nodes": [
        "sheet900"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_e844d0e5b632",
        "power_net_5cc01b775688",
        "power_net_b17423d6c3da",
        "power_net_46d0d8d77ef1",
        "power_net_bb6d458571f6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U901",
          "pin": "1",
          "netId": "power_net_e844d0e5b632",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "3",
          "netId": "power_net_5cc01b775688",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "4",
          "netId": "power_net_b17423d6c3da",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "6",
          "netId": "power_net_bb6d458571f6",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Положительное аналоговое питание",
      "text": "U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.",
      "body": "U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.",
      "nodes": [
        "sheet1000"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_6cbfb60c2369",
        "power_net_967875cada1d",
        "power_net_1924d0e843c7",
        "power_net_46d0d8d77ef1",
        "power_net_6217d5a17f1f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1001",
          "pin": "1",
          "netId": "power_net_6cbfb60c2369",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "3",
          "netId": "power_net_967875cada1d",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "4",
          "netId": "power_net_1924d0e843c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "6",
          "netId": "power_net_6217d5a17f1f",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Отрицательное аналоговое питание",
      "text": "U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.",
      "body": "U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.",
      "nodes": [
        "sheet1100"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_f2adc37303b7",
        "power_net_1f3c8d72605a",
        "power_net_0c0796c3402c",
        "power_net_50ecae0bf119",
        "power_net_85fba6457595",
        "power_net_34b1e1d7c8f5",
        "power_net_46d0d8d77ef1",
        "power_net_8c87872e8e46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1101",
          "pin": "1",
          "netId": "power_net_f2adc37303b7",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1101",
          "pin": "3",
          "netId": "power_net_1f3c8d72605a",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "4",
          "netId": "power_net_1f3c8d72605a",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1101",
          "pin": "4",
          "netId": "power_net_0c0796c3402c",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "1",
          "netId": "power_net_50ecae0bf119",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "2",
          "netId": "power_net_85fba6457595",
          "name": "GND",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "3",
          "netId": "power_net_34b1e1d7c8f5",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "6",
          "netId": "power_net_8c87872e8e46",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Дежурное питание контроля",
      "text": "U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.",
      "body": "U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.",
      "nodes": [
        "sheet500"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_478d89e5a433",
        "power_net_bfbd5cdcdcfd",
        "power_net_46d0d8d77ef1",
        "power_net_abd71ae65884"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U501",
          "pin": "1",
          "netId": "power_net_478d89e5a433",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "3",
          "netId": "power_net_bfbd5cdcdcfd",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "4",
          "netId": "power_net_46d0d8d77ef1",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U501",
          "pin": "6",
          "netId": "power_net_abd71ae65884",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание USB 5 В",
      "text": "U601 преобразует BUS24 в USB5 для интерфейса USB платы.",
      "body": "U601 преобразует BUS24 в USB5 для интерфейса USB платы.",
      "nodes": [
        "sheet600"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_258477dfa0e7",
        "power_net_3b6d6f34935e",
        "power_net_7cbabff32742",
        "power_net_46d0d8d77ef1",
        "power_net_337fb5fa8fe7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U601",
          "pin": "1",
          "netId": "power_net_258477dfa0e7",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "3",
          "netId": "power_net_3b6d6f34935e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "4",
          "netId": "power_net_7cbabff32742",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "6",
          "netId": "power_net_337fb5fa8fe7",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание контроллера 3,3 В",
      "text": "U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.",
      "body": "U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.",
      "nodes": [
        "sheet700"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_4841c007890a",
        "power_net_e9f3329b3263",
        "power_net_1ea84087196f",
        "power_net_c3fa8d82d379",
        "power_net_182b119f7233",
        "power_net_40a542f475fe",
        "power_net_1f7d40ccf183",
        "power_net_67f8b3236d09",
        "power_net_cfa48b7bd3ef",
        "power_net_02417181d3e9",
        "power_net_46d0d8d77ef1",
        "power_net_a05083c8f20a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U701",
          "pin": "1",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "2",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "3",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "4",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "5",
          "netId": "power_net_4841c007890a",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "6",
          "netId": "power_net_e9f3329b3263",
          "name": "BOOT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "7",
          "netId": "power_net_1ea84087196f",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "8",
          "netId": "power_net_c3fa8d82d379",
          "name": "VCC",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "9",
          "netId": "power_net_182b119f7233",
          "name": "BIAS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "10",
          "netId": "power_net_40a542f475fe",
          "name": "RT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "11",
          "netId": "power_net_1f7d40ccf183",
          "name": "SS/TRK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "12",
          "netId": "power_net_67f8b3236d09",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "16",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "18",
          "netId": "power_net_02417181d3e9",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U701",
          "pin": "23",
          "netId": "power_net_a05083c8f20a",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Промежуточное питание ПЛИС",
      "text": "U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.",
      "body": "U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.",
      "nodes": [
        "sheet800"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_97f323bfddf7",
        "power_net_243bfdfe27c1",
        "power_net_f84fdc18b2a1",
        "power_net_02ddea88c03c",
        "power_net_20b613e14cd0",
        "power_net_0661cc4eb426",
        "power_net_a895f7a76079",
        "power_net_0fe1da6e5f9e",
        "power_net_2965499926c8",
        "power_net_08c3817ee687",
        "power_net_46d0d8d77ef1",
        "power_net_032acd3b6ad9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U801",
          "pin": "1",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "2",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "3",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "4",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "5",
          "netId": "power_net_97f323bfddf7",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "6",
          "netId": "power_net_243bfdfe27c1",
          "name": "BOOT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "7",
          "netId": "power_net_f84fdc18b2a1",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "8",
          "netId": "power_net_02ddea88c03c",
          "name": "VCC",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "9",
          "netId": "power_net_20b613e14cd0",
          "name": "BIAS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "10",
          "netId": "power_net_0661cc4eb426",
          "name": "RT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "11",
          "netId": "power_net_a895f7a76079",
          "name": "SS/TRK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "12",
          "netId": "power_net_0fe1da6e5f9e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "16",
          "netId": "power_net_2965499926c8",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "18",
          "netId": "power_net_08c3817ee687",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "20",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "21",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "22",
          "netId": "power_net_46d0d8d77ef1",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U801",
          "pin": "23",
          "netId": "power_net_032acd3b6ad9",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Предстабилизатор аналогового питания",
      "text": "U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.",
      "body": "U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.",
      "nodes": [
        "sheet900"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_e844d0e5b632",
        "power_net_5cc01b775688",
        "power_net_b17423d6c3da",
        "power_net_46d0d8d77ef1",
        "power_net_bb6d458571f6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U901",
          "pin": "1",
          "netId": "power_net_e844d0e5b632",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "3",
          "netId": "power_net_5cc01b775688",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "4",
          "netId": "power_net_b17423d6c3da",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U901",
          "pin": "6",
          "netId": "power_net_bb6d458571f6",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Положительное аналоговое питание",
      "text": "U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.",
      "body": "U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.",
      "nodes": [
        "sheet1000"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_6cbfb60c2369",
        "power_net_967875cada1d",
        "power_net_1924d0e843c7",
        "power_net_46d0d8d77ef1",
        "power_net_6217d5a17f1f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1001",
          "pin": "1",
          "netId": "power_net_6cbfb60c2369",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "3",
          "netId": "power_net_967875cada1d",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "4",
          "netId": "power_net_1924d0e843c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1001",
          "pin": "6",
          "netId": "power_net_6217d5a17f1f",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Отрицательное аналоговое питание",
      "text": "U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.",
      "body": "U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.",
      "nodes": [
        "sheet1100"
      ],
      "edges": [],
      "sceneId": "power-primary",
      "netIds": [
        "power_net_f2adc37303b7",
        "power_net_1f3c8d72605a",
        "power_net_0c0796c3402c",
        "power_net_50ecae0bf119",
        "power_net_85fba6457595",
        "power_net_34b1e1d7c8f5",
        "power_net_46d0d8d77ef1",
        "power_net_8c87872e8e46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1101",
          "pin": "1",
          "netId": "power_net_f2adc37303b7",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1101",
          "pin": "3",
          "netId": "power_net_1f3c8d72605a",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "4",
          "netId": "power_net_1f3c8d72605a",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1101",
          "pin": "4",
          "netId": "power_net_0c0796c3402c",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "1",
          "netId": "power_net_50ecae0bf119",
          "name": "CB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "2",
          "netId": "power_net_85fba6457595",
          "name": "GND",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "3",
          "netId": "power_net_34b1e1d7c8f5",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1102",
          "pin": "6",
          "netId": "power_net_8c87872e8e46",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
