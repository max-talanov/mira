/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3200_PM_NEGATIVE_OVERCURRENT",
  "title": "Как работает: Защита отрицательной шины по току",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
  "steps": [
    {
      "title": "Задаётся порог отрицательного тока",
      "text": "Делитель и фильтрация формируют аппаратный порог для измерения отрицательной шины.",
      "body": "Делитель и фильтрация формируют аппаратный порог для измерения отрицательной шины.",
      "nodes": [
        "threshold"
      ],
      "edges": [],
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_4aeb4892b398",
        "power_net_cfd922d13086"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3203",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3202",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3201",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3203",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3201",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3202",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3201",
          "pin": "2",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измерение сравнивается с порогом",
      "text": "Компаратор получает подготовленный сигнал тока и порог. Возможное превышение формирует событие токовой защиты.",
      "body": "Компаратор получает подготовленный сигнал тока и порог. Возможное превышение формирует событие токовой защиты.",
      "nodes": [
        "threshold",
        "compare"
      ],
      "edges": [
        "threshold_compare"
      ],
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "netIds": [
        "power_net_4aeb4892b398",
        "power_net_cfd922d13086"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3203",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3201",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "5",
          "netId": "power_net_cfd922d13086",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3202",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3201",
          "pin": "2",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Результат поступает в защиту",
      "text": "Выходная цепь компаратора связана с общей логикой аварий. Это быстрый аппаратный канал, отдельный от опроса телеметрии.",
      "body": "Выходная цепь компаратора связана с общей логикой аварий. Это быстрый аппаратный канал, отдельный от опроса телеметрии.",
      "nodes": [
        "compare"
      ],
      "edges": [],
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "netIds": [
        "power_net_2aea9a339bff",
        "power_net_4aeb4892b398",
        "power_net_67006db669b3",
        "power_net_860af4e4ed8e",
        "power_net_cfd922d13086",
        "power_net_d1bea8e58439",
        "power_net_deb9e24e4b28"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3201",
          "pin": "1",
          "netId": "power_net_2aea9a339bff",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "4",
          "netId": "power_net_860af4e4ed8e",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "5",
          "netId": "power_net_cfd922d13086",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "13",
          "netId": "power_net_d1bea8e58439",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "14",
          "netId": "power_net_deb9e24e4b28",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Задаётся порог отрицательного тока",
      "text": "Делитель и фильтрация формируют аппаратный порог для измерения отрицательной шины.",
      "body": "Делитель и фильтрация формируют аппаратный порог для измерения отрицательной шины.",
      "nodes": [
        "threshold"
      ],
      "edges": [],
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_4aeb4892b398",
        "power_net_cfd922d13086"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3203",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3202",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3201",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3203",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3201",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3202",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3201",
          "pin": "2",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измерение сравнивается с порогом",
      "text": "Компаратор получает подготовленный сигнал тока и порог. Возможное превышение формирует событие токовой защиты.",
      "body": "Компаратор получает подготовленный сигнал тока и порог. Возможное превышение формирует событие токовой защиты.",
      "nodes": [
        "threshold",
        "compare"
      ],
      "edges": [
        "threshold_compare"
      ],
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "netIds": [
        "power_net_4aeb4892b398",
        "power_net_cfd922d13086"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3203",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3201",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "5",
          "netId": "power_net_cfd922d13086",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3202",
          "pin": "1",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3201",
          "pin": "2",
          "netId": "power_net_cfd922d13086",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Результат поступает в защиту",
      "text": "Выходная цепь компаратора связана с общей логикой аварий. Это быстрый аппаратный канал, отдельный от опроса телеметрии.",
      "body": "Выходная цепь компаратора связана с общей логикой аварий. Это быстрый аппаратный канал, отдельный от опроса телеметрии.",
      "nodes": [
        "compare"
      ],
      "edges": [],
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "netIds": [
        "power_net_2aea9a339bff",
        "power_net_4aeb4892b398",
        "power_net_67006db669b3",
        "power_net_860af4e4ed8e",
        "power_net_cfd922d13086",
        "power_net_d1bea8e58439",
        "power_net_deb9e24e4b28"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3201",
          "pin": "1",
          "netId": "power_net_2aea9a339bff",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "4",
          "netId": "power_net_860af4e4ed8e",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "5",
          "netId": "power_net_cfd922d13086",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "13",
          "netId": "power_net_d1bea8e58439",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "14",
          "netId": "power_net_deb9e24e4b28",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
