/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1200_DAC_FPGA_CONTROL_INTERFACE",
  "title": "Как работает: Управление аналоговыми источниками",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
  "steps": [
    {
      "title": "ПЛИС формирует команды ЦАП",
      "text": "U500 выдаёт последовательные сигналы управления банком аналоговых источников. Отдельные линии выбора определяют адресуемое устройство.",
      "body": "U500 выдаёт последовательные сигналы управления банком аналоговых источников. Отдельные линии выбора определяют адресуемое устройство.",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "netIds": [
        "control_net_3230bba6e369",
        "control_net_08fdee08456b",
        "control_net_9872096d1603",
        "control_net_5fd8dcc5fbb4",
        "control_net_dec8aaf78baf",
        "control_net_7208b29a2b1c",
        "control_net_fd223a19128e",
        "control_net_1ac6761e03ed",
        "control_net_937ff9979dc3",
        "control_net_85ba8fc9e715",
        "control_net_ac5068fd8652",
        "control_net_ca03fb089228",
        "control_net_1d078f5152c1",
        "control_net_8543c7028353",
        "control_net_fd8710ab620d",
        "control_net_4dea48708eb3",
        "control_net_efab486ffaed",
        "control_net_7f616706cf93",
        "control_net_8baeadc9d1f8",
        "control_net_da58769d7620",
        "control_net_b467eac10258",
        "control_net_a3c162bcb298",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_fe5724fe2bab",
        "control_net_b02072f17830",
        "control_net_82b207235505",
        "control_net_92cfc687656d",
        "control_net_bae01a82acc2",
        "control_net_168076ddc771",
        "control_net_def0213ce26f",
        "control_net_79395ecc284b",
        "control_net_410016c949d5",
        "control_net_71168801242c",
        "control_net_e542b9e16418",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf",
        "control_net_ef7dcf4c5ac1",
        "control_net_07a2fafb5ee8",
        "control_net_63296c08fb96",
        "control_net_0e6757f456c8",
        "control_net_fe9a6d2314d3",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_2b2d32129563",
        "control_net_63eb0399a909",
        "control_net_6d399f5ab100",
        "control_net_3216c2600ec6",
        "control_net_633521e6d31e",
        "control_net_0fed13c85d5f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA1",
          "netId": "control_net_3230bba6e369",
          "name": "IO_L7P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA3",
          "netId": "control_net_08fdee08456b",
          "name": "IO_L9N_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA4",
          "netId": "control_net_9872096d1603",
          "name": "IO_L11N_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA5",
          "netId": "control_net_5fd8dcc5fbb4",
          "name": "IO_L10P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA6",
          "netId": "control_net_dec8aaf78baf",
          "name": "IO_L18N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA8",
          "netId": "control_net_7208b29a2b1c",
          "name": "IO_L22P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB1",
          "netId": "control_net_fd223a19128e",
          "name": "IO_L7N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB2",
          "netId": "control_net_1ac6761e03ed",
          "name": "IO_L8N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB3",
          "netId": "control_net_937ff9979dc3",
          "name": "IO_L8P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB5",
          "netId": "control_net_85ba8fc9e715",
          "name": "IO_L10N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB6",
          "netId": "control_net_ac5068fd8652",
          "name": "IO_L20N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB7",
          "netId": "control_net_ca03fb089228",
          "name": "IO_L20P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB8",
          "netId": "control_net_1d078f5152c1",
          "name": "IO_L22N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R4",
          "netId": "control_net_4dea48708eb3",
          "name": "IO_L13P_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R6",
          "netId": "control_net_efab486ffaed",
          "name": "IO_L17P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T4",
          "netId": "control_net_da58769d7620",
          "name": "IO_L13N_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T5",
          "netId": "control_net_b467eac10258",
          "name": "IO_L14P_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T6",
          "netId": "control_net_a3c162bcb298",
          "name": "IO_L17N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U3",
          "netId": "control_net_fe5724fe2bab",
          "name": "IO_L6P_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U5",
          "netId": "control_net_b02072f17830",
          "name": "IO_L14N_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U6",
          "netId": "control_net_82b207235505",
          "name": "IO_L16P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U7",
          "netId": "control_net_92cfc687656d",
          "name": "IO_25_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V3",
          "netId": "control_net_168076ddc771",
          "name": "IO_L6N_T0_VREF_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V4",
          "netId": "control_net_def0213ce26f",
          "name": "IO_L12P_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V5",
          "netId": "control_net_79395ecc284b",
          "name": "IO_L16N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V7",
          "netId": "control_net_410016c949d5",
          "name": "IO_L19P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V8",
          "netId": "control_net_71168801242c",
          "name": "IO_L21N_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V9",
          "netId": "control_net_e542b9e16418",
          "name": "IO_L21P_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W4",
          "netId": "control_net_ef7dcf4c5ac1",
          "name": "IO_L12N_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W5",
          "netId": "control_net_07a2fafb5ee8",
          "name": "IO_L15N_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W6",
          "netId": "control_net_63296c08fb96",
          "name": "IO_L15P_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W7",
          "netId": "control_net_0e6757f456c8",
          "name": "IO_L19N_T3_VREF_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W9",
          "netId": "control_net_fe9a6d2314d3",
          "name": "IO_L24P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y3",
          "netId": "control_net_2b2d32129563",
          "name": "IO_L9P_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y4",
          "netId": "control_net_63eb0399a909",
          "name": "IO_L11P_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y6",
          "netId": "control_net_6d399f5ab100",
          "name": "IO_L18P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y7",
          "netId": "control_net_3216c2600ec6",
          "name": "IO_L23N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y8",
          "netId": "control_net_633521e6d31e",
          "name": "IO_L23P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y9",
          "netId": "control_net_0fed13c85d5f",
          "name": "IO_L24N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Состояние при запуске определено",
      "text": "Резисторы задают начальные уровни выбора, сброса и фиксации. На схеме подсвечиваются реальные линии; история не приписывает им произвольные логические значения.",
      "body": "Резисторы задают начальные уровни выбора, сброса и фиксации. На схеме подсвечиваются реальные линии; история не приписывает им произвольные логические значения.",
      "nodes": [
        "bias",
        "fpga"
      ],
      "edges": [
        "fpga_bias"
      ],
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_0d0a126b05bc",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_fad82bf41bcf",
        "control_net_596ada6680f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1203",
          "pin": "1",
          "netId": "control_net_8543c7028353",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1206",
          "pin": "1",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1207",
          "pin": "1",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1200",
          "pin": "1",
          "netId": "control_net_90accaec6322",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1201",
          "pin": "1",
          "netId": "control_net_bae01a82acc2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1202",
          "pin": "1",
          "netId": "control_net_fd8710ab620d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1204",
          "pin": "1",
          "netId": "control_net_fad82bf41bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1205",
          "pin": "1",
          "netId": "control_net_596ada6680f2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Настройки продолжаются к источникам",
      "text": "Цифровые команды идут к листам ЦАП. Само аналоговое напряжение создаётся там, после приёма соответствующей команды.",
      "body": "Цифровые команды идут к листам ЦАП. Само аналоговое напряжение создаётся там, после приёма соответствующей команды.",
      "nodes": [
        "fpga",
        "bias"
      ],
      "edges": [
        "fpga_bias"
      ],
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_0d0a126b05bc",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_fad82bf41bcf",
        "control_net_596ada6680f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1203",
          "pin": "1",
          "netId": "control_net_8543c7028353",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1206",
          "pin": "1",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1207",
          "pin": "1",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1200",
          "pin": "1",
          "netId": "control_net_90accaec6322",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1201",
          "pin": "1",
          "netId": "control_net_bae01a82acc2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1202",
          "pin": "1",
          "netId": "control_net_fd8710ab620d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1204",
          "pin": "1",
          "netId": "control_net_fad82bf41bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1205",
          "pin": "1",
          "netId": "control_net_596ada6680f2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "ПЛИС формирует команды ЦАП",
      "text": "U500 выдаёт последовательные сигналы управления банком аналоговых источников. Отдельные линии выбора определяют адресуемое устройство.",
      "body": "U500 выдаёт последовательные сигналы управления банком аналоговых источников. Отдельные линии выбора определяют адресуемое устройство.",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "netIds": [
        "control_net_3230bba6e369",
        "control_net_08fdee08456b",
        "control_net_9872096d1603",
        "control_net_5fd8dcc5fbb4",
        "control_net_dec8aaf78baf",
        "control_net_7208b29a2b1c",
        "control_net_fd223a19128e",
        "control_net_1ac6761e03ed",
        "control_net_937ff9979dc3",
        "control_net_85ba8fc9e715",
        "control_net_ac5068fd8652",
        "control_net_ca03fb089228",
        "control_net_1d078f5152c1",
        "control_net_8543c7028353",
        "control_net_fd8710ab620d",
        "control_net_4dea48708eb3",
        "control_net_efab486ffaed",
        "control_net_7f616706cf93",
        "control_net_8baeadc9d1f8",
        "control_net_da58769d7620",
        "control_net_b467eac10258",
        "control_net_a3c162bcb298",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_fe5724fe2bab",
        "control_net_b02072f17830",
        "control_net_82b207235505",
        "control_net_92cfc687656d",
        "control_net_bae01a82acc2",
        "control_net_168076ddc771",
        "control_net_def0213ce26f",
        "control_net_79395ecc284b",
        "control_net_410016c949d5",
        "control_net_71168801242c",
        "control_net_e542b9e16418",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf",
        "control_net_ef7dcf4c5ac1",
        "control_net_07a2fafb5ee8",
        "control_net_63296c08fb96",
        "control_net_0e6757f456c8",
        "control_net_fe9a6d2314d3",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_2b2d32129563",
        "control_net_63eb0399a909",
        "control_net_6d399f5ab100",
        "control_net_3216c2600ec6",
        "control_net_633521e6d31e",
        "control_net_0fed13c85d5f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "AA1",
          "netId": "control_net_3230bba6e369",
          "name": "IO_L7P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA3",
          "netId": "control_net_08fdee08456b",
          "name": "IO_L9N_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA4",
          "netId": "control_net_9872096d1603",
          "name": "IO_L11N_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA5",
          "netId": "control_net_5fd8dcc5fbb4",
          "name": "IO_L10P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA6",
          "netId": "control_net_dec8aaf78baf",
          "name": "IO_L18N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA8",
          "netId": "control_net_7208b29a2b1c",
          "name": "IO_L22P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB1",
          "netId": "control_net_fd223a19128e",
          "name": "IO_L7N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB2",
          "netId": "control_net_1ac6761e03ed",
          "name": "IO_L8N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB3",
          "netId": "control_net_937ff9979dc3",
          "name": "IO_L8P_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB5",
          "netId": "control_net_85ba8fc9e715",
          "name": "IO_L10N_T1_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB6",
          "netId": "control_net_ac5068fd8652",
          "name": "IO_L20N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB7",
          "netId": "control_net_ca03fb089228",
          "name": "IO_L20P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB8",
          "netId": "control_net_1d078f5152c1",
          "name": "IO_L22N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R4",
          "netId": "control_net_4dea48708eb3",
          "name": "IO_L13P_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R6",
          "netId": "control_net_efab486ffaed",
          "name": "IO_L17P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T4",
          "netId": "control_net_da58769d7620",
          "name": "IO_L13N_T2_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T5",
          "netId": "control_net_b467eac10258",
          "name": "IO_L14P_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T6",
          "netId": "control_net_a3c162bcb298",
          "name": "IO_L17N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U3",
          "netId": "control_net_fe5724fe2bab",
          "name": "IO_L6P_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U5",
          "netId": "control_net_b02072f17830",
          "name": "IO_L14N_T2_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U6",
          "netId": "control_net_82b207235505",
          "name": "IO_L16P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U7",
          "netId": "control_net_92cfc687656d",
          "name": "IO_25_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V3",
          "netId": "control_net_168076ddc771",
          "name": "IO_L6N_T0_VREF_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V4",
          "netId": "control_net_def0213ce26f",
          "name": "IO_L12P_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V5",
          "netId": "control_net_79395ecc284b",
          "name": "IO_L16N_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V7",
          "netId": "control_net_410016c949d5",
          "name": "IO_L19P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V8",
          "netId": "control_net_71168801242c",
          "name": "IO_L21N_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V9",
          "netId": "control_net_e542b9e16418",
          "name": "IO_L21P_T3_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W4",
          "netId": "control_net_ef7dcf4c5ac1",
          "name": "IO_L12N_T1_MRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W5",
          "netId": "control_net_07a2fafb5ee8",
          "name": "IO_L15N_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W6",
          "netId": "control_net_63296c08fb96",
          "name": "IO_L15P_T2_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W7",
          "netId": "control_net_0e6757f456c8",
          "name": "IO_L19N_T3_VREF_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W9",
          "netId": "control_net_fe9a6d2314d3",
          "name": "IO_L24P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y3",
          "netId": "control_net_2b2d32129563",
          "name": "IO_L9P_T1_DQS_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y4",
          "netId": "control_net_63eb0399a909",
          "name": "IO_L11P_T1_SRCC_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y6",
          "netId": "control_net_6d399f5ab100",
          "name": "IO_L18P_T2_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y7",
          "netId": "control_net_3216c2600ec6",
          "name": "IO_L23N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y8",
          "netId": "control_net_633521e6d31e",
          "name": "IO_L23P_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y9",
          "netId": "control_net_0fed13c85d5f",
          "name": "IO_L24N_T3_34",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Состояние при запуске определено",
      "text": "Резисторы задают начальные уровни выбора, сброса и фиксации. На схеме подсвечиваются реальные линии; история не приписывает им произвольные логические значения.",
      "body": "Резисторы задают начальные уровни выбора, сброса и фиксации. На схеме подсвечиваются реальные линии; история не приписывает им произвольные логические значения.",
      "nodes": [
        "bias",
        "fpga"
      ],
      "edges": [
        "fpga_bias"
      ],
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_0d0a126b05bc",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_fad82bf41bcf",
        "control_net_596ada6680f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1203",
          "pin": "1",
          "netId": "control_net_8543c7028353",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1206",
          "pin": "1",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1207",
          "pin": "1",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1200",
          "pin": "1",
          "netId": "control_net_90accaec6322",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1201",
          "pin": "1",
          "netId": "control_net_bae01a82acc2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1202",
          "pin": "1",
          "netId": "control_net_fd8710ab620d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1204",
          "pin": "1",
          "netId": "control_net_fad82bf41bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1205",
          "pin": "1",
          "netId": "control_net_596ada6680f2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Настройки продолжаются к источникам",
      "text": "Цифровые команды идут к листам ЦАП. Само аналоговое напряжение создаётся там, после приёма соответствующей команды.",
      "body": "Цифровые команды идут к листам ЦАП. Само аналоговое напряжение создаётся там, после приёма соответствующей команды.",
      "nodes": [
        "fpga",
        "bias"
      ],
      "edges": [
        "fpga_bias"
      ],
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_0d0a126b05bc",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_fad82bf41bcf",
        "control_net_596ada6680f2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1203",
          "pin": "1",
          "netId": "control_net_8543c7028353",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1206",
          "pin": "1",
          "netId": "control_net_0d0a126b05bc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W1",
          "netId": "control_net_0d0a126b05bc",
          "name": "IO_L5P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1207",
          "pin": "1",
          "netId": "control_net_a2017f4fe37b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y1",
          "netId": "control_net_a2017f4fe37b",
          "name": "IO_L5N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1200",
          "pin": "1",
          "netId": "control_net_90accaec6322",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1201",
          "pin": "1",
          "netId": "control_net_bae01a82acc2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1202",
          "pin": "1",
          "netId": "control_net_fd8710ab620d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1204",
          "pin": "1",
          "netId": "control_net_fad82bf41bcf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W2",
          "netId": "control_net_fad82bf41bcf",
          "name": "IO_L4P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1205",
          "pin": "1",
          "netId": "control_net_596ada6680f2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y2",
          "netId": "control_net_596ada6680f2",
          "name": "IO_L4N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
