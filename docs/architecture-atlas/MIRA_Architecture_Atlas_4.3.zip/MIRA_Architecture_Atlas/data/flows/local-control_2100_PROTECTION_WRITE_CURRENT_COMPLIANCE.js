/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "title": "Как работает: Ограничение напряжения и тока записи",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "steps": [
    {
      "title": "Выбираются напряжение и предел тока",
      "text": "Аналоговые селекторы подают команды активной операции в общий регулируемый источник. Значения задаются предшествующими ЦАП.",
      "body": "Аналоговые селекторы подают команды активной операции в общий регулируемый источник. Значения задаются предшествующими ЦАП.",
      "nodes": [
        "commands"
      ],
      "edges": [],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_c716783a5090",
        "control_net_87568f65b103",
        "control_net_2e82cb98585d",
        "control_net_884dc726c5ee",
        "control_net_eafb3ab75ceb",
        "control_net_e5381212c338",
        "control_net_1f8df2d46142",
        "control_net_55226bb23b92",
        "control_net_c2d31e9a7d3a",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_6f005443ad9c",
        "control_net_c3b957dc2a05",
        "control_net_a6fb2d1ff68e",
        "control_net_ca37f2f49804",
        "control_net_cac6d1065fe3",
        "control_net_e5df7ddd81fb",
        "control_net_53c8d7c2e621",
        "control_net_ee356dd4a609"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R2108",
          "pin": "1",
          "netId": "control_net_c716783a5090",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "7",
          "netId": "control_net_c716783a5090",
          "name": "S4A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "10",
          "netId": "control_net_c716783a5090",
          "name": "S4B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2105",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2106",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2107",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2108",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "14",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2100",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2109",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2115",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2105",
          "pin": "1",
          "netId": "control_net_884dc726c5ee",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "4",
          "netId": "control_net_884dc726c5ee",
          "name": "S1A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "13",
          "netId": "control_net_884dc726c5ee",
          "name": "S1B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2106",
          "pin": "1",
          "netId": "control_net_eafb3ab75ceb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "5",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "12",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2101",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2110",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2116",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2107",
          "pin": "1",
          "netId": "control_net_1f8df2d46142",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "6",
          "netId": "control_net_1f8df2d46142",
          "name": "S3A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "11",
          "netId": "control_net_1f8df2d46142",
          "name": "S3B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "8",
          "netId": "control_net_55226bb23b92",
          "name": "DA",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "9",
          "netId": "control_net_c2d31e9a7d3a",
          "name": "DB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "1",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "16",
          "netId": "control_net_4cbb94b58c81",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "8",
          "netId": "control_net_e5df7ddd81fb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2100",
          "pin": "1",
          "netId": "control_net_e5df7ddd81fb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2100",
          "pin": "2",
          "netId": "control_net_ee356dd4a609",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измеряется фактический ток",
      "text": "Кельвиновское измерение и усилители формируют сигнал обратной связи по току источника. Он участвует в регулировании и наблюдении.",
      "body": "Кельвиновское измерение и усилители формируют сигнал обратной связи по току источника. Он участвует в регулировании и наблюдении.",
      "nodes": [
        "sense",
        "control"
      ],
      "edges": [
        "sense_control"
      ],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_87568f65b103",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_edfd1164669d",
        "control_net_13ff4635cb1b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2104",
          "pin": "1",
          "netId": "control_net_87568f65b103",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "4",
          "netId": "control_net_5b5c009b1508",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "7",
          "netId": "control_net_5b5c009b1508",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2128",
          "pin": "2",
          "netId": "control_net_5b5c009b1508",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "1",
          "netId": "control_net_5b5c009b1508",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "6",
          "netId": "control_net_81a816b03060",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2103",
          "pin": "2",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2129",
          "pin": "2",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2103",
          "pin": "1",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "7",
          "netId": "control_net_edfd1164669d",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2117",
          "pin": "1",
          "netId": "control_net_edfd1164669d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "1",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор управляет выходом",
      "text": "Усилители сравнивают команды и обратную связь; выходной усилитель подаёт регулируемый сигнал в последующую маршрутизацию.",
      "body": "Усилители сравнивают команды и обратную связь; выходной усилитель подаёт регулируемый сигнал в последующую маршрутизацию.",
      "nodes": [
        "commands",
        "control",
        "drive"
      ],
      "edges": [
        "commands_control",
        "control_drive"
      ],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_87568f65b103",
        "control_net_ee356dd4a609",
        "control_net_13ff4635cb1b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R2105",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2106",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2107",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2108",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2100",
          "pin": "2",
          "netId": "control_net_ee356dd4a609",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2139",
          "pin": "1",
          "netId": "control_net_ee356dd4a609",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2101",
          "pin": "3",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Между операциями состояние ограничивается",
      "text": "Цепи ограничения и сброса удерживают состояние регулятора в предусмотренных схемой пределах при смене режима.",
      "body": "Цепи ограничения и сброса удерживают состояние регулятора в предусмотренных схемой пределах при смене режима.",
      "nodes": [
        "reset",
        "control"
      ],
      "edges": [
        "control_reset"
      ],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_c27d9f1c5177",
        "control_net_13ff4635cb1b",
        "control_net_f58cc678464d",
        "control_net_2860e727c5a6",
        "control_net_2b71697338af",
        "control_net_4b7c47b539e3",
        "control_net_f423ec67f84e",
        "control_net_affe5a5b3b9b",
        "control_net_1d37a4d602ee",
        "control_net_10974d5ea208",
        "control_net_91d1f89a3eb2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R2139",
          "pin": "2",
          "netId": "control_net_c27d9f1c5177",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2101",
          "pin": "1",
          "netId": "control_net_c27d9f1c5177",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2102",
          "pin": "1",
          "netId": "control_net_c27d9f1c5177",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2102",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2103",
          "pin": "1",
          "netId": "control_net_13ff4635cb1b",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "9",
          "netId": "control_net_f58cc678464d",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2121",
          "pin": "2",
          "netId": "control_net_f58cc678464d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2100",
          "pin": "1",
          "netId": "control_net_f58cc678464d",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "8",
          "netId": "control_net_2860e727c5a6",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2100",
          "pin": "3",
          "netId": "control_net_2860e727c5a6",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "13",
          "netId": "control_net_2b71697338af",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2122",
          "pin": "2",
          "netId": "control_net_2b71697338af",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2101",
          "pin": "1",
          "netId": "control_net_2b71697338af",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "14",
          "netId": "control_net_4b7c47b539e3",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2101",
          "pin": "3",
          "netId": "control_net_4b7c47b539e3",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "9",
          "netId": "control_net_f423ec67f84e",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2131",
          "pin": "2",
          "netId": "control_net_f423ec67f84e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2102",
          "pin": "1",
          "netId": "control_net_f423ec67f84e",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "8",
          "netId": "control_net_affe5a5b3b9b",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2102",
          "pin": "3",
          "netId": "control_net_affe5a5b3b9b",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "13",
          "netId": "control_net_1d37a4d602ee",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2132",
          "pin": "2",
          "netId": "control_net_1d37a4d602ee",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2103",
          "pin": "2",
          "netId": "control_net_1d37a4d602ee",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "14",
          "netId": "control_net_10974d5ea208",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2103",
          "pin": "3",
          "netId": "control_net_10974d5ea208",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2121",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2122",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2123",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2124",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2100",
          "pin": "2",
          "netId": "control_net_91d1f89a3eb2",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2101",
          "pin": "2",
          "netId": "control_net_91d1f89a3eb2",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Выбираются напряжение и предел тока",
      "text": "Аналоговые селекторы подают команды активной операции в общий регулируемый источник. Значения задаются предшествующими ЦАП.",
      "body": "Аналоговые селекторы подают команды активной операции в общий регулируемый источник. Значения задаются предшествующими ЦАП.",
      "nodes": [
        "commands"
      ],
      "edges": [],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_c716783a5090",
        "control_net_87568f65b103",
        "control_net_2e82cb98585d",
        "control_net_884dc726c5ee",
        "control_net_eafb3ab75ceb",
        "control_net_e5381212c338",
        "control_net_1f8df2d46142",
        "control_net_55226bb23b92",
        "control_net_c2d31e9a7d3a",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_6f005443ad9c",
        "control_net_c3b957dc2a05",
        "control_net_a6fb2d1ff68e",
        "control_net_ca37f2f49804",
        "control_net_cac6d1065fe3",
        "control_net_e5df7ddd81fb",
        "control_net_53c8d7c2e621",
        "control_net_ee356dd4a609"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R2108",
          "pin": "1",
          "netId": "control_net_c716783a5090",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "7",
          "netId": "control_net_c716783a5090",
          "name": "S4A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "10",
          "netId": "control_net_c716783a5090",
          "name": "S4B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2105",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2106",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2107",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2108",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "14",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2100",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2109",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2115",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2105",
          "pin": "1",
          "netId": "control_net_884dc726c5ee",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "4",
          "netId": "control_net_884dc726c5ee",
          "name": "S1A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "13",
          "netId": "control_net_884dc726c5ee",
          "name": "S1B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2106",
          "pin": "1",
          "netId": "control_net_eafb3ab75ceb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "5",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "12",
          "netId": "control_net_eafb3ab75ceb",
          "name": "S2B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2101",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2110",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2116",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2107",
          "pin": "1",
          "netId": "control_net_1f8df2d46142",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "6",
          "netId": "control_net_1f8df2d46142",
          "name": "S3A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "11",
          "netId": "control_net_1f8df2d46142",
          "name": "S3B",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "8",
          "netId": "control_net_55226bb23b92",
          "name": "DA",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "9",
          "netId": "control_net_c2d31e9a7d3a",
          "name": "DB",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "1",
          "netId": "control_net_68c0b1b9f3d9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "16",
          "netId": "control_net_4cbb94b58c81",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2103",
          "pin": "2",
          "netId": "control_net_6f005443ad9c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "4",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "5",
          "netId": "control_net_a6fb2d1ff68e",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "6",
          "netId": "control_net_ca37f2f49804",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "7",
          "netId": "control_net_cac6d1065fe3",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "8",
          "netId": "control_net_e5df7ddd81fb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2100",
          "pin": "1",
          "netId": "control_net_e5df7ddd81fb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2100",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2100",
          "pin": "2",
          "netId": "control_net_ee356dd4a609",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измеряется фактический ток",
      "text": "Кельвиновское измерение и усилители формируют сигнал обратной связи по току источника. Он участвует в регулировании и наблюдении.",
      "body": "Кельвиновское измерение и усилители формируют сигнал обратной связи по току источника. Он участвует в регулировании и наблюдении.",
      "nodes": [
        "sense",
        "control"
      ],
      "edges": [
        "sense_control"
      ],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_87568f65b103",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_edfd1164669d",
        "control_net_13ff4635cb1b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2104",
          "pin": "1",
          "netId": "control_net_87568f65b103",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "4",
          "netId": "control_net_5b5c009b1508",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "7",
          "netId": "control_net_5b5c009b1508",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2128",
          "pin": "2",
          "netId": "control_net_5b5c009b1508",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "1",
          "netId": "control_net_5b5c009b1508",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "6",
          "netId": "control_net_81a816b03060",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2103",
          "pin": "2",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2129",
          "pin": "2",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2103",
          "pin": "1",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2104",
          "pin": "7",
          "netId": "control_net_edfd1164669d",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2117",
          "pin": "1",
          "netId": "control_net_edfd1164669d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2109",
          "pin": "1",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор управляет выходом",
      "text": "Усилители сравнивают команды и обратную связь; выходной усилитель подаёт регулируемый сигнал в последующую маршрутизацию.",
      "body": "Усилители сравнивают команды и обратную связь; выходной усилитель подаёт регулируемый сигнал в последующую маршрутизацию.",
      "nodes": [
        "commands",
        "control",
        "drive"
      ],
      "edges": [
        "commands_control",
        "control_drive"
      ],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_87568f65b103",
        "control_net_ee356dd4a609",
        "control_net_13ff4635cb1b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R2105",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2106",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2107",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2108",
          "pin": "2",
          "netId": "control_net_87568f65b103",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "12",
          "netId": "control_net_87568f65b103",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2100",
          "pin": "2",
          "netId": "control_net_ee356dd4a609",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2139",
          "pin": "1",
          "netId": "control_net_ee356dd4a609",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2101",
          "pin": "3",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Между операциями состояние ограничивается",
      "text": "Цепи ограничения и сброса удерживают состояние регулятора в предусмотренных схемой пределах при смене режима.",
      "body": "Цепи ограничения и сброса удерживают состояние регулятора в предусмотренных схемой пределах при смене режима.",
      "nodes": [
        "reset",
        "control"
      ],
      "edges": [
        "control_reset"
      ],
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "netIds": [
        "control_net_c27d9f1c5177",
        "control_net_13ff4635cb1b",
        "control_net_f58cc678464d",
        "control_net_2860e727c5a6",
        "control_net_2b71697338af",
        "control_net_4b7c47b539e3",
        "control_net_f423ec67f84e",
        "control_net_affe5a5b3b9b",
        "control_net_1d37a4d602ee",
        "control_net_10974d5ea208",
        "control_net_91d1f89a3eb2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R2139",
          "pin": "2",
          "netId": "control_net_c27d9f1c5177",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2101",
          "pin": "1",
          "netId": "control_net_c27d9f1c5177",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2102",
          "pin": "1",
          "netId": "control_net_c27d9f1c5177",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2105",
          "pin": "10",
          "netId": "control_net_13ff4635cb1b",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2130",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2102",
          "pin": "2",
          "netId": "control_net_13ff4635cb1b",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2103",
          "pin": "1",
          "netId": "control_net_13ff4635cb1b",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "9",
          "netId": "control_net_f58cc678464d",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2121",
          "pin": "2",
          "netId": "control_net_f58cc678464d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2100",
          "pin": "1",
          "netId": "control_net_f58cc678464d",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "8",
          "netId": "control_net_2860e727c5a6",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2100",
          "pin": "3",
          "netId": "control_net_2860e727c5a6",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "13",
          "netId": "control_net_2b71697338af",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2122",
          "pin": "2",
          "netId": "control_net_2b71697338af",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2101",
          "pin": "1",
          "netId": "control_net_2b71697338af",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2106",
          "pin": "14",
          "netId": "control_net_4b7c47b539e3",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2101",
          "pin": "3",
          "netId": "control_net_4b7c47b539e3",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "9",
          "netId": "control_net_f423ec67f84e",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2131",
          "pin": "2",
          "netId": "control_net_f423ec67f84e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2102",
          "pin": "1",
          "netId": "control_net_f423ec67f84e",
          "name": "A1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "8",
          "netId": "control_net_affe5a5b3b9b",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2102",
          "pin": "3",
          "netId": "control_net_affe5a5b3b9b",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "13",
          "netId": "control_net_1d37a4d602ee",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2132",
          "pin": "2",
          "netId": "control_net_1d37a4d602ee",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2103",
          "pin": "2",
          "netId": "control_net_1d37a4d602ee",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2107",
          "pin": "14",
          "netId": "control_net_10974d5ea208",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2103",
          "pin": "3",
          "netId": "control_net_10974d5ea208",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2121",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2122",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2123",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2124",
          "pin": "1",
          "netId": "control_net_91d1f89a3eb2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2100",
          "pin": "2",
          "netId": "control_net_91d1f89a3eb2",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_D2101",
          "pin": "2",
          "netId": "control_net_91d1f89a3eb2",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
