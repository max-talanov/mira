/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2100_PROGRAM_POSITIVE",
  "title": "Как работает: Коммутация положительного питания записи",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2100_PROGRAM_POSITIVE",
  "steps": [
    {
      "title": "Приходит разрешение положительной шины",
      "text": "Оптопара и управляющие элементы передают команду в цепь затворов силовых транзисторов.",
      "body": "Оптопара и управляющие элементы передают команду в цепь затворов силовых транзисторов.",
      "nodes": [
        "control"
      ],
      "edges": [],
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "netIds": [
        "power_net_4499eab6d6ac",
        "power_net_46ab17b8adeb",
        "power_net_3340775b1468",
        "power_net_877d9e8f0cbb",
        "power_net_4ec3a13ab6a0",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2105",
          "pin": "2",
          "netId": "power_net_4499eab6d6ac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "1",
          "netId": "power_net_4499eab6d6ac",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "3",
          "netId": "power_net_3340775b1468",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2107",
          "pin": "1",
          "netId": "power_net_3340775b1468",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "1",
          "netId": "power_net_3340775b1468",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "4",
          "netId": "power_net_877d9e8f0cbb",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "3",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2105",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Силовой путь подключается",
      "text": "Последовательные ключи подключают положительную программирующую шину при разрешённом управлении. История показывает назначение пути, а не модель затворных напряжений.",
      "body": "Последовательные ключи подключают положительную программирующую шину при разрешённом управлении. История показывает назначение пути, а не модель затворных напряжений.",
      "nodes": [
        "control",
        "switch"
      ],
      "edges": [
        "switch_control"
      ],
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "netIds": [
        "power_net_46ab17b8adeb",
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q2104",
          "pin": "3",
          "netId": "power_net_46ab17b8adeb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2101",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "3",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "4",
          "netId": "power_net_877d9e8f0cbb",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выключение снимает заряд затвора",
      "text": "Быстрый зажим и вспомогательные элементы снимают управление и задают выключенное состояние ключей.",
      "body": "Быстрый зажим и вспомогательные элементы снимают управление и задают выключенное состояние ключей.",
      "nodes": [
        "stop",
        "switch"
      ],
      "edges": [
        "switch_stop"
      ],
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "netIds": [
        "power_net_5a1f578d112a",
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q2104",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2106",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2101",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2106",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2101",
          "pin": "2",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2101",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2101",
          "pin": "1",
          "netId": "power_net_877d9e8f0cbb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2103",
          "pin": "1",
          "netId": "power_net_877d9e8f0cbb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Приходит разрешение положительной шины",
      "text": "Оптопара и управляющие элементы передают команду в цепь затворов силовых транзисторов.",
      "body": "Оптопара и управляющие элементы передают команду в цепь затворов силовых транзисторов.",
      "nodes": [
        "control"
      ],
      "edges": [],
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "netIds": [
        "power_net_4499eab6d6ac",
        "power_net_46ab17b8adeb",
        "power_net_3340775b1468",
        "power_net_877d9e8f0cbb",
        "power_net_4ec3a13ab6a0",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2105",
          "pin": "2",
          "netId": "power_net_4499eab6d6ac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "1",
          "netId": "power_net_4499eab6d6ac",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "3",
          "netId": "power_net_3340775b1468",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2107",
          "pin": "1",
          "netId": "power_net_3340775b1468",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "1",
          "netId": "power_net_3340775b1468",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "4",
          "netId": "power_net_877d9e8f0cbb",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "3",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2105",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Силовой путь подключается",
      "text": "Последовательные ключи подключают положительную программирующую шину при разрешённом управлении. История показывает назначение пути, а не модель затворных напряжений.",
      "body": "Последовательные ключи подключают положительную программирующую шину при разрешённом управлении. История показывает назначение пути, а не модель затворных напряжений.",
      "nodes": [
        "control",
        "switch"
      ],
      "edges": [
        "switch_control"
      ],
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "netIds": [
        "power_net_46ab17b8adeb",
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q2104",
          "pin": "3",
          "netId": "power_net_46ab17b8adeb",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2101",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "3",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2101",
          "pin": "4",
          "netId": "power_net_877d9e8f0cbb",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2105",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выключение снимает заряд затвора",
      "text": "Быстрый зажим и вспомогательные элементы снимают управление и задают выключенное состояние ключей.",
      "body": "Быстрый зажим и вспомогательные элементы снимают управление и задают выключенное состояние ключей.",
      "nodes": [
        "stop",
        "switch"
      ],
      "edges": [
        "switch_stop"
      ],
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "netIds": [
        "power_net_5a1f578d112a",
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q2104",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2106",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2101",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2106",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2101",
          "pin": "2",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2101",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "1",
          "netId": "power_net_4ec3a13ab6a0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2103",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2101",
          "pin": "1",
          "netId": "power_net_877d9e8f0cbb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2103",
          "pin": "1",
          "netId": "power_net_877d9e8f0cbb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2102",
          "pin": "2",
          "netId": "power_net_877d9e8f0cbb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
