/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3600_MONITOR_FPGA_ANA_AFE",
  "title": "Как работает: Контроль ПЛИС и аналогового питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
  "steps": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_ca00563d0462",
        "power_net_4b914b219ba5",
        "power_net_4aeb4892b398",
        "power_net_cd1e0a0c9a0e",
        "power_net_20b613e14cd0",
        "power_net_b8182397a510",
        "power_net_324fb6a46e24"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3601",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3602",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3601",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "2",
          "netId": "power_net_ca00563d0462",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3604",
          "pin": "2",
          "netId": "power_net_ca00563d0462",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "3",
          "netId": "power_net_4b914b219ba5",
          "name": "LIMIT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3603",
          "pin": "1",
          "netId": "power_net_4b914b219ba5",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3601",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "7",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "8",
          "netId": "power_net_20b613e14cd0",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3601",
          "pin": "1",
          "netId": "power_net_b8182397a510",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3602",
          "pin": "1",
          "netId": "power_net_b8182397a510",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3601",
          "pin": "1",
          "netId": "power_net_b8182397a510",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3601",
          "pin": "3",
          "netId": "power_net_b8182397a510",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3603",
          "pin": "1",
          "netId": "power_net_324fb6a46e24",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3604",
          "pin": "1",
          "netId": "power_net_324fb6a46e24",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "fpga",
        "analog",
        "positive"
      ],
      "edges": [
        "fpga_analog",
        "fpga_positive",
        "analog_positive"
      ],
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3603",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3602",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "fpga",
        "analog",
        "positive"
      ],
      "edges": [
        "fpga_analog",
        "fpga_positive",
        "analog_positive"
      ],
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3603",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3602",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измерения снимаются с ветвей",
      "text": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "body": "Усилители измерения тока и делители напряжения получают сигналы соответствующих шин. Каждый блок представляет отдельную ветвь. ",
      "nodes": [
        "fpga"
      ],
      "edges": [],
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "netIds": [
        "power_net_67006db669b3",
        "power_net_ca00563d0462",
        "power_net_4b914b219ba5",
        "power_net_4aeb4892b398",
        "power_net_cd1e0a0c9a0e",
        "power_net_20b613e14cd0",
        "power_net_b8182397a510",
        "power_net_324fb6a46e24"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3601",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3602",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3601",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "2",
          "netId": "power_net_ca00563d0462",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3604",
          "pin": "2",
          "netId": "power_net_ca00563d0462",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "3",
          "netId": "power_net_4b914b219ba5",
          "name": "LIMIT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3603",
          "pin": "1",
          "netId": "power_net_4b914b219ba5",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3601",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "7",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "8",
          "netId": "power_net_20b613e14cd0",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3601",
          "pin": "1",
          "netId": "power_net_b8182397a510",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3602",
          "pin": "1",
          "netId": "power_net_b8182397a510",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3601",
          "pin": "1",
          "netId": "power_net_b8182397a510",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3601",
          "pin": "3",
          "netId": "power_net_b8182397a510",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3603",
          "pin": "1",
          "netId": "power_net_324fb6a46e24",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3604",
          "pin": "1",
          "netId": "power_net_324fb6a46e24",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получаются пары напряжение / ток",
      "text": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "body": "Измерительные усилители и обвязка формируют мониторные цепи. Напряжение и ток одной ветви далее выбираются согласованным адресом.",
      "nodes": [
        "fpga",
        "analog",
        "positive"
      ],
      "edges": [
        "fpga_analog",
        "fpga_positive",
        "analog_positive"
      ],
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3603",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3602",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Телеметрия и аппаратный сигнал разделены",
      "text": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "body": "Мониторные выходы продолжаются к селекторам и АЦП. Аппаратные аварийные выходы существуют отдельно от последовательного опроса измерений.",
      "nodes": [
        "fpga",
        "analog",
        "positive"
      ],
      "edges": [
        "fpga_analog",
        "fpga_positive",
        "analog_positive"
      ],
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "netIds": [
        "power_net_4aeb4892b398"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3603",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3602",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3601",
          "pin": "6",
          "netId": "power_net_4aeb4892b398",
          "name": "~{ALERT}",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
