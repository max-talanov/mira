/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_200_MCU_FMC_AND_SDRAM",
  "title": "Как работает: Оперативная память контроллера",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_200_MCU_FMC_AND_SDRAM",
  "steps": [
    {
      "title": "Контроллер запрашивает данные",
      "text": "Контроллер памяти STM32 выдаёт адрес, тактовый сигнал и команды доступа к SDRAM.",
      "body": "Контроллер памяти STM32 выдаёт адрес, тактовый сигнал и команды доступа к SDRAM.",
      "nodes": [
        "host",
        "bus"
      ],
      "edges": [
        "host_bus_0"
      ],
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "netIds": [
        "control_net_bf2f5ebca199",
        "control_net_f87a72a8ece7",
        "control_net_57814f35c37d",
        "control_net_88e82b098d8a",
        "control_net_576d489f596c",
        "control_net_64e3b30cda92",
        "control_net_5a1408d6925c",
        "control_net_e03d15dc4157",
        "control_net_478ea3ad984d",
        "control_net_51ade1c12a34",
        "control_net_497868960a10",
        "control_net_cf0d706ad175",
        "control_net_df9972435b68",
        "control_net_57fd38ae982f",
        "control_net_3a8f32a74ef2",
        "control_net_8726d2dae752",
        "control_net_66b853d97583",
        "control_net_1828c29d5fa6",
        "control_net_25457d3dd391",
        "control_net_cb5d34db7f7a",
        "control_net_802aa4569b27",
        "control_net_3974126e88cb",
        "control_net_f2ad5b3a1b23"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R200",
          "pin": "1",
          "netId": "control_net_bf2f5ebca199",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R202",
          "pin": "1",
          "netId": "control_net_f87a72a8ece7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R222",
          "pin": "1",
          "netId": "control_net_57814f35c37d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R214",
          "pin": "1",
          "netId": "control_net_88e82b098d8a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R210",
          "pin": "1",
          "netId": "control_net_576d489f596c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R213",
          "pin": "1",
          "netId": "control_net_64e3b30cda92",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R211",
          "pin": "1",
          "netId": "control_net_5a1408d6925c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R221",
          "pin": "1",
          "netId": "control_net_e03d15dc4157",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R216",
          "pin": "1",
          "netId": "control_net_478ea3ad984d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R209",
          "pin": "1",
          "netId": "control_net_51ade1c12a34",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R204",
          "pin": "1",
          "netId": "control_net_497868960a10",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R207",
          "pin": "1",
          "netId": "control_net_cf0d706ad175",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R217",
          "pin": "1",
          "netId": "control_net_df9972435b68",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R208",
          "pin": "1",
          "netId": "control_net_57fd38ae982f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R206",
          "pin": "1",
          "netId": "control_net_3a8f32a74ef2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R218",
          "pin": "1",
          "netId": "control_net_8726d2dae752",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R201",
          "pin": "1",
          "netId": "control_net_66b853d97583",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R212",
          "pin": "1",
          "netId": "control_net_1828c29d5fa6",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R220",
          "pin": "1",
          "netId": "control_net_25457d3dd391",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R219",
          "pin": "1",
          "netId": "control_net_cb5d34db7f7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R203",
          "pin": "1",
          "netId": "control_net_802aa4569b27",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R215",
          "pin": "1",
          "netId": "control_net_3974126e88cb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R205",
          "pin": "1",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Команды доходят до памяти",
      "text": "Последовательные резисторы находятся в тракте адресов, команд и тактирования. Они не хранят данные, а помогают согласовать фронты сигналов.",
      "body": "Последовательные резисторы находятся в тракте адресов, команд и тактирования. Они не хранят данные, а помогают согласовать фронты сигналов.",
      "nodes": [
        "bus",
        "memory"
      ],
      "edges": [
        "bus_memory_1"
      ],
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "netIds": [
        "control_net_1fb2e0bffca2",
        "control_net_b56b3c253467",
        "control_net_812a5aa5142f",
        "control_net_ea2e71d8ad65",
        "control_net_29b779eba1df",
        "control_net_a3f957371c3f",
        "control_net_22d2ed5a92b0",
        "control_net_e61f684e2b30",
        "control_net_50fec45c4cfe",
        "control_net_8e2c742867a9",
        "control_net_0d875c33a31d",
        "control_net_a7ff225fafcc",
        "control_net_7fb3e667afc3",
        "control_net_88a82b0ea167",
        "control_net_6a7ba2287274",
        "control_net_1ab10b21ce8a",
        "control_net_ac77da14ad01",
        "control_net_c768cd02e6fd",
        "control_net_9cec32a3a290",
        "control_net_50162c30e639",
        "control_net_bf332d53cb7b",
        "control_net_5ff18f95d1df",
        "control_net_ba4358c26b16"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R200",
          "pin": "2",
          "netId": "control_net_1fb2e0bffca2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "23",
          "netId": "control_net_1fb2e0bffca2",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R202",
          "pin": "2",
          "netId": "control_net_b56b3c253467",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "25",
          "netId": "control_net_b56b3c253467",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R222",
          "pin": "2",
          "netId": "control_net_812a5aa5142f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "38",
          "netId": "control_net_812a5aa5142f",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R214",
          "pin": "2",
          "netId": "control_net_ea2e71d8ad65",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "21",
          "netId": "control_net_ea2e71d8ad65",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R210",
          "pin": "2",
          "netId": "control_net_29b779eba1df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "22",
          "netId": "control_net_29b779eba1df",
          "name": "A10",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R213",
          "pin": "2",
          "netId": "control_net_a3f957371c3f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "20",
          "netId": "control_net_a3f957371c3f",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "15",
          "netId": "control_net_22d2ed5a92b0",
          "name": "DQML",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R215",
          "pin": "2",
          "netId": "control_net_22d2ed5a92b0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "16",
          "netId": "control_net_e61f684e2b30",
          "name": "WE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R219",
          "pin": "2",
          "netId": "control_net_e61f684e2b30",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "17",
          "netId": "control_net_50fec45c4cfe",
          "name": "CAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R217",
          "pin": "2",
          "netId": "control_net_50fec45c4cfe",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "18",
          "netId": "control_net_8e2c742867a9",
          "name": "RAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R218",
          "pin": "2",
          "netId": "control_net_8e2c742867a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "19",
          "netId": "control_net_0d875c33a31d",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R223",
          "pin": "2",
          "netId": "control_net_0d875c33a31d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R220",
          "pin": "2",
          "netId": "control_net_0d875c33a31d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "24",
          "netId": "control_net_a7ff225fafcc",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R201",
          "pin": "2",
          "netId": "control_net_a7ff225fafcc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "26",
          "netId": "control_net_7fb3e667afc3",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R203",
          "pin": "2",
          "netId": "control_net_7fb3e667afc3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "29",
          "netId": "control_net_88a82b0ea167",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R204",
          "pin": "2",
          "netId": "control_net_88a82b0ea167",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "30",
          "netId": "control_net_6a7ba2287274",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R205",
          "pin": "2",
          "netId": "control_net_6a7ba2287274",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "31",
          "netId": "control_net_1ab10b21ce8a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R206",
          "pin": "2",
          "netId": "control_net_1ab10b21ce8a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "32",
          "netId": "control_net_ac77da14ad01",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R207",
          "pin": "2",
          "netId": "control_net_ac77da14ad01",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "33",
          "netId": "control_net_c768cd02e6fd",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R208",
          "pin": "2",
          "netId": "control_net_c768cd02e6fd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "34",
          "netId": "control_net_9cec32a3a290",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R209",
          "pin": "2",
          "netId": "control_net_9cec32a3a290",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "35",
          "netId": "control_net_50162c30e639",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R211",
          "pin": "2",
          "netId": "control_net_50162c30e639",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "36",
          "netId": "control_net_bf332d53cb7b",
          "name": "A12",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R212",
          "pin": "2",
          "netId": "control_net_bf332d53cb7b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "37",
          "netId": "control_net_5ff18f95d1df",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R221",
          "pin": "2",
          "netId": "control_net_5ff18f95d1df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R224",
          "pin": "1",
          "netId": "control_net_5ff18f95d1df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "39",
          "netId": "control_net_ba4358c26b16",
          "name": "DQMH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R216",
          "pin": "2",
          "netId": "control_net_ba4358c26b16",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Данные возвращаются по шине",
      "text": "16-разрядная шина соединяет SDRAM и STM32 для чтения и записи. Содержимое этой памяти теряется при отключении питания.",
      "body": "16-разрядная шина соединяет SDRAM и STM32 для чтения и записи. Содержимое этой памяти теряется при отключении питания.",
      "nodes": [
        "memory",
        "host"
      ],
      "edges": [
        "host_memory_2"
      ],
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "netIds": [
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U200",
          "pin": "2",
          "netId": "control_net_30b951256d65",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "4",
          "netId": "control_net_05f1cce27675",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "5",
          "netId": "control_net_dbb7c66b055c",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "7",
          "netId": "control_net_71220214496a",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "8",
          "netId": "control_net_e8c9dc419d80",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "10",
          "netId": "control_net_c3d2e7b446eb",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "11",
          "netId": "control_net_3f3c225eebe4",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "13",
          "netId": "control_net_4fca7f1d1465",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "42",
          "netId": "control_net_1643db7ef9f9",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "44",
          "netId": "control_net_a3813a077889",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "45",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "47",
          "netId": "control_net_4ddbefaae88b",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "48",
          "netId": "control_net_c16e9f400334",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "50",
          "netId": "control_net_98b1a2522dce",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "51",
          "netId": "control_net_5c8668fc4b07",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "53",
          "netId": "control_net_a0420c81d318",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Контроллер запрашивает данные",
      "text": "Контроллер памяти STM32 выдаёт адрес, тактовый сигнал и команды доступа к SDRAM.",
      "body": "Контроллер памяти STM32 выдаёт адрес, тактовый сигнал и команды доступа к SDRAM.",
      "nodes": [
        "host",
        "bus"
      ],
      "edges": [
        "host_bus_0"
      ],
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "netIds": [
        "control_net_bf2f5ebca199",
        "control_net_f87a72a8ece7",
        "control_net_57814f35c37d",
        "control_net_88e82b098d8a",
        "control_net_576d489f596c",
        "control_net_64e3b30cda92",
        "control_net_5a1408d6925c",
        "control_net_e03d15dc4157",
        "control_net_478ea3ad984d",
        "control_net_51ade1c12a34",
        "control_net_497868960a10",
        "control_net_cf0d706ad175",
        "control_net_df9972435b68",
        "control_net_57fd38ae982f",
        "control_net_3a8f32a74ef2",
        "control_net_8726d2dae752",
        "control_net_66b853d97583",
        "control_net_1828c29d5fa6",
        "control_net_25457d3dd391",
        "control_net_cb5d34db7f7a",
        "control_net_802aa4569b27",
        "control_net_3974126e88cb",
        "control_net_f2ad5b3a1b23"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R200",
          "pin": "1",
          "netId": "control_net_bf2f5ebca199",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "18",
          "netId": "control_net_bf2f5ebca199",
          "name": "PF0_/_FMC_A0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R202",
          "pin": "1",
          "netId": "control_net_f87a72a8ece7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "20",
          "netId": "control_net_f87a72a8ece7",
          "name": "PF2_/_FMC_A2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R222",
          "pin": "1",
          "netId": "control_net_57814f35c37d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "118",
          "netId": "control_net_57814f35c37d",
          "name": "PG8_/_FMC_SDCLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R214",
          "pin": "1",
          "netId": "control_net_88e82b098d8a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "115",
          "netId": "control_net_88e82b098d8a",
          "name": "PG5_/_FMC_BA1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R210",
          "pin": "1",
          "netId": "control_net_576d489f596c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "63",
          "netId": "control_net_576d489f596c",
          "name": "PG0_/_FMC_A10",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R213",
          "pin": "1",
          "netId": "control_net_64e3b30cda92",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "114",
          "netId": "control_net_64e3b30cda92",
          "name": "PG4_/_FMC_BA0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R211",
          "pin": "1",
          "netId": "control_net_5a1408d6925c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "66",
          "netId": "control_net_5a1408d6925c",
          "name": "PG1_/_FMC_A11",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R221",
          "pin": "1",
          "netId": "control_net_e03d15dc4157",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "54",
          "netId": "control_net_e03d15dc4157",
          "name": "PC5_/_FMC_SDCKE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R216",
          "pin": "1",
          "netId": "control_net_478ea3ad984d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "171",
          "netId": "control_net_478ea3ad984d",
          "name": "PE1_/_FMC_NBL1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R209",
          "pin": "1",
          "netId": "control_net_51ade1c12a34",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "62",
          "netId": "control_net_51ade1c12a34",
          "name": "PF15_/_FMC_A9",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R204",
          "pin": "1",
          "netId": "control_net_497868960a10",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "22",
          "netId": "control_net_497868960a10",
          "name": "PF4_/_FMC_A4",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R207",
          "pin": "1",
          "netId": "control_net_cf0d706ad175",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "60",
          "netId": "control_net_cf0d706ad175",
          "name": "PF13_/_FMC_A7",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R217",
          "pin": "1",
          "netId": "control_net_df9972435b68",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "161",
          "netId": "control_net_df9972435b68",
          "name": "PG15_/_FMC_SDNCAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R208",
          "pin": "1",
          "netId": "control_net_57fd38ae982f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "61",
          "netId": "control_net_57fd38ae982f",
          "name": "PF14_/_FMC_A8",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R206",
          "pin": "1",
          "netId": "control_net_3a8f32a74ef2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "59",
          "netId": "control_net_3a8f32a74ef2",
          "name": "PF12_/_FMC_A6",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R218",
          "pin": "1",
          "netId": "control_net_8726d2dae752",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "58",
          "netId": "control_net_8726d2dae752",
          "name": "PF11_/_FMC_SDNRAS",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R201",
          "pin": "1",
          "netId": "control_net_66b853d97583",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "19",
          "netId": "control_net_66b853d97583",
          "name": "PF1_/_FMC_A1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R212",
          "pin": "1",
          "netId": "control_net_1828c29d5fa6",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "110",
          "netId": "control_net_1828c29d5fa6",
          "name": "PG2_/_FMC_A12",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R220",
          "pin": "1",
          "netId": "control_net_25457d3dd391",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "53",
          "netId": "control_net_25457d3dd391",
          "name": "PC4_/_FMC_SDNE0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R219",
          "pin": "1",
          "netId": "control_net_cb5d34db7f7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "34",
          "netId": "control_net_cb5d34db7f7a",
          "name": "PC0_/_FMC_SDNWE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R203",
          "pin": "1",
          "netId": "control_net_802aa4569b27",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "21",
          "netId": "control_net_802aa4569b27",
          "name": "PF3_/_FMC_A3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R215",
          "pin": "1",
          "netId": "control_net_3974126e88cb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "170",
          "netId": "control_net_3974126e88cb",
          "name": "PE0_/_FMC_NBL0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "23",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "PF5_/_FMC_A5",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R205",
          "pin": "1",
          "netId": "control_net_f2ad5b3a1b23",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Команды доходят до памяти",
      "text": "Последовательные резисторы находятся в тракте адресов, команд и тактирования. Они не хранят данные, а помогают согласовать фронты сигналов.",
      "body": "Последовательные резисторы находятся в тракте адресов, команд и тактирования. Они не хранят данные, а помогают согласовать фронты сигналов.",
      "nodes": [
        "bus",
        "memory"
      ],
      "edges": [
        "bus_memory_1"
      ],
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "netIds": [
        "control_net_1fb2e0bffca2",
        "control_net_b56b3c253467",
        "control_net_812a5aa5142f",
        "control_net_ea2e71d8ad65",
        "control_net_29b779eba1df",
        "control_net_a3f957371c3f",
        "control_net_22d2ed5a92b0",
        "control_net_e61f684e2b30",
        "control_net_50fec45c4cfe",
        "control_net_8e2c742867a9",
        "control_net_0d875c33a31d",
        "control_net_a7ff225fafcc",
        "control_net_7fb3e667afc3",
        "control_net_88a82b0ea167",
        "control_net_6a7ba2287274",
        "control_net_1ab10b21ce8a",
        "control_net_ac77da14ad01",
        "control_net_c768cd02e6fd",
        "control_net_9cec32a3a290",
        "control_net_50162c30e639",
        "control_net_bf332d53cb7b",
        "control_net_5ff18f95d1df",
        "control_net_ba4358c26b16"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R200",
          "pin": "2",
          "netId": "control_net_1fb2e0bffca2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "23",
          "netId": "control_net_1fb2e0bffca2",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R202",
          "pin": "2",
          "netId": "control_net_b56b3c253467",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "25",
          "netId": "control_net_b56b3c253467",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R222",
          "pin": "2",
          "netId": "control_net_812a5aa5142f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "38",
          "netId": "control_net_812a5aa5142f",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R214",
          "pin": "2",
          "netId": "control_net_ea2e71d8ad65",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "21",
          "netId": "control_net_ea2e71d8ad65",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R210",
          "pin": "2",
          "netId": "control_net_29b779eba1df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "22",
          "netId": "control_net_29b779eba1df",
          "name": "A10",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R213",
          "pin": "2",
          "netId": "control_net_a3f957371c3f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "20",
          "netId": "control_net_a3f957371c3f",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "15",
          "netId": "control_net_22d2ed5a92b0",
          "name": "DQML",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R215",
          "pin": "2",
          "netId": "control_net_22d2ed5a92b0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "16",
          "netId": "control_net_e61f684e2b30",
          "name": "WE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R219",
          "pin": "2",
          "netId": "control_net_e61f684e2b30",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "17",
          "netId": "control_net_50fec45c4cfe",
          "name": "CAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R217",
          "pin": "2",
          "netId": "control_net_50fec45c4cfe",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "18",
          "netId": "control_net_8e2c742867a9",
          "name": "RAS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R218",
          "pin": "2",
          "netId": "control_net_8e2c742867a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "19",
          "netId": "control_net_0d875c33a31d",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R223",
          "pin": "2",
          "netId": "control_net_0d875c33a31d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R220",
          "pin": "2",
          "netId": "control_net_0d875c33a31d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "24",
          "netId": "control_net_a7ff225fafcc",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R201",
          "pin": "2",
          "netId": "control_net_a7ff225fafcc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "26",
          "netId": "control_net_7fb3e667afc3",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R203",
          "pin": "2",
          "netId": "control_net_7fb3e667afc3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "29",
          "netId": "control_net_88a82b0ea167",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R204",
          "pin": "2",
          "netId": "control_net_88a82b0ea167",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "30",
          "netId": "control_net_6a7ba2287274",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R205",
          "pin": "2",
          "netId": "control_net_6a7ba2287274",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "31",
          "netId": "control_net_1ab10b21ce8a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R206",
          "pin": "2",
          "netId": "control_net_1ab10b21ce8a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "32",
          "netId": "control_net_ac77da14ad01",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R207",
          "pin": "2",
          "netId": "control_net_ac77da14ad01",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "33",
          "netId": "control_net_c768cd02e6fd",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R208",
          "pin": "2",
          "netId": "control_net_c768cd02e6fd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "34",
          "netId": "control_net_9cec32a3a290",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R209",
          "pin": "2",
          "netId": "control_net_9cec32a3a290",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "35",
          "netId": "control_net_50162c30e639",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R211",
          "pin": "2",
          "netId": "control_net_50162c30e639",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "36",
          "netId": "control_net_bf332d53cb7b",
          "name": "A12",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R212",
          "pin": "2",
          "netId": "control_net_bf332d53cb7b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "37",
          "netId": "control_net_5ff18f95d1df",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R221",
          "pin": "2",
          "netId": "control_net_5ff18f95d1df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R224",
          "pin": "1",
          "netId": "control_net_5ff18f95d1df",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "39",
          "netId": "control_net_ba4358c26b16",
          "name": "DQMH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R216",
          "pin": "2",
          "netId": "control_net_ba4358c26b16",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Данные возвращаются по шине",
      "text": "16-разрядная шина соединяет SDRAM и STM32 для чтения и записи. Содержимое этой памяти теряется при отключении питания.",
      "body": "16-разрядная шина соединяет SDRAM и STM32 для чтения и записи. Содержимое этой памяти теряется при отключении питания.",
      "nodes": [
        "memory",
        "host"
      ],
      "edges": [
        "host_memory_2"
      ],
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "netIds": [
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U200",
          "pin": "2",
          "netId": "control_net_30b951256d65",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "97",
          "netId": "control_net_30b951256d65",
          "name": "PD14_/_FMC_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "4",
          "netId": "control_net_05f1cce27675",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "98",
          "netId": "control_net_05f1cce27675",
          "name": "PD15_/_FMC_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "5",
          "netId": "control_net_dbb7c66b055c",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "143",
          "netId": "control_net_dbb7c66b055c",
          "name": "PD0_/_FMC_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "7",
          "netId": "control_net_71220214496a",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "144",
          "netId": "control_net_71220214496a",
          "name": "PD1_/_FMC_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "8",
          "netId": "control_net_e8c9dc419d80",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "67",
          "netId": "control_net_e8c9dc419d80",
          "name": "PE7_/_FMC_D4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "10",
          "netId": "control_net_c3d2e7b446eb",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "68",
          "netId": "control_net_c3d2e7b446eb",
          "name": "PE8_/_FMC_D5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "11",
          "netId": "control_net_3f3c225eebe4",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "69",
          "netId": "control_net_3f3c225eebe4",
          "name": "PE9_/_FMC_D6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "13",
          "netId": "control_net_4fca7f1d1465",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "72",
          "netId": "control_net_4fca7f1d1465",
          "name": "PE10_/_FMC_D7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "42",
          "netId": "control_net_1643db7ef9f9",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "73",
          "netId": "control_net_1643db7ef9f9",
          "name": "PE11_/_FMC_D8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "44",
          "netId": "control_net_a3813a077889",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "74",
          "netId": "control_net_a3813a077889",
          "name": "PE12_/_FMC_D9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "45",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "75",
          "netId": "control_net_cfc4efe0cd4a",
          "name": "PE13_/_FMC_D10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "47",
          "netId": "control_net_4ddbefaae88b",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "76",
          "netId": "control_net_4ddbefaae88b",
          "name": "PE14_/_FMC_D11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "48",
          "netId": "control_net_c16e9f400334",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "77",
          "netId": "control_net_c16e9f400334",
          "name": "PE15_/_FMC_D12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "50",
          "netId": "control_net_98b1a2522dce",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "89",
          "netId": "control_net_98b1a2522dce",
          "name": "PD8_/_FMC_D13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "51",
          "netId": "control_net_5c8668fc4b07",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "90",
          "netId": "control_net_5c8668fc4b07",
          "name": "PD9_/_FMC_D14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U200",
          "pin": "53",
          "netId": "control_net_a0420c81d318",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "91",
          "netId": "control_net_a0420c81d318",
          "name": "PD10_/_FMC_D15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
