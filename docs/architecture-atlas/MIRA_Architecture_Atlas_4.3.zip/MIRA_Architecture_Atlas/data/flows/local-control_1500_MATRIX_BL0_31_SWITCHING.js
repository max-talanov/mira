/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1500_MATRIX_BL0_31_SWITCHING",
  "title": "Как работает: Коммутация битовых линий матрицы",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
  "steps": [
    {
      "title": "Управление выбирает соединения",
      "text": "Банки аналоговых ключей получают управляющий образ и соединяют источники, ограничивающие пути и служебный тракт с выбранными BL.",
      "body": "Банки аналоговых ключей получают управляющий образ и соединяют источники, ограничивающие пути и служебный тракт с выбранными BL.",
      "nodes": [
        "bank0",
        "bank1"
      ],
      "edges": [
        "bank0_bank1"
      ],
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1516",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1596",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Напряжение идёт по выбранному пути",
      "text": "Первый и второй банки обслуживают BL0…15. Выделение цепи показывает её реальные выводы; положение ключа определяется управляющими сигналами.",
      "body": "Первый и второй банки обслуживают BL0…15. Выделение цепи показывает её реальные выводы; положение ключа определяется управляющими сигналами.",
      "nodes": [
        "bank0",
        "bank1"
      ],
      "edges": [
        "bank0_bank1"
      ],
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1516",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1596",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Маршрутизация охватывает 32 BL",
      "text": "Третий и четвёртый банки обслуживают BL16…31. Это одинаковые по назначению каналы одного функционального узла.",
      "body": "Третий и четвёртый банки обслуживают BL16…31. Это одинаковые по назначению каналы одного функционального узла.",
      "nodes": [
        "bank2",
        "bank3"
      ],
      "edges": [
        "bank2_bank3"
      ],
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1598",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1599",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1597",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Управление выбирает соединения",
      "text": "Банки аналоговых ключей получают управляющий образ и соединяют источники, ограничивающие пути и служебный тракт с выбранными BL.",
      "body": "Банки аналоговых ключей получают управляющий образ и соединяют источники, ограничивающие пути и служебный тракт с выбранными BL.",
      "nodes": [
        "bank0",
        "bank1"
      ],
      "edges": [
        "bank0_bank1"
      ],
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1516",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1596",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Напряжение идёт по выбранному пути",
      "text": "Первый и второй банки обслуживают BL0…15. Выделение цепи показывает её реальные выводы; положение ключа определяется управляющими сигналами.",
      "body": "Первый и второй банки обслуживают BL0…15. Выделение цепи показывает её реальные выводы; положение ключа определяется управляющими сигналами.",
      "nodes": [
        "bank0",
        "bank1"
      ],
      "edges": [
        "bank0_bank1"
      ],
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1516",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1596",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1516",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1517",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Маршрутизация охватывает 32 BL",
      "text": "Третий и четвёртый банки обслуживают BL16…31. Это одинаковые по назначению каналы одного функционального узла.",
      "body": "Третий и четвёртый банки обслуживают BL16…31. Это одинаковые по назначению каналы одного функционального узла.",
      "nodes": [
        "bank2",
        "bank3"
      ],
      "edges": [
        "bank2_bank3"
      ],
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1598",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1599",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1597",
          "pin": "1",
          "netId": "control_net_209d9624cc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "1",
          "netId": "control_net_11d0bca5a9c3",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "16",
          "netId": "control_net_5adbbaca70af",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1518",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1519",
          "pin": "15",
          "netId": "control_net_5d5a8a88fb46",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
