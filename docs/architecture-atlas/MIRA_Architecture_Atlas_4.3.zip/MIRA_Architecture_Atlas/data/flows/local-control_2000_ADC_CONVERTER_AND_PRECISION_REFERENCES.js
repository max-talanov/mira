/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "title": "Как работает: Оцифровка сигнала матрицы",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "steps": [
    {
      "title": "Опора задаёт масштаб",
      "text": "Источники опорного напряжения задают масштаб преобразования АЦП. Они не являются измеряемым сигналом.",
      "body": "Источники опорного напряжения задают масштаб преобразования АЦП. Они не являются измеряемым сигналом.",
      "nodes": [
        "reference"
      ],
      "edges": [],
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "netIds": [
        "control_net_f3e1ab997145",
        "control_net_394d6f53173b",
        "control_net_f74ce33ca00c",
        "control_net_da38a944d8bb",
        "control_net_18acc164b68f",
        "control_net_96e5e93b8b79",
        "control_net_91f318f8e7ad",
        "control_net_95324335ce2a",
        "control_net_65bfc0fba55b",
        "control_net_43aaa7149bc5",
        "control_net_594b7095cf6e",
        "control_net_b4fd0f4101eb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2000",
          "pin": "1",
          "netId": "control_net_f3e1ab997145",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "2",
          "netId": "control_net_394d6f53173b",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2017",
          "pin": "1",
          "netId": "control_net_394d6f53173b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "3",
          "netId": "control_net_f74ce33ca00c",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "5",
          "netId": "control_net_da38a944d8bb",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "6",
          "netId": "control_net_18acc164b68f",
          "name": "VOUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2000",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2001",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2002",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "7",
          "netId": "control_net_96e5e93b8b79",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "8",
          "netId": "control_net_91f318f8e7ad",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2000",
          "pin": "2",
          "netId": "control_net_95324335ce2a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2001",
          "pin": "1",
          "netId": "control_net_95324335ce2a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "3",
          "netId": "control_net_95324335ce2a",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "1",
          "netId": "control_net_65bfc0fba55b",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "2",
          "netId": "control_net_43aaa7149bc5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "6",
          "netId": "control_net_43aaa7149bc5",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "5",
          "netId": "control_net_594b7095cf6e",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "8",
          "netId": "control_net_594b7095cf6e",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "7",
          "netId": "control_net_b4fd0f4101eb",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2004",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигнал готовится к АЦП",
      "text": "Выбранный мониторный сигнал проходит буфер и дифференциальный усилитель, формирующий два входных напряжения АЦП.",
      "body": "Выбранный мониторный сигнал проходит буфер и дифференциальный усилитель, формирующий два входных напряжения АЦП.",
      "nodes": [
        "monitor",
        "differential"
      ],
      "edges": [
        "monitor_differential"
      ],
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "netIds": [
        "control_net_a636afc1774d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2003",
          "pin": "1",
          "netId": "control_net_a636afc1774d",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2004",
          "pin": "2",
          "netId": "control_net_a636afc1774d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2005",
          "pin": "1",
          "netId": "control_net_a636afc1774d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "АЦП формирует цифровой результат",
      "text": "АЦП принимает подготовленный аналоговый сигнал и по цифровому интерфейсу передаёт отсчёты к ПЛИС. История не задаёт частоту выборок.",
      "body": "АЦП принимает подготовленный аналоговый сигнал и по цифровому интерфейсу передаёт отсчёты к ПЛИС. История не задаёт частоту выборок.",
      "nodes": [
        "differential",
        "reference",
        "adc"
      ],
      "edges": [
        "reference_differential",
        "reference_adc",
        "differential_adc"
      ],
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "netIds": [
        "control_net_43aaa7149bc5",
        "control_net_18acc164b68f",
        "control_net_87a4861c654c",
        "control_net_d96556e65ebd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2001",
          "pin": "2",
          "netId": "control_net_43aaa7149bc5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "6",
          "netId": "control_net_43aaa7149bc5",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2003",
          "pin": "2",
          "netId": "control_net_43aaa7149bc5",
          "name": "VOCM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "6",
          "netId": "control_net_18acc164b68f",
          "name": "VOUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2000",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "REF",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2001",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2002",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2008",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2009",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2006",
          "pin": "2",
          "netId": "control_net_87a4861c654c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2006",
          "pin": "1",
          "netId": "control_net_87a4861c654c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "3",
          "netId": "control_net_87a4861c654c",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2009",
          "pin": "2",
          "netId": "control_net_d96556e65ebd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2006",
          "pin": "2",
          "netId": "control_net_d96556e65ebd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "4",
          "netId": "control_net_d96556e65ebd",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Опора задаёт масштаб",
      "text": "Источники опорного напряжения задают масштаб преобразования АЦП. Они не являются измеряемым сигналом.",
      "body": "Источники опорного напряжения задают масштаб преобразования АЦП. Они не являются измеряемым сигналом.",
      "nodes": [
        "reference"
      ],
      "edges": [],
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "netIds": [
        "control_net_f3e1ab997145",
        "control_net_394d6f53173b",
        "control_net_f74ce33ca00c",
        "control_net_da38a944d8bb",
        "control_net_18acc164b68f",
        "control_net_96e5e93b8b79",
        "control_net_91f318f8e7ad",
        "control_net_95324335ce2a",
        "control_net_65bfc0fba55b",
        "control_net_43aaa7149bc5",
        "control_net_594b7095cf6e",
        "control_net_b4fd0f4101eb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2000",
          "pin": "1",
          "netId": "control_net_f3e1ab997145",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "2",
          "netId": "control_net_394d6f53173b",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2017",
          "pin": "1",
          "netId": "control_net_394d6f53173b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "3",
          "netId": "control_net_f74ce33ca00c",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "5",
          "netId": "control_net_da38a944d8bb",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "6",
          "netId": "control_net_18acc164b68f",
          "name": "VOUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2000",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2001",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2002",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "7",
          "netId": "control_net_96e5e93b8b79",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "8",
          "netId": "control_net_91f318f8e7ad",
          "name": "DNC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2000",
          "pin": "2",
          "netId": "control_net_95324335ce2a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2001",
          "pin": "1",
          "netId": "control_net_95324335ce2a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "3",
          "netId": "control_net_95324335ce2a",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "1",
          "netId": "control_net_65bfc0fba55b",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "2",
          "netId": "control_net_43aaa7149bc5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "6",
          "netId": "control_net_43aaa7149bc5",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "5",
          "netId": "control_net_594b7095cf6e",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "8",
          "netId": "control_net_594b7095cf6e",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "7",
          "netId": "control_net_b4fd0f4101eb",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2004",
          "pin": "1",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигнал готовится к АЦП",
      "text": "Выбранный мониторный сигнал проходит буфер и дифференциальный усилитель, формирующий два входных напряжения АЦП.",
      "body": "Выбранный мониторный сигнал проходит буфер и дифференциальный усилитель, формирующий два входных напряжения АЦП.",
      "nodes": [
        "monitor",
        "differential"
      ],
      "edges": [
        "monitor_differential"
      ],
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "netIds": [
        "control_net_a636afc1774d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2003",
          "pin": "1",
          "netId": "control_net_a636afc1774d",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2004",
          "pin": "2",
          "netId": "control_net_a636afc1774d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2005",
          "pin": "1",
          "netId": "control_net_a636afc1774d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "АЦП формирует цифровой результат",
      "text": "АЦП принимает подготовленный аналоговый сигнал и по цифровому интерфейсу передаёт отсчёты к ПЛИС. История не задаёт частоту выборок.",
      "body": "АЦП принимает подготовленный аналоговый сигнал и по цифровому интерфейсу передаёт отсчёты к ПЛИС. История не задаёт частоту выборок.",
      "nodes": [
        "differential",
        "reference",
        "adc"
      ],
      "edges": [
        "reference_differential",
        "reference_adc",
        "differential_adc"
      ],
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "netIds": [
        "control_net_43aaa7149bc5",
        "control_net_18acc164b68f",
        "control_net_87a4861c654c",
        "control_net_d96556e65ebd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2001",
          "pin": "2",
          "netId": "control_net_43aaa7149bc5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2001",
          "pin": "6",
          "netId": "control_net_43aaa7149bc5",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2003",
          "pin": "2",
          "netId": "control_net_43aaa7149bc5",
          "name": "VOCM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2000",
          "pin": "6",
          "netId": "control_net_18acc164b68f",
          "name": "VOUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2000",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "REF",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2001",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2002",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2008",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2009",
          "pin": "1",
          "netId": "control_net_18acc164b68f",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2006",
          "pin": "2",
          "netId": "control_net_87a4861c654c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2006",
          "pin": "1",
          "netId": "control_net_87a4861c654c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "3",
          "netId": "control_net_87a4861c654c",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2009",
          "pin": "2",
          "netId": "control_net_d96556e65ebd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2006",
          "pin": "2",
          "netId": "control_net_d96556e65ebd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "4",
          "netId": "control_net_d96556e65ebd",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
