/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control-boundary",
  "title": "Как работает: Приём питания и разрешений",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control-boundary",
  "steps": [
    {
      "title": "Вход питания платы Control",
      "text": "J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.",
      "body": "J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.",
      "nodes": [
        "sheet400"
      ],
      "edges": [],
      "sceneId": "control-boundary",
      "netIds": [
        "control_net_8108fd43e4b2",
        "control_net_3db345350ff9",
        "control_net_6f005443ad9c",
        "control_net_4ad2a1c9d225",
        "control_net_9bddf3e35643",
        "control_net_df95db02c560",
        "control_net_225bd2a08dfb",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_44af6a0dc05c",
        "control_net_cb711dcd1752",
        "control_net_90c4fa851afd",
        "control_net_48bfab6ba5e0",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159",
        "control_net_01f75bd2f12a",
        "control_net_5fb1532b0e1e",
        "control_net_732d19ff86ef",
        "control_net_b4fd0f4101eb",
        "control_net_a05784e4a1d3",
        "control_net_2e82cb98585d",
        "control_net_e5381212c338",
        "control_net_0f879d751610",
        "control_net_e0edb28bbf68",
        "control_net_0a1befd890ff",
        "control_net_8377a92cc3c5",
        "control_net_c3283ba17c11",
        "control_net_f64354686773",
        "control_net_0cbb519cdc03",
        "control_net_e65fb75085e7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J400",
          "pin": "57",
          "netId": "control_net_8108fd43e4b2",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "9",
          "netId": "control_net_8108fd43e4b2",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "2",
          "netId": "control_net_8108fd43e4b2",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "4",
          "netId": "control_net_3db345350ff9",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "9",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "11",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "1",
          "netId": "control_net_4ad2a1c9d225",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "55",
          "netId": "control_net_9bddf3e35643",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "2",
          "netId": "control_net_9bddf3e35643",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "3",
          "netId": "control_net_df95db02c560",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "56",
          "netId": "control_net_225bd2a08dfb",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "5",
          "netId": "control_net_225bd2a08dfb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "6",
          "netId": "control_net_7f8e95e35104",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "8",
          "netId": "control_net_9edec24f88a2",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "54",
          "netId": "control_net_44af6a0dc05c",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "12",
          "netId": "control_net_44af6a0dc05c",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "11",
          "netId": "control_net_cb711dcd1752",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "1",
          "netId": "control_net_48bfab6ba5e0",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "13",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "15",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "17",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "19",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "21",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "23",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "25",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "27",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "29",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "31",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "33",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "35",
          "netId": "control_net_732d19ff86ef",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "37",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "39",
          "netId": "control_net_a05784e4a1d3",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "41",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "43",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "45",
          "netId": "control_net_0f879d751610",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "47",
          "netId": "control_net_e0edb28bbf68",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "49",
          "netId": "control_net_0a1befd890ff",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "51",
          "netId": "control_net_8377a92cc3c5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "52",
          "netId": "control_net_c3283ba17c11",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "53",
          "netId": "control_net_f64354686773",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "58",
          "netId": "control_net_0cbb519cdc03",
          "name": "",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "59",
          "netId": "control_net_e65fb75085e7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Вход питания платы Control",
      "text": "J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.",
      "body": "J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.",
      "nodes": [
        "sheet400"
      ],
      "edges": [],
      "sceneId": "control-boundary",
      "netIds": [
        "control_net_8108fd43e4b2",
        "control_net_3db345350ff9",
        "control_net_6f005443ad9c",
        "control_net_4ad2a1c9d225",
        "control_net_9bddf3e35643",
        "control_net_df95db02c560",
        "control_net_225bd2a08dfb",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2",
        "control_net_44af6a0dc05c",
        "control_net_cb711dcd1752",
        "control_net_90c4fa851afd",
        "control_net_48bfab6ba5e0",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159",
        "control_net_01f75bd2f12a",
        "control_net_5fb1532b0e1e",
        "control_net_732d19ff86ef",
        "control_net_b4fd0f4101eb",
        "control_net_a05784e4a1d3",
        "control_net_2e82cb98585d",
        "control_net_e5381212c338",
        "control_net_0f879d751610",
        "control_net_e0edb28bbf68",
        "control_net_0a1befd890ff",
        "control_net_8377a92cc3c5",
        "control_net_c3283ba17c11",
        "control_net_f64354686773",
        "control_net_0cbb519cdc03",
        "control_net_e65fb75085e7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J400",
          "pin": "57",
          "netId": "control_net_8108fd43e4b2",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "9",
          "netId": "control_net_8108fd43e4b2",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "2",
          "netId": "control_net_8108fd43e4b2",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "4",
          "netId": "control_net_3db345350ff9",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "7",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "9",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "11",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U401",
          "pin": "1",
          "netId": "control_net_4ad2a1c9d225",
          "name": "NC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "55",
          "netId": "control_net_9bddf3e35643",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "2",
          "netId": "control_net_9bddf3e35643",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "3",
          "netId": "control_net_df95db02c560",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "56",
          "netId": "control_net_225bd2a08dfb",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "5",
          "netId": "control_net_225bd2a08dfb",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "6",
          "netId": "control_net_7f8e95e35104",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "8",
          "netId": "control_net_9edec24f88a2",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "54",
          "netId": "control_net_44af6a0dc05c",
          "name": "",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "12",
          "netId": "control_net_44af6a0dc05c",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "11",
          "netId": "control_net_cb711dcd1752",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "3",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "5",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U400",
          "pin": "14",
          "netId": "control_net_90c4fa851afd",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "1",
          "netId": "control_net_48bfab6ba5e0",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "13",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "15",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "17",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "19",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "21",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "23",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "25",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "27",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "29",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "31",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "33",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "35",
          "netId": "control_net_732d19ff86ef",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "37",
          "netId": "control_net_b4fd0f4101eb",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "39",
          "netId": "control_net_a05784e4a1d3",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "41",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "43",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "45",
          "netId": "control_net_0f879d751610",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "47",
          "netId": "control_net_e0edb28bbf68",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "49",
          "netId": "control_net_0a1befd890ff",
          "name": "",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "51",
          "netId": "control_net_8377a92cc3c5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "52",
          "netId": "control_net_c3283ba17c11",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "53",
          "netId": "control_net_f64354686773",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "58",
          "netId": "control_net_0cbb519cdc03",
          "name": "",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J400",
          "pin": "59",
          "netId": "control_net_e65fb75085e7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
