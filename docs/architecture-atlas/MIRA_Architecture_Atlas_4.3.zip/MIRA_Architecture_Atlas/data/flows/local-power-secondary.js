/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power-secondary",
  "title": "Как работает: Питание отдельных нагрузок",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power-secondary",
  "steps": [
    {
      "title": "Питание ядра ПЛИС",
      "text": "U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.",
      "body": "U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.",
      "nodes": [
        "sheet1200"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_25f4b9dd8faf",
        "power_net_cd1e0a0c9a0e",
        "power_net_a1556093443e",
        "power_net_4a30a9f331e1",
        "power_net_50cf3ae624b1",
        "power_net_0828b35e4b6c",
        "power_net_95f2aea4f265",
        "power_net_f04a3136bae5",
        "power_net_44d5eba2ecef"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1201",
          "pin": "1",
          "netId": "power_net_25f4b9dd8faf",
          "name": "BOOT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "6",
          "netId": "power_net_a1556093443e",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "7",
          "netId": "power_net_a1556093443e",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "13",
          "netId": "power_net_4a30a9f331e1",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "14",
          "netId": "power_net_50cf3ae624b1",
          "name": "SS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "15",
          "netId": "power_net_0828b35e4b6c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "16",
          "netId": "power_net_95f2aea4f265",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "17",
          "netId": "power_net_f04a3136bae5",
          "name": "VREG5",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "18",
          "netId": "power_net_44d5eba2ecef",
          "name": "MODE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Вспомогательное питание ПЛИС 1,8 В",
      "text": "U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.",
      "body": "U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.",
      "nodes": [
        "sheet1300"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_438a56c0fd28",
        "power_net_b80a0b0c471f",
        "power_net_ee6e52656b26",
        "power_net_72aaeb0dd85a",
        "power_net_7aa373b3d11c",
        "power_net_cd1e0a0c9a0e",
        "power_net_91608c5bec4e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1301",
          "pin": "1",
          "netId": "power_net_438a56c0fd28",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "2",
          "netId": "power_net_438a56c0fd28",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "3",
          "netId": "power_net_438a56c0fd28",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "4",
          "netId": "power_net_b80a0b0c471f",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "5",
          "netId": "power_net_ee6e52656b26",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "7",
          "netId": "power_net_72aaeb0dd85a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "14",
          "netId": "power_net_72aaeb0dd85a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "9",
          "netId": "power_net_7aa373b3d11c",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "13",
          "netId": "power_net_91608c5bec4e",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Вспомогательное питание 2,5 В",
      "text": "U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.",
      "body": "U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.",
      "nodes": [
        "sheet1400"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_3a7ca3c79de6",
        "power_net_fcfa30509d75",
        "power_net_b07a46e4f6c7",
        "power_net_38cd986dd59a",
        "power_net_918357f17ed8",
        "power_net_cd1e0a0c9a0e",
        "power_net_8d8d482ee874"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1401",
          "pin": "1",
          "netId": "power_net_3a7ca3c79de6",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "2",
          "netId": "power_net_3a7ca3c79de6",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "3",
          "netId": "power_net_3a7ca3c79de6",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "4",
          "netId": "power_net_fcfa30509d75",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "5",
          "netId": "power_net_b07a46e4f6c7",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "7",
          "netId": "power_net_38cd986dd59a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "14",
          "netId": "power_net_38cd986dd59a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "9",
          "netId": "power_net_918357f17ed8",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "13",
          "netId": "power_net_8d8d482ee874",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание выводов ПЛИС 3,3 В",
      "text": "U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.",
      "body": "U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.",
      "nodes": [
        "sheet1500"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_55443e628a89",
        "power_net_b81a8e339338",
        "power_net_3ecb4d4cd8ac",
        "power_net_33017e9a066b",
        "power_net_e8a759043e79",
        "power_net_cd1e0a0c9a0e",
        "power_net_ae3413231f47"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1501",
          "pin": "1",
          "netId": "power_net_55443e628a89",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "2",
          "netId": "power_net_55443e628a89",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "3",
          "netId": "power_net_55443e628a89",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "4",
          "netId": "power_net_b81a8e339338",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "5",
          "netId": "power_net_3ecb4d4cd8ac",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "7",
          "netId": "power_net_33017e9a066b",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "14",
          "netId": "power_net_33017e9a066b",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "9",
          "netId": "power_net_e8a759043e79",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "13",
          "netId": "power_net_ae3413231f47",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание памяти DDR3L",
      "text": "U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.",
      "body": "U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.",
      "nodes": [
        "sheet1600"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_1d82566a37af",
        "power_net_ed26aaa81531",
        "power_net_3f8a62ed2da9",
        "power_net_978b64498138",
        "power_net_4ff2f354d5ba",
        "power_net_cd1e0a0c9a0e",
        "power_net_005a44b1c652"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1601",
          "pin": "1",
          "netId": "power_net_1d82566a37af",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "2",
          "netId": "power_net_1d82566a37af",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "3",
          "netId": "power_net_1d82566a37af",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "5",
          "netId": "power_net_3f8a62ed2da9",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "7",
          "netId": "power_net_978b64498138",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "14",
          "netId": "power_net_978b64498138",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "9",
          "netId": "power_net_4ff2f354d5ba",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "13",
          "netId": "power_net_005a44b1c652",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание ядра Ethernet PHY",
      "text": "U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.",
      "body": "U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.",
      "nodes": [
        "sheet1700"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_e2a38e9401f4",
        "power_net_ac83bbc60cc7",
        "power_net_c273117280e8",
        "power_net_086f4f3255c8",
        "power_net_4cedc6c1ccf2",
        "power_net_cd1e0a0c9a0e",
        "power_net_055c51598970"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1701",
          "pin": "1",
          "netId": "power_net_e2a38e9401f4",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "2",
          "netId": "power_net_e2a38e9401f4",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "3",
          "netId": "power_net_e2a38e9401f4",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "4",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "5",
          "netId": "power_net_c273117280e8",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "7",
          "netId": "power_net_086f4f3255c8",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "14",
          "netId": "power_net_086f4f3255c8",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "9",
          "netId": "power_net_4cedc6c1ccf2",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "13",
          "netId": "power_net_055c51598970",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание и опора терминации DDR",
      "text": "U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.",
      "body": "U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.",
      "nodes": [
        "sheet1800"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_a494eb253ace",
        "power_net_f3a748e4fa19",
        "power_net_e295c6eba3ce",
        "power_net_fd4fbf0c155f",
        "power_net_49a6d57a88bc",
        "power_net_0ee4f5245d75",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1801",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "REFIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "2",
          "netId": "power_net_f3a748e4fa19",
          "name": "VLDOIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "3",
          "netId": "power_net_e295c6eba3ce",
          "name": "VO",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "5",
          "netId": "power_net_e295c6eba3ce",
          "name": "VOSNS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "6",
          "netId": "power_net_fd4fbf0c155f",
          "name": "REFOUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "7",
          "netId": "power_net_49a6d57a88bc",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Малошумящее аналоговое питание 5 В",
      "text": "U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.",
      "body": "U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.",
      "nodes": [
        "sheet1900"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_4716fe94234d",
        "power_net_d033005e565e",
        "power_net_99aaef80128f",
        "power_net_f8cf954155c7",
        "power_net_a22147576fa0",
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "2",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "3",
          "netId": "power_net_d033005e565e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "5",
          "netId": "power_net_99aaef80128f",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "7",
          "netId": "power_net_f8cf954155c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "8",
          "netId": "power_net_a22147576fa0",
          "name": "NR/SS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "9",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "10",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Малошумящее аналоговое питание 3,3 В",
      "text": "U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.",
      "body": "U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.",
      "nodes": [
        "sheet2000"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_a207f0246008",
        "power_net_0192549c3eb6",
        "power_net_e1dd2bfabf3b",
        "power_net_8a3bb3e9fe35",
        "power_net_665362b38beb",
        "power_net_f5932d689562"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2001",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "2",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "3",
          "netId": "power_net_0192549c3eb6",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "5",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "7",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "8",
          "netId": "power_net_665362b38beb",
          "name": "NR/SS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "9",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "10",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Питание ядра ПЛИС",
      "text": "U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.",
      "body": "U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.",
      "nodes": [
        "sheet1200"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_25f4b9dd8faf",
        "power_net_cd1e0a0c9a0e",
        "power_net_a1556093443e",
        "power_net_4a30a9f331e1",
        "power_net_50cf3ae624b1",
        "power_net_0828b35e4b6c",
        "power_net_95f2aea4f265",
        "power_net_f04a3136bae5",
        "power_net_44d5eba2ecef"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1201",
          "pin": "1",
          "netId": "power_net_25f4b9dd8faf",
          "name": "BOOT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "2",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "VIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "6",
          "netId": "power_net_a1556093443e",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "7",
          "netId": "power_net_a1556093443e",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "13",
          "netId": "power_net_4a30a9f331e1",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "14",
          "netId": "power_net_50cf3ae624b1",
          "name": "SS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "15",
          "netId": "power_net_0828b35e4b6c",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "16",
          "netId": "power_net_95f2aea4f265",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "17",
          "netId": "power_net_f04a3136bae5",
          "name": "VREG5",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1201",
          "pin": "18",
          "netId": "power_net_44d5eba2ecef",
          "name": "MODE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Вспомогательное питание ПЛИС 1,8 В",
      "text": "U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.",
      "body": "U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.",
      "nodes": [
        "sheet1300"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_438a56c0fd28",
        "power_net_b80a0b0c471f",
        "power_net_ee6e52656b26",
        "power_net_72aaeb0dd85a",
        "power_net_7aa373b3d11c",
        "power_net_cd1e0a0c9a0e",
        "power_net_91608c5bec4e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1301",
          "pin": "1",
          "netId": "power_net_438a56c0fd28",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "2",
          "netId": "power_net_438a56c0fd28",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "3",
          "netId": "power_net_438a56c0fd28",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "4",
          "netId": "power_net_b80a0b0c471f",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "5",
          "netId": "power_net_ee6e52656b26",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "7",
          "netId": "power_net_72aaeb0dd85a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "14",
          "netId": "power_net_72aaeb0dd85a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "9",
          "netId": "power_net_7aa373b3d11c",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1301",
          "pin": "13",
          "netId": "power_net_91608c5bec4e",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Вспомогательное питание 2,5 В",
      "text": "U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.",
      "body": "U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.",
      "nodes": [
        "sheet1400"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_3a7ca3c79de6",
        "power_net_fcfa30509d75",
        "power_net_b07a46e4f6c7",
        "power_net_38cd986dd59a",
        "power_net_918357f17ed8",
        "power_net_cd1e0a0c9a0e",
        "power_net_8d8d482ee874"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1401",
          "pin": "1",
          "netId": "power_net_3a7ca3c79de6",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "2",
          "netId": "power_net_3a7ca3c79de6",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "3",
          "netId": "power_net_3a7ca3c79de6",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "4",
          "netId": "power_net_fcfa30509d75",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "5",
          "netId": "power_net_b07a46e4f6c7",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "7",
          "netId": "power_net_38cd986dd59a",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "14",
          "netId": "power_net_38cd986dd59a",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "9",
          "netId": "power_net_918357f17ed8",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1401",
          "pin": "13",
          "netId": "power_net_8d8d482ee874",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание выводов ПЛИС 3,3 В",
      "text": "U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.",
      "body": "U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.",
      "nodes": [
        "sheet1500"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_55443e628a89",
        "power_net_b81a8e339338",
        "power_net_3ecb4d4cd8ac",
        "power_net_33017e9a066b",
        "power_net_e8a759043e79",
        "power_net_cd1e0a0c9a0e",
        "power_net_ae3413231f47"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1501",
          "pin": "1",
          "netId": "power_net_55443e628a89",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "2",
          "netId": "power_net_55443e628a89",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "3",
          "netId": "power_net_55443e628a89",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "4",
          "netId": "power_net_b81a8e339338",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "5",
          "netId": "power_net_3ecb4d4cd8ac",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "7",
          "netId": "power_net_33017e9a066b",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "14",
          "netId": "power_net_33017e9a066b",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "9",
          "netId": "power_net_e8a759043e79",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1501",
          "pin": "13",
          "netId": "power_net_ae3413231f47",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание памяти DDR3L",
      "text": "U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.",
      "body": "U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.",
      "nodes": [
        "sheet1600"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_1d82566a37af",
        "power_net_ed26aaa81531",
        "power_net_3f8a62ed2da9",
        "power_net_978b64498138",
        "power_net_4ff2f354d5ba",
        "power_net_cd1e0a0c9a0e",
        "power_net_005a44b1c652"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1601",
          "pin": "1",
          "netId": "power_net_1d82566a37af",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "2",
          "netId": "power_net_1d82566a37af",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "3",
          "netId": "power_net_1d82566a37af",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "5",
          "netId": "power_net_3f8a62ed2da9",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "7",
          "netId": "power_net_978b64498138",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "14",
          "netId": "power_net_978b64498138",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "9",
          "netId": "power_net_4ff2f354d5ba",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1601",
          "pin": "13",
          "netId": "power_net_005a44b1c652",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание ядра Ethernet PHY",
      "text": "U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.",
      "body": "U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.",
      "nodes": [
        "sheet1700"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_e2a38e9401f4",
        "power_net_ac83bbc60cc7",
        "power_net_c273117280e8",
        "power_net_086f4f3255c8",
        "power_net_4cedc6c1ccf2",
        "power_net_cd1e0a0c9a0e",
        "power_net_055c51598970"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1701",
          "pin": "1",
          "netId": "power_net_e2a38e9401f4",
          "name": "SW",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "2",
          "netId": "power_net_e2a38e9401f4",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "3",
          "netId": "power_net_e2a38e9401f4",
          "name": "SW",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "4",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "5",
          "netId": "power_net_c273117280e8",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "7",
          "netId": "power_net_086f4f3255c8",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "14",
          "netId": "power_net_086f4f3255c8",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "9",
          "netId": "power_net_4cedc6c1ccf2",
          "name": "SS/TR",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "13",
          "netId": "power_net_055c51598970",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питание и опора терминации DDR",
      "text": "U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.",
      "body": "U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.",
      "nodes": [
        "sheet1800"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_a494eb253ace",
        "power_net_f3a748e4fa19",
        "power_net_e295c6eba3ce",
        "power_net_fd4fbf0c155f",
        "power_net_49a6d57a88bc",
        "power_net_0ee4f5245d75",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1801",
          "pin": "1",
          "netId": "power_net_a494eb253ace",
          "name": "REFIN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "2",
          "netId": "power_net_f3a748e4fa19",
          "name": "VLDOIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "3",
          "netId": "power_net_e295c6eba3ce",
          "name": "VO",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "5",
          "netId": "power_net_e295c6eba3ce",
          "name": "VOSNS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "6",
          "netId": "power_net_fd4fbf0c155f",
          "name": "REFOUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "7",
          "netId": "power_net_49a6d57a88bc",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1801",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Малошумящее аналоговое питание 5 В",
      "text": "U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.",
      "body": "U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.",
      "nodes": [
        "sheet1900"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_4716fe94234d",
        "power_net_d033005e565e",
        "power_net_99aaef80128f",
        "power_net_f8cf954155c7",
        "power_net_a22147576fa0",
        "power_net_bbc855740138"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1901",
          "pin": "1",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "2",
          "netId": "power_net_4716fe94234d",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "3",
          "netId": "power_net_d033005e565e",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "5",
          "netId": "power_net_99aaef80128f",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "7",
          "netId": "power_net_f8cf954155c7",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "8",
          "netId": "power_net_a22147576fa0",
          "name": "NR/SS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "9",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1901",
          "pin": "10",
          "netId": "power_net_bbc855740138",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Малошумящее аналоговое питание 3,3 В",
      "text": "U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.",
      "body": "U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.",
      "nodes": [
        "sheet2000"
      ],
      "edges": [],
      "sceneId": "power-secondary",
      "netIds": [
        "power_net_a207f0246008",
        "power_net_0192549c3eb6",
        "power_net_e1dd2bfabf3b",
        "power_net_8a3bb3e9fe35",
        "power_net_665362b38beb",
        "power_net_f5932d689562"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2001",
          "pin": "1",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "2",
          "netId": "power_net_a207f0246008",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "3",
          "netId": "power_net_0192549c3eb6",
          "name": "FB",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "5",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PG",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "7",
          "netId": "power_net_8a3bb3e9fe35",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "8",
          "netId": "power_net_665362b38beb",
          "name": "NR/SS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "9",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2001",
          "pin": "10",
          "netId": "power_net_f5932d689562",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
