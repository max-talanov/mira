/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_300_MCU_QSPI_MICROSD_AND_CONTROL",
  "title": "Как работает: Память и управление платой",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
  "steps": [
    {
      "title": "Хост выбирает хранилище",
      "text": "STM32 обращается к постоянной QSPI-памяти или съёмной карте. Это разные интерфейсы и разные способы хранения данных.",
      "body": "STM32 обращается к постоянной QSPI-памяти или съёмной карте. Это разные интерфейсы и разные способы хранения данных.",
      "nodes": [
        "host",
        "flash",
        "card"
      ],
      "edges": [
        "host_flash",
        "host_card"
      ],
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "netIds": [
        "control_net_1ae330a90d69",
        "control_net_dbb8a4cebc4d",
        "control_net_a6d0f4299492",
        "control_net_0afe468f72ab",
        "control_net_c17cd2b70efc",
        "control_net_bfc714f087e0",
        "control_net_94be9f57dcd4",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_119d91accf55",
        "control_net_7f80f60475c4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U300",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R304",
          "pin": "2",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R309",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "3",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "WP_N_/_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R307",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R310",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "7",
          "netId": "control_net_a6d0f4299492",
          "name": "HOLD_N_/_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R308",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R311",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R303",
          "pin": "1",
          "netId": "control_net_0afe468f72ab",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R306",
          "pin": "1",
          "netId": "control_net_c17cd2b70efc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R305",
          "pin": "1",
          "netId": "control_net_bfc714f087e0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "9",
          "netId": "control_net_94be9f57dcd4",
          "name": "DETECT1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R323",
          "pin": "2",
          "netId": "control_net_94be9f57dcd4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R315",
          "pin": "1",
          "netId": "control_net_adae77af0ed0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R317",
          "pin": "1",
          "netId": "control_net_3792d8c5e55e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R312",
          "pin": "1",
          "netId": "control_net_24c9b5fda4e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R313",
          "pin": "1",
          "netId": "control_net_0a220a15306e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R314",
          "pin": "1",
          "netId": "control_net_119d91accf55",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R316",
          "pin": "1",
          "netId": "control_net_7f80f60475c4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обмен с постоянной памятью",
      "text": "QSPI-соединения связывают STM32 с микросхемой Flash; записанные данные сохраняются без питания. Конкретный формат данных задаёт программа.",
      "body": "QSPI-соединения связывают STM32 с микросхемой Flash; записанные данные сохраняются без питания. Конкретный формат данных задаёт программа.",
      "nodes": [
        "host",
        "flash"
      ],
      "edges": [
        "host_flash"
      ],
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "netIds": [
        "control_net_1ae330a90d69",
        "control_net_dbb8a4cebc4d",
        "control_net_a6d0f4299492",
        "control_net_0afe468f72ab",
        "control_net_c17cd2b70efc",
        "control_net_bfc714f087e0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U300",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R304",
          "pin": "2",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R309",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "3",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "WP_N_/_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R307",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R310",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "7",
          "netId": "control_net_a6d0f4299492",
          "name": "HOLD_N_/_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R308",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R311",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R303",
          "pin": "1",
          "netId": "control_net_0afe468f72ab",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R306",
          "pin": "1",
          "netId": "control_net_c17cd2b70efc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R305",
          "pin": "1",
          "netId": "control_net_bfc714f087e0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обмен со съёмной картой",
      "text": "Линии карты проходят через защитные устройства возле разъёма. Они ограничивают электростатические воздействия и не декодируют данные.",
      "body": "Линии карты проходят через защитные устройства возле разъёма. Они ограничивают электростатические воздействия и не декодируют данные.",
      "nodes": [
        "host",
        "protect",
        "card"
      ],
      "edges": [
        "host_card"
      ],
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "netIds": [
        "control_net_94be9f57dcd4",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_119d91accf55",
        "control_net_7f80f60475c4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J300",
          "pin": "9",
          "netId": "control_net_94be9f57dcd4",
          "name": "DETECT1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R323",
          "pin": "2",
          "netId": "control_net_94be9f57dcd4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R315",
          "pin": "1",
          "netId": "control_net_adae77af0ed0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R317",
          "pin": "1",
          "netId": "control_net_3792d8c5e55e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R312",
          "pin": "1",
          "netId": "control_net_24c9b5fda4e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R313",
          "pin": "1",
          "netId": "control_net_0a220a15306e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R314",
          "pin": "1",
          "netId": "control_net_119d91accf55",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R316",
          "pin": "1",
          "netId": "control_net_7f80f60475c4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Хост выбирает хранилище",
      "text": "STM32 обращается к постоянной QSPI-памяти или съёмной карте. Это разные интерфейсы и разные способы хранения данных.",
      "body": "STM32 обращается к постоянной QSPI-памяти или съёмной карте. Это разные интерфейсы и разные способы хранения данных.",
      "nodes": [
        "host",
        "flash",
        "card"
      ],
      "edges": [
        "host_flash",
        "host_card"
      ],
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "netIds": [
        "control_net_1ae330a90d69",
        "control_net_dbb8a4cebc4d",
        "control_net_a6d0f4299492",
        "control_net_0afe468f72ab",
        "control_net_c17cd2b70efc",
        "control_net_bfc714f087e0",
        "control_net_94be9f57dcd4",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_119d91accf55",
        "control_net_7f80f60475c4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U300",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R304",
          "pin": "2",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R309",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "3",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "WP_N_/_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R307",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R310",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "7",
          "netId": "control_net_a6d0f4299492",
          "name": "HOLD_N_/_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R308",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R311",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R303",
          "pin": "1",
          "netId": "control_net_0afe468f72ab",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R306",
          "pin": "1",
          "netId": "control_net_c17cd2b70efc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R305",
          "pin": "1",
          "netId": "control_net_bfc714f087e0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J300",
          "pin": "9",
          "netId": "control_net_94be9f57dcd4",
          "name": "DETECT1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R323",
          "pin": "2",
          "netId": "control_net_94be9f57dcd4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R315",
          "pin": "1",
          "netId": "control_net_adae77af0ed0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R317",
          "pin": "1",
          "netId": "control_net_3792d8c5e55e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R312",
          "pin": "1",
          "netId": "control_net_24c9b5fda4e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R313",
          "pin": "1",
          "netId": "control_net_0a220a15306e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R314",
          "pin": "1",
          "netId": "control_net_119d91accf55",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R316",
          "pin": "1",
          "netId": "control_net_7f80f60475c4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обмен с постоянной памятью",
      "text": "QSPI-соединения связывают STM32 с микросхемой Flash; записанные данные сохраняются без питания. Конкретный формат данных задаёт программа.",
      "body": "QSPI-соединения связывают STM32 с микросхемой Flash; записанные данные сохраняются без питания. Конкретный формат данных задаёт программа.",
      "nodes": [
        "host",
        "flash"
      ],
      "edges": [
        "host_flash"
      ],
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "netIds": [
        "control_net_1ae330a90d69",
        "control_net_dbb8a4cebc4d",
        "control_net_a6d0f4299492",
        "control_net_0afe468f72ab",
        "control_net_c17cd2b70efc",
        "control_net_bfc714f087e0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U300",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R304",
          "pin": "2",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R309",
          "pin": "1",
          "netId": "control_net_1ae330a90d69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "3",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "WP_N_/_IO2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R307",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R310",
          "pin": "1",
          "netId": "control_net_dbb8a4cebc4d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U300",
          "pin": "7",
          "netId": "control_net_a6d0f4299492",
          "name": "HOLD_N_/_IO3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R308",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R311",
          "pin": "2",
          "netId": "control_net_a6d0f4299492",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R303",
          "pin": "1",
          "netId": "control_net_0afe468f72ab",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "57",
          "netId": "control_net_0afe468f72ab",
          "name": "PB2_/_QSPI_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R306",
          "pin": "1",
          "netId": "control_net_c17cd2b70efc",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "95",
          "netId": "control_net_c17cd2b70efc",
          "name": "PD12_/_QSPI_IO1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "94",
          "netId": "control_net_bfc714f087e0",
          "name": "PD11_/_QSPI_IO0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R305",
          "pin": "1",
          "netId": "control_net_bfc714f087e0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обмен со съёмной картой",
      "text": "Линии карты проходят через защитные устройства возле разъёма. Они ограничивают электростатические воздействия и не декодируют данные.",
      "body": "Линии карты проходят через защитные устройства возле разъёма. Они ограничивают электростатические воздействия и не декодируют данные.",
      "nodes": [
        "host",
        "protect",
        "card"
      ],
      "edges": [
        "host_card"
      ],
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "netIds": [
        "control_net_94be9f57dcd4",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_119d91accf55",
        "control_net_7f80f60475c4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J300",
          "pin": "9",
          "netId": "control_net_94be9f57dcd4",
          "name": "DETECT1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R323",
          "pin": "2",
          "netId": "control_net_94be9f57dcd4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "116",
          "netId": "control_net_94be9f57dcd4",
          "name": "PG6_/_SD_CD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R315",
          "pin": "1",
          "netId": "control_net_adae77af0ed0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "141",
          "netId": "control_net_adae77af0ed0",
          "name": "PC11_/_SD_D3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R317",
          "pin": "1",
          "netId": "control_net_3792d8c5e55e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "142",
          "netId": "control_net_3792d8c5e55e",
          "name": "PC12_/_SD_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R312",
          "pin": "1",
          "netId": "control_net_24c9b5fda4e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "124",
          "netId": "control_net_24c9b5fda4e5",
          "name": "PC8_/_SD_D0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "125",
          "netId": "control_net_0a220a15306e",
          "name": "PC9_/_SD_D1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R313",
          "pin": "1",
          "netId": "control_net_0a220a15306e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "140",
          "netId": "control_net_119d91accf55",
          "name": "PC10_/_SD_D2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R314",
          "pin": "1",
          "netId": "control_net_119d91accf55",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "145",
          "netId": "control_net_7f80f60475c4",
          "name": "PD2_/_SD_CMD",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R316",
          "pin": "1",
          "netId": "control_net_7f80f60475c4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
