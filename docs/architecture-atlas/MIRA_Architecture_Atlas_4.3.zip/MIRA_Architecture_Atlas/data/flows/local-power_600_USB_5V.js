/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_600_USB_5V",
  "title": "Как работает: Питание USB 5 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_600_USB_5V",
  "steps": [
    {
      "title": "На вход приходит BUS24",
      "text": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U601",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_6649c6cdd008",
        "power_net_7cbabff32742"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q601",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R601",
          "pin": "2",
          "netId": "power_net_7cbabff32742",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q601",
          "pin": "2",
          "netId": "power_net_7cbabff32742",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "4",
          "netId": "power_net_7cbabff32742",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует USB5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину USB5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину USB5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_4413b84fafe0",
        "power_net_17beae47ec7a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R605",
          "pin": "1",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R604",
          "pin": "2",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C605",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C604",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R604",
          "pin": "1",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L601",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R602",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования USB5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования USB5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_4413b84fafe0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R605",
          "pin": "1",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R604",
          "pin": "2",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит BUS24",
      "text": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина BUS24 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_46d0d8d77ef1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U601",
          "pin": "5",
          "netId": "power_net_46d0d8d77ef1",
          "name": "VIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_6649c6cdd008",
        "power_net_7cbabff32742"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q601",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R601",
          "pin": "2",
          "netId": "power_net_7cbabff32742",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q601",
          "pin": "2",
          "netId": "power_net_7cbabff32742",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U601",
          "pin": "4",
          "netId": "power_net_7cbabff32742",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует USB5",
      "text": "Регулятор и цепь обратной связи формируют выходную шину USB5. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину USB5. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_4413b84fafe0",
        "power_net_17beae47ec7a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R605",
          "pin": "1",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R604",
          "pin": "2",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C605",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C604",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R604",
          "pin": "1",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L601",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R602",
          "pin": "2",
          "netId": "power_net_17beae47ec7a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования USB5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования USB5 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_600_USB_5V",
      "netIds": [
        "power_net_4413b84fafe0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R605",
          "pin": "1",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R604",
          "pin": "2",
          "netId": "power_net_4413b84fafe0",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
