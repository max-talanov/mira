/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_500_FPGA_POWER_AND_DECOUPLING",
  "title": "Как работает: Питание ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
  "steps": [
    {
      "title": "Подводится питание ядра",
      "text": "Шина CORE1V0 питает внутреннюю логику и блочную память ПЛИС. Это отдельный домен от питания выводов.",
      "body": "Шина CORE1V0 питает внутреннюю логику и блочную память ПЛИС. Это отдельный домен от питания выводов.",
      "nodes": [
        "reservoir",
        "core"
      ],
      "edges": [
        "reservoir_core_0"
      ],
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "netIds": [
        "control_net_4bfa9adb9035"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C504",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C538",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C514",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C506",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C515",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C518",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C508",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C500",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C507",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C526",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C510",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C505",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C522",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C524",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C525",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C516",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C523",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C513",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C511",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C512",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C521",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C539",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C519",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C536",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C509",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C520",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C501",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C503",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C502",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C537",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C517",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Поддерживаются локальные токи",
      "text": "Локальные и накопительные конденсаторы поддерживают соответствующие шины непосредственно у секций ПЛИС.",
      "body": "Локальные и накопительные конденсаторы поддерживают соответствующие шины непосредственно у секций ПЛИС.",
      "nodes": [
        "reservoir",
        "aux",
        "core"
      ],
      "edges": [
        "reservoir_core_0",
        "aux_core_1"
      ],
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "netIds": [
        "control_net_4bfa9adb9035",
        "control_net_6f005443ad9c",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C504",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C538",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C514",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C506",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C515",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C518",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C508",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C500",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C507",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C526",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C510",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C505",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C522",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C524",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C525",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C516",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C523",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C513",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C511",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C512",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C521",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C539",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C519",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C536",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C509",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C520",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C501",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C503",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C502",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C537",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C517",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C555",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C551",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C558",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C557",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C563",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C545",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C566",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C560",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C559",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C562",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C554",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C565",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C556",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C540",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C544",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C552",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C549",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C548",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C547",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C561",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C541",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C542",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C543",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C564",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C550",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C568",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C567",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C553",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C546",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C527",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C530",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C528",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C534",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C529",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C533",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C532",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C531",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C535",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C576",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C570",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C572",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B14",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D18",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E15",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F22",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G19",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H16",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J13",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K20",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C575",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C578",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C580",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C577",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C569",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C574",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C581",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C579",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C571",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C573",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питаются вспомогательные домены",
      "text": "Вспомогательное питание и питание банков ввода-вывода имеют собственные цепи. На схеме можно выделить каждый домен и его выводы.",
      "body": "Вспомогательное питание и питание банков ввода-вывода имеют собственные цепи. На схеме можно выделить каждый домен и его выводы.",
      "nodes": [
        "aux",
        "core"
      ],
      "edges": [
        "aux_core_1"
      ],
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C555",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C551",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C558",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C557",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C563",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C545",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C566",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C560",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C559",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C562",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C554",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C565",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C556",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C540",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C544",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C552",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C549",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C548",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C547",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C561",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C541",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C542",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C543",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C564",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C550",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C568",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C567",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C553",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C546",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C576",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C570",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C572",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B14",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D18",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E15",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F22",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G19",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H16",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J13",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K20",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C575",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C578",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C580",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C577",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C569",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C574",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C581",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C579",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C571",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C573",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Подводится питание ядра",
      "text": "Шина CORE1V0 питает внутреннюю логику и блочную память ПЛИС. Это отдельный домен от питания выводов.",
      "body": "Шина CORE1V0 питает внутреннюю логику и блочную память ПЛИС. Это отдельный домен от питания выводов.",
      "nodes": [
        "reservoir",
        "core"
      ],
      "edges": [
        "reservoir_core_0"
      ],
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "netIds": [
        "control_net_4bfa9adb9035"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C504",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C538",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C514",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C506",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C515",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C518",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C508",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C500",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C507",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C526",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C510",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C505",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C522",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C524",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C525",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C516",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C523",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C513",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C511",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C512",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C521",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C539",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C519",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C536",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C509",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C520",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C501",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C503",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C502",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C537",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C517",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Поддерживаются локальные токи",
      "text": "Локальные и накопительные конденсаторы поддерживают соответствующие шины непосредственно у секций ПЛИС.",
      "body": "Локальные и накопительные конденсаторы поддерживают соответствующие шины непосредственно у секций ПЛИС.",
      "nodes": [
        "reservoir",
        "aux",
        "core"
      ],
      "edges": [
        "reservoir_core_0",
        "aux_core_1"
      ],
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "netIds": [
        "control_net_4bfa9adb9035",
        "control_net_6f005443ad9c",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C504",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C538",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C514",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C506",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N11",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCBRAM",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R7",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R9",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T8",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T10",
          "netId": "control_net_4bfa9adb9035",
          "name": "VCCINT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C515",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C518",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C508",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C500",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C507",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C526",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C510",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C505",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C522",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C524",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C525",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C516",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C523",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C513",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C511",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C512",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C521",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C539",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C519",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C536",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C509",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C520",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C501",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C503",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C502",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C537",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C517",
          "pin": "1",
          "netId": "control_net_4bfa9adb9035",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C555",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C551",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C558",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C557",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C563",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C545",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C566",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C560",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C559",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C562",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C554",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C565",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C556",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C540",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C544",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C552",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C549",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C548",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C547",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C561",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C541",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C542",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C543",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C564",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C550",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C568",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C567",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C553",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C546",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C527",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C530",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C528",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C534",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C529",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C533",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C532",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C531",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C535",
          "pin": "1",
          "netId": "control_net_fc6dfc0c018d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C576",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C570",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C572",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B14",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D18",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E15",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F22",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G19",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H16",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J13",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K20",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C575",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C578",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C580",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C577",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C569",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C574",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C581",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C579",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C571",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C573",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Питаются вспомогательные домены",
      "text": "Вспомогательное питание и питание банков ввода-вывода имеют собственные цепи. На схеме можно выделить каждый домен и его выводы.",
      "body": "Вспомогательное питание и питание банков ввода-вывода имеют собственные цепи. На схеме можно выделить каждый домен и его выводы.",
      "nodes": [
        "aux",
        "core"
      ],
      "edges": [
        "aux_core_1"
      ],
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C555",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C551",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C558",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C557",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C563",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C545",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C566",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C560",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C559",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C562",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C554",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C565",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C556",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA7",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA17",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M4",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M14",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N1",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_35",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P18",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R15",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T2",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T12",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_0",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T22",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U19",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V6",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W3",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_34",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W13",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y10",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_13",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y20",
          "netId": "control_net_6f005443ad9c",
          "name": "VCCO_14",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C540",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C544",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C552",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C549",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C548",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C547",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C561",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C541",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C542",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C543",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C564",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C550",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C568",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C567",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C553",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C546",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P12",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R11",
          "netId": "control_net_fc6dfc0c018d",
          "name": "VCCAUX",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C576",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C570",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C572",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B14",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D18",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E15",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F22",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G19",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H16",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J13",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K20",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L17",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N21",
          "netId": "control_net_a0d28f360159",
          "name": "VCCO_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C575",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C578",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C580",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C577",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C569",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C574",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C581",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C579",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C571",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C573",
          "pin": "1",
          "netId": "control_net_a0d28f360159",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
