/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "title": "Как работает: Память и тактирование ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "steps": [
    {
      "title": "Появляется опорная частота",
      "text": "Дифференциальный генератор подаёт опорный сигнал 200 МГц на ПЛИС. Дальнейшие частоты интерфейса формирует проект ПЛИС.",
      "body": "Дифференциальный генератор подаёт опорный сигнал 200 МГц на ПЛИС. Дальнейшие частоты интерфейса формирует проект ПЛИС.",
      "nodes": [
        "clock",
        "fpga"
      ],
      "edges": [
        "clock_fpga_0"
      ],
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "netIds": [
        "control_net_c31eb8fe07d3",
        "control_net_d44f364a5830",
        "control_net_3bfe72ccfc41",
        "control_net_21a5e9f13f7f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "J19",
          "netId": "control_net_c31eb8fe07d3",
          "name": "IO_L12P_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H19",
          "netId": "control_net_d44f364a5830",
          "name": "IO_L12N_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y800",
          "pin": "5",
          "netId": "control_net_3bfe72ccfc41",
          "name": "OUT_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y800",
          "pin": "4",
          "netId": "control_net_21a5e9f13f7f",
          "name": "OUT_P",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "ПЛИС адресует память",
      "text": "Команды, адреса и тактовые линии соединяют U500 с DDR3L. Цепи VTT и DDR_VREF задают требуемые уровни терминации и опоры.",
      "body": "Команды, адреса и тактовые линии соединяют U500 с DDR3L. Цепи VTT и DDR_VREF задают требуемые уровни терминации и опоры.",
      "nodes": [
        "fpga",
        "termination",
        "memory"
      ],
      "edges": [
        "fpga_memory_1",
        "fpga_memory_2",
        "termination_memory_3"
      ],
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "netIds": [
        "control_net_58af204d8c23",
        "control_net_cccff17550b9",
        "control_net_f4bfe5cdab56",
        "control_net_4bb6a512cc3a",
        "control_net_19bcc72c5488",
        "control_net_185955b3a706",
        "control_net_d109bb25230c",
        "control_net_d9ef0a17e785",
        "control_net_fd2bad63a67c",
        "control_net_bb3aaa71ba05",
        "control_net_907e4adf7ca2",
        "control_net_ebaa690e703b",
        "control_net_92d89f9df56c",
        "control_net_c4d0ccc3d16d",
        "control_net_5220b4a56b5c",
        "control_net_d7ba445b9916",
        "control_net_395f29bc0592",
        "control_net_be534772f175",
        "control_net_42df6ae20837",
        "control_net_075227a69d18",
        "control_net_707df60aeb98",
        "control_net_abae69816039",
        "control_net_4baca15034bf",
        "control_net_4143ff0aef6d",
        "control_net_3ddfecb0df47",
        "control_net_1d61ccb9d017",
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_010b6b6f67c9",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a",
        "control_net_01f75bd2f12a",
        "control_net_5fb1532b0e1e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R814",
          "pin": "1",
          "netId": "control_net_58af204d8c23",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R2",
          "netId": "control_net_58af204d8c23",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N20",
          "netId": "control_net_58af204d8c23",
          "name": "IO_L18P_T2_A24_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R807",
          "pin": "1",
          "netId": "control_net_cccff17550b9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N3",
          "netId": "control_net_cccff17550b9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M15",
          "netId": "control_net_cccff17550b9",
          "name": "IO_L24P_T3_RS1_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R818",
          "pin": "1",
          "netId": "control_net_f4bfe5cdab56",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R7",
          "netId": "control_net_f4bfe5cdab56",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M22",
          "netId": "control_net_f4bfe5cdab56",
          "name": "IO_L15N_T2_DQS_ADV_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R813",
          "pin": "1",
          "netId": "control_net_4bb6a512cc3a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R8",
          "netId": "control_net_4bb6a512cc3a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M21",
          "netId": "control_net_4bb6a512cc3a",
          "name": "IO_L10P_T1_AD11P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R820",
          "pin": "1",
          "netId": "control_net_19bcc72c5488",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T3",
          "netId": "control_net_19bcc72c5488",
          "name": "A13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N18",
          "netId": "control_net_19bcc72c5488",
          "name": "IO_L17P_T2_A26_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R809",
          "pin": "1",
          "netId": "control_net_185955b3a706",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P3",
          "netId": "control_net_185955b3a706",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M16",
          "netId": "control_net_185955b3a706",
          "name": "IO_L24N_T3_RS0_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R823",
          "pin": "1",
          "netId": "control_net_d109bb25230c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N8",
          "netId": "control_net_d109bb25230c",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J20",
          "netId": "control_net_d109bb25230c",
          "name": "IO_L11P_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R826",
          "pin": "1",
          "netId": "control_net_d9ef0a17e785",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K3",
          "netId": "control_net_d9ef0a17e785",
          "name": "~{CAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K18",
          "netId": "control_net_d9ef0a17e785",
          "name": "IO_L13P_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R824",
          "pin": "1",
          "netId": "control_net_fd2bad63a67c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M3",
          "netId": "control_net_fd2bad63a67c",
          "name": "BA2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L20",
          "netId": "control_net_fd2bad63a67c",
          "name": "IO_L14N_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R825",
          "pin": "1",
          "netId": "control_net_bb3aaa71ba05",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J3",
          "netId": "control_net_bb3aaa71ba05",
          "name": "~{RAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H20",
          "netId": "control_net_bb3aaa71ba05",
          "name": "IO_L8P_T1_AD10P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R819",
          "pin": "1",
          "netId": "control_net_907e4adf7ca2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N7",
          "netId": "control_net_907e4adf7ca2",
          "name": "A12/~{BC}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K22",
          "netId": "control_net_907e4adf7ca2",
          "name": "IO_L9N_T1_DQS_AD3N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R806",
          "pin": "1",
          "netId": "control_net_ebaa690e703b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T2",
          "netId": "control_net_ebaa690e703b",
          "name": "~{RESET}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K16",
          "netId": "control_net_ebaa690e703b",
          "name": "IO_L23N_T3_FWE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R815",
          "pin": "1",
          "netId": "control_net_92d89f9df56c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T8",
          "netId": "control_net_92d89f9df56c",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M20",
          "netId": "control_net_92d89f9df56c",
          "name": "IO_L18N_T2_A23_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R830",
          "pin": "1",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J7",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "CK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K17",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "IO_L21P_T3_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R830",
          "pin": "2",
          "netId": "control_net_5220b4a56b5c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K7",
          "netId": "control_net_5220b4a56b5c",
          "name": "~{CK}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J17",
          "netId": "control_net_5220b4a56b5c",
          "name": "IO_L21N_T3_DQS_A18_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R811",
          "pin": "1",
          "netId": "control_net_d7ba445b9916",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P8",
          "netId": "control_net_d7ba445b9916",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K21",
          "netId": "control_net_d7ba445b9916",
          "name": "IO_L9P_T1_DQS_AD3P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K1",
          "netId": "control_net_395f29bc0592",
          "name": "ODT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R829",
          "pin": "1",
          "netId": "control_net_395f29bc0592",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K19",
          "netId": "control_net_395f29bc0592",
          "name": "IO_L13N_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K9",
          "netId": "control_net_be534772f175",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R828",
          "pin": "1",
          "netId": "control_net_be534772f175",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H22",
          "netId": "control_net_be534772f175",
          "name": "IO_L7N_T1_AD2N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L3",
          "netId": "control_net_42df6ae20837",
          "name": "~{WE}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R827",
          "pin": "1",
          "netId": "control_net_42df6ae20837",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L16",
          "netId": "control_net_42df6ae20837",
          "name": "IO_L23P_T3_FOE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L7",
          "netId": "control_net_075227a69d18",
          "name": "A10/AP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J21",
          "netId": "control_net_075227a69d18",
          "name": "IO_L11N_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R817",
          "pin": "1",
          "netId": "control_net_075227a69d18",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M2",
          "netId": "control_net_707df60aeb98",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L19",
          "netId": "control_net_707df60aeb98",
          "name": "IO_L14P_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R822",
          "pin": "1",
          "netId": "control_net_707df60aeb98",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N2",
          "netId": "control_net_abae69816039",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R810",
          "pin": "1",
          "netId": "control_net_abae69816039",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L18",
          "netId": "control_net_abae69816039",
          "name": "IO_L16N_T2_A27_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P2",
          "netId": "control_net_4baca15034bf",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R812",
          "pin": "1",
          "netId": "control_net_4baca15034bf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M18",
          "netId": "control_net_4baca15034bf",
          "name": "IO_L16P_T2_A28_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P7",
          "netId": "control_net_4143ff0aef6d",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R808",
          "pin": "1",
          "netId": "control_net_4143ff0aef6d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L21",
          "netId": "control_net_4143ff0aef6d",
          "name": "IO_L10N_T1_AD11N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R3",
          "netId": "control_net_3ddfecb0df47",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N19",
          "netId": "control_net_3ddfecb0df47",
          "name": "IO_L17N_T2_A25_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R816",
          "pin": "1",
          "netId": "control_net_3ddfecb0df47",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T7",
          "netId": "control_net_1d61ccb9d017",
          "name": "A14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R821",
          "pin": "1",
          "netId": "control_net_1d61ccb9d017",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N22",
          "netId": "control_net_1d61ccb9d017",
          "name": "IO_L15P_T2_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A19",
          "netId": "control_net_6943e9712d9c",
          "name": "IO_L17N_T2_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E7",
          "netId": "control_net_6943e9712d9c",
          "name": "LDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A20",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "IO_L16N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F8",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A21",
          "netId": "control_net_ac8599a8c0cd",
          "name": "IO_L21N_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B7",
          "netId": "control_net_ac8599a8c0cd",
          "name": "~{UDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B20",
          "netId": "control_net_c5d6e41ef012",
          "name": "IO_L16P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F7",
          "netId": "control_net_c5d6e41ef012",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B21",
          "netId": "control_net_49b164ada644",
          "name": "IO_L21P_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C7",
          "netId": "control_net_49b164ada644",
          "name": "UDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B22",
          "netId": "control_net_63a08f54a8af",
          "name": "IO_L20N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B8",
          "netId": "control_net_63a08f54a8af",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C18",
          "netId": "control_net_a46672b578ec",
          "name": "IO_L13P_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H7",
          "netId": "control_net_a46672b578ec",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C19",
          "netId": "control_net_85a84369e22a",
          "name": "IO_L13N_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H8",
          "netId": "control_net_85a84369e22a",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C22",
          "netId": "control_net_010b6b6f67c9",
          "name": "IO_L20P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A7",
          "netId": "control_net_010b6b6f67c9",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D19",
          "netId": "control_net_d514c816e952",
          "name": "IO_L14N_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E3",
          "netId": "control_net_d514c816e952",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D20",
          "netId": "control_net_3a2594a1e1f9",
          "name": "IO_L19P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C8",
          "netId": "control_net_3a2594a1e1f9",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D21",
          "netId": "control_net_9bc7997904a8",
          "name": "IO_L23N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A2",
          "netId": "control_net_9bc7997904a8",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D22",
          "netId": "control_net_6e031edce63d",
          "name": "IO_L22N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A3",
          "netId": "control_net_6e031edce63d",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E18",
          "netId": "control_net_17b46c5249cb",
          "name": "IO_L15N_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G3",
          "netId": "control_net_17b46c5249cb",
          "name": "~{LDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E19",
          "netId": "control_net_4ff8255e049a",
          "name": "IO_L14P_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F2",
          "netId": "control_net_4ff8255e049a",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E21",
          "netId": "control_net_18e1c9509d79",
          "name": "IO_L23P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C2",
          "netId": "control_net_18e1c9509d79",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E22",
          "netId": "control_net_d2bff6eceb03",
          "name": "IO_L22P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D7",
          "netId": "control_net_d2bff6eceb03",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F18",
          "netId": "control_net_dc796dddd274",
          "name": "IO_L15P_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F3",
          "netId": "control_net_dc796dddd274",
          "name": "LDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F19",
          "netId": "control_net_184f5bb728b0",
          "name": "IO_L18P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H3",
          "netId": "control_net_184f5bb728b0",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F20",
          "netId": "control_net_0065f370787e",
          "name": "IO_L18N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G2",
          "netId": "control_net_0065f370787e",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G21",
          "netId": "control_net_710e1e095743",
          "name": "IO_L24P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C3",
          "netId": "control_net_710e1e095743",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G22",
          "netId": "control_net_3a720de9ef0a",
          "name": "IO_L24N_T3_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D3",
          "netId": "control_net_3a720de9ef0a",
          "name": "UDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R814",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R807",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R818",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R813",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R820",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R809",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R823",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R826",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R824",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R825",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R819",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R815",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R811",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R821",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R829",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R808",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R812",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R827",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R828",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R810",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R817",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R816",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R822",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C20",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D15",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "V_{REFDQ}",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M8",
          "netId": "control_net_5fb1532b0e1e",
          "name": "V_{REFCA}",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C836",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C834",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C835",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H18",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K14",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_A21_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C837",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Данные передаются со стробами",
      "text": "16 линий данных и сопутствующие стробы обслуживают запись и чтение DDR3L. Эта история показывает назначение тракта, а не моделирует временную диаграмму памяти.",
      "body": "16 линий данных и сопутствующие стробы обслуживают запись и чтение DDR3L. Эта история показывает назначение тракта, а не моделирует временную диаграмму памяти.",
      "nodes": [
        "fpga",
        "memory"
      ],
      "edges": [
        "fpga_memory_1",
        "fpga_memory_2"
      ],
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "netIds": [
        "control_net_58af204d8c23",
        "control_net_cccff17550b9",
        "control_net_f4bfe5cdab56",
        "control_net_4bb6a512cc3a",
        "control_net_19bcc72c5488",
        "control_net_185955b3a706",
        "control_net_d109bb25230c",
        "control_net_d9ef0a17e785",
        "control_net_fd2bad63a67c",
        "control_net_bb3aaa71ba05",
        "control_net_907e4adf7ca2",
        "control_net_ebaa690e703b",
        "control_net_92d89f9df56c",
        "control_net_c4d0ccc3d16d",
        "control_net_5220b4a56b5c",
        "control_net_d7ba445b9916",
        "control_net_395f29bc0592",
        "control_net_be534772f175",
        "control_net_42df6ae20837",
        "control_net_075227a69d18",
        "control_net_707df60aeb98",
        "control_net_abae69816039",
        "control_net_4baca15034bf",
        "control_net_4143ff0aef6d",
        "control_net_3ddfecb0df47",
        "control_net_1d61ccb9d017",
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_010b6b6f67c9",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U800",
          "pin": "R2",
          "netId": "control_net_58af204d8c23",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N20",
          "netId": "control_net_58af204d8c23",
          "name": "IO_L18P_T2_A24_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N3",
          "netId": "control_net_cccff17550b9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M15",
          "netId": "control_net_cccff17550b9",
          "name": "IO_L24P_T3_RS1_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R7",
          "netId": "control_net_f4bfe5cdab56",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M22",
          "netId": "control_net_f4bfe5cdab56",
          "name": "IO_L15N_T2_DQS_ADV_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R8",
          "netId": "control_net_4bb6a512cc3a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M21",
          "netId": "control_net_4bb6a512cc3a",
          "name": "IO_L10P_T1_AD11P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T3",
          "netId": "control_net_19bcc72c5488",
          "name": "A13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N18",
          "netId": "control_net_19bcc72c5488",
          "name": "IO_L17P_T2_A26_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P3",
          "netId": "control_net_185955b3a706",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M16",
          "netId": "control_net_185955b3a706",
          "name": "IO_L24N_T3_RS0_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N8",
          "netId": "control_net_d109bb25230c",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J20",
          "netId": "control_net_d109bb25230c",
          "name": "IO_L11P_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K3",
          "netId": "control_net_d9ef0a17e785",
          "name": "~{CAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K18",
          "netId": "control_net_d9ef0a17e785",
          "name": "IO_L13P_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M3",
          "netId": "control_net_fd2bad63a67c",
          "name": "BA2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L20",
          "netId": "control_net_fd2bad63a67c",
          "name": "IO_L14N_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J3",
          "netId": "control_net_bb3aaa71ba05",
          "name": "~{RAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H20",
          "netId": "control_net_bb3aaa71ba05",
          "name": "IO_L8P_T1_AD10P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N7",
          "netId": "control_net_907e4adf7ca2",
          "name": "A12/~{BC}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K22",
          "netId": "control_net_907e4adf7ca2",
          "name": "IO_L9N_T1_DQS_AD3N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T2",
          "netId": "control_net_ebaa690e703b",
          "name": "~{RESET}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K16",
          "netId": "control_net_ebaa690e703b",
          "name": "IO_L23N_T3_FWE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T8",
          "netId": "control_net_92d89f9df56c",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M20",
          "netId": "control_net_92d89f9df56c",
          "name": "IO_L18N_T2_A23_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J7",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "CK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K17",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "IO_L21P_T3_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K7",
          "netId": "control_net_5220b4a56b5c",
          "name": "~{CK}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J17",
          "netId": "control_net_5220b4a56b5c",
          "name": "IO_L21N_T3_DQS_A18_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P8",
          "netId": "control_net_d7ba445b9916",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K21",
          "netId": "control_net_d7ba445b9916",
          "name": "IO_L9P_T1_DQS_AD3P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K1",
          "netId": "control_net_395f29bc0592",
          "name": "ODT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K19",
          "netId": "control_net_395f29bc0592",
          "name": "IO_L13N_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K9",
          "netId": "control_net_be534772f175",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H22",
          "netId": "control_net_be534772f175",
          "name": "IO_L7N_T1_AD2N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L3",
          "netId": "control_net_42df6ae20837",
          "name": "~{WE}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L16",
          "netId": "control_net_42df6ae20837",
          "name": "IO_L23P_T3_FOE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L7",
          "netId": "control_net_075227a69d18",
          "name": "A10/AP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J21",
          "netId": "control_net_075227a69d18",
          "name": "IO_L11N_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M2",
          "netId": "control_net_707df60aeb98",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L19",
          "netId": "control_net_707df60aeb98",
          "name": "IO_L14P_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N2",
          "netId": "control_net_abae69816039",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L18",
          "netId": "control_net_abae69816039",
          "name": "IO_L16N_T2_A27_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P2",
          "netId": "control_net_4baca15034bf",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M18",
          "netId": "control_net_4baca15034bf",
          "name": "IO_L16P_T2_A28_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P7",
          "netId": "control_net_4143ff0aef6d",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L21",
          "netId": "control_net_4143ff0aef6d",
          "name": "IO_L10N_T1_AD11N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R3",
          "netId": "control_net_3ddfecb0df47",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N19",
          "netId": "control_net_3ddfecb0df47",
          "name": "IO_L17N_T2_A25_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T7",
          "netId": "control_net_1d61ccb9d017",
          "name": "A14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N22",
          "netId": "control_net_1d61ccb9d017",
          "name": "IO_L15P_T2_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A19",
          "netId": "control_net_6943e9712d9c",
          "name": "IO_L17N_T2_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E7",
          "netId": "control_net_6943e9712d9c",
          "name": "LDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A20",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "IO_L16N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F8",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A21",
          "netId": "control_net_ac8599a8c0cd",
          "name": "IO_L21N_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B7",
          "netId": "control_net_ac8599a8c0cd",
          "name": "~{UDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B20",
          "netId": "control_net_c5d6e41ef012",
          "name": "IO_L16P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F7",
          "netId": "control_net_c5d6e41ef012",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B21",
          "netId": "control_net_49b164ada644",
          "name": "IO_L21P_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C7",
          "netId": "control_net_49b164ada644",
          "name": "UDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B22",
          "netId": "control_net_63a08f54a8af",
          "name": "IO_L20N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B8",
          "netId": "control_net_63a08f54a8af",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C18",
          "netId": "control_net_a46672b578ec",
          "name": "IO_L13P_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H7",
          "netId": "control_net_a46672b578ec",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C19",
          "netId": "control_net_85a84369e22a",
          "name": "IO_L13N_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H8",
          "netId": "control_net_85a84369e22a",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C22",
          "netId": "control_net_010b6b6f67c9",
          "name": "IO_L20P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A7",
          "netId": "control_net_010b6b6f67c9",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D19",
          "netId": "control_net_d514c816e952",
          "name": "IO_L14N_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E3",
          "netId": "control_net_d514c816e952",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D20",
          "netId": "control_net_3a2594a1e1f9",
          "name": "IO_L19P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C8",
          "netId": "control_net_3a2594a1e1f9",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D21",
          "netId": "control_net_9bc7997904a8",
          "name": "IO_L23N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A2",
          "netId": "control_net_9bc7997904a8",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D22",
          "netId": "control_net_6e031edce63d",
          "name": "IO_L22N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A3",
          "netId": "control_net_6e031edce63d",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E18",
          "netId": "control_net_17b46c5249cb",
          "name": "IO_L15N_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G3",
          "netId": "control_net_17b46c5249cb",
          "name": "~{LDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E19",
          "netId": "control_net_4ff8255e049a",
          "name": "IO_L14P_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F2",
          "netId": "control_net_4ff8255e049a",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E21",
          "netId": "control_net_18e1c9509d79",
          "name": "IO_L23P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C2",
          "netId": "control_net_18e1c9509d79",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E22",
          "netId": "control_net_d2bff6eceb03",
          "name": "IO_L22P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D7",
          "netId": "control_net_d2bff6eceb03",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F18",
          "netId": "control_net_dc796dddd274",
          "name": "IO_L15P_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F3",
          "netId": "control_net_dc796dddd274",
          "name": "LDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F19",
          "netId": "control_net_184f5bb728b0",
          "name": "IO_L18P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H3",
          "netId": "control_net_184f5bb728b0",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F20",
          "netId": "control_net_0065f370787e",
          "name": "IO_L18N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G2",
          "netId": "control_net_0065f370787e",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G21",
          "netId": "control_net_710e1e095743",
          "name": "IO_L24P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C3",
          "netId": "control_net_710e1e095743",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G22",
          "netId": "control_net_3a720de9ef0a",
          "name": "IO_L24N_T3_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D3",
          "netId": "control_net_3a720de9ef0a",
          "name": "UDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Появляется опорная частота",
      "text": "Дифференциальный генератор подаёт опорный сигнал 200 МГц на ПЛИС. Дальнейшие частоты интерфейса формирует проект ПЛИС.",
      "body": "Дифференциальный генератор подаёт опорный сигнал 200 МГц на ПЛИС. Дальнейшие частоты интерфейса формирует проект ПЛИС.",
      "nodes": [
        "clock",
        "fpga"
      ],
      "edges": [
        "clock_fpga_0"
      ],
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "netIds": [
        "control_net_c31eb8fe07d3",
        "control_net_d44f364a5830",
        "control_net_3bfe72ccfc41",
        "control_net_21a5e9f13f7f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "J19",
          "netId": "control_net_c31eb8fe07d3",
          "name": "IO_L12P_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H19",
          "netId": "control_net_d44f364a5830",
          "name": "IO_L12N_T1_MRCC_15",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y800",
          "pin": "5",
          "netId": "control_net_3bfe72ccfc41",
          "name": "OUT_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y800",
          "pin": "4",
          "netId": "control_net_21a5e9f13f7f",
          "name": "OUT_P",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "ПЛИС адресует память",
      "text": "Команды, адреса и тактовые линии соединяют U500 с DDR3L. Цепи VTT и DDR_VREF задают требуемые уровни терминации и опоры.",
      "body": "Команды, адреса и тактовые линии соединяют U500 с DDR3L. Цепи VTT и DDR_VREF задают требуемые уровни терминации и опоры.",
      "nodes": [
        "fpga",
        "termination",
        "memory"
      ],
      "edges": [
        "fpga_memory_1",
        "fpga_memory_2",
        "termination_memory_3"
      ],
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "netIds": [
        "control_net_58af204d8c23",
        "control_net_cccff17550b9",
        "control_net_f4bfe5cdab56",
        "control_net_4bb6a512cc3a",
        "control_net_19bcc72c5488",
        "control_net_185955b3a706",
        "control_net_d109bb25230c",
        "control_net_d9ef0a17e785",
        "control_net_fd2bad63a67c",
        "control_net_bb3aaa71ba05",
        "control_net_907e4adf7ca2",
        "control_net_ebaa690e703b",
        "control_net_92d89f9df56c",
        "control_net_c4d0ccc3d16d",
        "control_net_5220b4a56b5c",
        "control_net_d7ba445b9916",
        "control_net_395f29bc0592",
        "control_net_be534772f175",
        "control_net_42df6ae20837",
        "control_net_075227a69d18",
        "control_net_707df60aeb98",
        "control_net_abae69816039",
        "control_net_4baca15034bf",
        "control_net_4143ff0aef6d",
        "control_net_3ddfecb0df47",
        "control_net_1d61ccb9d017",
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_010b6b6f67c9",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a",
        "control_net_01f75bd2f12a",
        "control_net_5fb1532b0e1e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R814",
          "pin": "1",
          "netId": "control_net_58af204d8c23",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R2",
          "netId": "control_net_58af204d8c23",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N20",
          "netId": "control_net_58af204d8c23",
          "name": "IO_L18P_T2_A24_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R807",
          "pin": "1",
          "netId": "control_net_cccff17550b9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N3",
          "netId": "control_net_cccff17550b9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M15",
          "netId": "control_net_cccff17550b9",
          "name": "IO_L24P_T3_RS1_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R818",
          "pin": "1",
          "netId": "control_net_f4bfe5cdab56",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R7",
          "netId": "control_net_f4bfe5cdab56",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M22",
          "netId": "control_net_f4bfe5cdab56",
          "name": "IO_L15N_T2_DQS_ADV_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R813",
          "pin": "1",
          "netId": "control_net_4bb6a512cc3a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R8",
          "netId": "control_net_4bb6a512cc3a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M21",
          "netId": "control_net_4bb6a512cc3a",
          "name": "IO_L10P_T1_AD11P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R820",
          "pin": "1",
          "netId": "control_net_19bcc72c5488",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T3",
          "netId": "control_net_19bcc72c5488",
          "name": "A13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N18",
          "netId": "control_net_19bcc72c5488",
          "name": "IO_L17P_T2_A26_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R809",
          "pin": "1",
          "netId": "control_net_185955b3a706",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P3",
          "netId": "control_net_185955b3a706",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M16",
          "netId": "control_net_185955b3a706",
          "name": "IO_L24N_T3_RS0_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R823",
          "pin": "1",
          "netId": "control_net_d109bb25230c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N8",
          "netId": "control_net_d109bb25230c",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J20",
          "netId": "control_net_d109bb25230c",
          "name": "IO_L11P_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R826",
          "pin": "1",
          "netId": "control_net_d9ef0a17e785",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K3",
          "netId": "control_net_d9ef0a17e785",
          "name": "~{CAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K18",
          "netId": "control_net_d9ef0a17e785",
          "name": "IO_L13P_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R824",
          "pin": "1",
          "netId": "control_net_fd2bad63a67c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M3",
          "netId": "control_net_fd2bad63a67c",
          "name": "BA2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L20",
          "netId": "control_net_fd2bad63a67c",
          "name": "IO_L14N_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R825",
          "pin": "1",
          "netId": "control_net_bb3aaa71ba05",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J3",
          "netId": "control_net_bb3aaa71ba05",
          "name": "~{RAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H20",
          "netId": "control_net_bb3aaa71ba05",
          "name": "IO_L8P_T1_AD10P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R819",
          "pin": "1",
          "netId": "control_net_907e4adf7ca2",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N7",
          "netId": "control_net_907e4adf7ca2",
          "name": "A12/~{BC}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K22",
          "netId": "control_net_907e4adf7ca2",
          "name": "IO_L9N_T1_DQS_AD3N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R806",
          "pin": "1",
          "netId": "control_net_ebaa690e703b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T2",
          "netId": "control_net_ebaa690e703b",
          "name": "~{RESET}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K16",
          "netId": "control_net_ebaa690e703b",
          "name": "IO_L23N_T3_FWE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R815",
          "pin": "1",
          "netId": "control_net_92d89f9df56c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T8",
          "netId": "control_net_92d89f9df56c",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M20",
          "netId": "control_net_92d89f9df56c",
          "name": "IO_L18N_T2_A23_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R830",
          "pin": "1",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J7",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "CK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K17",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "IO_L21P_T3_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R830",
          "pin": "2",
          "netId": "control_net_5220b4a56b5c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K7",
          "netId": "control_net_5220b4a56b5c",
          "name": "~{CK}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J17",
          "netId": "control_net_5220b4a56b5c",
          "name": "IO_L21N_T3_DQS_A18_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R811",
          "pin": "1",
          "netId": "control_net_d7ba445b9916",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P8",
          "netId": "control_net_d7ba445b9916",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K21",
          "netId": "control_net_d7ba445b9916",
          "name": "IO_L9P_T1_DQS_AD3P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K1",
          "netId": "control_net_395f29bc0592",
          "name": "ODT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R829",
          "pin": "1",
          "netId": "control_net_395f29bc0592",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K19",
          "netId": "control_net_395f29bc0592",
          "name": "IO_L13N_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K9",
          "netId": "control_net_be534772f175",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R828",
          "pin": "1",
          "netId": "control_net_be534772f175",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H22",
          "netId": "control_net_be534772f175",
          "name": "IO_L7N_T1_AD2N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L3",
          "netId": "control_net_42df6ae20837",
          "name": "~{WE}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R827",
          "pin": "1",
          "netId": "control_net_42df6ae20837",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L16",
          "netId": "control_net_42df6ae20837",
          "name": "IO_L23P_T3_FOE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L7",
          "netId": "control_net_075227a69d18",
          "name": "A10/AP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J21",
          "netId": "control_net_075227a69d18",
          "name": "IO_L11N_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R817",
          "pin": "1",
          "netId": "control_net_075227a69d18",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M2",
          "netId": "control_net_707df60aeb98",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L19",
          "netId": "control_net_707df60aeb98",
          "name": "IO_L14P_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R822",
          "pin": "1",
          "netId": "control_net_707df60aeb98",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N2",
          "netId": "control_net_abae69816039",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R810",
          "pin": "1",
          "netId": "control_net_abae69816039",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L18",
          "netId": "control_net_abae69816039",
          "name": "IO_L16N_T2_A27_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P2",
          "netId": "control_net_4baca15034bf",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R812",
          "pin": "1",
          "netId": "control_net_4baca15034bf",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M18",
          "netId": "control_net_4baca15034bf",
          "name": "IO_L16P_T2_A28_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P7",
          "netId": "control_net_4143ff0aef6d",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R808",
          "pin": "1",
          "netId": "control_net_4143ff0aef6d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L21",
          "netId": "control_net_4143ff0aef6d",
          "name": "IO_L10N_T1_AD11N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R3",
          "netId": "control_net_3ddfecb0df47",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N19",
          "netId": "control_net_3ddfecb0df47",
          "name": "IO_L17N_T2_A25_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R816",
          "pin": "1",
          "netId": "control_net_3ddfecb0df47",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T7",
          "netId": "control_net_1d61ccb9d017",
          "name": "A14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R821",
          "pin": "1",
          "netId": "control_net_1d61ccb9d017",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N22",
          "netId": "control_net_1d61ccb9d017",
          "name": "IO_L15P_T2_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A19",
          "netId": "control_net_6943e9712d9c",
          "name": "IO_L17N_T2_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E7",
          "netId": "control_net_6943e9712d9c",
          "name": "LDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A20",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "IO_L16N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F8",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A21",
          "netId": "control_net_ac8599a8c0cd",
          "name": "IO_L21N_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B7",
          "netId": "control_net_ac8599a8c0cd",
          "name": "~{UDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B20",
          "netId": "control_net_c5d6e41ef012",
          "name": "IO_L16P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F7",
          "netId": "control_net_c5d6e41ef012",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B21",
          "netId": "control_net_49b164ada644",
          "name": "IO_L21P_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C7",
          "netId": "control_net_49b164ada644",
          "name": "UDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B22",
          "netId": "control_net_63a08f54a8af",
          "name": "IO_L20N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B8",
          "netId": "control_net_63a08f54a8af",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C18",
          "netId": "control_net_a46672b578ec",
          "name": "IO_L13P_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H7",
          "netId": "control_net_a46672b578ec",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C19",
          "netId": "control_net_85a84369e22a",
          "name": "IO_L13N_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H8",
          "netId": "control_net_85a84369e22a",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C22",
          "netId": "control_net_010b6b6f67c9",
          "name": "IO_L20P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A7",
          "netId": "control_net_010b6b6f67c9",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D19",
          "netId": "control_net_d514c816e952",
          "name": "IO_L14N_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E3",
          "netId": "control_net_d514c816e952",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D20",
          "netId": "control_net_3a2594a1e1f9",
          "name": "IO_L19P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C8",
          "netId": "control_net_3a2594a1e1f9",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D21",
          "netId": "control_net_9bc7997904a8",
          "name": "IO_L23N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A2",
          "netId": "control_net_9bc7997904a8",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D22",
          "netId": "control_net_6e031edce63d",
          "name": "IO_L22N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A3",
          "netId": "control_net_6e031edce63d",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E18",
          "netId": "control_net_17b46c5249cb",
          "name": "IO_L15N_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G3",
          "netId": "control_net_17b46c5249cb",
          "name": "~{LDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E19",
          "netId": "control_net_4ff8255e049a",
          "name": "IO_L14P_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F2",
          "netId": "control_net_4ff8255e049a",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E21",
          "netId": "control_net_18e1c9509d79",
          "name": "IO_L23P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C2",
          "netId": "control_net_18e1c9509d79",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E22",
          "netId": "control_net_d2bff6eceb03",
          "name": "IO_L22P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D7",
          "netId": "control_net_d2bff6eceb03",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F18",
          "netId": "control_net_dc796dddd274",
          "name": "IO_L15P_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F3",
          "netId": "control_net_dc796dddd274",
          "name": "LDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F19",
          "netId": "control_net_184f5bb728b0",
          "name": "IO_L18P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H3",
          "netId": "control_net_184f5bb728b0",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F20",
          "netId": "control_net_0065f370787e",
          "name": "IO_L18N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G2",
          "netId": "control_net_0065f370787e",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G21",
          "netId": "control_net_710e1e095743",
          "name": "IO_L24P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C3",
          "netId": "control_net_710e1e095743",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G22",
          "netId": "control_net_3a720de9ef0a",
          "name": "IO_L24N_T3_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D3",
          "netId": "control_net_3a720de9ef0a",
          "name": "UDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R814",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R807",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R818",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R813",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R820",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R809",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R823",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R826",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R824",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R825",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R819",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R815",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R811",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R821",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R829",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R808",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R812",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R827",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R828",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R810",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R817",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R816",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R822",
          "pin": "2",
          "netId": "control_net_01f75bd2f12a",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C20",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D15",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_16",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "V_{REFDQ}",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M8",
          "netId": "control_net_5fb1532b0e1e",
          "name": "V_{REFCA}",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C836",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C834",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C835",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H18",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L6N_T0_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K14",
          "netId": "control_net_5fb1532b0e1e",
          "name": "IO_L19N_T3_A21_VREF_15",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C837",
          "pin": "1",
          "netId": "control_net_5fb1532b0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Данные передаются со стробами",
      "text": "16 линий данных и сопутствующие стробы обслуживают запись и чтение DDR3L. Эта история показывает назначение тракта, а не моделирует временную диаграмму памяти.",
      "body": "16 линий данных и сопутствующие стробы обслуживают запись и чтение DDR3L. Эта история показывает назначение тракта, а не моделирует временную диаграмму памяти.",
      "nodes": [
        "fpga",
        "memory"
      ],
      "edges": [
        "fpga_memory_1",
        "fpga_memory_2"
      ],
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "netIds": [
        "control_net_58af204d8c23",
        "control_net_cccff17550b9",
        "control_net_f4bfe5cdab56",
        "control_net_4bb6a512cc3a",
        "control_net_19bcc72c5488",
        "control_net_185955b3a706",
        "control_net_d109bb25230c",
        "control_net_d9ef0a17e785",
        "control_net_fd2bad63a67c",
        "control_net_bb3aaa71ba05",
        "control_net_907e4adf7ca2",
        "control_net_ebaa690e703b",
        "control_net_92d89f9df56c",
        "control_net_c4d0ccc3d16d",
        "control_net_5220b4a56b5c",
        "control_net_d7ba445b9916",
        "control_net_395f29bc0592",
        "control_net_be534772f175",
        "control_net_42df6ae20837",
        "control_net_075227a69d18",
        "control_net_707df60aeb98",
        "control_net_abae69816039",
        "control_net_4baca15034bf",
        "control_net_4143ff0aef6d",
        "control_net_3ddfecb0df47",
        "control_net_1d61ccb9d017",
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_010b6b6f67c9",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U800",
          "pin": "R2",
          "netId": "control_net_58af204d8c23",
          "name": "A7",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N20",
          "netId": "control_net_58af204d8c23",
          "name": "IO_L18P_T2_A24_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N3",
          "netId": "control_net_cccff17550b9",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M15",
          "netId": "control_net_cccff17550b9",
          "name": "IO_L24P_T3_RS1_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R7",
          "netId": "control_net_f4bfe5cdab56",
          "name": "A11",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M22",
          "netId": "control_net_f4bfe5cdab56",
          "name": "IO_L15N_T2_DQS_ADV_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R8",
          "netId": "control_net_4bb6a512cc3a",
          "name": "A6",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M21",
          "netId": "control_net_4bb6a512cc3a",
          "name": "IO_L10P_T1_AD11P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T3",
          "netId": "control_net_19bcc72c5488",
          "name": "A13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N18",
          "netId": "control_net_19bcc72c5488",
          "name": "IO_L17P_T2_A26_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P3",
          "netId": "control_net_185955b3a706",
          "name": "A2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M16",
          "netId": "control_net_185955b3a706",
          "name": "IO_L24N_T3_RS0_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N8",
          "netId": "control_net_d109bb25230c",
          "name": "BA1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J20",
          "netId": "control_net_d109bb25230c",
          "name": "IO_L11P_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K3",
          "netId": "control_net_d9ef0a17e785",
          "name": "~{CAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K18",
          "netId": "control_net_d9ef0a17e785",
          "name": "IO_L13P_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M3",
          "netId": "control_net_fd2bad63a67c",
          "name": "BA2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L20",
          "netId": "control_net_fd2bad63a67c",
          "name": "IO_L14N_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J3",
          "netId": "control_net_bb3aaa71ba05",
          "name": "~{RAS}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H20",
          "netId": "control_net_bb3aaa71ba05",
          "name": "IO_L8P_T1_AD10P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N7",
          "netId": "control_net_907e4adf7ca2",
          "name": "A12/~{BC}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K22",
          "netId": "control_net_907e4adf7ca2",
          "name": "IO_L9N_T1_DQS_AD3N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T2",
          "netId": "control_net_ebaa690e703b",
          "name": "~{RESET}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K16",
          "netId": "control_net_ebaa690e703b",
          "name": "IO_L23N_T3_FWE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T8",
          "netId": "control_net_92d89f9df56c",
          "name": "A8",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M20",
          "netId": "control_net_92d89f9df56c",
          "name": "IO_L18N_T2_A23_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "J7",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "CK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K17",
          "netId": "control_net_c4d0ccc3d16d",
          "name": "IO_L21P_T3_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K7",
          "netId": "control_net_5220b4a56b5c",
          "name": "~{CK}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J17",
          "netId": "control_net_5220b4a56b5c",
          "name": "IO_L21N_T3_DQS_A18_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P8",
          "netId": "control_net_d7ba445b9916",
          "name": "A4",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K21",
          "netId": "control_net_d7ba445b9916",
          "name": "IO_L9P_T1_DQS_AD3P_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K1",
          "netId": "control_net_395f29bc0592",
          "name": "ODT",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K19",
          "netId": "control_net_395f29bc0592",
          "name": "IO_L13N_T2_MRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "K9",
          "netId": "control_net_be534772f175",
          "name": "CKE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "H22",
          "netId": "control_net_be534772f175",
          "name": "IO_L7N_T1_AD2N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L3",
          "netId": "control_net_42df6ae20837",
          "name": "~{WE}",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L16",
          "netId": "control_net_42df6ae20837",
          "name": "IO_L23P_T3_FOE_B_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "L7",
          "netId": "control_net_075227a69d18",
          "name": "A10/AP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "J21",
          "netId": "control_net_075227a69d18",
          "name": "IO_L11N_T1_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "M2",
          "netId": "control_net_707df60aeb98",
          "name": "BA0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L19",
          "netId": "control_net_707df60aeb98",
          "name": "IO_L14P_T2_SRCC_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "N2",
          "netId": "control_net_abae69816039",
          "name": "A3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L18",
          "netId": "control_net_abae69816039",
          "name": "IO_L16N_T2_A27_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P2",
          "netId": "control_net_4baca15034bf",
          "name": "A5",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M18",
          "netId": "control_net_4baca15034bf",
          "name": "IO_L16P_T2_A28_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "P7",
          "netId": "control_net_4143ff0aef6d",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L21",
          "netId": "control_net_4143ff0aef6d",
          "name": "IO_L10N_T1_AD11N_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "R3",
          "netId": "control_net_3ddfecb0df47",
          "name": "A9",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N19",
          "netId": "control_net_3ddfecb0df47",
          "name": "IO_L17N_T2_A25_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "T7",
          "netId": "control_net_1d61ccb9d017",
          "name": "A14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N22",
          "netId": "control_net_1d61ccb9d017",
          "name": "IO_L15P_T2_DQS_15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A19",
          "netId": "control_net_6943e9712d9c",
          "name": "IO_L17N_T2_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E7",
          "netId": "control_net_6943e9712d9c",
          "name": "LDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A20",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "IO_L16N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F8",
          "netId": "control_net_6dc2bebc3e2e",
          "name": "DQ3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A21",
          "netId": "control_net_ac8599a8c0cd",
          "name": "IO_L21N_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B7",
          "netId": "control_net_ac8599a8c0cd",
          "name": "~{UDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B20",
          "netId": "control_net_c5d6e41ef012",
          "name": "IO_L16P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F7",
          "netId": "control_net_c5d6e41ef012",
          "name": "DQ1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B21",
          "netId": "control_net_49b164ada644",
          "name": "IO_L21P_T3_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C7",
          "netId": "control_net_49b164ada644",
          "name": "UDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B22",
          "netId": "control_net_63a08f54a8af",
          "name": "IO_L20N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "B8",
          "netId": "control_net_63a08f54a8af",
          "name": "DQ14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C18",
          "netId": "control_net_a46672b578ec",
          "name": "IO_L13P_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H7",
          "netId": "control_net_a46672b578ec",
          "name": "DQ7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C19",
          "netId": "control_net_85a84369e22a",
          "name": "IO_L13N_T2_MRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H8",
          "netId": "control_net_85a84369e22a",
          "name": "DQ5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C22",
          "netId": "control_net_010b6b6f67c9",
          "name": "IO_L20P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A7",
          "netId": "control_net_010b6b6f67c9",
          "name": "DQ12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D19",
          "netId": "control_net_d514c816e952",
          "name": "IO_L14N_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "E3",
          "netId": "control_net_d514c816e952",
          "name": "DQ0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D20",
          "netId": "control_net_3a2594a1e1f9",
          "name": "IO_L19P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C8",
          "netId": "control_net_3a2594a1e1f9",
          "name": "DQ10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D21",
          "netId": "control_net_9bc7997904a8",
          "name": "IO_L23N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A2",
          "netId": "control_net_9bc7997904a8",
          "name": "DQ13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D22",
          "netId": "control_net_6e031edce63d",
          "name": "IO_L22N_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "A3",
          "netId": "control_net_6e031edce63d",
          "name": "DQ15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E18",
          "netId": "control_net_17b46c5249cb",
          "name": "IO_L15N_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G3",
          "netId": "control_net_17b46c5249cb",
          "name": "~{LDQS}",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E19",
          "netId": "control_net_4ff8255e049a",
          "name": "IO_L14P_T2_SRCC_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F2",
          "netId": "control_net_4ff8255e049a",
          "name": "DQ2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E21",
          "netId": "control_net_18e1c9509d79",
          "name": "IO_L23P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C2",
          "netId": "control_net_18e1c9509d79",
          "name": "DQ11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E22",
          "netId": "control_net_d2bff6eceb03",
          "name": "IO_L22P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D7",
          "netId": "control_net_d2bff6eceb03",
          "name": "DQ8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F18",
          "netId": "control_net_dc796dddd274",
          "name": "IO_L15P_T2_DQS_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "F3",
          "netId": "control_net_dc796dddd274",
          "name": "LDQS",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F19",
          "netId": "control_net_184f5bb728b0",
          "name": "IO_L18P_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "H3",
          "netId": "control_net_184f5bb728b0",
          "name": "DQ4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F20",
          "netId": "control_net_0065f370787e",
          "name": "IO_L18N_T2_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "G2",
          "netId": "control_net_0065f370787e",
          "name": "DQ6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G21",
          "netId": "control_net_710e1e095743",
          "name": "IO_L24P_T3_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "C3",
          "netId": "control_net_710e1e095743",
          "name": "DQ9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "G22",
          "netId": "control_net_3a720de9ef0a",
          "name": "IO_L24N_T3_16",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U800",
          "pin": "D3",
          "netId": "control_net_3a720de9ef0a",
          "name": "UDM",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
