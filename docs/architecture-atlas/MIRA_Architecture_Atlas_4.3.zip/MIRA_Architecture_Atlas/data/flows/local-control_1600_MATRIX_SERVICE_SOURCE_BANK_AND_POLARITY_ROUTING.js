/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "title": "Как работает: Выбор источника, банка и полярности",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "steps": [
    {
      "title": "Выбирается служебный источник",
      "text": "Аналоговый селектор выбирает источник, соответствующий операции. Названия входных цепей показывают, какие команды доступны.",
      "body": "Аналоговый селектор выбирает источник, соответствующий операции. Названия входных цепей показывают, какие команды доступны.",
      "nodes": [
        "source"
      ],
      "edges": [],
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "netIds": [
        "control_net_c3b957dc2a05",
        "control_net_209d9624cc4d",
        "control_net_e5381212c338",
        "control_net_03d282e4ab71",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_992a28f1c452",
        "control_net_1d431849abfd",
        "control_net_2e82cb98585d",
        "control_net_53c8d7c2e621"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "4",
          "netId": "control_net_03d282e4ab71",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "5",
          "netId": "control_net_ba0a0fb27c13",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "6",
          "netId": "control_net_9f53cd2eaa32",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "7",
          "netId": "control_net_992a28f1c452",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "8",
          "netId": "control_net_1d431849abfd",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбираются банк и полярность",
      "text": "Следующие ключи задают направление служебного сигнала и его полярность перед подключением к банку BL.",
      "body": "Следующие ключи задают направление служебного сигнала и его полярность перед подключением к банку BL.",
      "nodes": [
        "source",
        "bank",
        "polarity"
      ],
      "edges": [
        "source_bank",
        "bank_polarity"
      ],
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_2c4dffd5842a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "8",
          "netId": "control_net_2c4dffd5842a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "3",
          "netId": "control_net_2c4dffd5842a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Определяется возврат READ",
      "text": "Отдельный тракт подключает возврат READ и управляет сбросом состояния регулятора при отключённом источнике.",
      "body": "Отдельный тракт подключает возврат READ и управляет сбросом состояния регулятора при отключённом источнике.",
      "nodes": [
        "return",
        "bank"
      ],
      "edges": [],
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "netIds": [
        "control_net_e5381212c338",
        "control_net_2e82cb98585d",
        "control_net_1548c2f283f9",
        "control_net_45e2821ea470",
        "control_net_d65f00f0a2d4",
        "control_net_69c914a4b819",
        "control_net_cfdd109d7d0d",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_1c11014d6a17",
        "control_net_a752af94ed43",
        "control_net_0c29d09eb5e8",
        "control_net_3f65bb4e6c1b",
        "control_net_209d9624cc4d",
        "control_net_e35a26b2e235",
        "control_net_42857bff9d0c",
        "control_net_435ce00e5df8",
        "control_net_c3af5f92c044",
        "control_net_2c4dffd5842a",
        "control_net_24511a425a2f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1600",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1601",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1603",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1605",
          "pin": "2",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1607",
          "pin": "2",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1600",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1602",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1604",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1606",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "16",
          "netId": "control_net_1548c2f283f9",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1602",
          "pin": "1",
          "netId": "control_net_1548c2f283f9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "14",
          "netId": "control_net_45e2821ea470",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "11",
          "netId": "control_net_45e2821ea470",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1601",
          "pin": "1",
          "netId": "control_net_45e2821ea470",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "15",
          "netId": "control_net_d65f00f0a2d4",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "9",
          "netId": "control_net_69c914a4b819",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1603",
          "pin": "1",
          "netId": "control_net_69c914a4b819",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "1",
          "netId": "control_net_cfdd109d7d0d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "8",
          "netId": "control_net_cfdd109d7d0d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "2",
          "netId": "control_net_5b5c009b1508",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "3",
          "netId": "control_net_81a816b03060",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1605",
          "pin": "1",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "6",
          "netId": "control_net_1c11014d6a17",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1605",
          "pin": "2",
          "netId": "control_net_1c11014d6a17",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "7",
          "netId": "control_net_a752af94ed43",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "12",
          "netId": "control_net_0c29d09eb5e8",
          "name": "NIC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "1",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "4",
          "netId": "control_net_e35a26b2e235",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "5",
          "netId": "control_net_42857bff9d0c",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "6",
          "netId": "control_net_435ce00e5df8",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "7",
          "netId": "control_net_c3af5f92c044",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "8",
          "netId": "control_net_2c4dffd5842a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "16",
          "netId": "control_net_24511a425a2f",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Выбирается служебный источник",
      "text": "Аналоговый селектор выбирает источник, соответствующий операции. Названия входных цепей показывают, какие команды доступны.",
      "body": "Аналоговый селектор выбирает источник, соответствующий операции. Названия входных цепей показывают, какие команды доступны.",
      "nodes": [
        "source"
      ],
      "edges": [],
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "netIds": [
        "control_net_c3b957dc2a05",
        "control_net_209d9624cc4d",
        "control_net_e5381212c338",
        "control_net_03d282e4ab71",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_992a28f1c452",
        "control_net_1d431849abfd",
        "control_net_2e82cb98585d",
        "control_net_53c8d7c2e621"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "1",
          "netId": "control_net_c3b957dc2a05",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "4",
          "netId": "control_net_03d282e4ab71",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "5",
          "netId": "control_net_ba0a0fb27c13",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "6",
          "netId": "control_net_9f53cd2eaa32",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "7",
          "netId": "control_net_992a28f1c452",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "8",
          "netId": "control_net_1d431849abfd",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1601",
          "pin": "16",
          "netId": "control_net_53c8d7c2e621",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбираются банк и полярность",
      "text": "Следующие ключи задают направление служебного сигнала и его полярность перед подключением к банку BL.",
      "body": "Следующие ключи задают направление служебного сигнала и его полярность перед подключением к банку BL.",
      "nodes": [
        "source",
        "bank",
        "polarity"
      ],
      "edges": [
        "source_bank",
        "bank_polarity"
      ],
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "netIds": [
        "control_net_209d9624cc4d",
        "control_net_2c4dffd5842a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1601",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "8",
          "netId": "control_net_2c4dffd5842a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1602",
          "pin": "3",
          "netId": "control_net_2c4dffd5842a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Определяется возврат READ",
      "text": "Отдельный тракт подключает возврат READ и управляет сбросом состояния регулятора при отключённом источнике.",
      "body": "Отдельный тракт подключает возврат READ и управляет сбросом состояния регулятора при отключённом источнике.",
      "nodes": [
        "return",
        "bank"
      ],
      "edges": [],
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "netIds": [
        "control_net_e5381212c338",
        "control_net_2e82cb98585d",
        "control_net_1548c2f283f9",
        "control_net_45e2821ea470",
        "control_net_d65f00f0a2d4",
        "control_net_69c914a4b819",
        "control_net_cfdd109d7d0d",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_1c11014d6a17",
        "control_net_a752af94ed43",
        "control_net_0c29d09eb5e8",
        "control_net_3f65bb4e6c1b",
        "control_net_209d9624cc4d",
        "control_net_e35a26b2e235",
        "control_net_42857bff9d0c",
        "control_net_435ce00e5df8",
        "control_net_c3af5f92c044",
        "control_net_2c4dffd5842a",
        "control_net_24511a425a2f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1600",
          "pin": "3",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "4",
          "netId": "control_net_e5381212c338",
          "name": "VSS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1601",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1603",
          "pin": "1",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1605",
          "pin": "2",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1607",
          "pin": "2",
          "netId": "control_net_e5381212c338",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "13",
          "netId": "control_net_2e82cb98585d",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1600",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1602",
          "pin": "1",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1604",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1606",
          "pin": "2",
          "netId": "control_net_2e82cb98585d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "16",
          "netId": "control_net_1548c2f283f9",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1602",
          "pin": "1",
          "netId": "control_net_1548c2f283f9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "14",
          "netId": "control_net_45e2821ea470",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "11",
          "netId": "control_net_45e2821ea470",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1601",
          "pin": "1",
          "netId": "control_net_45e2821ea470",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "15",
          "netId": "control_net_d65f00f0a2d4",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "9",
          "netId": "control_net_69c914a4b819",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1603",
          "pin": "1",
          "netId": "control_net_69c914a4b819",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "1",
          "netId": "control_net_cfdd109d7d0d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "8",
          "netId": "control_net_cfdd109d7d0d",
          "name": "IN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "2",
          "netId": "control_net_5b5c009b1508",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "3",
          "netId": "control_net_81a816b03060",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1605",
          "pin": "1",
          "netId": "control_net_81a816b03060",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "6",
          "netId": "control_net_1c11014d6a17",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1605",
          "pin": "2",
          "netId": "control_net_1c11014d6a17",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "7",
          "netId": "control_net_a752af94ed43",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1603",
          "pin": "12",
          "netId": "control_net_0c29d09eb5e8",
          "name": "NIC",
          "direction": "no_connect",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "1",
          "netId": "control_net_3f65bb4e6c1b",
          "name": "A0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "2",
          "netId": "control_net_209d9624cc4d",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "4",
          "netId": "control_net_e35a26b2e235",
          "name": "S1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "5",
          "netId": "control_net_42857bff9d0c",
          "name": "S2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "6",
          "netId": "control_net_435ce00e5df8",
          "name": "S3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "7",
          "netId": "control_net_c3af5f92c044",
          "name": "S4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "8",
          "netId": "control_net_2c4dffd5842a",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1600",
          "pin": "16",
          "netId": "control_net_24511a425a2f",
          "name": "A1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
