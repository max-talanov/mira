/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_400_INPUT_FILTER_SENSE",
  "title": "Как работает: Фильтрация защищённой шины 24 В",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_400_INPUT_FILTER_SENSE",
  "steps": [
    {
      "title": "Защищённая шина входит в фильтр",
      "text": "Фильтр и локальные конденсаторы принимают защищённое входное питание. Через этот узел энергия идёт к основным ветвям.",
      "body": "Фильтр и локальные конденсаторы принимают защищённое входное питание. Через этот узел энергия идёт к основным ветвям.",
      "nodes": [
        "filter"
      ],
      "edges": [],
      "sceneId": "power_400_INPUT_FILTER_SENSE",
      "netIds": [
        "power_net_8174cad108e5",
        "power_net_a837894762cd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_L401",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C402",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C403",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C401",
          "pin": "1",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L401",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "После фильтра доступно наблюдение",
      "text": "Цепи измерения и индикации показывают состояние доставленного питания. Измерение является ответвлением, а не последовательной обработкой энергии.",
      "body": "Цепи измерения и индикации показывают состояние доставленного питания. Измерение является ответвлением, а не последовательной обработкой энергии.",
      "nodes": [
        "filter",
        "sense"
      ],
      "edges": [
        "filter_sense"
      ],
      "sceneId": "power_400_INPUT_FILTER_SENSE",
      "netIds": [
        "power_net_8174cad108e5"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_L401",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C402",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C403",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R401",
          "pin": "1",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C401",
          "pin": "1",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Защищённая шина входит в фильтр",
      "text": "Фильтр и локальные конденсаторы принимают защищённое входное питание. Через этот узел энергия идёт к основным ветвям.",
      "body": "Фильтр и локальные конденсаторы принимают защищённое входное питание. Через этот узел энергия идёт к основным ветвям.",
      "nodes": [
        "filter"
      ],
      "edges": [],
      "sceneId": "power_400_INPUT_FILTER_SENSE",
      "netIds": [
        "power_net_8174cad108e5",
        "power_net_a837894762cd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_L401",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C402",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C403",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C401",
          "pin": "1",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L401",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "После фильтра доступно наблюдение",
      "text": "Цепи измерения и индикации показывают состояние доставленного питания. Измерение является ответвлением, а не последовательной обработкой энергии.",
      "body": "Цепи измерения и индикации показывают состояние доставленного питания. Измерение является ответвлением, а не последовательной обработкой энергии.",
      "nodes": [
        "filter",
        "sense"
      ],
      "edges": [
        "filter_sense"
      ],
      "sceneId": "power_400_INPUT_FILTER_SENSE",
      "netIds": [
        "power_net_8174cad108e5"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_L401",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C402",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C403",
          "pin": "2",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R401",
          "pin": "1",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C401",
          "pin": "1",
          "netId": "power_net_8174cad108e5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
