/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "title": "Как работает: Подключение экспериментальной матрицы",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "steps": [
    {
      "title": "Сигналы доходят до адаптера",
      "text": "Разъём J1800 выводит BL, WL, NL и контакты смещения к экспериментальной матрице. Эта диаграмма показывает интерфейс, а не внутреннюю схему мемристоров.",
      "body": "Разъём J1800 выводит BL, WL, NL и контакты смещения к экспериментальной матрице. Эта диаграмма показывает интерфейс, а не внутреннюю схему мемристоров.",
      "nodes": [
        "socket"
      ],
      "edges": [],
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "netIds": [
        "control_net_9fb08613c315",
        "control_net_67556870ea17",
        "control_net_79947d226d73",
        "control_net_e4379a2b0f61",
        "control_net_3762f1a58fed",
        "control_net_d380ae123eb3",
        "control_net_919f25939ba9",
        "control_net_e8ccb5161adb",
        "control_net_072af1a28ea6",
        "control_net_5212ff00c1ac",
        "control_net_c5cc096c8461",
        "control_net_1f3aab800672",
        "control_net_f8df3c62c75a",
        "control_net_37f8b631169e",
        "control_net_aab6d32988cf",
        "control_net_92ecd1b9c91e",
        "control_net_76481426c5c9",
        "control_net_8c1f7a16a91f",
        "control_net_15a5f03664b6",
        "control_net_093450c5090e",
        "control_net_f237bfeb4d31",
        "control_net_36b8e2744fa2",
        "control_net_cb9a53bc7e2d",
        "control_net_0066c578f4fd",
        "control_net_a3c1624fed4f",
        "control_net_06c41da37048",
        "control_net_668f023fd21c",
        "control_net_5a6f03bbf06c",
        "control_net_7deb95e626ac",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_ae5aa8c25d68",
        "control_net_8238d609143f",
        "control_net_e4f13269db06",
        "control_net_5b406ad8357d",
        "control_net_e066c57b7888",
        "control_net_a0fe3e097faf",
        "control_net_747cc492238d",
        "control_net_5ef23046b636",
        "control_net_6380a00471f5",
        "control_net_fca0e6b6f6af",
        "control_net_b0ea7c0c27c3",
        "control_net_3c196a06fe86",
        "control_net_945cddbc767f",
        "control_net_c494e5a21fb7",
        "control_net_edac321adbf1",
        "control_net_33ee65c78544",
        "control_net_b538393eaff5",
        "control_net_9aa6ed5fa484",
        "control_net_2661b7e1d1d8",
        "control_net_da64d12ab5ef",
        "control_net_5b7588c91934",
        "control_net_a38212b18dab",
        "control_net_b1a7be433721",
        "control_net_dee259c78870",
        "control_net_ef57e67af6ee",
        "control_net_96843655892a",
        "control_net_77eb74275447",
        "control_net_410ce51ce77b",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_7443657d6bc7",
        "control_net_331bcbe5832b",
        "control_net_af268a134ce7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J1800",
          "pin": "1",
          "netId": "control_net_9fb08613c315",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "2",
          "netId": "control_net_67556870ea17",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "3",
          "netId": "control_net_79947d226d73",
          "name": "NL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "4",
          "netId": "control_net_e4379a2b0f61",
          "name": "NL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "5",
          "netId": "control_net_3762f1a58fed",
          "name": "NL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "6",
          "netId": "control_net_d380ae123eb3",
          "name": "NL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "7",
          "netId": "control_net_919f25939ba9",
          "name": "NL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "8",
          "netId": "control_net_e8ccb5161adb",
          "name": "NL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "9",
          "netId": "control_net_072af1a28ea6",
          "name": "NL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "10",
          "netId": "control_net_5212ff00c1ac",
          "name": "NL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "11",
          "netId": "control_net_c5cc096c8461",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "12",
          "netId": "control_net_1f3aab800672",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "13",
          "netId": "control_net_f8df3c62c75a",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "14",
          "netId": "control_net_37f8b631169e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "15",
          "netId": "control_net_aab6d32988cf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "16",
          "netId": "control_net_92ecd1b9c91e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "17",
          "netId": "control_net_76481426c5c9",
          "name": "BL16",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "18",
          "netId": "control_net_8c1f7a16a91f",
          "name": "BL17",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "19",
          "netId": "control_net_15a5f03664b6",
          "name": "BL18",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "20",
          "netId": "control_net_093450c5090e",
          "name": "BL19",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "21",
          "netId": "control_net_f237bfeb4d31",
          "name": "BL20",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "22",
          "netId": "control_net_36b8e2744fa2",
          "name": "BL21",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "23",
          "netId": "control_net_cb9a53bc7e2d",
          "name": "BL22",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "24",
          "netId": "control_net_0066c578f4fd",
          "name": "BL23",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "25",
          "netId": "control_net_a3c1624fed4f",
          "name": "BL24",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "26",
          "netId": "control_net_06c41da37048",
          "name": "BL25",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "27",
          "netId": "control_net_668f023fd21c",
          "name": "BL26",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "28",
          "netId": "control_net_5a6f03bbf06c",
          "name": "BL27",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "29",
          "netId": "control_net_7deb95e626ac",
          "name": "BL28",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "30",
          "netId": "control_net_9037a6d55684",
          "name": "BL29",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "31",
          "netId": "control_net_e59cadbe90ef",
          "name": "BL30",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "32",
          "netId": "control_net_ae5aa8c25d68",
          "name": "BL31",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "33",
          "netId": "control_net_8238d609143f",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "34",
          "netId": "control_net_e4f13269db06",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "35",
          "netId": "control_net_5b406ad8357d",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "36",
          "netId": "control_net_e066c57b7888",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "37",
          "netId": "control_net_a0fe3e097faf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "38",
          "netId": "control_net_747cc492238d",
          "name": "WL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "39",
          "netId": "control_net_5ef23046b636",
          "name": "WL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "40",
          "netId": "control_net_6380a00471f5",
          "name": "CASE_COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "41",
          "netId": "control_net_fca0e6b6f6af",
          "name": "WL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "42",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "WL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "43",
          "netId": "control_net_3c196a06fe86",
          "name": "WL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "44",
          "netId": "control_net_945cddbc767f",
          "name": "WL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "45",
          "netId": "control_net_c494e5a21fb7",
          "name": "WL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "46",
          "netId": "control_net_edac321adbf1",
          "name": "WL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "47",
          "netId": "control_net_33ee65c78544",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "48",
          "netId": "control_net_b538393eaff5",
          "name": "GND_REF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "49",
          "netId": "control_net_9aa6ed5fa484",
          "name": "BL15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "50",
          "netId": "control_net_2661b7e1d1d8",
          "name": "BL14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "51",
          "netId": "control_net_da64d12ab5ef",
          "name": "BL13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "52",
          "netId": "control_net_5b7588c91934",
          "name": "BL12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "53",
          "netId": "control_net_a38212b18dab",
          "name": "BL11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "54",
          "netId": "control_net_b1a7be433721",
          "name": "BL10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "55",
          "netId": "control_net_dee259c78870",
          "name": "BL9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "56",
          "netId": "control_net_ef57e67af6ee",
          "name": "BL8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "57",
          "netId": "control_net_96843655892a",
          "name": "BL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "58",
          "netId": "control_net_77eb74275447",
          "name": "BL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "59",
          "netId": "control_net_410ce51ce77b",
          "name": "BL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "60",
          "netId": "control_net_30db039e0318",
          "name": "BL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "61",
          "netId": "control_net_538bdbb480c1",
          "name": "BL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "62",
          "netId": "control_net_7443657d6bc7",
          "name": "BL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "63",
          "netId": "control_net_331bcbe5832b",
          "name": "BL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "64",
          "netId": "control_net_af268a134ce7",
          "name": "BL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Определяется смещение адаптера",
      "text": "Перемычки J1801 и J1802 задают показанные в исходнике варианты подключения смещения. Их фактическое положение необходимо согласовать с адаптером.",
      "body": "Перемычки J1801 и J1802 задают показанные в исходнике варианты подключения смещения. Их фактическое положение необходимо согласовать с адаптером.",
      "nodes": [
        "bias",
        "socket"
      ],
      "edges": [
        "socket_bias"
      ],
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "netIds": [
        "control_net_6380a00471f5",
        "control_net_b538393eaff5"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1801",
          "pin": "1",
          "netId": "control_net_6380a00471f5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1802",
          "pin": "2",
          "netId": "control_net_6380a00471f5",
          "name": "MATRIX_CONTACT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "40",
          "netId": "control_net_6380a00471f5",
          "name": "CASE_COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1800",
          "pin": "1",
          "netId": "control_net_b538393eaff5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1801",
          "pin": "2",
          "netId": "control_net_b538393eaff5",
          "name": "MATRIX_CONTACT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "48",
          "netId": "control_net_b538393eaff5",
          "name": "GND_REF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Ток возвращается к измерению",
      "text": "Через контакты разъёма выбранный ток продолжает путь к селектору и измерительному тракту на других функциональных диаграммах.",
      "body": "Через контакты разъёма выбранный ток продолжает путь к селектору и измерительному тракту на других функциональных диаграммах.",
      "nodes": [
        "socket"
      ],
      "edges": [],
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "netIds": [
        "control_net_9fb08613c315",
        "control_net_67556870ea17",
        "control_net_79947d226d73",
        "control_net_e4379a2b0f61",
        "control_net_3762f1a58fed",
        "control_net_d380ae123eb3",
        "control_net_919f25939ba9",
        "control_net_e8ccb5161adb",
        "control_net_072af1a28ea6",
        "control_net_5212ff00c1ac",
        "control_net_c5cc096c8461",
        "control_net_1f3aab800672",
        "control_net_f8df3c62c75a",
        "control_net_37f8b631169e",
        "control_net_aab6d32988cf",
        "control_net_92ecd1b9c91e",
        "control_net_76481426c5c9",
        "control_net_8c1f7a16a91f",
        "control_net_15a5f03664b6",
        "control_net_093450c5090e",
        "control_net_f237bfeb4d31",
        "control_net_36b8e2744fa2",
        "control_net_cb9a53bc7e2d",
        "control_net_0066c578f4fd",
        "control_net_a3c1624fed4f",
        "control_net_06c41da37048",
        "control_net_668f023fd21c",
        "control_net_5a6f03bbf06c",
        "control_net_7deb95e626ac",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_ae5aa8c25d68",
        "control_net_8238d609143f",
        "control_net_e4f13269db06",
        "control_net_5b406ad8357d",
        "control_net_e066c57b7888",
        "control_net_a0fe3e097faf",
        "control_net_747cc492238d",
        "control_net_5ef23046b636",
        "control_net_6380a00471f5",
        "control_net_fca0e6b6f6af",
        "control_net_b0ea7c0c27c3",
        "control_net_3c196a06fe86",
        "control_net_945cddbc767f",
        "control_net_c494e5a21fb7",
        "control_net_edac321adbf1",
        "control_net_33ee65c78544",
        "control_net_b538393eaff5",
        "control_net_9aa6ed5fa484",
        "control_net_2661b7e1d1d8",
        "control_net_da64d12ab5ef",
        "control_net_5b7588c91934",
        "control_net_a38212b18dab",
        "control_net_b1a7be433721",
        "control_net_dee259c78870",
        "control_net_ef57e67af6ee",
        "control_net_96843655892a",
        "control_net_77eb74275447",
        "control_net_410ce51ce77b",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_7443657d6bc7",
        "control_net_331bcbe5832b",
        "control_net_af268a134ce7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J1800",
          "pin": "1",
          "netId": "control_net_9fb08613c315",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "2",
          "netId": "control_net_67556870ea17",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "3",
          "netId": "control_net_79947d226d73",
          "name": "NL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "4",
          "netId": "control_net_e4379a2b0f61",
          "name": "NL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "5",
          "netId": "control_net_3762f1a58fed",
          "name": "NL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "6",
          "netId": "control_net_d380ae123eb3",
          "name": "NL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "7",
          "netId": "control_net_919f25939ba9",
          "name": "NL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "8",
          "netId": "control_net_e8ccb5161adb",
          "name": "NL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "9",
          "netId": "control_net_072af1a28ea6",
          "name": "NL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "10",
          "netId": "control_net_5212ff00c1ac",
          "name": "NL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "11",
          "netId": "control_net_c5cc096c8461",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "12",
          "netId": "control_net_1f3aab800672",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "13",
          "netId": "control_net_f8df3c62c75a",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "14",
          "netId": "control_net_37f8b631169e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "15",
          "netId": "control_net_aab6d32988cf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "16",
          "netId": "control_net_92ecd1b9c91e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "17",
          "netId": "control_net_76481426c5c9",
          "name": "BL16",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "18",
          "netId": "control_net_8c1f7a16a91f",
          "name": "BL17",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "19",
          "netId": "control_net_15a5f03664b6",
          "name": "BL18",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "20",
          "netId": "control_net_093450c5090e",
          "name": "BL19",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "21",
          "netId": "control_net_f237bfeb4d31",
          "name": "BL20",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "22",
          "netId": "control_net_36b8e2744fa2",
          "name": "BL21",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "23",
          "netId": "control_net_cb9a53bc7e2d",
          "name": "BL22",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "24",
          "netId": "control_net_0066c578f4fd",
          "name": "BL23",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "25",
          "netId": "control_net_a3c1624fed4f",
          "name": "BL24",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "26",
          "netId": "control_net_06c41da37048",
          "name": "BL25",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "27",
          "netId": "control_net_668f023fd21c",
          "name": "BL26",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "28",
          "netId": "control_net_5a6f03bbf06c",
          "name": "BL27",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "29",
          "netId": "control_net_7deb95e626ac",
          "name": "BL28",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "30",
          "netId": "control_net_9037a6d55684",
          "name": "BL29",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "31",
          "netId": "control_net_e59cadbe90ef",
          "name": "BL30",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "32",
          "netId": "control_net_ae5aa8c25d68",
          "name": "BL31",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "33",
          "netId": "control_net_8238d609143f",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "34",
          "netId": "control_net_e4f13269db06",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "35",
          "netId": "control_net_5b406ad8357d",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "36",
          "netId": "control_net_e066c57b7888",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "37",
          "netId": "control_net_a0fe3e097faf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "38",
          "netId": "control_net_747cc492238d",
          "name": "WL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "39",
          "netId": "control_net_5ef23046b636",
          "name": "WL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "40",
          "netId": "control_net_6380a00471f5",
          "name": "CASE_COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "41",
          "netId": "control_net_fca0e6b6f6af",
          "name": "WL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "42",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "WL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "43",
          "netId": "control_net_3c196a06fe86",
          "name": "WL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "44",
          "netId": "control_net_945cddbc767f",
          "name": "WL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "45",
          "netId": "control_net_c494e5a21fb7",
          "name": "WL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "46",
          "netId": "control_net_edac321adbf1",
          "name": "WL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "47",
          "netId": "control_net_33ee65c78544",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "48",
          "netId": "control_net_b538393eaff5",
          "name": "GND_REF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "49",
          "netId": "control_net_9aa6ed5fa484",
          "name": "BL15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "50",
          "netId": "control_net_2661b7e1d1d8",
          "name": "BL14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "51",
          "netId": "control_net_da64d12ab5ef",
          "name": "BL13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "52",
          "netId": "control_net_5b7588c91934",
          "name": "BL12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "53",
          "netId": "control_net_a38212b18dab",
          "name": "BL11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "54",
          "netId": "control_net_b1a7be433721",
          "name": "BL10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "55",
          "netId": "control_net_dee259c78870",
          "name": "BL9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "56",
          "netId": "control_net_ef57e67af6ee",
          "name": "BL8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "57",
          "netId": "control_net_96843655892a",
          "name": "BL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "58",
          "netId": "control_net_77eb74275447",
          "name": "BL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "59",
          "netId": "control_net_410ce51ce77b",
          "name": "BL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "60",
          "netId": "control_net_30db039e0318",
          "name": "BL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "61",
          "netId": "control_net_538bdbb480c1",
          "name": "BL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "62",
          "netId": "control_net_7443657d6bc7",
          "name": "BL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "63",
          "netId": "control_net_331bcbe5832b",
          "name": "BL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "64",
          "netId": "control_net_af268a134ce7",
          "name": "BL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Сигналы доходят до адаптера",
      "text": "Разъём J1800 выводит BL, WL, NL и контакты смещения к экспериментальной матрице. Эта диаграмма показывает интерфейс, а не внутреннюю схему мемристоров.",
      "body": "Разъём J1800 выводит BL, WL, NL и контакты смещения к экспериментальной матрице. Эта диаграмма показывает интерфейс, а не внутреннюю схему мемристоров.",
      "nodes": [
        "socket"
      ],
      "edges": [],
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "netIds": [
        "control_net_9fb08613c315",
        "control_net_67556870ea17",
        "control_net_79947d226d73",
        "control_net_e4379a2b0f61",
        "control_net_3762f1a58fed",
        "control_net_d380ae123eb3",
        "control_net_919f25939ba9",
        "control_net_e8ccb5161adb",
        "control_net_072af1a28ea6",
        "control_net_5212ff00c1ac",
        "control_net_c5cc096c8461",
        "control_net_1f3aab800672",
        "control_net_f8df3c62c75a",
        "control_net_37f8b631169e",
        "control_net_aab6d32988cf",
        "control_net_92ecd1b9c91e",
        "control_net_76481426c5c9",
        "control_net_8c1f7a16a91f",
        "control_net_15a5f03664b6",
        "control_net_093450c5090e",
        "control_net_f237bfeb4d31",
        "control_net_36b8e2744fa2",
        "control_net_cb9a53bc7e2d",
        "control_net_0066c578f4fd",
        "control_net_a3c1624fed4f",
        "control_net_06c41da37048",
        "control_net_668f023fd21c",
        "control_net_5a6f03bbf06c",
        "control_net_7deb95e626ac",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_ae5aa8c25d68",
        "control_net_8238d609143f",
        "control_net_e4f13269db06",
        "control_net_5b406ad8357d",
        "control_net_e066c57b7888",
        "control_net_a0fe3e097faf",
        "control_net_747cc492238d",
        "control_net_5ef23046b636",
        "control_net_6380a00471f5",
        "control_net_fca0e6b6f6af",
        "control_net_b0ea7c0c27c3",
        "control_net_3c196a06fe86",
        "control_net_945cddbc767f",
        "control_net_c494e5a21fb7",
        "control_net_edac321adbf1",
        "control_net_33ee65c78544",
        "control_net_b538393eaff5",
        "control_net_9aa6ed5fa484",
        "control_net_2661b7e1d1d8",
        "control_net_da64d12ab5ef",
        "control_net_5b7588c91934",
        "control_net_a38212b18dab",
        "control_net_b1a7be433721",
        "control_net_dee259c78870",
        "control_net_ef57e67af6ee",
        "control_net_96843655892a",
        "control_net_77eb74275447",
        "control_net_410ce51ce77b",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_7443657d6bc7",
        "control_net_331bcbe5832b",
        "control_net_af268a134ce7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J1800",
          "pin": "1",
          "netId": "control_net_9fb08613c315",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "2",
          "netId": "control_net_67556870ea17",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "3",
          "netId": "control_net_79947d226d73",
          "name": "NL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "4",
          "netId": "control_net_e4379a2b0f61",
          "name": "NL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "5",
          "netId": "control_net_3762f1a58fed",
          "name": "NL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "6",
          "netId": "control_net_d380ae123eb3",
          "name": "NL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "7",
          "netId": "control_net_919f25939ba9",
          "name": "NL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "8",
          "netId": "control_net_e8ccb5161adb",
          "name": "NL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "9",
          "netId": "control_net_072af1a28ea6",
          "name": "NL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "10",
          "netId": "control_net_5212ff00c1ac",
          "name": "NL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "11",
          "netId": "control_net_c5cc096c8461",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "12",
          "netId": "control_net_1f3aab800672",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "13",
          "netId": "control_net_f8df3c62c75a",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "14",
          "netId": "control_net_37f8b631169e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "15",
          "netId": "control_net_aab6d32988cf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "16",
          "netId": "control_net_92ecd1b9c91e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "17",
          "netId": "control_net_76481426c5c9",
          "name": "BL16",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "18",
          "netId": "control_net_8c1f7a16a91f",
          "name": "BL17",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "19",
          "netId": "control_net_15a5f03664b6",
          "name": "BL18",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "20",
          "netId": "control_net_093450c5090e",
          "name": "BL19",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "21",
          "netId": "control_net_f237bfeb4d31",
          "name": "BL20",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "22",
          "netId": "control_net_36b8e2744fa2",
          "name": "BL21",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "23",
          "netId": "control_net_cb9a53bc7e2d",
          "name": "BL22",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "24",
          "netId": "control_net_0066c578f4fd",
          "name": "BL23",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "25",
          "netId": "control_net_a3c1624fed4f",
          "name": "BL24",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "26",
          "netId": "control_net_06c41da37048",
          "name": "BL25",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "27",
          "netId": "control_net_668f023fd21c",
          "name": "BL26",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "28",
          "netId": "control_net_5a6f03bbf06c",
          "name": "BL27",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "29",
          "netId": "control_net_7deb95e626ac",
          "name": "BL28",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "30",
          "netId": "control_net_9037a6d55684",
          "name": "BL29",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "31",
          "netId": "control_net_e59cadbe90ef",
          "name": "BL30",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "32",
          "netId": "control_net_ae5aa8c25d68",
          "name": "BL31",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "33",
          "netId": "control_net_8238d609143f",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "34",
          "netId": "control_net_e4f13269db06",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "35",
          "netId": "control_net_5b406ad8357d",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "36",
          "netId": "control_net_e066c57b7888",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "37",
          "netId": "control_net_a0fe3e097faf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "38",
          "netId": "control_net_747cc492238d",
          "name": "WL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "39",
          "netId": "control_net_5ef23046b636",
          "name": "WL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "40",
          "netId": "control_net_6380a00471f5",
          "name": "CASE_COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "41",
          "netId": "control_net_fca0e6b6f6af",
          "name": "WL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "42",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "WL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "43",
          "netId": "control_net_3c196a06fe86",
          "name": "WL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "44",
          "netId": "control_net_945cddbc767f",
          "name": "WL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "45",
          "netId": "control_net_c494e5a21fb7",
          "name": "WL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "46",
          "netId": "control_net_edac321adbf1",
          "name": "WL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "47",
          "netId": "control_net_33ee65c78544",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "48",
          "netId": "control_net_b538393eaff5",
          "name": "GND_REF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "49",
          "netId": "control_net_9aa6ed5fa484",
          "name": "BL15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "50",
          "netId": "control_net_2661b7e1d1d8",
          "name": "BL14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "51",
          "netId": "control_net_da64d12ab5ef",
          "name": "BL13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "52",
          "netId": "control_net_5b7588c91934",
          "name": "BL12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "53",
          "netId": "control_net_a38212b18dab",
          "name": "BL11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "54",
          "netId": "control_net_b1a7be433721",
          "name": "BL10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "55",
          "netId": "control_net_dee259c78870",
          "name": "BL9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "56",
          "netId": "control_net_ef57e67af6ee",
          "name": "BL8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "57",
          "netId": "control_net_96843655892a",
          "name": "BL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "58",
          "netId": "control_net_77eb74275447",
          "name": "BL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "59",
          "netId": "control_net_410ce51ce77b",
          "name": "BL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "60",
          "netId": "control_net_30db039e0318",
          "name": "BL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "61",
          "netId": "control_net_538bdbb480c1",
          "name": "BL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "62",
          "netId": "control_net_7443657d6bc7",
          "name": "BL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "63",
          "netId": "control_net_331bcbe5832b",
          "name": "BL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "64",
          "netId": "control_net_af268a134ce7",
          "name": "BL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Определяется смещение адаптера",
      "text": "Перемычки J1801 и J1802 задают показанные в исходнике варианты подключения смещения. Их фактическое положение необходимо согласовать с адаптером.",
      "body": "Перемычки J1801 и J1802 задают показанные в исходнике варианты подключения смещения. Их фактическое положение необходимо согласовать с адаптером.",
      "nodes": [
        "bias",
        "socket"
      ],
      "edges": [
        "socket_bias"
      ],
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "netIds": [
        "control_net_6380a00471f5",
        "control_net_b538393eaff5"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R1801",
          "pin": "1",
          "netId": "control_net_6380a00471f5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1802",
          "pin": "2",
          "netId": "control_net_6380a00471f5",
          "name": "MATRIX_CONTACT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "40",
          "netId": "control_net_6380a00471f5",
          "name": "CASE_COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1800",
          "pin": "1",
          "netId": "control_net_b538393eaff5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1801",
          "pin": "2",
          "netId": "control_net_b538393eaff5",
          "name": "MATRIX_CONTACT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "48",
          "netId": "control_net_b538393eaff5",
          "name": "GND_REF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Ток возвращается к измерению",
      "text": "Через контакты разъёма выбранный ток продолжает путь к селектору и измерительному тракту на других функциональных диаграммах.",
      "body": "Через контакты разъёма выбранный ток продолжает путь к селектору и измерительному тракту на других функциональных диаграммах.",
      "nodes": [
        "socket"
      ],
      "edges": [],
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "netIds": [
        "control_net_9fb08613c315",
        "control_net_67556870ea17",
        "control_net_79947d226d73",
        "control_net_e4379a2b0f61",
        "control_net_3762f1a58fed",
        "control_net_d380ae123eb3",
        "control_net_919f25939ba9",
        "control_net_e8ccb5161adb",
        "control_net_072af1a28ea6",
        "control_net_5212ff00c1ac",
        "control_net_c5cc096c8461",
        "control_net_1f3aab800672",
        "control_net_f8df3c62c75a",
        "control_net_37f8b631169e",
        "control_net_aab6d32988cf",
        "control_net_92ecd1b9c91e",
        "control_net_76481426c5c9",
        "control_net_8c1f7a16a91f",
        "control_net_15a5f03664b6",
        "control_net_093450c5090e",
        "control_net_f237bfeb4d31",
        "control_net_36b8e2744fa2",
        "control_net_cb9a53bc7e2d",
        "control_net_0066c578f4fd",
        "control_net_a3c1624fed4f",
        "control_net_06c41da37048",
        "control_net_668f023fd21c",
        "control_net_5a6f03bbf06c",
        "control_net_7deb95e626ac",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_ae5aa8c25d68",
        "control_net_8238d609143f",
        "control_net_e4f13269db06",
        "control_net_5b406ad8357d",
        "control_net_e066c57b7888",
        "control_net_a0fe3e097faf",
        "control_net_747cc492238d",
        "control_net_5ef23046b636",
        "control_net_6380a00471f5",
        "control_net_fca0e6b6f6af",
        "control_net_b0ea7c0c27c3",
        "control_net_3c196a06fe86",
        "control_net_945cddbc767f",
        "control_net_c494e5a21fb7",
        "control_net_edac321adbf1",
        "control_net_33ee65c78544",
        "control_net_b538393eaff5",
        "control_net_9aa6ed5fa484",
        "control_net_2661b7e1d1d8",
        "control_net_da64d12ab5ef",
        "control_net_5b7588c91934",
        "control_net_a38212b18dab",
        "control_net_b1a7be433721",
        "control_net_dee259c78870",
        "control_net_ef57e67af6ee",
        "control_net_96843655892a",
        "control_net_77eb74275447",
        "control_net_410ce51ce77b",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_7443657d6bc7",
        "control_net_331bcbe5832b",
        "control_net_af268a134ce7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J1800",
          "pin": "1",
          "netId": "control_net_9fb08613c315",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "2",
          "netId": "control_net_67556870ea17",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "3",
          "netId": "control_net_79947d226d73",
          "name": "NL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "4",
          "netId": "control_net_e4379a2b0f61",
          "name": "NL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "5",
          "netId": "control_net_3762f1a58fed",
          "name": "NL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "6",
          "netId": "control_net_d380ae123eb3",
          "name": "NL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "7",
          "netId": "control_net_919f25939ba9",
          "name": "NL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "8",
          "netId": "control_net_e8ccb5161adb",
          "name": "NL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "9",
          "netId": "control_net_072af1a28ea6",
          "name": "NL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "10",
          "netId": "control_net_5212ff00c1ac",
          "name": "NL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "11",
          "netId": "control_net_c5cc096c8461",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "12",
          "netId": "control_net_1f3aab800672",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "13",
          "netId": "control_net_f8df3c62c75a",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "14",
          "netId": "control_net_37f8b631169e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "15",
          "netId": "control_net_aab6d32988cf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "16",
          "netId": "control_net_92ecd1b9c91e",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "17",
          "netId": "control_net_76481426c5c9",
          "name": "BL16",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "18",
          "netId": "control_net_8c1f7a16a91f",
          "name": "BL17",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "19",
          "netId": "control_net_15a5f03664b6",
          "name": "BL18",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "20",
          "netId": "control_net_093450c5090e",
          "name": "BL19",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "21",
          "netId": "control_net_f237bfeb4d31",
          "name": "BL20",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "22",
          "netId": "control_net_36b8e2744fa2",
          "name": "BL21",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "23",
          "netId": "control_net_cb9a53bc7e2d",
          "name": "BL22",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "24",
          "netId": "control_net_0066c578f4fd",
          "name": "BL23",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "25",
          "netId": "control_net_a3c1624fed4f",
          "name": "BL24",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "26",
          "netId": "control_net_06c41da37048",
          "name": "BL25",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "27",
          "netId": "control_net_668f023fd21c",
          "name": "BL26",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "28",
          "netId": "control_net_5a6f03bbf06c",
          "name": "BL27",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "29",
          "netId": "control_net_7deb95e626ac",
          "name": "BL28",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "30",
          "netId": "control_net_9037a6d55684",
          "name": "BL29",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "31",
          "netId": "control_net_e59cadbe90ef",
          "name": "BL30",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "32",
          "netId": "control_net_ae5aa8c25d68",
          "name": "BL31",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "33",
          "netId": "control_net_8238d609143f",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "34",
          "netId": "control_net_e4f13269db06",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "35",
          "netId": "control_net_5b406ad8357d",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "36",
          "netId": "control_net_e066c57b7888",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "37",
          "netId": "control_net_a0fe3e097faf",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "38",
          "netId": "control_net_747cc492238d",
          "name": "WL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "39",
          "netId": "control_net_5ef23046b636",
          "name": "WL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "40",
          "netId": "control_net_6380a00471f5",
          "name": "CASE_COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "41",
          "netId": "control_net_fca0e6b6f6af",
          "name": "WL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "42",
          "netId": "control_net_b0ea7c0c27c3",
          "name": "WL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "43",
          "netId": "control_net_3c196a06fe86",
          "name": "WL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "44",
          "netId": "control_net_945cddbc767f",
          "name": "WL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "45",
          "netId": "control_net_c494e5a21fb7",
          "name": "WL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "46",
          "netId": "control_net_edac321adbf1",
          "name": "WL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "47",
          "netId": "control_net_33ee65c78544",
          "name": "NC",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "48",
          "netId": "control_net_b538393eaff5",
          "name": "GND_REF",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "49",
          "netId": "control_net_9aa6ed5fa484",
          "name": "BL15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "50",
          "netId": "control_net_2661b7e1d1d8",
          "name": "BL14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "51",
          "netId": "control_net_da64d12ab5ef",
          "name": "BL13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "52",
          "netId": "control_net_5b7588c91934",
          "name": "BL12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "53",
          "netId": "control_net_a38212b18dab",
          "name": "BL11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "54",
          "netId": "control_net_b1a7be433721",
          "name": "BL10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "55",
          "netId": "control_net_dee259c78870",
          "name": "BL9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "56",
          "netId": "control_net_ef57e67af6ee",
          "name": "BL8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "57",
          "netId": "control_net_96843655892a",
          "name": "BL7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "58",
          "netId": "control_net_77eb74275447",
          "name": "BL6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "59",
          "netId": "control_net_410ce51ce77b",
          "name": "BL5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "60",
          "netId": "control_net_30db039e0318",
          "name": "BL4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "61",
          "netId": "control_net_538bdbb480c1",
          "name": "BL3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "62",
          "netId": "control_net_7443657d6bc7",
          "name": "BL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "63",
          "netId": "control_net_331bcbe5832b",
          "name": "BL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J1800",
          "pin": "64",
          "netId": "control_net_af268a134ce7",
          "name": "BL0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
