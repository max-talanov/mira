/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_700_FPGA_USB3_FIFO_INTERFACE",
  "title": "Как работает: USB · от кабеля до данных ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
  "steps": [
    {
      "title": "Кабель подключается к USB-C",
      "text": "Разъём принимает сигналы USB и CC. Защитные устройства расположены на внешних линиях, а контроллер ориентации выбирает соответствующий тракт SuperSpeed.",
      "body": "Разъём принимает сигналы USB и CC. Защитные устройства расположены на внешних линиях, а контроллер ориентации выбирает соответствующий тракт SuperSpeed.",
      "nodes": [
        "connector",
        "protection",
        "orientation"
      ],
      "edges": [
        "connector_protection",
        "connector_orientation",
        "protection_orientation"
      ],
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "netIds": [
        "control_net_8a18244b5094",
        "control_net_cd5767d1244a",
        "control_net_4a77ae0a5e9e",
        "control_net_81e7ad5ba413",
        "control_net_dfb816a62c27",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_bb9ef2893216",
        "control_net_3e4cca7b1d3b",
        "control_net_9cc415b59d1d",
        "control_net_3fea9522f27f",
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_D700",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "ESD1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R701",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C707",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R703",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U703",
          "pin": "1",
          "netId": "control_net_cd5767d1244a",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "19",
          "netId": "control_net_cd5767d1244a",
          "name": "RX2p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A11",
          "netId": "control_net_cd5767d1244a",
          "name": "SSRX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U703",
          "pin": "2",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "18",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "RX2n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A10",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "SSRX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "1",
          "netId": "control_net_81e7ad5ba413",
          "name": "CC2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U705",
          "pin": "2",
          "netId": "control_net_81e7ad5ba413",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B5",
          "netId": "control_net_81e7ad5ba413",
          "name": "CC2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "2",
          "netId": "control_net_dfb816a62c27",
          "name": "CC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U705",
          "pin": "1",
          "netId": "control_net_dfb816a62c27",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A5",
          "netId": "control_net_dfb816a62c27",
          "name": "CC1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "14",
          "netId": "control_net_7293b201db23",
          "name": "RX1n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U702",
          "pin": "2",
          "netId": "control_net_7293b201db23",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B10",
          "netId": "control_net_7293b201db23",
          "name": "SSRX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "15",
          "netId": "control_net_c17cad38b3b9",
          "name": "RX1p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U702",
          "pin": "1",
          "netId": "control_net_c17cad38b3b9",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B11",
          "netId": "control_net_c17cad38b3b9",
          "name": "SSRX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "16",
          "netId": "control_net_bb9ef2893216",
          "name": "TX1n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U700",
          "pin": "2",
          "netId": "control_net_bb9ef2893216",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A3",
          "netId": "control_net_bb9ef2893216",
          "name": "SSTX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "17",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "TX1p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U700",
          "pin": "1",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A2",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "SSTX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "20",
          "netId": "control_net_9cc415b59d1d",
          "name": "TX2n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U701",
          "pin": "2",
          "netId": "control_net_9cc415b59d1d",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B3",
          "netId": "control_net_9cc415b59d1d",
          "name": "SSTX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "21",
          "netId": "control_net_3fea9522f27f",
          "name": "TX2p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U701",
          "pin": "1",
          "netId": "control_net_3fea9522f27f",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B2",
          "netId": "control_net_3fea9522f27f",
          "name": "SSTX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U704",
          "pin": "1",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U704",
          "pin": "2",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "USB преобразуется в слова FIFO",
      "text": "FT601 принимает USB-трафик и представляет цифровой интерфейс FIFO шириной 32 бита. Тактовые и управляющие сигналы определяют обмен словами.",
      "body": "FT601 принимает USB-трафик и представляет цифровой интерфейс FIFO шириной 32 бита. Тактовые и управляющие сигналы определяют обмен словами.",
      "nodes": [
        "orientation",
        "bridge",
        "support"
      ],
      "edges": [
        "orientation_bridge",
        "bridge_support"
      ],
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "netIds": [
        "control_net_4e0bed631879",
        "control_net_ee1064f82d57",
        "control_net_90ccce2c8039",
        "control_net_4ab70b5a5d2e",
        "control_net_3ab09453d63e",
        "control_net_b1490930ce10",
        "control_net_db15969a3ef3",
        "control_net_62e5d80fdc50",
        "control_net_66452339ef9c",
        "control_net_b6e5a544d44c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U706",
          "pin": "9",
          "netId": "control_net_4e0bed631879",
          "name": "RXp",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "35",
          "netId": "control_net_4e0bed631879",
          "name": "RIDP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "10",
          "netId": "control_net_ee1064f82d57",
          "name": "RXn",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "34",
          "netId": "control_net_ee1064f82d57",
          "name": "RIDN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C708",
          "pin": "1",
          "netId": "control_net_90ccce2c8039",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "32",
          "netId": "control_net_90ccce2c8039",
          "name": "TODP",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "31",
          "netId": "control_net_4ab70b5a5d2e",
          "name": "TODN",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C709",
          "pin": "1",
          "netId": "control_net_4ab70b5a5d2e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C718",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C729",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C728",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C730",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_FB701",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "3",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "30",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "33",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "39",
          "netId": "control_net_3ab09453d63e",
          "name": "DV10",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "48",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C727",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C719",
          "pin": "1",
          "netId": "control_net_b1490930ce10",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_FB701",
          "pin": "2",
          "netId": "control_net_b1490930ce10",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "2",
          "netId": "control_net_b1490930ce10",
          "name": "AVDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C713",
          "pin": "1",
          "netId": "control_net_db15969a3ef3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y700",
          "pin": "1",
          "netId": "control_net_db15969a3ef3",
          "name": "XTAL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "21",
          "netId": "control_net_db15969a3ef3",
          "name": "XI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C717",
          "pin": "1",
          "netId": "control_net_62e5d80fdc50",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "28",
          "netId": "control_net_62e5d80fdc50",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C716",
          "pin": "1",
          "netId": "control_net_62e5d80fdc50",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_FB700",
          "pin": "2",
          "netId": "control_net_62e5d80fdc50",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C714",
          "pin": "1",
          "netId": "control_net_66452339ef9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y700",
          "pin": "3",
          "netId": "control_net_66452339ef9c",
          "name": "XTAL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "22",
          "netId": "control_net_66452339ef9c",
          "name": "XO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "37",
          "netId": "control_net_b6e5a544d44c",
          "name": "VBUS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U708",
          "pin": "4",
          "netId": "control_net_b6e5a544d44c",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R714",
          "pin": "1",
          "netId": "control_net_b6e5a544d44c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "ПЛИС обменивается словами",
      "text": "Шина данных и сигналы управления потоком соединяют FT601 с U500. Приём и передача используют одну физическую связь с разными состояниями управления.",
      "body": "Шина данных и сигналы управления потоком соединяют FT601 с U500. Приём и передача используют одну физическую связь с разными состояниями управления.",
      "nodes": [
        "bridge",
        "fpga"
      ],
      "edges": [
        "bridge_fpga"
      ],
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "netIds": [
        "control_net_5d12a42f13a7",
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_0aa940b07213",
        "control_net_5f4121b0067b",
        "control_net_45ad74d728ee",
        "control_net_34a5458782a9",
        "control_net_a0ccf5710062",
        "control_net_77550a265a38",
        "control_net_95229f960617",
        "control_net_76c093c7625c",
        "control_net_0c2767ceedce",
        "control_net_e4fd6a071815",
        "control_net_81564ca10d04",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C731",
          "pin": "1",
          "netId": "control_net_5d12a42f13a7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R706",
          "pin": "2",
          "netId": "control_net_5d12a42f13a7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "15",
          "netId": "control_net_5d12a42f13a7",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R712",
          "pin": "1",
          "netId": "control_net_5d12a42f13a7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R711",
          "pin": "2",
          "netId": "control_net_0aa940b07213",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "13",
          "netId": "control_net_0aa940b07213",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P16",
          "netId": "control_net_0aa940b07213",
          "name": "IO_L24P_T3_A01_D17_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R710",
          "pin": "2",
          "netId": "control_net_5f4121b0067b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "11",
          "netId": "control_net_5f4121b0067b",
          "name": "WR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N14",
          "netId": "control_net_5f4121b0067b",
          "name": "IO_L23N_T3_A02_D18_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R713",
          "pin": "2",
          "netId": "control_net_45ad74d728ee",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "12",
          "netId": "control_net_45ad74d728ee",
          "name": "RD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N13",
          "netId": "control_net_45ad74d728ee",
          "name": "IO_L23P_T3_A03_D19_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "4",
          "netId": "control_net_34a5458782a9",
          "name": "BE_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R18",
          "netId": "control_net_34a5458782a9",
          "name": "IO_L20P_T3_A08_D24_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "5",
          "netId": "control_net_a0ccf5710062",
          "name": "BE_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T18",
          "netId": "control_net_a0ccf5710062",
          "name": "IO_L20N_T3_A07_D23_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "6",
          "netId": "control_net_77550a265a38",
          "name": "BE_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N17",
          "netId": "control_net_77550a265a38",
          "name": "IO_L21P_T3_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "7",
          "netId": "control_net_95229f960617",
          "name": "BE_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P17",
          "netId": "control_net_95229f960617",
          "name": "IO_L21N_T3_DQS_A06_D22_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "8",
          "netId": "control_net_76c093c7625c",
          "name": "TXE_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R16",
          "netId": "control_net_76c093c7625c",
          "name": "IO_L22N_T3_A04_D20_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "9",
          "netId": "control_net_0c2767ceedce",
          "name": "RXF_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P15",
          "netId": "control_net_0c2767ceedce",
          "name": "IO_L22P_T3_A05_D21_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "10",
          "netId": "control_net_e4fd6a071815",
          "name": "SIWU_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R707",
          "pin": "2",
          "netId": "control_net_e4fd6a071815",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R17",
          "netId": "control_net_e4fd6a071815",
          "name": "IO_L24N_T3_A00_D16_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "58",
          "netId": "control_net_81564ca10d04",
          "name": "CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W19",
          "netId": "control_net_81564ca10d04",
          "name": "IO_L12P_T1_MRCC_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Кабель подключается к USB-C",
      "text": "Разъём принимает сигналы USB и CC. Защитные устройства расположены на внешних линиях, а контроллер ориентации выбирает соответствующий тракт SuperSpeed.",
      "body": "Разъём принимает сигналы USB и CC. Защитные устройства расположены на внешних линиях, а контроллер ориентации выбирает соответствующий тракт SuperSpeed.",
      "nodes": [
        "connector",
        "protection",
        "orientation"
      ],
      "edges": [
        "connector_protection",
        "connector_orientation",
        "protection_orientation"
      ],
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "netIds": [
        "control_net_8a18244b5094",
        "control_net_cd5767d1244a",
        "control_net_4a77ae0a5e9e",
        "control_net_81e7ad5ba413",
        "control_net_dfb816a62c27",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_bb9ef2893216",
        "control_net_3e4cca7b1d3b",
        "control_net_9cc415b59d1d",
        "control_net_3fea9522f27f",
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_D700",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "ESD1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R701",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C707",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B4",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B9",
          "netId": "control_net_8a18244b5094",
          "name": "VBUS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R703",
          "pin": "1",
          "netId": "control_net_8a18244b5094",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U703",
          "pin": "1",
          "netId": "control_net_cd5767d1244a",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "19",
          "netId": "control_net_cd5767d1244a",
          "name": "RX2p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A11",
          "netId": "control_net_cd5767d1244a",
          "name": "SSRX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U703",
          "pin": "2",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "18",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "RX2n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A10",
          "netId": "control_net_4a77ae0a5e9e",
          "name": "SSRX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "1",
          "netId": "control_net_81e7ad5ba413",
          "name": "CC2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U705",
          "pin": "2",
          "netId": "control_net_81e7ad5ba413",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B5",
          "netId": "control_net_81e7ad5ba413",
          "name": "CC2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "2",
          "netId": "control_net_dfb816a62c27",
          "name": "CC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U705",
          "pin": "1",
          "netId": "control_net_dfb816a62c27",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A5",
          "netId": "control_net_dfb816a62c27",
          "name": "CC1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "14",
          "netId": "control_net_7293b201db23",
          "name": "RX1n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U702",
          "pin": "2",
          "netId": "control_net_7293b201db23",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B10",
          "netId": "control_net_7293b201db23",
          "name": "SSRX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "15",
          "netId": "control_net_c17cad38b3b9",
          "name": "RX1p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U702",
          "pin": "1",
          "netId": "control_net_c17cad38b3b9",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B11",
          "netId": "control_net_c17cad38b3b9",
          "name": "SSRX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "16",
          "netId": "control_net_bb9ef2893216",
          "name": "TX1n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U700",
          "pin": "2",
          "netId": "control_net_bb9ef2893216",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A3",
          "netId": "control_net_bb9ef2893216",
          "name": "SSTX1-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "17",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "TX1p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U700",
          "pin": "1",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A2",
          "netId": "control_net_3e4cca7b1d3b",
          "name": "SSTX1+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "20",
          "netId": "control_net_9cc415b59d1d",
          "name": "TX2n",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U701",
          "pin": "2",
          "netId": "control_net_9cc415b59d1d",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B3",
          "netId": "control_net_9cc415b59d1d",
          "name": "SSTX2-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "21",
          "netId": "control_net_3fea9522f27f",
          "name": "TX2p",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U701",
          "pin": "1",
          "netId": "control_net_3fea9522f27f",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B2",
          "netId": "control_net_3fea9522f27f",
          "name": "SSTX2+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U704",
          "pin": "1",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B6",
          "netId": "control_net_95ec31f2c17b",
          "name": "D+",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U704",
          "pin": "2",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "A7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J700",
          "pin": "B7",
          "netId": "control_net_93c1caa5f020",
          "name": "D-",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "USB преобразуется в слова FIFO",
      "text": "FT601 принимает USB-трафик и представляет цифровой интерфейс FIFO шириной 32 бита. Тактовые и управляющие сигналы определяют обмен словами.",
      "body": "FT601 принимает USB-трафик и представляет цифровой интерфейс FIFO шириной 32 бита. Тактовые и управляющие сигналы определяют обмен словами.",
      "nodes": [
        "orientation",
        "bridge",
        "support"
      ],
      "edges": [
        "orientation_bridge",
        "bridge_support"
      ],
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "netIds": [
        "control_net_4e0bed631879",
        "control_net_ee1064f82d57",
        "control_net_90ccce2c8039",
        "control_net_4ab70b5a5d2e",
        "control_net_3ab09453d63e",
        "control_net_b1490930ce10",
        "control_net_db15969a3ef3",
        "control_net_62e5d80fdc50",
        "control_net_66452339ef9c",
        "control_net_b6e5a544d44c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U706",
          "pin": "9",
          "netId": "control_net_4e0bed631879",
          "name": "RXp",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "35",
          "netId": "control_net_4e0bed631879",
          "name": "RIDP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U706",
          "pin": "10",
          "netId": "control_net_ee1064f82d57",
          "name": "RXn",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "34",
          "netId": "control_net_ee1064f82d57",
          "name": "RIDN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C708",
          "pin": "1",
          "netId": "control_net_90ccce2c8039",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "32",
          "netId": "control_net_90ccce2c8039",
          "name": "TODP",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "31",
          "netId": "control_net_4ab70b5a5d2e",
          "name": "TODN",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C709",
          "pin": "1",
          "netId": "control_net_4ab70b5a5d2e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C718",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C729",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C728",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C730",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_FB701",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "3",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "30",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "33",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "39",
          "netId": "control_net_3ab09453d63e",
          "name": "DV10",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "48",
          "netId": "control_net_3ab09453d63e",
          "name": "VD10",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C727",
          "pin": "1",
          "netId": "control_net_3ab09453d63e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C719",
          "pin": "1",
          "netId": "control_net_b1490930ce10",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_FB701",
          "pin": "2",
          "netId": "control_net_b1490930ce10",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "2",
          "netId": "control_net_b1490930ce10",
          "name": "AVDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C713",
          "pin": "1",
          "netId": "control_net_db15969a3ef3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y700",
          "pin": "1",
          "netId": "control_net_db15969a3ef3",
          "name": "XTAL1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "21",
          "netId": "control_net_db15969a3ef3",
          "name": "XI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C717",
          "pin": "1",
          "netId": "control_net_62e5d80fdc50",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "28",
          "netId": "control_net_62e5d80fdc50",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C716",
          "pin": "1",
          "netId": "control_net_62e5d80fdc50",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_FB700",
          "pin": "2",
          "netId": "control_net_62e5d80fdc50",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C714",
          "pin": "1",
          "netId": "control_net_66452339ef9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y700",
          "pin": "3",
          "netId": "control_net_66452339ef9c",
          "name": "XTAL2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "22",
          "netId": "control_net_66452339ef9c",
          "name": "XO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "37",
          "netId": "control_net_b6e5a544d44c",
          "name": "VBUS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U708",
          "pin": "4",
          "netId": "control_net_b6e5a544d44c",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R714",
          "pin": "1",
          "netId": "control_net_b6e5a544d44c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "ПЛИС обменивается словами",
      "text": "Шина данных и сигналы управления потоком соединяют FT601 с U500. Приём и передача используют одну физическую связь с разными состояниями управления.",
      "body": "Шина данных и сигналы управления потоком соединяют FT601 с U500. Приём и передача используют одну физическую связь с разными состояниями управления.",
      "nodes": [
        "bridge",
        "fpga"
      ],
      "edges": [
        "bridge_fpga"
      ],
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "netIds": [
        "control_net_5d12a42f13a7",
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_0aa940b07213",
        "control_net_5f4121b0067b",
        "control_net_45ad74d728ee",
        "control_net_34a5458782a9",
        "control_net_a0ccf5710062",
        "control_net_77550a265a38",
        "control_net_95229f960617",
        "control_net_76c093c7625c",
        "control_net_0c2767ceedce",
        "control_net_e4fd6a071815",
        "control_net_81564ca10d04",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_C731",
          "pin": "1",
          "netId": "control_net_5d12a42f13a7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R706",
          "pin": "2",
          "netId": "control_net_5d12a42f13a7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "15",
          "netId": "control_net_5d12a42f13a7",
          "name": "RESET_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R712",
          "pin": "1",
          "netId": "control_net_5d12a42f13a7",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R711",
          "pin": "2",
          "netId": "control_net_0aa940b07213",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "13",
          "netId": "control_net_0aa940b07213",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P16",
          "netId": "control_net_0aa940b07213",
          "name": "IO_L24P_T3_A01_D17_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R710",
          "pin": "2",
          "netId": "control_net_5f4121b0067b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "11",
          "netId": "control_net_5f4121b0067b",
          "name": "WR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N14",
          "netId": "control_net_5f4121b0067b",
          "name": "IO_L23N_T3_A02_D18_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R713",
          "pin": "2",
          "netId": "control_net_45ad74d728ee",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "12",
          "netId": "control_net_45ad74d728ee",
          "name": "RD_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N13",
          "netId": "control_net_45ad74d728ee",
          "name": "IO_L23P_T3_A03_D19_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "4",
          "netId": "control_net_34a5458782a9",
          "name": "BE_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R18",
          "netId": "control_net_34a5458782a9",
          "name": "IO_L20P_T3_A08_D24_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "5",
          "netId": "control_net_a0ccf5710062",
          "name": "BE_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T18",
          "netId": "control_net_a0ccf5710062",
          "name": "IO_L20N_T3_A07_D23_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "6",
          "netId": "control_net_77550a265a38",
          "name": "BE_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N17",
          "netId": "control_net_77550a265a38",
          "name": "IO_L21P_T3_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "7",
          "netId": "control_net_95229f960617",
          "name": "BE_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P17",
          "netId": "control_net_95229f960617",
          "name": "IO_L21N_T3_DQS_A06_D22_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "8",
          "netId": "control_net_76c093c7625c",
          "name": "TXE_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R16",
          "netId": "control_net_76c093c7625c",
          "name": "IO_L22N_T3_A04_D20_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "9",
          "netId": "control_net_0c2767ceedce",
          "name": "RXF_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P15",
          "netId": "control_net_0c2767ceedce",
          "name": "IO_L22P_T3_A05_D21_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "10",
          "netId": "control_net_e4fd6a071815",
          "name": "SIWU_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R707",
          "pin": "2",
          "netId": "control_net_e4fd6a071815",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R17",
          "netId": "control_net_e4fd6a071815",
          "name": "IO_L24N_T3_A00_D16_14",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "58",
          "netId": "control_net_81564ca10d04",
          "name": "CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W19",
          "netId": "control_net_81564ca10d04",
          "name": "IO_L12P_T1_MRCC_14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
