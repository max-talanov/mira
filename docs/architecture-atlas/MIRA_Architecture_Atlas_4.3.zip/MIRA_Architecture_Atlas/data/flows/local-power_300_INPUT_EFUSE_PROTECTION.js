/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_300_INPUT_EFUSE_PROTECTION",
  "title": "Как работает: Ограничение и отключение питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
  "steps": [
    {
      "title": "Питание входит в защищаемый тракт",
      "text": "Последовательный MOSFET и диод образуют показанную в схеме входную защиту от нежелательного обратного пути.",
      "body": "Последовательный MOSFET и диод образуют показанную в схеме входную защиту от нежелательного обратного пути.",
      "nodes": [
        "reverse",
        "efuse"
      ],
      "edges": [
        "efuse_reverse"
      ],
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "netIds": [
        "power_net_a837894762cd",
        "power_net_3dcac14084cf",
        "power_net_3937c8c839ac"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R310",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C305",
          "pin": "2",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "18",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "19",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "20",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D301",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q301",
          "pin": "1",
          "netId": "power_net_3dcac14084cf",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C303",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "3",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Электронный предохранитель управляет током",
      "text": "U301 регулирует включение защищённого питания и реагирует на аварийные условия согласно своей обвязке.",
      "body": "U301 регулирует включение защищённого питания и реагирует на аварийные условия согласно своей обвязке.",
      "nodes": [
        "efuse"
      ],
      "edges": [],
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "netIds": [
        "power_net_ebbb4413206b",
        "power_net_fc972acc08ff",
        "power_net_212cb9d210a9",
        "power_net_cd4425540176",
        "power_net_a837894762cd",
        "power_net_3e20fe25098d",
        "power_net_c9b6c7228333",
        "power_net_67006db669b3",
        "power_net_4debf317f2c4",
        "power_net_4277075bbc34",
        "power_net_3937c8c839ac",
        "power_net_3dcac14084cf",
        "power_net_0118a5d9fdb8",
        "power_net_e5a2750417c1",
        "power_net_cc22b913a226",
        "power_net_9517f7952aef",
        "power_net_fc607675ab2d",
        "power_net_35045b6a457d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R302",
          "pin": "2",
          "netId": "power_net_ebbb4413206b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R303",
          "pin": "1",
          "netId": "power_net_ebbb4413206b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "7",
          "netId": "power_net_ebbb4413206b",
          "name": "UVLO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R303",
          "pin": "2",
          "netId": "power_net_fc972acc08ff",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R302",
          "pin": "1",
          "netId": "power_net_212cb9d210a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "8",
          "netId": "power_net_212cb9d210a9",
          "name": "OVP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R301",
          "pin": "2",
          "netId": "power_net_212cb9d210a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R308",
          "pin": "1",
          "netId": "power_net_cd4425540176",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "16",
          "netId": "power_net_cd4425540176",
          "name": "PGTH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R309",
          "pin": "2",
          "netId": "power_net_cd4425540176",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R310",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C305",
          "pin": "2",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "18",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "19",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "20",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R310",
          "pin": "2",
          "netId": "power_net_3e20fe25098d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R309",
          "pin": "1",
          "netId": "power_net_3e20fe25098d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "17",
          "netId": "power_net_c9b6c7228333",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R307",
          "pin": "1",
          "netId": "power_net_c9b6c7228333",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R307",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "10",
          "netId": "power_net_4debf317f2c4",
          "name": "dVdT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C304",
          "pin": "1",
          "netId": "power_net_4debf317f2c4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "11",
          "netId": "power_net_4277075bbc34",
          "name": "ILIM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R305",
          "pin": "1",
          "netId": "power_net_4277075bbc34",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C303",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "3",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "5",
          "netId": "power_net_0118a5d9fdb8",
          "name": "DRV",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "6",
          "netId": "power_net_e5a2750417c1",
          "name": "IN_SYS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "12",
          "netId": "power_net_cc22b913a226",
          "name": "MODE",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "13",
          "netId": "power_net_9517f7952aef",
          "name": "SHDN_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "14",
          "netId": "power_net_fc607675ab2d",
          "name": "IMON",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "15",
          "netId": "power_net_35045b6a457d",
          "name": "FLT_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Команда и индикация задают состояние",
      "text": "Локальные управляющие элементы, перемычка и индикация связаны с запуском eFuse. Наличие напряжения до защиты ещё не означает питание после неё.",
      "body": "Локальные управляющие элементы, перемычка и индикация связаны с запуском eFuse. Наличие напряжения до защиты ещё не означает питание после неё.",
      "nodes": [
        "enable",
        "efuse"
      ],
      "edges": [
        "efuse_enable"
      ],
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "netIds": [
        "power_net_0118a5d9fdb8",
        "power_net_3dcac14084cf",
        "power_net_fc972acc08ff",
        "power_net_9517f7952aef",
        "power_net_35045b6a457d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q302",
          "pin": "1",
          "netId": "power_net_0118a5d9fdb8",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "5",
          "netId": "power_net_0118a5d9fdb8",
          "name": "DRV",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q302",
          "pin": "3",
          "netId": "power_net_3dcac14084cf",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R303",
          "pin": "2",
          "netId": "power_net_fc972acc08ff",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R304",
          "pin": "1",
          "netId": "power_net_fc972acc08ff",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "13",
          "netId": "power_net_9517f7952aef",
          "name": "SHDN_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_JP301",
          "pin": "1",
          "netId": "power_net_9517f7952aef",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "15",
          "netId": "power_net_35045b6a457d",
          "name": "FLT_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D302",
          "pin": "1",
          "netId": "power_net_35045b6a457d",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Питание входит в защищаемый тракт",
      "text": "Последовательный MOSFET и диод образуют показанную в схеме входную защиту от нежелательного обратного пути.",
      "body": "Последовательный MOSFET и диод образуют показанную в схеме входную защиту от нежелательного обратного пути.",
      "nodes": [
        "reverse",
        "efuse"
      ],
      "edges": [
        "efuse_reverse"
      ],
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "netIds": [
        "power_net_a837894762cd",
        "power_net_3dcac14084cf",
        "power_net_3937c8c839ac"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R310",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C305",
          "pin": "2",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "18",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "19",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "20",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D301",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q301",
          "pin": "1",
          "netId": "power_net_3dcac14084cf",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C303",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "3",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Электронный предохранитель управляет током",
      "text": "U301 регулирует включение защищённого питания и реагирует на аварийные условия согласно своей обвязке.",
      "body": "U301 регулирует включение защищённого питания и реагирует на аварийные условия согласно своей обвязке.",
      "nodes": [
        "efuse"
      ],
      "edges": [],
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "netIds": [
        "power_net_ebbb4413206b",
        "power_net_fc972acc08ff",
        "power_net_212cb9d210a9",
        "power_net_cd4425540176",
        "power_net_a837894762cd",
        "power_net_3e20fe25098d",
        "power_net_c9b6c7228333",
        "power_net_67006db669b3",
        "power_net_4debf317f2c4",
        "power_net_4277075bbc34",
        "power_net_3937c8c839ac",
        "power_net_3dcac14084cf",
        "power_net_0118a5d9fdb8",
        "power_net_e5a2750417c1",
        "power_net_cc22b913a226",
        "power_net_9517f7952aef",
        "power_net_fc607675ab2d",
        "power_net_35045b6a457d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R302",
          "pin": "2",
          "netId": "power_net_ebbb4413206b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R303",
          "pin": "1",
          "netId": "power_net_ebbb4413206b",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "7",
          "netId": "power_net_ebbb4413206b",
          "name": "UVLO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R303",
          "pin": "2",
          "netId": "power_net_fc972acc08ff",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R302",
          "pin": "1",
          "netId": "power_net_212cb9d210a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "8",
          "netId": "power_net_212cb9d210a9",
          "name": "OVP",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R301",
          "pin": "2",
          "netId": "power_net_212cb9d210a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R308",
          "pin": "1",
          "netId": "power_net_cd4425540176",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "16",
          "netId": "power_net_cd4425540176",
          "name": "PGTH",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R309",
          "pin": "2",
          "netId": "power_net_cd4425540176",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R310",
          "pin": "1",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C305",
          "pin": "2",
          "netId": "power_net_a837894762cd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "18",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "19",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "20",
          "netId": "power_net_a837894762cd",
          "name": "OUT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R310",
          "pin": "2",
          "netId": "power_net_3e20fe25098d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R309",
          "pin": "1",
          "netId": "power_net_3e20fe25098d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "17",
          "netId": "power_net_c9b6c7228333",
          "name": "PGOOD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R307",
          "pin": "1",
          "netId": "power_net_c9b6c7228333",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R307",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "10",
          "netId": "power_net_4debf317f2c4",
          "name": "dVdT",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C304",
          "pin": "1",
          "netId": "power_net_4debf317f2c4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "11",
          "netId": "power_net_4277075bbc34",
          "name": "ILIM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R305",
          "pin": "1",
          "netId": "power_net_4277075bbc34",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C303",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "1",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "2",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "3",
          "netId": "power_net_3937c8c839ac",
          "name": "IN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "5",
          "netId": "power_net_0118a5d9fdb8",
          "name": "DRV",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "6",
          "netId": "power_net_e5a2750417c1",
          "name": "IN_SYS",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "12",
          "netId": "power_net_cc22b913a226",
          "name": "MODE",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "13",
          "netId": "power_net_9517f7952aef",
          "name": "SHDN_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "14",
          "netId": "power_net_fc607675ab2d",
          "name": "IMON",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "15",
          "netId": "power_net_35045b6a457d",
          "name": "FLT_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Команда и индикация задают состояние",
      "text": "Локальные управляющие элементы, перемычка и индикация связаны с запуском eFuse. Наличие напряжения до защиты ещё не означает питание после неё.",
      "body": "Локальные управляющие элементы, перемычка и индикация связаны с запуском eFuse. Наличие напряжения до защиты ещё не означает питание после неё.",
      "nodes": [
        "enable",
        "efuse"
      ],
      "edges": [
        "efuse_enable"
      ],
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "netIds": [
        "power_net_0118a5d9fdb8",
        "power_net_3dcac14084cf",
        "power_net_fc972acc08ff",
        "power_net_9517f7952aef",
        "power_net_35045b6a457d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q302",
          "pin": "1",
          "netId": "power_net_0118a5d9fdb8",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "5",
          "netId": "power_net_0118a5d9fdb8",
          "name": "DRV",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q302",
          "pin": "3",
          "netId": "power_net_3dcac14084cf",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "4",
          "netId": "power_net_3dcac14084cf",
          "name": "B_GATE",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R303",
          "pin": "2",
          "netId": "power_net_fc972acc08ff",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R304",
          "pin": "1",
          "netId": "power_net_fc972acc08ff",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "13",
          "netId": "power_net_9517f7952aef",
          "name": "SHDN_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_JP301",
          "pin": "1",
          "netId": "power_net_9517f7952aef",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U301",
          "pin": "15",
          "netId": "power_net_35045b6a457d",
          "name": "FLT_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D302",
          "pin": "1",
          "netId": "power_net_35045b6a457d",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
