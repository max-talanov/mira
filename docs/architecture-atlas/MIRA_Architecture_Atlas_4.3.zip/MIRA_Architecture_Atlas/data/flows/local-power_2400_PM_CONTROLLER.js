/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2400_PM_CONTROLLER",
  "title": "Как работает: Контроллер последовательности питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2400_PM_CONTROLLER",
  "steps": [
    {
      "title": "Дежурное питание запускает диспетчер",
      "text": "Локальные цепи питания и запуска обеспечивают работу STM32G0 диспетчера питания.",
      "body": "Локальные цепи питания и запуска обеспечивают работу STM32G0 диспетчера питания.",
      "nodes": [
        "support",
        "controller"
      ],
      "edges": [
        "controller_support"
      ],
      "sceneId": "power_2400_PM_CONTROLLER",
      "netIds": [
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2404",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2402",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2405",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2403",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Диспетчер выдаёт запросы",
      "text": "Программа STM32G0 формирует запросы ветвей питания и принимает сигналы состояния. Аппаратные разрешения проверяются отдельной логикой.",
      "body": "Программа STM32G0 формирует запросы ветвей питания и принимает сигналы состояния. Аппаратные разрешения проверяются отдельной логикой.",
      "nodes": [
        "controller"
      ],
      "edges": [],
      "sceneId": "power_2400_PM_CONTROLLER",
      "netIds": [
        "power_net_9ab95937734d",
        "power_net_cfb766cbb94f",
        "power_net_47f67f61993c",
        "power_net_15b0cf67917c",
        "power_net_9389f5dbe1a6",
        "power_net_67006db669b3",
        "power_net_f4716909bd0c",
        "power_net_3f4e1d0f28d6",
        "power_net_2cbf74589b12",
        "power_net_6ad422db16ac",
        "power_net_6d982403b080",
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_393e02135991",
        "power_net_f632ebdd7344",
        "power_net_e5822cf03a94",
        "power_net_4d93f44a0a86",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a",
        "power_net_36bf51cd4ad6",
        "power_net_ccf5ee78cf75",
        "power_net_c9b6c7228333",
        "power_net_35045b6a457d",
        "power_net_4aeb4892b398",
        "power_net_25cd945f19a1",
        "power_net_a250a8b7fe30",
        "power_net_8828c890966d",
        "power_net_5a1f578d112a",
        "power_net_86751620b7fb",
        "power_net_ae3b1a85f32f",
        "power_net_cfa48b7bd3ef",
        "power_net_2965499926c8",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ed26aaa81531",
        "power_net_ac83bbc60cc7",
        "power_net_0ee4f5245d75",
        "power_net_99aaef80128f",
        "power_net_e1dd2bfabf3b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "PC11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "2",
          "netId": "power_net_cfb766cbb94f",
          "name": "PC12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "4",
          "netId": "power_net_15b0cf67917c",
          "name": "PC14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "5",
          "netId": "power_net_9389f5dbe1a6",
          "name": "PC15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "10",
          "netId": "power_net_f4716909bd0c",
          "name": "PF0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "11",
          "netId": "power_net_3f4e1d0f28d6",
          "name": "PF1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "13",
          "netId": "power_net_6ad422db16ac",
          "name": "PC0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "14",
          "netId": "power_net_6d982403b080",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "15",
          "netId": "power_net_55a52205aaf0",
          "name": "PC2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "16",
          "netId": "power_net_47577a24d67e",
          "name": "PC3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "17",
          "netId": "power_net_393e02135991",
          "name": "PA0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "18",
          "netId": "power_net_f632ebdd7344",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "19",
          "netId": "power_net_e5822cf03a94",
          "name": "PA2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "20",
          "netId": "power_net_4d93f44a0a86",
          "name": "PA3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "21",
          "netId": "power_net_c19f5798f458",
          "name": "PA4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "22",
          "netId": "power_net_c66ec173184e",
          "name": "PA5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "23",
          "netId": "power_net_83fb386e92c5",
          "name": "PA6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "24",
          "netId": "power_net_c876bbd15aa2",
          "name": "PA7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "25",
          "netId": "power_net_5a10e16f7ce2",
          "name": "PC4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "26",
          "netId": "power_net_1f6f0734f873",
          "name": "PC5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "27",
          "netId": "power_net_afa5c4d57041",
          "name": "PB0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "28",
          "netId": "power_net_d1fe7a20e661",
          "name": "PB1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "29",
          "netId": "power_net_1b4ac01010f8",
          "name": "PB2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "30",
          "netId": "power_net_5dc0cb853f29",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "31",
          "netId": "power_net_69d4e38b1bd0",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "32",
          "netId": "power_net_2c93a597633f",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "33",
          "netId": "power_net_12bae3231aaa",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "34",
          "netId": "power_net_b527a6b82695",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "35",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "36",
          "netId": "power_net_97db96dcc04b",
          "name": "PA8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "37",
          "netId": "power_net_2074a83eb788",
          "name": "PA9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "38",
          "netId": "power_net_7071622db9df",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "39",
          "netId": "power_net_b5187ab6f19a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "40",
          "netId": "power_net_36bf51cd4ad6",
          "name": "PD8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "41",
          "netId": "power_net_ccf5ee78cf75",
          "name": "PD9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "42",
          "netId": "power_net_c9b6c7228333",
          "name": "PA10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "43",
          "netId": "power_net_35045b6a457d",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "45",
          "netId": "power_net_25cd945f19a1",
          "name": "PA13/SWDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "46",
          "netId": "power_net_a250a8b7fe30",
          "name": "PA14/BOOT0/SWCLK",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "49",
          "netId": "power_net_86751620b7fb",
          "name": "PC9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обратная связь поступает в контроллер",
      "text": "Телеметрия и статусы позволяют программе оценивать состояние ветвей. Эта история не утверждает конкретный алгоритм прошивки или задержки запуска.",
      "body": "Телеметрия и статусы позволяют программе оценивать состояние ветвей. Эта история не утверждает конкретный алгоритм прошивки или задержки запуска.",
      "nodes": [
        "controller",
        "support"
      ],
      "edges": [
        "controller_support"
      ],
      "sceneId": "power_2400_PM_CONTROLLER",
      "netIds": [
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2404",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2402",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2405",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2403",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Дежурное питание запускает диспетчер",
      "text": "Локальные цепи питания и запуска обеспечивают работу STM32G0 диспетчера питания.",
      "body": "Локальные цепи питания и запуска обеспечивают работу STM32G0 диспетчера питания.",
      "nodes": [
        "support",
        "controller"
      ],
      "edges": [
        "controller_support"
      ],
      "sceneId": "power_2400_PM_CONTROLLER",
      "netIds": [
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2404",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2402",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2405",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2403",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Диспетчер выдаёт запросы",
      "text": "Программа STM32G0 формирует запросы ветвей питания и принимает сигналы состояния. Аппаратные разрешения проверяются отдельной логикой.",
      "body": "Программа STM32G0 формирует запросы ветвей питания и принимает сигналы состояния. Аппаратные разрешения проверяются отдельной логикой.",
      "nodes": [
        "controller"
      ],
      "edges": [],
      "sceneId": "power_2400_PM_CONTROLLER",
      "netIds": [
        "power_net_9ab95937734d",
        "power_net_cfb766cbb94f",
        "power_net_47f67f61993c",
        "power_net_15b0cf67917c",
        "power_net_9389f5dbe1a6",
        "power_net_67006db669b3",
        "power_net_f4716909bd0c",
        "power_net_3f4e1d0f28d6",
        "power_net_2cbf74589b12",
        "power_net_6ad422db16ac",
        "power_net_6d982403b080",
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_393e02135991",
        "power_net_f632ebdd7344",
        "power_net_e5822cf03a94",
        "power_net_4d93f44a0a86",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a",
        "power_net_36bf51cd4ad6",
        "power_net_ccf5ee78cf75",
        "power_net_c9b6c7228333",
        "power_net_35045b6a457d",
        "power_net_4aeb4892b398",
        "power_net_25cd945f19a1",
        "power_net_a250a8b7fe30",
        "power_net_8828c890966d",
        "power_net_5a1f578d112a",
        "power_net_86751620b7fb",
        "power_net_ae3b1a85f32f",
        "power_net_cfa48b7bd3ef",
        "power_net_2965499926c8",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ed26aaa81531",
        "power_net_ac83bbc60cc7",
        "power_net_0ee4f5245d75",
        "power_net_99aaef80128f",
        "power_net_e1dd2bfabf3b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "PC11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "2",
          "netId": "power_net_cfb766cbb94f",
          "name": "PC12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "4",
          "netId": "power_net_15b0cf67917c",
          "name": "PC14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "5",
          "netId": "power_net_9389f5dbe1a6",
          "name": "PC15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "10",
          "netId": "power_net_f4716909bd0c",
          "name": "PF0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "11",
          "netId": "power_net_3f4e1d0f28d6",
          "name": "PF1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "13",
          "netId": "power_net_6ad422db16ac",
          "name": "PC0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "14",
          "netId": "power_net_6d982403b080",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "15",
          "netId": "power_net_55a52205aaf0",
          "name": "PC2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "16",
          "netId": "power_net_47577a24d67e",
          "name": "PC3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "17",
          "netId": "power_net_393e02135991",
          "name": "PA0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "18",
          "netId": "power_net_f632ebdd7344",
          "name": "PA1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "19",
          "netId": "power_net_e5822cf03a94",
          "name": "PA2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "20",
          "netId": "power_net_4d93f44a0a86",
          "name": "PA3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "21",
          "netId": "power_net_c19f5798f458",
          "name": "PA4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "22",
          "netId": "power_net_c66ec173184e",
          "name": "PA5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "23",
          "netId": "power_net_83fb386e92c5",
          "name": "PA6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "24",
          "netId": "power_net_c876bbd15aa2",
          "name": "PA7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "25",
          "netId": "power_net_5a10e16f7ce2",
          "name": "PC4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "26",
          "netId": "power_net_1f6f0734f873",
          "name": "PC5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "27",
          "netId": "power_net_afa5c4d57041",
          "name": "PB0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "28",
          "netId": "power_net_d1fe7a20e661",
          "name": "PB1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "29",
          "netId": "power_net_1b4ac01010f8",
          "name": "PB2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "30",
          "netId": "power_net_5dc0cb853f29",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "31",
          "netId": "power_net_69d4e38b1bd0",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "32",
          "netId": "power_net_2c93a597633f",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "33",
          "netId": "power_net_12bae3231aaa",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "34",
          "netId": "power_net_b527a6b82695",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "35",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "PB15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "36",
          "netId": "power_net_97db96dcc04b",
          "name": "PA8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "37",
          "netId": "power_net_2074a83eb788",
          "name": "PA9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "38",
          "netId": "power_net_7071622db9df",
          "name": "PC6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "39",
          "netId": "power_net_b5187ab6f19a",
          "name": "PC7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "40",
          "netId": "power_net_36bf51cd4ad6",
          "name": "PD8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "41",
          "netId": "power_net_ccf5ee78cf75",
          "name": "PD9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "42",
          "netId": "power_net_c9b6c7228333",
          "name": "PA10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "43",
          "netId": "power_net_35045b6a457d",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "45",
          "netId": "power_net_25cd945f19a1",
          "name": "PA13/SWDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "46",
          "netId": "power_net_a250a8b7fe30",
          "name": "PA14/BOOT0/SWCLK",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "49",
          "netId": "power_net_86751620b7fb",
          "name": "PC9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Обратная связь поступает в контроллер",
      "text": "Телеметрия и статусы позволяют программе оценивать состояние ветвей. Эта история не утверждает конкретный алгоритм прошивки или задержки запуска.",
      "body": "Телеметрия и статусы позволяют программе оценивать состояние ветвей. Эта история не утверждает конкретный алгоритм прошивки или задержки запуска.",
      "nodes": [
        "controller",
        "support"
      ],
      "edges": [
        "controller_support"
      ],
      "sceneId": "power_2400_PM_CONTROLLER",
      "netIds": [
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "7",
          "netId": "power_net_67006db669b3",
          "name": "VREF+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "VDD/VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2404",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2402",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2405",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2403",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
