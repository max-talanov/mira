/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3400_NEGATIVE_RAIL_MONITOR",
  "title": "Как работает: Измерение отрицательной шины",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
  "steps": [
    {
      "title": "Измеряется отрицательная шина",
      "text": "Двойной усилитель преобразует информацию об отрицательном напряжении и токе в мониторные сигналы относительно общего провода.",
      "body": "Двойной усилитель преобразует информацию об отрицательном напряжении и токе в мониторные сигналы относительно общего провода.",
      "nodes": [
        "sense"
      ],
      "edges": [],
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "netIds": [
        "power_net_85fba6457595",
        "power_net_73e3c3662042",
        "power_net_1102d6d40667",
        "power_net_28c7570b1cac",
        "power_net_f0f2c8248eaf",
        "power_net_e64007ec9076",
        "power_net_67006db669b3",
        "power_net_c215e379dc64",
        "power_net_de6034a2bdb7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C3402",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "4",
          "netId": "power_net_85fba6457595",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "2",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "3",
          "netId": "power_net_1102d6d40667",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3404",
          "pin": "1",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "6",
          "netId": "power_net_f0f2c8248eaf",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "7",
          "netId": "power_net_e64007ec9076",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигналы ограничиваются и фильтруются",
      "text": "Защитные диоды и фильтры подготавливают выходы к дальнейшей телеметрии.",
      "body": "Защитные диоды и фильтры подготавливают выходы к дальнейшей телеметрии.",
      "nodes": [
        "sense",
        "clamp"
      ],
      "edges": [
        "sense_clamp"
      ],
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "netIds": [
        "power_net_de6034a2bdb7",
        "power_net_28c7570b1cac"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3409",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3402",
          "pin": "3",
          "netId": "power_net_de6034a2bdb7",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3404",
          "pin": "1",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3408",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3407",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Мониторные цепи идут к выбору канала",
      "text": "Выходы напряжения и тока продолжаются в систему выбора измеряемой ветви. Значения здесь не являются результатом реального измерения в браузере.",
      "body": "Выходы напряжения и тока продолжаются в систему выбора измеряемой ветви. Значения здесь не являются результатом реального измерения в браузере.",
      "nodes": [
        "sense"
      ],
      "edges": [],
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "netIds": [
        "power_net_85fba6457595",
        "power_net_73e3c3662042",
        "power_net_1102d6d40667",
        "power_net_28c7570b1cac",
        "power_net_f0f2c8248eaf",
        "power_net_e64007ec9076",
        "power_net_67006db669b3",
        "power_net_c215e379dc64",
        "power_net_de6034a2bdb7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C3402",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "4",
          "netId": "power_net_85fba6457595",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "2",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "3",
          "netId": "power_net_1102d6d40667",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3404",
          "pin": "1",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "6",
          "netId": "power_net_f0f2c8248eaf",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "7",
          "netId": "power_net_e64007ec9076",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измеряется отрицательная шина",
      "text": "Двойной усилитель преобразует информацию об отрицательном напряжении и токе в мониторные сигналы относительно общего провода.",
      "body": "Двойной усилитель преобразует информацию об отрицательном напряжении и токе в мониторные сигналы относительно общего провода.",
      "nodes": [
        "sense"
      ],
      "edges": [],
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "netIds": [
        "power_net_85fba6457595",
        "power_net_73e3c3662042",
        "power_net_1102d6d40667",
        "power_net_28c7570b1cac",
        "power_net_f0f2c8248eaf",
        "power_net_e64007ec9076",
        "power_net_67006db669b3",
        "power_net_c215e379dc64",
        "power_net_de6034a2bdb7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C3402",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "4",
          "netId": "power_net_85fba6457595",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "2",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "3",
          "netId": "power_net_1102d6d40667",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3404",
          "pin": "1",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "6",
          "netId": "power_net_f0f2c8248eaf",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "7",
          "netId": "power_net_e64007ec9076",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сигналы ограничиваются и фильтруются",
      "text": "Защитные диоды и фильтры подготавливают выходы к дальнейшей телеметрии.",
      "body": "Защитные диоды и фильтры подготавливают выходы к дальнейшей телеметрии.",
      "nodes": [
        "sense",
        "clamp"
      ],
      "edges": [
        "sense_clamp"
      ],
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "netIds": [
        "power_net_de6034a2bdb7",
        "power_net_28c7570b1cac"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R3409",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D3402",
          "pin": "3",
          "netId": "power_net_de6034a2bdb7",
          "name": "K1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3404",
          "pin": "1",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3408",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3407",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Мониторные цепи идут к выбору канала",
      "text": "Выходы напряжения и тока продолжаются в систему выбора измеряемой ветви. Значения здесь не являются результатом реального измерения в браузере.",
      "body": "Выходы напряжения и тока продолжаются в систему выбора измеряемой ветви. Значения здесь не являются результатом реального измерения в браузере.",
      "nodes": [
        "sense"
      ],
      "edges": [],
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "netIds": [
        "power_net_85fba6457595",
        "power_net_73e3c3662042",
        "power_net_1102d6d40667",
        "power_net_28c7570b1cac",
        "power_net_f0f2c8248eaf",
        "power_net_e64007ec9076",
        "power_net_67006db669b3",
        "power_net_c215e379dc64",
        "power_net_de6034a2bdb7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_C3402",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "1",
          "netId": "power_net_85fba6457595",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "4",
          "netId": "power_net_85fba6457595",
          "name": "V-",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3403",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "2",
          "netId": "power_net_73e3c3662042",
          "name": "IN-_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "2",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "3",
          "netId": "power_net_1102d6d40667",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3404",
          "pin": "1",
          "netId": "power_net_1102d6d40667",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3405",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "1",
          "netId": "power_net_28c7570b1cac",
          "name": "OUT_A",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "6",
          "netId": "power_net_f0f2c8248eaf",
          "name": "IN-_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "2",
          "netId": "power_net_f0f2c8248eaf",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3406",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "7",
          "netId": "power_net_e64007ec9076",
          "name": "OUT_B",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "1",
          "netId": "power_net_e64007ec9076",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3401",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3401",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3401",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3402",
          "pin": "1",
          "netId": "power_net_c215e379dc64",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R3409",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
