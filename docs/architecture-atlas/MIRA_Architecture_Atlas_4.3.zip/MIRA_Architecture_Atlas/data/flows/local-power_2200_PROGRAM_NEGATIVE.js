/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2200_PROGRAM_NEGATIVE",
  "title": "Как работает: Коммутация отрицательного питания записи",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2200_PROGRAM_NEGATIVE",
  "steps": [
    {
      "title": "Команда переходит в отрицательный домен",
      "text": "Оптопары передают управляющие запросы к схеме отрицательной программирующей шины.",
      "body": "Оптопары передают управляющие запросы к схеме отрицательной программирующей шины.",
      "nodes": [
        "control"
      ],
      "edges": [],
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "netIds": [
        "power_net_563d73fc35e8",
        "power_net_46ab17b8adeb",
        "power_net_646f65822b1f",
        "power_net_77d673a9c74f",
        "power_net_67006db669b3",
        "power_net_12cb7f6811c2",
        "power_net_33746b374e79",
        "power_net_cb68ff534fc3",
        "power_net_30a587454a9d",
        "power_net_55db14645113"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2206",
          "pin": "2",
          "netId": "power_net_563d73fc35e8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "1",
          "netId": "power_net_563d73fc35e8",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "3",
          "netId": "power_net_646f65822b1f",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "4",
          "netId": "power_net_77d673a9c74f",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2208",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2201",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2206",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2203",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "4",
          "netId": "power_net_12cb7f6811c2",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2203",
          "pin": "2",
          "netId": "power_net_12cb7f6811c2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2201",
          "pin": "2",
          "netId": "power_net_33746b374e79",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "1",
          "netId": "power_net_33746b374e79",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2208",
          "pin": "2",
          "netId": "power_net_30a587454a9d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "1",
          "netId": "power_net_30a587454a9d",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "3",
          "netId": "power_net_55db14645113",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Отрицательная шина подключается",
      "text": "Силовые транзисторы соединяют или изолируют отрицательный источник с программирующим выходом.",
      "body": "Силовые транзисторы соединяют или изолируют отрицательный источник с программирующим выходом.",
      "nodes": [
        "control",
        "switch"
      ],
      "edges": [
        "switch_control"
      ],
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "netIds": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2204",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "3",
          "netId": "power_net_646f65822b1f",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2204",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "3",
          "netId": "power_net_55db14645113",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2203",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2209",
          "pin": "2",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "4",
          "netId": "power_net_77d673a9c74f",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Ограничиваются затворные напряжения",
      "text": "Диодная сеть образует предусмотренные схемой защитные и ограничивающие пути. Их точные подключения видны на фрагменте схемотехники.",
      "body": "Диодная сеть образует предусмотренные схемой защитные и ограничивающие пути. Их точные подключения видны на фрагменте схемотехники.",
      "nodes": [
        "clamp",
        "switch"
      ],
      "edges": [
        "switch_clamp"
      ],
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "netIds": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2204",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2201",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2203",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2201",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2204",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2204",
          "pin": "2",
          "netId": "power_net_55db14645113",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2203",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2209",
          "pin": "2",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2203",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2207",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Команда переходит в отрицательный домен",
      "text": "Оптопары передают управляющие запросы к схеме отрицательной программирующей шины.",
      "body": "Оптопары передают управляющие запросы к схеме отрицательной программирующей шины.",
      "nodes": [
        "control"
      ],
      "edges": [],
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "netIds": [
        "power_net_563d73fc35e8",
        "power_net_46ab17b8adeb",
        "power_net_646f65822b1f",
        "power_net_77d673a9c74f",
        "power_net_67006db669b3",
        "power_net_12cb7f6811c2",
        "power_net_33746b374e79",
        "power_net_cb68ff534fc3",
        "power_net_30a587454a9d",
        "power_net_55db14645113"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2206",
          "pin": "2",
          "netId": "power_net_563d73fc35e8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "1",
          "netId": "power_net_563d73fc35e8",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "2",
          "netId": "power_net_46ab17b8adeb",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "3",
          "netId": "power_net_646f65822b1f",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "4",
          "netId": "power_net_77d673a9c74f",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2208",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2201",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2206",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2203",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "4",
          "netId": "power_net_12cb7f6811c2",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2203",
          "pin": "2",
          "netId": "power_net_12cb7f6811c2",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2201",
          "pin": "2",
          "netId": "power_net_33746b374e79",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "1",
          "netId": "power_net_33746b374e79",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2208",
          "pin": "2",
          "netId": "power_net_30a587454a9d",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "1",
          "netId": "power_net_30a587454a9d",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "3",
          "netId": "power_net_55db14645113",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Отрицательная шина подключается",
      "text": "Силовые транзисторы соединяют или изолируют отрицательный источник с программирующим выходом.",
      "body": "Силовые транзисторы соединяют или изолируют отрицательный источник с программирующим выходом.",
      "nodes": [
        "control",
        "switch"
      ],
      "edges": [
        "switch_control"
      ],
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "netIds": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2201",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2204",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "3",
          "netId": "power_net_646f65822b1f",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2204",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2203",
          "pin": "3",
          "netId": "power_net_55db14645113",
          "name": "E",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2203",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2209",
          "pin": "2",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2202",
          "pin": "4",
          "netId": "power_net_77d673a9c74f",
          "name": "C",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Ограничиваются затворные напряжения",
      "text": "Диодная сеть образует предусмотренные схемой защитные и ограничивающие пути. Их точные подключения видны на фрагменте схемотехники.",
      "body": "Диодная сеть образует предусмотренные схемой защитные и ограничивающие пути. Их точные подключения видны на фрагменте схемотехники.",
      "nodes": [
        "clamp",
        "switch"
      ],
      "edges": [
        "switch_clamp"
      ],
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "netIds": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2204",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2201",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "3",
          "netId": "power_net_cb68ff534fc3",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "1",
          "netId": "power_net_cb68ff534fc3",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2203",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2201",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2201",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2202",
          "pin": "2",
          "netId": "power_net_646f65822b1f",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2204",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2204",
          "pin": "2",
          "netId": "power_net_55db14645113",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2203",
          "pin": "1",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2209",
          "pin": "2",
          "netId": "power_net_55db14645113",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2203",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2207",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q2203",
          "pin": "1",
          "netId": "power_net_77d673a9c74f",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
