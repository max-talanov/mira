/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_2500_PM_WATCHDOGS",
  "title": "Как работает: Сторожевой контроль контроллеров",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_2500_PM_WATCHDOGS",
  "steps": [
    {
      "title": "Контроллеры выдают признаки активности",
      "text": "Отдельные watchdog следят за диспетчером питания и хостом. Это два самостоятельных канала наблюдения.",
      "body": "Отдельные watchdog следят за диспетчером питания и хостом. Это два самостоятельных канала наблюдения.",
      "nodes": [
        "pm",
        "host"
      ],
      "edges": [],
      "sceneId": "power_2500_PM_WATCHDOGS",
      "netIds": [
        "power_net_1e4739bcc8aa",
        "power_net_e7486b382586",
        "power_net_0418bd5d299f",
        "power_net_86751620b7fb",
        "power_net_67006db669b3",
        "power_net_35a895f0e023",
        "power_net_62071cc6daac",
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_b4c478ffb022",
        "power_net_35aa4cb845bd",
        "power_net_6ce2d2b05bfc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2506",
          "pin": "1",
          "netId": "power_net_1e4739bcc8aa",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "3",
          "netId": "power_net_1e4739bcc8aa",
          "name": "MR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2502",
          "pin": "2",
          "netId": "power_net_1e4739bcc8aa",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2506",
          "pin": "2",
          "netId": "power_net_e7486b382586",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "1",
          "netId": "power_net_e7486b382586",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "5",
          "netId": "power_net_e7486b382586",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2503",
          "pin": "1",
          "netId": "power_net_e7486b382586",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2507",
          "pin": "1",
          "netId": "power_net_0418bd5d299f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "6",
          "netId": "power_net_0418bd5d299f",
          "name": "WDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "7",
          "netId": "power_net_86751620b7fb",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2508",
          "pin": "1",
          "netId": "power_net_86751620b7fb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2504",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2503",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2509",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2501",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2508",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "3",
          "netId": "power_net_35a895f0e023",
          "name": "MR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2501",
          "pin": "1",
          "netId": "power_net_35a895f0e023",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2501",
          "pin": "2",
          "netId": "power_net_35a895f0e023",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "2",
          "netId": "power_net_62071cc6daac",
          "name": "CWD",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2502",
          "pin": "1",
          "netId": "power_net_55a52205aaf0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "6",
          "netId": "power_net_55a52205aaf0",
          "name": "WDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2503",
          "pin": "1",
          "netId": "power_net_47577a24d67e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "7",
          "netId": "power_net_47577a24d67e",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2504",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "8",
          "netId": "power_net_b4c478ffb022",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "8",
          "netId": "power_net_35aa4cb845bd",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2509",
          "pin": "1",
          "netId": "power_net_35aa4cb845bd",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "2",
          "netId": "power_net_6ce2d2b05bfc",
          "name": "CWD",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Потеря активности вызывает сброс",
      "text": "Соответствующий watchdog связан со своим трактом сброса. Допустимые интервалы определяются настройками микросхем и программой.",
      "body": "Соответствующий watchdog связан со своим трактом сброса. Допустимые интервалы определяются настройками микросхем и программой.",
      "nodes": [
        "pm",
        "host",
        "reset"
      ],
      "edges": [
        "pm_reset"
      ],
      "sceneId": "power_2500_PM_WATCHDOGS",
      "netIds": [
        "power_net_b4c478ffb022",
        "power_net_47577a24d67e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2504",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "8",
          "netId": "power_net_b4c478ffb022",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "K1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2503",
          "pin": "1",
          "netId": "power_net_47577a24d67e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "7",
          "netId": "power_net_47577a24d67e",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запросы сброса объединяются",
      "text": "Диодная и резистивная сеть объединяет показанные источники сброса. Подсветка показывает реальные соединения без выдуманных логических уровней.",
      "body": "Диодная и резистивная сеть объединяет показанные источники сброса. Подсветка показывает реальные соединения без выдуманных логических уровней.",
      "nodes": [
        "reset"
      ],
      "edges": [],
      "sceneId": "power_2500_PM_WATCHDOGS",
      "netIds": [
        "power_net_2cbf74589b12",
        "power_net_67006db669b3",
        "power_net_b4c478ffb022",
        "power_net_47577a24d67e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2505",
          "pin": "1",
          "netId": "power_net_2cbf74589b12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "3",
          "netId": "power_net_2cbf74589b12",
          "name": "A1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2502",
          "pin": "1",
          "netId": "power_net_2cbf74589b12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2505",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "K1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Контроллеры выдают признаки активности",
      "text": "Отдельные watchdog следят за диспетчером питания и хостом. Это два самостоятельных канала наблюдения.",
      "body": "Отдельные watchdog следят за диспетчером питания и хостом. Это два самостоятельных канала наблюдения.",
      "nodes": [
        "pm",
        "host"
      ],
      "edges": [],
      "sceneId": "power_2500_PM_WATCHDOGS",
      "netIds": [
        "power_net_1e4739bcc8aa",
        "power_net_e7486b382586",
        "power_net_0418bd5d299f",
        "power_net_86751620b7fb",
        "power_net_67006db669b3",
        "power_net_35a895f0e023",
        "power_net_62071cc6daac",
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_b4c478ffb022",
        "power_net_35aa4cb845bd",
        "power_net_6ce2d2b05bfc"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2506",
          "pin": "1",
          "netId": "power_net_1e4739bcc8aa",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "3",
          "netId": "power_net_1e4739bcc8aa",
          "name": "MR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2502",
          "pin": "2",
          "netId": "power_net_1e4739bcc8aa",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2506",
          "pin": "2",
          "netId": "power_net_e7486b382586",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "1",
          "netId": "power_net_e7486b382586",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "5",
          "netId": "power_net_e7486b382586",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2503",
          "pin": "1",
          "netId": "power_net_e7486b382586",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2507",
          "pin": "1",
          "netId": "power_net_0418bd5d299f",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "6",
          "netId": "power_net_0418bd5d299f",
          "name": "WDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "7",
          "netId": "power_net_86751620b7fb",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2508",
          "pin": "1",
          "netId": "power_net_86751620b7fb",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2504",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2503",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "5",
          "netId": "power_net_67006db669b3",
          "name": "SET1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2509",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2501",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2508",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "3",
          "netId": "power_net_35a895f0e023",
          "name": "MR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2501",
          "pin": "1",
          "netId": "power_net_35a895f0e023",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2501",
          "pin": "2",
          "netId": "power_net_35a895f0e023",
          "name": "Pin_2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "2",
          "netId": "power_net_62071cc6daac",
          "name": "CWD",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2502",
          "pin": "1",
          "netId": "power_net_55a52205aaf0",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "6",
          "netId": "power_net_55a52205aaf0",
          "name": "WDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2503",
          "pin": "1",
          "netId": "power_net_47577a24d67e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "7",
          "netId": "power_net_47577a24d67e",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2504",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "8",
          "netId": "power_net_b4c478ffb022",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "8",
          "netId": "power_net_35aa4cb845bd",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2509",
          "pin": "1",
          "netId": "power_net_35aa4cb845bd",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "2",
          "netId": "power_net_6ce2d2b05bfc",
          "name": "CWD",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Потеря активности вызывает сброс",
      "text": "Соответствующий watchdog связан со своим трактом сброса. Допустимые интервалы определяются настройками микросхем и программой.",
      "body": "Соответствующий watchdog связан со своим трактом сброса. Допустимые интервалы определяются настройками микросхем и программой.",
      "nodes": [
        "pm",
        "host",
        "reset"
      ],
      "edges": [
        "pm_reset"
      ],
      "sceneId": "power_2500_PM_WATCHDOGS",
      "netIds": [
        "power_net_b4c478ffb022",
        "power_net_47577a24d67e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2504",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "8",
          "netId": "power_net_b4c478ffb022",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "K1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2503",
          "pin": "1",
          "netId": "power_net_47577a24d67e",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "7",
          "netId": "power_net_47577a24d67e",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запросы сброса объединяются",
      "text": "Диодная и резистивная сеть объединяет показанные источники сброса. Подсветка показывает реальные соединения без выдуманных логических уровней.",
      "body": "Диодная и резистивная сеть объединяет показанные источники сброса. Подсветка показывает реальные соединения без выдуманных логических уровней.",
      "nodes": [
        "reset"
      ],
      "edges": [],
      "sceneId": "power_2500_PM_WATCHDOGS",
      "netIds": [
        "power_net_2cbf74589b12",
        "power_net_67006db669b3",
        "power_net_b4c478ffb022",
        "power_net_47577a24d67e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R2505",
          "pin": "1",
          "netId": "power_net_2cbf74589b12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "3",
          "netId": "power_net_2cbf74589b12",
          "name": "A1/A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C2502",
          "pin": "1",
          "netId": "power_net_2cbf74589b12",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R2505",
          "pin": "2",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "K1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D2501",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "K2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
