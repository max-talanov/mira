/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_600_FPGA_CONFIGURATION_AND_XADC",
  "title": "Как работает: Загрузка и восстановление ПЛИС",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
  "steps": [
    {
      "title": "Появляются условия загрузки",
      "text": "После установления питания схема конфигурации использует локальную Flash как источник битового потока. Учебный порядок не задаёт временные интервалы запуска.",
      "body": "После установления питания схема конфигурации использует локальную Flash как источник битового потока. Учебный порядок не задаёт временные интервалы запуска.",
      "nodes": [
        "flash",
        "fpga"
      ],
      "edges": [
        "flash_fpga_0"
      ],
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "netIds": [
        "control_net_52c8c7557923",
        "control_net_834296c71f70",
        "control_net_3591ba357658",
        "control_net_6bc6649476ec",
        "control_net_9e71347ab99c",
        "control_net_92af7290af48"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R601",
          "pin": "2",
          "netId": "control_net_52c8c7557923",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "1",
          "netId": "control_net_52c8c7557923",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R602",
          "pin": "1",
          "netId": "control_net_834296c71f70",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "7",
          "netId": "control_net_834296c71f70",
          "name": "IO3_HOLD_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R606",
          "pin": "1",
          "netId": "control_net_3591ba357658",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "3",
          "netId": "control_net_3591ba357658",
          "name": "IO2_WP_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L12",
          "netId": "control_net_6bc6649476ec",
          "name": "CCLK_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "6",
          "netId": "control_net_6bc6649476ec",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "2",
          "netId": "control_net_9e71347ab99c",
          "name": "IO1_DO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "5",
          "netId": "control_net_92af7290af48",
          "name": "IO0_DI",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "ПЛИС получает конфигурацию",
      "text": "Линии FPGA_CFG соединяют Flash и конфигурационную секцию U500. INIT и DONE относятся к процессу конфигурации, а не к готовности всей программы эксперимента.",
      "body": "Линии FPGA_CFG соединяют Flash и конфигурационную секцию U500. INIT и DONE относятся к процессу конфигурации, а не к готовности всей программы эксперимента.",
      "nodes": [
        "flash",
        "fpga"
      ],
      "edges": [
        "flash_fpga_0"
      ],
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "netIds": [
        "control_net_52c8c7557923",
        "control_net_834296c71f70",
        "control_net_3591ba357658",
        "control_net_6bc6649476ec",
        "control_net_9e71347ab99c",
        "control_net_92af7290af48"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R601",
          "pin": "2",
          "netId": "control_net_52c8c7557923",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "1",
          "netId": "control_net_52c8c7557923",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R602",
          "pin": "1",
          "netId": "control_net_834296c71f70",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "7",
          "netId": "control_net_834296c71f70",
          "name": "IO3_HOLD_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R606",
          "pin": "1",
          "netId": "control_net_3591ba357658",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "3",
          "netId": "control_net_3591ba357658",
          "name": "IO2_WP_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L12",
          "netId": "control_net_6bc6649476ec",
          "name": "CCLK_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "6",
          "netId": "control_net_6bc6649476ec",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "2",
          "netId": "control_net_9e71347ab99c",
          "name": "IO1_DO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "5",
          "netId": "control_net_92af7290af48",
          "name": "IO0_DI",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Можно запросить повторную загрузку",
      "text": "Кнопка или буфер команды STM32 воздействуют на FPGA_PROGRAM_N. Этот запрос перезапускает конфигурацию; JTAG обеспечивает отдельный путь программирования и восстановления.",
      "body": "Кнопка или буфер команды STM32 воздействуют на FPGA_PROGRAM_N. Этот запрос перезапускает конфигурацию; JTAG обеспечивает отдельный путь программирования и восстановления.",
      "nodes": [
        "recover",
        "jtag",
        "fpga"
      ],
      "edges": [
        "jtag_fpga_1",
        "recover_fpga_2"
      ],
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "netIds": [
        "control_net_ba92e944f30f",
        "control_net_0b94eea9a209",
        "control_net_c251169eb896",
        "control_net_61b4ba86f12f",
        "control_net_4701afd22aa9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J600",
          "pin": "3",
          "netId": "control_net_ba92e944f30f",
          "name": "FPGA_JTAG_TCK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V12",
          "netId": "control_net_ba92e944f30f",
          "name": "TCK_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J600",
          "pin": "4",
          "netId": "control_net_0b94eea9a209",
          "name": "FPGA_JTAG_TMS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T13",
          "netId": "control_net_0b94eea9a209",
          "name": "TMS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J600",
          "pin": "5",
          "netId": "control_net_c251169eb896",
          "name": "FPGA_JTAG_TDI",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R13",
          "netId": "control_net_c251169eb896",
          "name": "TDI_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J600",
          "pin": "6",
          "netId": "control_net_61b4ba86f12f",
          "name": "FPGA_JTAG_TDO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U13",
          "netId": "control_net_61b4ba86f12f",
          "name": "TDO_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U601",
          "pin": "4",
          "netId": "control_net_4701afd22aa9",
          "name": "Y_OD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_SW600",
          "pin": "1",
          "netId": "control_net_4701afd22aa9",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R605",
          "pin": "1",
          "netId": "control_net_4701afd22aa9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N12",
          "netId": "control_net_4701afd22aa9",
          "name": "PROGRAM_B_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Появляются условия загрузки",
      "text": "После установления питания схема конфигурации использует локальную Flash как источник битового потока. Учебный порядок не задаёт временные интервалы запуска.",
      "body": "После установления питания схема конфигурации использует локальную Flash как источник битового потока. Учебный порядок не задаёт временные интервалы запуска.",
      "nodes": [
        "flash",
        "fpga"
      ],
      "edges": [
        "flash_fpga_0"
      ],
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "netIds": [
        "control_net_52c8c7557923",
        "control_net_834296c71f70",
        "control_net_3591ba357658",
        "control_net_6bc6649476ec",
        "control_net_9e71347ab99c",
        "control_net_92af7290af48"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R601",
          "pin": "2",
          "netId": "control_net_52c8c7557923",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "1",
          "netId": "control_net_52c8c7557923",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R602",
          "pin": "1",
          "netId": "control_net_834296c71f70",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "7",
          "netId": "control_net_834296c71f70",
          "name": "IO3_HOLD_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R606",
          "pin": "1",
          "netId": "control_net_3591ba357658",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "3",
          "netId": "control_net_3591ba357658",
          "name": "IO2_WP_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L12",
          "netId": "control_net_6bc6649476ec",
          "name": "CCLK_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "6",
          "netId": "control_net_6bc6649476ec",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "2",
          "netId": "control_net_9e71347ab99c",
          "name": "IO1_DO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "5",
          "netId": "control_net_92af7290af48",
          "name": "IO0_DI",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "ПЛИС получает конфигурацию",
      "text": "Линии FPGA_CFG соединяют Flash и конфигурационную секцию U500. INIT и DONE относятся к процессу конфигурации, а не к готовности всей программы эксперимента.",
      "body": "Линии FPGA_CFG соединяют Flash и конфигурационную секцию U500. INIT и DONE относятся к процессу конфигурации, а не к готовности всей программы эксперимента.",
      "nodes": [
        "flash",
        "fpga"
      ],
      "edges": [
        "flash_fpga_0"
      ],
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "netIds": [
        "control_net_52c8c7557923",
        "control_net_834296c71f70",
        "control_net_3591ba357658",
        "control_net_6bc6649476ec",
        "control_net_9e71347ab99c",
        "control_net_92af7290af48"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R601",
          "pin": "2",
          "netId": "control_net_52c8c7557923",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "1",
          "netId": "control_net_52c8c7557923",
          "name": "CS_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R602",
          "pin": "1",
          "netId": "control_net_834296c71f70",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "7",
          "netId": "control_net_834296c71f70",
          "name": "IO3_HOLD_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R606",
          "pin": "1",
          "netId": "control_net_3591ba357658",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "3",
          "netId": "control_net_3591ba357658",
          "name": "IO2_WP_N",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L12",
          "netId": "control_net_6bc6649476ec",
          "name": "CCLK_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "6",
          "netId": "control_net_6bc6649476ec",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "2",
          "netId": "control_net_9e71347ab99c",
          "name": "IO1_DO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U600",
          "pin": "5",
          "netId": "control_net_92af7290af48",
          "name": "IO0_DI",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Можно запросить повторную загрузку",
      "text": "Кнопка или буфер команды STM32 воздействуют на FPGA_PROGRAM_N. Этот запрос перезапускает конфигурацию; JTAG обеспечивает отдельный путь программирования и восстановления.",
      "body": "Кнопка или буфер команды STM32 воздействуют на FPGA_PROGRAM_N. Этот запрос перезапускает конфигурацию; JTAG обеспечивает отдельный путь программирования и восстановления.",
      "nodes": [
        "recover",
        "jtag",
        "fpga"
      ],
      "edges": [
        "jtag_fpga_1",
        "recover_fpga_2"
      ],
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "netIds": [
        "control_net_ba92e944f30f",
        "control_net_0b94eea9a209",
        "control_net_c251169eb896",
        "control_net_61b4ba86f12f",
        "control_net_4701afd22aa9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_J600",
          "pin": "3",
          "netId": "control_net_ba92e944f30f",
          "name": "FPGA_JTAG_TCK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V12",
          "netId": "control_net_ba92e944f30f",
          "name": "TCK_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J600",
          "pin": "4",
          "netId": "control_net_0b94eea9a209",
          "name": "FPGA_JTAG_TMS",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T13",
          "netId": "control_net_0b94eea9a209",
          "name": "TMS_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J600",
          "pin": "5",
          "netId": "control_net_c251169eb896",
          "name": "FPGA_JTAG_TDI",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R13",
          "netId": "control_net_c251169eb896",
          "name": "TDI_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J600",
          "pin": "6",
          "netId": "control_net_61b4ba86f12f",
          "name": "FPGA_JTAG_TDO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U13",
          "netId": "control_net_61b4ba86f12f",
          "name": "TDO_0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U601",
          "pin": "4",
          "netId": "control_net_4701afd22aa9",
          "name": "Y_OD",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_SW600",
          "pin": "1",
          "netId": "control_net_4701afd22aa9",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R605",
          "pin": "1",
          "netId": "control_net_4701afd22aa9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "N12",
          "netId": "control_net_4701afd22aa9",
          "name": "PROGRAM_B_0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
