/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power-monitoring",
  "title": "Как работает: Контроль всех ветвей питания",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power-monitoring",
  "steps": [
    {
      "title": "Измерение отрицательной шины",
      "text": "U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току. Связь с соседним узлом показана цепями MON_I_N15, MON_V_N15.",
      "body": "U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току. Связь с соседним узлом показана цепями MON_I_N15, MON_V_N15.",
      "nodes": [
        "sheet3400",
        "sheet3900"
      ],
      "edges": [
        "sheet3400_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_9ac6d4c8f874",
        "power_net_de6034a2bdb7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3901",
          "pin": "2",
          "netId": "power_net_9ac6d4c8f874",
          "name": "CH7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "CH7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль входа и системного питания",
      "text": "U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "body": "U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "nodes": [
        "sheet3500",
        "sheet3900"
      ],
      "edges": [
        "sheet3500_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_d2e17a0e1422",
        "power_net_df57fc034b72",
        "power_net_ca640db2f885",
        "power_net_e14830d3e0bb",
        "power_net_0673bddb62dd",
        "power_net_80ed0592af12",
        "power_net_217501fd4a1b",
        "power_net_8165c7e0e80c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "6",
          "netId": "power_net_d2e17a0e1422",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "8",
          "netId": "power_net_df57fc034b72",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "7",
          "netId": "power_net_ca640db2f885",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "9",
          "netId": "power_net_e14830d3e0bb",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "7",
          "netId": "power_net_0673bddb62dd",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "9",
          "netId": "power_net_80ed0592af12",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "8",
          "netId": "power_net_217501fd4a1b",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "6",
          "netId": "power_net_8165c7e0e80c",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль ПЛИС и аналогового питания",
      "text": "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE. Связь с соседним узлом показана цепями MON_V_FPGA, MON_V_P15, MON_V_ANA6, MON_I_ANA6.",
      "body": "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE. Связь с соседним узлом показана цепями MON_V_FPGA, MON_V_P15, MON_V_ANA6, MON_I_ANA6.",
      "nodes": [
        "sheet3600",
        "sheet3900"
      ],
      "edges": [
        "sheet3600_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_b8182397a510",
        "power_net_68f62ae4eb87",
        "power_net_710c162550a1",
        "power_net_5c97037182dc",
        "power_net_0b315650a930",
        "power_net_324fb6a46e24"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "5",
          "netId": "power_net_b8182397a510",
          "name": "CH4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "3",
          "netId": "power_net_68f62ae4eb87",
          "name": "CH6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "4",
          "netId": "power_net_710c162550a1",
          "name": "CH5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "4",
          "netId": "power_net_5c97037182dc",
          "name": "CH5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "3",
          "netId": "power_net_0b315650a930",
          "name": "CH6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "5",
          "netId": "power_net_324fb6a46e24",
          "name": "CH4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль питания ядра и выводов ПЛИС",
      "text": "U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС. Связь с соседним узлом показана цепями MON_V_IO33, MON_I_AUX25, MON_I_IO33, MON_I_AUX18.",
      "body": "U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС. Связь с соседним узлом показана цепями MON_V_IO33, MON_I_AUX25, MON_I_IO33, MON_I_AUX18.",
      "nodes": [
        "sheet3700",
        "sheet3900"
      ],
      "edges": [
        "sheet3700_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_06b222f621c5",
        "power_net_56f70873fed6",
        "power_net_0937e82a0391",
        "power_net_747203f7ea20",
        "power_net_006931c58e47",
        "power_net_92a8731620d4",
        "power_net_072a5b0d730e",
        "power_net_493e78469ebd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "20",
          "netId": "power_net_06b222f621c5",
          "name": "CH11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "21",
          "netId": "power_net_56f70873fed6",
          "name": "CH10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "20",
          "netId": "power_net_0937e82a0391",
          "name": "CH11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "22",
          "netId": "power_net_747203f7ea20",
          "name": "CH9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "23",
          "netId": "power_net_006931c58e47",
          "name": "CH8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "22",
          "netId": "power_net_92a8731620d4",
          "name": "CH9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "23",
          "netId": "power_net_072a5b0d730e",
          "name": "CH8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "21",
          "netId": "power_net_493e78469ebd",
          "name": "CH10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль памяти, PHY и аналоговых шин",
      "text": "U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины. Связь с соседним узлом показана цепями MON_V_ANA33, MON_I_PHY, MON_V_DDR, MON_I_ANA33.",
      "body": "U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины. Связь с соседним узлом показана цепями MON_V_ANA33, MON_I_PHY, MON_V_DDR, MON_I_ANA33.",
      "nodes": [
        "sheet3800",
        "sheet3900"
      ],
      "edges": [
        "sheet3800_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_01417a8fa2e7",
        "power_net_bb20ea345245",
        "power_net_071bab851593",
        "power_net_a632dd3fa2a2",
        "power_net_84769727a28d",
        "power_net_c5bc442d624e",
        "power_net_2f3224d5b90a",
        "power_net_223314db53b0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "16",
          "netId": "power_net_01417a8fa2e7",
          "name": "CH15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "18",
          "netId": "power_net_bb20ea345245",
          "name": "CH13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "19",
          "netId": "power_net_071bab851593",
          "name": "CH12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "16",
          "netId": "power_net_a632dd3fa2a2",
          "name": "CH15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "17",
          "netId": "power_net_84769727a28d",
          "name": "CH14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "18",
          "netId": "power_net_c5bc442d624e",
          "name": "CH13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "19",
          "netId": "power_net_2f3224d5b90a",
          "name": "CH12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "17",
          "netId": "power_net_223314db53b0",
          "name": "CH14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбор измеряемой шины",
      "text": "U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "body": "U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "nodes": [
        "sheet3900",
        "sheet3500"
      ],
      "edges": [
        "sheet3500_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_d2e17a0e1422",
        "power_net_df57fc034b72",
        "power_net_ca640db2f885",
        "power_net_e14830d3e0bb",
        "power_net_0673bddb62dd",
        "power_net_80ed0592af12",
        "power_net_217501fd4a1b",
        "power_net_8165c7e0e80c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "6",
          "netId": "power_net_d2e17a0e1422",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "8",
          "netId": "power_net_df57fc034b72",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "7",
          "netId": "power_net_ca640db2f885",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "9",
          "netId": "power_net_e14830d3e0bb",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "7",
          "netId": "power_net_0673bddb62dd",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "9",
          "netId": "power_net_80ed0592af12",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "8",
          "netId": "power_net_217501fd4a1b",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "6",
          "netId": "power_net_8165c7e0e80c",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Буферы измерений для контроллера",
      "text": "U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания. Связь с соседним узлом показана цепями MUX_A1, MUX_A0, MUX_DISABLE, MUX_A2.",
      "body": "U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания. Связь с соседним узлом показана цепями MUX_A1, MUX_A0, MUX_DISABLE, MUX_A2.",
      "nodes": [
        "sheet4000",
        "sheet3900"
      ],
      "edges": [
        "sheet3900_sheet4000"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_97db96dcc04b",
        "power_net_b8fd52d3ecf7",
        "power_net_b5187ab6f19a",
        "power_net_2074a83eb788",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_7071622db9df"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "3",
          "netId": "power_net_882de840965a",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "1",
          "netId": "power_net_882de840965a",
          "name": "COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "5",
          "netId": "power_net_e4e50653a8a5",
          "name": "IN+_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "1",
          "netId": "power_net_e4e50653a8a5",
          "name": "COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Измерение отрицательной шины",
      "text": "U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току. Связь с соседним узлом показана цепями MON_I_N15, MON_V_N15.",
      "body": "U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току. Связь с соседним узлом показана цепями MON_I_N15, MON_V_N15.",
      "nodes": [
        "sheet3400",
        "sheet3900"
      ],
      "edges": [
        "sheet3400_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_9ac6d4c8f874",
        "power_net_de6034a2bdb7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3901",
          "pin": "2",
          "netId": "power_net_9ac6d4c8f874",
          "name": "CH7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "2",
          "netId": "power_net_de6034a2bdb7",
          "name": "CH7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль входа и системного питания",
      "text": "U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "body": "U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "nodes": [
        "sheet3500",
        "sheet3900"
      ],
      "edges": [
        "sheet3500_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_d2e17a0e1422",
        "power_net_df57fc034b72",
        "power_net_ca640db2f885",
        "power_net_e14830d3e0bb",
        "power_net_0673bddb62dd",
        "power_net_80ed0592af12",
        "power_net_217501fd4a1b",
        "power_net_8165c7e0e80c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "6",
          "netId": "power_net_d2e17a0e1422",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "8",
          "netId": "power_net_df57fc034b72",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "7",
          "netId": "power_net_ca640db2f885",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "9",
          "netId": "power_net_e14830d3e0bb",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "7",
          "netId": "power_net_0673bddb62dd",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "9",
          "netId": "power_net_80ed0592af12",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "8",
          "netId": "power_net_217501fd4a1b",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "6",
          "netId": "power_net_8165c7e0e80c",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль ПЛИС и аналогового питания",
      "text": "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE. Связь с соседним узлом показана цепями MON_V_FPGA, MON_V_P15, MON_V_ANA6, MON_I_ANA6.",
      "body": "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE. Связь с соседним узлом показана цепями MON_V_FPGA, MON_V_P15, MON_V_ANA6, MON_I_ANA6.",
      "nodes": [
        "sheet3600",
        "sheet3900"
      ],
      "edges": [
        "sheet3600_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_b8182397a510",
        "power_net_68f62ae4eb87",
        "power_net_710c162550a1",
        "power_net_5c97037182dc",
        "power_net_0b315650a930",
        "power_net_324fb6a46e24"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "5",
          "netId": "power_net_b8182397a510",
          "name": "CH4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "3",
          "netId": "power_net_68f62ae4eb87",
          "name": "CH6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "4",
          "netId": "power_net_710c162550a1",
          "name": "CH5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "4",
          "netId": "power_net_5c97037182dc",
          "name": "CH5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "3",
          "netId": "power_net_0b315650a930",
          "name": "CH6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "5",
          "netId": "power_net_324fb6a46e24",
          "name": "CH4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль питания ядра и выводов ПЛИС",
      "text": "U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС. Связь с соседним узлом показана цепями MON_V_IO33, MON_I_AUX25, MON_I_IO33, MON_I_AUX18.",
      "body": "U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС. Связь с соседним узлом показана цепями MON_V_IO33, MON_I_AUX25, MON_I_IO33, MON_I_AUX18.",
      "nodes": [
        "sheet3700",
        "sheet3900"
      ],
      "edges": [
        "sheet3700_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_06b222f621c5",
        "power_net_56f70873fed6",
        "power_net_0937e82a0391",
        "power_net_747203f7ea20",
        "power_net_006931c58e47",
        "power_net_92a8731620d4",
        "power_net_072a5b0d730e",
        "power_net_493e78469ebd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "20",
          "netId": "power_net_06b222f621c5",
          "name": "CH11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "21",
          "netId": "power_net_56f70873fed6",
          "name": "CH10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "20",
          "netId": "power_net_0937e82a0391",
          "name": "CH11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "22",
          "netId": "power_net_747203f7ea20",
          "name": "CH9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "23",
          "netId": "power_net_006931c58e47",
          "name": "CH8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "22",
          "netId": "power_net_92a8731620d4",
          "name": "CH9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "23",
          "netId": "power_net_072a5b0d730e",
          "name": "CH8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "21",
          "netId": "power_net_493e78469ebd",
          "name": "CH10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроль памяти, PHY и аналоговых шин",
      "text": "U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины. Связь с соседним узлом показана цепями MON_V_ANA33, MON_I_PHY, MON_V_DDR, MON_I_ANA33.",
      "body": "U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины. Связь с соседним узлом показана цепями MON_V_ANA33, MON_I_PHY, MON_V_DDR, MON_I_ANA33.",
      "nodes": [
        "sheet3800",
        "sheet3900"
      ],
      "edges": [
        "sheet3800_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_01417a8fa2e7",
        "power_net_bb20ea345245",
        "power_net_071bab851593",
        "power_net_a632dd3fa2a2",
        "power_net_84769727a28d",
        "power_net_c5bc442d624e",
        "power_net_2f3224d5b90a",
        "power_net_223314db53b0"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "16",
          "netId": "power_net_01417a8fa2e7",
          "name": "CH15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "18",
          "netId": "power_net_bb20ea345245",
          "name": "CH13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "19",
          "netId": "power_net_071bab851593",
          "name": "CH12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "16",
          "netId": "power_net_a632dd3fa2a2",
          "name": "CH15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "17",
          "netId": "power_net_84769727a28d",
          "name": "CH14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "18",
          "netId": "power_net_c5bc442d624e",
          "name": "CH13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "19",
          "netId": "power_net_2f3224d5b90a",
          "name": "CH12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "17",
          "netId": "power_net_223314db53b0",
          "name": "CH14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбор измеряемой шины",
      "text": "U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "body": "U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания. Связь с соседним узлом показана цепями MON_V_SYS, MON_V_AON, MON_I_USB, MON_I_INPUT.",
      "nodes": [
        "sheet3900",
        "sheet3500"
      ],
      "edges": [
        "sheet3500_sheet3900"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_d2e17a0e1422",
        "power_net_df57fc034b72",
        "power_net_ca640db2f885",
        "power_net_e14830d3e0bb",
        "power_net_0673bddb62dd",
        "power_net_80ed0592af12",
        "power_net_217501fd4a1b",
        "power_net_8165c7e0e80c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "6",
          "netId": "power_net_d2e17a0e1422",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "8",
          "netId": "power_net_df57fc034b72",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "7",
          "netId": "power_net_ca640db2f885",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "9",
          "netId": "power_net_e14830d3e0bb",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "7",
          "netId": "power_net_0673bddb62dd",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "9",
          "netId": "power_net_80ed0592af12",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "8",
          "netId": "power_net_217501fd4a1b",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "6",
          "netId": "power_net_8165c7e0e80c",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Буферы измерений для контроллера",
      "text": "U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания. Связь с соседним узлом показана цепями MUX_A1, MUX_A0, MUX_DISABLE, MUX_A2.",
      "body": "U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания. Связь с соседним узлом показана цепями MUX_A1, MUX_A0, MUX_DISABLE, MUX_A2.",
      "nodes": [
        "sheet4000",
        "sheet3900"
      ],
      "edges": [
        "sheet3900_sheet4000"
      ],
      "sceneId": "power-monitoring",
      "netIds": [
        "power_net_97db96dcc04b",
        "power_net_b8fd52d3ecf7",
        "power_net_b5187ab6f19a",
        "power_net_2074a83eb788",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_7071622db9df"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "3",
          "netId": "power_net_882de840965a",
          "name": "IN+_A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "1",
          "netId": "power_net_882de840965a",
          "name": "COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U4001",
          "pin": "5",
          "netId": "power_net_e4e50653a8a5",
          "name": "IN+_B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "1",
          "netId": "power_net_e4e50653a8a5",
          "name": "COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
