/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_3900_TELEMETRY_MULTIPLEXERS",
  "title": "Как работает: Выбор измеряемой шины",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
  "steps": [
    {
      "title": "Выбирается номер ветви",
      "text": "Общие адресные цепи задают соответствующие входы селекторов тока и напряжения.",
      "body": "Общие адресные цепи задают соответствующие входы селекторов тока и напряжения.",
      "nodes": [
        "current",
        "voltage"
      ],
      "edges": [
        "current_voltage"
      ],
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "netIds": [
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подключается выбранный ток",
      "text": "16-канальный селектор передаёт один сигнал измерения тока в общий тракт. Остальные входы продолжают существовать, но не являются выбранным выходом.",
      "body": "16-канальный селектор передаёт один сигнал измерения тока в общий тракт. Остальные входы продолжают существовать, но не являются выбранным выходом.",
      "nodes": [
        "current"
      ],
      "edges": [],
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "netIds": [
        "power_net_882de840965a",
        "power_net_9ac6d4c8f874",
        "power_net_0b315650a930",
        "power_net_5c97037182dc",
        "power_net_324fb6a46e24",
        "power_net_8165c7e0e80c",
        "power_net_ca640db2f885",
        "power_net_217501fd4a1b",
        "power_net_e14830d3e0bb",
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_7071622db9df",
        "power_net_2074a83eb788",
        "power_net_b5187ab6f19a",
        "power_net_a632dd3fa2a2",
        "power_net_223314db53b0",
        "power_net_bb20ea345245",
        "power_net_2f3224d5b90a",
        "power_net_0937e82a0391",
        "power_net_56f70873fed6",
        "power_net_747203f7ea20",
        "power_net_006931c58e47",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3901",
          "pin": "1",
          "netId": "power_net_882de840965a",
          "name": "COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "2",
          "netId": "power_net_9ac6d4c8f874",
          "name": "CH7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "3",
          "netId": "power_net_0b315650a930",
          "name": "CH6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "4",
          "netId": "power_net_5c97037182dc",
          "name": "CH5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "5",
          "netId": "power_net_324fb6a46e24",
          "name": "CH4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "6",
          "netId": "power_net_8165c7e0e80c",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "7",
          "netId": "power_net_ca640db2f885",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "8",
          "netId": "power_net_217501fd4a1b",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "9",
          "netId": "power_net_e14830d3e0bb",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "16",
          "netId": "power_net_a632dd3fa2a2",
          "name": "CH15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "17",
          "netId": "power_net_223314db53b0",
          "name": "CH14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "18",
          "netId": "power_net_bb20ea345245",
          "name": "CH13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "19",
          "netId": "power_net_2f3224d5b90a",
          "name": "CH12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "20",
          "netId": "power_net_0937e82a0391",
          "name": "CH11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "21",
          "netId": "power_net_56f70873fed6",
          "name": "CH10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "22",
          "netId": "power_net_747203f7ea20",
          "name": "CH9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "23",
          "netId": "power_net_006931c58e47",
          "name": "CH8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3901",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "24",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбирается парное напряжение",
      "text": "Второй селектор с тем же адресом выбирает напряжение той же ветви. Пара сигналов продолжает путь к буферам АЦП.",
      "body": "Второй селектор с тем же адресом выбирает напряжение той же ветви. Пара сигналов продолжает путь к буферам АЦП.",
      "nodes": [
        "voltage",
        "current"
      ],
      "edges": [
        "current_voltage"
      ],
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "netIds": [
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Выбирается номер ветви",
      "text": "Общие адресные цепи задают соответствующие входы селекторов тока и напряжения.",
      "body": "Общие адресные цепи задают соответствующие входы селекторов тока и напряжения.",
      "nodes": [
        "current",
        "voltage"
      ],
      "edges": [
        "current_voltage"
      ],
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "netIds": [
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Подключается выбранный ток",
      "text": "16-канальный селектор передаёт один сигнал измерения тока в общий тракт. Остальные входы продолжают существовать, но не являются выбранным выходом.",
      "body": "16-канальный селектор передаёт один сигнал измерения тока в общий тракт. Остальные входы продолжают существовать, но не являются выбранным выходом.",
      "nodes": [
        "current"
      ],
      "edges": [],
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "netIds": [
        "power_net_882de840965a",
        "power_net_9ac6d4c8f874",
        "power_net_0b315650a930",
        "power_net_5c97037182dc",
        "power_net_324fb6a46e24",
        "power_net_8165c7e0e80c",
        "power_net_ca640db2f885",
        "power_net_217501fd4a1b",
        "power_net_e14830d3e0bb",
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_7071622db9df",
        "power_net_2074a83eb788",
        "power_net_b5187ab6f19a",
        "power_net_a632dd3fa2a2",
        "power_net_223314db53b0",
        "power_net_bb20ea345245",
        "power_net_2f3224d5b90a",
        "power_net_0937e82a0391",
        "power_net_56f70873fed6",
        "power_net_747203f7ea20",
        "power_net_006931c58e47",
        "power_net_67006db669b3"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3901",
          "pin": "1",
          "netId": "power_net_882de840965a",
          "name": "COM",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "2",
          "netId": "power_net_9ac6d4c8f874",
          "name": "CH7",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "3",
          "netId": "power_net_0b315650a930",
          "name": "CH6",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "4",
          "netId": "power_net_5c97037182dc",
          "name": "CH5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "5",
          "netId": "power_net_324fb6a46e24",
          "name": "CH4",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "6",
          "netId": "power_net_8165c7e0e80c",
          "name": "CH3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "7",
          "netId": "power_net_ca640db2f885",
          "name": "CH2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "8",
          "netId": "power_net_217501fd4a1b",
          "name": "CH1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "9",
          "netId": "power_net_e14830d3e0bb",
          "name": "CH0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "16",
          "netId": "power_net_a632dd3fa2a2",
          "name": "CH15",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "17",
          "netId": "power_net_223314db53b0",
          "name": "CH14",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "18",
          "netId": "power_net_bb20ea345245",
          "name": "CH13",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "19",
          "netId": "power_net_2f3224d5b90a",
          "name": "CH12",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "20",
          "netId": "power_net_0937e82a0391",
          "name": "CH11",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "21",
          "netId": "power_net_56f70873fed6",
          "name": "CH10",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "22",
          "netId": "power_net_747203f7ea20",
          "name": "CH9",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "23",
          "netId": "power_net_006931c58e47",
          "name": "CH8",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C3901",
          "pin": "1",
          "netId": "power_net_67006db669b3",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "24",
          "netId": "power_net_67006db669b3",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Выбирается парное напряжение",
      "text": "Второй селектор с тем же адресом выбирает напряжение той же ветви. Пара сигналов продолжает путь к буферам АЦП.",
      "body": "Второй селектор с тем же адресом выбирает напряжение той же ветви. Пара сигналов продолжает путь к буферам АЦП.",
      "nodes": [
        "voltage",
        "current"
      ],
      "edges": [
        "current_voltage"
      ],
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "netIds": [
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3902",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "10",
          "netId": "power_net_b8fd52d3ecf7",
          "name": "S0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "11",
          "netId": "power_net_97db96dcc04b",
          "name": "S1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "14",
          "netId": "power_net_2074a83eb788",
          "name": "S2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "13",
          "netId": "power_net_7071622db9df",
          "name": "S3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3902",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3901",
          "pin": "15",
          "netId": "power_net_b5187ab6f19a",
          "name": "DISABLE",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
