/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_100_MCU_POWER_CLOCKS_AND_DEBUG",
  "title": "Как работает: Основной контроллер · запуск и отладка",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
  "steps": [
    {
      "title": "Начинается запуск",
      "text": "После появления питания локальные конденсаторы поддерживают питание STM32. Цепи сброса и выбора загрузки определяют условия начала работы.",
      "body": "После появления питания локальные конденсаторы поддерживают питание STM32. Цепи сброса и выбора загрузки определяют условия начала работы.",
      "nodes": [
        "supply",
        "start",
        "host"
      ],
      "edges": [
        "start_host_2",
        "supply_host_4"
      ],
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "netIds": [
        "control_net_9529eebe621c",
        "control_net_0cbb519cdc03",
        "control_net_90c4fa851afd",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R102",
          "pin": "1",
          "netId": "control_net_9529eebe621c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "1",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R106",
          "pin": "2",
          "netId": "control_net_0cbb519cdc03",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C132",
          "pin": "1",
          "netId": "control_net_0cbb519cdc03",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_SW100",
          "pin": "1",
          "netId": "control_net_0cbb519cdc03",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C106",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C102",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C118",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C113",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C105",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C111",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C110",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R106",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C107",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C112",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C101",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C104",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C109",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C128",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C117",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C115",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C114",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C127",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C125",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "3V3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C126",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R100",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C103",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C108",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C116",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C124",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C121",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C122",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C123",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R100",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C119",
          "pin": "1",
          "netId": "control_net_90afbe6c9420",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C120",
          "pin": "1",
          "netId": "control_net_90afbe6c9420",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Появляется тактирование",
      "text": "Основной генератор передаёт тактовый сигнал STM32; отдельный низкочастотный резонатор обслуживает низкоскоростные функции. Эти тракты рассматриваются отдельно.",
      "body": "Основной генератор передаёт тактовый сигнал STM32; отдельный низкочастотный резонатор обслуживает низкоскоростные функции. Эти тракты рассматриваются отдельно.",
      "nodes": [
        "fast",
        "slow",
        "host"
      ],
      "edges": [
        "fast_host_0",
        "slow_host_1"
      ],
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "netIds": [
        "control_net_7a4e5a463be4",
        "control_net_a38bef0f0104",
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R101",
          "pin": "2",
          "netId": "control_net_7a4e5a463be4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R101",
          "pin": "1",
          "netId": "control_net_a38bef0f0104",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "3",
          "netId": "control_net_a38bef0f0104",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C130",
          "pin": "1",
          "netId": "control_net_03fabe1e0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "2",
          "netId": "control_net_03fabe1e0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C131",
          "pin": "1",
          "netId": "control_net_78e8fc2cd369",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "1",
          "netId": "control_net_78e8fc2cd369",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроллер готов к отладке",
      "text": "Через разъём отладки внешний программатор обращается к STM32. Рабочие команды эксперимента выполняет программа контроллера.",
      "body": "Через разъём отладки внешний программатор обращается к STM32. Рабочие команды эксперимента выполняет программа контроллера.",
      "nodes": [
        "debug",
        "host"
      ],
      "edges": [
        "debug_host_3"
      ],
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "netIds": [
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_6d1eda208f89",
        "control_net_e478289ae762"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R103",
          "pin": "1",
          "netId": "control_net_360449ac40c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R105",
          "pin": "2",
          "netId": "control_net_c76cd2a32b0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R104",
          "pin": "2",
          "netId": "control_net_c76cd2a32b0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "6",
          "netId": "control_net_750a12d376b8",
          "name": "SWO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "2",
          "netId": "control_net_6d1eda208f89",
          "name": "SWDIO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R103",
          "pin": "2",
          "netId": "control_net_6d1eda208f89",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "4",
          "netId": "control_net_e478289ae762",
          "name": "SWCLK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R104",
          "pin": "1",
          "netId": "control_net_e478289ae762",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Начинается запуск",
      "text": "После появления питания локальные конденсаторы поддерживают питание STM32. Цепи сброса и выбора загрузки определяют условия начала работы.",
      "body": "После появления питания локальные конденсаторы поддерживают питание STM32. Цепи сброса и выбора загрузки определяют условия начала работы.",
      "nodes": [
        "supply",
        "start",
        "host"
      ],
      "edges": [
        "start_host_2",
        "supply_host_4"
      ],
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "netIds": [
        "control_net_9529eebe621c",
        "control_net_0cbb519cdc03",
        "control_net_90c4fa851afd",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_R102",
          "pin": "1",
          "netId": "control_net_9529eebe621c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "167",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "1",
          "netId": "control_net_9529eebe621c",
          "name": "BOOT0",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "33",
          "netId": "control_net_0cbb519cdc03",
          "name": "NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R106",
          "pin": "2",
          "netId": "control_net_0cbb519cdc03",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C132",
          "pin": "1",
          "netId": "control_net_0cbb519cdc03",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_SW100",
          "pin": "1",
          "netId": "control_net_0cbb519cdc03",
          "name": "1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C106",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C100",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C102",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C118",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C113",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C105",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C111",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C110",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R106",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C107",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C112",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C101",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C104",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C109",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C128",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C117",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C115",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C114",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C127",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C125",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J101",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "3V3",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C126",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R100",
          "pin": "2",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C103",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "7",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "8",
          "netId": "control_net_90c4fa851afd",
          "name": "VBAT",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "13",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "25",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "44",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "48",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "65",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "71",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "82",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "84",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "92",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "99",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "105",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "113",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "120",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD50_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "121",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD33_USB",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "126",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "135",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "136",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "152",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "160",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "174",
          "netId": "control_net_90c4fa851afd",
          "name": "PDR_ON",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "175",
          "netId": "control_net_90c4fa851afd",
          "name": "VDDLDO",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "176",
          "netId": "control_net_90c4fa851afd",
          "name": "VDD",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C108",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C116",
          "pin": "1",
          "netId": "control_net_90c4fa851afd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C124",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C121",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C122",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C123",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R100",
          "pin": "1",
          "netId": "control_net_d9a5590f95c8",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "39",
          "netId": "control_net_d9a5590f95c8",
          "name": "VREF+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "40",
          "netId": "control_net_d9a5590f95c8",
          "name": "VDDA",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C119",
          "pin": "1",
          "netId": "control_net_90afbe6c9420",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C120",
          "pin": "1",
          "netId": "control_net_90afbe6c9420",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "80",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "power_out",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "133",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "172",
          "netId": "control_net_90afbe6c9420",
          "name": "VCAP",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Появляется тактирование",
      "text": "Основной генератор передаёт тактовый сигнал STM32; отдельный низкочастотный резонатор обслуживает низкоскоростные функции. Эти тракты рассматриваются отдельно.",
      "body": "Основной генератор передаёт тактовый сигнал STM32; отдельный низкочастотный резонатор обслуживает низкоскоростные функции. Эти тракты рассматриваются отдельно.",
      "nodes": [
        "fast",
        "slow",
        "host"
      ],
      "edges": [
        "fast_host_0",
        "slow_host_1"
      ],
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "netIds": [
        "control_net_7a4e5a463be4",
        "control_net_a38bef0f0104",
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "31",
          "netId": "control_net_7a4e5a463be4",
          "name": "PH0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R101",
          "pin": "2",
          "netId": "control_net_7a4e5a463be4",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R101",
          "pin": "1",
          "netId": "control_net_a38bef0f0104",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y100",
          "pin": "3",
          "netId": "control_net_a38bef0f0104",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "10",
          "netId": "control_net_03fabe1e0e1e",
          "name": "PC14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C130",
          "pin": "1",
          "netId": "control_net_03fabe1e0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "2",
          "netId": "control_net_03fabe1e0e1e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "11",
          "netId": "control_net_78e8fc2cd369",
          "name": "PC15",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C131",
          "pin": "1",
          "netId": "control_net_78e8fc2cd369",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Y101",
          "pin": "1",
          "netId": "control_net_78e8fc2cd369",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Контроллер готов к отладке",
      "text": "Через разъём отладки внешний программатор обращается к STM32. Рабочие команды эксперимента выполняет программа контроллера.",
      "body": "Через разъём отладки внешний программатор обращается к STM32. Рабочие команды эксперимента выполняет программа контроллера.",
      "nodes": [
        "debug",
        "host"
      ],
      "edges": [
        "debug_host_3"
      ],
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "netIds": [
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_6d1eda208f89",
        "control_net_e478289ae762"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "132",
          "netId": "control_net_360449ac40c1",
          "name": "PA13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R103",
          "pin": "1",
          "netId": "control_net_360449ac40c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "138",
          "netId": "control_net_c76cd2a32b0e",
          "name": "PA14",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R105",
          "pin": "2",
          "netId": "control_net_c76cd2a32b0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R104",
          "pin": "2",
          "netId": "control_net_c76cd2a32b0e",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "162",
          "netId": "control_net_750a12d376b8",
          "name": "PB3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "6",
          "netId": "control_net_750a12d376b8",
          "name": "SWO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "2",
          "netId": "control_net_6d1eda208f89",
          "name": "SWDIO",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R103",
          "pin": "2",
          "netId": "control_net_6d1eda208f89",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_J100",
          "pin": "4",
          "netId": "control_net_e478289ae762",
          "name": "SWCLK",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R104",
          "pin": "1",
          "netId": "control_net_e478289ae762",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
