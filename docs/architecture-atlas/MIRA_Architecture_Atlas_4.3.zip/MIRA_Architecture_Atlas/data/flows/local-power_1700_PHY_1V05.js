/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_1700_PHY_1V05",
  "title": "Как работает: Питание ядра Ethernet PHY",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_1700_PHY_1V05",
  "steps": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1701",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_05ab23d96f3d",
        "power_net_055c51598970"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1701",
          "pin": "1",
          "netId": "power_net_05ab23d96f3d",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1701",
          "pin": "2",
          "netId": "power_net_055c51598970",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1701",
          "pin": "1",
          "netId": "power_net_055c51598970",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "13",
          "netId": "power_net_055c51598970",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует PHY1V05",
      "text": "Регулятор и цепь обратной связи формируют выходную шину PHY1V05. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину PHY1V05. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_d1b6d8a1c1d4",
        "power_net_086f4f3255c8"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1706",
          "pin": "1",
          "netId": "power_net_d1b6d8a1c1d4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1705",
          "pin": "2",
          "netId": "power_net_d1b6d8a1c1d4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1704",
          "pin": "1",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1703",
          "pin": "1",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1701",
          "pin": "2",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1705",
          "pin": "1",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "7",
          "netId": "power_net_086f4f3255c8",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "14",
          "netId": "power_net_086f4f3255c8",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования PHY1V05 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования PHY1V05 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_d1b6d8a1c1d4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1706",
          "pin": "1",
          "netId": "power_net_d1b6d8a1c1d4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "На вход приходит FPGA5V5",
      "text": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "body": "Шина FPGA5V5 подводит энергию к преобразователю. Вход и общий провод можно проследить по точным цепям схемы.",
      "nodes": [
        "input",
        "convert"
      ],
      "edges": [
        "input_convert"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_cd1e0a0c9a0e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U1701",
          "pin": "10",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "AVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "11",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "12",
          "netId": "power_net_cd1e0a0c9a0e",
          "name": "PVIN",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Запрос проходит разрешение",
      "text": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "body": "Управляющая цепь связывает команду включения и вывод разрешения регулятора. Дальнейшая подача питания зависит от условий этого узла.",
      "nodes": [
        "enable",
        "convert"
      ],
      "edges": [
        "enable_convert"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_05ab23d96f3d",
        "power_net_055c51598970"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_Q1701",
          "pin": "1",
          "netId": "power_net_05ab23d96f3d",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q1701",
          "pin": "2",
          "netId": "power_net_055c51598970",
          "name": "S",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1701",
          "pin": "1",
          "netId": "power_net_055c51598970",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "13",
          "netId": "power_net_055c51598970",
          "name": "EN",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Регулятор формирует PHY1V05",
      "text": "Регулятор и цепь обратной связи формируют выходную шину PHY1V05. Накопительные и фильтрующие элементы поддерживают выход.",
      "body": "Регулятор и цепь обратной связи формируют выходную шину PHY1V05. Накопительные и фильтрующие элементы поддерживают выход.",
      "nodes": [
        "convert",
        "filter"
      ],
      "edges": [
        "convert_filter"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_d1b6d8a1c1d4",
        "power_net_086f4f3255c8"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1706",
          "pin": "1",
          "netId": "power_net_d1b6d8a1c1d4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1705",
          "pin": "2",
          "netId": "power_net_d1b6d8a1c1d4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_C1704",
          "pin": "1",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1703",
          "pin": "1",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_L1701",
          "pin": "2",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R1705",
          "pin": "1",
          "netId": "power_net_086f4f3255c8",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "7",
          "netId": "power_net_086f4f3255c8",
          "name": "FSW",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U1701",
          "pin": "14",
          "netId": "power_net_086f4f3255c8",
          "name": "VOS",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Шина идёт к потребителям",
      "text": "После формирования PHY1V05 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "body": "После формирования PHY1V05 питание продолжается к потребителям и измерительным ответвлениям. Анимация не показывает реальные переходные процессы или задержки запуска.",
      "nodes": [
        "filter",
        "output"
      ],
      "edges": [
        "filter_output"
      ],
      "sceneId": "power_1700_PHY_1V05",
      "netIds": [
        "power_net_d1b6d8a1c1d4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R1706",
          "pin": "1",
          "netId": "power_net_d1b6d8a1c1d4",
          "name": "~",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
