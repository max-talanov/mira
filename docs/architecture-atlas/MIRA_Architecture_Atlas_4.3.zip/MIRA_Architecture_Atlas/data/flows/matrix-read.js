/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "matrix-read",
  "title": "Прочитать матрицу",
  "description": "Посмотрите связь между командами, аналоговым воздействием, откликом матрицы и числовым результатом.",
  "sceneId": "system",
  "steps": [
    {
      "title": "Выбор операции чтения",
      "text": "Основной контроллер и ПЛИС подготавливают эксперимент и время операции.",
      "body": "Основной контроллер и ПЛИС подготавливают эксперимент и время операции.",
      "nodes": [
        "mcu",
        "fpga"
      ],
      "edges": [
        "mcu_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Установка напряжений чтения",
      "text": "Команды ЦАП задают аналоговые уставки чтения.",
      "body": "Команды ЦАП задают аналоговые уставки чтения.",
      "nodes": [
        "fpga",
        "drive"
      ],
      "edges": [
        "fpga_drive"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "5",
          "netId": "control_net_90accaec6322",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Применение зафиксированной коммутации",
      "text": "Коммутатор подключает выбранное воздействие и обратный путь к матрице.",
      "body": "Коммутатор подключает выбранное воздействие и обратный путь к матрице.",
      "nodes": [
        "drive",
        "fpga",
        "matrix"
      ],
      "edges": [
        "drive_matrix",
        "fpga_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40",
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измерение отклика",
      "text": "Выбранный ток матрицы поступает в преобразователь ток-напряжение и входной тракт АЦП.",
      "body": "Выбранный ток матрицы поступает в преобразователь ток-напряжение и входной тракт АЦП.",
      "nodes": [
        "matrix",
        "readout"
      ],
      "edges": [
        "matrix_readout"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d65f00f0a2d4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получение числового результата",
      "text": "ПЛИС принимает результат АЦП и может передать его на компьютер.",
      "body": "ПЛИС принимает результат АЦП и может передать его на компьютер.",
      "nodes": [
        "readout",
        "fpga",
        "links",
        "host"
      ],
      "edges": [
        "host_links",
        "links_fpga",
        "readout_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Выбор операции чтения",
      "text": "Основной контроллер и ПЛИС подготавливают эксперимент и время операции.",
      "body": "Основной контроллер и ПЛИС подготавливают эксперимент и время операции.",
      "nodes": [
        "mcu",
        "fpga"
      ],
      "edges": [
        "mcu_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U100",
          "pin": "49",
          "netId": "control_net_9aff4b2212a6",
          "name": "PA4_/_FPGA_CS_N",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "50",
          "netId": "control_net_e84839bbf71f",
          "name": "PA5_/_FPGA_SCK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "51",
          "netId": "control_net_625cef89ab64",
          "name": "PA6_/_FPGA_MISO",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "52",
          "netId": "control_net_e8d1c7605faf",
          "name": "PA7_/_FPGA_MOSI",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U100",
          "pin": "55",
          "netId": "control_net_cdd2b08d9db8",
          "name": "PB0_/_FPGA_IRQ",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA9",
          "netId": "control_net_028458bc6a66",
          "name": "IO_L8P_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA10",
          "netId": "control_net_189baa4e46d2",
          "name": "IO_L9P_T1_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB10",
          "netId": "control_net_ff9ff859ce5e",
          "name": "IO_L8N_T1_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB12",
          "netId": "control_net_101ecb817b3a",
          "name": "IO_L7N_T1_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Установка напряжений чтения",
      "text": "Команды ЦАП задают аналоговые уставки чтения.",
      "body": "Команды ЦАП задают аналоговые уставки чтения.",
      "nodes": [
        "fpga",
        "drive"
      ],
      "edges": [
        "fpga_drive"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "R2",
          "netId": "control_net_8543c7028353",
          "name": "IO_L3N_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "6",
          "netId": "control_net_8baeadc9d1f8",
          "name": "SCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T3",
          "netId": "control_net_8baeadc9d1f8",
          "name": "IO_0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "7",
          "netId": "control_net_7f616706cf93",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T1",
          "netId": "control_net_7f616706cf93",
          "name": "IO_L1P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1100",
          "pin": "16",
          "netId": "control_net_2889fbee2814",
          "name": "SDO",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U1",
          "netId": "control_net_2889fbee2814",
          "name": "IO_L1N_T0_34",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1000",
          "pin": "5",
          "netId": "control_net_90accaec6322",
          "name": "SYNC_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U2",
          "netId": "control_net_90accaec6322",
          "name": "IO_L2P_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V2",
          "netId": "control_net_bae01a82acc2",
          "name": "IO_L2N_T0_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R3",
          "netId": "control_net_fd8710ab620d",
          "name": "IO_L3P_T0_DQS_34",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Применение зафиксированной коммутации",
      "text": "Коммутатор подключает выбранное воздействие и обратный путь к матрице.",
      "body": "Коммутатор подключает выбранное воздействие и обратный путь к матрице.",
      "nodes": [
        "drive",
        "fpga",
        "matrix"
      ],
      "edges": [
        "drive_matrix",
        "fpga_matrix"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40",
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U500",
          "pin": "D2",
          "netId": "control_net_30006651dbc3",
          "name": "IO_L4N_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E2",
          "netId": "control_net_889281b6cc29",
          "name": "IO_L4P_T0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "D1",
          "netId": "control_net_429d3a1721ef",
          "name": "IO_L3N_T0_DQS_AD5N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "E1",
          "netId": "control_net_d2248f535667",
          "name": "IO_L3P_T0_DQS_AD5P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "A1",
          "netId": "control_net_a0f26e09322b",
          "name": "IO_L1N_T0_AD4N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B1",
          "netId": "control_net_770516324e4c",
          "name": "IO_L1P_T0_AD4P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "B2",
          "netId": "control_net_d846a1ae0de8",
          "name": "IO_L2N_T0_AD12N_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "C2",
          "netId": "control_net_0831bf7686e1",
          "name": "IO_L2P_T0_AD12P_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "F4",
          "netId": "control_net_f05b5740e1a9",
          "name": "IO_0_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L4",
          "netId": "control_net_c4621dfd0ac4",
          "name": "IO_L18N_T2_35",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Измерение отклика",
      "text": "Выбранный ток матрицы поступает в преобразователь ток-напряжение и входной тракт АЦП.",
      "body": "Выбранный ток матрицы поступает в преобразователь ток-напряжение и входной тракт АЦП.",
      "nodes": [
        "matrix",
        "readout"
      ],
      "edges": [
        "matrix_readout"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_d65f00f0a2d4"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1900",
          "pin": "2",
          "netId": "control_net_d65f00f0a2d4",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Получение числового результата",
      "text": "ПЛИС принимает результат АЦП и может передать его на компьютер.",
      "body": "ПЛИС принимает результат АЦП и может передать его на компьютер.",
      "nodes": [
        "readout",
        "fpga",
        "links",
        "host"
      ],
      "edges": [
        "host_links",
        "links_fpga",
        "readout_fpga"
      ],
      "sceneId": "system",
      "netIds": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e",
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U707",
          "pin": "40",
          "netId": "control_net_a3e916588f1a",
          "name": "DATA_0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P20",
          "netId": "control_net_a3e916588f1a",
          "name": "IO_0_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "41",
          "netId": "control_net_55817c8282e0",
          "name": "DATA_1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V22",
          "netId": "control_net_55817c8282e0",
          "name": "IO_L3N_T0_DQS_EMCCLK_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "42",
          "netId": "control_net_e44786acaa30",
          "name": "DATA_2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T21",
          "netId": "control_net_e44786acaa30",
          "name": "IO_L4P_T0_D04_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "43",
          "netId": "control_net_a6a3fee83c7f",
          "name": "DATA_3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U21",
          "netId": "control_net_a6a3fee83c7f",
          "name": "IO_L4N_T0_D05_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "44",
          "netId": "control_net_ae2900dc7735",
          "name": "DATA_4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P19",
          "netId": "control_net_ae2900dc7735",
          "name": "IO_L5P_T0_D06_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "45",
          "netId": "control_net_708de604029c",
          "name": "DATA_5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R19",
          "netId": "control_net_708de604029c",
          "name": "IO_L5N_T0_D07_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "46",
          "netId": "control_net_fb7db09ec7c3",
          "name": "DATA_6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "T20",
          "netId": "control_net_fb7db09ec7c3",
          "name": "IO_L6N_T0_D08_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "47",
          "netId": "control_net_67008bb4401d",
          "name": "DATA_7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W21",
          "netId": "control_net_67008bb4401d",
          "name": "IO_L7P_T1_D09_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "50",
          "netId": "control_net_38b9badc71df",
          "name": "DATA_8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W22",
          "netId": "control_net_38b9badc71df",
          "name": "IO_L7N_T1_D10_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "51",
          "netId": "control_net_c39dacef288b",
          "name": "DATA_9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA20",
          "netId": "control_net_c39dacef288b",
          "name": "IO_L8P_T1_D11_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "52",
          "netId": "control_net_93963a89c623",
          "name": "DATA_10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA21",
          "netId": "control_net_93963a89c623",
          "name": "IO_L8N_T1_D12_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "53",
          "netId": "control_net_080b1c6e773b",
          "name": "DATA_11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y21",
          "netId": "control_net_080b1c6e773b",
          "name": "IO_L9P_T1_DQS_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "54",
          "netId": "control_net_c4ab00cc76ca",
          "name": "DATA_12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y22",
          "netId": "control_net_c4ab00cc76ca",
          "name": "IO_L9N_T1_DQS_D13_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "55",
          "netId": "control_net_f2e37bb320d3",
          "name": "DATA_13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB21",
          "netId": "control_net_f2e37bb320d3",
          "name": "IO_L10P_T1_D14_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "56",
          "netId": "control_net_adca8d8efad4",
          "name": "DATA_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB22",
          "netId": "control_net_adca8d8efad4",
          "name": "IO_L10N_T1_D15_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "57",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "DATA_15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U20",
          "netId": "control_net_fb2e9fe80e2d",
          "name": "IO_L11P_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA18",
          "netId": "control_net_2e89b83a9cd1",
          "name": "IO_L17P_T2_A14_D30_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "71",
          "netId": "control_net_2e89b83a9cd1",
          "name": "DATA_26",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA19",
          "netId": "control_net_01a067f231f5",
          "name": "IO_L15P_T2_DQS_RDWR_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "66",
          "netId": "control_net_01a067f231f5",
          "name": "DATA_22",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB18",
          "netId": "control_net_4a9a6e85b720",
          "name": "IO_L17N_T2_A13_D29_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "72",
          "netId": "control_net_4a9a6e85b720",
          "name": "DATA_27",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB20",
          "netId": "control_net_08fb6faf20a6",
          "name": "IO_L15N_T2_DQS_DOUT_CSO_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "67",
          "netId": "control_net_08fb6faf20a6",
          "name": "DATA_23",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "P14",
          "netId": "control_net_d35e6450ec18",
          "name": "IO_L19P_T3_A10_D26_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "75",
          "netId": "control_net_d35e6450ec18",
          "name": "DATA_30",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "R14",
          "netId": "control_net_90cbd311d743",
          "name": "IO_L19N_T3_A09_D25_VREF_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "76",
          "netId": "control_net_90cbd311d743",
          "name": "DATA_31",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U17",
          "netId": "control_net_fb90ec6e0d11",
          "name": "IO_L18P_T2_A12_D28_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "73",
          "netId": "control_net_fb90ec6e0d11",
          "name": "DATA_28",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "U18",
          "netId": "control_net_b19700dbe4c4",
          "name": "IO_L18N_T2_A11_D27_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "74",
          "netId": "control_net_b19700dbe4c4",
          "name": "DATA_29",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V17",
          "netId": "control_net_9a988f0c62fc",
          "name": "IO_L16P_T2_CSI_B_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "69",
          "netId": "control_net_9a988f0c62fc",
          "name": "DATA_24",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V18",
          "netId": "control_net_f1f55e7a2140",
          "name": "IO_L14P_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "64",
          "netId": "control_net_f1f55e7a2140",
          "name": "DATA_20",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V19",
          "netId": "control_net_cbf683fe7e90",
          "name": "IO_L14N_T2_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "65",
          "netId": "control_net_cbf683fe7e90",
          "name": "DATA_21",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V20",
          "netId": "control_net_6d1b692341f6",
          "name": "IO_L11N_T1_SRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "60",
          "netId": "control_net_6d1b692341f6",
          "name": "DATA_16",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W17",
          "netId": "control_net_ea07dd504c63",
          "name": "IO_L16N_T2_A15_D31_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "70",
          "netId": "control_net_ea07dd504c63",
          "name": "DATA_25",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W20",
          "netId": "control_net_edfa87483431",
          "name": "IO_L12N_T1_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "61",
          "netId": "control_net_edfa87483431",
          "name": "DATA_17",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y18",
          "netId": "control_net_576fff37cf3a",
          "name": "IO_L13P_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "62",
          "netId": "control_net_576fff37cf3a",
          "name": "DATA_18",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y19",
          "netId": "control_net_88588227b7a2",
          "name": "IO_L13N_T2_MRCC_14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U707",
          "pin": "63",
          "netId": "control_net_88588227b7a2",
          "name": "DATA_19",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA13",
          "netId": "control_net_14e361774b31",
          "name": "IO_L3P_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "34",
          "netId": "control_net_14e361774b31",
          "name": "RX_D1",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA15",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "IO_L4P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "36",
          "netId": "control_net_7a2cc9ad1aae",
          "name": "RX_D3",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AA16",
          "netId": "control_net_842a1bd896e7",
          "name": "IO_L1N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "26",
          "netId": "control_net_842a1bd896e7",
          "name": "TX_D2",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB13",
          "netId": "control_net_cc90c66f0af7",
          "name": "IO_L3N_T0_DQS_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "35",
          "netId": "control_net_cc90c66f0af7",
          "name": "RX_D2",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB15",
          "netId": "control_net_dbd1a2d49097",
          "name": "IO_L4N_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "37",
          "netId": "control_net_dbd1a2d49097",
          "name": "TX_CTRL",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB16",
          "netId": "control_net_f755d28cb131",
          "name": "IO_L2P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "25",
          "netId": "control_net_f755d28cb131",
          "name": "TX_D3",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "AB17",
          "netId": "control_net_5682aa39e237",
          "name": "IO_L2N_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "33",
          "netId": "control_net_5682aa39e237",
          "name": "RX_D0",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "V13",
          "netId": "control_net_af615c537cb1",
          "name": "IO_L13P_T2_MRCC_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "29",
          "netId": "control_net_af615c537cb1",
          "name": "GTX_CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "W11",
          "netId": "control_net_e773796fd1f6",
          "name": "IO_L12P_T1_MRCC_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "32",
          "netId": "control_net_e773796fd1f6",
          "name": "RX_CLK",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y13",
          "netId": "control_net_e39e2c0118dc",
          "name": "IO_L5P_T0_13",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "38",
          "netId": "control_net_e39e2c0118dc",
          "name": "RX_CTRL",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y16",
          "netId": "control_net_bb18f917ddd6",
          "name": "IO_L1P_T0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "27",
          "netId": "control_net_bb18f917ddd6",
          "name": "TX_D1",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "Y17",
          "netId": "control_net_4b92eab01e5e",
          "name": "IO_0_13",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U902",
          "pin": "28",
          "netId": "control_net_4b92eab01e5e",
          "name": "TX_D0",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "K6",
          "netId": "control_net_3be7162ce896",
          "name": "IO_L17P_T2_35",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "7",
          "netId": "control_net_3be7162ce896",
          "name": "SDO",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "L1",
          "netId": "control_net_3d36f9d91f43",
          "name": "IO_L15N_T2_DQS_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "6",
          "netId": "control_net_3d36f9d91f43",
          "name": "CNV",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M2",
          "netId": "control_net_a1f3e5011080",
          "name": "IO_L16N_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "9",
          "netId": "control_net_a1f3e5011080",
          "name": "SDI",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U500",
          "pin": "M3",
          "netId": "control_net_b97070122e98",
          "name": "IO_L16P_T2_35",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2004",
          "pin": "8",
          "netId": "control_net_b97070122e98",
          "name": "SCK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "illustrative": true
});
