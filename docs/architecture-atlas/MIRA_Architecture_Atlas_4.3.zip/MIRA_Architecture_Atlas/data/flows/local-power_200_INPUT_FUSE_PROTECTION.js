/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power_200_INPUT_FUSE_PROTECTION",
  "title": "Как работает: Предохранитель и индикация",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power_200_INPUT_FUSE_PROTECTION",
  "steps": [
    {
      "title": "Ток проходит через предохранитель",
      "text": "Плавкий предохранитель включён в последовательный входной тракт. При токе, достаточном для его срабатывания, он разрывает этот путь.",
      "body": "Плавкий предохранитель включён в последовательный входной тракт. При токе, достаточном для его срабатывания, он разрывает этот путь.",
      "nodes": [
        "fuse"
      ],
      "edges": [],
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "netIds": [
        "power_net_6741c8732f40",
        "power_net_e5a2750417c1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_F201",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_F201",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Короткий выброс ограничивается",
      "text": "TVS образует параллельный путь ограничения импульсного перенапряжения. Это отдельная функция от длительной токовой защиты.",
      "body": "TVS образует параллельный путь ограничения импульсного перенапряжения. Это отдельная функция от длительной токовой защиты.",
      "nodes": [
        "transient",
        "fuse"
      ],
      "edges": [
        "fuse_transient"
      ],
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "netIds": [
        "power_net_e5a2750417c1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_F201",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D205",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Состояние входа отображается",
      "text": "Диоды и транзистор обслуживают местную индикацию входа и предохранителя. Значения уровней зависят от фактического состояния схемы.",
      "body": "Диоды и транзистор обслуживают местную индикацию входа и предохранителя. Значения уровней зависят от фактического состояния схемы.",
      "nodes": [
        "indicate"
      ],
      "edges": [],
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "netIds": [
        "power_net_1c0ab1e296fd",
        "power_net_0c0d2e9f9201",
        "power_net_6741c8732f40",
        "power_net_e5a2750417c1",
        "power_net_4a7c0e6708e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R204",
          "pin": "1",
          "netId": "power_net_1c0ab1e296fd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R203",
          "pin": "2",
          "netId": "power_net_1c0ab1e296fd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q201",
          "pin": "1",
          "netId": "power_net_1c0ab1e296fd",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D201",
          "pin": "1",
          "netId": "power_net_0c0d2e9f9201",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R201",
          "pin": "2",
          "netId": "power_net_0c0d2e9f9201",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D202",
          "pin": "2",
          "netId": "power_net_0c0d2e9f9201",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q201",
          "pin": "3",
          "netId": "power_net_0c0d2e9f9201",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R201",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R203",
          "pin": "1",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R202",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D204",
          "pin": "2",
          "netId": "power_net_4a7c0e6708e6",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R202",
          "pin": "1",
          "netId": "power_net_4a7c0e6708e6",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D203",
          "pin": "1",
          "netId": "power_net_4a7c0e6708e6",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Ток проходит через предохранитель",
      "text": "Плавкий предохранитель включён в последовательный входной тракт. При токе, достаточном для его срабатывания, он разрывает этот путь.",
      "body": "Плавкий предохранитель включён в последовательный входной тракт. При токе, достаточном для его срабатывания, он разрывает этот путь.",
      "nodes": [
        "fuse"
      ],
      "edges": [],
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "netIds": [
        "power_net_6741c8732f40",
        "power_net_e5a2750417c1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_F201",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_F201",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Короткий выброс ограничивается",
      "text": "TVS образует параллельный путь ограничения импульсного перенапряжения. Это отдельная функция от длительной токовой защиты.",
      "body": "TVS образует параллельный путь ограничения импульсного перенапряжения. Это отдельная функция от длительной токовой защиты.",
      "nodes": [
        "transient",
        "fuse"
      ],
      "edges": [
        "fuse_transient"
      ],
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "netIds": [
        "power_net_e5a2750417c1"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_F201",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D205",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "A2",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Состояние входа отображается",
      "text": "Диоды и транзистор обслуживают местную индикацию входа и предохранителя. Значения уровней зависят от фактического состояния схемы.",
      "body": "Диоды и транзистор обслуживают местную индикацию входа и предохранителя. Значения уровней зависят от фактического состояния схемы.",
      "nodes": [
        "indicate"
      ],
      "edges": [],
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "netIds": [
        "power_net_1c0ab1e296fd",
        "power_net_0c0d2e9f9201",
        "power_net_6741c8732f40",
        "power_net_e5a2750417c1",
        "power_net_4a7c0e6708e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_R204",
          "pin": "1",
          "netId": "power_net_1c0ab1e296fd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R203",
          "pin": "2",
          "netId": "power_net_1c0ab1e296fd",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q201",
          "pin": "1",
          "netId": "power_net_1c0ab1e296fd",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D201",
          "pin": "1",
          "netId": "power_net_0c0d2e9f9201",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R201",
          "pin": "2",
          "netId": "power_net_0c0d2e9f9201",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D202",
          "pin": "2",
          "netId": "power_net_0c0d2e9f9201",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_Q201",
          "pin": "3",
          "netId": "power_net_0c0d2e9f9201",
          "name": "D",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R201",
          "pin": "1",
          "netId": "power_net_6741c8732f40",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R203",
          "pin": "1",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R202",
          "pin": "2",
          "netId": "power_net_e5a2750417c1",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D204",
          "pin": "2",
          "netId": "power_net_4a7c0e6708e6",
          "name": "A",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_R202",
          "pin": "1",
          "netId": "power_net_4a7c0e6708e6",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_D203",
          "pin": "1",
          "netId": "power_net_4a7c0e6708e6",
          "name": "K",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
