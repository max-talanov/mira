/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "title": "Как работает: 80-битное состояние ключей",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "steps": [
    {
      "title": "Поступают последовательные биты",
      "text": "Первая часть цепочки принимает начальные 32 бита образа переключателей. Тактовая линия продвигает данные по регистрам.",
      "body": "Первая часть цепочки принимает начальные 32 бита образа переключателей. Тактовая линия продвигает данные по регистрам.",
      "nodes": [
        "first"
      ],
      "edges": [],
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "netIds": [
        "control_net_4aefa7bda0e0",
        "control_net_7e66df34c1cb",
        "control_net_30da3c89e6b0",
        "control_net_aa8081055225",
        "control_net_e85cee5f43f2",
        "control_net_48fcc210d1f6",
        "control_net_282ba042f616",
        "control_net_0c3b3e665145",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_2e40141f478d",
        "control_net_671137df6d42",
        "control_net_8d2c65e46923",
        "control_net_928a45524bd4",
        "control_net_6f005443ad9c",
        "control_net_27e11deab85a",
        "control_net_acd932993b7b",
        "control_net_2595b3f207c1",
        "control_net_48cbd08d5e88",
        "control_net_ac7e9e00c8b3",
        "control_net_5e93332cd041",
        "control_net_24fd3915e934",
        "control_net_5ceb5d4eb098",
        "control_net_91367f0adb00",
        "control_net_f05b5740e1a9",
        "control_net_b211580c8101",
        "control_net_d948d4dd3369",
        "control_net_cc7e68c63366",
        "control_net_70c03a238d66",
        "control_net_dfebfa8ce954",
        "control_net_45c19501bad5",
        "control_net_2bbd0dc06c6f",
        "control_net_5c0da047cc8c",
        "control_net_2f56e21bf1c8",
        "control_net_01c0ad0ef8f8",
        "control_net_323da0f3bc1f",
        "control_net_bb256500c151",
        "control_net_a3db8189ec60",
        "control_net_3e8175ead30c",
        "control_net_f498b034d47c",
        "control_net_a275f9d9677f",
        "control_net_8ae298951006"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1401",
          "pin": "1",
          "netId": "control_net_4aefa7bda0e0",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "2",
          "netId": "control_net_7e66df34c1cb",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "3",
          "netId": "control_net_30da3c89e6b0",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "4",
          "netId": "control_net_aa8081055225",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "5",
          "netId": "control_net_e85cee5f43f2",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "6",
          "netId": "control_net_48fcc210d1f6",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "7",
          "netId": "control_net_282ba042f616",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "9",
          "netId": "control_net_0c3b3e665145",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "14",
          "netId": "control_net_0c3b3e665145",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "14",
          "netId": "control_net_8d2c65e46923",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "9",
          "netId": "control_net_8d2c65e46923",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "15",
          "netId": "control_net_928a45524bd4",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1403",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1400",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1402",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1401",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "1",
          "netId": "control_net_27e11deab85a",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "2",
          "netId": "control_net_acd932993b7b",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "3",
          "netId": "control_net_2595b3f207c1",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "4",
          "netId": "control_net_48cbd08d5e88",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "5",
          "netId": "control_net_ac7e9e00c8b3",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "6",
          "netId": "control_net_5e93332cd041",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "7",
          "netId": "control_net_24fd3915e934",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "14",
          "netId": "control_net_5ceb5d4eb098",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "9",
          "netId": "control_net_5ceb5d4eb098",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "15",
          "netId": "control_net_91367f0adb00",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1407",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1415",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1403",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "14",
          "netId": "control_net_f05b5740e1a9",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1411",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "1",
          "netId": "control_net_b211580c8101",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "2",
          "netId": "control_net_d948d4dd3369",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "3",
          "netId": "control_net_cc7e68c63366",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "4",
          "netId": "control_net_70c03a238d66",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "5",
          "netId": "control_net_dfebfa8ce954",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "6",
          "netId": "control_net_45c19501bad5",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "7",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "9",
          "netId": "control_net_5c0da047cc8c",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "15",
          "netId": "control_net_2f56e21bf1c8",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "1",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "2",
          "netId": "control_net_323da0f3bc1f",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "3",
          "netId": "control_net_bb256500c151",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "4",
          "netId": "control_net_a3db8189ec60",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "5",
          "netId": "control_net_3e8175ead30c",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "6",
          "netId": "control_net_f498b034d47c",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "7",
          "netId": "control_net_a275f9d9677f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "15",
          "netId": "control_net_8ae298951006",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Образ сдвигается дальше",
      "text": "Следующие четыре регистра продолжают последовательную цепочку до 64 бит. Выход очередного регистра служит входом следующего.",
      "body": "Следующие четыре регистра продолжают последовательную цепочку до 64 бит. Выход очередного регистра служит входом следующего.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "netIds": [
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_5c0da047cc8c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1404",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1401",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1409",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1405",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1413",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1402",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1406",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1414",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1410",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "14",
          "netId": "control_net_5c0da047cc8c",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "9",
          "netId": "control_net_5c0da047cc8c",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Фиксируется полный образ",
      "text": "Последние 16 бит завершают 80-битный образ. Линия фиксации переносит загруженное состояние на удерживаемые выходы; её имена видны на схеме.",
      "body": "Последние 16 бит завершают 80-битный образ. Линия фиксации переносит загруженное состояние на удерживаемые выходы; её имена видны на схеме.",
      "nodes": [
        "second",
        "last"
      ],
      "edges": [
        "second_last"
      ],
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "netIds": [
        "control_net_c73ef0628409",
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_9f906a4c978b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1404",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1401",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1409",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1405",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1413",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1402",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1406",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1414",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1410",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "14",
          "netId": "control_net_9f906a4c978b",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "9",
          "netId": "control_net_9f906a4c978b",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Поступают последовательные биты",
      "text": "Первая часть цепочки принимает начальные 32 бита образа переключателей. Тактовая линия продвигает данные по регистрам.",
      "body": "Первая часть цепочки принимает начальные 32 бита образа переключателей. Тактовая линия продвигает данные по регистрам.",
      "nodes": [
        "first"
      ],
      "edges": [],
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "netIds": [
        "control_net_4aefa7bda0e0",
        "control_net_7e66df34c1cb",
        "control_net_30da3c89e6b0",
        "control_net_aa8081055225",
        "control_net_e85cee5f43f2",
        "control_net_48fcc210d1f6",
        "control_net_282ba042f616",
        "control_net_0c3b3e665145",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_2e40141f478d",
        "control_net_671137df6d42",
        "control_net_8d2c65e46923",
        "control_net_928a45524bd4",
        "control_net_6f005443ad9c",
        "control_net_27e11deab85a",
        "control_net_acd932993b7b",
        "control_net_2595b3f207c1",
        "control_net_48cbd08d5e88",
        "control_net_ac7e9e00c8b3",
        "control_net_5e93332cd041",
        "control_net_24fd3915e934",
        "control_net_5ceb5d4eb098",
        "control_net_91367f0adb00",
        "control_net_f05b5740e1a9",
        "control_net_b211580c8101",
        "control_net_d948d4dd3369",
        "control_net_cc7e68c63366",
        "control_net_70c03a238d66",
        "control_net_dfebfa8ce954",
        "control_net_45c19501bad5",
        "control_net_2bbd0dc06c6f",
        "control_net_5c0da047cc8c",
        "control_net_2f56e21bf1c8",
        "control_net_01c0ad0ef8f8",
        "control_net_323da0f3bc1f",
        "control_net_bb256500c151",
        "control_net_a3db8189ec60",
        "control_net_3e8175ead30c",
        "control_net_f498b034d47c",
        "control_net_a275f9d9677f",
        "control_net_8ae298951006"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1401",
          "pin": "1",
          "netId": "control_net_4aefa7bda0e0",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "2",
          "netId": "control_net_7e66df34c1cb",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "3",
          "netId": "control_net_30da3c89e6b0",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "4",
          "netId": "control_net_aa8081055225",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "5",
          "netId": "control_net_e85cee5f43f2",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "6",
          "netId": "control_net_48fcc210d1f6",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "7",
          "netId": "control_net_282ba042f616",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "9",
          "netId": "control_net_0c3b3e665145",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "14",
          "netId": "control_net_0c3b3e665145",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "13",
          "netId": "control_net_671137df6d42",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "14",
          "netId": "control_net_8d2c65e46923",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "9",
          "netId": "control_net_8d2c65e46923",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "15",
          "netId": "control_net_928a45524bd4",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1403",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "16",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1400",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1402",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C1401",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "1",
          "netId": "control_net_27e11deab85a",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "2",
          "netId": "control_net_acd932993b7b",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "3",
          "netId": "control_net_2595b3f207c1",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "4",
          "netId": "control_net_48cbd08d5e88",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "5",
          "netId": "control_net_ac7e9e00c8b3",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "6",
          "netId": "control_net_5e93332cd041",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "7",
          "netId": "control_net_24fd3915e934",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "14",
          "netId": "control_net_5ceb5d4eb098",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "9",
          "netId": "control_net_5ceb5d4eb098",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "15",
          "netId": "control_net_91367f0adb00",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1407",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1415",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1403",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "14",
          "netId": "control_net_f05b5740e1a9",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1411",
          "pin": "1",
          "netId": "control_net_f05b5740e1a9",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "1",
          "netId": "control_net_b211580c8101",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "2",
          "netId": "control_net_d948d4dd3369",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "3",
          "netId": "control_net_cc7e68c63366",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "4",
          "netId": "control_net_70c03a238d66",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "5",
          "netId": "control_net_dfebfa8ce954",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "6",
          "netId": "control_net_45c19501bad5",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "7",
          "netId": "control_net_2bbd0dc06c6f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "9",
          "netId": "control_net_5c0da047cc8c",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "15",
          "netId": "control_net_2f56e21bf1c8",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "1",
          "netId": "control_net_01c0ad0ef8f8",
          "name": "QB",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "2",
          "netId": "control_net_323da0f3bc1f",
          "name": "QC",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "3",
          "netId": "control_net_bb256500c151",
          "name": "QD",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "4",
          "netId": "control_net_a3db8189ec60",
          "name": "QE",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "5",
          "netId": "control_net_3e8175ead30c",
          "name": "QF",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "6",
          "netId": "control_net_f498b034d47c",
          "name": "QG",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "7",
          "netId": "control_net_a275f9d9677f",
          "name": "QH",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "15",
          "netId": "control_net_8ae298951006",
          "name": "QA",
          "direction": "tri_state",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Образ сдвигается дальше",
      "text": "Следующие четыре регистра продолжают последовательную цепочку до 64 бит. Выход очередного регистра служит входом следующего.",
      "body": "Следующие четыре регистра продолжают последовательную цепочку до 64 бит. Выход очередного регистра служит входом следующего.",
      "nodes": [
        "first",
        "second"
      ],
      "edges": [
        "first_second"
      ],
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "netIds": [
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_5c0da047cc8c"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1404",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1401",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1409",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1405",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1413",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1401",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1402",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1406",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1414",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1400",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1410",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1402",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "14",
          "netId": "control_net_5c0da047cc8c",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1403",
          "pin": "9",
          "netId": "control_net_5c0da047cc8c",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Фиксируется полный образ",
      "text": "Последние 16 бит завершают 80-битный образ. Линия фиксации переносит загруженное состояние на удерживаемые выходы; её имена видны на схеме.",
      "body": "Последние 16 бит завершают 80-битный образ. Линия фиксации переносит загруженное состояние на удерживаемые выходы; её имена видны на схеме.",
      "nodes": [
        "second",
        "last"
      ],
      "edges": [
        "second_last"
      ],
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "netIds": [
        "control_net_c73ef0628409",
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_9f906a4c978b"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U1404",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "13",
          "netId": "control_net_c73ef0628409",
          "name": "OE_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1401",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1409",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1405",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1413",
          "pin": "1",
          "netId": "control_net_2e40141f478d",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "12",
          "netId": "control_net_2e40141f478d",
          "name": "RCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "10",
          "netId": "control_net_d0ee9c0888fb",
          "name": "SRCLR_N",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1404",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1402",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1406",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1405",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1414",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1406",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R1410",
          "pin": "1",
          "netId": "control_net_770516324e4c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1409",
          "pin": "11",
          "netId": "control_net_770516324e4c",
          "name": "SRCLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1408",
          "pin": "14",
          "netId": "control_net_9f906a4c978b",
          "name": "SER",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U1407",
          "pin": "9",
          "netId": "control_net_9f906a4c978b",
          "name": "QH_SER",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
