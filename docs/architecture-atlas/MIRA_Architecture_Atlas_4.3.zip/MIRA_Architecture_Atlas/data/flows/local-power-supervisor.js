/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-power-supervisor",
  "title": "Как работает: Запуск и аппаратная безопасность",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "power-supervisor",
  "steps": [
    {
      "title": "Контроллер последовательности питания",
      "text": "U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "body": "U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "nodes": [
        "sheet2400",
        "sheet3000"
      ],
      "edges": [
        "sheet2400_sheet3000"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_0ee4f5245d75",
        "power_net_2965499926c8",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_47f67f61993c",
        "power_net_ed26aaa81531",
        "power_net_e46274585def",
        "power_net_cfa48b7bd3ef",
        "power_net_0c8e0f29b47d",
        "power_net_e1dd2bfabf3b",
        "power_net_99aaef80128f",
        "power_net_61199f10a0d6",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ae3b1a85f32f",
        "power_net_ac83bbc60cc7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "4",
          "netId": "power_net_2965499926c8",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "12",
          "netId": "power_net_95f2aea4f265",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "13",
          "netId": "power_net_b80a0b0c471f",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "6",
          "netId": "power_net_47f67f61993c",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "5",
          "netId": "power_net_e46274585def",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "2",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "10",
          "netId": "power_net_0c8e0f29b47d",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "12",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "10",
          "netId": "power_net_99aaef80128f",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "9",
          "netId": "power_net_61199f10a0d6",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "1",
          "netId": "power_net_fcfa30509d75",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "2",
          "netId": "power_net_b81a8e339338",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "5",
          "netId": "power_net_ac83bbc60cc7",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сторожевой контроль контроллеров",
      "text": "U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера. Связь с соседним узлом показана цепями PM_WDO_N, HOST_RESET_N, PM_RESET_N, AON_RESET_N.",
      "body": "U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера. Связь с соседним узлом показана цепями PM_WDO_N, HOST_RESET_N, PM_RESET_N, AON_RESET_N.",
      "nodes": [
        "sheet2500",
        "sheet2600"
      ],
      "edges": [
        "sheet2500_sheet2600"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_47577a24d67e",
        "power_net_35aa4cb845bd",
        "power_net_2cbf74589b12",
        "power_net_b4c478ffb022",
        "power_net_86751620b7fb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2501",
          "pin": "7",
          "netId": "power_net_47577a24d67e",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "8",
          "netId": "power_net_35aa4cb845bd",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "10",
          "netId": "power_net_35aa4cb845bd",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "13",
          "netId": "power_net_2cbf74589b12",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "8",
          "netId": "power_net_b4c478ffb022",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "7",
          "netId": "power_net_86751620b7fb",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "5",
          "netId": "power_net_86751620b7fb",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Аппаратные разрешения и блокировки",
      "text": "Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы. Связь с соседним узлом показана цепями PG_INPUT, PWR_KILL_GPIO, MATRIX_ARM_PULSE, ALL_RAILS_PG.",
      "body": "Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы. Связь с соседним узлом показана цепями PG_INPUT, PWR_KILL_GPIO, MATRIX_ARM_PULSE, ALL_RAILS_PG.",
      "nodes": [
        "sheet2600",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2600"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_c9b6c7228333",
        "power_net_9ab95937734d",
        "power_net_6d982403b080",
        "power_net_47f67f61993c",
        "power_net_6ad422db16ac",
        "power_net_4aeb4892b398",
        "power_net_47577a24d67e",
        "power_net_8828c890966d",
        "power_net_35045b6a457d",
        "power_net_cfb766cbb94f",
        "power_net_2cbf74589b12",
        "power_net_86751620b7fb",
        "power_net_5a1f578d112a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "42",
          "netId": "power_net_c9b6c7228333",
          "name": "PA10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "4",
          "netId": "power_net_c9b6c7228333",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "PC11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "14",
          "netId": "power_net_6d982403b080",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "2",
          "netId": "power_net_47f67f61993c",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "13",
          "netId": "power_net_6ad422db16ac",
          "name": "PC0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "10",
          "netId": "power_net_4aeb4892b398",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "16",
          "netId": "power_net_47577a24d67e",
          "name": "PC3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "43",
          "netId": "power_net_35045b6a457d",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "5",
          "netId": "power_net_35045b6a457d",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "2",
          "netId": "power_net_cfb766cbb94f",
          "name": "PC12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "13",
          "netId": "power_net_2cbf74589b12",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "49",
          "netId": "power_net_86751620b7fb",
          "name": "PC9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "5",
          "netId": "power_net_86751620b7fb",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешения основных преобразователей",
      "text": "U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_SYS, EN_REQ_P15, GLOBAL_PWR_PERMIT, EN_REQ_ANA.",
      "body": "U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_SYS, EN_REQ_P15, GLOBAL_PWR_PERMIT, EN_REQ_ANA.",
      "nodes": [
        "sheet2700",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2700"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_c19f5798f458",
        "power_net_c876bbd15aa2",
        "power_net_8828c890966d",
        "power_net_83fb386e92c5",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_f4716909bd0c",
        "power_net_c66ec173184e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "21",
          "netId": "power_net_c19f5798f458",
          "name": "PA4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "5",
          "netId": "power_net_c19f5798f458",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "24",
          "netId": "power_net_c876bbd15aa2",
          "name": "PA7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "2",
          "netId": "power_net_c876bbd15aa2",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "23",
          "netId": "power_net_83fb386e92c5",
          "name": "PA6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "13",
          "netId": "power_net_83fb386e92c5",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "25",
          "netId": "power_net_5a10e16f7ce2",
          "name": "PC4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "5",
          "netId": "power_net_5a10e16f7ce2",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "26",
          "netId": "power_net_1f6f0734f873",
          "name": "PC5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "10",
          "netId": "power_net_1f6f0734f873",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "27",
          "netId": "power_net_afa5c4d57041",
          "name": "PB0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "13",
          "netId": "power_net_afa5c4d57041",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "10",
          "netId": "power_net_f4716909bd0c",
          "name": "PF0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "2",
          "netId": "power_net_f4716909bd0c",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "22",
          "netId": "power_net_c66ec173184e",
          "name": "PA5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "10",
          "netId": "power_net_c66ec173184e",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешения вспомогательных преобразователей",
      "text": "U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_VTT, EN_REQ_AUX25, EN_REQ_DDR, GLOBAL_PWR_PERMIT.",
      "body": "U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_VTT, EN_REQ_AUX25, EN_REQ_DDR, GLOBAL_PWR_PERMIT.",
      "nodes": [
        "sheet2800",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2800"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_2c93a597633f",
        "power_net_d1fe7a20e661",
        "power_net_5dc0cb853f29",
        "power_net_8828c890966d",
        "power_net_69d4e38b1bd0",
        "power_net_12bae3231aaa",
        "power_net_1b4ac01010f8",
        "power_net_b527a6b82695"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "32",
          "netId": "power_net_2c93a597633f",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "2",
          "netId": "power_net_2c93a597633f",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "28",
          "netId": "power_net_d1fe7a20e661",
          "name": "PB1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "2",
          "netId": "power_net_d1fe7a20e661",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "30",
          "netId": "power_net_5dc0cb853f29",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "10",
          "netId": "power_net_5dc0cb853f29",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "31",
          "netId": "power_net_69d4e38b1bd0",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "13",
          "netId": "power_net_69d4e38b1bd0",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "33",
          "netId": "power_net_12bae3231aaa",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "5",
          "netId": "power_net_12bae3231aaa",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "29",
          "netId": "power_net_1b4ac01010f8",
          "name": "PB2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "5",
          "netId": "power_net_1b4ac01010f8",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "34",
          "netId": "power_net_b527a6b82695",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "10",
          "netId": "power_net_b527a6b82695",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка допустимых напряжений",
      "text": "U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON. Связь с соседним узлом показана цепями PG_ANA, PG_P15, PG_N15, PG_USB.",
      "body": "U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON. Связь с соседним узлом показана цепями PG_ANA, PG_P15, PG_N15, PG_USB.",
      "nodes": [
        "sheet2900",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2900"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_ae3b1a85f32f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "14",
          "netId": "power_net_61199f10a0d6",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "13",
          "netId": "power_net_0c8e0f29b47d",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "2",
          "netId": "power_net_ae3b1a85f32f",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность напряжений питания",
      "text": "U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "body": "U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "nodes": [
        "sheet3000",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet3000"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_0ee4f5245d75",
        "power_net_2965499926c8",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_47f67f61993c",
        "power_net_ed26aaa81531",
        "power_net_e46274585def",
        "power_net_cfa48b7bd3ef",
        "power_net_0c8e0f29b47d",
        "power_net_e1dd2bfabf3b",
        "power_net_99aaef80128f",
        "power_net_61199f10a0d6",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ae3b1a85f32f",
        "power_net_ac83bbc60cc7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "4",
          "netId": "power_net_2965499926c8",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "12",
          "netId": "power_net_95f2aea4f265",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "13",
          "netId": "power_net_b80a0b0c471f",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "6",
          "netId": "power_net_47f67f61993c",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "5",
          "netId": "power_net_e46274585def",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "2",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "10",
          "netId": "power_net_0c8e0f29b47d",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "12",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "10",
          "netId": "power_net_99aaef80128f",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "9",
          "netId": "power_net_61199f10a0d6",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "1",
          "netId": "power_net_fcfa30509d75",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "2",
          "netId": "power_net_b81a8e339338",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "5",
          "netId": "power_net_ac83bbc60cc7",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность команд включения",
      "text": "U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин. Связь с соседним узлом показана цепями CMD_CORE, CMD_ANA, CMD_USB, CMD_P15.",
      "body": "U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин. Связь с соседним узлом показана цепями CMD_CORE, CMD_ANA, CMD_USB, CMD_P15.",
      "nodes": [
        "sheet3100",
        "sheet2700"
      ],
      "edges": [
        "sheet2700_sheet3100"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_3db57ce8c78a",
        "power_net_6220152fdd65",
        "power_net_6649c6cdd008",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_7f7616523bf4",
        "power_net_9020238d369a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2702",
          "pin": "8",
          "netId": "power_net_3db57ce8c78a",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "12",
          "netId": "power_net_3db57ce8c78a",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "11",
          "netId": "power_net_6220152fdd65",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "5",
          "netId": "power_net_6220152fdd65",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "3",
          "netId": "power_net_6649c6cdd008",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "3",
          "netId": "power_net_35be90fefcdd",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "9",
          "netId": "power_net_35be90fefcdd",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "6",
          "netId": "power_net_afd79c7e6e58",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "10",
          "netId": "power_net_afd79c7e6e58",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "8",
          "netId": "power_net_7f7616523bf4",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "4",
          "netId": "power_net_7f7616523bf4",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "6",
          "netId": "power_net_9020238d369a",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "2",
          "netId": "power_net_9020238d369a",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "11",
          "netId": "power_net_9693d69e08e6",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "13",
          "netId": "power_net_9693d69e08e6",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Защита отрицательной шины по току",
      "text": "U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.",
      "body": "U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.",
      "nodes": [
        "sheet3200"
      ],
      "edges": [],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_2aea9a339bff",
        "power_net_4aeb4892b398",
        "power_net_67006db669b3",
        "power_net_860af4e4ed8e",
        "power_net_cfd922d13086",
        "power_net_d1bea8e58439",
        "power_net_deb9e24e4b28"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3201",
          "pin": "1",
          "netId": "power_net_2aea9a339bff",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "4",
          "netId": "power_net_860af4e4ed8e",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "5",
          "netId": "power_net_cfd922d13086",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "13",
          "netId": "power_net_d1bea8e58439",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "14",
          "netId": "power_net_deb9e24e4b28",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Связь контроллера питания с основным",
      "text": "J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера. Связь с соседним узлом показана цепями ADC_VTT, PM_SWDIO_MCU, ALL_RAILS_PG, GLOBAL_PWR_PERMIT.",
      "body": "J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера. Связь с соседним узлом показана цепями ADC_VTT, PM_SWDIO_MCU, ALL_RAILS_PG, GLOBAL_PWR_PERMIT.",
      "nodes": [
        "sheet3300",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet3300"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_e5822cf03a94",
        "power_net_25cd945f19a1",
        "power_net_47f67f61993c",
        "power_net_8828c890966d",
        "power_net_ccf5ee78cf75",
        "power_net_36bf51cd4ad6",
        "power_net_a250a8b7fe30",
        "power_net_2cbf74589b12",
        "power_net_5a1f578d112a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "19",
          "netId": "power_net_e5822cf03a94",
          "name": "PA2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "45",
          "netId": "power_net_25cd945f19a1",
          "name": "PA13/SWDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "9",
          "netId": "power_net_47f67f61993c",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "41",
          "netId": "power_net_ccf5ee78cf75",
          "name": "PD9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "2",
          "netId": "power_net_36bf51cd4ad6",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "40",
          "netId": "power_net_36bf51cd4ad6",
          "name": "PD8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "46",
          "netId": "power_net_a250a8b7fe30",
          "name": "PA14/BOOT0/SWCLK",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "5",
          "netId": "power_net_2cbf74589b12",
          "name": "Pin_5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "5",
          "netId": "power_net_5a1f578d112a",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Контроллер последовательности питания",
      "text": "U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "body": "U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "nodes": [
        "sheet2400",
        "sheet3000"
      ],
      "edges": [
        "sheet2400_sheet3000"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_0ee4f5245d75",
        "power_net_2965499926c8",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_47f67f61993c",
        "power_net_ed26aaa81531",
        "power_net_e46274585def",
        "power_net_cfa48b7bd3ef",
        "power_net_0c8e0f29b47d",
        "power_net_e1dd2bfabf3b",
        "power_net_99aaef80128f",
        "power_net_61199f10a0d6",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ae3b1a85f32f",
        "power_net_ac83bbc60cc7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "4",
          "netId": "power_net_2965499926c8",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "12",
          "netId": "power_net_95f2aea4f265",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "13",
          "netId": "power_net_b80a0b0c471f",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "6",
          "netId": "power_net_47f67f61993c",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "5",
          "netId": "power_net_e46274585def",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "2",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "10",
          "netId": "power_net_0c8e0f29b47d",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "12",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "10",
          "netId": "power_net_99aaef80128f",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "9",
          "netId": "power_net_61199f10a0d6",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "1",
          "netId": "power_net_fcfa30509d75",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "2",
          "netId": "power_net_b81a8e339338",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "5",
          "netId": "power_net_ac83bbc60cc7",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Сторожевой контроль контроллеров",
      "text": "U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера. Связь с соседним узлом показана цепями PM_WDO_N, HOST_RESET_N, PM_RESET_N, AON_RESET_N.",
      "body": "U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера. Связь с соседним узлом показана цепями PM_WDO_N, HOST_RESET_N, PM_RESET_N, AON_RESET_N.",
      "nodes": [
        "sheet2500",
        "sheet2600"
      ],
      "edges": [
        "sheet2500_sheet2600"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_47577a24d67e",
        "power_net_35aa4cb845bd",
        "power_net_2cbf74589b12",
        "power_net_b4c478ffb022",
        "power_net_86751620b7fb"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2501",
          "pin": "7",
          "netId": "power_net_47577a24d67e",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "8",
          "netId": "power_net_35aa4cb845bd",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "10",
          "netId": "power_net_35aa4cb845bd",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "13",
          "netId": "power_net_2cbf74589b12",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2501",
          "pin": "8",
          "netId": "power_net_b4c478ffb022",
          "name": "RESET_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "1",
          "netId": "power_net_b4c478ffb022",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2502",
          "pin": "7",
          "netId": "power_net_86751620b7fb",
          "name": "WDO_N",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "5",
          "netId": "power_net_86751620b7fb",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Аппаратные разрешения и блокировки",
      "text": "Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы. Связь с соседним узлом показана цепями PG_INPUT, PWR_KILL_GPIO, MATRIX_ARM_PULSE, ALL_RAILS_PG.",
      "body": "Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы. Связь с соседним узлом показана цепями PG_INPUT, PWR_KILL_GPIO, MATRIX_ARM_PULSE, ALL_RAILS_PG.",
      "nodes": [
        "sheet2600",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2600"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_c9b6c7228333",
        "power_net_9ab95937734d",
        "power_net_6d982403b080",
        "power_net_47f67f61993c",
        "power_net_6ad422db16ac",
        "power_net_4aeb4892b398",
        "power_net_47577a24d67e",
        "power_net_8828c890966d",
        "power_net_35045b6a457d",
        "power_net_cfb766cbb94f",
        "power_net_2cbf74589b12",
        "power_net_86751620b7fb",
        "power_net_5a1f578d112a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "42",
          "netId": "power_net_c9b6c7228333",
          "name": "PA10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "4",
          "netId": "power_net_c9b6c7228333",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "1",
          "netId": "power_net_9ab95937734d",
          "name": "PC11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "14",
          "netId": "power_net_6d982403b080",
          "name": "PC1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "11",
          "netId": "power_net_6d982403b080",
          "name": "2CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "2",
          "netId": "power_net_47f67f61993c",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "13",
          "netId": "power_net_6ad422db16ac",
          "name": "PC0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "3",
          "netId": "power_net_6ad422db16ac",
          "name": "1CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "44",
          "netId": "power_net_4aeb4892b398",
          "name": "PA12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "10",
          "netId": "power_net_4aeb4892b398",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "16",
          "netId": "power_net_47577a24d67e",
          "name": "PC3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "2",
          "netId": "power_net_47577a24d67e",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "5",
          "netId": "power_net_8828c890966d",
          "name": "1Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "43",
          "netId": "power_net_35045b6a457d",
          "name": "PA11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "5",
          "netId": "power_net_35045b6a457d",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "2",
          "netId": "power_net_cfb766cbb94f",
          "name": "PC12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2601",
          "pin": "13",
          "netId": "power_net_2cbf74589b12",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "49",
          "netId": "power_net_86751620b7fb",
          "name": "PC9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2602",
          "pin": "5",
          "netId": "power_net_86751620b7fb",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J2603",
          "pin": "1",
          "netId": "power_net_5a1f578d112a",
          "name": "Pin_1",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2603",
          "pin": "9",
          "netId": "power_net_5a1f578d112a",
          "name": "2Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешения основных преобразователей",
      "text": "U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_SYS, EN_REQ_P15, GLOBAL_PWR_PERMIT, EN_REQ_ANA.",
      "body": "U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_SYS, EN_REQ_P15, GLOBAL_PWR_PERMIT, EN_REQ_ANA.",
      "nodes": [
        "sheet2700",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2700"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_c19f5798f458",
        "power_net_c876bbd15aa2",
        "power_net_8828c890966d",
        "power_net_83fb386e92c5",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_f4716909bd0c",
        "power_net_c66ec173184e"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "21",
          "netId": "power_net_c19f5798f458",
          "name": "PA4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "5",
          "netId": "power_net_c19f5798f458",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "24",
          "netId": "power_net_c876bbd15aa2",
          "name": "PA7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "2",
          "netId": "power_net_c876bbd15aa2",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "23",
          "netId": "power_net_83fb386e92c5",
          "name": "PA6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "13",
          "netId": "power_net_83fb386e92c5",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "25",
          "netId": "power_net_5a10e16f7ce2",
          "name": "PC4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "5",
          "netId": "power_net_5a10e16f7ce2",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "26",
          "netId": "power_net_1f6f0734f873",
          "name": "PC5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "10",
          "netId": "power_net_1f6f0734f873",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "27",
          "netId": "power_net_afa5c4d57041",
          "name": "PB0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "13",
          "netId": "power_net_afa5c4d57041",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "10",
          "netId": "power_net_f4716909bd0c",
          "name": "PF0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "2",
          "netId": "power_net_f4716909bd0c",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "22",
          "netId": "power_net_c66ec173184e",
          "name": "PA5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "10",
          "netId": "power_net_c66ec173184e",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешения вспомогательных преобразователей",
      "text": "U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_VTT, EN_REQ_AUX25, EN_REQ_DDR, GLOBAL_PWR_PERMIT.",
      "body": "U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением. Связь с соседним узлом показана цепями EN_REQ_VTT, EN_REQ_AUX25, EN_REQ_DDR, GLOBAL_PWR_PERMIT.",
      "nodes": [
        "sheet2800",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2800"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_2c93a597633f",
        "power_net_d1fe7a20e661",
        "power_net_5dc0cb853f29",
        "power_net_8828c890966d",
        "power_net_69d4e38b1bd0",
        "power_net_12bae3231aaa",
        "power_net_1b4ac01010f8",
        "power_net_b527a6b82695"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "32",
          "netId": "power_net_2c93a597633f",
          "name": "PB12",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "2",
          "netId": "power_net_2c93a597633f",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "28",
          "netId": "power_net_d1fe7a20e661",
          "name": "PB1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "2",
          "netId": "power_net_d1fe7a20e661",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "30",
          "netId": "power_net_5dc0cb853f29",
          "name": "PB10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "10",
          "netId": "power_net_5dc0cb853f29",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "1",
          "netId": "power_net_8828c890966d",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "4",
          "netId": "power_net_8828c890966d",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "9",
          "netId": "power_net_8828c890966d",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "31",
          "netId": "power_net_69d4e38b1bd0",
          "name": "PB11",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "13",
          "netId": "power_net_69d4e38b1bd0",
          "name": "4B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "33",
          "netId": "power_net_12bae3231aaa",
          "name": "PB13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "5",
          "netId": "power_net_12bae3231aaa",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "29",
          "netId": "power_net_1b4ac01010f8",
          "name": "PB2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2801",
          "pin": "5",
          "netId": "power_net_1b4ac01010f8",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "34",
          "netId": "power_net_b527a6b82695",
          "name": "PB14",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2802",
          "pin": "10",
          "netId": "power_net_b527a6b82695",
          "name": "3B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Проверка допустимых напряжений",
      "text": "U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON. Связь с соседним узлом показана цепями PG_ANA, PG_P15, PG_N15, PG_USB.",
      "body": "U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON. Связь с соседним узлом показана цепями PG_ANA, PG_P15, PG_N15, PG_USB.",
      "nodes": [
        "sheet2900",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet2900"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_ae3b1a85f32f"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "1",
          "netId": "power_net_e46274585def",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "14",
          "netId": "power_net_61199f10a0d6",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "13",
          "netId": "power_net_0c8e0f29b47d",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2901",
          "pin": "2",
          "netId": "power_net_ae3b1a85f32f",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность напряжений питания",
      "text": "U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "body": "U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений. Связь с соседним узлом показана цепями PGR_VTT, PG_FPGA, PGR_CORE, PGR_AUX18.",
      "nodes": [
        "sheet3000",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet3000"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_0ee4f5245d75",
        "power_net_2965499926c8",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_47f67f61993c",
        "power_net_ed26aaa81531",
        "power_net_e46274585def",
        "power_net_cfa48b7bd3ef",
        "power_net_0c8e0f29b47d",
        "power_net_e1dd2bfabf3b",
        "power_net_99aaef80128f",
        "power_net_61199f10a0d6",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ae3b1a85f32f",
        "power_net_ac83bbc60cc7"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "62",
          "netId": "power_net_0ee4f5245d75",
          "name": "PB8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "9",
          "netId": "power_net_0ee4f5245d75",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "52",
          "netId": "power_net_2965499926c8",
          "name": "PD2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "4",
          "netId": "power_net_2965499926c8",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "56",
          "netId": "power_net_95f2aea4f265",
          "name": "PD6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "12",
          "netId": "power_net_95f2aea4f265",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "57",
          "netId": "power_net_b80a0b0c471f",
          "name": "PB3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "13",
          "netId": "power_net_b80a0b0c471f",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3018",
          "pin": "6",
          "netId": "power_net_47f67f61993c",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "60",
          "netId": "power_net_ed26aaa81531",
          "name": "PB6",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "4",
          "netId": "power_net_ed26aaa81531",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "53",
          "netId": "power_net_e46274585def",
          "name": "PD3",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "5",
          "netId": "power_net_e46274585def",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "51",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "PD1",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "2",
          "netId": "power_net_cfa48b7bd3ef",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "55",
          "netId": "power_net_0c8e0f29b47d",
          "name": "PD5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "10",
          "netId": "power_net_0c8e0f29b47d",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "64",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "PC10",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "12",
          "netId": "power_net_e1dd2bfabf3b",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "63",
          "netId": "power_net_99aaef80128f",
          "name": "PB9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "10",
          "netId": "power_net_99aaef80128f",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "54",
          "netId": "power_net_61199f10a0d6",
          "name": "PD4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "9",
          "netId": "power_net_61199f10a0d6",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "58",
          "netId": "power_net_fcfa30509d75",
          "name": "PB4",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "1",
          "netId": "power_net_fcfa30509d75",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "59",
          "netId": "power_net_b81a8e339338",
          "name": "PB5",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "2",
          "netId": "power_net_b81a8e339338",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "50",
          "netId": "power_net_ae3b1a85f32f",
          "name": "PD0",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3001",
          "pin": "1",
          "netId": "power_net_ae3b1a85f32f",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "61",
          "netId": "power_net_ac83bbc60cc7",
          "name": "PB7",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3017",
          "pin": "5",
          "netId": "power_net_ac83bbc60cc7",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Готовность команд включения",
      "text": "U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин. Связь с соседним узлом показана цепями CMD_CORE, CMD_ANA, CMD_USB, CMD_P15.",
      "body": "U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин. Связь с соседним узлом показана цепями CMD_CORE, CMD_ANA, CMD_USB, CMD_P15.",
      "nodes": [
        "sheet3100",
        "sheet2700"
      ],
      "edges": [
        "sheet2700_sheet3100"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_3db57ce8c78a",
        "power_net_6220152fdd65",
        "power_net_6649c6cdd008",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_7f7616523bf4",
        "power_net_9020238d369a",
        "power_net_9693d69e08e6"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2702",
          "pin": "8",
          "netId": "power_net_3db57ce8c78a",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "12",
          "netId": "power_net_3db57ce8c78a",
          "name": "2C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "11",
          "netId": "power_net_6220152fdd65",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "5",
          "netId": "power_net_6220152fdd65",
          "name": "1D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "3",
          "netId": "power_net_6649c6cdd008",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "1",
          "netId": "power_net_6649c6cdd008",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "3",
          "netId": "power_net_35be90fefcdd",
          "name": "1Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "9",
          "netId": "power_net_35be90fefcdd",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "6",
          "netId": "power_net_afd79c7e6e58",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "10",
          "netId": "power_net_afd79c7e6e58",
          "name": "2B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "8",
          "netId": "power_net_7f7616523bf4",
          "name": "3Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "4",
          "netId": "power_net_7f7616523bf4",
          "name": "1C",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2701",
          "pin": "6",
          "netId": "power_net_9020238d369a",
          "name": "2Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "2",
          "netId": "power_net_9020238d369a",
          "name": "1B",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2702",
          "pin": "11",
          "netId": "power_net_9693d69e08e6",
          "name": "4Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3101",
          "pin": "13",
          "netId": "power_net_9693d69e08e6",
          "name": "2D",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Защита отрицательной шины по току",
      "text": "U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.",
      "body": "U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.",
      "nodes": [
        "sheet3200"
      ],
      "edges": [],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_2aea9a339bff",
        "power_net_4aeb4892b398",
        "power_net_67006db669b3",
        "power_net_860af4e4ed8e",
        "power_net_cfd922d13086",
        "power_net_d1bea8e58439",
        "power_net_deb9e24e4b28"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U3201",
          "pin": "1",
          "netId": "power_net_2aea9a339bff",
          "name": "OUT2",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "2",
          "netId": "power_net_4aeb4892b398",
          "name": "OUT1",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "3",
          "netId": "power_net_67006db669b3",
          "name": "V+",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "6",
          "netId": "power_net_67006db669b3",
          "name": "IN2-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "8",
          "netId": "power_net_67006db669b3",
          "name": "IN3-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "10",
          "netId": "power_net_67006db669b3",
          "name": "IN4-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "4",
          "netId": "power_net_860af4e4ed8e",
          "name": "IN1-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "5",
          "netId": "power_net_cfd922d13086",
          "name": "IN1+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "13",
          "netId": "power_net_d1bea8e58439",
          "name": "OUT4",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3201",
          "pin": "14",
          "netId": "power_net_deb9e24e4b28",
          "name": "OUT3",
          "direction": "open_collector",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Связь контроллера питания с основным",
      "text": "J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера. Связь с соседним узлом показана цепями ADC_VTT, PM_SWDIO_MCU, ALL_RAILS_PG, GLOBAL_PWR_PERMIT.",
      "body": "J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера. Связь с соседним узлом показана цепями ADC_VTT, PM_SWDIO_MCU, ALL_RAILS_PG, GLOBAL_PWR_PERMIT.",
      "nodes": [
        "sheet3300",
        "sheet2400"
      ],
      "edges": [
        "sheet2400_sheet3300"
      ],
      "sceneId": "power-supervisor",
      "netIds": [
        "power_net_e5822cf03a94",
        "power_net_25cd945f19a1",
        "power_net_47f67f61993c",
        "power_net_8828c890966d",
        "power_net_ccf5ee78cf75",
        "power_net_36bf51cd4ad6",
        "power_net_a250a8b7fe30",
        "power_net_2cbf74589b12",
        "power_net_5a1f578d112a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "power_U2401",
          "pin": "19",
          "netId": "power_net_e5822cf03a94",
          "name": "PA2",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "45",
          "netId": "power_net_25cd945f19a1",
          "name": "PA13/SWDIO",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "9",
          "netId": "power_net_47f67f61993c",
          "name": "3A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "3",
          "netId": "power_net_47f67f61993c",
          "name": "PC13",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "12",
          "netId": "power_net_8828c890966d",
          "name": "4A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "47",
          "netId": "power_net_8828c890966d",
          "name": "PA15",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "41",
          "netId": "power_net_ccf5ee78cf75",
          "name": "PD9",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "2",
          "netId": "power_net_36bf51cd4ad6",
          "name": "1A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "40",
          "netId": "power_net_36bf51cd4ad6",
          "name": "PD8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "46",
          "netId": "power_net_a250a8b7fe30",
          "name": "PA14/BOOT0/SWCLK",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_J3301",
          "pin": "5",
          "netId": "power_net_2cbf74589b12",
          "name": "Pin_5",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "12",
          "netId": "power_net_2cbf74589b12",
          "name": "PF2/NRST",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U3301",
          "pin": "5",
          "netId": "power_net_5a1f578d112a",
          "name": "2A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "power_U2401",
          "pin": "48",
          "netId": "power_net_5a1f578d112a",
          "name": "PC8",
          "direction": "bidirectional",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
