/* Educational animation path; no hardware control. */
window.MIRA_FUNCTIONAL.scenarios.push({
  "id": "local-control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "title": "Как работает: Аппаратная остановка матрицы",
  "description": "Последовательно проследите входы, преобразование и выходы этого функционального узла. Подсветка учебная; исходные имена цепей и выводов сохранены.",
  "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "steps": [
    {
      "title": "Срабатывает сравнение тока",
      "text": "Компаратор получает измеренный ток источника и резервный порог отключения. Возможное превышение поступает в аппаратную защиту.",
      "body": "Компаратор получает измеренный ток источника и резервный порог отключения. Возможное превышение поступает в аппаратную защиту.",
      "nodes": [
        "compare"
      ],
      "edges": [],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_720010c527b5",
        "control_net_2d2627aeff69",
        "control_net_7b06e5d6a4d9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2200",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2211",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2203",
          "pin": "1",
          "netId": "control_net_720010c527b5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2202",
          "pin": "2",
          "netId": "control_net_720010c527b5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2211",
          "pin": "2",
          "netId": "control_net_720010c527b5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2200",
          "pin": "2",
          "netId": "control_net_2d2627aeff69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2201",
          "pin": "1",
          "netId": "control_net_2d2627aeff69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2200",
          "pin": "1",
          "netId": "control_net_fc57b8202dba",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2202",
          "pin": "1",
          "netId": "control_net_7eb34b3468da",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Событие проходит аппаратную логику",
      "text": "Логика объединяет условия превышения тока и нарушения конфигурации. Это отдельный путь от обычной обработки данных ПЛИС.",
      "body": "Логика объединяет условия превышения тока и нарушения конфигурации. Это отдельный путь от обычной обработки данных ПЛИС.",
      "nodes": [
        "compare",
        "qualify"
      ],
      "edges": [
        "compare_qualify"
      ],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_7b06e5d6a4d9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2201",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Авария запоминается",
      "text": "Защёлка удерживает аварийное состояние до предусмотренного сброса. Исчезновение причины не означает автоматического возобновления операции.",
      "body": "Защёлка удерживает аварийное состояние до предусмотренного сброса. Исчезновение причины не означает автоматического возобновления операции.",
      "nodes": [
        "qualify",
        "remember"
      ],
      "edges": [
        "qualify_remember"
      ],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_9269f101a22a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "4",
          "netId": "control_net_9269f101a22a",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешение снимается на границе питания",
      "text": "Транзисторный интерфейс передаёт аварийный сигнал и запрет в систему питания. На этой диаграмме подтверждены цепи стороны Control.",
      "body": "Транзисторный интерфейс передаёт аварийный сигнал и запрет в систему питания. На этой диаграмме подтверждены цепи стороны Control.",
      "nodes": [
        "remember",
        "inhibit"
      ],
      "edges": [
        "remember_inhibit"
      ],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_d44a94d9b4fd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Q2200",
          "pin": "1",
          "netId": "control_net_d44a94d9b4fd",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Q2201",
          "pin": "1",
          "netId": "control_net_d44a94d9b4fd",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "frames": [
    {
      "title": "Срабатывает сравнение тока",
      "text": "Компаратор получает измеренный ток источника и резервный порог отключения. Возможное превышение поступает в аппаратную защиту.",
      "body": "Компаратор получает измеренный ток источника и резервный порог отключения. Возможное превышение поступает в аппаратную защиту.",
      "nodes": [
        "compare"
      ],
      "edges": [],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_6f005443ad9c",
        "control_net_720010c527b5",
        "control_net_2d2627aeff69",
        "control_net_7b06e5d6a4d9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2200",
          "pin": "5",
          "netId": "control_net_6f005443ad9c",
          "name": "VCC",
          "direction": "power_in",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_C2200",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2211",
          "pin": "1",
          "netId": "control_net_6f005443ad9c",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "4",
          "netId": "control_net_720010c527b5",
          "name": "IN-",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2203",
          "pin": "1",
          "netId": "control_net_720010c527b5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2202",
          "pin": "2",
          "netId": "control_net_720010c527b5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2211",
          "pin": "2",
          "netId": "control_net_720010c527b5",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2200",
          "pin": "2",
          "netId": "control_net_2d2627aeff69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "3",
          "netId": "control_net_2d2627aeff69",
          "name": "IN+",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2201",
          "pin": "1",
          "netId": "control_net_2d2627aeff69",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2200",
          "pin": "1",
          "netId": "control_net_fc57b8202dba",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_R2202",
          "pin": "1",
          "netId": "control_net_7eb34b3468da",
          "name": "",
          "direction": "passive",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Событие проходит аппаратную логику",
      "text": "Логика объединяет условия превышения тока и нарушения конфигурации. Это отдельный путь от обычной обработки данных ПЛИС.",
      "body": "Логика объединяет условия превышения тока и нарушения конфигурации. Это отдельный путь от обычной обработки данных ПЛИС.",
      "nodes": [
        "compare",
        "qualify"
      ],
      "edges": [
        "compare_qualify"
      ],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_7b06e5d6a4d9"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2201",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "A",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2200",
          "pin": "1",
          "netId": "control_net_7b06e5d6a4d9",
          "name": "OUT",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Авария запоминается",
      "text": "Защёлка удерживает аварийное состояние до предусмотренного сброса. Исчезновение причины не означает автоматического возобновления операции.",
      "body": "Защёлка удерживает аварийное состояние до предусмотренного сброса. Исчезновение причины не означает автоматического возобновления операции.",
      "nodes": [
        "qualify",
        "remember"
      ],
      "edges": [
        "qualify_remember"
      ],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_9269f101a22a"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2202",
          "pin": "1",
          "netId": "control_net_9269f101a22a",
          "name": "CLK",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_U2203",
          "pin": "4",
          "netId": "control_net_9269f101a22a",
          "name": "Y",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    },
    {
      "title": "Разрешение снимается на границе питания",
      "text": "Транзисторный интерфейс передаёт аварийный сигнал и запрет в систему питания. На этой диаграмме подтверждены цепи стороны Control.",
      "body": "Транзисторный интерфейс передаёт аварийный сигнал и запрет в систему питания. На этой диаграмме подтверждены цепи стороны Control.",
      "nodes": [
        "remember",
        "inhibit"
      ],
      "edges": [
        "remember_inhibit"
      ],
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "netIds": [
        "control_net_d44a94d9b4fd"
      ],
      "pinStates": [],
      "pinHighlights": [
        {
          "component": "control_U2202",
          "pin": "5",
          "netId": "control_net_d44a94d9b4fd",
          "name": "Q",
          "direction": "output",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Q2200",
          "pin": "1",
          "netId": "control_net_d44a94d9b4fd",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        },
        {
          "component": "control_Q2201",
          "pin": "1",
          "netId": "control_net_d44a94d9b4fd",
          "name": "G",
          "direction": "input",
          "value": "выделен тракт",
          "label": "Подсветка соединения; электрический уровень не моделируется"
        }
      ],
      "illustrative": true,
      "statePolicy": "Подсветка показывает рассматриваемый тракт. Логические уровни, напряжения, задержки и физические формы сигналов не вычисляются."
    }
  ],
  "educational": true,
  "local": true,
  "illustrative": true
});
