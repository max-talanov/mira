/* Editable functional scene: control_PROTECTION */
window.MIRA_FUNCTIONAL.scenes["control_PROTECTION"]={
  "id": "control_PROTECTION",
  "title": "PROTECTION",
  "subtitle": "Защита и регулирование матричного тракта",
  "description": "Регулятор ограничивает напряжение и ток программирования, а аппаратная защита фиксирует аварии и отзывает разрешение.",
  "nodes": [
    {
      "id": "sheet2100",
      "title": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "subtitle": "Ограничение напряжения и тока записи",
      "description": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
      "refs": [
        "control_U2100",
        "control_U2103",
        "control_U2104",
        "control_U2109",
        "control_U2105",
        "control_U2106"
      ],
      "role": "analog",
      "x": 40,
      "y": 180,
      "w": 410,
      "h": 210,
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2100",
          "control_U2103",
          "control_U2104",
          "control_U2109",
          "control_U2105",
          "control_U2106"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_U2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2104",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2109",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Ограничение напряжения и тока записи",
      "sourceSheetName": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceFile": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet2200",
      "title": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "subtitle": "Аппаратная остановка матрицы",
      "description": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
      "refs": [
        "control_U2201",
        "control_U2200",
        "control_U2202",
        "control_U2203"
      ],
      "role": "fault",
      "x": 760,
      "y": 195,
      "w": 320,
      "h": 170,
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2201",
          "control_U2200",
          "control_U2202",
          "control_U2203"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Аппаратная остановка матрицы",
      "sourceSheetName": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "sheet2100_sheet2200",
      "from": "sheet2100",
      "to": "sheet2200",
      "label": "MAT_ILIM_SENSE_BUF",
      "type": "data",
      "nets": [
        "control_net_7eb34b3468da"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_ILIM_SENSE_BUF",
      "netLabels": [
        "MAT_ILIM_SENSE_BUF"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ILIM_SENSE_BUF"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1120,
    "h": 285
  },
  "board": "control",
  "sheetIds": [
    "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
    "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U2100",
      "control_U2103",
      "control_U2104",
      "control_U2109",
      "control_U2105",
      "control_U2106",
      "control_U2201",
      "control_U2200",
      "control_U2202",
      "control_U2203"
    ],
    "sheetIds": [
      "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
    ],
    "units": [
      {
        "component": "control_U2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2104",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2109",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_PROTECTION"
  ],
  "suggestedScenario": "local-control_PROTECTION",
  "explanationTitleRu": "Защита и регулирование матричного тракта",
  "sourceSheetId": "control_PROTECTION",
  "sourceSheetName": "PROTECTION",
  "sourceFile": "PROTECTION.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
