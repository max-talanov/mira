/* Editable functional scene: control_300_MCU_QSPI_MICROSD_AND_CONTROL */
window.MIRA_FUNCTIONAL.scenes["control_300_MCU_QSPI_MICROSD_AND_CONTROL"]={
  "id": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
  "title": "300_MCU_QSPI_MICROSD_AND_CONTROL",
  "subtitle": "Память и управление платой",
  "description": "U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.",
  "nodes": [
    {
      "id": "host",
      "title": "Основной контроллер",
      "subtitle": "",
      "description": "STM32 читает постоянную память, съёмный носитель и состояние платы.",
      "refs": [
        "control_U100",
        "control_R300",
        "control_R308",
        "control_R304",
        "control_R302",
        "control_R307",
        "control_R301"
      ],
      "role": "data",
      "x": 40,
      "y": 280,
      "w": 350,
      "h": 184,
      "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceSheetIds": [
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_U100",
          "control_R300",
          "control_R308",
          "control_R304",
          "control_R302",
          "control_R307",
          "control_R301"
        ],
        "sheetIds": [
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_R300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R301",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R302",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R304",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R307",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R308",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 3
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "flash",
      "title": "Хранение постоянных данных",
      "subtitle": "",
      "description": "Flash-память Quad-SPI сохраняет программы и данные после выключения питания.",
      "refs": [
        "control_U300",
        "control_C300",
        "control_R303",
        "control_C301",
        "control_R306",
        "control_R311",
        "control_R305",
        "control_R309",
        "control_R310"
      ],
      "role": "data",
      "x": 710,
      "y": 40,
      "w": 300,
      "h": 150,
      "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceSheetIds": [
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_U300",
          "control_C300",
          "control_R303",
          "control_C301",
          "control_R306",
          "control_R311",
          "control_R305",
          "control_R309",
          "control_R310"
        ],
        "sheetIds": [
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_C300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_C301",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R303",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R305",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R306",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R309",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R310",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R311",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "card",
      "title": "Съёмный накопитель",
      "subtitle": "",
      "description": "Разъём microSD подключает съёмный накопитель к контроллеру.",
      "refs": [
        "control_J300",
        "control_R315",
        "control_R317",
        "control_R312",
        "control_R323",
        "control_R313",
        "control_R314",
        "control_R316"
      ],
      "role": "data",
      "x": 710,
      "y": 520,
      "w": 300,
      "h": 150,
      "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceSheetIds": [
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_J300",
          "control_R315",
          "control_R317",
          "control_R312",
          "control_R323",
          "control_R313",
          "control_R314",
          "control_R316"
        ],
        "sheetIds": [
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_J300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R312",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R313",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R314",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R315",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R316",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R317",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R323",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "protect",
      "title": "Защита сигналов карты",
      "subtitle": "",
      "description": "ESD-защита ограничивает электростатические разряды со стороны разъёма карты.",
      "refs": [
        "control_U301",
        "control_U302",
        "control_U303",
        "control_R322",
        "control_R318",
        "control_C303",
        "control_R321",
        "control_R320",
        "control_C302",
        "control_R319"
      ],
      "role": "fault",
      "x": 1210,
      "y": 530,
      "w": 260,
      "h": 136,
      "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceSheetIds": [
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_U301",
          "control_U302",
          "control_U303",
          "control_R322",
          "control_R318",
          "control_C303",
          "control_R321",
          "control_R320",
          "control_C302",
          "control_R319"
        ],
        "sheetIds": [
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_C302",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_C303",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R318",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R319",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R320",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R321",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_R322",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U301",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U302",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U303",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "host_flash",
      "from": "host",
      "to": "flash",
      "label": "Постоянные данные",
      "type": "control",
      "nets": [
        "control_net_1ae330a90d69",
        "control_net_dbb8a4cebc4d",
        "control_net_a6d0f4299492",
        "control_net_0afe468f72ab",
        "control_net_c17cd2b70efc",
        "control_net_bfc714f087e0"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Постоянные данные",
      "netLabels": [
        "MCU_QSPI_CLK",
        "MCU_QSPI_IO1",
        "MCU_QSPI_IO0"
      ],
      "unnamedNetIds": [
        "control_net_1ae330a90d69",
        "control_net_dbb8a4cebc4d",
        "control_net_a6d0f4299492"
      ],
      "labelLines": [
        "MCU_QSPI_CLK · MCU_QSPI_IO0",
        "MCU_QSPI_IO1"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "host_card",
      "from": "host",
      "to": "card",
      "label": "7 цепей",
      "type": "control",
      "nets": [
        "control_net_94be9f57dcd4",
        "control_net_adae77af0ed0",
        "control_net_3792d8c5e55e",
        "control_net_24c9b5fda4e5",
        "control_net_0a220a15306e",
        "control_net_119d91accf55",
        "control_net_7f80f60475c4"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "7 цепей",
      "netLabels": [
        "MCU_SD_CD_N",
        "MCU_SD_D3",
        "MCU_SD_CLK",
        "MCU_SD_D0",
        "MCU_SD_D1",
        "MCU_SD_D2",
        "MCU_SD_CMD"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MCU_SD_CD_N · MCU_SD_CLK",
        "MCU_SD_CMD · MCU_SD_D0",
        "MCU_SD_D1 · MCU_SD_D2",
        "MCU_SD_D3"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 5,
    "w": 1510,
    "h": 705
  },
  "board": "control",
  "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 34,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U100",
      "control_R300",
      "control_R308",
      "control_R304",
      "control_R302",
      "control_R307",
      "control_R301",
      "control_U300",
      "control_C300",
      "control_R303",
      "control_C301",
      "control_R306",
      "control_R311",
      "control_R305",
      "control_R309",
      "control_R310",
      "control_J300",
      "control_R315",
      "control_R317",
      "control_R312",
      "control_R323",
      "control_R313",
      "control_R314",
      "control_R316",
      "control_U301",
      "control_U302",
      "control_U303",
      "control_R322",
      "control_R318",
      "control_C303",
      "control_R321",
      "control_R320",
      "control_C302",
      "control_R319"
    ],
    "sheetIds": [
      "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
    ],
    "units": [
      {
        "component": "control_R300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R301",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R302",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R304",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R307",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R308",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 3
      },
      {
        "component": "control_C300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_C301",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R303",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R305",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R306",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R309",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R310",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R311",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_J300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R312",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R313",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R314",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R315",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R316",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R317",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R323",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_C302",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_C303",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R318",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R319",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R320",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R321",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_R322",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U301",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U302",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U303",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_300_MCU_QSPI_MICROSD_AND_CONTROL"
  ],
  "suggestedScenario": "local-control_300_MCU_QSPI_MICROSD_AND_CONTROL",
  "explanationTitleRu": "Память и управление платой",
  "sourceSheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
  "sourceSheetName": "300_MCU_QSPI_MICROSD_AND_CONTROL",
  "sourceFile": "300_MCU_QSPI_MICROSD_AND_CONTROL.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-host",
  "layout": {
    "version": 2,
    "kind": "storage-branches",
    "label": "Два независимых вида памяти вокруг контроллера",
    "geometryOnly": true
  },
  "regions": []
};
