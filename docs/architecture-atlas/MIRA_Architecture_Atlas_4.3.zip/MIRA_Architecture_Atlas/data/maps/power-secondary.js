/* Editable functional scene: power-secondary */
window.MIRA_FUNCTIONAL.scenes["power-secondary"]={
  "id": "power-secondary",
  "title": "SECONDARY_POWER",
  "subtitle": "Питание отдельных нагрузок",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet1200",
      "title": "1200_POWER_MONITOR",
      "subtitle": "Питание ядра ПЛИС",
      "description": "U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.",
      "refs": [
        "power_U1201"
      ],
      "role": "power",
      "x": 380,
      "y": 300,
      "w": 430,
      "h": 220,
      "sceneId": "power_1200_POWER_MONITOR",
      "sheetId": "power_1200_POWER_MONITOR",
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1201"
        ],
        "sheetIds": [
          "power_1200_POWER_MONITOR"
        ],
        "units": [
          {
            "component": "power_U1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание ядра ПЛИС",
      "sourceSheetName": "1200_POWER_MONITOR",
      "sourceSheetId": "power_1200_POWER_MONITOR",
      "sourceFile": "1200_POWER_MONITOR.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet1300",
      "title": "1300_FPGA_AUX_1V8",
      "subtitle": "Вспомогательное питание ПЛИС 1,8 В",
      "description": "U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.",
      "refs": [
        "power_U1301"
      ],
      "role": "power",
      "x": 40,
      "y": 40,
      "w": 330,
      "h": 172,
      "sceneId": "power_1300_FPGA_AUX_1V8",
      "sheetId": "power_1300_FPGA_AUX_1V8",
      "sourceSheetIds": [
        "power_1300_FPGA_AUX_1V8"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1301"
        ],
        "sheetIds": [
          "power_1300_FPGA_AUX_1V8"
        ],
        "units": [
          {
            "component": "power_U1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Вспомогательное питание ПЛИС 1,8 В",
      "sourceSheetName": "1300_FPGA_AUX_1V8",
      "sourceSheetId": "power_1300_FPGA_AUX_1V8",
      "sourceFile": "1300_FPGA_AUX_1V8.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet1400",
      "title": "1400_FPGA_AUX_2V5",
      "subtitle": "Вспомогательное питание 2,5 В",
      "description": "U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.",
      "refs": [
        "power_U1401"
      ],
      "role": "power",
      "x": 40,
      "y": 640,
      "w": 330,
      "h": 172,
      "sceneId": "power_1400_FPGA_AUX_2V5",
      "sheetId": "power_1400_FPGA_AUX_2V5",
      "sourceSheetIds": [
        "power_1400_FPGA_AUX_2V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1401"
        ],
        "sheetIds": [
          "power_1400_FPGA_AUX_2V5"
        ],
        "units": [
          {
            "component": "power_U1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Вспомогательное питание 2,5 В",
      "sourceSheetName": "1400_FPGA_AUX_2V5",
      "sourceSheetId": "power_1400_FPGA_AUX_2V5",
      "sourceFile": "1400_FPGA_AUX_2V5.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet1500",
      "title": "1500_FPGA_IO_3V3",
      "subtitle": "Питание выводов ПЛИС 3,3 В",
      "description": "U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.",
      "refs": [
        "power_U1501"
      ],
      "role": "power",
      "x": 520,
      "y": 40,
      "w": 350,
      "h": 182,
      "sceneId": "power_1500_FPGA_IO_3V3",
      "sheetId": "power_1500_FPGA_IO_3V3",
      "sourceSheetIds": [
        "power_1500_FPGA_IO_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1501"
        ],
        "sheetIds": [
          "power_1500_FPGA_IO_3V3"
        ],
        "units": [
          {
            "component": "power_U1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание выводов ПЛИС 3,3 В",
      "sourceSheetName": "1500_FPGA_IO_3V3",
      "sourceSheetId": "power_1500_FPGA_IO_3V3",
      "sourceFile": "1500_FPGA_IO_3V3.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1600",
      "title": "1600_DDR_1V35",
      "subtitle": "Питание памяти DDR3L",
      "description": "U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.",
      "refs": [
        "power_U1601"
      ],
      "role": "power",
      "x": 1070,
      "y": 70,
      "w": 410,
      "h": 210,
      "sceneId": "power_1600_DDR_1V35",
      "sheetId": "power_1600_DDR_1V35",
      "sourceSheetIds": [
        "power_1600_DDR_1V35"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1601"
        ],
        "sheetIds": [
          "power_1600_DDR_1V35"
        ],
        "units": [
          {
            "component": "power_U1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание памяти DDR3L",
      "sourceSheetName": "1600_DDR_1V35",
      "sourceSheetId": "power_1600_DDR_1V35",
      "sourceFile": "1600_DDR_1V35.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet1700",
      "title": "1700_PHY_1V05",
      "subtitle": "Питание ядра Ethernet PHY",
      "description": "U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.",
      "refs": [
        "power_U1701"
      ],
      "role": "power",
      "x": 1650,
      "y": 70,
      "w": 330,
      "h": 174,
      "sceneId": "power_1700_PHY_1V05",
      "sheetId": "power_1700_PHY_1V05",
      "sourceSheetIds": [
        "power_1700_PHY_1V05"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1701"
        ],
        "sheetIds": [
          "power_1700_PHY_1V05"
        ],
        "units": [
          {
            "component": "power_U1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание ядра Ethernet PHY",
      "sourceSheetName": "1700_PHY_1V05",
      "sourceSheetId": "power_1700_PHY_1V05",
      "sourceFile": "1700_PHY_1V05.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "sheet1800",
      "title": "1800_DDR_VTT_REFERENCE",
      "subtitle": "Питание и опора терминации DDR",
      "description": "U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.",
      "refs": [
        "power_U1801"
      ],
      "role": "power",
      "x": 1110,
      "y": 475,
      "w": 330,
      "h": 172,
      "sceneId": "power_1800_DDR_VTT_REFERENCE",
      "sheetId": "power_1800_DDR_VTT_REFERENCE",
      "sourceSheetIds": [
        "power_1800_DDR_VTT_REFERENCE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1801"
        ],
        "sheetIds": [
          "power_1800_DDR_VTT_REFERENCE"
        ],
        "units": [
          {
            "component": "power_U1801",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание и опора терминации DDR",
      "sourceSheetName": "1800_DDR_VTT_REFERENCE",
      "sourceSheetId": "power_1800_DDR_VTT_REFERENCE",
      "sourceFile": "1800_DDR_VTT_REFERENCE.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet1900",
      "title": "1900_ANALOG_5V",
      "subtitle": "Малошумящее аналоговое питание 5 В",
      "description": "U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.",
      "refs": [
        "power_U1901"
      ],
      "role": "power",
      "x": 1650,
      "y": 395,
      "w": 350,
      "h": 182,
      "sceneId": "power_1900_ANALOG_5V",
      "sheetId": "power_1900_ANALOG_5V",
      "sourceSheetIds": [
        "power_1900_ANALOG_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1901"
        ],
        "sheetIds": [
          "power_1900_ANALOG_5V"
        ],
        "units": [
          {
            "component": "power_U1901",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Малошумящее аналоговое питание 5 В",
      "sourceSheetName": "1900_ANALOG_5V",
      "sourceSheetId": "power_1900_ANALOG_5V",
      "sourceFile": "1900_ANALOG_5V.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet2000",
      "title": "2000_ANALOG_3V3",
      "subtitle": "Малошумящее аналоговое питание 3,3 В",
      "description": "U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.",
      "refs": [
        "power_U2001"
      ],
      "role": "power",
      "x": 1650,
      "y": 720,
      "w": 350,
      "h": 182,
      "sceneId": "power_2000_ANALOG_3V3",
      "sheetId": "power_2000_ANALOG_3V3",
      "sourceSheetIds": [
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2001"
        ],
        "sheetIds": [
          "power_2000_ANALOG_3V3"
        ],
        "units": [
          {
            "component": "power_U2001",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Малошумящее аналоговое питание 3,3 В",
      "sourceSheetName": "2000_ANALOG_3V3",
      "sourceSheetId": "power_2000_ANALOG_3V3",
      "sourceFile": "2000_ANALOG_3V3.kicad_sch",
      "layoutRole": "bank"
    }
  ],
  "edges": [],
  "bounds": {
    "x": -28,
    "y": -49,
    "w": 2096,
    "h": 1016
  },
  "board": "power",
  "sheetIds": [
    "power_1200_POWER_MONITOR",
    "power_1300_FPGA_AUX_1V8",
    "power_1400_FPGA_AUX_2V5",
    "power_1500_FPGA_IO_3V3",
    "power_1600_DDR_1V35",
    "power_1700_PHY_1V05",
    "power_1800_DDR_VTT_REFERENCE",
    "power_1900_ANALOG_5V",
    "power_2000_ANALOG_3V3"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1201",
      "power_U1301",
      "power_U1401",
      "power_U1501",
      "power_U1601",
      "power_U1701",
      "power_U1801",
      "power_U1901",
      "power_U2001"
    ],
    "sheetIds": [
      "power_1200_POWER_MONITOR",
      "power_1300_FPGA_AUX_1V8",
      "power_1400_FPGA_AUX_2V5",
      "power_1500_FPGA_IO_3V3",
      "power_1600_DDR_1V35",
      "power_1700_PHY_1V05",
      "power_1800_DDR_VTT_REFERENCE",
      "power_1900_ANALOG_5V",
      "power_2000_ANALOG_3V3"
    ],
    "units": [
      {
        "component": "power_U1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_U1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_U1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_U1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_U1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_U1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_U1801",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_U1901",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_U2001",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power-secondary"
  ],
  "suggestedScenario": "local-power-secondary",
  "explanationTitleRu": "Питание отдельных нагрузок",
  "sourceSheetId": "power_SECONDARY_POWER",
  "sourceSheetName": "SECONDARY_POWER",
  "sourceFile": "SECONDARY_POWER.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power",
  "layout": {
    "version": 2,
    "kind": "secondary-domain-clusters",
    "label": "Домены ПЛИС, памяти и малошумящего аналогового питания",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": -14,
      "w": 886,
      "h": 851,
      "title": "ПЛИС · ядро и вспомогательные домены",
      "kind": "primary",
      "nodeIds": [
        "sheet1200",
        "sheet1300",
        "sheet1400",
        "sheet1500"
      ]
    },
    {
      "x": 1042,
      "y": 16,
      "w": 466,
      "h": 656,
      "title": "Память DDR",
      "kind": "primary",
      "nodeIds": [
        "sheet1600",
        "sheet1800"
      ]
    },
    {
      "x": 1622,
      "y": 341,
      "w": 406,
      "h": 586,
      "title": "Аналоговые домены",
      "kind": "primary",
      "nodeIds": [
        "sheet1900",
        "sheet2000"
      ]
    }
  ]
};
