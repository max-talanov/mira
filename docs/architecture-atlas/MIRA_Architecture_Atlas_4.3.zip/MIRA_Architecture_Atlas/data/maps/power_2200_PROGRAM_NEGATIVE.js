/* Editable functional scene: power_2200_PROGRAM_NEGATIVE */
window.MIRA_FUNCTIONAL.scenes["power_2200_PROGRAM_NEGATIVE"]={
  "id": "power_2200_PROGRAM_NEGATIVE",
  "title": "2200_PROGRAM_NEGATIVE",
  "subtitle": "Коммутация отрицательного питания записи",
  "description": "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом.",
  "nodes": [
    {
      "id": "switch",
      "title": "Подключение отрицательной шины",
      "subtitle": "",
      "description": "Ключи подключают или изолируют отрицательное питание программирования.",
      "refs": [
        "power_Q2201",
        "power_Q2202",
        "power_Q2203",
        "power_Q2204",
        "power_R2202",
        "power_R2204",
        "power_C2203",
        "power_R2209",
        "power_R2211",
        "power_R2210",
        "power_C2201"
      ],
      "role": "power",
      "x": 620,
      "y": 220,
      "w": 370,
      "h": 194,
      "sheetId": "power_2200_PROGRAM_NEGATIVE",
      "sourceSheetIds": [
        "power_2200_PROGRAM_NEGATIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q2201",
          "power_Q2202",
          "power_Q2203",
          "power_Q2204",
          "power_R2202",
          "power_R2204",
          "power_C2203",
          "power_R2209",
          "power_R2211",
          "power_R2210",
          "power_C2201"
        ],
        "sheetIds": [
          "power_2200_PROGRAM_NEGATIVE"
        ],
        "units": [
          {
            "component": "power_C2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_C2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_Q2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_Q2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_Q2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_Q2204",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2204",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2209",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2210",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2211",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "control",
      "title": "Развязанная передача команд",
      "subtitle": "",
      "description": "Оптопары передают команды в домен управления затворами отрицательной шины.",
      "refs": [
        "power_U2201",
        "power_U2202",
        "power_U2203",
        "power_R2208",
        "power_R2201",
        "power_R2206",
        "power_R2203"
      ],
      "role": "control",
      "x": 40,
      "y": 60,
      "w": 270,
      "h": 144,
      "sheetId": "power_2200_PROGRAM_NEGATIVE",
      "sourceSheetIds": [
        "power_2200_PROGRAM_NEGATIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2201",
          "power_U2202",
          "power_U2203",
          "power_R2208",
          "power_R2201",
          "power_R2206",
          "power_R2203"
        ],
        "sheetIds": [
          "power_2200_PROGRAM_NEGATIVE"
        ],
        "units": [
          {
            "component": "power_R2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2206",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2208",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "clamp",
      "title": "Ограничение затвора и выхода",
      "subtitle": "",
      "description": "Диодная сеть формирует показанные на схеме защитные и ограничивающие пути источника.",
      "refs": [
        "power_D2201",
        "power_D2202",
        "power_D2203",
        "power_D2204",
        "power_R2205",
        "power_R2207",
        "power_C2202"
      ],
      "role": "fault",
      "x": 55,
      "y": 510,
      "w": 250,
      "h": 132,
      "sheetId": "power_2200_PROGRAM_NEGATIVE",
      "sourceSheetIds": [
        "power_2200_PROGRAM_NEGATIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_D2201",
          "power_D2202",
          "power_D2203",
          "power_D2204",
          "power_R2205",
          "power_R2207",
          "power_C2202"
        ],
        "sheetIds": [
          "power_2200_PROGRAM_NEGATIVE"
        ],
        "units": [
          {
            "component": "power_C2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_D2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_D2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_D2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_D2204",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2205",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_R2207",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "switch_control",
      "from": "switch",
      "to": "control",
      "label": "4 цепи",
      "type": "data",
      "nets": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MATRIX_N_GATE",
        "MATRIX_N_SOURCE"
      ],
      "unnamedNetIds": [
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "labelLines": [
        "MATRIX_N_GATE",
        "MATRIX_N_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "switch_clamp",
      "from": "switch",
      "to": "clamp",
      "label": "4 цепи",
      "type": "data",
      "nets": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MATRIX_N_GATE",
        "MATRIX_N_SOURCE"
      ],
      "unnamedNetIds": [
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "labelLines": [
        "MATRIX_N_GATE",
        "MATRIX_N_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "control_clamp",
      "from": "control",
      "to": "clamp",
      "label": "4 цепи",
      "type": "data",
      "nets": [
        "power_net_cb68ff534fc3",
        "power_net_646f65822b1f",
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MATRIX_N_GATE",
        "MATRIX_N_SOURCE"
      ],
      "unnamedNetIds": [
        "power_net_55db14645113",
        "power_net_77d673a9c74f"
      ],
      "labelLines": [
        "MATRIX_N_GATE",
        "MATRIX_N_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 1030,
    "h": 657
  },
  "board": "power",
  "sheetId": "power_2200_PROGRAM_NEGATIVE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 25,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_Q2201",
      "power_Q2202",
      "power_Q2203",
      "power_Q2204",
      "power_R2202",
      "power_R2204",
      "power_C2203",
      "power_R2209",
      "power_R2211",
      "power_R2210",
      "power_C2201",
      "power_U2201",
      "power_U2202",
      "power_U2203",
      "power_R2208",
      "power_R2201",
      "power_R2206",
      "power_R2203",
      "power_D2201",
      "power_D2202",
      "power_D2203",
      "power_D2204",
      "power_R2205",
      "power_R2207",
      "power_C2202"
    ],
    "sheetIds": [
      "power_2200_PROGRAM_NEGATIVE"
    ],
    "units": [
      {
        "component": "power_C2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_C2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_Q2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_Q2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_Q2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_Q2204",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2204",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2209",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2210",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2211",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2206",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2208",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_C2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_D2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_D2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_D2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_D2204",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2205",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_R2207",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2200_PROGRAM_NEGATIVE"
  ],
  "suggestedScenario": "local-power_2200_PROGRAM_NEGATIVE",
  "explanationTitleRu": "Коммутация отрицательного питания записи",
  "sourceSheetId": "power_2200_PROGRAM_NEGATIVE",
  "sourceSheetName": "2200_PROGRAM_NEGATIVE",
  "sourceFile": "2200_PROGRAM_NEGATIVE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-program",
  "layout": {
    "version": 2,
    "kind": "switch-with-control",
    "label": "Силовые ключи, команда управления и отдельная защита",
    "geometryOnly": true
  },
  "regions": []
};
