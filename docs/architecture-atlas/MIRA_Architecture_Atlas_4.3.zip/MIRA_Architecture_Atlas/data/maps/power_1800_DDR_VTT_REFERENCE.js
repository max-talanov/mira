/* Editable functional scene: power_1800_DDR_VTT_REFERENCE */
window.MIRA_FUNCTIONAL.scenes["power_1800_DDR_VTT_REFERENCE"]={
  "id": "power_1800_DDR_VTT_REFERENCE",
  "title": "1800_DDR_VTT_REFERENCE",
  "subtitle": "Питание и опора терминации DDR",
  "description": "U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход DDR1V35",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1800_DDR_VTT_REFERENCE"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1800_DDR_VTT_REFERENCE"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Следящее питание терминации: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1801",
        "power_R1804"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1800_DDR_VTT_REFERENCE",
      "sourceSheetIds": [
        "power_1800_DDR_VTT_REFERENCE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1801",
          "power_R1804"
        ],
        "sheetIds": [
          "power_1800_DDR_VTT_REFERENCE"
        ],
        "units": [
          {
            "component": "power_R1804",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_U1801",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1801",
        "power_R1801"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1800_DDR_VTT_REFERENCE",
      "sourceSheetIds": [
        "power_1800_DDR_VTT_REFERENCE"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1801",
          "power_R1801"
        ],
        "sheetIds": [
          "power_1800_DDR_VTT_REFERENCE"
        ],
        "units": [
          {
            "component": "power_Q1801",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_R1801",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1806",
        "power_C1801",
        "power_C1805",
        "power_C1807",
        "power_C1804",
        "power_C1802",
        "power_C1803",
        "power_R1802",
        "power_R1803"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1800_DDR_VTT_REFERENCE",
      "sourceSheetIds": [
        "power_1800_DDR_VTT_REFERENCE"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1806",
          "power_C1801",
          "power_C1805",
          "power_C1807",
          "power_C1804",
          "power_C1802",
          "power_C1803",
          "power_R1802",
          "power_R1803"
        ],
        "sheetIds": [
          "power_1800_DDR_VTT_REFERENCE"
        ],
        "units": [
          {
            "component": "power_C1801",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_C1802",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_C1803",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_C1804",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_C1805",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_C1806",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_C1807",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_R1802",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_R1803",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход VTT",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1800_DDR_VTT_REFERENCE"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1800_DDR_VTT_REFERENCE"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "DDR1V35",
      "type": "power",
      "nets": [
        "power_net_f3a748e4fa19"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "DDR1V35",
      "netLabels": [
        "DDR1V35"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DDR1V35"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_e295c6eba3ce",
        "power_net_0ee4f5245d75",
        "power_net_ae048a8edaa8",
        "power_net_a494eb253ace",
        "power_net_49a6d57a88bc"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "VTT",
        "PGR_VTT",
        "CMD_VTT",
        "REFIN_VTT",
        "EN_VTT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_VTT · EN_VTT",
        "PGR_VTT · REFIN_VTT",
        "VTT"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "VTT",
      "type": "power",
      "nets": [
        "power_net_e295c6eba3ce"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "VTT",
      "netLabels": [
        "VTT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "VTT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_ae048a8edaa8",
        "power_net_49a6d57a88bc"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_VTT",
        "EN_VTT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_VTT",
        "EN_VTT"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1800_DDR_VTT_REFERENCE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1801",
      "power_R1804",
      "power_Q1801",
      "power_R1801",
      "power_C1806",
      "power_C1801",
      "power_C1805",
      "power_C1807",
      "power_C1804",
      "power_C1802",
      "power_C1803",
      "power_R1802",
      "power_R1803"
    ],
    "sheetIds": [
      "power_1800_DDR_VTT_REFERENCE"
    ],
    "units": [
      {
        "component": "power_R1804",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_U1801",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_Q1801",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_R1801",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1801",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1802",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1803",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1804",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1805",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1806",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_C1807",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_R1802",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_R1803",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1800_DDR_VTT_REFERENCE"
  ],
  "suggestedScenario": "local-power_1800_DDR_VTT_REFERENCE",
  "explanationTitleRu": "Питание и опора терминации DDR",
  "sourceSheetId": "power_1800_DDR_VTT_REFERENCE",
  "sourceSheetName": "1800_DDR_VTT_REFERENCE",
  "sourceFile": "1800_DDR_VTT_REFERENCE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
