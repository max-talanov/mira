/* Editable functional scene: power_1100_AFE_NEGATIVE_15V */
window.MIRA_FUNCTIONAL.scenes["power_1100_AFE_NEGATIVE_15V"]={
  "id": "power_1100_AFE_NEGATIVE_15V",
  "title": "1100_AFE_NEGATIVE_15V",
  "subtitle": "Отрицательное аналоговое питание",
  "description": "U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Отрицательная аналоговая шина: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1102",
        "power_L1101",
        "power_R1106"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1100_AFE_NEGATIVE_15V",
      "sourceSheetIds": [
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1102",
          "power_L1101",
          "power_R1106"
        ],
        "sheetIds": [
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": [
          {
            "component": "power_L1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1106",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U1102",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_U1101",
        "power_R1102",
        "power_R1101"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1100_AFE_NEGATIVE_15V",
      "sourceSheetIds": [
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1101",
          "power_R1102",
          "power_R1101"
        ],
        "sheetIds": [
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": [
          {
            "component": "power_R1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1102",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1109",
        "power_C1102",
        "power_C1101",
        "power_C1107",
        "power_C1103",
        "power_C1106",
        "power_C1105",
        "power_C1108",
        "power_C1104",
        "power_R1108",
        "power_R1103",
        "power_R1104",
        "power_R1105",
        "power_R1107",
        "power_D1101"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1100_AFE_NEGATIVE_15V",
      "sourceSheetIds": [
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1109",
          "power_C1102",
          "power_C1101",
          "power_C1107",
          "power_C1103",
          "power_C1106",
          "power_C1105",
          "power_C1108",
          "power_C1104",
          "power_R1108",
          "power_R1103",
          "power_R1104",
          "power_R1105",
          "power_R1107",
          "power_D1101"
        ],
        "sheetIds": [
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": [
          {
            "component": "power_C1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1102",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1103",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1104",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1105",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1106",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1107",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1108",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1109",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_D1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1103",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1104",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1105",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1107",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1108",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход N15",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_afd79c7e6e58",
        "power_net_85fba6457595",
        "power_net_c215e379dc64",
        "power_net_50ecae0bf119",
        "power_net_1f3c8d72605a",
        "power_net_34b1e1d7c8f5"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "CMD_N15",
        "N15_RAW",
        "N15",
        "CB_N15",
        "EN_N15",
        "FB_N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CB_N15 · CMD_N15",
        "EN_N15 · FB_N15",
        "N15 · N15_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "N15",
      "type": "power",
      "nets": [
        "power_net_c215e379dc64"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "N15",
      "netLabels": [
        "N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "N15"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_afd79c7e6e58",
        "power_net_1f3c8d72605a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_N15",
        "EN_N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_N15",
        "EN_N15"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1100_AFE_NEGATIVE_15V",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 21,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1102",
      "power_L1101",
      "power_R1106",
      "power_U1101",
      "power_R1102",
      "power_R1101",
      "power_C1109",
      "power_C1102",
      "power_C1101",
      "power_C1107",
      "power_C1103",
      "power_C1106",
      "power_C1105",
      "power_C1108",
      "power_C1104",
      "power_R1108",
      "power_R1103",
      "power_R1104",
      "power_R1105",
      "power_R1107",
      "power_D1101"
    ],
    "sheetIds": [
      "power_1100_AFE_NEGATIVE_15V"
    ],
    "units": [
      {
        "component": "power_L1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1106",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1102",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1102",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1102",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1103",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1104",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1105",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1106",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1107",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1108",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1109",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_D1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1103",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1104",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1105",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1107",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1108",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1100_AFE_NEGATIVE_15V"
  ],
  "suggestedScenario": "local-power_1100_AFE_NEGATIVE_15V",
  "explanationTitleRu": "Отрицательное аналоговое питание",
  "sourceSheetId": "power_1100_AFE_NEGATIVE_15V",
  "sourceSheetName": "1100_AFE_NEGATIVE_15V",
  "sourceFile": "1100_AFE_NEGATIVE_15V.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
