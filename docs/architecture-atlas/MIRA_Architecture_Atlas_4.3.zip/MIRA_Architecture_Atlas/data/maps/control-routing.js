/* Editable functional scene: control-routing */
window.MIRA_FUNCTIONAL.scenes["control-routing"]={
  "id": "control-routing",
  "title": "MATRIX",
  "subtitle": "Фиксация и коммутация операции",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet1300",
      "title": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "subtitle": "Проверка согласованности операции",
      "description": "U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния.",
      "refs": [
        "control_U1319",
        "control_U1306",
        "control_U1305",
        "control_U1304",
        "control_U1312",
        "control_U1313"
      ],
      "role": "analog",
      "x": 40,
      "y": 300,
      "w": 410,
      "h": 210,
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1319",
          "control_U1306",
          "control_U1305",
          "control_U1304",
          "control_U1312",
          "control_U1313"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_U1304",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1305",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1306",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1312",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1313",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1319",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Проверка согласованности операции",
      "sourceSheetName": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceFile": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet1400",
      "title": "1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "subtitle": "80-битное состояние ключей",
      "description": "U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий.",
      "refs": [
        "control_U1404",
        "control_U1408",
        "control_U1401",
        "control_U1405",
        "control_U1403",
        "control_U1400"
      ],
      "role": "analog",
      "x": 520,
      "y": 70,
      "w": 330,
      "h": 174,
      "sceneId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sourceSheetIds": [
        "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1404",
          "control_U1408",
          "control_U1401",
          "control_U1405",
          "control_U1403",
          "control_U1400"
        ],
        "sheetIds": [
          "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
        ],
        "units": [
          {
            "component": "control_U1400",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1401",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1403",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1404",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1405",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1408",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "80-битное состояние ключей",
      "sourceSheetName": "1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sourceSheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sourceFile": "1400_MATRIX_SERIAL_CONTROL_REGISTERS.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "sheet1500",
      "title": "1500_MATRIX_BL0_31_SWITCHING",
      "subtitle": "Коммутация битовых линий матрицы",
      "description": "Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение.",
      "refs": [
        "control_U1500",
        "control_U1503",
        "control_U1508",
        "control_U1513",
        "control_U1506",
        "control_U1502"
      ],
      "role": "analog",
      "x": 1010,
      "y": 70,
      "w": 330,
      "h": 174,
      "sceneId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sourceSheetIds": [
        "control_1500_MATRIX_BL0_31_SWITCHING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1500",
          "control_U1503",
          "control_U1508",
          "control_U1513",
          "control_U1506",
          "control_U1502"
        ],
        "sheetIds": [
          "control_1500_MATRIX_BL0_31_SWITCHING"
        ],
        "units": [
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          }
        ]
      },
      "explanationTitleRu": "Коммутация битовых линий матрицы",
      "sourceSheetName": "1500_MATRIX_BL0_31_SWITCHING",
      "sourceSheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sourceFile": "1500_MATRIX_BL0_31_SWITCHING.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1600",
      "title": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "subtitle": "Выбор источника, банка и полярности",
      "description": "Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике.",
      "refs": [
        "control_U1601",
        "control_U1600",
        "control_U1602",
        "control_U1603"
      ],
      "role": "analog",
      "x": 520,
      "y": 620,
      "w": 330,
      "h": 174,
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceSheetIds": [
        "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1601",
          "control_U1600",
          "control_U1602",
          "control_U1603"
        ],
        "sheetIds": [
          "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
        ],
        "units": [
          {
            "component": "control_U1600",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1601",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 2
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 3
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 4
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 5
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 2
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 3
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 4
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 5
          }
        ]
      },
      "explanationTitleRu": "Выбор источника, банка и полярности",
      "sourceSheetName": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceSheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceFile": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1700",
      "title": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "subtitle": "Выбор строк и измерительных линий",
      "description": "U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата.",
      "refs": [
        "control_U1703",
        "control_U1700",
        "control_U1701",
        "control_U1702",
        "control_U1704",
        "control_U1705"
      ],
      "role": "analog",
      "x": 1010,
      "y": 620,
      "w": 330,
      "h": 174,
      "sceneId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceSheetIds": [
        "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1703",
          "control_U1700",
          "control_U1701",
          "control_U1702",
          "control_U1704",
          "control_U1705"
        ],
        "sheetIds": [
          "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
        ],
        "units": [
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          },
          {
            "component": "control_U1704",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1705",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Выбор строк и измерительных линий",
      "sourceSheetName": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceSheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceFile": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1800",
      "title": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "subtitle": "Подключение экспериментальной матрицы",
      "description": "J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня.",
      "refs": [
        "control_J1800",
        "control_J1802",
        "control_J1801"
      ],
      "role": "analog",
      "x": 1490,
      "y": 320,
      "w": 410,
      "h": 210,
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "sheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "sourceSheetIds": [
        "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
      ],
      "circuitGroup": {
        "refs": [
          "control_J1800",
          "control_J1802",
          "control_J1801"
        ],
        "sheetIds": [
          "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
        ],
        "units": [
          {
            "component": "control_J1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_J1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 2
          },
          {
            "component": "control_J1801",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_J1802",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Подключение экспериментальной матрицы",
      "sourceSheetName": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "sourceSheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "sourceFile": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS.kicad_sch",
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "sheet1400_sheet1500",
      "from": "sheet1400",
      "to": "sheet1500",
      "label": "64 цепи",
      "type": "analog",
      "nets": [
        "control_net_57236d4b4e50",
        "control_net_70c03a238d66",
        "control_net_7e66df34c1cb",
        "control_net_e2ace5299f00",
        "control_net_f498b034d47c",
        "control_net_dfebfa8ce954",
        "control_net_8cec06d0a68e",
        "control_net_91367f0adb00",
        "control_net_4e889b41bce9",
        "control_net_4f58db14a2f0",
        "control_net_8ae298951006",
        "control_net_c7a227845fc4",
        "control_net_aa8081055225",
        "control_net_38aa1b871436",
        "control_net_30da3c89e6b0",
        "control_net_27e11deab85a",
        "control_net_77dec07465d1",
        "control_net_76168421ae64",
        "control_net_01c0ad0ef8f8",
        "control_net_5e01c47f5c29",
        "control_net_35c00105d395",
        "control_net_48fcc210d1f6",
        "control_net_31367ce75c40",
        "control_net_282ba042f616",
        "control_net_acd932993b7b",
        "control_net_2f56e21bf1c8",
        "control_net_e9062516eb43",
        "control_net_d24d5fdebd2d",
        "control_net_e542c28a3215",
        "control_net_c20b4b863473",
        "control_net_adcb6c1bfe2e",
        "control_net_2595b3f207c1",
        "control_net_3e8175ead30c",
        "control_net_699b10c0cb1f",
        "control_net_928a45524bd4",
        "control_net_51b3012894bb",
        "control_net_853be9b7ad24",
        "control_net_48cbd08d5e88",
        "control_net_5e93332cd041",
        "control_net_45c19501bad5",
        "control_net_db3c5d849c82",
        "control_net_37fa60099550",
        "control_net_b211580c8101",
        "control_net_4aefa7bda0e0",
        "control_net_2bbd0dc06c6f",
        "control_net_c8a58330532e",
        "control_net_24fd3915e934",
        "control_net_a3db8189ec60",
        "control_net_287cfdf7ef3f",
        "control_net_ac7e9e00c8b3",
        "control_net_42dd32d2dba8",
        "control_net_ad6ab5928142",
        "control_net_cc7e68c63366",
        "control_net_c771f664cff1",
        "control_net_d948d4dd3369",
        "control_net_fbc93a9a1f13",
        "control_net_bb256500c151",
        "control_net_724ff3a3348c",
        "control_net_323da0f3bc1f",
        "control_net_39c83bb6d20e",
        "control_net_dcf3a56694f7",
        "control_net_a275f9d9677f",
        "control_net_aad969376bf0",
        "control_net_e85cee5f43f2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "64 цепи",
      "netLabels": [
        "MAT_BL_ZERO_11",
        "MAT_BL_VMM_28",
        "MAT_BL_VMM_10",
        "MAT_BL_ZERO_10",
        "MAT_BL_VMM_6",
        "MAT_BL_VMM_29",
        "MAT_BL_ZERO_31",
        "MAT_BL_VMM_16",
        "MAT_BL_ZERO_25",
        "MAT_BL_ZERO_27",
        "MAT_BL_VMM_0",
        "MAT_BL_ZERO_7",
        "MAT_BL_VMM_12",
        "MAT_BL_ZERO_19",
        "MAT_BL_VMM_11",
        "MAT_BL_VMM_17",
        "MAT_BL_ZERO_26",
        "MAT_BL_ZERO_13",
        "MAT_BL_VMM_1",
        "MAT_BL_ZERO_0",
        "MAT_BL_ZERO_16",
        "MAT_BL_VMM_14",
        "MAT_BL_ZERO_23",
        "MAT_BL_VMM_15",
        "MAT_BL_VMM_18",
        "MAT_BL_VMM_24",
        "MAT_BL_ZERO_5",
        "MAT_BL_ZERO_14",
        "MAT_BL_ZERO_17",
        "MAT_BL_ZERO_3",
        "MAT_BL_ZERO_1",
        "MAT_BL_VMM_19",
        "MAT_BL_VMM_5",
        "MAT_BL_ZERO_24",
        "MAT_BL_VMM_8",
        "MAT_BL_ZERO_20",
        "MAT_BL_ZERO_29",
        "MAT_BL_VMM_20",
        "MAT_BL_VMM_22",
        "MAT_BL_VMM_30",
        "MAT_BL_ZERO_8",
        "MAT_BL_ZERO_22",
        "MAT_BL_VMM_25",
        "MAT_BL_VMM_9",
        "MAT_BL_VMM_31",
        "MAT_BL_ZERO_15",
        "MAT_BL_VMM_23",
        "MAT_BL_VMM_4",
        "MAT_BL_ZERO_18",
        "MAT_BL_VMM_21",
        "MAT_BL_ZERO_30",
        "MAT_BL_ZERO_9",
        "MAT_BL_VMM_27",
        "MAT_BL_ZERO_28",
        "MAT_BL_VMM_26",
        "MAT_BL_ZERO_4",
        "MAT_BL_VMM_3",
        "MAT_BL_ZERO_21",
        "MAT_BL_VMM_2",
        "MAT_BL_ZERO_6",
        "MAT_BL_ZERO_2",
        "MAT_BL_VMM_7",
        "MAT_BL_ZERO_12",
        "MAT_BL_VMM_13"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_ZERO_11 · MAT_BL_VMM_28",
        "MAT_BL_VMM_10 · ещё 61"
      ],
      "allConnectionsLabel": "Все соединения: 64",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1500_sheet1800",
      "from": "sheet1500",
      "to": "sheet1800",
      "label": "32 цепи",
      "type": "data",
      "nets": [
        "control_net_410ce51ce77b",
        "control_net_5b7588c91934",
        "control_net_96843655892a",
        "control_net_ef57e67af6ee",
        "control_net_a38212b18dab",
        "control_net_cb9a53bc7e2d",
        "control_net_b1a7be433721",
        "control_net_5a6f03bbf06c",
        "control_net_f237bfeb4d31",
        "control_net_7deb95e626ac",
        "control_net_dee259c78870",
        "control_net_30db039e0318",
        "control_net_538bdbb480c1",
        "control_net_9aa6ed5fa484",
        "control_net_af268a134ce7",
        "control_net_2661b7e1d1d8",
        "control_net_7443657d6bc7",
        "control_net_8c1f7a16a91f",
        "control_net_9037a6d55684",
        "control_net_e59cadbe90ef",
        "control_net_77eb74275447",
        "control_net_331bcbe5832b",
        "control_net_da64d12ab5ef",
        "control_net_668f023fd21c",
        "control_net_15a5f03664b6",
        "control_net_0066c578f4fd",
        "control_net_ae5aa8c25d68",
        "control_net_76481426c5c9",
        "control_net_36b8e2744fa2",
        "control_net_06c41da37048",
        "control_net_093450c5090e",
        "control_net_a3c1624fed4f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "32 цепи",
      "netLabels": [
        "BL5",
        "BL12",
        "BL7",
        "BL8",
        "BL11",
        "BL22",
        "BL10",
        "BL27",
        "BL20",
        "BL28",
        "BL9",
        "BL4",
        "BL3",
        "BL15",
        "BL0",
        "BL14",
        "BL2",
        "BL17",
        "BL29",
        "BL30",
        "BL6",
        "BL1",
        "BL13",
        "BL26",
        "BL18",
        "BL23",
        "BL31",
        "BL16",
        "BL21",
        "BL25",
        "BL19",
        "BL24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL5 · BL12",
        "BL7 · ещё 29"
      ],
      "allConnectionsLabel": "Все соединения: 32",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1400_sheet1700",
      "from": "sheet1400",
      "to": "sheet1700",
      "label": "16 цепей",
      "type": "analog",
      "nets": [
        "control_net_6597f27cfc2b",
        "control_net_52153a3ca99d",
        "control_net_45ab5f0aea68",
        "control_net_09be2b97e593",
        "control_net_1f62e25a43f4",
        "control_net_6cd7e17461df",
        "control_net_582519679d90",
        "control_net_03726fa80526",
        "control_net_18924996523a",
        "control_net_86b7951f0b9b",
        "control_net_6f8884418f43",
        "control_net_be1982fe6067",
        "control_net_b2b91481bc2e",
        "control_net_a335d291d1da",
        "control_net_df58d9efe6ea",
        "control_net_c04b6da19edd"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "16 цепей",
      "netLabels": [
        "MAT_WL_ON_5",
        "MAT_WL_ON_7",
        "MAT_WL_ON_6",
        "MAT_NL_ZERO_1",
        "MAT_WL_ON_3",
        "MAT_NL_ZERO_4",
        "MAT_NL_ZERO_0",
        "MAT_WL_ON_0",
        "MAT_WL_ON_4",
        "MAT_NL_ZERO_6",
        "MAT_WL_ON_1",
        "MAT_NL_ZERO_3",
        "MAT_WL_ON_2",
        "MAT_NL_ZERO_5",
        "MAT_NL_ZERO_2",
        "MAT_NL_ZERO_7"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_WL_ON_5 · MAT_WL_ON_7",
        "MAT_WL_ON_6 · ещё 13"
      ],
      "allConnectionsLabel": "Все соединения: 16",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "sheet1700_sheet1800",
      "from": "sheet1700",
      "to": "sheet1800",
      "label": "16 цепей",
      "type": "analog",
      "nets": [
        "control_net_c494e5a21fb7",
        "control_net_5ef23046b636",
        "control_net_747cc492238d",
        "control_net_945cddbc767f",
        "control_net_3762f1a58fed",
        "control_net_b0ea7c0c27c3",
        "control_net_edac321adbf1",
        "control_net_5212ff00c1ac",
        "control_net_3c196a06fe86",
        "control_net_d380ae123eb3",
        "control_net_79947d226d73",
        "control_net_fca0e6b6f6af",
        "control_net_e8ccb5161adb",
        "control_net_072af1a28ea6",
        "control_net_e4379a2b0f61",
        "control_net_919f25939ba9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "16 цепей",
      "netLabels": [
        "WL1",
        "WL6",
        "WL7",
        "WL2",
        "NL2",
        "WL4",
        "WL0",
        "NL7",
        "WL3",
        "NL3",
        "NL0",
        "WL5",
        "NL5",
        "NL6",
        "NL1",
        "NL4"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "WL1 · WL6",
        "WL7 · ещё 13"
      ],
      "allConnectionsLabel": "Все соединения: 16",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1300_sheet1600",
      "from": "sheet1300",
      "to": "sheet1600",
      "label": "9 цепей",
      "type": "analog",
      "nets": [
        "control_net_53c8d7c2e621",
        "control_net_69c914a4b819",
        "control_net_209d9624cc4d",
        "control_net_24511a425a2f",
        "control_net_3f65bb4e6c1b",
        "control_net_1548c2f283f9",
        "control_net_17e2493797cd",
        "control_net_5a48e06ad240",
        "control_net_c3b957dc2a05"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "9 цепей",
      "netLabels": [
        "MAT_SRC_A1",
        "MAT_WRITE_SAFE",
        "MAT_SERVICE_SAFE",
        "MAT_BL_A4",
        "MAT_BL_A3",
        "MAT_READ_SAFE",
        "MAT_SOURCE_SAFE",
        "MAT_POLARITY",
        "MAT_SRC_A0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_SRC_A1 · MAT_WRITE_SAFE",
        "MAT_SERVICE_SAFE · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1300_sheet1400",
      "from": "sheet1300",
      "to": "sheet1400",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_d0ee9c0888fb",
        "control_net_c73ef0628409",
        "control_net_2e40141f478d",
        "control_net_f05b5740e1a9",
        "control_net_770516324e4c",
        "control_net_671137df6d42",
        "control_net_0831bf7686e1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "MAT_ALLOWED",
        "MAT_OE_N",
        "MAT_CONFIG_LATCH",
        "MAT_SPI_MOSI",
        "MAT_SPI_SCK",
        "MAT_VMM_OE_N",
        "MAT_SPI_OE_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ALLOWED",
        "MAT_CONFIG_LATCH",
        "MAT_OE_N",
        "MAT_SPI_MOSI",
        "MAT_SPI_OE_N",
        "MAT_SPI_SCK",
        "MAT_VMM_OE_N"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1300_sheet1700",
      "from": "sheet1300",
      "to": "sheet1700",
      "label": "5 цепей",
      "type": "analog",
      "nets": [
        "control_net_3f3c0536dd7c",
        "control_net_12757af1d119",
        "control_net_209d9624cc4d",
        "control_net_7a2e58dd0886",
        "control_net_558e432b5f50"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "5 цепей",
      "netLabels": [
        "MAT_VMM_DRIVE_SAFE",
        "MAT_NL_A1",
        "MAT_SERVICE_SAFE",
        "MAT_NL_A2",
        "MAT_NL_A0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_NL_A0",
        "MAT_NL_A1",
        "MAT_NL_A2",
        "MAT_SERVICE_SAFE",
        "MAT_VMM_DRIVE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1500_sheet1600",
      "from": "sheet1500",
      "to": "sheet1600",
      "label": "5 цепей",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_e35a26b2e235",
        "control_net_c3af5f92c044",
        "control_net_435ce00e5df8",
        "control_net_42857bff9d0c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "5 цепей",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_BANK_0",
        "MAT_BL_BANK_3",
        "MAT_BL_BANK_2",
        "MAT_BL_BANK_1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_BANK_0",
        "MAT_BL_BANK_1",
        "MAT_BL_BANK_2",
        "MAT_BL_BANK_3",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "sheet1300_sheet1500",
      "from": "sheet1300",
      "to": "sheet1500",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_5adbbaca70af",
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_BL_A1",
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1600_sheet1700",
      "from": "sheet1600",
      "to": "sheet1700",
      "label": "2 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_93f6dc0512af"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_NL_SERVICE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_SERVICE_SAFE",
        "MAT_NL_SERVICE"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1500_sheet1700",
      "from": "sheet1500",
      "to": "sheet1700",
      "label": "MAT_SERVICE_SAFE",
      "type": "data",
      "nets": [
        "control_net_209d9624cc4d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_SERVICE_SAFE",
      "netLabels": [
        "MAT_SERVICE_SAFE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 1940,
    "h": 799
  },
  "board": "control",
  "sheetIds": [
    "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
    "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
    "control_1500_MATRIX_BL0_31_SWITCHING",
    "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
    "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
    "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1319",
      "control_U1306",
      "control_U1305",
      "control_U1304",
      "control_U1312",
      "control_U1313",
      "control_U1404",
      "control_U1408",
      "control_U1401",
      "control_U1405",
      "control_U1403",
      "control_U1400",
      "control_U1500",
      "control_U1503",
      "control_U1508",
      "control_U1513",
      "control_U1506",
      "control_U1502",
      "control_U1601",
      "control_U1600",
      "control_U1602",
      "control_U1603",
      "control_U1703",
      "control_U1700",
      "control_U1701",
      "control_U1702",
      "control_U1704",
      "control_U1705",
      "control_J1800",
      "control_J1802",
      "control_J1801"
    ],
    "sheetIds": [
      "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "control_1500_MATRIX_BL0_31_SWITCHING",
      "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
    ],
    "units": [
      {
        "component": "control_U1304",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1305",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1306",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1312",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1313",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1319",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1400",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1401",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1403",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1404",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1405",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1408",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1600",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1601",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 2
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 3
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 4
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 5
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 2
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 3
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 4
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 5
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_U1704",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1705",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_J1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_J1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 2
      },
      {
        "component": "control_J1801",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_J1802",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-routing"
  ],
  "suggestedScenario": "local-control-routing",
  "explanationTitleRu": "Фиксация и коммутация операции",
  "sourceSheetId": "control_MATRIX",
  "sourceSheetName": "MATRIX",
  "sourceFile": "MATRIX.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "matrix-routing",
    "label": "Разрешённые команды, банки ключей и разъём матрицы",
    "geometryOnly": true
  },
  "regions": []
};
