/* Editable functional scene: power_2000_ANALOG_3V3 */
window.MIRA_FUNCTIONAL.scenes["power_2000_ANALOG_3V3"]={
  "id": "power_2000_ANALOG_3V3",
  "title": "2000_ANALOG_3V3",
  "subtitle": "Малошумящее аналоговое питание 3,3 В",
  "description": "U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход ANA5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_2000_ANALOG_3V3"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Малошумящее аналоговое питание 3,3 В: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U2001",
        "power_R2002"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_2000_ANALOG_3V3",
      "sourceSheetIds": [
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2001",
          "power_R2002"
        ],
        "sheetIds": [
          "power_2000_ANALOG_3V3"
        ],
        "units": [
          {
            "component": "power_R2002",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_U2001",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q2001",
        "power_R2001"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_2000_ANALOG_3V3",
      "sourceSheetIds": [
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q2001",
          "power_R2001"
        ],
        "sheetIds": [
          "power_2000_ANALOG_3V3"
        ],
        "units": [
          {
            "component": "power_Q2001",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_R2001",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C2004",
        "power_C2003",
        "power_C2002",
        "power_C2001",
        "power_R2003",
        "power_R2004",
        "power_R2006",
        "power_R2005"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_2000_ANALOG_3V3",
      "sourceSheetIds": [
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_C2004",
          "power_C2003",
          "power_C2002",
          "power_C2001",
          "power_R2003",
          "power_R2004",
          "power_R2006",
          "power_R2005"
        ],
        "sheetIds": [
          "power_2000_ANALOG_3V3"
        ],
        "units": [
          {
            "component": "power_C2001",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_C2002",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_C2003",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_C2004",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_R2003",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_R2004",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_R2005",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          },
          {
            "component": "power_R2006",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход ANA3V3",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_2000_ANALOG_3V3"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "ANA5",
      "type": "power",
      "nets": [
        "power_net_f5932d689562"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "ANA5",
      "netLabels": [
        "ANA5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_2fb6eec8140e",
        "power_net_a207f0246008"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "ANA3V3",
        "ANA33_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA3V3",
        "ANA33_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "ANA3V3",
      "type": "power",
      "nets": [
        "power_net_2fb6eec8140e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "ANA3V3",
      "netLabels": [
        "ANA3V3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA3V3"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_55bbd3deed41",
        "power_net_8a3bb3e9fe35"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_ANA33",
        "EN_ANA33"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA33",
        "EN_ANA33"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_2000_ANALOG_3V3",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 12,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2001",
      "power_R2002",
      "power_Q2001",
      "power_R2001",
      "power_C2004",
      "power_C2003",
      "power_C2002",
      "power_C2001",
      "power_R2003",
      "power_R2004",
      "power_R2006",
      "power_R2005"
    ],
    "sheetIds": [
      "power_2000_ANALOG_3V3"
    ],
    "units": [
      {
        "component": "power_R2002",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_U2001",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_Q2001",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_R2001",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_C2001",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_C2002",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_C2003",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_C2004",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_R2003",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_R2004",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_R2005",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_R2006",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2000_ANALOG_3V3"
  ],
  "suggestedScenario": "local-power_2000_ANALOG_3V3",
  "explanationTitleRu": "Малошумящее аналоговое питание 3,3 В",
  "sourceSheetId": "power_2000_ANALOG_3V3",
  "sourceSheetName": "2000_ANALOG_3V3",
  "sourceFile": "2000_ANALOG_3V3.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
