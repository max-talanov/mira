/* Editable functional scene: power_2400_PM_CONTROLLER */
window.MIRA_FUNCTIONAL.scenes["power_2400_PM_CONTROLLER"]={
  "id": "power_2400_PM_CONTROLLER",
  "title": "2400_PM_CONTROLLER",
  "subtitle": "Контроллер последовательности питания",
  "description": "U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером.",
  "nodes": [
    {
      "id": "controller",
      "title": "Последовательность запуска и контроль",
      "subtitle": "",
      "description": "Контроллер питания STM32G0 выдаёт запросы включения шин и читает измерения и состояние.",
      "refs": [
        "power_U2401"
      ],
      "role": "control",
      "x": 40,
      "y": 180,
      "w": 350,
      "h": 184,
      "sheetId": "power_2400_PM_CONTROLLER",
      "sourceSheetIds": [
        "power_2400_PM_CONTROLLER"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2401"
        ],
        "sheetIds": [
          "power_2400_PM_CONTROLLER"
        ],
        "units": [
          {
            "component": "power_U2401",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "support",
      "title": "Обеспечение запуска контроллера",
      "subtitle": "",
      "description": "Локальные цепи питания и запуска обеспечивают работу контроллера питания.",
      "refs": [
        "power_C2404",
        "power_C2402",
        "power_C2405",
        "power_C2401",
        "power_C2403"
      ],
      "role": "power",
      "x": 760,
      "y": 195,
      "w": 280,
      "h": 150,
      "sheetId": "power_2400_PM_CONTROLLER",
      "sourceSheetIds": [
        "power_2400_PM_CONTROLLER"
      ],
      "circuitGroup": {
        "refs": [
          "power_C2404",
          "power_C2402",
          "power_C2405",
          "power_C2401",
          "power_C2403"
        ],
        "sheetIds": [
          "power_2400_PM_CONTROLLER"
        ],
        "units": [
          {
            "component": "power_C2401",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          },
          {
            "component": "power_C2402",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          },
          {
            "component": "power_C2403",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          },
          {
            "component": "power_C2404",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          },
          {
            "component": "power_C2405",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "controller_support",
      "from": "controller",
      "to": "support",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_67006db669b3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "AON"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AON"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1080,
    "h": 259
  },
  "board": "power",
  "sheetId": "power_2400_PM_CONTROLLER",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 6,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2401",
      "power_C2404",
      "power_C2402",
      "power_C2405",
      "power_C2401",
      "power_C2403"
    ],
    "sheetIds": [
      "power_2400_PM_CONTROLLER"
    ],
    "units": [
      {
        "component": "power_U2401",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_C2401",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_C2402",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_C2403",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_C2404",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_C2405",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2400_PM_CONTROLLER"
  ],
  "suggestedScenario": "local-power_2400_PM_CONTROLLER",
  "explanationTitleRu": "Контроллер последовательности питания",
  "sourceSheetId": "power_2400_PM_CONTROLLER",
  "sourceSheetName": "2400_PM_CONTROLLER",
  "sourceFile": "2400_PM_CONTROLLER.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
