/* Editable functional scene: control-boundary */
window.MIRA_FUNCTIONAL.scenes["control-boundary"]={
  "id": "control-boundary",
  "title": "INTERCONNECT",
  "subtitle": "Приём питания и разрешений",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet400",
      "title": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "subtitle": "Вход питания платы Control",
      "description": "J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.",
      "refs": [
        "control_J400",
        "control_U400",
        "control_U401"
      ],
      "role": "data",
      "x": 40,
      "y": 70,
      "w": 410,
      "h": 210,
      "sceneId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sourceSheetIds": [
        "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_J400",
          "control_U400",
          "control_U401"
        ],
        "sheetIds": [
          "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
        ],
        "units": [
          {
            "component": "control_J400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 4
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 5
          },
          {
            "component": "control_U401",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Вход питания платы Control",
      "sourceSheetName": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sourceSheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sourceFile": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch",
      "layoutRole": "primary"
    }
  ],
  "edges": [],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 490,
    "h": 285
  },
  "board": "control",
  "sheetIds": [
    "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_J400",
      "control_U400",
      "control_U401"
    ],
    "sheetIds": [
      "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
    ],
    "units": [
      {
        "component": "control_J400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 5
      },
      {
        "component": "control_U401",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-boundary"
  ],
  "suggestedScenario": "local-control-boundary",
  "explanationTitleRu": "Приём питания и разрешений",
  "sourceSheetId": "control_INTERCONNECT",
  "sourceSheetName": "INTERCONNECT",
  "sourceFile": "INTERCONNECT.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "functional-islands",
    "label": "Функциональные группы; электрические связи не добавлены",
    "geometryOnly": true
  },
  "regions": []
};
