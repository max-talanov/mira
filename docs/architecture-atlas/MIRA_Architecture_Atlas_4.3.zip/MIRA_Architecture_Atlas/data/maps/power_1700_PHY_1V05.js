/* Editable functional scene: power_1700_PHY_1V05 */
window.MIRA_FUNCTIONAL.scenes["power_1700_PHY_1V05"]={
  "id": "power_1700_PHY_1V05",
  "title": "1700_PHY_1V05",
  "subtitle": "Питание ядра Ethernet PHY",
  "description": "U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход FPGA5V5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1700_PHY_1V05"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1700_PHY_1V05"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Питание ядра Ethernet PHY: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1701",
        "power_L1701",
        "power_R1704",
        "power_R1703",
        "power_R1702",
        "power_R1705"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1700_PHY_1V05",
      "sourceSheetIds": [
        "power_1700_PHY_1V05"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1701",
          "power_L1701",
          "power_R1704",
          "power_R1703",
          "power_R1702",
          "power_R1705"
        ],
        "sheetIds": [
          "power_1700_PHY_1V05"
        ],
        "units": [
          {
            "component": "power_L1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_R1702",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_R1703",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_R1704",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_R1705",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_U1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1701",
        "power_R1701"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1700_PHY_1V05",
      "sourceSheetIds": [
        "power_1700_PHY_1V05"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1701",
          "power_R1701"
        ],
        "sheetIds": [
          "power_1700_PHY_1V05"
        ],
        "units": [
          {
            "component": "power_Q1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_R1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1703",
        "power_C1704",
        "power_C1701",
        "power_C1702",
        "power_R1706"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1700_PHY_1V05",
      "sourceSheetIds": [
        "power_1700_PHY_1V05"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1703",
          "power_C1704",
          "power_C1701",
          "power_C1702",
          "power_R1706"
        ],
        "sheetIds": [
          "power_1700_PHY_1V05"
        ],
        "units": [
          {
            "component": "power_C1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_C1702",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_C1703",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_C1704",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_R1706",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход PHY1V05",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1700_PHY_1V05"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1700_PHY_1V05"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_d1b6d8a1c1d4",
        "power_net_086f4f3255c8"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "PHY1V05",
        "PHY_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PHY1V05",
        "PHY_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "PHY1V05",
      "type": "power",
      "nets": [
        "power_net_d1b6d8a1c1d4"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "PHY1V05",
      "netLabels": [
        "PHY1V05"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PHY1V05"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_05ab23d96f3d",
        "power_net_055c51598970"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_PHY",
        "EN_PHY"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_PHY",
        "EN_PHY"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1700_PHY_1V05",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1701",
      "power_L1701",
      "power_R1704",
      "power_R1703",
      "power_R1702",
      "power_R1705",
      "power_Q1701",
      "power_R1701",
      "power_C1703",
      "power_C1704",
      "power_C1701",
      "power_C1702",
      "power_R1706"
    ],
    "sheetIds": [
      "power_1700_PHY_1V05"
    ],
    "units": [
      {
        "component": "power_L1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_R1702",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_R1703",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_R1704",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_R1705",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_U1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_Q1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_R1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_C1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_C1702",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_C1703",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_C1704",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_R1706",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1700_PHY_1V05"
  ],
  "suggestedScenario": "local-power_1700_PHY_1V05",
  "explanationTitleRu": "Питание ядра Ethernet PHY",
  "sourceSheetId": "power_1700_PHY_1V05",
  "sourceSheetName": "1700_PHY_1V05",
  "sourceFile": "1700_PHY_1V05.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
