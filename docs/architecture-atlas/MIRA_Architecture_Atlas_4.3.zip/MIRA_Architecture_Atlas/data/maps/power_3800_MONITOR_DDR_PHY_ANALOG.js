/* Editable functional scene: power_3800_MONITOR_DDR_PHY_ANALOG */
window.MIRA_FUNCTIONAL.scenes["power_3800_MONITOR_DDR_PHY_ANALOG"]={
  "id": "power_3800_MONITOR_DDR_PHY_ANALOG",
  "title": "3800_MONITOR_DDR_PHY_ANALOG",
  "subtitle": "Контроль памяти, PHY и аналоговых шин",
  "description": "U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины.",
  "nodes": [
    {
      "id": "ddr",
      "title": "Измерение питания памяти DDR3L",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3801",
        "power_C3803",
        "power_C3801",
        "power_C3805",
        "power_R3801",
        "power_R3802",
        "power_R3807",
        "power_D3801",
        "power_R3805"
      ],
      "role": "analog",
      "x": 40,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sourceSheetIds": [
        "power_3800_MONITOR_DDR_PHY_ANALOG"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3801",
          "power_C3803",
          "power_C3801",
          "power_C3805",
          "power_R3801",
          "power_R3802",
          "power_R3807",
          "power_D3801",
          "power_R3805"
        ],
        "sheetIds": [
          "power_3800_MONITOR_DDR_PHY_ANALOG"
        ],
        "units": [
          {
            "component": "power_C3801",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3803",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3805",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_D3801",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3801",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3802",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3805",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3807",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3801",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "ana5",
      "title": "Измерение аналогового питания 5 В",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3802",
        "power_R3808",
        "power_C3802",
        "power_R3806",
        "power_D3802",
        "power_C3806",
        "power_R3803",
        "power_C3804",
        "power_R3804"
      ],
      "role": "analog",
      "x": 620,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sourceSheetIds": [
        "power_3800_MONITOR_DDR_PHY_ANALOG"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3802",
          "power_R3808",
          "power_C3802",
          "power_R3806",
          "power_D3802",
          "power_C3806",
          "power_R3803",
          "power_C3804",
          "power_R3804"
        ],
        "sheetIds": [
          "power_3800_MONITOR_DDR_PHY_ANALOG"
        ],
        "units": [
          {
            "component": "power_C3802",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3804",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3806",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_D3802",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3803",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3804",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3806",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3808",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3802",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "phy",
      "title": "Измерение питания ядра Ethernet",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3803",
        "power_C3811",
        "power_R3813",
        "power_D3803",
        "power_R3809",
        "power_C3809",
        "power_R3810",
        "power_C3807",
        "power_R3815"
      ],
      "role": "analog",
      "x": 1220,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sourceSheetIds": [
        "power_3800_MONITOR_DDR_PHY_ANALOG"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3803",
          "power_C3811",
          "power_R3813",
          "power_D3803",
          "power_R3809",
          "power_C3809",
          "power_R3810",
          "power_C3807",
          "power_R3815"
        ],
        "sheetIds": [
          "power_3800_MONITOR_DDR_PHY_ANALOG"
        ],
        "units": [
          {
            "component": "power_C3807",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3809",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3811",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_D3803",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3809",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3810",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3813",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3815",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3803",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "ana33",
      "title": "Измерение аналогового питания 3,3 В",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3804",
        "power_C3808",
        "power_R3812",
        "power_C3812",
        "power_R3814",
        "power_R3816",
        "power_C3810",
        "power_D3804",
        "power_R3811"
      ],
      "role": "analog",
      "x": 620,
      "y": 490,
      "w": 310,
      "h": 164,
      "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sourceSheetIds": [
        "power_3800_MONITOR_DDR_PHY_ANALOG"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3804",
          "power_C3808",
          "power_R3812",
          "power_C3812",
          "power_R3814",
          "power_R3816",
          "power_C3810",
          "power_D3804",
          "power_R3811"
        ],
        "sheetIds": [
          "power_3800_MONITOR_DDR_PHY_ANALOG"
        ],
        "units": [
          {
            "component": "power_C3808",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3810",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_C3812",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_D3804",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3811",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3812",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3814",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_R3816",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3804",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "ddr_ana5",
      "from": "ddr",
      "to": "ana5",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "ddr_phy",
      "from": "ddr",
      "to": "phy",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "ddr_ana33",
      "from": "ddr",
      "to": "ana33",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "ana5_phy",
      "from": "ana5",
      "to": "phy",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "ana5_ana33",
      "from": "ana5",
      "to": "ana33",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "phy_ana33",
      "from": "phy",
      "to": "ana33",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": -28,
    "y": -29,
    "w": 1626,
    "h": 748
  },
  "board": "power",
  "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 36,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3801",
      "power_C3803",
      "power_C3801",
      "power_C3805",
      "power_R3801",
      "power_R3802",
      "power_R3807",
      "power_D3801",
      "power_R3805",
      "power_U3802",
      "power_R3808",
      "power_C3802",
      "power_R3806",
      "power_D3802",
      "power_C3806",
      "power_R3803",
      "power_C3804",
      "power_R3804",
      "power_U3803",
      "power_C3811",
      "power_R3813",
      "power_D3803",
      "power_R3809",
      "power_C3809",
      "power_R3810",
      "power_C3807",
      "power_R3815",
      "power_U3804",
      "power_C3808",
      "power_R3812",
      "power_C3812",
      "power_R3814",
      "power_R3816",
      "power_C3810",
      "power_D3804",
      "power_R3811"
    ],
    "sheetIds": [
      "power_3800_MONITOR_DDR_PHY_ANALOG"
    ],
    "units": [
      {
        "component": "power_C3801",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3803",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3805",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_D3801",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3801",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3802",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3805",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3807",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3801",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3802",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3804",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3806",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_D3802",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3803",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3804",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3806",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3808",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3802",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3807",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3809",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3811",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_D3803",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3809",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3810",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3813",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3815",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3803",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3808",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3810",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_C3812",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_D3804",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3811",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3812",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3814",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_R3816",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3804",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3800_MONITOR_DDR_PHY_ANALOG"
  ],
  "suggestedScenario": "local-power_3800_MONITOR_DDR_PHY_ANALOG",
  "explanationTitleRu": "Контроль памяти, PHY и аналоговых шин",
  "sourceSheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
  "sourceSheetName": "3800_MONITOR_DDR_PHY_ANALOG",
  "sourceFile": "3800_MONITOR_DDR_PHY_ANALOG.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "parallel-measurement-banks",
    "label": "Равноправные измерительные каналы разных шин",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 6,
      "w": 1546,
      "h": 673,
      "title": "Параллельные измерения тока и напряжения",
      "kind": "analog",
      "nodeIds": [
        "ddr",
        "ana5",
        "phy",
        "ana33"
      ]
    }
  ]
};
