/* Editable functional scene: control_200_MCU_FMC_AND_SDRAM */
window.MIRA_FUNCTIONAL.scenes["control_200_MCU_FMC_AND_SDRAM"]={
  "id": "control_200_MCU_FMC_AND_SDRAM",
  "title": "200_MCU_FMC_AND_SDRAM",
  "subtitle": "Оперативная память контроллера",
  "description": "Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.",
  "nodes": [
    {
      "id": "host",
      "title": "Запрос обращения к памяти",
      "subtitle": "",
      "description": "Контроллер памяти STM32 формирует адрес и команду SDRAM.",
      "refs": [
        "control_U100"
      ],
      "role": "data",
      "x": 40,
      "y": 160,
      "w": 350,
      "h": 184,
      "sheetId": "control_200_MCU_FMC_AND_SDRAM",
      "sourceSheetIds": [
        "control_200_MCU_FMC_AND_SDRAM"
      ],
      "circuitGroup": {
        "refs": [
          "control_U100"
        ],
        "sheetIds": [
          "control_200_MCU_FMC_AND_SDRAM"
        ],
        "units": [
          {
            "component": "control_U100",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 2
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "bus",
      "title": "Согласование шины памяти",
      "subtitle": "",
      "description": "Последовательные резисторы уменьшают звон фронтов адресных, командных и тактовых сигналов.",
      "refs": [
        "control_R200",
        "control_R201",
        "control_R202",
        "control_R203",
        "control_R204",
        "control_R205",
        "control_R206",
        "control_R207",
        "control_R208",
        "control_R209",
        "control_R210",
        "control_R211",
        "control_R212",
        "control_R213",
        "control_R214",
        "control_R215",
        "control_R216",
        "control_R217",
        "control_R218",
        "control_R219",
        "control_R220",
        "control_R221",
        "control_R222",
        "control_R223",
        "control_R224"
      ],
      "role": "control",
      "x": 590,
      "y": 180,
      "w": 280,
      "h": 145,
      "sheetId": "control_200_MCU_FMC_AND_SDRAM",
      "sourceSheetIds": [
        "control_200_MCU_FMC_AND_SDRAM"
      ],
      "circuitGroup": {
        "refs": [
          "control_R200",
          "control_R201",
          "control_R202",
          "control_R203",
          "control_R204",
          "control_R205",
          "control_R206",
          "control_R207",
          "control_R208",
          "control_R209",
          "control_R210",
          "control_R211",
          "control_R212",
          "control_R213",
          "control_R214",
          "control_R215",
          "control_R216",
          "control_R217",
          "control_R218",
          "control_R219",
          "control_R220",
          "control_R221",
          "control_R222",
          "control_R223",
          "control_R224"
        ],
        "sheetIds": [
          "control_200_MCU_FMC_AND_SDRAM"
        ],
        "units": [
          {
            "component": "control_R200",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R201",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R202",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R203",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R204",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R205",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R206",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R207",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R208",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R209",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R210",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R211",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R212",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R213",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R214",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R215",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R216",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R217",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R218",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R219",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R220",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R221",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R222",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R223",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_R224",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "memory",
      "title": "Хранение рабочих данных",
      "subtitle": "",
      "description": "SDRAM предоставляет контроллеру 64 МиБ энергозависимой оперативной памяти.",
      "refs": [
        "control_U200"
      ],
      "role": "data",
      "x": 1140,
      "y": 160,
      "w": 350,
      "h": 184,
      "sheetId": "control_200_MCU_FMC_AND_SDRAM",
      "sourceSheetIds": [
        "control_200_MCU_FMC_AND_SDRAM"
      ],
      "circuitGroup": {
        "refs": [
          "control_U200"
        ],
        "sheetIds": [
          "control_200_MCU_FMC_AND_SDRAM"
        ],
        "units": [
          {
            "component": "control_U200",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "bypass",
      "title": "Локальное питание памяти",
      "subtitle": "",
      "description": "Локальные конденсаторы поддерживают питание памяти.",
      "refs": [
        "control_C200",
        "control_C201",
        "control_C202",
        "control_C203",
        "control_C204",
        "control_C205",
        "control_C206",
        "control_C207"
      ],
      "role": "power",
      "x": 1160,
      "y": 530,
      "w": 260,
      "h": 132,
      "sheetId": "control_200_MCU_FMC_AND_SDRAM",
      "sourceSheetIds": [
        "control_200_MCU_FMC_AND_SDRAM"
      ],
      "circuitGroup": {
        "refs": [
          "control_C200",
          "control_C201",
          "control_C202",
          "control_C203",
          "control_C204",
          "control_C205",
          "control_C206",
          "control_C207"
        ],
        "sheetIds": [
          "control_200_MCU_FMC_AND_SDRAM"
        ],
        "units": [
          {
            "component": "control_C200",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C201",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C202",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C203",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C204",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C205",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C206",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_C207",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "host_bus_0",
      "from": "host",
      "to": "bus",
      "label": "Адреса, тактирование и команды",
      "type": "control",
      "nets": [
        "control_net_bf2f5ebca199",
        "control_net_f87a72a8ece7",
        "control_net_57814f35c37d",
        "control_net_88e82b098d8a",
        "control_net_576d489f596c",
        "control_net_64e3b30cda92",
        "control_net_5a1408d6925c",
        "control_net_e03d15dc4157",
        "control_net_478ea3ad984d",
        "control_net_51ade1c12a34",
        "control_net_497868960a10",
        "control_net_cf0d706ad175",
        "control_net_df9972435b68",
        "control_net_57fd38ae982f",
        "control_net_3a8f32a74ef2",
        "control_net_8726d2dae752",
        "control_net_66b853d97583",
        "control_net_1828c29d5fa6",
        "control_net_25457d3dd391",
        "control_net_cb5d34db7f7a",
        "control_net_802aa4569b27",
        "control_net_3974126e88cb",
        "control_net_f2ad5b3a1b23"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Адрес / команда",
      "netLabels": [
        "FMC_A0",
        "FMC_A2",
        "FMC_SDCLK",
        "FMC_BA1",
        "FMC_A10",
        "FMC_BA0",
        "FMC_A11",
        "FMC_SDCKE0",
        "FMC_NBL1",
        "FMC_A9",
        "FMC_A4",
        "FMC_A7",
        "FMC_SDNCAS",
        "FMC_A8",
        "FMC_A6",
        "FMC_SDNRAS",
        "FMC_A1",
        "FMC_A12",
        "FMC_SDNE0",
        "FMC_SDNWE",
        "FMC_A3",
        "FMC_NBL0",
        "FMC_A5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FMC_A0 · FMC_A2",
        "FMC_SDCLK · ещё 20"
      ],
      "allConnectionsLabel": "Все соединения: 23",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "bus_memory_1",
      "from": "bus",
      "to": "memory",
      "label": "Сигналы после согласования",
      "type": "control",
      "nets": [
        "control_net_1fb2e0bffca2",
        "control_net_b56b3c253467",
        "control_net_812a5aa5142f",
        "control_net_ea2e71d8ad65",
        "control_net_29b779eba1df",
        "control_net_a3f957371c3f",
        "control_net_22d2ed5a92b0",
        "control_net_e61f684e2b30",
        "control_net_50fec45c4cfe",
        "control_net_8e2c742867a9",
        "control_net_0d875c33a31d",
        "control_net_a7ff225fafcc",
        "control_net_7fb3e667afc3",
        "control_net_88a82b0ea167",
        "control_net_6a7ba2287274",
        "control_net_1ab10b21ce8a",
        "control_net_ac77da14ad01",
        "control_net_c768cd02e6fd",
        "control_net_9cec32a3a290",
        "control_net_50162c30e639",
        "control_net_bf332d53cb7b",
        "control_net_5ff18f95d1df",
        "control_net_ba4358c26b16"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Согласованная шина",
      "netLabels": [],
      "unnamedNetIds": [
        "control_net_1fb2e0bffca2",
        "control_net_b56b3c253467",
        "control_net_812a5aa5142f",
        "control_net_ea2e71d8ad65",
        "control_net_29b779eba1df",
        "control_net_a3f957371c3f",
        "control_net_22d2ed5a92b0",
        "control_net_e61f684e2b30",
        "control_net_50fec45c4cfe",
        "control_net_8e2c742867a9",
        "control_net_0d875c33a31d",
        "control_net_a7ff225fafcc",
        "control_net_7fb3e667afc3",
        "control_net_88a82b0ea167",
        "control_net_6a7ba2287274",
        "control_net_1ab10b21ce8a",
        "control_net_ac77da14ad01",
        "control_net_c768cd02e6fd",
        "control_net_9cec32a3a290",
        "control_net_50162c30e639",
        "control_net_bf332d53cb7b",
        "control_net_5ff18f95d1df",
        "control_net_ba4358c26b16"
      ],
      "labelLines": [],
      "allConnectionsLabel": "Все соединения: 23",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "host_memory_2",
      "from": "host",
      "to": "memory",
      "label": "16-битная шина данных",
      "type": "data",
      "nets": [
        "control_net_30b951256d65",
        "control_net_05f1cce27675",
        "control_net_dbb7c66b055c",
        "control_net_71220214496a",
        "control_net_e8c9dc419d80",
        "control_net_c3d2e7b446eb",
        "control_net_3f3c225eebe4",
        "control_net_4fca7f1d1465",
        "control_net_1643db7ef9f9",
        "control_net_a3813a077889",
        "control_net_cfc4efe0cd4a",
        "control_net_4ddbefaae88b",
        "control_net_c16e9f400334",
        "control_net_98b1a2522dce",
        "control_net_5c8668fc4b07",
        "control_net_a0420c81d318"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "16-битные данные",
      "netLabels": [
        "FMC_D0",
        "FMC_D1",
        "FMC_D2",
        "FMC_D3",
        "FMC_D4",
        "FMC_D5",
        "FMC_D6",
        "FMC_D7",
        "FMC_D8",
        "FMC_D9",
        "FMC_D10",
        "FMC_D11",
        "FMC_D12",
        "FMC_D13",
        "FMC_D14",
        "FMC_D15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FMC_D0 · FMC_D1",
        "FMC_D2 · ещё 13"
      ],
      "allConnectionsLabel": "Все соединения: 16",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "bypass_memory_3",
      "from": "bypass",
      "to": "memory",
      "label": "Питание памяти 3,3 В",
      "type": "power",
      "nets": [
        "control_net_90c4fa851afd"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Питание памяти 3,3 В",
      "netLabels": [
        "SYS3V3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "SYS3V3"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 125,
    "w": 1530,
    "h": 577
  },
  "board": "control",
  "sheetId": "control_200_MCU_FMC_AND_SDRAM",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 35,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U100",
      "control_R200",
      "control_R201",
      "control_R202",
      "control_R203",
      "control_R204",
      "control_R205",
      "control_R206",
      "control_R207",
      "control_R208",
      "control_R209",
      "control_R210",
      "control_R211",
      "control_R212",
      "control_R213",
      "control_R214",
      "control_R215",
      "control_R216",
      "control_R217",
      "control_R218",
      "control_R219",
      "control_R220",
      "control_R221",
      "control_R222",
      "control_R223",
      "control_R224",
      "control_U200",
      "control_C200",
      "control_C201",
      "control_C202",
      "control_C203",
      "control_C204",
      "control_C205",
      "control_C206",
      "control_C207"
    ],
    "sheetIds": [
      "control_200_MCU_FMC_AND_SDRAM"
    ],
    "units": [
      {
        "component": "control_U100",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 2
      },
      {
        "component": "control_R200",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R201",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R202",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R203",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R204",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R205",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R206",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R207",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R208",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R209",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R210",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R211",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R212",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R213",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R214",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R215",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R216",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R217",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R218",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R219",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R220",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R221",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R222",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R223",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_R224",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_U200",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C200",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C201",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C202",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C203",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C204",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C205",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C206",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_C207",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_200_MCU_FMC_AND_SDRAM"
  ],
  "suggestedScenario": "local-control_200_MCU_FMC_AND_SDRAM",
  "explanationTitleRu": "Оперативная память контроллера",
  "sourceSheetId": "control_200_MCU_FMC_AND_SDRAM",
  "sourceSheetName": "200_MCU_FMC_AND_SDRAM",
  "sourceFile": "200_MCU_FMC_AND_SDRAM.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-host",
  "layout": {
    "version": 2,
    "kind": "memory-bus",
    "label": "Обмен по шине и отдельная поддержка питания",
    "geometryOnly": true
  },
  "regions": []
};
