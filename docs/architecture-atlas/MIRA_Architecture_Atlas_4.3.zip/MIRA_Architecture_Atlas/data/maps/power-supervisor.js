/* Editable functional scene: power-supervisor */
window.MIRA_FUNCTIONAL.scenes["power-supervisor"]={
  "id": "power-supervisor",
  "title": "POWER_CONTROL",
  "subtitle": "Запуск и аппаратная безопасность",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet2400",
      "title": "2400_PM_CONTROLLER",
      "subtitle": "Контроллер последовательности питания",
      "description": "U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером.",
      "refs": [
        "power_U2401"
      ],
      "role": "data",
      "x": 600,
      "y": 340,
      "w": 410,
      "h": 210,
      "sceneId": "power_2400_PM_CONTROLLER",
      "sheetId": "power_2400_PM_CONTROLLER",
      "sourceSheetIds": [
        "power_2400_PM_CONTROLLER"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2401"
        ],
        "sheetIds": [
          "power_2400_PM_CONTROLLER"
        ],
        "units": [
          {
            "component": "power_U2401",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Контроллер последовательности питания",
      "sourceSheetName": "2400_PM_CONTROLLER",
      "sourceSheetId": "power_2400_PM_CONTROLLER",
      "sourceFile": "2400_PM_CONTROLLER.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet2500",
      "title": "2500_PM_WATCHDOGS",
      "subtitle": "Сторожевой контроль контроллеров",
      "description": "U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера.",
      "refs": [
        "power_U2502",
        "power_U2501",
        "power_J2502",
        "power_J2501"
      ],
      "role": "data",
      "x": 40,
      "y": 40,
      "w": 320,
      "h": 170,
      "sceneId": "power_2500_PM_WATCHDOGS",
      "sheetId": "power_2500_PM_WATCHDOGS",
      "sourceSheetIds": [
        "power_2500_PM_WATCHDOGS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2502",
          "power_U2501",
          "power_J2502",
          "power_J2501"
        ],
        "sheetIds": [
          "power_2500_PM_WATCHDOGS"
        ],
        "units": [
          {
            "component": "power_J2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_J2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_U2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_U2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Сторожевой контроль контроллеров",
      "sourceSheetName": "2500_PM_WATCHDOGS",
      "sourceSheetId": "power_2500_PM_WATCHDOGS",
      "sourceFile": "2500_PM_WATCHDOGS.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet2600",
      "title": "2600_PM_PERMIT_INTERLOCKS",
      "subtitle": "Аппаратные разрешения и блокировки",
      "description": "Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы.",
      "refs": [
        "power_J2602",
        "power_U2601",
        "power_J2601",
        "power_J2603",
        "power_U2603",
        "power_U2602"
      ],
      "role": "data",
      "x": 40,
      "y": 650,
      "w": 410,
      "h": 210,
      "sceneId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sourceSheetIds": [
        "power_2600_PM_PERMIT_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "power_J2602",
          "power_U2601",
          "power_J2601",
          "power_J2603",
          "power_U2603",
          "power_U2602"
        ],
        "sheetIds": [
          "power_2600_PM_PERMIT_INTERLOCKS"
        ],
        "units": [
          {
            "component": "power_J2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_J2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_J2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Аппаратные разрешения и блокировки",
      "sourceSheetName": "2600_PM_PERMIT_INTERLOCKS",
      "sourceSheetId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sourceFile": "2600_PM_PERMIT_INTERLOCKS.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet2700",
      "title": "2700_PM_ENABLE_GATES_PRIMARY",
      "subtitle": "Разрешения основных преобразователей",
      "description": "U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением.",
      "refs": [
        "power_U2701",
        "power_U2702"
      ],
      "role": "data",
      "x": 1200,
      "y": 40,
      "w": 320,
      "h": 166,
      "sceneId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "sheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "sourceSheetIds": [
        "power_2700_PM_ENABLE_GATES_PRIMARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2701",
          "power_U2702"
        ],
        "sheetIds": [
          "power_2700_PM_ENABLE_GATES_PRIMARY"
        ],
        "units": [
          {
            "component": "power_U2701",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_U2702",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Разрешения основных преобразователей",
      "sourceSheetName": "2700_PM_ENABLE_GATES_PRIMARY",
      "sourceSheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "sourceFile": "2700_PM_ENABLE_GATES_PRIMARY.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet2800",
      "title": "2800_PM_ENABLE_GATES_AUXILIARY",
      "subtitle": "Разрешения вспомогательных преобразователей",
      "description": "U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением.",
      "refs": [
        "power_U2802",
        "power_U2801"
      ],
      "role": "data",
      "x": 1200,
      "y": 650,
      "w": 320,
      "h": 166,
      "sceneId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "sheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "sourceSheetIds": [
        "power_2800_PM_ENABLE_GATES_AUXILIARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2802",
          "power_U2801"
        ],
        "sheetIds": [
          "power_2800_PM_ENABLE_GATES_AUXILIARY"
        ],
        "units": [
          {
            "component": "power_U2801",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_U2802",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Разрешения вспомогательных преобразователей",
      "sourceSheetName": "2800_PM_ENABLE_GATES_AUXILIARY",
      "sourceSheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "sourceFile": "2800_PM_ENABLE_GATES_AUXILIARY.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet2900",
      "title": "2900_PM_ANALOG_POWER_GOOD",
      "subtitle": "Проверка допустимых напряжений",
      "description": "U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON.",
      "refs": [
        "power_U2901"
      ],
      "role": "data",
      "x": 40,
      "y": 350,
      "w": 320,
      "h": 166,
      "sceneId": "power_2900_PM_ANALOG_POWER_GOOD",
      "sheetId": "power_2900_PM_ANALOG_POWER_GOOD",
      "sourceSheetIds": [
        "power_2900_PM_ANALOG_POWER_GOOD"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2901"
        ],
        "sheetIds": [
          "power_2900_PM_ANALOG_POWER_GOOD"
        ],
        "units": [
          {
            "component": "power_U2901",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Проверка допустимых напряжений",
      "sourceSheetName": "2900_PM_ANALOG_POWER_GOOD",
      "sourceSheetId": "power_2900_PM_ANALOG_POWER_GOOD",
      "sourceFile": "2900_PM_ANALOG_POWER_GOOD.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "sheet3000",
      "title": "3000_PM_RAIL_READY",
      "subtitle": "Готовность напряжений питания",
      "description": "U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений.",
      "refs": [
        "power_U3001",
        "power_U3017",
        "power_U3018"
      ],
      "role": "data",
      "x": 600,
      "y": 40,
      "w": 320,
      "h": 166,
      "sceneId": "power_3000_PM_RAIL_READY",
      "sheetId": "power_3000_PM_RAIL_READY",
      "sourceSheetIds": [
        "power_3000_PM_RAIL_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3001",
          "power_U3017",
          "power_U3018"
        ],
        "sheetIds": [
          "power_3000_PM_RAIL_READY"
        ],
        "units": [
          {
            "component": "power_U3001",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          },
          {
            "component": "power_U3017",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          },
          {
            "component": "power_U3018",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Готовность напряжений питания",
      "sourceSheetName": "3000_PM_RAIL_READY",
      "sourceSheetId": "power_3000_PM_RAIL_READY",
      "sourceFile": "3000_PM_RAIL_READY.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "sheet3100",
      "title": "3100_PM_COMMAND_READY",
      "subtitle": "Готовность команд включения",
      "description": "U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин.",
      "refs": [
        "power_U3103",
        "power_U3101",
        "power_U3102"
      ],
      "role": "data",
      "x": 1770,
      "y": 345,
      "w": 320,
      "h": 166,
      "sceneId": "power_3100_PM_COMMAND_READY",
      "sheetId": "power_3100_PM_COMMAND_READY",
      "sourceSheetIds": [
        "power_3100_PM_COMMAND_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3103",
          "power_U3101",
          "power_U3102"
        ],
        "sheetIds": [
          "power_3100_PM_COMMAND_READY"
        ],
        "units": [
          {
            "component": "power_U3101",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          },
          {
            "component": "power_U3102",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          },
          {
            "component": "power_U3103",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Готовность команд включения",
      "sourceSheetName": "3100_PM_COMMAND_READY",
      "sourceSheetId": "power_3100_PM_COMMAND_READY",
      "sourceFile": "3100_PM_COMMAND_READY.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "sheet3200",
      "title": "3200_PM_NEGATIVE_OVERCURRENT",
      "subtitle": "Защита отрицательной шины по току",
      "description": "U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.",
      "refs": [
        "power_U3201"
      ],
      "role": "data",
      "x": 600,
      "y": 920,
      "w": 320,
      "h": 170,
      "sceneId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "sheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "sourceSheetIds": [
        "power_3200_PM_NEGATIVE_OVERCURRENT"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3201"
        ],
        "sheetIds": [
          "power_3200_PM_NEGATIVE_OVERCURRENT"
        ],
        "units": [
          {
            "component": "power_U3201",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Защита отрицательной шины по току",
      "sourceSheetName": "3200_PM_NEGATIVE_OVERCURRENT",
      "sourceSheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "sourceFile": "3200_PM_NEGATIVE_OVERCURRENT.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet3300",
      "title": "3300_PM_DEBUG_HOST_INTERFACE",
      "subtitle": "Связь контроллера питания с основным",
      "description": "J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера.",
      "refs": [
        "power_J3301",
        "power_J3302",
        "power_U3301"
      ],
      "role": "data",
      "x": 1200,
      "y": 960,
      "w": 320,
      "h": 164,
      "sceneId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "sheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "sourceSheetIds": [
        "power_3300_PM_DEBUG_HOST_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_J3301",
          "power_J3302",
          "power_U3301"
        ],
        "sheetIds": [
          "power_3300_PM_DEBUG_HOST_INTERFACE"
        ],
        "units": [
          {
            "component": "power_J3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_J3302",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_U3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Связь контроллера питания с основным",
      "sourceSheetName": "3300_PM_DEBUG_HOST_INTERFACE",
      "sourceSheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "sourceFile": "3300_PM_DEBUG_HOST_INTERFACE.kicad_sch",
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "sheet2400_sheet3000",
      "from": "sheet2400",
      "to": "sheet3000",
      "label": "16 цепей",
      "type": "control",
      "nets": [
        "power_net_0ee4f5245d75",
        "power_net_2965499926c8",
        "power_net_95f2aea4f265",
        "power_net_b80a0b0c471f",
        "power_net_47f67f61993c",
        "power_net_ed26aaa81531",
        "power_net_e46274585def",
        "power_net_cfa48b7bd3ef",
        "power_net_0c8e0f29b47d",
        "power_net_e1dd2bfabf3b",
        "power_net_99aaef80128f",
        "power_net_61199f10a0d6",
        "power_net_fcfa30509d75",
        "power_net_b81a8e339338",
        "power_net_ae3b1a85f32f",
        "power_net_ac83bbc60cc7"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "16 цепей",
      "netLabels": [
        "PGR_VTT",
        "PG_FPGA",
        "PGR_CORE",
        "PGR_AUX18",
        "ALL_RAILS_PG",
        "PGR_DDR",
        "PG_ANA",
        "PG_SYS",
        "PG_N15",
        "PGR_ANA33",
        "PGR_ANA5",
        "PG_P15",
        "PGR_AUX25",
        "PGR_IO33",
        "PG_USB",
        "PGR_PHY"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PGR_VTT · PG_FPGA",
        "PGR_CORE · ещё 13"
      ],
      "allConnectionsLabel": "Все соединения: 16",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "sheet2400_sheet2600",
      "from": "sheet2400",
      "to": "sheet2600",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_c9b6c7228333",
        "power_net_9ab95937734d",
        "power_net_6d982403b080",
        "power_net_47f67f61993c",
        "power_net_6ad422db16ac",
        "power_net_4aeb4892b398",
        "power_net_47577a24d67e",
        "power_net_8828c890966d",
        "power_net_35045b6a457d",
        "power_net_cfb766cbb94f",
        "power_net_2cbf74589b12",
        "power_net_86751620b7fb",
        "power_net_5a1f578d112a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "PG_INPUT",
        "PWR_KILL_GPIO",
        "MATRIX_ARM_PULSE",
        "ALL_RAILS_PG",
        "PWR_ARM_PULSE",
        "OC_OK_N",
        "PM_WDO_N",
        "GLOBAL_PWR_PERMIT",
        "FLT_INPUT_N",
        "MATRIX_KILL_GPIO",
        "PM_RESET_N",
        "HOST_WDO_N",
        "MATRIX_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PG_INPUT · PWR_KILL_GPIO",
        "MATRIX_ARM_PULSE · ещё 10"
      ],
      "allConnectionsLabel": "Все соединения: 13",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "sheet2400_sheet2700",
      "from": "sheet2400",
      "to": "sheet2700",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_c19f5798f458",
        "power_net_c876bbd15aa2",
        "power_net_8828c890966d",
        "power_net_83fb386e92c5",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_f4716909bd0c",
        "power_net_c66ec173184e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "EN_REQ_SYS",
        "EN_REQ_P15",
        "GLOBAL_PWR_PERMIT",
        "EN_REQ_ANA",
        "EN_REQ_N15",
        "EN_REQ_CORE",
        "EN_REQ_AUX18",
        "EN_REQ_USB",
        "EN_REQ_FPGA"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "EN_REQ_SYS · EN_REQ_P15",
        "GLOBAL_PWR_PERMIT · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet2400_sheet3300",
      "from": "sheet2400",
      "to": "sheet3300",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_e5822cf03a94",
        "power_net_25cd945f19a1",
        "power_net_47f67f61993c",
        "power_net_8828c890966d",
        "power_net_ccf5ee78cf75",
        "power_net_36bf51cd4ad6",
        "power_net_a250a8b7fe30",
        "power_net_2cbf74589b12",
        "power_net_5a1f578d112a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "ADC_VTT",
        "PM_SWDIO_MCU",
        "ALL_RAILS_PG",
        "GLOBAL_PWR_PERMIT",
        "PM_UART_RX",
        "PM_UART_TX",
        "PM_SWCLK_MCU",
        "PM_RESET_N",
        "MATRIX_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ADC_VTT · PM_SWDIO_MCU",
        "ALL_RAILS_PG · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "sheet2400_sheet2800",
      "from": "sheet2400",
      "to": "sheet2800",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_2c93a597633f",
        "power_net_d1fe7a20e661",
        "power_net_5dc0cb853f29",
        "power_net_8828c890966d",
        "power_net_69d4e38b1bd0",
        "power_net_12bae3231aaa",
        "power_net_1b4ac01010f8",
        "power_net_b527a6b82695"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "EN_REQ_VTT",
        "EN_REQ_AUX25",
        "EN_REQ_DDR",
        "GLOBAL_PWR_PERMIT",
        "EN_REQ_PHY",
        "EN_REQ_ANA5",
        "EN_REQ_IO33",
        "EN_REQ_ANA33"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "EN_REQ_ANA33",
        "EN_REQ_ANA5",
        "EN_REQ_AUX25",
        "EN_REQ_DDR",
        "EN_REQ_IO33",
        "EN_REQ_PHY",
        "EN_REQ_VTT",
        "GLOBAL_PWR_PERMIT"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet2700_sheet3100",
      "from": "sheet2700",
      "to": "sheet3100",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_3db57ce8c78a",
        "power_net_6220152fdd65",
        "power_net_6649c6cdd008",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_7f7616523bf4",
        "power_net_9020238d369a",
        "power_net_9693d69e08e6"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "CMD_CORE",
        "CMD_ANA",
        "CMD_USB",
        "CMD_P15",
        "CMD_N15",
        "CMD_FPGA",
        "CMD_SYS",
        "CMD_AUX18"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA · CMD_AUX18",
        "CMD_CORE · CMD_FPGA",
        "CMD_N15 · CMD_P15",
        "CMD_SYS · CMD_USB"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet2800_sheet3100",
      "from": "sheet2800",
      "to": "sheet3100",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_05ab23d96f3d",
        "power_net_04b2f0a4c78b",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41",
        "power_net_d07b46e16a3e",
        "power_net_0faf4b6ebbf5"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "CMD_PHY",
        "CMD_IO33",
        "CMD_VTT",
        "CMD_ANA5",
        "CMD_ANA33",
        "CMD_DDR",
        "CMD_AUX25"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA33 · CMD_ANA5",
        "CMD_AUX25 · CMD_DDR",
        "CMD_IO33 · CMD_PHY",
        "CMD_VTT"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet2500_sheet2600",
      "from": "sheet2500",
      "to": "sheet2600",
      "label": "5 цепей",
      "type": "control",
      "nets": [
        "power_net_47577a24d67e",
        "power_net_35aa4cb845bd",
        "power_net_2cbf74589b12",
        "power_net_b4c478ffb022",
        "power_net_86751620b7fb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "5 цепей",
      "netLabels": [
        "PM_WDO_N",
        "HOST_RESET_N",
        "PM_RESET_N",
        "AON_RESET_N",
        "HOST_WDO_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AON_RESET_N · HOST_RESET_N",
        "HOST_WDO_N · PM_RESET_N",
        "PM_WDO_N"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "sheet2400_sheet2500",
      "from": "sheet2400",
      "to": "sheet2500",
      "label": "4 цепи",
      "type": "control",
      "nets": [
        "power_net_55a52205aaf0",
        "power_net_47577a24d67e",
        "power_net_2cbf74589b12",
        "power_net_86751620b7fb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "PM_WDI",
        "PM_WDO_N",
        "PM_RESET_N",
        "HOST_WDO_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "HOST_WDO_N · PM_RESET_N",
        "PM_WDI · PM_WDO_N"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "sheet2400_sheet2900",
      "from": "sheet2400",
      "to": "sheet2900",
      "label": "4 цепи",
      "type": "control",
      "nets": [
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_ae3b1a85f32f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "PG_ANA",
        "PG_P15",
        "PG_N15",
        "PG_USB"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PG_ANA · PG_N15",
        "PG_P15 · PG_USB"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "sheet2600_sheet3300",
      "from": "sheet2600",
      "to": "sheet3300",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_47f67f61993c",
        "power_net_8828c890966d",
        "power_net_2cbf74589b12",
        "power_net_5a1f578d112a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "ALL_RAILS_PG",
        "GLOBAL_PWR_PERMIT",
        "PM_RESET_N",
        "MATRIX_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ALL_RAILS_PG",
        "GLOBAL_PWR_PERMIT",
        "MATRIX_PERMIT",
        "PM_RESET_N"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet2900_sheet3000",
      "from": "sheet2900",
      "to": "sheet3000",
      "label": "4 цепи",
      "type": "control",
      "nets": [
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_ae3b1a85f32f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "PG_ANA",
        "PG_P15",
        "PG_N15",
        "PG_USB"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PG_ANA · PG_N15",
        "PG_P15 · PG_USB"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 5,
    "w": 2130,
    "h": 1159
  },
  "board": "power",
  "sheetIds": [
    "power_2400_PM_CONTROLLER",
    "power_2500_PM_WATCHDOGS",
    "power_2600_PM_PERMIT_INTERLOCKS",
    "power_2700_PM_ENABLE_GATES_PRIMARY",
    "power_2800_PM_ENABLE_GATES_AUXILIARY",
    "power_2900_PM_ANALOG_POWER_GOOD",
    "power_3000_PM_RAIL_READY",
    "power_3100_PM_COMMAND_READY",
    "power_3200_PM_NEGATIVE_OVERCURRENT",
    "power_3300_PM_DEBUG_HOST_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2401",
      "power_U2502",
      "power_U2501",
      "power_J2502",
      "power_J2501",
      "power_J2602",
      "power_U2601",
      "power_J2601",
      "power_J2603",
      "power_U2603",
      "power_U2602",
      "power_U2701",
      "power_U2702",
      "power_U2802",
      "power_U2801",
      "power_U2901",
      "power_U3001",
      "power_U3017",
      "power_U3018",
      "power_U3103",
      "power_U3101",
      "power_U3102",
      "power_U3201",
      "power_J3301",
      "power_J3302",
      "power_U3301"
    ],
    "sheetIds": [
      "power_2400_PM_CONTROLLER",
      "power_2500_PM_WATCHDOGS",
      "power_2600_PM_PERMIT_INTERLOCKS",
      "power_2700_PM_ENABLE_GATES_PRIMARY",
      "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "power_2900_PM_ANALOG_POWER_GOOD",
      "power_3000_PM_RAIL_READY",
      "power_3100_PM_COMMAND_READY",
      "power_3200_PM_NEGATIVE_OVERCURRENT",
      "power_3300_PM_DEBUG_HOST_INTERFACE"
    ],
    "units": [
      {
        "component": "power_U2401",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_J2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_J2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_U2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_U2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_J2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_J2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_J2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2701",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_U2702",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_U2801",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_U2802",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_U2901",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_U3001",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_U3017",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_U3018",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_U3101",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_U3102",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_U3103",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_U3201",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      },
      {
        "component": "power_J3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_J3302",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_U3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power-supervisor"
  ],
  "suggestedScenario": "local-power-supervisor",
  "explanationTitleRu": "Запуск и аппаратная безопасность",
  "sourceSheetId": "power_POWER_CONTROL",
  "sourceSheetName": "POWER_CONTROL",
  "sourceFile": "POWER_CONTROL.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power",
  "layout": {
    "version": 2,
    "kind": "supervision-hub",
    "label": "Контроллер, проверки, разрешения и интерфейс",
    "geometryOnly": true
  },
  "regions": []
};
