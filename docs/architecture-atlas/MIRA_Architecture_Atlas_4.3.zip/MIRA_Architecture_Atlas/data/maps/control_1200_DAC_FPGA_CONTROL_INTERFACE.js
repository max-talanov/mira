/* Editable functional scene: control_1200_DAC_FPGA_CONTROL_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["control_1200_DAC_FPGA_CONTROL_INTERFACE"]={
  "id": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
  "title": "1200_DAC_FPGA_CONTROL_INTERFACE",
  "subtitle": "Управление аналоговыми источниками",
  "description": "Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс.",
  "nodes": [
    {
      "id": "fpga",
      "title": "Передача аналоговых уставок",
      "subtitle": "",
      "description": "ПЛИС управляет группой ЦАП через последовательный интерфейс.",
      "refs": [
        "control_U500"
      ],
      "role": "control",
      "x": 40,
      "y": 100,
      "w": 360,
      "h": 194,
      "sheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "sourceSheetIds": [
        "control_1200_DAC_FPGA_CONTROL_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500"
        ],
        "sheetIds": [
          "control_1200_DAC_FPGA_CONTROL_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U500",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 7
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "bias",
      "title": "Безопасные начальные состояния",
      "subtitle": "",
      "description": "Подтягивающие резисторы задают определённые состояния выбора, сброса и фиксации при запуске.",
      "refs": [
        "control_R1200",
        "control_R1201",
        "control_R1202",
        "control_R1203",
        "control_R1204",
        "control_R1205",
        "control_R1206",
        "control_R1207",
        "control_C1206",
        "control_C1200",
        "control_C1203",
        "control_C1204",
        "control_C1201",
        "control_C1205",
        "control_C1202"
      ],
      "role": "control",
      "x": 680,
      "y": 360,
      "w": 250,
      "h": 132,
      "sheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "sourceSheetIds": [
        "control_1200_DAC_FPGA_CONTROL_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_R1200",
          "control_R1201",
          "control_R1202",
          "control_R1203",
          "control_R1204",
          "control_R1205",
          "control_R1206",
          "control_R1207",
          "control_C1206",
          "control_C1200",
          "control_C1203",
          "control_C1204",
          "control_C1201",
          "control_C1205",
          "control_C1202"
        ],
        "sheetIds": [
          "control_1200_DAC_FPGA_CONTROL_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C1200",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C1201",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C1202",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C1203",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C1204",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C1205",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C1206",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1200",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1201",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1202",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1203",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1204",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1205",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1206",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R1207",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "fpga_bias",
      "from": "fpga",
      "to": "bias",
      "label": "8 цепей",
      "type": "control",
      "nets": [
        "control_net_8543c7028353",
        "control_net_0d0a126b05bc",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d",
        "control_net_fad82bf41bcf",
        "control_net_596ada6680f2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "8 цепей",
      "netLabels": [
        "CS_BL3",
        "DAC_LDAC_N",
        "DAC_RESET_N",
        "CS_BL0",
        "CS_BL1",
        "CS_BL2",
        "CS_CTRL",
        "CS_HV"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CS_BL0 · CS_BL1",
        "CS_BL2 · CS_BL3",
        "CS_CTRL · CS_HV",
        "DAC_LDAC_N · DAC_RESET_N"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 65,
    "w": 970,
    "h": 467
  },
  "board": "control",
  "sheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 16,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U500",
      "control_R1200",
      "control_R1201",
      "control_R1202",
      "control_R1203",
      "control_R1204",
      "control_R1205",
      "control_R1206",
      "control_R1207",
      "control_C1206",
      "control_C1200",
      "control_C1203",
      "control_C1204",
      "control_C1201",
      "control_C1205",
      "control_C1202"
    ],
    "sheetIds": [
      "control_1200_DAC_FPGA_CONTROL_INTERFACE"
    ],
    "units": [
      {
        "component": "control_U500",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 7
      },
      {
        "component": "control_C1200",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C1201",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C1202",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C1203",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C1204",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C1205",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C1206",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1200",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1201",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1202",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1203",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1204",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1205",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1206",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R1207",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1200_DAC_FPGA_CONTROL_INTERFACE"
  ],
  "suggestedScenario": "local-control_1200_DAC_FPGA_CONTROL_INTERFACE",
  "explanationTitleRu": "Управление аналоговыми источниками",
  "sourceSheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
  "sourceSheetName": "1200_DAC_FPGA_CONTROL_INTERFACE",
  "sourceFile": "1200_DAC_FPGA_CONTROL_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-sources",
  "layout": {
    "version": 2,
    "kind": "control-with-safe-defaults",
    "label": "Основной интерфейс управления и начальные состояния",
    "geometryOnly": true
  },
  "regions": []
};
