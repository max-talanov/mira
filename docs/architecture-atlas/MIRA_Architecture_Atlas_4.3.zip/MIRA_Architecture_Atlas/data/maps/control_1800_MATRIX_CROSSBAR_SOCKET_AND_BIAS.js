/* Editable functional scene: control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS */
window.MIRA_FUNCTIONAL.scenes["control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"]={
  "id": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "title": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "subtitle": "Подключение экспериментальной матрицы",
  "description": "J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня.",
  "nodes": [
    {
      "id": "socket",
      "title": "Подключение мемристорной матрицы",
      "subtitle": "",
      "description": "Разъём выводит битовые линии, строки, нейронные линии и контакты смещения.",
      "refs": [
        "control_J1800"
      ],
      "role": "analog",
      "x": 40,
      "y": 100,
      "w": 370,
      "h": 198,
      "sheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "sourceSheetIds": [
        "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
      ],
      "circuitGroup": {
        "refs": [
          "control_J1800"
        ],
        "sheetIds": [
          "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
        ],
        "units": [
          {
            "component": "control_J1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_J1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 2
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "bias",
      "title": "Выбор смещения адаптера",
      "subtitle": "",
      "description": "Перемычки задают подключения смещения адаптера согласно исходной схеме.",
      "refs": [
        "control_J1801",
        "control_J1802",
        "control_R1801",
        "control_R1800"
      ],
      "role": "analog",
      "x": 720,
      "y": 350,
      "w": 250,
      "h": 132,
      "sheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "sourceSheetIds": [
        "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
      ],
      "circuitGroup": {
        "refs": [
          "control_J1801",
          "control_J1802",
          "control_R1801",
          "control_R1800"
        ],
        "sheetIds": [
          "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
        ],
        "units": [
          {
            "component": "control_J1801",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_J1802",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_R1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_R1801",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "socket_bias",
      "from": "socket",
      "to": "bias",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_6380a00471f5",
        "control_net_b538393eaff5"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_ADAPTER_CASE",
        "MAT_ADAPTER_VSUB"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADAPTER_CASE",
        "MAT_ADAPTER_VSUB"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 65,
    "w": 1010,
    "h": 457
  },
  "board": "control",
  "sheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 5,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_J1800",
      "control_J1801",
      "control_J1802",
      "control_R1801",
      "control_R1800"
    ],
    "sheetIds": [
      "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
    ],
    "units": [
      {
        "component": "control_J1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_J1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 2
      },
      {
        "component": "control_J1801",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_J1802",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_R1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_R1801",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
  ],
  "suggestedScenario": "local-control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "explanationTitleRu": "Подключение экспериментальной матрицы",
  "sourceSheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "sourceSheetName": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
  "sourceFile": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-routing",
  "layout": {
    "version": 2,
    "kind": "connector-with-bias",
    "label": "Разъём матрицы и вспомогательная настройка смещения",
    "geometryOnly": true
  },
  "regions": []
};
