/* Editable functional scene: control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"]={
  "id": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "title": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "subtitle": "Аппаратная остановка матрицы",
  "description": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
  "nodes": [
    {
      "id": "compare",
      "title": "Обнаружение превышения тока",
      "subtitle": "",
      "description": "Быстрый компаратор сравнивает измеренный ток записи с резервным порогом отключения.",
      "refs": [
        "control_U2200",
        "control_R2200",
        "control_R2203",
        "control_C2200",
        "control_R2201",
        "control_R2202",
        "control_R2211"
      ],
      "role": "fault",
      "x": 40,
      "y": 150,
      "w": 290,
      "h": 150,
      "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2200",
          "control_R2200",
          "control_R2203",
          "control_C2200",
          "control_R2201",
          "control_R2202",
          "control_R2211"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2211",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "qualify",
      "title": "Объединение причин отключения",
      "subtitle": "",
      "description": "Логика объединяет превышение тока и ошибку конфигурации.",
      "refs": [
        "control_U2201",
        "control_U2203",
        "control_C2201",
        "control_C2203"
      ],
      "role": "fault",
      "x": 600,
      "y": 140,
      "w": 310,
      "h": 162,
      "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2201",
          "control_U2203",
          "control_C2201",
          "control_C2203"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "remember",
      "title": "Фиксация аварии",
      "subtitle": "",
      "description": "Защёлка удерживает аварийное состояние до предусмотренной последовательности сброса.",
      "refs": [
        "control_U2202",
        "control_C2202",
        "control_R2204"
      ],
      "role": "fault",
      "x": 1180,
      "y": 140,
      "w": 350,
      "h": 184,
      "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2202",
          "control_C2202",
          "control_R2204"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2204",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "inhibit",
      "title": "Снятие разрешения питания",
      "subtitle": "",
      "description": "Транзисторы передают аварию и запрет в систему питания Power.",
      "refs": [
        "control_Q2200",
        "control_Q2201",
        "control_Q2202",
        "control_Q2203",
        "control_R2205",
        "control_R2206",
        "control_R2210",
        "control_R2208",
        "control_R2209",
        "control_R2207"
      ],
      "role": "fault",
      "x": 1185,
      "y": 570,
      "w": 260,
      "h": 140,
      "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_Q2200",
          "control_Q2201",
          "control_Q2202",
          "control_Q2203",
          "control_R2205",
          "control_R2206",
          "control_R2210",
          "control_R2208",
          "control_R2209",
          "control_R2207"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_Q2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_Q2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_Q2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_Q2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2205",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2206",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2207",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2208",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2209",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R2210",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "compare_qualify",
      "from": "compare",
      "to": "qualify",
      "label": "MAT_CMP_RAW",
      "type": "data",
      "nets": [
        "control_net_7b06e5d6a4d9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_CMP_RAW",
      "netLabels": [
        "MAT_CMP_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_CMP_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "qualify_remember",
      "from": "qualify",
      "to": "remember",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "control_net_9269f101a22a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "MAT_TRIP"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_TRIP"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "remember_inhibit",
      "from": "remember",
      "to": "inhibit",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "control_net_d44a94d9b4fd"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "MAT_FAULT_Q"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_FAULT_Q"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 105,
    "w": 1570,
    "h": 645
  },
  "board": "control",
  "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 24,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U2200",
      "control_R2200",
      "control_R2203",
      "control_C2200",
      "control_R2201",
      "control_R2202",
      "control_R2211",
      "control_U2201",
      "control_U2203",
      "control_C2201",
      "control_C2203",
      "control_U2202",
      "control_C2202",
      "control_R2204",
      "control_Q2200",
      "control_Q2201",
      "control_Q2202",
      "control_Q2203",
      "control_R2205",
      "control_R2206",
      "control_R2210",
      "control_R2208",
      "control_R2209",
      "control_R2207"
    ],
    "sheetIds": [
      "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
    ],
    "units": [
      {
        "component": "control_C2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2211",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2204",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_Q2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_Q2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_Q2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_Q2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2205",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2206",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2207",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2208",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2209",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R2210",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
  ],
  "suggestedScenario": "local-control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "explanationTitleRu": "Аппаратная остановка матрицы",
  "sourceSheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "sourceSheetName": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "sourceFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control_PROTECTION",
  "layout": {
    "version": 2,
    "kind": "latched-protection",
    "label": "Обнаружение, подтверждение, память аварии и запрет",
    "geometryOnly": true
  },
  "regions": []
};
