/* Editable functional scene: control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES */
window.MIRA_FUNCTIONAL.scenes["control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"]={
  "id": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "title": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "subtitle": "Оцифровка сигнала матрицы",
  "description": "Контрольный аналоговый сигнал проходит через высокоомный буфер и дифференциальный драйвер в АЦП AD4003 U2004. Масштаб задаёт отдельный прецизионный источник опоры.",
  "nodes": [
    {
      "id": "reference",
      "title": "Опорный уровень измерения",
      "subtitle": "",
      "description": "Прецизионный источник опорного напряжения задаёт масштаб АЦП.",
      "refs": [
        "control_U2000",
        "control_U2001",
        "control_R2000",
        "control_R2001",
        "control_C2001",
        "control_C2002",
        "control_C2004",
        "control_C2017"
      ],
      "role": "analog",
      "x": 570,
      "y": 540,
      "w": 260,
      "h": 140,
      "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetIds": [
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2000",
          "control_U2001",
          "control_R2000",
          "control_R2001",
          "control_C2001",
          "control_C2002",
          "control_C2004",
          "control_C2017"
        ],
        "sheetIds": [
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_C2001",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2002",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2004",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2017",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2000",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2001",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2000",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2001",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "monitor",
      "title": "Буфер выбранного сигнала",
      "subtitle": "",
      "description": "Выбранный контрольный сигнал буферизуется перед дифференциальным преобразованием.",
      "refs": [
        "control_U2002",
        "control_R2004",
        "control_C2003",
        "control_C2014",
        "control_C2015",
        "control_C2016"
      ],
      "role": "analog",
      "x": 40,
      "y": 80,
      "w": 280,
      "h": 145,
      "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetIds": [
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2002",
          "control_R2004",
          "control_C2003",
          "control_C2014",
          "control_C2015",
          "control_C2016"
        ],
        "sheetIds": [
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_C2003",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2014",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2015",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2016",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2004",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2002",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "differential",
      "title": "Дифференциальный вход АЦП",
      "subtitle": "",
      "description": "Дифференциальный усилитель формирует два входных напряжения АЦП.",
      "refs": [
        "control_U2003",
        "control_R2002",
        "control_R2005",
        "control_R2003",
        "control_R2006",
        "control_R2009"
      ],
      "role": "analog",
      "x": 570,
      "y": 80,
      "w": 350,
      "h": 184,
      "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetIds": [
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2003",
          "control_R2002",
          "control_R2005",
          "control_R2003",
          "control_R2006",
          "control_R2009"
        ],
        "sheetIds": [
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_R2002",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2003",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2005",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2006",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2009",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2003",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "adc",
      "title": "Преобразование напряжения в число",
      "subtitle": "",
      "description": "АЦП измеряет подготовленный аналоговый сигнал и выдаёт цифровой результат.",
      "refs": [
        "control_U2004",
        "control_C2006",
        "control_R2007",
        "control_R2008",
        "control_C2008",
        "control_C2009",
        "control_C2011",
        "control_C2012"
      ],
      "role": "data",
      "x": 1170,
      "y": 80,
      "w": 350,
      "h": 184,
      "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetIds": [
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2004",
          "control_C2006",
          "control_R2007",
          "control_R2008",
          "control_C2008",
          "control_C2009",
          "control_C2011",
          "control_C2012"
        ],
        "sheetIds": [
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_C2006",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2008",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2009",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2011",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2012",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2007",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2008",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2004",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "supply",
      "title": "Питание измерительного тракта",
      "subtitle": "",
      "description": "Локальные стабилизаторы формируют питание АЦП и входного драйвера.",
      "refs": [
        "control_U2005",
        "control_U2006",
        "control_R2010",
        "control_C2000",
        "control_C2005",
        "control_C2007",
        "control_C2010",
        "control_C2013",
        "control_C2018"
      ],
      "role": "power",
      "x": 1190,
      "y": 550,
      "w": 260,
      "h": 140,
      "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetIds": [
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2005",
          "control_U2006",
          "control_R2010",
          "control_C2000",
          "control_C2005",
          "control_C2007",
          "control_C2010",
          "control_C2013",
          "control_C2018"
        ],
        "sheetIds": [
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_C2000",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2005",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2007",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2010",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2013",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_C2018",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_R2010",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2005",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2006",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "reference_differential",
      "from": "reference",
      "to": "differential",
      "label": "MAT_ADC_CM",
      "type": "data",
      "nets": [
        "control_net_43aaa7149bc5"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_ADC_CM",
      "netLabels": [
        "MAT_ADC_CM"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADC_CM"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "reference_adc",
      "from": "reference",
      "to": "adc",
      "label": "MAT_ADC_REF",
      "type": "data",
      "nets": [
        "control_net_18acc164b68f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_ADC_REF",
      "netLabels": [
        "MAT_ADC_REF"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADC_REF"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "reference_supply",
      "from": "reference",
      "to": "supply",
      "label": "MAT_REF_PRE12",
      "type": "data",
      "nets": [
        "control_net_394d6f53173b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_REF_PRE12",
      "netLabels": [
        "MAT_REF_PRE12"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_REF_PRE12"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "monitor_differential",
      "from": "monitor",
      "to": "differential",
      "label": "FDA_N",
      "type": "data",
      "nets": [
        "control_net_a636afc1774d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "FDA_N",
      "netLabels": [
        "FDA_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FDA_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "differential_adc",
      "from": "differential",
      "to": "adc",
      "label": "2 цепи",
      "type": "analog",
      "nets": [
        "control_net_87a4861c654c",
        "control_net_d96556e65ebd"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_ADC_INP",
        "MAT_ADC_INN"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADC_INP",
        "MAT_ADC_INN"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "adc_supply",
      "from": "adc",
      "to": "supply",
      "label": "MAT_ADC_1V8",
      "type": "data",
      "nets": [
        "control_net_9be4961b0c0d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_ADC_1V8",
      "netLabels": [
        "MAT_ADC_1V8"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADC_1V8"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 45,
    "w": 1560,
    "h": 685
  },
  "board": "control",
  "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 37,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U2000",
      "control_U2001",
      "control_R2000",
      "control_R2001",
      "control_C2001",
      "control_C2002",
      "control_C2004",
      "control_C2017",
      "control_U2002",
      "control_R2004",
      "control_C2003",
      "control_C2014",
      "control_C2015",
      "control_C2016",
      "control_U2003",
      "control_R2002",
      "control_R2005",
      "control_R2003",
      "control_R2006",
      "control_R2009",
      "control_U2004",
      "control_C2006",
      "control_R2007",
      "control_R2008",
      "control_C2008",
      "control_C2009",
      "control_C2011",
      "control_C2012",
      "control_U2005",
      "control_U2006",
      "control_R2010",
      "control_C2000",
      "control_C2005",
      "control_C2007",
      "control_C2010",
      "control_C2013",
      "control_C2018"
    ],
    "sheetIds": [
      "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
    ],
    "units": [
      {
        "component": "control_C2001",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2002",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2004",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2017",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2000",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2001",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2000",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2001",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2003",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2014",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2015",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2016",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2004",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2002",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2002",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2003",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2005",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2006",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2009",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2003",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2006",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2008",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2009",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2011",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2012",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2007",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2008",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2004",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2000",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2005",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2007",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2010",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2013",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_C2018",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_R2010",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2005",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2006",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
  ],
  "suggestedScenario": "local-control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "explanationTitleRu": "Оцифровка сигнала матрицы",
  "sourceSheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "sourceSheetName": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
  "sourceFile": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-readout",
  "layout": {
    "version": 2,
    "kind": "converter-with-support",
    "label": "Подготовка сигнала, АЦП, опорное напряжение и питание",
    "geometryOnly": true
  },
  "regions": []
};
