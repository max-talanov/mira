/* Editable functional scene: power_3500_MONITOR_INPUT_AON_USB_SYS */
window.MIRA_FUNCTIONAL.scenes["power_3500_MONITOR_INPUT_AON_USB_SYS"]={
  "id": "power_3500_MONITOR_INPUT_AON_USB_SYS",
  "title": "3500_MONITOR_INPUT_AON_USB_SYS",
  "subtitle": "Контроль входа и системного питания",
  "description": "U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину.",
  "nodes": [
    {
      "id": "input",
      "title": "Измерение входного питания",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3501",
        "power_C3502",
        "power_R3503",
        "power_R3501",
        "power_R3502",
        "power_C3503",
        "power_D3501",
        "power_R3504",
        "power_C3501"
      ],
      "role": "analog",
      "x": 40,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceSheetIds": [
        "power_3500_MONITOR_INPUT_AON_USB_SYS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3501",
          "power_C3502",
          "power_R3503",
          "power_R3501",
          "power_R3502",
          "power_C3503",
          "power_D3501",
          "power_R3504",
          "power_C3501"
        ],
        "sheetIds": [
          "power_3500_MONITOR_INPUT_AON_USB_SYS"
        ],
        "units": [
          {
            "component": "power_C3501",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3502",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3503",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_D3501",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3501",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3502",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3503",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3504",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3501",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "aon",
      "title": "Измерение дежурного питания",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3502",
        "power_C3506",
        "power_R3506",
        "power_R3505",
        "power_C3504",
        "power_C3505",
        "power_R3507",
        "power_D3502",
        "power_R3508"
      ],
      "role": "analog",
      "x": 620,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceSheetIds": [
        "power_3500_MONITOR_INPUT_AON_USB_SYS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3502",
          "power_C3506",
          "power_R3506",
          "power_R3505",
          "power_C3504",
          "power_C3505",
          "power_R3507",
          "power_D3502",
          "power_R3508"
        ],
        "sheetIds": [
          "power_3500_MONITOR_INPUT_AON_USB_SYS"
        ],
        "units": [
          {
            "component": "power_C3504",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3505",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3506",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_D3502",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3505",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3506",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3507",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3508",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3502",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "usb",
      "title": "Измерение питания USB",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3503",
        "power_C3509",
        "power_R3511",
        "power_D3503",
        "power_R3509",
        "power_C3508",
        "power_C3507",
        "power_R3510",
        "power_R3512"
      ],
      "role": "analog",
      "x": 1220,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceSheetIds": [
        "power_3500_MONITOR_INPUT_AON_USB_SYS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3503",
          "power_C3509",
          "power_R3511",
          "power_D3503",
          "power_R3509",
          "power_C3508",
          "power_C3507",
          "power_R3510",
          "power_R3512"
        ],
        "sheetIds": [
          "power_3500_MONITOR_INPUT_AON_USB_SYS"
        ],
        "units": [
          {
            "component": "power_C3507",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3508",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3509",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_D3503",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3509",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3510",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3511",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3512",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3503",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "system",
      "title": "Измерение системного питания",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3504",
        "power_D3504",
        "power_C3511",
        "power_C3510",
        "power_R3515",
        "power_R3513",
        "power_C3512",
        "power_R3516",
        "power_R3514"
      ],
      "role": "analog",
      "x": 620,
      "y": 490,
      "w": 310,
      "h": 164,
      "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceSheetIds": [
        "power_3500_MONITOR_INPUT_AON_USB_SYS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3504",
          "power_D3504",
          "power_C3511",
          "power_C3510",
          "power_R3515",
          "power_R3513",
          "power_C3512",
          "power_R3516",
          "power_R3514"
        ],
        "sheetIds": [
          "power_3500_MONITOR_INPUT_AON_USB_SYS"
        ],
        "units": [
          {
            "component": "power_C3510",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3511",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_C3512",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_D3504",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3513",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3514",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3515",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_R3516",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3504",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "aon_usb",
      "from": "aon",
      "to": "usb",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "aon_system",
      "from": "aon",
      "to": "system",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "usb_system",
      "from": "usb",
      "to": "system",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": -28,
    "y": -29,
    "w": 1626,
    "h": 748
  },
  "board": "power",
  "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 36,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3501",
      "power_C3502",
      "power_R3503",
      "power_R3501",
      "power_R3502",
      "power_C3503",
      "power_D3501",
      "power_R3504",
      "power_C3501",
      "power_U3502",
      "power_C3506",
      "power_R3506",
      "power_R3505",
      "power_C3504",
      "power_C3505",
      "power_R3507",
      "power_D3502",
      "power_R3508",
      "power_U3503",
      "power_C3509",
      "power_R3511",
      "power_D3503",
      "power_R3509",
      "power_C3508",
      "power_C3507",
      "power_R3510",
      "power_R3512",
      "power_U3504",
      "power_D3504",
      "power_C3511",
      "power_C3510",
      "power_R3515",
      "power_R3513",
      "power_C3512",
      "power_R3516",
      "power_R3514"
    ],
    "sheetIds": [
      "power_3500_MONITOR_INPUT_AON_USB_SYS"
    ],
    "units": [
      {
        "component": "power_C3501",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3502",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3503",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_D3501",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3501",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3502",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3503",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3504",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3501",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3504",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3505",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3506",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_D3502",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3505",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3506",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3507",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3508",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3502",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3507",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3508",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3509",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_D3503",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3509",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3510",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3511",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3512",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3503",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3510",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3511",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_C3512",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_D3504",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3513",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3514",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3515",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_R3516",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3504",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3500_MONITOR_INPUT_AON_USB_SYS"
  ],
  "suggestedScenario": "local-power_3500_MONITOR_INPUT_AON_USB_SYS",
  "explanationTitleRu": "Контроль входа и системного питания",
  "sourceSheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
  "sourceSheetName": "3500_MONITOR_INPUT_AON_USB_SYS",
  "sourceFile": "3500_MONITOR_INPUT_AON_USB_SYS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "parallel-measurement-banks",
    "label": "Равноправные измерительные каналы разных шин",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 6,
      "w": 1546,
      "h": 673,
      "title": "Параллельные измерения тока и напряжения",
      "kind": "analog",
      "nodeIds": [
        "input",
        "aon",
        "usb",
        "system"
      ]
    }
  ]
};
