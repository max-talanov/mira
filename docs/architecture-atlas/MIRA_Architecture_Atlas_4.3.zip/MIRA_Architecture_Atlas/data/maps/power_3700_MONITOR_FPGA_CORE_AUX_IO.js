/* Editable functional scene: power_3700_MONITOR_FPGA_CORE_AUX_IO */
window.MIRA_FUNCTIONAL.scenes["power_3700_MONITOR_FPGA_CORE_AUX_IO"]={
  "id": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
  "title": "3700_MONITOR_FPGA_CORE_AUX_IO",
  "subtitle": "Контроль питания ядра и выводов ПЛИС",
  "description": "U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС.",
  "nodes": [
    {
      "id": "core",
      "title": "Измерение питания ядра ПЛИС",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3701",
        "power_R3704",
        "power_R3701",
        "power_C3702",
        "power_C3703",
        "power_D3701",
        "power_C3701",
        "power_R3703",
        "power_R3702"
      ],
      "role": "analog",
      "x": 40,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceSheetIds": [
        "power_3700_MONITOR_FPGA_CORE_AUX_IO"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3701",
          "power_R3704",
          "power_R3701",
          "power_C3702",
          "power_C3703",
          "power_D3701",
          "power_C3701",
          "power_R3703",
          "power_R3702"
        ],
        "sheetIds": [
          "power_3700_MONITOR_FPGA_CORE_AUX_IO"
        ],
        "units": [
          {
            "component": "power_C3701",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3702",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3703",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_D3701",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3701",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3702",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3703",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3704",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3701",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "aux18",
      "title": "Измерение вспомогательного питания 1,8 В",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3702",
        "power_R3706",
        "power_D3702",
        "power_C3706",
        "power_C3705",
        "power_R3705",
        "power_R3707",
        "power_C3704",
        "power_R3708"
      ],
      "role": "analog",
      "x": 620,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceSheetIds": [
        "power_3700_MONITOR_FPGA_CORE_AUX_IO"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3702",
          "power_R3706",
          "power_D3702",
          "power_C3706",
          "power_C3705",
          "power_R3705",
          "power_R3707",
          "power_C3704",
          "power_R3708"
        ],
        "sheetIds": [
          "power_3700_MONITOR_FPGA_CORE_AUX_IO"
        ],
        "units": [
          {
            "component": "power_C3704",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3705",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3706",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_D3702",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3705",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3706",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3707",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3708",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3702",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "aux25",
      "title": "Измерение вспомогательного питания 2,5 В",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3703",
        "power_C3709",
        "power_R3710",
        "power_R3709",
        "power_D3703",
        "power_C3707",
        "power_C3708",
        "power_R3712",
        "power_R3711"
      ],
      "role": "analog",
      "x": 1220,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceSheetIds": [
        "power_3700_MONITOR_FPGA_CORE_AUX_IO"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3703",
          "power_C3709",
          "power_R3710",
          "power_R3709",
          "power_D3703",
          "power_C3707",
          "power_C3708",
          "power_R3712",
          "power_R3711"
        ],
        "sheetIds": [
          "power_3700_MONITOR_FPGA_CORE_AUX_IO"
        ],
        "units": [
          {
            "component": "power_C3707",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3708",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3709",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_D3703",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3709",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3710",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3711",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3712",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3703",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "io",
      "title": "Измерение питания выводов ПЛИС",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3704",
        "power_R3715",
        "power_C3712",
        "power_C3710",
        "power_D3704",
        "power_R3713",
        "power_C3711",
        "power_R3714",
        "power_R3716"
      ],
      "role": "analog",
      "x": 620,
      "y": 490,
      "w": 310,
      "h": 164,
      "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceSheetIds": [
        "power_3700_MONITOR_FPGA_CORE_AUX_IO"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3704",
          "power_R3715",
          "power_C3712",
          "power_C3710",
          "power_D3704",
          "power_R3713",
          "power_C3711",
          "power_R3714",
          "power_R3716"
        ],
        "sheetIds": [
          "power_3700_MONITOR_FPGA_CORE_AUX_IO"
        ],
        "units": [
          {
            "component": "power_C3710",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3711",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_C3712",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_D3704",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3713",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3714",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3715",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_R3716",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3704",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "core_aux18",
      "from": "core",
      "to": "aux18",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "core_aux25",
      "from": "core",
      "to": "aux25",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "core_io",
      "from": "core",
      "to": "io",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "aux18_aux25",
      "from": "aux18",
      "to": "aux25",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "aux18_io",
      "from": "aux18",
      "to": "io",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "aux25_io",
      "from": "aux25",
      "to": "io",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": -28,
    "y": -29,
    "w": 1626,
    "h": 748
  },
  "board": "power",
  "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 36,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3701",
      "power_R3704",
      "power_R3701",
      "power_C3702",
      "power_C3703",
      "power_D3701",
      "power_C3701",
      "power_R3703",
      "power_R3702",
      "power_U3702",
      "power_R3706",
      "power_D3702",
      "power_C3706",
      "power_C3705",
      "power_R3705",
      "power_R3707",
      "power_C3704",
      "power_R3708",
      "power_U3703",
      "power_C3709",
      "power_R3710",
      "power_R3709",
      "power_D3703",
      "power_C3707",
      "power_C3708",
      "power_R3712",
      "power_R3711",
      "power_U3704",
      "power_R3715",
      "power_C3712",
      "power_C3710",
      "power_D3704",
      "power_R3713",
      "power_C3711",
      "power_R3714",
      "power_R3716"
    ],
    "sheetIds": [
      "power_3700_MONITOR_FPGA_CORE_AUX_IO"
    ],
    "units": [
      {
        "component": "power_C3701",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3702",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3703",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_D3701",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3701",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3702",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3703",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3704",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3701",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3704",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3705",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3706",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_D3702",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3705",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3706",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3707",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3708",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3702",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3707",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3708",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3709",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_D3703",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3709",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3710",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3711",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3712",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3703",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3710",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3711",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_C3712",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_D3704",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3713",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3714",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3715",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_R3716",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3704",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3700_MONITOR_FPGA_CORE_AUX_IO"
  ],
  "suggestedScenario": "local-power_3700_MONITOR_FPGA_CORE_AUX_IO",
  "explanationTitleRu": "Контроль питания ядра и выводов ПЛИС",
  "sourceSheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
  "sourceSheetName": "3700_MONITOR_FPGA_CORE_AUX_IO",
  "sourceFile": "3700_MONITOR_FPGA_CORE_AUX_IO.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "parallel-measurement-banks",
    "label": "Равноправные измерительные каналы разных шин",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 6,
      "w": 1546,
      "h": 673,
      "title": "Параллельные измерения тока и напряжения",
      "kind": "analog",
      "nodeIds": [
        "core",
        "aux18",
        "aux25",
        "io"
      ]
    }
  ]
};
