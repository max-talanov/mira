/* Editable functional scene: control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR */
window.MIRA_FUNCTIONAL.scenes["control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"]={
  "id": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "title": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "subtitle": "Выбор строк и измерительных линий",
  "description": "U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата.",
  "nodes": [
    {
      "id": "word",
      "title": "Управление выбранными строками",
      "subtitle": "",
      "description": "Ключи строк подключают выбранное воздействие к восьми линиям WL.",
      "refs": [
        "control_U1700",
        "control_U1701",
        "control_R1708",
        "control_C1700",
        "control_R1713",
        "control_C1701",
        "control_R1702",
        "control_R1707",
        "control_R1712",
        "control_R1710",
        "control_R1701",
        "control_R1703",
        "control_R1711",
        "control_R1714",
        "control_R1700",
        "control_R1709",
        "control_R1715",
        "control_R1704",
        "control_R1706",
        "control_R1705"
      ],
      "role": "analog",
      "x": 40,
      "y": 80,
      "w": 310,
      "h": 158,
      "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceSheetIds": [
        "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1700",
          "control_U1701",
          "control_R1708",
          "control_C1700",
          "control_R1713",
          "control_C1701",
          "control_R1702",
          "control_R1707",
          "control_R1712",
          "control_R1710",
          "control_R1701",
          "control_R1703",
          "control_R1711",
          "control_R1714",
          "control_R1700",
          "control_R1709",
          "control_R1715",
          "control_R1704",
          "control_R1706",
          "control_R1705"
        ],
        "sheetIds": [
          "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
        ],
        "units": [
          {
            "component": "control_C1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1704",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1705",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1706",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1707",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1708",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1709",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1710",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1711",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1712",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1713",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1714",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1715",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1700",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1701",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "clamp",
      "title": "Фиксация неактивных линий NL",
      "subtitle": "",
      "description": "Зажимные ключи задают состояние неактивных линий NL.",
      "refs": [
        "control_U1702",
        "control_U1703",
        "control_R1724",
        "control_R1725",
        "control_R1717",
        "control_R1720",
        "control_R1728",
        "control_R1729",
        "control_R1727",
        "control_R1730",
        "control_R1721",
        "control_R1719",
        "control_R1726",
        "control_R1716",
        "control_R1718",
        "control_R1731",
        "control_R1722",
        "control_R1723"
      ],
      "role": "analog",
      "x": 40,
      "y": 520,
      "w": 310,
      "h": 158,
      "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceSheetIds": [
        "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1702",
          "control_U1703",
          "control_R1724",
          "control_R1725",
          "control_R1717",
          "control_R1720",
          "control_R1728",
          "control_R1729",
          "control_R1727",
          "control_R1730",
          "control_R1721",
          "control_R1719",
          "control_R1726",
          "control_R1716",
          "control_R1718",
          "control_R1731",
          "control_R1722",
          "control_R1723"
        ],
        "sheetIds": [
          "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
        ],
        "units": [
          {
            "component": "control_R1716",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1717",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1718",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1719",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1720",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1721",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1722",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1723",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1724",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1725",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1726",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1727",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1728",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1729",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1730",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1731",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 4
          },
          {
            "component": "control_U1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "selection",
      "title": "Выбор измеряемой линии NL",
      "subtitle": "",
      "description": "Аналоговый селектор подключает одну линию NL к измерительному тракту.",
      "refs": [
        "control_U1705",
        "control_C1705",
        "control_C1704",
        "control_C1703",
        "control_C1706",
        "control_C1710",
        "control_C1702",
        "control_C1708"
      ],
      "role": "analog",
      "x": 760,
      "y": 295,
      "w": 350,
      "h": 184,
      "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceSheetIds": [
        "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1705",
          "control_C1705",
          "control_C1704",
          "control_C1703",
          "control_C1706",
          "control_C1710",
          "control_C1702",
          "control_C1708"
        ],
        "sheetIds": [
          "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
        ],
        "units": [
          {
            "component": "control_C1702",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1703",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1704",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1705",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1706",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1708",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1710",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1705",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "permit",
      "title": "Проверка команд коммутации",
      "subtitle": "",
      "description": "Логика объединяет управляющие сигналы сети выбора линий.",
      "refs": [
        "control_U1704",
        "control_R1732",
        "control_C1707",
        "control_C1709"
      ],
      "role": "control",
      "x": 780,
      "y": -80,
      "w": 260,
      "h": 140,
      "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
      "sourceSheetIds": [
        "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1704",
          "control_R1732",
          "control_C1707",
          "control_C1709"
        ],
        "sheetIds": [
          "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
        ],
        "units": [
          {
            "component": "control_C1707",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1709",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1732",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1704",
            "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "clamp_selection",
      "from": "clamp",
      "to": "selection",
      "label": "8 цепей",
      "type": "analog",
      "nets": [
        "control_net_919f25939ba9",
        "control_net_79947d226d73",
        "control_net_d380ae123eb3",
        "control_net_5212ff00c1ac",
        "control_net_072af1a28ea6",
        "control_net_e8ccb5161adb",
        "control_net_3762f1a58fed",
        "control_net_e4379a2b0f61"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "8 цепей",
      "netLabels": [
        "NL4",
        "NL0",
        "NL3",
        "NL7",
        "NL6",
        "NL5",
        "NL2",
        "NL1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "NL0 · NL1",
        "NL2 · NL3",
        "NL4 · NL5",
        "NL6 · NL7"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "selection_permit",
      "from": "selection",
      "to": "permit",
      "label": "MAT_NL_SAFE",
      "type": "analog",
      "nets": [
        "control_net_fdc5577f6544"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_NL_SAFE",
      "netLabels": [
        "MAT_NL_SAFE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_NL_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": 0,
    "y": -115,
    "w": 1150,
    "h": 833
  },
  "board": "control",
  "sheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 50,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1700",
      "control_U1701",
      "control_R1708",
      "control_C1700",
      "control_R1713",
      "control_C1701",
      "control_R1702",
      "control_R1707",
      "control_R1712",
      "control_R1710",
      "control_R1701",
      "control_R1703",
      "control_R1711",
      "control_R1714",
      "control_R1700",
      "control_R1709",
      "control_R1715",
      "control_R1704",
      "control_R1706",
      "control_R1705",
      "control_U1702",
      "control_U1703",
      "control_R1724",
      "control_R1725",
      "control_R1717",
      "control_R1720",
      "control_R1728",
      "control_R1729",
      "control_R1727",
      "control_R1730",
      "control_R1721",
      "control_R1719",
      "control_R1726",
      "control_R1716",
      "control_R1718",
      "control_R1731",
      "control_R1722",
      "control_R1723",
      "control_U1705",
      "control_C1705",
      "control_C1704",
      "control_C1703",
      "control_C1706",
      "control_C1710",
      "control_C1702",
      "control_C1708",
      "control_U1704",
      "control_R1732",
      "control_C1707",
      "control_C1709"
    ],
    "sheetIds": [
      "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
    ],
    "units": [
      {
        "component": "control_C1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1704",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1705",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1706",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1707",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1708",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1709",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1710",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1711",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1712",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1713",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1714",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1715",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1700",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1701",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_R1716",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1717",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1718",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1719",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1720",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1721",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1722",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1723",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1724",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1725",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1726",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1727",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1728",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1729",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1730",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1731",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 4
      },
      {
        "component": "control_U1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 5
      },
      {
        "component": "control_C1702",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1703",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1704",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1705",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1706",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1708",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1710",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1705",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1707",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1709",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1732",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1704",
        "sheet": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR"
  ],
  "suggestedScenario": "local-control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "explanationTitleRu": "Выбор строк и измерительных линий",
  "sourceSheetId": "control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "sourceSheetName": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR",
  "sourceFile": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-routing",
  "layout": {
    "version": 2,
    "kind": "routing-fan-in",
    "label": "Выбор строк и измерительного пути",
    "geometryOnly": true
  },
  "regions": []
};
