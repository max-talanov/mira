/* Editable functional scene: power_2900_PM_ANALOG_POWER_GOOD */
window.MIRA_FUNCTIONAL.scenes["power_2900_PM_ANALOG_POWER_GOOD"]={
  "id": "power_2900_PM_ANALOG_POWER_GOOD",
  "title": "2900_PM_ANALOG_POWER_GOOD",
  "subtitle": "Проверка допустимых напряжений",
  "description": "U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON.",
  "nodes": [
    {
      "id": "threshold",
      "title": "Задание допустимых диапазонов",
      "subtitle": "",
      "description": "Делители задают пороги компараторов для проверки аналогового питания.",
      "refs": [
        "power_R2901",
        "power_R2902",
        "power_R2903",
        "power_R2904",
        "power_R2905",
        "power_R2906",
        "power_R2907",
        "power_R2908",
        "power_R2909",
        "power_R2910",
        "power_R2911",
        "power_R2912",
        "power_C2902",
        "power_C2905",
        "power_C2904",
        "power_C2903",
        "power_C2901"
      ],
      "role": "analog",
      "x": 40,
      "y": 75,
      "w": 250,
      "h": 134,
      "sheetId": "power_2900_PM_ANALOG_POWER_GOOD",
      "sourceSheetIds": [
        "power_2900_PM_ANALOG_POWER_GOOD"
      ],
      "circuitGroup": {
        "refs": [
          "power_R2901",
          "power_R2902",
          "power_R2903",
          "power_R2904",
          "power_R2905",
          "power_R2906",
          "power_R2907",
          "power_R2908",
          "power_R2909",
          "power_R2910",
          "power_R2911",
          "power_R2912",
          "power_C2902",
          "power_C2905",
          "power_C2904",
          "power_C2903",
          "power_C2901"
        ],
        "sheetIds": [
          "power_2900_PM_ANALOG_POWER_GOOD"
        ],
        "units": [
          {
            "component": "power_C2901",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_C2902",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_C2903",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_C2904",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_C2905",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2901",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2902",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2903",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2904",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2905",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2906",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2907",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2908",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2909",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2910",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2911",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          },
          {
            "component": "power_R2912",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "compare",
      "title": "Проверка аналоговых напряжений",
      "subtitle": "",
      "description": "Четырёхканальный компаратор преобразует измеренные напряжения в цифровые сигналы готовности.",
      "refs": [
        "power_U2901"
      ],
      "role": "fault",
      "x": 620,
      "y": 230,
      "w": 360,
      "h": 194,
      "sheetId": "power_2900_PM_ANALOG_POWER_GOOD",
      "sourceSheetIds": [
        "power_2900_PM_ANALOG_POWER_GOOD"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2901"
        ],
        "sheetIds": [
          "power_2900_PM_ANALOG_POWER_GOOD"
        ],
        "units": [
          {
            "component": "power_U2901",
            "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "threshold_compare",
      "from": "threshold",
      "to": "compare",
      "label": "8 цепей",
      "type": "control",
      "nets": [
        "power_net_ae3b1a85f32f",
        "power_net_e46274585def",
        "power_net_61199f10a0d6",
        "power_net_0c8e0f29b47d",
        "power_net_d3607cfa6b03",
        "power_net_de65996f492f",
        "power_net_9ec66895516f",
        "power_net_6a587efc79ba"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "8 цепей",
      "netLabels": [
        "PG_USB",
        "PG_ANA",
        "PG_P15",
        "PG_N15"
      ],
      "unnamedNetIds": [
        "power_net_d3607cfa6b03",
        "power_net_de65996f492f",
        "power_net_9ec66895516f",
        "power_net_6a587efc79ba"
      ],
      "labelLines": [
        "PG_ANA · PG_N15",
        "PG_P15 · PG_USB"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 40,
    "w": 1020,
    "h": 424
  },
  "board": "power",
  "sheetId": "power_2900_PM_ANALOG_POWER_GOOD",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 18,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_R2901",
      "power_R2902",
      "power_R2903",
      "power_R2904",
      "power_R2905",
      "power_R2906",
      "power_R2907",
      "power_R2908",
      "power_R2909",
      "power_R2910",
      "power_R2911",
      "power_R2912",
      "power_C2902",
      "power_C2905",
      "power_C2904",
      "power_C2903",
      "power_C2901",
      "power_U2901"
    ],
    "sheetIds": [
      "power_2900_PM_ANALOG_POWER_GOOD"
    ],
    "units": [
      {
        "component": "power_C2901",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_C2902",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_C2903",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_C2904",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_C2905",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2901",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2902",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2903",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2904",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2905",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2906",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2907",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2908",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2909",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2910",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2911",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_R2912",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      },
      {
        "component": "power_U2901",
        "sheet": "power_2900_PM_ANALOG_POWER_GOOD",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2900_PM_ANALOG_POWER_GOOD"
  ],
  "suggestedScenario": "local-power_2900_PM_ANALOG_POWER_GOOD",
  "explanationTitleRu": "Проверка допустимых напряжений",
  "sourceSheetId": "power_2900_PM_ANALOG_POWER_GOOD",
  "sourceSheetName": "2900_PM_ANALOG_POWER_GOOD",
  "sourceFile": "2900_PM_ANALOG_POWER_GOOD.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "comparison-with-reference",
    "label": "Компаратор и отдельная цепь задания порогов",
    "geometryOnly": true
  },
  "regions": []
};
