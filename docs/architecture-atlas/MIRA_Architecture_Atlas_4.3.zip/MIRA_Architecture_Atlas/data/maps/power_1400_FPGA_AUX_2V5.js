/* Editable functional scene: power_1400_FPGA_AUX_2V5 */
window.MIRA_FUNCTIONAL.scenes["power_1400_FPGA_AUX_2V5"]={
  "id": "power_1400_FPGA_AUX_2V5",
  "title": "1400_FPGA_AUX_2V5",
  "subtitle": "Вспомогательное питание 2,5 В",
  "description": "U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход FPGA5V5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1400_FPGA_AUX_2V5"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1400_FPGA_AUX_2V5"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Вспомогательное питание 2,5 В: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1401",
        "power_L1401",
        "power_R1403",
        "power_R1404",
        "power_R1405",
        "power_R1402"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1400_FPGA_AUX_2V5",
      "sourceSheetIds": [
        "power_1400_FPGA_AUX_2V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1401",
          "power_L1401",
          "power_R1403",
          "power_R1404",
          "power_R1405",
          "power_R1402"
        ],
        "sheetIds": [
          "power_1400_FPGA_AUX_2V5"
        ],
        "units": [
          {
            "component": "power_L1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_R1402",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_R1403",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_R1404",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_R1405",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_U1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1401",
        "power_R1401"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1400_FPGA_AUX_2V5",
      "sourceSheetIds": [
        "power_1400_FPGA_AUX_2V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1401",
          "power_R1401"
        ],
        "sheetIds": [
          "power_1400_FPGA_AUX_2V5"
        ],
        "units": [
          {
            "component": "power_Q1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_R1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1403",
        "power_C1401",
        "power_C1402",
        "power_C1404",
        "power_R1406"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1400_FPGA_AUX_2V5",
      "sourceSheetIds": [
        "power_1400_FPGA_AUX_2V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1403",
          "power_C1401",
          "power_C1402",
          "power_C1404",
          "power_R1406"
        ],
        "sheetIds": [
          "power_1400_FPGA_AUX_2V5"
        ],
        "units": [
          {
            "component": "power_C1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_C1402",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_C1403",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_C1404",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_R1406",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход AUX2V5",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1400_FPGA_AUX_2V5"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1400_FPGA_AUX_2V5"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_4a44013bf2b3",
        "power_net_38cd986dd59a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "AUX2V5",
        "AUX25_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AUX2V5",
        "AUX25_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "AUX2V5",
      "type": "power",
      "nets": [
        "power_net_4a44013bf2b3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "AUX2V5",
      "netLabels": [
        "AUX2V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AUX2V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_0faf4b6ebbf5",
        "power_net_8d8d482ee874"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_AUX25",
        "EN_AUX25"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_AUX25",
        "EN_AUX25"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1400_FPGA_AUX_2V5",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1401",
      "power_L1401",
      "power_R1403",
      "power_R1404",
      "power_R1405",
      "power_R1402",
      "power_Q1401",
      "power_R1401",
      "power_C1403",
      "power_C1401",
      "power_C1402",
      "power_C1404",
      "power_R1406"
    ],
    "sheetIds": [
      "power_1400_FPGA_AUX_2V5"
    ],
    "units": [
      {
        "component": "power_L1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_R1402",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_R1403",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_R1404",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_R1405",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_U1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_Q1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_R1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_C1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_C1402",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_C1403",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_C1404",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_R1406",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1400_FPGA_AUX_2V5"
  ],
  "suggestedScenario": "local-power_1400_FPGA_AUX_2V5",
  "explanationTitleRu": "Вспомогательное питание 2,5 В",
  "sourceSheetId": "power_1400_FPGA_AUX_2V5",
  "sourceSheetName": "1400_FPGA_AUX_2V5",
  "sourceFile": "1400_FPGA_AUX_2V5.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
