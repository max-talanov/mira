/* Editable functional scene: power_3600_MONITOR_FPGA_ANA_AFE */
window.MIRA_FUNCTIONAL.scenes["power_3600_MONITOR_FPGA_ANA_AFE"]={
  "id": "power_3600_MONITOR_FPGA_ANA_AFE",
  "title": "3600_MONITOR_FPGA_ANA_AFE",
  "subtitle": "Контроль ПЛИС и аналогового питания",
  "description": "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE.",
  "nodes": [
    {
      "id": "fpga",
      "title": "Измерение промежуточного питания ПЛИС",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3601",
        "power_C3603",
        "power_R3601",
        "power_R3602",
        "power_C3601",
        "power_R3603",
        "power_C3602",
        "power_D3601",
        "power_R3604"
      ],
      "role": "analog",
      "x": 40,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "sourceSheetIds": [
        "power_3600_MONITOR_FPGA_ANA_AFE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3601",
          "power_C3603",
          "power_R3601",
          "power_R3602",
          "power_C3601",
          "power_R3603",
          "power_C3602",
          "power_D3601",
          "power_R3604"
        ],
        "sheetIds": [
          "power_3600_MONITOR_FPGA_ANA_AFE"
        ],
        "units": [
          {
            "component": "power_C3601",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_C3602",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_C3603",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_D3601",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3601",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3602",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3603",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3604",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3601",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "analog",
      "title": "Измерение аналогового предстабилизатора",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3602",
        "power_R3608",
        "power_R3605",
        "power_R3606",
        "power_C3606",
        "power_D3602",
        "power_R3607",
        "power_C3604",
        "power_C3605"
      ],
      "role": "analog",
      "x": 630,
      "y": 210,
      "w": 310,
      "h": 164,
      "sheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "sourceSheetIds": [
        "power_3600_MONITOR_FPGA_ANA_AFE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3602",
          "power_R3608",
          "power_R3605",
          "power_R3606",
          "power_C3606",
          "power_D3602",
          "power_R3607",
          "power_C3604",
          "power_C3605"
        ],
        "sheetIds": [
          "power_3600_MONITOR_FPGA_ANA_AFE"
        ],
        "units": [
          {
            "component": "power_C3604",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_C3605",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_C3606",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_D3602",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3605",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3606",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3607",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3608",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3602",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "positive",
      "title": "Измерение положительной аналоговой шины",
      "subtitle": "",
      "description": "Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.",
      "refs": [
        "power_U3603",
        "power_C3607",
        "power_R3612",
        "power_R3609",
        "power_D3603",
        "power_R3611",
        "power_C3608",
        "power_C3609",
        "power_R3610"
      ],
      "role": "analog",
      "x": 1220,
      "y": 60,
      "w": 310,
      "h": 164,
      "sheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "sourceSheetIds": [
        "power_3600_MONITOR_FPGA_ANA_AFE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3603",
          "power_C3607",
          "power_R3612",
          "power_R3609",
          "power_D3603",
          "power_R3611",
          "power_C3608",
          "power_C3609",
          "power_R3610"
        ],
        "sheetIds": [
          "power_3600_MONITOR_FPGA_ANA_AFE"
        ],
        "units": [
          {
            "component": "power_C3607",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_C3608",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_C3609",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_D3603",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3609",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3610",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3611",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_R3612",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3603",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "fpga_analog",
      "from": "fpga",
      "to": "analog",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_positive",
      "from": "fpga",
      "to": "positive",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "analog_positive",
      "from": "analog",
      "to": "positive",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": -28,
    "y": -29,
    "w": 1626,
    "h": 468
  },
  "board": "power",
  "sheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 27,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3601",
      "power_C3603",
      "power_R3601",
      "power_R3602",
      "power_C3601",
      "power_R3603",
      "power_C3602",
      "power_D3601",
      "power_R3604",
      "power_U3602",
      "power_R3608",
      "power_R3605",
      "power_R3606",
      "power_C3606",
      "power_D3602",
      "power_R3607",
      "power_C3604",
      "power_C3605",
      "power_U3603",
      "power_C3607",
      "power_R3612",
      "power_R3609",
      "power_D3603",
      "power_R3611",
      "power_C3608",
      "power_C3609",
      "power_R3610"
    ],
    "sheetIds": [
      "power_3600_MONITOR_FPGA_ANA_AFE"
    ],
    "units": [
      {
        "component": "power_C3601",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3602",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3603",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_D3601",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3601",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3602",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3603",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3604",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3601",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3604",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3605",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3606",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_D3602",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3605",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3606",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3607",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3608",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3602",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3607",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3608",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_C3609",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_D3603",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3609",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3610",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3611",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_R3612",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3603",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3600_MONITOR_FPGA_ANA_AFE"
  ],
  "suggestedScenario": "local-power_3600_MONITOR_FPGA_ANA_AFE",
  "explanationTitleRu": "Контроль ПЛИС и аналогового питания",
  "sourceSheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
  "sourceSheetName": "3600_MONITOR_FPGA_ANA_AFE",
  "sourceFile": "3600_MONITOR_FPGA_ANA_AFE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "parallel-measurement-banks",
    "label": "Равноправные измерительные каналы разных шин",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 6,
      "w": 1546,
      "h": 393,
      "title": "Параллельные измерения тока и напряжения",
      "kind": "analog",
      "nodeIds": [
        "fpga",
        "analog",
        "positive"
      ]
    }
  ]
};
