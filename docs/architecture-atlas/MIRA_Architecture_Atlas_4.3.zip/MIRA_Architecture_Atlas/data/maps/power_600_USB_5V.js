/* Editable functional scene: power_600_USB_5V */
window.MIRA_FUNCTIONAL.scenes["power_600_USB_5V"]={
  "id": "power_600_USB_5V",
  "title": "600_USB_5V",
  "subtitle": "Питание USB 5 В",
  "description": "U601 преобразует BUS24 в USB5 для интерфейса USB платы.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_600_USB_5V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_600_USB_5V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Питание USB: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U601",
        "power_L601",
        "power_R603",
        "power_R602"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_600_USB_5V",
      "sourceSheetIds": [
        "power_600_USB_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U601",
          "power_L601",
          "power_R603",
          "power_R602"
        ],
        "sheetIds": [
          "power_600_USB_5V"
        ],
        "units": [
          {
            "component": "power_L601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_R602",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_R603",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_U601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q601",
        "power_R601"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_600_USB_5V",
      "sourceSheetIds": [
        "power_600_USB_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q601",
          "power_R601"
        ],
        "sheetIds": [
          "power_600_USB_5V"
        ],
        "units": [
          {
            "component": "power_Q601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_R601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C603",
        "power_C605",
        "power_C604",
        "power_C601",
        "power_C602",
        "power_R605",
        "power_R604",
        "power_D601"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_600_USB_5V",
      "sourceSheetIds": [
        "power_600_USB_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_C603",
          "power_C605",
          "power_C604",
          "power_C601",
          "power_C602",
          "power_R605",
          "power_R604",
          "power_D601"
        ],
        "sheetIds": [
          "power_600_USB_5V"
        ],
        "units": [
          {
            "component": "power_C601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_C602",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_C603",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_C604",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_C605",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_D601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_R604",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_R605",
            "sheet": "power_600_USB_5V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход USB5",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_600_USB_5V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_600_USB_5V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_4413b84fafe0",
        "power_net_17beae47ec7a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "USB5",
        "USB_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB5",
        "USB_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "USB5",
      "type": "power",
      "nets": [
        "power_net_4413b84fafe0"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "USB5",
      "netLabels": [
        "USB5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_6649c6cdd008",
        "power_net_7cbabff32742"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_USB",
        "EN_USB"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_USB",
        "EN_USB"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_600_USB_5V",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 14,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U601",
      "power_L601",
      "power_R603",
      "power_R602",
      "power_Q601",
      "power_R601",
      "power_C603",
      "power_C605",
      "power_C604",
      "power_C601",
      "power_C602",
      "power_R605",
      "power_R604",
      "power_D601"
    ],
    "sheetIds": [
      "power_600_USB_5V"
    ],
    "units": [
      {
        "component": "power_L601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_R602",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_R603",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_U601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_Q601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_R601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_C601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_C602",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_C603",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_C604",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_C605",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_D601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_R604",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_R605",
        "sheet": "power_600_USB_5V",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_600_USB_5V"
  ],
  "suggestedScenario": "local-power_600_USB_5V",
  "explanationTitleRu": "Питание USB 5 В",
  "sourceSheetId": "power_600_USB_5V",
  "sourceSheetName": "600_USB_5V",
  "sourceFile": "600_USB_5V.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
