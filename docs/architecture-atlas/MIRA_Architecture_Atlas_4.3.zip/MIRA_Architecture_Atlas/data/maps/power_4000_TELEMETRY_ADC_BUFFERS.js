/* Editable functional scene: power_4000_TELEMETRY_ADC_BUFFERS */
window.MIRA_FUNCTIONAL.scenes["power_4000_TELEMETRY_ADC_BUFFERS"]={
  "id": "power_4000_TELEMETRY_ADC_BUFFERS",
  "title": "4000_TELEMETRY_ADC_BUFFERS",
  "subtitle": "Буферы измерений для контроллера",
  "description": "U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания.",
  "nodes": [
    {
      "id": "buffer",
      "title": "Буферы перед АЦП контроллера",
      "subtitle": "",
      "description": "Два повторителя изолируют выбранные сигналы тока и напряжения от импульсной нагрузки входов АЦП.",
      "refs": [
        "power_U4001"
      ],
      "role": "analog",
      "x": 40,
      "y": 180,
      "w": 350,
      "h": 184,
      "sheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "sourceSheetIds": [
        "power_4000_TELEMETRY_ADC_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U4001"
        ],
        "sheetIds": [
          "power_4000_TELEMETRY_ADC_BUFFERS"
        ],
        "units": [
          {
            "component": "power_U4001",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "default",
      "title": "Начальные состояния выбора и аварий",
      "subtitle": "",
      "description": "Цепи смещения, выходной развязки и фильтрации задают поведение при запуске и работе с АЦП.",
      "refs": [
        "power_R4007",
        "power_R4008",
        "power_C4003",
        "power_R4005",
        "power_R4002",
        "power_R4006",
        "power_C4002",
        "power_C4001",
        "power_R4004",
        "power_R4003",
        "power_R4001"
      ],
      "role": "control",
      "x": 760,
      "y": 195,
      "w": 280,
      "h": 150,
      "sheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "sourceSheetIds": [
        "power_4000_TELEMETRY_ADC_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "power_R4007",
          "power_R4008",
          "power_C4003",
          "power_R4005",
          "power_R4002",
          "power_R4006",
          "power_C4002",
          "power_C4001",
          "power_R4004",
          "power_R4003",
          "power_R4001"
        ],
        "sheetIds": [
          "power_4000_TELEMETRY_ADC_BUFFERS"
        ],
        "units": [
          {
            "component": "power_C4001",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_C4002",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_C4003",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4001",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4002",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4003",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4004",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4005",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4006",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4007",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          },
          {
            "component": "power_R4008",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "buffer_default",
      "from": "buffer",
      "to": "default",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "power_net_a13f4f0d6d68",
        "power_net_1980cbe8a6c0"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [],
      "unnamedNetIds": [
        "power_net_a13f4f0d6d68",
        "power_net_1980cbe8a6c0"
      ],
      "labelLines": [],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1080,
    "h": 259
  },
  "board": "power",
  "sheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 12,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U4001",
      "power_R4007",
      "power_R4008",
      "power_C4003",
      "power_R4005",
      "power_R4002",
      "power_R4006",
      "power_C4002",
      "power_C4001",
      "power_R4004",
      "power_R4003",
      "power_R4001"
    ],
    "sheetIds": [
      "power_4000_TELEMETRY_ADC_BUFFERS"
    ],
    "units": [
      {
        "component": "power_U4001",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_C4001",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_C4002",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_C4003",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4001",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4002",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4003",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4004",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4005",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4006",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4007",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      },
      {
        "component": "power_R4008",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_4000_TELEMETRY_ADC_BUFFERS"
  ],
  "suggestedScenario": "local-power_4000_TELEMETRY_ADC_BUFFERS",
  "explanationTitleRu": "Буферы измерений для контроллера",
  "sourceSheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
  "sourceSheetName": "4000_TELEMETRY_ADC_BUFFERS",
  "sourceFile": "4000_TELEMETRY_ADC_BUFFERS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
