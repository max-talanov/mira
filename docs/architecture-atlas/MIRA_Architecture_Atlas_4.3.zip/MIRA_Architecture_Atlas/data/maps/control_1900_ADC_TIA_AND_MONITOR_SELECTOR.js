/* Editable functional scene: control_1900_ADC_TIA_AND_MONITOR_SELECTOR */
window.MIRA_FUNCTIONAL.scenes["control_1900_ADC_TIA_AND_MONITOR_SELECTOR"]={
  "id": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "title": "1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "subtitle": "Преобразование тока матрицы в напряжение",
  "description": "U1900 преобразует выбранный ток матрицы в напряжение. U1901 выбирает диапазон обратной связи, U1902 — контролируемую аналоговую точку.",
  "nodes": [
    {
      "id": "current",
      "title": "Преобразование тока в напряжение",
      "subtitle": "",
      "description": "Трансимпедансный усилитель преобразует возвращающийся ток матрицы в измеряемое напряжение.",
      "refs": [
        "control_U1900",
        "control_C1903",
        "control_C1904",
        "control_C1901",
        "control_C1902",
        "control_C1900",
        "control_R1900"
      ],
      "role": "analog",
      "x": 40,
      "y": 160,
      "w": 350,
      "h": 184,
      "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1900",
          "control_C1903",
          "control_C1904",
          "control_C1901",
          "control_C1902",
          "control_C1900",
          "control_R1900"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
        ],
        "units": [
          {
            "component": "control_C1900",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1901",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1902",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1904",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1900",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1900",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "range",
      "title": "Выбор чувствительности по току",
      "subtitle": "",
      "description": "Выбор обратной связи меняет диапазон преобразования тока в напряжение.",
      "refs": [
        "control_U1901",
        "control_C1913",
        "control_C1912",
        "control_R1907",
        "control_C1911",
        "control_C1910",
        "control_R1901",
        "control_C1905",
        "control_R1906",
        "control_R1903",
        "control_C1908",
        "control_C1914",
        "control_R1904",
        "control_C1907",
        "control_R1908",
        "control_R1902",
        "control_C1909",
        "control_R1905",
        "control_C1906"
      ],
      "role": "control",
      "x": 55,
      "y": 575,
      "w": 260,
      "h": 140,
      "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1901",
          "control_C1913",
          "control_C1912",
          "control_R1907",
          "control_C1911",
          "control_C1910",
          "control_R1901",
          "control_C1905",
          "control_R1906",
          "control_R1903",
          "control_C1908",
          "control_C1914",
          "control_R1904",
          "control_C1907",
          "control_R1908",
          "control_R1902",
          "control_C1909",
          "control_R1905",
          "control_C1906"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
        ],
        "units": [
          {
            "component": "control_C1905",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1906",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1907",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1908",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1909",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1910",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1911",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1912",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1913",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1914",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1901",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1902",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1904",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1905",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1906",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1907",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_R1908",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1901",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "monitor",
      "title": "Выбор точки контроля",
      "subtitle": "",
      "description": "Аналоговый селектор выбирает диагностический сигнал или сигнал контроля источника.",
      "refs": [
        "control_U1902",
        "control_C1915",
        "control_C1916",
        "control_C1917",
        "control_C1918"
      ],
      "role": "analog",
      "x": 610,
      "y": 170,
      "w": 300,
      "h": 154,
      "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1902",
          "control_C1915",
          "control_C1916",
          "control_C1917",
          "control_C1918"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
        ],
        "units": [
          {
            "component": "control_C1915",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1916",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1917",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_C1918",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1902",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "buffer",
      "title": "Наблюдение без нагрузки",
      "subtitle": "",
      "description": "Высокоомные буферы изолируют контрольные точки регулятора от нагрузки селектора.",
      "refs": [
        "control_U1903"
      ],
      "role": "analog",
      "x": 1190,
      "y": 160,
      "w": 350,
      "h": 184,
      "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1903"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
        ],
        "units": [
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 3
          }
        ]
      },
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "current_range",
      "from": "current",
      "to": "range",
      "label": "2 цепи",
      "type": "analog",
      "nets": [
        "control_net_d65f00f0a2d4",
        "control_net_f993730bd850"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_TIA_IN",
        "MAT_TIA_OUT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_TIA_IN",
        "MAT_TIA_OUT"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "current_monitor",
      "from": "current",
      "to": "monitor",
      "label": "MAT_TIA_OUT",
      "type": "analog",
      "nets": [
        "control_net_f993730bd850"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_TIA_OUT",
      "netLabels": [
        "MAT_TIA_OUT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_TIA_OUT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "range_monitor",
      "from": "range",
      "to": "monitor",
      "label": "MAT_TIA_OUT",
      "type": "analog",
      "nets": [
        "control_net_f993730bd850"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_TIA_OUT",
      "netLabels": [
        "MAT_TIA_OUT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_TIA_OUT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "monitor_buffer",
      "from": "monitor",
      "to": "buffer",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_CC_SENSE_BUF",
        "MAT_ILIM_SENSE_BUF"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_CC_SENSE_BUF",
        "MAT_ILIM_SENSE_BUF"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 125,
    "w": 1580,
    "h": 630
  },
  "board": "control",
  "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 32,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1900",
      "control_C1903",
      "control_C1904",
      "control_C1901",
      "control_C1902",
      "control_C1900",
      "control_R1900",
      "control_U1901",
      "control_C1913",
      "control_C1912",
      "control_R1907",
      "control_C1911",
      "control_C1910",
      "control_R1901",
      "control_C1905",
      "control_R1906",
      "control_R1903",
      "control_C1908",
      "control_C1914",
      "control_R1904",
      "control_C1907",
      "control_R1908",
      "control_R1902",
      "control_C1909",
      "control_R1905",
      "control_C1906",
      "control_U1902",
      "control_C1915",
      "control_C1916",
      "control_C1917",
      "control_C1918",
      "control_U1903"
    ],
    "sheetIds": [
      "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
    ],
    "units": [
      {
        "component": "control_C1900",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1901",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1902",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1904",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1900",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1900",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1905",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1906",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1907",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1908",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1909",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1910",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1911",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1912",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1913",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1914",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1901",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1902",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1904",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1905",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1906",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1907",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_R1908",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1901",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1915",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1916",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1917",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_C1918",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1902",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 3
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
  ],
  "suggestedScenario": "local-control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "explanationTitleRu": "Преобразование тока матрицы в напряжение",
  "sourceSheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "sourceSheetName": "1900_ADC_TIA_AND_MONITOR_SELECTOR",
  "sourceFile": "1900_ADC_TIA_AND_MONITOR_SELECTOR.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-readout",
  "layout": {
    "version": 2,
    "kind": "measurement-path",
    "label": "Ток преобразуется в напряжение, затем выбирается сигнал",
    "geometryOnly": true
  },
  "regions": []
};
