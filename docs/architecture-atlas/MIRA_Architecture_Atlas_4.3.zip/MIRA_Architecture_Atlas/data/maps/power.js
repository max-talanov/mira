/* Editable functional scene: power */
window.MIRA_FUNCTIONAL.scenes["power"]={
  "id": "power",
  "title": "POWER_SYSTEM",
  "subtitle": "Плата Power · питание и аппаратная защита",
  "description": "Проследите путь питания и независимый путь контроля на одной диаграмме. Выберите блок, чтобы рассмотреть его работу.",
  "nodes": [
    {
      "id": "input",
      "title": "POWER_INPUT",
      "subtitle": "Защита входа 24 В",
      "description": "Приём внешнего питания, отключение при аварии и фильтрация шины.",
      "refs": [
        "power_J101",
        "power_U301",
        "power_JP301"
      ],
      "role": "power",
      "x": 40,
      "y": 185,
      "w": 300,
      "h": 150,
      "sceneId": "power-input",
      "sourceSheetIds": [
        "power_100_INPUT_CONNECTOR",
        "power_300_INPUT_EFUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_J101",
          "power_U301",
          "power_JP301"
        ],
        "sheetIds": [
          "power_100_INPUT_CONNECTOR",
          "power_300_INPUT_EFUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_J101",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          },
          {
            "component": "power_JP301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_U301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Защита входа 24 В",
      "sourceSheetName": "POWER_INPUT",
      "sourceSheetId": "power_POWER_INPUT",
      "sourceFile": "POWER_INPUT.kicad_sch",
      "layoutRole": "gateway"
    },
    {
      "id": "primary",
      "title": "PRIMARY_POWER",
      "subtitle": "Основные ветви питания",
      "description": "Формирование дежурного питания, питания контроллера и промежуточных напряжений ПЛИС и аналоговых узлов.",
      "refs": [
        "power_U501",
        "power_U601",
        "power_U701",
        "power_U801",
        "power_U901",
        "power_U1001",
        "power_U1101",
        "power_U1102"
      ],
      "role": "power",
      "x": 530,
      "y": 160,
      "w": 410,
      "h": 210,
      "sceneId": "power-primary",
      "sourceSheetIds": [
        "power_500_AON_3V3_BUCK",
        "power_600_USB_5V",
        "power_700_SYS_3V3",
        "power_800_FPGA_INTERMEDIATE_5V5",
        "power_900_ANALOG_PREREGULATOR_6V",
        "power_1000_AFE_POSITIVE_15V",
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U501",
          "power_U601",
          "power_U701",
          "power_U801",
          "power_U901",
          "power_U1001",
          "power_U1101",
          "power_U1102"
        ],
        "sheetIds": [
          "power_500_AON_3V3_BUCK",
          "power_600_USB_5V",
          "power_700_SYS_3V3",
          "power_800_FPGA_INTERMEDIATE_5V5",
          "power_900_ANALOG_PREREGULATOR_6V",
          "power_1000_AFE_POSITIVE_15V",
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": [
          {
            "component": "power_U1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U1102",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_U601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          },
          {
            "component": "power_U701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_U801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_U901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Основные ветви питания",
      "sourceSheetName": "PRIMARY_POWER",
      "sourceSheetId": "power_PRIMARY_POWER",
      "sourceFile": "PRIMARY_POWER.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "secondary",
      "title": "SECONDARY_POWER",
      "subtitle": "Питание отдельных доменов",
      "description": "Формирование питания ПЛИС, памяти, PHY и малошумящих аналоговых шин из основных ветвей.",
      "refs": [
        "power_U1201",
        "power_U1301",
        "power_U1401",
        "power_U1501",
        "power_U1601",
        "power_U1701",
        "power_U1801",
        "power_U1901",
        "power_U2001"
      ],
      "role": "power",
      "x": 1110,
      "y": 160,
      "w": 410,
      "h": 210,
      "sceneId": "power-secondary",
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR",
        "power_1300_FPGA_AUX_1V8",
        "power_1400_FPGA_AUX_2V5",
        "power_1500_FPGA_IO_3V3",
        "power_1600_DDR_1V35",
        "power_1700_PHY_1V05",
        "power_1800_DDR_VTT_REFERENCE",
        "power_1900_ANALOG_5V",
        "power_2000_ANALOG_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1201",
          "power_U1301",
          "power_U1401",
          "power_U1501",
          "power_U1601",
          "power_U1701",
          "power_U1801",
          "power_U1901",
          "power_U2001"
        ],
        "sheetIds": [
          "power_1200_POWER_MONITOR",
          "power_1300_FPGA_AUX_1V8",
          "power_1400_FPGA_AUX_2V5",
          "power_1500_FPGA_IO_3V3",
          "power_1600_DDR_1V35",
          "power_1700_PHY_1V05",
          "power_1800_DDR_VTT_REFERENCE",
          "power_1900_ANALOG_5V",
          "power_2000_ANALOG_3V3"
        ],
        "units": [
          {
            "component": "power_U1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_U1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_U1401",
            "sheet": "power_1400_FPGA_AUX_2V5",
            "unit": 1
          },
          {
            "component": "power_U1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_U1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_U1701",
            "sheet": "power_1700_PHY_1V05",
            "unit": 1
          },
          {
            "component": "power_U1801",
            "sheet": "power_1800_DDR_VTT_REFERENCE",
            "unit": 1
          },
          {
            "component": "power_U1901",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_U2001",
            "sheet": "power_2000_ANALOG_3V3",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание отдельных доменов",
      "sourceSheetName": "SECONDARY_POWER",
      "sourceSheetId": "power_SECONDARY_POWER",
      "sourceFile": "SECONDARY_POWER.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "supervisor",
      "title": "POWER_CONTROL",
      "subtitle": "Безопасный запуск",
      "description": "Отдельный контроллер и аппаратная логика проверяют разрешения на включение напряжений.",
      "refs": [
        "power_U2401",
        "power_U2502",
        "power_U2501",
        "power_J2502",
        "power_J2501",
        "power_J2602",
        "power_U2601",
        "power_J2601",
        "power_J2603",
        "power_U2603"
      ],
      "role": "control",
      "x": 530,
      "y": 565,
      "w": 410,
      "h": 210,
      "sceneId": "power-supervisor",
      "sourceSheetIds": [
        "power_2400_PM_CONTROLLER",
        "power_2500_PM_WATCHDOGS",
        "power_2600_PM_PERMIT_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2401",
          "power_U2502",
          "power_U2501",
          "power_J2502",
          "power_J2501",
          "power_J2602",
          "power_U2601",
          "power_J2601",
          "power_J2603",
          "power_U2603"
        ],
        "sheetIds": [
          "power_2400_PM_CONTROLLER",
          "power_2500_PM_WATCHDOGS",
          "power_2600_PM_PERMIT_INTERLOCKS"
        ],
        "units": [
          {
            "component": "power_J2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_J2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_J2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_J2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_J2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2401",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          },
          {
            "component": "power_U2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_U2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_U2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Безопасный запуск",
      "sourceSheetName": "POWER_CONTROL",
      "sourceSheetId": "power_POWER_CONTROL",
      "sourceFile": "POWER_CONTROL.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "monitor",
      "title": "POWER_MONITOR",
      "subtitle": "Контроль напряжения и тока",
      "description": "Измерение каждой шины и передача выбранной пары напряжение/ток контроллеру питания.",
      "refs": [
        "power_U3401",
        "power_U3503",
        "power_U3504",
        "power_U3501",
        "power_U3502",
        "power_U3603",
        "power_U3602",
        "power_U3601",
        "power_U3701",
        "power_U3704"
      ],
      "role": "analog",
      "x": 40,
      "y": 590,
      "w": 320,
      "h": 170,
      "sceneId": "power-monitoring",
      "sourceSheetIds": [
        "power_3400_NEGATIVE_RAIL_MONITOR",
        "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "power_3600_MONITOR_FPGA_ANA_AFE",
        "power_3700_MONITOR_FPGA_CORE_AUX_IO"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3401",
          "power_U3503",
          "power_U3504",
          "power_U3501",
          "power_U3502",
          "power_U3603",
          "power_U3602",
          "power_U3601",
          "power_U3701",
          "power_U3704"
        ],
        "sheetIds": [
          "power_3400_NEGATIVE_RAIL_MONITOR",
          "power_3500_MONITOR_INPUT_AON_USB_SYS",
          "power_3600_MONITOR_FPGA_ANA_AFE",
          "power_3700_MONITOR_FPGA_CORE_AUX_IO"
        ],
        "units": [
          {
            "component": "power_U3401",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_U3501",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3502",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3503",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3504",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3601",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3602",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3603",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3701",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3704",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Контроль напряжения и тока",
      "sourceSheetName": "POWER_MONITOR",
      "sourceSheetId": "power_POWER_MONITOR",
      "sourceFile": "POWER_MONITOR.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "program",
      "title": "PROGRAM_SWITCHES",
      "subtitle": "Включение питания записи",
      "description": "Коммутация положительной и отрицательной шин источника экспериментальных воздействий.",
      "refs": [
        "power_U2101",
        "power_U2203",
        "power_U2201",
        "power_U2202",
        "power_J2301"
      ],
      "role": "power",
      "x": 1125,
      "y": 565,
      "w": 310,
      "h": 150,
      "sceneId": "power-program",
      "sourceSheetIds": [
        "power_2100_PROGRAM_POSITIVE",
        "power_2200_PROGRAM_NEGATIVE",
        "power_2300_PROGRAM_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2101",
          "power_U2203",
          "power_U2201",
          "power_U2202",
          "power_J2301"
        ],
        "sheetIds": [
          "power_2100_PROGRAM_POSITIVE",
          "power_2200_PROGRAM_NEGATIVE",
          "power_2300_PROGRAM_INTERFACE"
        ],
        "units": [
          {
            "component": "power_J2301",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_U2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_U2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Включение питания записи",
      "sourceSheetName": "PROGRAM_SWITCHES",
      "sourceSheetId": "power_PROGRAM_SWITCHES",
      "sourceFile": "PROGRAM_SWITCHES.kicad_sch",
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "input_primary",
      "from": "input",
      "to": "primary",
      "label": "Защищённая шина 24 В",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Защищённые 24 В",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "primary_secondary",
      "from": "primary",
      "to": "secondary",
      "label": "Промежуточные ветви питания",
      "type": "power",
      "nets": [
        "power_net_bbc855740138",
        "power_net_cd1e0a0c9a0e",
        "power_net_f5932d689562"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Промежуточные шины",
      "netLabels": [
        "ANA6",
        "FPGA5V5",
        "ANA5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA5 · ANA6",
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "primary_supervisor",
      "from": "primary",
      "to": "supervisor",
      "label": "Дежурное питание контроля",
      "type": "power",
      "nets": [
        "power_net_67006db669b3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Дежурное питание",
      "netLabels": [
        "AON"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AON"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "supervisor_primary",
      "from": "supervisor",
      "to": "primary",
      "label": "Разрешённые команды основных шин",
      "type": "control",
      "nets": [
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_USB",
        "CMD_SYS",
        "CMD_FPGA",
        "CMD_P15",
        "CMD_N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_FPGA · CMD_N15",
        "CMD_P15 · CMD_SYS",
        "CMD_USB"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "supervisor_secondary",
      "from": "supervisor",
      "to": "secondary",
      "label": "Разрешённые команды нагрузок",
      "type": "control",
      "nets": [
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41",
        "power_net_05ab23d96f3d",
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_d07b46e16a3e",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_VTT",
        "CMD_ANA5",
        "CMD_ANA33",
        "CMD_PHY",
        "CMD_AUX25",
        "CMD_IO33",
        "CMD_DDR",
        "CMD_CORE",
        "CMD_AUX18"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_VTT · CMD_ANA5",
        "CMD_ANA33 · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P1",
        "title": "Включение"
      },
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "secondary_monitor",
      "from": "secondary",
      "to": "monitor",
      "label": "Контроль выходных шин",
      "type": "analog",
      "nets": [
        "power_net_0673bddb62dd",
        "power_net_710c162550a1",
        "power_net_68f62ae4eb87",
        "power_net_de6034a2bdb7",
        "power_net_217501fd4a1b",
        "power_net_d2e17a0e1422",
        "power_net_ca640db2f885",
        "power_net_df57fc034b72",
        "power_net_80ed0592af12",
        "power_net_e14830d3e0bb",
        "power_net_8165c7e0e80c",
        "power_net_006931c58e47",
        "power_net_072a5b0d730e",
        "power_net_92a8731620d4",
        "power_net_56f70873fed6",
        "power_net_493e78469ebd",
        "power_net_747203f7ea20",
        "power_net_0937e82a0391",
        "power_net_06b222f621c5",
        "power_net_bb20ea345245",
        "power_net_223314db53b0",
        "power_net_84769727a28d",
        "power_net_c5bc442d624e",
        "power_net_01417a8fa2e7",
        "power_net_a632dd3fa2a2",
        "power_net_071bab851593",
        "power_net_2f3224d5b90a",
        "power_net_5c97037182dc",
        "power_net_324fb6a46e24",
        "power_net_0b315650a930",
        "power_net_b8182397a510",
        "power_net_9ac6d4c8f874"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Измерения",
      "netLabels": [
        "MON_V_USB",
        "MON_V_ANA6",
        "MON_V_P15",
        "MON_V_N15",
        "MON_I_AON",
        "MON_V_SYS",
        "MON_I_USB",
        "MON_V_AON",
        "MON_V_INPUT",
        "MON_I_INPUT",
        "MON_I_SYS",
        "MON_I_CORE",
        "MON_V_CORE",
        "MON_V_AUX18",
        "MON_I_AUX25",
        "MON_V_AUX25",
        "MON_I_AUX18",
        "MON_I_IO33",
        "MON_V_IO33",
        "MON_I_PHY",
        "MON_I_ANA5",
        "MON_V_ANA5",
        "MON_V_PHY",
        "MON_V_ANA33",
        "MON_I_ANA33",
        "MON_V_DDR",
        "MON_I_DDR",
        "MON_I_ANA6",
        "MON_I_FPGA",
        "MON_I_P15",
        "MON_V_FPGA",
        "MON_I_N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MON_V_USB · MON_V_ANA6",
        "MON_V_P15 · ещё 29"
      ],
      "allConnectionsLabel": "Все соединения: 32",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "monitor_supervisor",
      "from": "monitor",
      "to": "supervisor",
      "label": "Выбранные напряжение и ток",
      "type": "analog",
      "nets": [
        "power_net_4aeb4892b398",
        "power_net_393e02135991",
        "power_net_f632ebdd7344"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Измеренные параметры",
      "netLabels": [
        "OC_OK_N",
        "ADC_I",
        "ADC_V"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ADC_I · ADC_V",
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "primary_program",
      "from": "primary",
      "to": "program",
      "label": "Положительная / отрицательная шины",
      "type": "power",
      "nets": [
        "power_net_a18264aeba79",
        "power_net_c215e379dc64"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "±15 В",
      "netLabels": [
        "P15",
        "N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "P15",
        "N15"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "supervisor_program",
      "from": "supervisor",
      "to": "program",
      "label": "Разрешение программирования",
      "type": "fault",
      "nets": [
        "power_net_89bfaea42e83",
        "power_net_65bf7e1e53cf",
        "power_net_5a1f578d112a",
        "power_net_8828c890966d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Разрешение",
      "netLabels": [
        "MATRIX_PERMIT_HOST",
        "GLOBAL_PWR_PERMIT_HOST",
        "MATRIX_PERMIT",
        "GLOBAL_PWR_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "GLOBAL_PWR_PERMIT",
        "GLOBAL_PWR_PERMIT_HOST",
        "MATRIX_PERMIT",
        "MATRIX_PERMIT_HOST"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P2",
        "title": "Разрешение"
      },
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 125,
    "w": 1560,
    "h": 690
  },
  "board": "power",
  "kind": "board",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J101",
      "power_U301",
      "power_JP301",
      "power_U501",
      "power_U601",
      "power_U701",
      "power_U801",
      "power_U901",
      "power_U1001",
      "power_U1101",
      "power_U1102",
      "power_U1201",
      "power_U1301",
      "power_U1401",
      "power_U1501",
      "power_U1601",
      "power_U1701",
      "power_U1801",
      "power_U1901",
      "power_U2001",
      "power_U2401",
      "power_U2502",
      "power_U2501",
      "power_J2502",
      "power_J2501",
      "power_J2602",
      "power_U2601",
      "power_J2601",
      "power_J2603",
      "power_U2603",
      "power_U3401",
      "power_U3503",
      "power_U3504",
      "power_U3501",
      "power_U3502",
      "power_U3603",
      "power_U3602",
      "power_U3601",
      "power_U3701",
      "power_U3704",
      "power_U2101",
      "power_U2203",
      "power_U2201",
      "power_U2202",
      "power_J2301"
    ],
    "sheetIds": [
      "power_100_INPUT_CONNECTOR",
      "power_300_INPUT_EFUSE_PROTECTION",
      "power_500_AON_3V3_BUCK",
      "power_600_USB_5V",
      "power_700_SYS_3V3",
      "power_800_FPGA_INTERMEDIATE_5V5",
      "power_900_ANALOG_PREREGULATOR_6V",
      "power_1000_AFE_POSITIVE_15V",
      "power_1100_AFE_NEGATIVE_15V",
      "power_1200_POWER_MONITOR",
      "power_1300_FPGA_AUX_1V8",
      "power_1400_FPGA_AUX_2V5",
      "power_1500_FPGA_IO_3V3",
      "power_1600_DDR_1V35",
      "power_1700_PHY_1V05",
      "power_1800_DDR_VTT_REFERENCE",
      "power_1900_ANALOG_5V",
      "power_2000_ANALOG_3V3",
      "power_2400_PM_CONTROLLER",
      "power_2500_PM_WATCHDOGS",
      "power_2600_PM_PERMIT_INTERLOCKS",
      "power_3400_NEGATIVE_RAIL_MONITOR",
      "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "power_3600_MONITOR_FPGA_ANA_AFE",
      "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "power_2100_PROGRAM_POSITIVE",
      "power_2200_PROGRAM_NEGATIVE",
      "power_2300_PROGRAM_INTERFACE"
    ],
    "units": [
      {
        "component": "power_J101",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      },
      {
        "component": "power_JP301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_U301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_U1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1102",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_U601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_U701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_U801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_U901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_U1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_U1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_U1401",
        "sheet": "power_1400_FPGA_AUX_2V5",
        "unit": 1
      },
      {
        "component": "power_U1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_U1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_U1701",
        "sheet": "power_1700_PHY_1V05",
        "unit": 1
      },
      {
        "component": "power_U1801",
        "sheet": "power_1800_DDR_VTT_REFERENCE",
        "unit": 1
      },
      {
        "component": "power_U1901",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_U2001",
        "sheet": "power_2000_ANALOG_3V3",
        "unit": 1
      },
      {
        "component": "power_J2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_J2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_J2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_J2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_J2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2401",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_U2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_U2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_U2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U3401",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_U3501",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3502",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3503",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3504",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3601",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3602",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3603",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3701",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3704",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_J2301",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_U2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_U2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power"
  ],
  "suggestedScenario": "local-power",
  "explanationTitleRu": "Плата Power · питание и аппаратная защита",
  "sourceSheetId": "power_POWER_SYSTEM",
  "sourceSheetName": "POWER_SYSTEM",
  "sourceFile": "POWER_SYSTEM.kicad_sch",
  "nameSource": "root-filename",
  "hidden": false,
  "parentScene": "system",
  "layout": {
    "version": 2,
    "kind": "power-tree",
    "label": "Путь энергии сверху, контроль и разрешения снизу",
    "geometryOnly": true
  },
  "regions": []
};
