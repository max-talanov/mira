/* Editable functional scene: power-monitoring */
window.MIRA_FUNCTIONAL.scenes["power-monitoring"]={
  "id": "power-monitoring",
  "title": "POWER_MONITOR",
  "subtitle": "Контроль всех ветвей питания",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet3400",
      "title": "3400_NEGATIVE_RAIL_MONITOR",
      "subtitle": "Измерение отрицательной шины",
      "description": "U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току.",
      "refs": [
        "power_U3401"
      ],
      "role": "data",
      "x": 40,
      "y": 40,
      "w": 320,
      "h": 166,
      "sceneId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "sheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "sourceSheetIds": [
        "power_3400_NEGATIVE_RAIL_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3401"
        ],
        "sheetIds": [
          "power_3400_NEGATIVE_RAIL_MONITOR"
        ],
        "units": [
          {
            "component": "power_U3401",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Измерение отрицательной шины",
      "sourceSheetName": "3400_NEGATIVE_RAIL_MONITOR",
      "sourceSheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "sourceFile": "3400_NEGATIVE_RAIL_MONITOR.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet3500",
      "title": "3500_MONITOR_INPUT_AON_USB_SYS",
      "subtitle": "Контроль входа и системного питания",
      "description": "U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину.",
      "refs": [
        "power_U3503",
        "power_U3504",
        "power_U3501",
        "power_U3502"
      ],
      "role": "data",
      "x": 40,
      "y": 380,
      "w": 320,
      "h": 166,
      "sceneId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceSheetIds": [
        "power_3500_MONITOR_INPUT_AON_USB_SYS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3503",
          "power_U3504",
          "power_U3501",
          "power_U3502"
        ],
        "sheetIds": [
          "power_3500_MONITOR_INPUT_AON_USB_SYS"
        ],
        "units": [
          {
            "component": "power_U3501",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3502",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3503",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          },
          {
            "component": "power_U3504",
            "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Контроль входа и системного питания",
      "sourceSheetName": "3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceSheetId": "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "sourceFile": "3500_MONITOR_INPUT_AON_USB_SYS.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet3600",
      "title": "3600_MONITOR_FPGA_ANA_AFE",
      "subtitle": "Контроль ПЛИС и аналогового питания",
      "description": "U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE.",
      "refs": [
        "power_U3603",
        "power_U3602",
        "power_U3601"
      ],
      "role": "data",
      "x": 40,
      "y": 720,
      "w": 320,
      "h": 166,
      "sceneId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "sheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "sourceSheetIds": [
        "power_3600_MONITOR_FPGA_ANA_AFE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3603",
          "power_U3602",
          "power_U3601"
        ],
        "sheetIds": [
          "power_3600_MONITOR_FPGA_ANA_AFE"
        ],
        "units": [
          {
            "component": "power_U3601",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3602",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          },
          {
            "component": "power_U3603",
            "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Контроль ПЛИС и аналогового питания",
      "sourceSheetName": "3600_MONITOR_FPGA_ANA_AFE",
      "sourceSheetId": "power_3600_MONITOR_FPGA_ANA_AFE",
      "sourceFile": "3600_MONITOR_FPGA_ANA_AFE.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet3700",
      "title": "3700_MONITOR_FPGA_CORE_AUX_IO",
      "subtitle": "Контроль питания ядра и выводов ПЛИС",
      "description": "U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС.",
      "refs": [
        "power_U3701",
        "power_U3704",
        "power_U3702",
        "power_U3703"
      ],
      "role": "data",
      "x": 490,
      "y": 40,
      "w": 320,
      "h": 166,
      "sceneId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceSheetIds": [
        "power_3700_MONITOR_FPGA_CORE_AUX_IO"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3701",
          "power_U3704",
          "power_U3702",
          "power_U3703"
        ],
        "sheetIds": [
          "power_3700_MONITOR_FPGA_CORE_AUX_IO"
        ],
        "units": [
          {
            "component": "power_U3701",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3702",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3703",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          },
          {
            "component": "power_U3704",
            "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Контроль питания ядра и выводов ПЛИС",
      "sourceSheetName": "3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceSheetId": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "sourceFile": "3700_MONITOR_FPGA_CORE_AUX_IO.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet3800",
      "title": "3800_MONITOR_DDR_PHY_ANALOG",
      "subtitle": "Контроль памяти, PHY и аналоговых шин",
      "description": "U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины.",
      "refs": [
        "power_U3802",
        "power_U3804",
        "power_U3801",
        "power_U3803"
      ],
      "role": "data",
      "x": 490,
      "y": 720,
      "w": 320,
      "h": 166,
      "sceneId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sourceSheetIds": [
        "power_3800_MONITOR_DDR_PHY_ANALOG"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3802",
          "power_U3804",
          "power_U3801",
          "power_U3803"
        ],
        "sheetIds": [
          "power_3800_MONITOR_DDR_PHY_ANALOG"
        ],
        "units": [
          {
            "component": "power_U3801",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3802",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3803",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          },
          {
            "component": "power_U3804",
            "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Контроль памяти, PHY и аналоговых шин",
      "sourceSheetName": "3800_MONITOR_DDR_PHY_ANALOG",
      "sourceSheetId": "power_3800_MONITOR_DDR_PHY_ANALOG",
      "sourceFile": "3800_MONITOR_DDR_PHY_ANALOG.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet3900",
      "title": "3900_TELEMETRY_MULTIPLEXERS",
      "subtitle": "Выбор измеряемой шины",
      "description": "U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания.",
      "refs": [
        "power_U3902",
        "power_U3901"
      ],
      "role": "data",
      "x": 940,
      "y": 365,
      "w": 410,
      "h": 210,
      "sceneId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "sheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "sourceSheetIds": [
        "power_3900_TELEMETRY_MULTIPLEXERS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3902",
          "power_U3901"
        ],
        "sheetIds": [
          "power_3900_TELEMETRY_MULTIPLEXERS"
        ],
        "units": [
          {
            "component": "power_U3901",
            "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
            "unit": 1
          },
          {
            "component": "power_U3902",
            "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Выбор измеряемой шины",
      "sourceSheetName": "3900_TELEMETRY_MULTIPLEXERS",
      "sourceSheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "sourceFile": "3900_TELEMETRY_MULTIPLEXERS.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet4000",
      "title": "4000_TELEMETRY_ADC_BUFFERS",
      "subtitle": "Буферы измерений для контроллера",
      "description": "U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания.",
      "refs": [
        "power_U4001"
      ],
      "role": "data",
      "x": 1490,
      "y": 380,
      "w": 320,
      "h": 166,
      "sceneId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "sheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "sourceSheetIds": [
        "power_4000_TELEMETRY_ADC_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U4001"
        ],
        "sheetIds": [
          "power_4000_TELEMETRY_ADC_BUFFERS"
        ],
        "units": [
          {
            "component": "power_U4001",
            "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Буферы измерений для контроллера",
      "sourceSheetName": "4000_TELEMETRY_ADC_BUFFERS",
      "sourceSheetId": "power_4000_TELEMETRY_ADC_BUFFERS",
      "sourceFile": "4000_TELEMETRY_ADC_BUFFERS.kicad_sch",
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "sheet3500_sheet3900",
      "from": "sheet3500",
      "to": "sheet3900",
      "label": "Измерения тока",
      "type": "analog",
      "nets": [
        "power_net_d2e17a0e1422",
        "power_net_df57fc034b72",
        "power_net_ca640db2f885",
        "power_net_e14830d3e0bb",
        "power_net_0673bddb62dd",
        "power_net_80ed0592af12",
        "power_net_217501fd4a1b",
        "power_net_8165c7e0e80c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Ток",
      "netLabels": [
        "MON_V_SYS",
        "MON_V_AON",
        "MON_I_USB",
        "MON_I_INPUT",
        "MON_V_USB",
        "MON_V_INPUT",
        "MON_I_AON",
        "MON_I_SYS"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MON_I_AON · MON_I_INPUT",
        "MON_I_SYS · MON_I_USB",
        "MON_V_AON · MON_V_INPUT",
        "MON_V_SYS · MON_V_USB"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3700_sheet3900",
      "from": "sheet3700",
      "to": "sheet3900",
      "label": "Измерения тока",
      "type": "analog",
      "nets": [
        "power_net_06b222f621c5",
        "power_net_56f70873fed6",
        "power_net_0937e82a0391",
        "power_net_747203f7ea20",
        "power_net_006931c58e47",
        "power_net_92a8731620d4",
        "power_net_072a5b0d730e",
        "power_net_493e78469ebd"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Ток",
      "netLabels": [
        "MON_V_IO33",
        "MON_I_AUX25",
        "MON_I_IO33",
        "MON_I_AUX18",
        "MON_I_CORE",
        "MON_V_AUX18",
        "MON_V_CORE",
        "MON_V_AUX25"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MON_I_AUX18 · MON_I_AUX25",
        "MON_I_CORE · MON_I_IO33",
        "MON_V_AUX18 · MON_V_AUX25",
        "MON_V_CORE · MON_V_IO33"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3800_sheet3900",
      "from": "sheet3800",
      "to": "sheet3900",
      "label": "Измерения тока",
      "type": "analog",
      "nets": [
        "power_net_01417a8fa2e7",
        "power_net_bb20ea345245",
        "power_net_071bab851593",
        "power_net_a632dd3fa2a2",
        "power_net_84769727a28d",
        "power_net_c5bc442d624e",
        "power_net_2f3224d5b90a",
        "power_net_223314db53b0"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Ток",
      "netLabels": [
        "MON_V_ANA33",
        "MON_I_PHY",
        "MON_V_DDR",
        "MON_I_ANA33",
        "MON_V_ANA5",
        "MON_V_PHY",
        "MON_I_DDR",
        "MON_I_ANA5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MON_I_ANA33 · MON_I_ANA5",
        "MON_I_DDR · MON_I_PHY",
        "MON_V_ANA33 · MON_V_ANA5",
        "MON_V_DDR · MON_V_PHY"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3900_sheet4000",
      "from": "sheet3900",
      "to": "sheet4000",
      "label": "Выбранное измерение",
      "type": "control",
      "nets": [
        "power_net_97db96dcc04b",
        "power_net_b8fd52d3ecf7",
        "power_net_b5187ab6f19a",
        "power_net_2074a83eb788",
        "power_net_882de840965a",
        "power_net_e4e50653a8a5",
        "power_net_7071622db9df"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Выбранное измерение",
      "netLabels": [
        "MUX_A1",
        "MUX_A0",
        "MUX_DISABLE",
        "MUX_A2",
        "MUX_I_COM",
        "MUX_V_COM",
        "MUX_A3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MUX_A0 · MUX_A1",
        "MUX_A2 · MUX_A3",
        "MUX_DISABLE · MUX_I_COM",
        "MUX_V_COM"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3600_sheet3900",
      "from": "sheet3600",
      "to": "sheet3900",
      "label": "Измерения тока",
      "type": "analog",
      "nets": [
        "power_net_b8182397a510",
        "power_net_68f62ae4eb87",
        "power_net_710c162550a1",
        "power_net_5c97037182dc",
        "power_net_0b315650a930",
        "power_net_324fb6a46e24"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Ток",
      "netLabels": [
        "MON_V_FPGA",
        "MON_V_P15",
        "MON_V_ANA6",
        "MON_I_ANA6",
        "MON_I_P15",
        "MON_I_FPGA"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MON_I_ANA6 · MON_I_FPGA",
        "MON_I_P15 · MON_V_ANA6",
        "MON_V_FPGA · MON_V_P15"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3400_sheet3900",
      "from": "sheet3400",
      "to": "sheet3900",
      "label": "Измерения тока",
      "type": "analog",
      "nets": [
        "power_net_9ac6d4c8f874",
        "power_net_de6034a2bdb7"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Ток",
      "netLabels": [
        "MON_I_N15",
        "MON_V_N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MON_I_N15",
        "MON_V_N15"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3500_sheet3600",
      "from": "sheet3500",
      "to": "sheet3600",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "sheet3500_sheet3700",
      "from": "sheet3500",
      "to": "sheet3700",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3500_sheet3800",
      "from": "sheet3500",
      "to": "sheet3800",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3500_sheet4000",
      "from": "sheet3500",
      "to": "sheet4000",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P1",
        "title": "OC_OK_N"
      },
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet3600_sheet3700",
      "from": "sheet3600",
      "to": "sheet3700",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "sheet3600_sheet3800",
      "from": "sheet3600",
      "to": "sheet3800",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 5,
    "w": 1850,
    "h": 921
  },
  "board": "power",
  "sheetIds": [
    "power_3400_NEGATIVE_RAIL_MONITOR",
    "power_3500_MONITOR_INPUT_AON_USB_SYS",
    "power_3600_MONITOR_FPGA_ANA_AFE",
    "power_3700_MONITOR_FPGA_CORE_AUX_IO",
    "power_3800_MONITOR_DDR_PHY_ANALOG",
    "power_3900_TELEMETRY_MULTIPLEXERS",
    "power_4000_TELEMETRY_ADC_BUFFERS"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3401",
      "power_U3503",
      "power_U3504",
      "power_U3501",
      "power_U3502",
      "power_U3603",
      "power_U3602",
      "power_U3601",
      "power_U3701",
      "power_U3704",
      "power_U3702",
      "power_U3703",
      "power_U3802",
      "power_U3804",
      "power_U3801",
      "power_U3803",
      "power_U3902",
      "power_U3901",
      "power_U4001"
    ],
    "sheetIds": [
      "power_3400_NEGATIVE_RAIL_MONITOR",
      "power_3500_MONITOR_INPUT_AON_USB_SYS",
      "power_3600_MONITOR_FPGA_ANA_AFE",
      "power_3700_MONITOR_FPGA_CORE_AUX_IO",
      "power_3800_MONITOR_DDR_PHY_ANALOG",
      "power_3900_TELEMETRY_MULTIPLEXERS",
      "power_4000_TELEMETRY_ADC_BUFFERS"
    ],
    "units": [
      {
        "component": "power_U3401",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_U3501",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3502",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3503",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3504",
        "sheet": "power_3500_MONITOR_INPUT_AON_USB_SYS",
        "unit": 1
      },
      {
        "component": "power_U3601",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3602",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3603",
        "sheet": "power_3600_MONITOR_FPGA_ANA_AFE",
        "unit": 1
      },
      {
        "component": "power_U3701",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3702",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3703",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3704",
        "sheet": "power_3700_MONITOR_FPGA_CORE_AUX_IO",
        "unit": 1
      },
      {
        "component": "power_U3801",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3802",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3803",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3804",
        "sheet": "power_3800_MONITOR_DDR_PHY_ANALOG",
        "unit": 1
      },
      {
        "component": "power_U3901",
        "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
        "unit": 1
      },
      {
        "component": "power_U3902",
        "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
        "unit": 1
      },
      {
        "component": "power_U4001",
        "sheet": "power_4000_TELEMETRY_ADC_BUFFERS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power-monitoring"
  ],
  "suggestedScenario": "local-power-monitoring",
  "explanationTitleRu": "Контроль всех ветвей питания",
  "sourceSheetId": "power_POWER_MONITOR",
  "sourceSheetName": "POWER_MONITOR",
  "sourceFile": "POWER_MONITOR.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power",
  "layout": {
    "version": 2,
    "kind": "telemetry-fan-in",
    "label": "Параллельные измерения сходятся к мультиплексорам",
    "geometryOnly": true
  },
  "regions": []
};
