/* Editable functional scene: control-readout */
window.MIRA_FUNCTIONAL.scenes["control-readout"]={
  "id": "control-readout",
  "title": "ADC",
  "subtitle": "Преобразование тока матрицы в данные",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet1900",
      "title": "1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "subtitle": "Преобразование тока матрицы в напряжение",
      "description": "U1900 преобразует выбранный ток матрицы в напряжение. U1901 выбирает диапазон обратной связи, U1902 — контролируемую аналоговую точку.",
      "refs": [
        "control_U1901",
        "control_U1902",
        "control_U1900",
        "control_U1903"
      ],
      "role": "analog",
      "x": 40,
      "y": 180,
      "w": 410,
      "h": 210,
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1901",
          "control_U1902",
          "control_U1900",
          "control_U1903"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR"
        ],
        "units": [
          {
            "component": "control_U1900",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1901",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1902",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 3
          }
        ]
      },
      "explanationTitleRu": "Преобразование тока матрицы в напряжение",
      "sourceSheetName": "1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceSheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "sourceFile": "1900_ADC_TIA_AND_MONITOR_SELECTOR.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet2000",
      "title": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "subtitle": "Оцифровка сигнала матрицы",
      "description": "Контрольный аналоговый сигнал проходит через высокоомный буфер и дифференциальный драйвер в АЦП AD4003 U2004. Масштаб задаёт отдельный прецизионный источник опоры.",
      "refs": [
        "control_U2000",
        "control_U2001",
        "control_U2002",
        "control_U2003",
        "control_U2004",
        "control_U2005"
      ],
      "role": "analog",
      "x": 760,
      "y": 195,
      "w": 320,
      "h": 150,
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetIds": [
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2000",
          "control_U2001",
          "control_U2002",
          "control_U2003",
          "control_U2004",
          "control_U2005"
        ],
        "sheetIds": [
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_U2000",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2001",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2002",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2003",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2004",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2005",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Оцифровка сигнала матрицы",
      "sourceSheetName": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceSheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "sourceFile": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES.kicad_sch",
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "sheet1900_sheet2000",
      "from": "sheet1900",
      "to": "sheet2000",
      "label": "MAT_MONITOR_RAW",
      "type": "data",
      "nets": [
        "control_net_a2221a9e6733"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_MONITOR_RAW",
      "netLabels": [
        "MAT_MONITOR_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_MONITOR_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1120,
    "h": 285
  },
  "board": "control",
  "sheetIds": [
    "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
    "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1901",
      "control_U1902",
      "control_U1900",
      "control_U1903",
      "control_U2000",
      "control_U2001",
      "control_U2002",
      "control_U2003",
      "control_U2004",
      "control_U2005"
    ],
    "sheetIds": [
      "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
    ],
    "units": [
      {
        "component": "control_U1900",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1901",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1902",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U2000",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2001",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2002",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2003",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2004",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2005",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-readout"
  ],
  "suggestedScenario": "local-control-readout",
  "explanationTitleRu": "Преобразование тока матрицы в данные",
  "sourceSheetId": "control_ADC",
  "sourceSheetName": "ADC",
  "sourceFile": "ADC.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
