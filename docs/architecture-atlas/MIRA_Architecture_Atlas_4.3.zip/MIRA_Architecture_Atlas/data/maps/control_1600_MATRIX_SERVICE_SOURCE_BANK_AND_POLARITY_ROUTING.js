/* Editable functional scene: control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING */
window.MIRA_FUNCTIONAL.scenes["control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"]={
  "id": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "title": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "subtitle": "Выбор источника, банка и полярности",
  "description": "Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике.",
  "nodes": [
    {
      "id": "source",
      "title": "Выбор сервисного источника",
      "subtitle": "",
      "description": "Селектор выбирает сервисное напряжение для текущей операции.",
      "refs": [
        "control_U1601"
      ],
      "role": "analog",
      "x": 40,
      "y": 80,
      "w": 290,
      "h": 150,
      "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceSheetIds": [
        "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1601"
        ],
        "sheetIds": [
          "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
        ],
        "units": [
          {
            "component": "control_U1601",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "bank",
      "title": "Выбор группы битовых линий",
      "subtitle": "",
      "description": "Селектор группы выбирает, куда направить сервисное воздействие.",
      "refs": [
        "control_U1600"
      ],
      "role": "analog",
      "x": 600,
      "y": 80,
      "w": 350,
      "h": 184,
      "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceSheetIds": [
        "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1600"
        ],
        "sheetIds": [
          "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
        ],
        "units": [
          {
            "component": "control_U1600",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "polarity",
      "title": "Выбор полярности записи",
      "subtitle": "",
      "description": "Коммутирующие ключи выбирают требуемую полярность источника.",
      "refs": [
        "control_U1602",
        "control_R1600",
        "control_R1604"
      ],
      "role": "analog",
      "x": 1150,
      "y": 80,
      "w": 300,
      "h": 156,
      "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceSheetIds": [
        "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1602",
          "control_R1600",
          "control_R1604"
        ],
        "sheetIds": [
          "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
        ],
        "units": [
          {
            "component": "control_R1600",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_R1604",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 2
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 3
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 4
          },
          {
            "component": "control_U1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 5
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "return",
      "title": "Возврат READ и сброс регулятора",
      "subtitle": "",
      "description": "Ключи подключают обратный путь READ и сбрасывают состояние регулятора, пока источник выключен.",
      "refs": [
        "control_U1603",
        "control_C1600",
        "control_C1601",
        "control_C1602",
        "control_C1603",
        "control_C1604",
        "control_C1605",
        "control_C1606",
        "control_C1607",
        "control_R1601",
        "control_R1602",
        "control_R1603",
        "control_R1605"
      ],
      "role": "analog",
      "x": 600,
      "y": 540,
      "w": 260,
      "h": 140,
      "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "sourceSheetIds": [
        "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1603",
          "control_C1600",
          "control_C1601",
          "control_C1602",
          "control_C1603",
          "control_C1604",
          "control_C1605",
          "control_C1606",
          "control_C1607",
          "control_R1601",
          "control_R1602",
          "control_R1603",
          "control_R1605"
        ],
        "sheetIds": [
          "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
        ],
        "units": [
          {
            "component": "control_C1600",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1601",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1604",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1605",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1606",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_C1607",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_R1601",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_R1602",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_R1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_R1605",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 1
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 2
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 3
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 4
          },
          {
            "component": "control_U1603",
            "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
            "unit": 5
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "source_bank",
      "from": "source",
      "to": "bank",
      "label": "MAT_SERVICE_SAFE",
      "type": "data",
      "nets": [
        "control_net_209d9624cc4d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_SERVICE_SAFE",
      "netLabels": [
        "MAT_SERVICE_SAFE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "bank_polarity",
      "from": "bank",
      "to": "polarity",
      "label": "MAT_BL_SERVICE",
      "type": "analog",
      "nets": [
        "control_net_2c4dffd5842a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_BL_SERVICE",
      "netLabels": [
        "MAT_BL_SERVICE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_SERVICE"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "polarity_return",
      "from": "polarity",
      "to": "return",
      "label": "MAT_RETURN",
      "type": "data",
      "nets": [
        "control_net_45e2821ea470"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_RETURN",
      "netLabels": [
        "MAT_RETURN"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_RETURN"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 45,
    "w": 1490,
    "h": 675
  },
  "board": "control",
  "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 18,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1601",
      "control_U1600",
      "control_U1602",
      "control_R1600",
      "control_R1604",
      "control_U1603",
      "control_C1600",
      "control_C1601",
      "control_C1602",
      "control_C1603",
      "control_C1604",
      "control_C1605",
      "control_C1606",
      "control_C1607",
      "control_R1601",
      "control_R1602",
      "control_R1603",
      "control_R1605"
    ],
    "sheetIds": [
      "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
    ],
    "units": [
      {
        "component": "control_U1601",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1600",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_R1600",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_R1604",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 2
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 3
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 4
      },
      {
        "component": "control_U1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 5
      },
      {
        "component": "control_C1600",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1601",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1604",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1605",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1606",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_C1607",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_R1601",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_R1602",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_R1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_R1605",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 1
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 2
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 3
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 4
      },
      {
        "component": "control_U1603",
        "sheet": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "unit": 5
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING"
  ],
  "suggestedScenario": "local-control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "explanationTitleRu": "Выбор источника, банка и полярности",
  "sourceSheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "sourceSheetName": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
  "sourceFile": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-routing",
  "layout": {
    "version": 2,
    "kind": "source-selection",
    "label": "Выбор источника и пути, возврат отдельной ветвью",
    "geometryOnly": true
  },
  "regions": []
};
