/* Editable functional scene: power_1000_AFE_POSITIVE_15V */
window.MIRA_FUNCTIONAL.scenes["power_1000_AFE_POSITIVE_15V"]={
  "id": "power_1000_AFE_POSITIVE_15V",
  "title": "1000_AFE_POSITIVE_15V",
  "subtitle": "Положительное аналоговое питание",
  "description": "U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1000_AFE_POSITIVE_15V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1000_AFE_POSITIVE_15V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Положительная аналоговая шина: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1001",
        "power_L1001",
        "power_R1003",
        "power_R1002"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1000_AFE_POSITIVE_15V",
      "sourceSheetIds": [
        "power_1000_AFE_POSITIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1001",
          "power_L1001",
          "power_R1003",
          "power_R1002"
        ],
        "sheetIds": [
          "power_1000_AFE_POSITIVE_15V"
        ],
        "units": [
          {
            "component": "power_L1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1002",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1003",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1001",
        "power_R1001"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1000_AFE_POSITIVE_15V",
      "sourceSheetIds": [
        "power_1000_AFE_POSITIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1001",
          "power_R1001"
        ],
        "sheetIds": [
          "power_1000_AFE_POSITIVE_15V"
        ],
        "units": [
          {
            "component": "power_Q1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1002",
        "power_C1004",
        "power_C1005",
        "power_C1003",
        "power_C1006",
        "power_C1001",
        "power_R1006",
        "power_D1001",
        "power_R1004",
        "power_R1005"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1000_AFE_POSITIVE_15V",
      "sourceSheetIds": [
        "power_1000_AFE_POSITIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1002",
          "power_C1004",
          "power_C1005",
          "power_C1003",
          "power_C1006",
          "power_C1001",
          "power_R1006",
          "power_D1001",
          "power_R1004",
          "power_R1005"
        ],
        "sheetIds": [
          "power_1000_AFE_POSITIVE_15V"
        ],
        "units": [
          {
            "component": "power_C1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1002",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1003",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1004",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1005",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_C1006",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_D1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1004",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1005",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          },
          {
            "component": "power_R1006",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход P15",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1000_AFE_POSITIVE_15V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1000_AFE_POSITIVE_15V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_35be90fefcdd",
        "power_net_a18264aeba79",
        "power_net_6cbfb60c2369",
        "power_net_967875cada1d",
        "power_net_1924d0e843c7",
        "power_net_6217d5a17f1f",
        "power_net_d150669ccf6b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "CMD_P15",
        "P15",
        "CB_P15",
        "FB_P15",
        "EN_P15",
        "P15_SW",
        "P15_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CB_P15 · CMD_P15",
        "EN_P15 · FB_P15",
        "P15 · P15_RAW",
        "P15_SW"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "P15",
      "type": "power",
      "nets": [
        "power_net_a18264aeba79"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "P15",
      "netLabels": [
        "P15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "P15"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_35be90fefcdd",
        "power_net_1924d0e843c7"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_P15",
        "EN_P15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_P15",
        "EN_P15"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1000_AFE_POSITIVE_15V",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 16,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1001",
      "power_L1001",
      "power_R1003",
      "power_R1002",
      "power_Q1001",
      "power_R1001",
      "power_C1002",
      "power_C1004",
      "power_C1005",
      "power_C1003",
      "power_C1006",
      "power_C1001",
      "power_R1006",
      "power_D1001",
      "power_R1004",
      "power_R1005"
    ],
    "sheetIds": [
      "power_1000_AFE_POSITIVE_15V"
    ],
    "units": [
      {
        "component": "power_L1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1002",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1003",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_Q1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1002",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1003",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1004",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1005",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_C1006",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_D1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1004",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1005",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_R1006",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1000_AFE_POSITIVE_15V"
  ],
  "suggestedScenario": "local-power_1000_AFE_POSITIVE_15V",
  "explanationTitleRu": "Положительное аналоговое питание",
  "sourceSheetId": "power_1000_AFE_POSITIVE_15V",
  "sourceSheetName": "1000_AFE_POSITIVE_15V",
  "sourceFile": "1000_AFE_POSITIVE_15V.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
