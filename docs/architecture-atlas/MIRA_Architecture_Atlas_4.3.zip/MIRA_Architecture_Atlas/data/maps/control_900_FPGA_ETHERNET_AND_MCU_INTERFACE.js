/* Editable functional scene: control_900_FPGA_ETHERNET_AND_MCU_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"]={
  "id": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "title": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "subtitle": "Ethernet · от сигнала в кабеле до ПЛИС",
  "description": "Проследите приём Ethernet на одной диаграмме: сетевой разъём, трансформаторная развязка, приём PHY и обработка в ПЛИС. Выберите соединение, чтобы увидеть реальные цепи и выводы.",
  "nodes": [
    {
      "id": "connector",
      "title": "Сетевой разъём",
      "subtitle": "",
      "description": "По кабелю электрический сигнал Ethernet поступает в разъём RJ45.",
      "refs": [
        "control_J900",
        "control_R921",
        "control_C938",
        "control_C937"
      ],
      "role": "data",
      "x": 40,
      "y": 230,
      "w": 250,
      "h": 138,
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_J900",
          "control_R921",
          "control_C938",
          "control_C937"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C937",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C938",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_J900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R921",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "isolation",
      "title": "Гальваническая развязка",
      "subtitle": "",
      "description": "Четыре трансформаторные пары передают сигнал, электрически разделяя кабель и плату.",
      "refs": [
        "control_T900",
        "control_C933",
        "control_R917",
        "control_R920",
        "control_C936",
        "control_R919",
        "control_R918",
        "control_C935",
        "control_C934"
      ],
      "role": "analog",
      "x": 450,
      "y": 230,
      "w": 250,
      "h": 148,
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_T900",
          "control_C933",
          "control_R917",
          "control_R920",
          "control_C936",
          "control_R919",
          "control_R918",
          "control_C935",
          "control_C934"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C933",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C934",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C935",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C936",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R917",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R918",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R919",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R920",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_T900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "phy",
      "title": "Приём сигнала Ethernet",
      "subtitle": "",
      "description": "PHY преобразует кабельный сигнал в синхронный цифровой интерфейс RGMII.",
      "refs": [
        "control_U902",
        "control_R914",
        "control_R910",
        "control_R912",
        "control_R916",
        "control_R907",
        "control_C932",
        "control_R906",
        "control_R908",
        "control_R911",
        "control_R915",
        "control_R909"
      ],
      "role": "data",
      "x": 870,
      "y": 215,
      "w": 350,
      "h": 184,
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U902",
          "control_R914",
          "control_R910",
          "control_R912",
          "control_R916",
          "control_R907",
          "control_C932",
          "control_R906",
          "control_R908",
          "control_R911",
          "control_R915",
          "control_R909"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C932",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R906",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R907",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R908",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R909",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R910",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R911",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R912",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R914",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R915",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R916",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "fpga",
      "title": "Обработка сетевых кадров",
      "subtitle": "",
      "description": "ПЛИС принимает цифровые данные. MAC и протоколы верхних уровней реализуются в программируемой логике или прошивке.",
      "refs": [
        "control_U500",
        "control_C904",
        "control_C902",
        "control_C900",
        "control_C905",
        "control_R913",
        "control_C901",
        "control_C903"
      ],
      "role": "data",
      "x": 1450,
      "y": 215,
      "w": 350,
      "h": 184,
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_C904",
          "control_C902",
          "control_C900",
          "control_C905",
          "control_R913",
          "control_C901",
          "control_C903"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C901",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C903",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C904",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C905",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R913",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "management",
      "title": "Связь MCU и ПЛИС",
      "subtitle": "",
      "description": "Отдельные буферы передают команды контроллера, ответы и состояние конфигурации между доменами питания.",
      "refs": [
        "control_U900",
        "control_U901",
        "control_C907",
        "control_R902",
        "control_R904",
        "control_C906",
        "control_R900",
        "control_R901",
        "control_R905",
        "control_R903"
      ],
      "role": "control",
      "x": 1460,
      "y": 570,
      "w": 260,
      "h": 140,
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U900",
          "control_U901",
          "control_C907",
          "control_R902",
          "control_R904",
          "control_C906",
          "control_R900",
          "control_R901",
          "control_R905",
          "control_R903"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C906",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C907",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R901",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R903",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R904",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R905",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U901",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "support",
      "title": "Обеспечение связи",
      "subtitle": "",
      "description": "Кварц 25 МГц, аналоговый стабилизатор и ESD-защита обеспечивают работу PHY и внешнего соединения.",
      "refs": [
        "control_Y900",
        "control_U903",
        "control_U904",
        "control_U905",
        "control_U906",
        "control_U907",
        "control_C930",
        "control_C910",
        "control_C911",
        "control_C913",
        "control_C921",
        "control_C908",
        "control_C929",
        "control_C915",
        "control_C927",
        "control_C931",
        "control_C924",
        "control_C926",
        "control_C925",
        "control_C916",
        "control_C920",
        "control_C923",
        "control_C919",
        "control_C917",
        "control_C922",
        "control_C912",
        "control_C909",
        "control_C928",
        "control_C918",
        "control_C914"
      ],
      "role": "power",
      "x": 870,
      "y": 570,
      "w": 260,
      "h": 140,
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_Y900",
          "control_U903",
          "control_U904",
          "control_U905",
          "control_U906",
          "control_U907",
          "control_C930",
          "control_C910",
          "control_C911",
          "control_C913",
          "control_C921",
          "control_C908",
          "control_C929",
          "control_C915",
          "control_C927",
          "control_C931",
          "control_C924",
          "control_C926",
          "control_C925",
          "control_C916",
          "control_C920",
          "control_C923",
          "control_C919",
          "control_C917",
          "control_C922",
          "control_C912",
          "control_C909",
          "control_C928",
          "control_C918",
          "control_C914"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C908",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C909",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C910",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C911",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C912",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C913",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C914",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C915",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C916",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C917",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C918",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C919",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C920",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C921",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C922",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C923",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C924",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C925",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C926",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C927",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C928",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C929",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C930",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C931",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U903",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U904",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U905",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U906",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U907",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_Y900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "connector_isolation_0",
      "from": "connector",
      "to": "isolation",
      "label": "Четыре кабельные пары",
      "type": "analog",
      "nets": [
        "control_net_eb689a40d9d8",
        "control_net_a0be4ca78cf4",
        "control_net_783e9d027a80",
        "control_net_e72d81f71514",
        "control_net_75386a9fba9e",
        "control_net_40965b12abcc",
        "control_net_46a7e4543439",
        "control_net_a5f76ff3f3d9"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Кабельные пары",
      "netLabels": [
        "ETH_A_P",
        "ETH_A_N",
        "ETH_B_P",
        "ETH_C_P",
        "ETH_C_N",
        "ETH_B_N",
        "ETH_D_P",
        "ETH_D_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ETH_A_P · ETH_A_N",
        "ETH_B_P · ETH_B_N",
        "ETH_C_P · ETH_C_N",
        "ETH_D_P · ETH_D_N"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "isolation_phy_1",
      "from": "isolation",
      "to": "phy",
      "label": "Сигнал после гальванической развязки",
      "type": "analog",
      "nets": [
        "control_net_e227481650c4",
        "control_net_2b9e82ff1f9a",
        "control_net_b7668147936d",
        "control_net_f14d9beef5b0",
        "control_net_bdf65fc018f7",
        "control_net_c7652af8ac7f",
        "control_net_c06d53ceafd7",
        "control_net_c72c6f1d768f"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Развязанный сигнал",
      "netLabels": [
        "MDI_C_P",
        "MDI_C_N",
        "MDI_A_P",
        "MDI_A_N",
        "MDI_B_P",
        "MDI_B_N",
        "MDI_D_P",
        "MDI_D_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MDI_A_P · MDI_A_N",
        "MDI_B_P · MDI_B_N",
        "MDI_C_P · MDI_C_N",
        "MDI_D_P · MDI_D_N"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "phy_fpga_2",
      "from": "phy",
      "to": "fpga",
      "label": "Приём: данные, тактирование, достоверность",
      "type": "data",
      "nets": [
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_cc90c66f0af7",
        "control_net_5682aa39e237",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Данные приёма",
      "netLabels": [
        "PHY_RXD1",
        "PHY_RXD3",
        "PHY_RXD2",
        "PHY_RXD0",
        "PHY_RXC",
        "PHY_RX_CTL"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PHY_RXC · PHY_RXD0",
        "PHY_RXD1 · PHY_RXD2",
        "PHY_RXD3 · PHY_RX_CTL"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_phy_3",
      "from": "fpga",
      "to": "phy",
      "label": "Передача: данные, тактирование, достоверность",
      "type": "data",
      "nets": [
        "control_net_842a1bd896e7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_af615c537cb1",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Данные передачи",
      "netLabels": [
        "PHY_TXD2",
        "PHY_TX_CTL",
        "PHY_TXD3",
        "PHY_TXC",
        "PHY_TXD1",
        "PHY_TXD0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PHY_TXC · PHY_TXD0",
        "PHY_TXD1 · PHY_TXD2",
        "PHY_TXD3 · PHY_TX_CTL"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "fpga_phy_4",
      "from": "fpga",
      "to": "phy",
      "label": "Настройка и контроль соединения",
      "type": "control",
      "nets": [
        "control_net_20b74826bb9f",
        "control_net_c9c89af3970f",
        "control_net_06de98680544",
        "control_net_0d1a4f8df7dc"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Управление соединением",
      "netLabels": [
        "PHY_MDIO",
        "PHY_RESET_N",
        "PHY_MDC",
        "PHY_INT_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PHY_INT_N · PHY_MDC",
        "PHY_MDIO · PHY_RESET_N"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "management_fpga_5",
      "from": "management",
      "to": "fpga",
      "label": "Буферизованные команды / состояние MCU",
      "type": "control",
      "nets": [
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_d586ee5fe950",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a",
        "control_net_b754ba5a60da"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Связь с контроллером",
      "netLabels": [
        "MCU_FPGA_MOSI_F",
        "MCU_FPGA_CS_N_F",
        "FPGA_IRQ_F",
        "MCU_FPGA_MISO_F",
        "MCU_FPGA_SCK_F",
        "HOST_ALIVE_F"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_IRQ_F",
        "HOST_ALIVE_F",
        "MCU_FPGA_CS_N_F",
        "MCU_FPGA_MISO_F",
        "MCU_FPGA_MOSI_F",
        "MCU_FPGA_SCK_F"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "support_phy_6",
      "from": "support",
      "to": "phy",
      "label": "Тактирование и аналоговое питание",
      "type": "power",
      "nets": [
        "control_net_7d62beb03b56",
        "control_net_45dfddf2e1c0",
        "control_net_9bc8e82b976f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Тактирование / питание",
      "netLabels": [
        "PHY2V5",
        "PHY_XI",
        "PHY_XO"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PHY2V5 · PHY_XI",
        "PHY_XO"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 126,
    "w": 1896,
    "h": 624
  },
  "board": "control",
  "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 73,
  "suggestedScenario": "local-control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_J900",
      "control_R921",
      "control_C938",
      "control_C937",
      "control_T900",
      "control_C933",
      "control_R917",
      "control_R920",
      "control_C936",
      "control_R919",
      "control_R918",
      "control_C935",
      "control_C934",
      "control_U902",
      "control_R914",
      "control_R910",
      "control_R912",
      "control_R916",
      "control_R907",
      "control_C932",
      "control_R906",
      "control_R908",
      "control_R911",
      "control_R915",
      "control_R909",
      "control_U500",
      "control_C904",
      "control_C902",
      "control_C900",
      "control_C905",
      "control_R913",
      "control_C901",
      "control_C903",
      "control_U900",
      "control_U901",
      "control_C907",
      "control_R902",
      "control_R904",
      "control_C906",
      "control_R900",
      "control_R901",
      "control_R905",
      "control_R903",
      "control_Y900",
      "control_U903",
      "control_U904",
      "control_U905",
      "control_U906",
      "control_U907",
      "control_C930",
      "control_C910",
      "control_C911",
      "control_C913",
      "control_C921",
      "control_C908",
      "control_C929",
      "control_C915",
      "control_C927",
      "control_C931",
      "control_C924",
      "control_C926",
      "control_C925",
      "control_C916",
      "control_C920",
      "control_C923",
      "control_C919",
      "control_C917",
      "control_C922",
      "control_C912",
      "control_C909",
      "control_C928",
      "control_C918",
      "control_C914"
    ],
    "sheetIds": [
      "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
    ],
    "units": [
      {
        "component": "control_C937",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C938",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_J900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R921",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C933",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C934",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C935",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C936",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R917",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R918",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R919",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R920",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_T900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C932",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R906",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R907",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R908",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R909",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R910",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R911",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R912",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R914",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R915",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R916",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_C900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C901",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C903",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C904",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C905",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R913",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_C906",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C907",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R901",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R903",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R904",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R905",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U901",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C908",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C909",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C910",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C911",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C912",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C913",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C914",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C915",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C916",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C917",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C918",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C919",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C920",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C921",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C922",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C923",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C924",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C925",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C926",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C927",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C928",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C929",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C930",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C931",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U903",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U904",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U905",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U906",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U907",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_Y900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "ethernet-local-rx",
    "local-control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
  ],
  "explanationTitleRu": "Ethernet · от сигнала в кабеле до ПЛИС",
  "sourceSheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "sourceSheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
  "sourceFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-fpga",
  "layout": {
    "version": 2,
    "kind": "signal-with-branches",
    "label": "Физический сигнал превращается в цифровые данные",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 161,
      "w": 1816,
      "h": 263,
      "title": "Путь сигнала",
      "kind": "primary",
      "nodeIds": [
        "connector",
        "isolation",
        "phy",
        "fpga"
      ]
    }
  ]
};
