/* Editable functional scene: power_700_SYS_3V3 */
window.MIRA_FUNCTIONAL.scenes["power_700_SYS_3V3"]={
  "id": "power_700_SYS_3V3",
  "title": "700_SYS_3V3",
  "subtitle": "Питание контроллера 3,3 В",
  "description": "U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_700_SYS_3V3"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_700_SYS_3V3"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Системное питание контроллера: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U701",
        "power_L701",
        "power_R701"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_700_SYS_3V3",
      "sourceSheetIds": [
        "power_700_SYS_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U701",
          "power_L701",
          "power_R701"
        ],
        "sheetIds": [
          "power_700_SYS_3V3"
        ],
        "units": [
          {
            "component": "power_L701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_R701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_U701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q701",
        "power_R702"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_700_SYS_3V3",
      "sourceSheetIds": [
        "power_700_SYS_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q701",
          "power_R702"
        ],
        "sheetIds": [
          "power_700_SYS_3V3"
        ],
        "units": [
          {
            "component": "power_Q701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_R702",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C702",
        "power_C710",
        "power_C703",
        "power_C701",
        "power_C705",
        "power_C714",
        "power_C706",
        "power_C707",
        "power_C709",
        "power_C712",
        "power_C711",
        "power_C713",
        "power_C708",
        "power_C704",
        "power_R706",
        "power_R703",
        "power_R704",
        "power_R705",
        "power_D701"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_700_SYS_3V3",
      "sourceSheetIds": [
        "power_700_SYS_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_C702",
          "power_C710",
          "power_C703",
          "power_C701",
          "power_C705",
          "power_C714",
          "power_C706",
          "power_C707",
          "power_C709",
          "power_C712",
          "power_C711",
          "power_C713",
          "power_C708",
          "power_C704",
          "power_R706",
          "power_R703",
          "power_R704",
          "power_R705",
          "power_D701"
        ],
        "sheetIds": [
          "power_700_SYS_3V3"
        ],
        "units": [
          {
            "component": "power_C701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C702",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C703",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C704",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C705",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C706",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C707",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C708",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C709",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C710",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C711",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C712",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C713",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_C714",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_D701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_R703",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_R704",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_R705",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          },
          {
            "component": "power_R706",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход SYS3V3",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_700_SYS_3V3"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_700_SYS_3V3"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_e7486b382586",
        "power_net_182b119f7233"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "SYS3V3",
        "SYS_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "SYS3V3",
        "SYS_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "SYS3V3",
      "type": "power",
      "nets": [
        "power_net_e7486b382586"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "SYS3V3",
      "netLabels": [
        "SYS3V3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "SYS3V3"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_9020238d369a",
        "power_net_02417181d3e9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_SYS",
        "EN_SYS"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_SYS",
        "EN_SYS"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_700_SYS_3V3",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 24,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U701",
      "power_L701",
      "power_R701",
      "power_Q701",
      "power_R702",
      "power_C702",
      "power_C710",
      "power_C703",
      "power_C701",
      "power_C705",
      "power_C714",
      "power_C706",
      "power_C707",
      "power_C709",
      "power_C712",
      "power_C711",
      "power_C713",
      "power_C708",
      "power_C704",
      "power_R706",
      "power_R703",
      "power_R704",
      "power_R705",
      "power_D701"
    ],
    "sheetIds": [
      "power_700_SYS_3V3"
    ],
    "units": [
      {
        "component": "power_L701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_R701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_U701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_Q701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_R702",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C702",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C703",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C704",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C705",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C706",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C707",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C708",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C709",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C710",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C711",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C712",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C713",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_C714",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_D701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_R703",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_R704",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_R705",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_R706",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_700_SYS_3V3"
  ],
  "suggestedScenario": "local-power_700_SYS_3V3",
  "explanationTitleRu": "Питание контроллера 3,3 В",
  "sourceSheetId": "power_700_SYS_3V3",
  "sourceSheetName": "700_SYS_3V3",
  "sourceFile": "700_SYS_3V3.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
