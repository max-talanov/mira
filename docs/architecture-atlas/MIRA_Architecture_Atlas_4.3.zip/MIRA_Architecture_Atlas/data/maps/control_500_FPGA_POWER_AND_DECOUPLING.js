/* Editable functional scene: control_500_FPGA_POWER_AND_DECOUPLING */
window.MIRA_FUNCTIONAL.scenes["control_500_FPGA_POWER_AND_DECOUPLING"]={
  "id": "control_500_FPGA_POWER_AND_DECOUPLING",
  "title": "500_FPGA_POWER_AND_DECOUPLING",
  "subtitle": "Питание ПЛИС",
  "description": "U500 — одна ПЛИС XC7A200T-2FBG484I с отдельным питанием ядра, вспомогательных узлов и банков ввода-вывода. Каждая группа имеет локальные развязывающие конденсаторы.",
  "nodes": [
    {
      "id": "core",
      "title": "Внутренняя логика ПЛИС",
      "subtitle": "",
      "description": "CORE1V0 питает внутреннюю логику и блочную память ПЛИС.",
      "refs": [
        "control_U500"
      ],
      "role": "power",
      "x": 590,
      "y": 250,
      "w": 370,
      "h": 198,
      "sheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "sourceSheetIds": [
        "control_500_FPGA_POWER_AND_DECOUPLING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500"
        ],
        "sheetIds": [
          "control_500_FPGA_POWER_AND_DECOUPLING"
        ],
        "units": [
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 9
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 10
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 11
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 12
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 13
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "reservoir",
      "title": "Конденсаторы питания ядра",
      "subtitle": "",
      "description": "Накопительные и локальные конденсаторы поддерживают домен питания ядра.",
      "refs": [
        "control_C500",
        "control_C501",
        "control_C502",
        "control_C503",
        "control_C504",
        "control_C505",
        "control_C506",
        "control_C507",
        "control_C508",
        "control_C509",
        "control_C510",
        "control_C511",
        "control_C512",
        "control_C513",
        "control_C514",
        "control_C515",
        "control_C516",
        "control_C517",
        "control_C518",
        "control_C519",
        "control_C520",
        "control_C521",
        "control_C522",
        "control_C523",
        "control_C524",
        "control_C525",
        "control_C526",
        "control_C527",
        "control_C528",
        "control_C529",
        "control_C530",
        "control_C531",
        "control_C532",
        "control_C533",
        "control_C534",
        "control_C535",
        "control_C536",
        "control_C537",
        "control_C538",
        "control_C539"
      ],
      "role": "power",
      "x": 40,
      "y": 70,
      "w": 250,
      "h": 132,
      "sheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "sourceSheetIds": [
        "control_500_FPGA_POWER_AND_DECOUPLING"
      ],
      "circuitGroup": {
        "refs": [
          "control_C500",
          "control_C501",
          "control_C502",
          "control_C503",
          "control_C504",
          "control_C505",
          "control_C506",
          "control_C507",
          "control_C508",
          "control_C509",
          "control_C510",
          "control_C511",
          "control_C512",
          "control_C513",
          "control_C514",
          "control_C515",
          "control_C516",
          "control_C517",
          "control_C518",
          "control_C519",
          "control_C520",
          "control_C521",
          "control_C522",
          "control_C523",
          "control_C524",
          "control_C525",
          "control_C526",
          "control_C527",
          "control_C528",
          "control_C529",
          "control_C530",
          "control_C531",
          "control_C532",
          "control_C533",
          "control_C534",
          "control_C535",
          "control_C536",
          "control_C537",
          "control_C538",
          "control_C539"
        ],
        "sheetIds": [
          "control_500_FPGA_POWER_AND_DECOUPLING"
        ],
        "units": [
          {
            "component": "control_C500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C501",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C502",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C503",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C504",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C505",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C506",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C507",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C508",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C509",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C510",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C511",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C512",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C513",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C514",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C515",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C516",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C517",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C518",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C519",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C520",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C521",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C522",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C523",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C524",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C525",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C526",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C527",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C528",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C529",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C530",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C531",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C532",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C533",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C534",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C535",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C536",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C537",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C538",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C539",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "aux",
      "title": "Питание банков и вспомогательных узлов",
      "subtitle": "",
      "description": "Локальные конденсаторы поддерживают вспомогательное питание и отдельные банки ввода-вывода.",
      "refs": [
        "control_C540",
        "control_C541",
        "control_C542",
        "control_C543",
        "control_C544",
        "control_C545",
        "control_C546",
        "control_C547",
        "control_C548",
        "control_C549",
        "control_C550",
        "control_C551",
        "control_C552",
        "control_C553",
        "control_C554",
        "control_C555",
        "control_C556",
        "control_C557",
        "control_C558",
        "control_C559",
        "control_C560",
        "control_C561",
        "control_C562",
        "control_C563",
        "control_C564",
        "control_C565",
        "control_C566",
        "control_C567",
        "control_C568",
        "control_C569",
        "control_C570",
        "control_C571",
        "control_C572",
        "control_C573",
        "control_C574",
        "control_C575",
        "control_C576",
        "control_C577",
        "control_C578",
        "control_C579",
        "control_C580",
        "control_C581"
      ],
      "role": "power",
      "x": 40,
      "y": 545,
      "w": 260,
      "h": 140,
      "sheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "sourceSheetIds": [
        "control_500_FPGA_POWER_AND_DECOUPLING"
      ],
      "circuitGroup": {
        "refs": [
          "control_C540",
          "control_C541",
          "control_C542",
          "control_C543",
          "control_C544",
          "control_C545",
          "control_C546",
          "control_C547",
          "control_C548",
          "control_C549",
          "control_C550",
          "control_C551",
          "control_C552",
          "control_C553",
          "control_C554",
          "control_C555",
          "control_C556",
          "control_C557",
          "control_C558",
          "control_C559",
          "control_C560",
          "control_C561",
          "control_C562",
          "control_C563",
          "control_C564",
          "control_C565",
          "control_C566",
          "control_C567",
          "control_C568",
          "control_C569",
          "control_C570",
          "control_C571",
          "control_C572",
          "control_C573",
          "control_C574",
          "control_C575",
          "control_C576",
          "control_C577",
          "control_C578",
          "control_C579",
          "control_C580",
          "control_C581"
        ],
        "sheetIds": [
          "control_500_FPGA_POWER_AND_DECOUPLING"
        ],
        "units": [
          {
            "component": "control_C540",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C541",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C542",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C543",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C544",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C545",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C546",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C547",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C548",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C549",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C550",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C551",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C552",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C553",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C554",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C555",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C556",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C557",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C558",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C559",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C560",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C561",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C562",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C563",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C564",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C565",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C566",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C567",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C568",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C569",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C570",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C571",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C572",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C573",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C574",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C575",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C576",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C577",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C578",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C579",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C580",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_C581",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "reservoir_core_0",
      "from": "reservoir",
      "to": "core",
      "label": "CORE1V0",
      "type": "power",
      "nets": [
        "control_net_4bfa9adb9035"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "CORE1V0",
      "netLabels": [
        "CORE1V0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CORE1V0"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "aux_core_1",
      "from": "aux",
      "to": "core",
      "label": "Вспомогательное питание / банки / память",
      "type": "power",
      "nets": [
        "control_net_6f005443ad9c",
        "control_net_fc6dfc0c018d",
        "control_net_a0d28f360159"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Питание",
      "netLabels": [
        "IO3V3",
        "AUX1V8",
        "DDR1V35"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AUX1V8 · DDR1V35",
        "IO3V3"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 1000,
    "h": 690
  },
  "board": "control",
  "sheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 83,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U500",
      "control_C500",
      "control_C501",
      "control_C502",
      "control_C503",
      "control_C504",
      "control_C505",
      "control_C506",
      "control_C507",
      "control_C508",
      "control_C509",
      "control_C510",
      "control_C511",
      "control_C512",
      "control_C513",
      "control_C514",
      "control_C515",
      "control_C516",
      "control_C517",
      "control_C518",
      "control_C519",
      "control_C520",
      "control_C521",
      "control_C522",
      "control_C523",
      "control_C524",
      "control_C525",
      "control_C526",
      "control_C527",
      "control_C528",
      "control_C529",
      "control_C530",
      "control_C531",
      "control_C532",
      "control_C533",
      "control_C534",
      "control_C535",
      "control_C536",
      "control_C537",
      "control_C538",
      "control_C539",
      "control_C540",
      "control_C541",
      "control_C542",
      "control_C543",
      "control_C544",
      "control_C545",
      "control_C546",
      "control_C547",
      "control_C548",
      "control_C549",
      "control_C550",
      "control_C551",
      "control_C552",
      "control_C553",
      "control_C554",
      "control_C555",
      "control_C556",
      "control_C557",
      "control_C558",
      "control_C559",
      "control_C560",
      "control_C561",
      "control_C562",
      "control_C563",
      "control_C564",
      "control_C565",
      "control_C566",
      "control_C567",
      "control_C568",
      "control_C569",
      "control_C570",
      "control_C571",
      "control_C572",
      "control_C573",
      "control_C574",
      "control_C575",
      "control_C576",
      "control_C577",
      "control_C578",
      "control_C579",
      "control_C580",
      "control_C581"
    ],
    "sheetIds": [
      "control_500_FPGA_POWER_AND_DECOUPLING"
    ],
    "units": [
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 9
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 10
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 11
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 12
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 13
      },
      {
        "component": "control_C500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C501",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C502",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C503",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C504",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C505",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C506",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C507",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C508",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C509",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C510",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C511",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C512",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C513",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C514",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C515",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C516",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C517",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C518",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C519",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C520",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C521",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C522",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C523",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C524",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C525",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C526",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C527",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C528",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C529",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C530",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C531",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C532",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C533",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C534",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C535",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C536",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C537",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C538",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C539",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C540",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C541",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C542",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C543",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C544",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C545",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C546",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C547",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C548",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C549",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C550",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C551",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C552",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C553",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C554",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C555",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C556",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C557",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C558",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C559",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C560",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C561",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C562",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C563",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C564",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C565",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C566",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C567",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C568",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C569",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C570",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C571",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C572",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C573",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C574",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C575",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C576",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C577",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C578",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C579",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C580",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_C581",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_500_FPGA_POWER_AND_DECOUPLING"
  ],
  "suggestedScenario": "local-control_500_FPGA_POWER_AND_DECOUPLING",
  "explanationTitleRu": "Питание ПЛИС",
  "sourceSheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
  "sourceSheetName": "500_FPGA_POWER_AND_DECOUPLING",
  "sourceFile": "500_FPGA_POWER_AND_DECOUPLING.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-fpga",
  "layout": {
    "version": 2,
    "kind": "fpga-power-support",
    "label": "Домен ядра и отдельные группы локального питания",
    "geometryOnly": true
  },
  "regions": []
};
