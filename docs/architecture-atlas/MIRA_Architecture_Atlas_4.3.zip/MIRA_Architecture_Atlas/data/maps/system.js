/* Editable functional scene: system */
window.MIRA_FUNCTIONAL.scenes["system"]={
  "id": "system",
  "title": "MIRA",
  "subtitle": "Общая структура · названия разделов и модулей совпадают с KiCad",
  "description": "Посмотрите, за что отвечает каждый блок. Запустите историю и проследите весь путь на одной диаграмме; затем раскройте нужный модуль.",
  "nodes": [
    {
      "id": "supply",
      "title": "Источник питания",
      "subtitle": "Питание обеих плат",
      "description": "Внешний источник подаёт питание на плату Power.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": -80,
      "w": 250,
      "h": 140,
      "fixed": true,
      "sourceSheetIds": [],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "power",
      "title": "POWER_SYSTEM",
      "subtitle": "Система питания",
      "description": "Плата Power защищает вход и формирует напряжения питания всех узлов MIRA.",
      "refs": [
        "power_J101",
        "power_U2401",
        "power_U301"
      ],
      "role": "power",
      "x": 500,
      "y": -90,
      "w": 410,
      "h": 210,
      "sceneId": "power",
      "fixed": true,
      "sourceSheetIds": [
        "power_100_INPUT_CONNECTOR",
        "power_2400_PM_CONTROLLER",
        "power_300_INPUT_EFUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_J101",
          "power_U2401",
          "power_U301"
        ],
        "sheetIds": [
          "power_100_INPUT_CONNECTOR",
          "power_2400_PM_CONTROLLER",
          "power_300_INPUT_EFUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_J101",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          },
          {
            "component": "power_U2401",
            "sheet": "power_2400_PM_CONTROLLER",
            "unit": 1
          },
          {
            "component": "power_U301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Система питания",
      "sourceSheetName": "POWER_SYSTEM",
      "sourceSheetId": "power_POWER_SYSTEM",
      "sourceFile": "POWER_SYSTEM.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "safety",
      "title": "PROTECTION",
      "subtitle": "Аппаратная защита",
      "description": "Аппаратные блокировки, ограничение тока и фиксация аварий могут остановить операцию с матрицей.",
      "refs": [
        "power_U2603",
        "control_U2200",
        "control_U2202"
      ],
      "role": "fault",
      "x": 480,
      "y": 650,
      "w": 320,
      "h": 170,
      "sceneId": "control_PROTECTION",
      "fixed": true,
      "sourceSheetIds": [
        "power_2600_PM_PERMIT_INTERLOCKS",
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2603",
          "control_U2200",
          "control_U2202"
        ],
        "sheetIds": [
          "power_2600_PM_PERMIT_INTERLOCKS",
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_U2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Аппаратная защита",
      "sourceSheetName": "PROTECTION",
      "sourceSheetId": "control_PROTECTION",
      "sourceFile": "PROTECTION.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "mcu",
      "title": "MCU",
      "subtitle": "Контроллер эксперимента",
      "description": "Основной STM32 хранит эксперимент и обменивается командами и состоянием с ПЛИС.",
      "refs": [
        "control_U100"
      ],
      "role": "data",
      "x": 1085,
      "y": -90,
      "w": 410,
      "h": 210,
      "sceneId": "control-host",
      "fixed": true,
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "control_200_MCU_FMC_AND_SDRAM",
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_U100"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
          "control_200_MCU_FMC_AND_SDRAM",
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 4
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 5
          },
          {
            "component": "control_U100",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 2
          },
          {
            "component": "control_U100",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 3
          }
        ]
      },
      "explanationTitleRu": "Контроллер эксперимента",
      "sourceSheetName": "MCU",
      "sourceSheetId": "control_MCU",
      "sourceFile": "MCU.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "host",
      "title": "Компьютер",
      "subtitle": "Настройка эксперимента · сбор результатов",
      "description": "Компьютер отправляет команды эксперимента и получает результаты измерений.",
      "refs": [],
      "role": "data",
      "x": 40,
      "y": 300,
      "w": 250,
      "h": 145,
      "fixed": true,
      "sourceSheetIds": [],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "links",
      "title": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "subtitle": "Ethernet / USB",
      "description": "Ethernet и USB преобразуют внешнее соединение в цифровой интерфейс ПЛИС.",
      "refs": [
        "control_J900",
        "control_T900",
        "control_U902",
        "control_J700",
        "control_U707"
      ],
      "role": "data",
      "x": 510,
      "y": 295,
      "w": 370,
      "h": 162,
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "fixed": true,
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_J900",
          "control_T900",
          "control_U902",
          "control_J700",
          "control_U707"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_J700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_J900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_T900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          }
        ]
      },
      "explanationTitleRu": "Ethernet / USB",
      "sourceSheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "fpga",
      "title": "FPGA",
      "subtitle": "ПЛИС",
      "description": "Программируемая логика управляет коммутацией матрицы, командами ЦАП, приёмом данных АЦП и быстрым обменом.",
      "refs": [
        "control_U500"
      ],
      "role": "data",
      "x": 1100,
      "y": 280,
      "w": 410,
      "h": 210,
      "sceneId": "control-fpga",
      "fixed": true,
      "sourceSheetIds": [
        "control_500_FPGA_POWER_AND_DECOUPLING",
        "control_600_FPGA_CONFIGURATION_AND_XADC",
        "control_700_FPGA_USB3_FIFO_INTERFACE",
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500"
        ],
        "sheetIds": [
          "control_500_FPGA_POWER_AND_DECOUPLING",
          "control_600_FPGA_CONFIGURATION_AND_XADC",
          "control_700_FPGA_USB3_FIFO_INTERFACE",
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
          "control_1200_DAC_FPGA_CONTROL_INTERFACE",
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_U500",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 7
          },
          {
            "component": "control_U500",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 8
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 9
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 10
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 11
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 12
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 13
          },
          {
            "component": "control_U500",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 2
          },
          {
            "component": "control_U500",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 5
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 6
          },
          {
            "component": "control_U500",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          }
        ]
      },
      "explanationTitleRu": "ПЛИС",
      "sourceSheetName": "FPGA",
      "sourceSheetId": "control_FPGA",
      "sourceFile": "FPGA.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "drive",
      "title": "DAC",
      "subtitle": "Аналоговое воздействие",
      "description": "Уставки ЦАП и общий регулируемый источник задают напряжения и ограничивают ток программирования.",
      "refs": [
        "control_U1000",
        "control_U1100",
        "control_U2101"
      ],
      "role": "analog",
      "x": 1620,
      "y": 285,
      "w": 270,
      "h": 160,
      "sceneId": "control-sources",
      "fixed": true,
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS",
        "control_1100_DAC_SERVICE_AND_FORMING",
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1000",
          "control_U1100",
          "control_U2101"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS",
          "control_1100_DAC_SERVICE_AND_FORMING",
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_U1000",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1100",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U2101",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Аналоговое воздействие",
      "sourceSheetName": "DAC",
      "sourceSheetId": "control_DAC",
      "sourceFile": "DAC.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "readout",
      "title": "ADC",
      "subtitle": "Измерение отклика",
      "description": "Измерительный тракт преобразует ток в напряжение, подготавливает сигнал для АЦП и выдаёт цифровые отсчёты.",
      "refs": [
        "control_U1900",
        "control_U2003",
        "control_U2004"
      ],
      "role": "analog",
      "x": 1090,
      "y": 635,
      "w": 290,
      "h": 152,
      "sceneId": "control-readout",
      "fixed": true,
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1900",
          "control_U2003",
          "control_U2004"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_U1900",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U2003",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2004",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Измерение отклика",
      "sourceSheetName": "ADC",
      "sourceSheetId": "control_ADC",
      "sourceFile": "ADC.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "matrix",
      "title": "MATRIX",
      "subtitle": "Мемристорная матрица",
      "description": "Зафиксированное состояние ключей направляет выбранное воздействие через экспериментальную мемристорную матрицу.",
      "refs": [
        "control_J1800"
      ],
      "role": "analog",
      "x": 1620,
      "y": 620,
      "w": 410,
      "h": 210,
      "sceneId": "control-routing",
      "fixed": true,
      "sourceSheetIds": [
        "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
      ],
      "circuitGroup": {
        "refs": [
          "control_J1800"
        ],
        "sheetIds": [
          "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
        ],
        "units": [
          {
            "component": "control_J1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 1
          },
          {
            "component": "control_J1800",
            "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
            "unit": 2
          }
        ]
      },
      "explanationTitleRu": "Мемристорная матрица",
      "sourceSheetName": "MATRIX",
      "sourceSheetId": "control_MATRIX",
      "sourceFile": "MATRIX.kicad_sch",
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "supply_power",
      "from": "supply",
      "to": "power",
      "label": "Вход 24 В",
      "type": "power",
      "nets": [
        "power_net_6741c8732f40"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "24 В",
      "netLabels": [
        "+24V_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "+24V_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "power_fpga",
      "from": "power",
      "to": "fpga",
      "label": "Последовательно включаемое цифровое питание",
      "type": "power",
      "nets": [
        "control_net_6f005443ad9c",
        "control_net_4bfa9adb9035",
        "control_net_fc6dfc0c018d"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Цифровое питание",
      "netLabels": [
        "IO3V3",
        "CORE1V0",
        "AUX1V8"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AUX1V8 · CORE1V0",
        "IO3V3"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P1",
        "title": "Цифровое питание"
      },
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "power_drive",
      "from": "power",
      "to": "drive",
      "label": "Аналоговые шины питания",
      "type": "power",
      "nets": [
        "control_net_b4fd0f4101eb",
        "control_net_a05784e4a1d3",
        "control_net_2e82cb98585d",
        "control_net_e5381212c338"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Аналоговое питание",
      "netLabels": [
        "ANA5",
        "ANA3V3",
        "P15",
        "N15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA3V3 · ANA5",
        "N15 · P15"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P2",
        "title": "Аналоговое питание"
      },
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "power_mcu",
      "from": "power",
      "to": "mcu",
      "label": "Питание и состояние контроллера",
      "type": "power",
      "nets": [
        "control_net_90c4fa851afd",
        "control_net_df95db02c560"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Питание контроллера",
      "netLabels": [
        "SYS3V3",
        "ALL_RAILS_PG_HOST"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "SYS3V3",
        "ALL_RAILS_PG_HOST"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P3",
        "title": "Питание контроллера"
      },
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "host_links",
      "from": "host",
      "to": "links",
      "label": "Команды и результаты",
      "type": "data",
      "nets": [],
      "bidirectional": true,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Команды / результаты",
      "netLabels": [],
      "unnamedNetIds": [],
      "labelLines": [],
      "allConnectionsLabel": "Все соединения: 0",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "links_fpga",
      "from": "links",
      "to": "fpga",
      "label": "Цифровой приём / передача",
      "type": "data",
      "nets": [
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2",
        "control_net_14e361774b31",
        "control_net_7a2cc9ad1aae",
        "control_net_842a1bd896e7",
        "control_net_cc90c66f0af7",
        "control_net_dbd1a2d49097",
        "control_net_f755d28cb131",
        "control_net_5682aa39e237",
        "control_net_af615c537cb1",
        "control_net_e773796fd1f6",
        "control_net_e39e2c0118dc",
        "control_net_bb18f917ddd6",
        "control_net_4b92eab01e5e"
      ],
      "bidirectional": true,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Цифровые данные",
      "netLabels": [
        "FT_D0",
        "FT_D1",
        "FT_D2",
        "FT_D3",
        "FT_D4",
        "FT_D5",
        "FT_D6",
        "FT_D7",
        "FT_D8",
        "FT_D9",
        "FT_D10",
        "FT_D11",
        "FT_D12",
        "FT_D13",
        "FT_D14",
        "FT_D15",
        "FT_D26",
        "FT_D22",
        "FT_D27",
        "FT_D23",
        "FT_D30",
        "FT_D31",
        "FT_D28",
        "FT_D29",
        "FT_D24",
        "FT_D20",
        "FT_D21",
        "FT_D16",
        "FT_D25",
        "FT_D17",
        "FT_D18",
        "FT_D19",
        "PHY_RXD1",
        "PHY_RXD3",
        "PHY_TXD2",
        "PHY_RXD2",
        "PHY_TX_CTL",
        "PHY_TXD3",
        "PHY_RXD0",
        "PHY_TXC",
        "PHY_RXC",
        "PHY_RX_CTL",
        "PHY_TXD1",
        "PHY_TXD0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FT_D0 · FT_D1",
        "FT_D2 · ещё 41"
      ],
      "allConnectionsLabel": "Все соединения: 44",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "mcu_fpga",
      "from": "mcu",
      "to": "fpga",
      "label": "Команды эксперимента / состояние",
      "type": "control",
      "nets": [
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "bidirectional": true,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Команды",
      "netLabels": [
        "MCU_FPGA_CS_N",
        "MCU_FPGA_SCK",
        "MCU_FPGA_MISO",
        "MCU_FPGA_MOSI",
        "FPGA_IRQ",
        "MCU_FPGA_MOSI_F",
        "MCU_FPGA_CS_N_F",
        "MCU_FPGA_MISO_F",
        "MCU_FPGA_SCK_F"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MCU_FPGA_CS_N · MCU_FPGA_SCK",
        "MCU_FPGA_MISO · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "fpga_drive",
      "from": "fpga",
      "to": "drive",
      "label": "Аналоговые уставки",
      "type": "control",
      "nets": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_2889fbee2814",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Уставки",
      "netLabels": [
        "CS_BL3",
        "DAC_SPI_SCK",
        "DAC_SPI_MOSI",
        "DAC_SPI_MISO",
        "CS_BL0",
        "CS_BL1",
        "CS_BL2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CS_BL0 · CS_BL1",
        "CS_BL2 · CS_BL3",
        "DAC_SPI_MISO · DAC_SPI_MOSI",
        "DAC_SPI_SCK"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "drive_matrix",
      "from": "drive",
      "to": "matrix",
      "label": "Выбранные напряжение и ток",
      "type": "analog",
      "nets": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Аналоговое воздействие",
      "netLabels": [
        "BL_DAC22",
        "BL_DAC26",
        "BL_DAC1",
        "BL_DAC23",
        "BL_DAC6",
        "BL_DAC20",
        "BL_DAC7",
        "BL_DAC30",
        "BL_DAC29",
        "BL_DAC27",
        "BL_DAC28",
        "BL_DAC15",
        "BL_DAC21",
        "BL_DAC4",
        "BL_DAC24",
        "BL_DAC9",
        "BL_DAC31",
        "BL_DAC8",
        "BL_DAC18",
        "BL_DAC13",
        "BL_DAC11",
        "BL_DAC17",
        "BL_DAC25",
        "BL_DAC5",
        "BL_DAC3",
        "BL_DAC19",
        "BL_DAC2",
        "BL_DAC16",
        "BL_DAC12",
        "BL_DAC0",
        "BL_DAC14",
        "BL_DAC10"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL_DAC22 · BL_DAC26",
        "BL_DAC1 · ещё 29"
      ],
      "allConnectionsLabel": "Все соединения: 32",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "fpga_matrix",
      "from": "fpga",
      "to": "matrix",
      "label": "Состояние ключей и точное время",
      "type": "control",
      "nets": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_f05b5740e1a9",
        "control_net_c4621dfd0ac4"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Временная логика",
      "netLabels": [
        "MAT_VMM_EN_REQ",
        "MAT_WRITE_EN_REQ",
        "MAT_READ_EN_REQ",
        "MAT_SERVICE_EN_REQ",
        "MAT_SPI_LATCH",
        "MAT_SPI_SCK",
        "MAT_PULSE",
        "MAT_SPI_OE_N",
        "MAT_SPI_MOSI",
        "MAT_FRAME_VALID"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_VMM_EN_REQ · MAT_WRITE_EN_REQ",
        "MAT_READ_EN_REQ · ещё 7"
      ],
      "allConnectionsLabel": "Все соединения: 10",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "matrix_readout",
      "from": "matrix",
      "to": "readout",
      "label": "Измеряемый электрический отклик",
      "type": "analog",
      "nets": [
        "control_net_d65f00f0a2d4"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Отклик",
      "netLabels": [
        "MAT_TIA_IN"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_TIA_IN"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "readout_fpga",
      "from": "readout",
      "to": "fpga",
      "label": "Отсчёты АЦП",
      "type": "data",
      "nets": [
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Отсчёты",
      "netLabels": [
        "MAT_ADC_SDO",
        "MAT_ADC_CNV",
        "MAT_ADC_SDI",
        "MAT_ADC_SCK"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADC_CNV · MAT_ADC_SCK",
        "MAT_ADC_SDI · MAT_ADC_SDO"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "matrix_safety",
      "from": "matrix",
      "to": "safety",
      "label": "События тока / конфигурации",
      "type": "fault",
      "nets": [
        "control_net_d4a1fffbf6b9",
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Входы защиты",
      "netLabels": [
        "MAT_CONFIG_TRIP",
        "MAT_CC_SENSE_BUF",
        "MAT_ILIM_SENSE_BUF"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_CC_SENSE_BUF",
        "MAT_CONFIG_TRIP",
        "MAT_ILIM_SENSE_BUF"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "safety_power",
      "from": "safety",
      "to": "power",
      "label": "Снятие аппаратного разрешения",
      "type": "fault",
      "nets": [
        "control_net_e65fb75085e7"
      ],
      "bidirectional": false,
      "scope": "functional",
      "description": "Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.",
      "shortLabel": "Запрет",
      "netLabels": [
        "MATRIX_INHIBIT_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_INHIBIT_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P4",
        "title": "MATRIX_INHIBIT_N"
      },
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": -125,
    "w": 2126,
    "h": 1020
  },
  "kind": "system",
  "depth": 0,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J101",
      "power_U2401",
      "power_U301",
      "power_U2603",
      "control_U2200",
      "control_U2202",
      "control_U100",
      "control_J900",
      "control_T900",
      "control_U902",
      "control_J700",
      "control_U707",
      "control_U500",
      "control_U1000",
      "control_U1100",
      "control_U2101",
      "control_U1900",
      "control_U2003",
      "control_U2004",
      "control_J1800"
    ],
    "sheetIds": [
      "power_100_INPUT_CONNECTOR",
      "power_2400_PM_CONTROLLER",
      "power_300_INPUT_EFUSE_PROTECTION",
      "power_2600_PM_PERMIT_INTERLOCKS",
      "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "control_200_MCU_FMC_AND_SDRAM",
      "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "control_700_FPGA_USB3_FIFO_INTERFACE",
      "control_500_FPGA_POWER_AND_DECOUPLING",
      "control_600_FPGA_CONFIGURATION_AND_XADC",
      "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "control_1000_DAC_BL0_31_AND_BUFFERS",
      "control_1100_DAC_SERVICE_AND_FORMING",
      "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS"
    ],
    "units": [
      {
        "component": "power_J101",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      },
      {
        "component": "power_U2401",
        "sheet": "power_2400_PM_CONTROLLER",
        "unit": 1
      },
      {
        "component": "power_U301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "control_U2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_U2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 4
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 5
      },
      {
        "component": "control_U100",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 2
      },
      {
        "component": "control_U100",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 3
      },
      {
        "component": "control_J700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_J900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_T900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U500",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 7
      },
      {
        "component": "control_U500",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 8
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 9
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 10
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 11
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 12
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 13
      },
      {
        "component": "control_U500",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 2
      },
      {
        "component": "control_U500",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 5
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 6
      },
      {
        "component": "control_U500",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U1000",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1100",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U2101",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U1900",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U2003",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2004",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_J1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 1
      },
      {
        "component": "control_J1800",
        "sheet": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "unit": 2
      }
    ]
  },
  "localScenarioIds": [
    "power-up",
    "ethernet-rx",
    "ethernet-tx",
    "matrix-read",
    "matrix-write",
    "matrix-fault",
    "fpga-config"
  ],
  "suggestedScenario": "power-up",
  "layout": {
    "version": 2,
    "kind": "system-loop",
    "label": "Главный тракт, управление и отдельная ветвь питания",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 226,
      "w": 2046,
      "h": 629,
      "title": "Данные и воздействие",
      "kind": "primary",
      "nodeIds": [
        "host",
        "links",
        "fpga",
        "drive",
        "matrix",
        "readout"
      ]
    }
  ]
};
