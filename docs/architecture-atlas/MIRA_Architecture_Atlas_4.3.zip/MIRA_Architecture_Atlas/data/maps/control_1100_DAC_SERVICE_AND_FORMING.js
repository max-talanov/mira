/* Editable functional scene: control_1100_DAC_SERVICE_AND_FORMING */
window.MIRA_FUNCTIONAL.scenes["control_1100_DAC_SERVICE_AND_FORMING"]={
  "id": "control_1100_DAC_SERVICE_AND_FORMING",
  "title": "1100_DAC_SERVICE_AND_FORMING",
  "subtitle": "Уставки READ, WRITE и FORMING",
  "description": "U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING.",
  "nodes": [
    {
      "id": "commands",
      "title": "Уставки напряжений эксперимента",
      "subtitle": "",
      "description": "Сервисный ЦАП формирует уставки напряжений и ограничений тока.",
      "refs": [
        "control_U1100",
        "control_C1104",
        "control_C1103",
        "control_C1100",
        "control_R1101",
        "control_C1106",
        "control_C1101",
        "control_C1102",
        "control_R1100",
        "control_C1105",
        "control_R1102"
      ],
      "role": "analog",
      "x": 40,
      "y": 80,
      "w": 350,
      "h": 184,
      "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sourceSheetIds": [
        "control_1100_DAC_SERVICE_AND_FORMING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1100",
          "control_C1104",
          "control_C1103",
          "control_C1100",
          "control_R1101",
          "control_C1106",
          "control_C1101",
          "control_C1102",
          "control_R1100",
          "control_C1105",
          "control_R1102"
        ],
        "sheetIds": [
          "control_1100_DAC_SERVICE_AND_FORMING"
        ],
        "units": [
          {
            "component": "control_C1100",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1103",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1104",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1105",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1106",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1100",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1100",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "buffer",
      "title": "Буферы сервисных уставок",
      "subtitle": "",
      "description": "Прецизионные повторители буферизуют сервисные уставки перед выбором источника и регулированием.",
      "refs": [
        "control_U1101",
        "control_U1102",
        "control_R1108",
        "control_R1107",
        "control_R1115",
        "control_R1103",
        "control_C1109",
        "control_C1112",
        "control_R1104",
        "control_R1111",
        "control_C1110",
        "control_C1111",
        "control_R1105",
        "control_R1110",
        "control_R1114",
        "control_C1108",
        "control_R1112",
        "control_R1106",
        "control_R1116",
        "control_C1107",
        "control_R1109",
        "control_R1113"
      ],
      "role": "analog",
      "x": 690,
      "y": 80,
      "w": 300,
      "h": 154,
      "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sourceSheetIds": [
        "control_1100_DAC_SERVICE_AND_FORMING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1101",
          "control_U1102",
          "control_R1108",
          "control_R1107",
          "control_R1115",
          "control_R1103",
          "control_C1109",
          "control_C1112",
          "control_R1104",
          "control_R1111",
          "control_C1110",
          "control_C1111",
          "control_R1105",
          "control_R1110",
          "control_R1114",
          "control_C1108",
          "control_R1112",
          "control_R1106",
          "control_R1116",
          "control_C1107",
          "control_R1109",
          "control_R1113"
        ],
        "sheetIds": [
          "control_1100_DAC_SERVICE_AND_FORMING"
        ],
        "units": [
          {
            "component": "control_C1107",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1108",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1109",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1110",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1111",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1112",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1103",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1104",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1105",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1106",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1107",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1108",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1109",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1110",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1111",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1112",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1113",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1114",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1115",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1116",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 2
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 3
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 4
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 5
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 2
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 3
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 4
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "forming",
      "title": "Уставка напряжения FORMING",
      "subtitle": "",
      "description": "Отдельный прецизионный ЦАП задаёт напряжение источника FORMING.",
      "refs": [
        "control_U1103",
        "control_R1120",
        "control_R1119",
        "control_C1117",
        "control_C1114",
        "control_C1113",
        "control_C1118",
        "control_C1116",
        "control_R1118",
        "control_C1115"
      ],
      "role": "analog",
      "x": 40,
      "y": 520,
      "w": 350,
      "h": 184,
      "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sourceSheetIds": [
        "control_1100_DAC_SERVICE_AND_FORMING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1103",
          "control_R1120",
          "control_R1119",
          "control_C1117",
          "control_C1114",
          "control_C1113",
          "control_C1118",
          "control_C1116",
          "control_R1118",
          "control_C1115"
        ],
        "sheetIds": [
          "control_1100_DAC_SERVICE_AND_FORMING"
        ],
        "units": [
          {
            "component": "control_C1113",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1114",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1115",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1116",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1117",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1118",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1118",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1119",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1120",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1103",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "formbuffer",
      "title": "Буфер источника FORMING",
      "subtitle": "",
      "description": "Усилитель FORMING управляет следующим аналоговым каскадом.",
      "refs": [
        "control_U1104",
        "control_C1121",
        "control_C1120",
        "control_C1122",
        "control_R1117",
        "control_C1119"
      ],
      "role": "analog",
      "x": 690,
      "y": 520,
      "w": 300,
      "h": 154,
      "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sourceSheetIds": [
        "control_1100_DAC_SERVICE_AND_FORMING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1104",
          "control_C1121",
          "control_C1120",
          "control_C1122",
          "control_R1117",
          "control_C1119"
        ],
        "sheetIds": [
          "control_1100_DAC_SERVICE_AND_FORMING"
        ],
        "units": [
          {
            "component": "control_C1119",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1120",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1121",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_C1122",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_R1117",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1104",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1104",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 2
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "commands_buffer",
      "from": "commands",
      "to": "buffer",
      "label": "8 цепей",
      "type": "control",
      "nets": [
        "control_net_e7bd9de88b26",
        "control_net_5f3aa6ac02ea",
        "control_net_872644d0a844",
        "control_net_5c53c9973c60",
        "control_net_245f41faaafc",
        "control_net_c1240dda3ce7",
        "control_net_3c3ad73203dc",
        "control_net_a29863c03d26"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "8 цепей",
      "netLabels": [
        "ILIM_SET_DAC",
        "VSET_DAC",
        "VREAD_DAC",
        "MATRIX_BIAS_DAC",
        "ILIM_FORM_DAC",
        "ILIM_RESET_DAC",
        "VWL_DAC",
        "VRESET_DAC"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ILIM_FORM_DAC",
        "ILIM_RESET_DAC",
        "ILIM_SET_DAC",
        "MATRIX_BIAS_DAC",
        "VREAD_DAC",
        "VRESET_DAC",
        "VSET_DAC",
        "VWL_DAC"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "commands_forming",
      "from": "commands",
      "to": "forming",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "DAC_SPI_SCK",
        "DAC_SPI_MOSI",
        "DAC_LDAC_N",
        "DAC_SPI_MISO",
        "DAC_RESET_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DAC_LDAC_N · DAC_RESET_N",
        "DAC_SPI_MISO · DAC_SPI_MOSI",
        "DAC_SPI_SCK"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "forming_formbuffer",
      "from": "forming",
      "to": "formbuffer",
      "label": "VFORM_DAC_RAW",
      "type": "analog",
      "nets": [
        "control_net_5980e068f72a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "VFORM_DAC_RAW",
      "netLabels": [
        "VFORM_DAC_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "VFORM_DAC_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 45,
    "w": 1030,
    "h": 699
  },
  "board": "control",
  "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 49,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1100",
      "control_C1104",
      "control_C1103",
      "control_C1100",
      "control_R1101",
      "control_C1106",
      "control_C1101",
      "control_C1102",
      "control_R1100",
      "control_C1105",
      "control_R1102",
      "control_U1101",
      "control_U1102",
      "control_R1108",
      "control_R1107",
      "control_R1115",
      "control_R1103",
      "control_C1109",
      "control_C1112",
      "control_R1104",
      "control_R1111",
      "control_C1110",
      "control_C1111",
      "control_R1105",
      "control_R1110",
      "control_R1114",
      "control_C1108",
      "control_R1112",
      "control_R1106",
      "control_R1116",
      "control_C1107",
      "control_R1109",
      "control_R1113",
      "control_U1103",
      "control_R1120",
      "control_R1119",
      "control_C1117",
      "control_C1114",
      "control_C1113",
      "control_C1118",
      "control_C1116",
      "control_R1118",
      "control_C1115",
      "control_U1104",
      "control_C1121",
      "control_C1120",
      "control_C1122",
      "control_R1117",
      "control_C1119"
    ],
    "sheetIds": [
      "control_1100_DAC_SERVICE_AND_FORMING"
    ],
    "units": [
      {
        "component": "control_C1100",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1103",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1104",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1105",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1106",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1100",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1100",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1107",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1108",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1109",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1110",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1111",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1112",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1103",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1104",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1105",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1106",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1107",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1108",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1109",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1110",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1111",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1112",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1113",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1114",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1115",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1116",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 2
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 3
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 4
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 5
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 2
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 3
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 4
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 5
      },
      {
        "component": "control_C1113",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1114",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1115",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1116",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1117",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1118",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1118",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1119",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1120",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1103",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1119",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1120",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1121",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_C1122",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_R1117",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1104",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1104",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 2
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1100_DAC_SERVICE_AND_FORMING"
  ],
  "suggestedScenario": "local-control_1100_DAC_SERVICE_AND_FORMING",
  "explanationTitleRu": "Уставки READ, WRITE и FORMING",
  "sourceSheetId": "control_1100_DAC_SERVICE_AND_FORMING",
  "sourceSheetName": "1100_DAC_SERVICE_AND_FORMING",
  "sourceFile": "1100_DAC_SERVICE_AND_FORMING.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-sources",
  "layout": {
    "version": 2,
    "kind": "parallel-sources",
    "label": "Служебные воздействия и FORMING отдельными ветвями",
    "geometryOnly": true
  },
  "regions": []
};
