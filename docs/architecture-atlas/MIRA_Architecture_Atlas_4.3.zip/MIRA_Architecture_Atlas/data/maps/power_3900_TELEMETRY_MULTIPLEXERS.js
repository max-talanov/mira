/* Editable functional scene: power_3900_TELEMETRY_MULTIPLEXERS */
window.MIRA_FUNCTIONAL.scenes["power_3900_TELEMETRY_MULTIPLEXERS"]={
  "id": "power_3900_TELEMETRY_MULTIPLEXERS",
  "title": "3900_TELEMETRY_MULTIPLEXERS",
  "subtitle": "Выбор измеряемой шины",
  "description": "U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания.",
  "nodes": [
    {
      "id": "current",
      "title": "Выбор измеряемого тока",
      "subtitle": "",
      "description": "Селектор 16:1 подключает сигнал тока одной шины к общему измерительному пути.",
      "refs": [
        "power_U3901",
        "power_C3901"
      ],
      "role": "analog",
      "x": 40,
      "y": 100,
      "w": 330,
      "h": 174,
      "sheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "sourceSheetIds": [
        "power_3900_TELEMETRY_MULTIPLEXERS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3901",
          "power_C3901"
        ],
        "sheetIds": [
          "power_3900_TELEMETRY_MULTIPLEXERS"
        ],
        "units": [
          {
            "component": "power_C3901",
            "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
            "unit": 1
          },
          {
            "component": "power_U3901",
            "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "voltage",
      "title": "Выбор соответствующего напряжения",
      "subtitle": "",
      "description": "Парный селектор по тому же адресу выбирает напряжение этой шины.",
      "refs": [
        "power_U3902",
        "power_C3902"
      ],
      "role": "analog",
      "x": 690,
      "y": 100,
      "w": 330,
      "h": 174,
      "sheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
      "sourceSheetIds": [
        "power_3900_TELEMETRY_MULTIPLEXERS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3902",
          "power_C3902"
        ],
        "sheetIds": [
          "power_3900_TELEMETRY_MULTIPLEXERS"
        ],
        "units": [
          {
            "component": "power_C3902",
            "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
            "unit": 1
          },
          {
            "component": "power_U3902",
            "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "current_voltage",
      "from": "current",
      "to": "voltage",
      "label": "Выбранное измерение",
      "type": "control",
      "nets": [
        "power_net_b8fd52d3ecf7",
        "power_net_97db96dcc04b",
        "power_net_2074a83eb788",
        "power_net_7071622db9df",
        "power_net_b5187ab6f19a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Выбранное измерение",
      "netLabels": [
        "MUX_A0",
        "MUX_A1",
        "MUX_A2",
        "MUX_A3",
        "MUX_DISABLE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MUX_A0 · MUX_A1",
        "MUX_A2 · MUX_A3",
        "MUX_DISABLE"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 65,
    "w": 1060,
    "h": 249
  },
  "board": "power",
  "sheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 4,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3901",
      "power_C3901",
      "power_U3902",
      "power_C3902"
    ],
    "sheetIds": [
      "power_3900_TELEMETRY_MULTIPLEXERS"
    ],
    "units": [
      {
        "component": "power_C3901",
        "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
        "unit": 1
      },
      {
        "component": "power_U3901",
        "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
        "unit": 1
      },
      {
        "component": "power_C3902",
        "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
        "unit": 1
      },
      {
        "component": "power_U3902",
        "sheet": "power_3900_TELEMETRY_MULTIPLEXERS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3900_TELEMETRY_MULTIPLEXERS"
  ],
  "suggestedScenario": "local-power_3900_TELEMETRY_MULTIPLEXERS",
  "explanationTitleRu": "Выбор измеряемой шины",
  "sourceSheetId": "power_3900_TELEMETRY_MULTIPLEXERS",
  "sourceSheetName": "3900_TELEMETRY_MULTIPLEXERS",
  "sourceFile": "3900_TELEMETRY_MULTIPLEXERS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "paired-measurement-selectors",
    "label": "Равноправный выбор тока и напряжения одним адресом",
    "geometryOnly": true
  },
  "regions": []
};
