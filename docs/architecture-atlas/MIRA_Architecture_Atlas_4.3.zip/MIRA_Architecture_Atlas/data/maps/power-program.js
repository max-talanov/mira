/* Editable functional scene: power-program */
window.MIRA_FUNCTIONAL.scenes["power-program"]={
  "id": "power-program",
  "title": "PROGRAM_SWITCHES",
  "subtitle": "Питание программирования",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet2100",
      "title": "2100_PROGRAM_POSITIVE",
      "subtitle": "Коммутация положительного питания записи",
      "description": "Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов.",
      "refs": [
        "power_U2101"
      ],
      "role": "power",
      "x": 40,
      "y": 65,
      "w": 380,
      "h": 200,
      "sceneId": "power_2100_PROGRAM_POSITIVE",
      "sheetId": "power_2100_PROGRAM_POSITIVE",
      "sourceSheetIds": [
        "power_2100_PROGRAM_POSITIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2101"
        ],
        "sheetIds": [
          "power_2100_PROGRAM_POSITIVE"
        ],
        "units": [
          {
            "component": "power_U2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Коммутация положительного питания записи",
      "sourceSheetName": "2100_PROGRAM_POSITIVE",
      "sourceSheetId": "power_2100_PROGRAM_POSITIVE",
      "sourceFile": "2100_PROGRAM_POSITIVE.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet2200",
      "title": "2200_PROGRAM_NEGATIVE",
      "subtitle": "Коммутация отрицательного питания записи",
      "description": "Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом.",
      "refs": [
        "power_U2203",
        "power_U2201",
        "power_U2202"
      ],
      "role": "power",
      "x": 40,
      "y": 470,
      "w": 380,
      "h": 200,
      "sceneId": "power_2200_PROGRAM_NEGATIVE",
      "sheetId": "power_2200_PROGRAM_NEGATIVE",
      "sourceSheetIds": [
        "power_2200_PROGRAM_NEGATIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2203",
          "power_U2201",
          "power_U2202"
        ],
        "sheetIds": [
          "power_2200_PROGRAM_NEGATIVE"
        ],
        "units": [
          {
            "component": "power_U2201",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2202",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          },
          {
            "component": "power_U2203",
            "sheet": "power_2200_PROGRAM_NEGATIVE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Коммутация отрицательного питания записи",
      "sourceSheetName": "2200_PROGRAM_NEGATIVE",
      "sourceSheetId": "power_2200_PROGRAM_NEGATIVE",
      "sourceFile": "2200_PROGRAM_NEGATIVE.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet2300",
      "title": "2300_PROGRAM_INTERFACE",
      "subtitle": "Разъём питания программирования",
      "description": "J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.",
      "refs": [
        "power_J2301"
      ],
      "role": "power",
      "x": 800,
      "y": 265,
      "w": 350,
      "h": 184,
      "sceneId": "power_2300_PROGRAM_INTERFACE",
      "sheetId": "power_2300_PROGRAM_INTERFACE",
      "sourceSheetIds": [
        "power_2300_PROGRAM_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_J2301"
        ],
        "sheetIds": [
          "power_2300_PROGRAM_INTERFACE"
        ],
        "units": [
          {
            "component": "power_J2301",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Разъём питания программирования",
      "sourceSheetName": "2300_PROGRAM_INTERFACE",
      "sourceSheetId": "power_2300_PROGRAM_INTERFACE",
      "sourceFile": "2300_PROGRAM_INTERFACE.kicad_sch",
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "sheet2100_sheet2200",
      "from": "sheet2100",
      "to": "sheet2200",
      "label": "MATRIX_OPTO_K",
      "type": "data",
      "nets": [
        "power_net_46ab17b8adeb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MATRIX_OPTO_K",
      "netLabels": [
        "MATRIX_OPTO_K"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_OPTO_K"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 30,
    "w": 1190,
    "h": 680
  },
  "board": "power",
  "sheetIds": [
    "power_2100_PROGRAM_POSITIVE",
    "power_2200_PROGRAM_NEGATIVE",
    "power_2300_PROGRAM_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2101",
      "power_U2203",
      "power_U2201",
      "power_U2202",
      "power_J2301"
    ],
    "sheetIds": [
      "power_2100_PROGRAM_POSITIVE",
      "power_2200_PROGRAM_NEGATIVE",
      "power_2300_PROGRAM_INTERFACE"
    ],
    "units": [
      {
        "component": "power_U2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_U2201",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2202",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_U2203",
        "sheet": "power_2200_PROGRAM_NEGATIVE",
        "unit": 1
      },
      {
        "component": "power_J2301",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power-program"
  ],
  "suggestedScenario": "local-power-program",
  "explanationTitleRu": "Питание программирования",
  "sourceSheetId": "power_PROGRAM_SWITCHES",
  "sourceSheetName": "PROGRAM_SWITCHES",
  "sourceFile": "PROGRAM_SWITCHES.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power",
  "layout": {
    "version": 2,
    "kind": "bipolar-program-branches",
    "label": "Две равноправные полярности и отдельный выход к нагрузке",
    "geometryOnly": true
  },
  "regions": []
};
