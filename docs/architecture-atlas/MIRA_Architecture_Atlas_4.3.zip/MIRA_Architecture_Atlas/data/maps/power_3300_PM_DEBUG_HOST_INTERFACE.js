/* Editable functional scene: power_3300_PM_DEBUG_HOST_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["power_3300_PM_DEBUG_HOST_INTERFACE"]={
  "id": "power_3300_PM_DEBUG_HOST_INTERFACE",
  "title": "3300_PM_DEBUG_HOST_INTERFACE",
  "subtitle": "Связь контроллера питания с основным",
  "description": "J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера.",
  "nodes": [
    {
      "id": "debug",
      "title": "Программирование контроллера питания",
      "subtitle": "",
      "description": "Разъём SWD предоставляет отладчику доступ к контроллеру питания.",
      "refs": [
        "power_J3301",
        "power_R3301",
        "power_R3306",
        "power_R3302",
        "power_R3303"
      ],
      "role": "data",
      "x": 40,
      "y": 60,
      "w": 250,
      "h": 136,
      "sheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "sourceSheetIds": [
        "power_3300_PM_DEBUG_HOST_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_J3301",
          "power_R3301",
          "power_R3306",
          "power_R3302",
          "power_R3303"
        ],
        "sheetIds": [
          "power_3300_PM_DEBUG_HOST_INTERFACE"
        ],
        "units": [
          {
            "component": "power_J3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3302",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3303",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3306",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "host",
      "title": "Связь с основным контроллером",
      "subtitle": "",
      "description": "Межконтроллерный разъём передаёт UART, сигналы сторожевого контроля и состояния.",
      "refs": [
        "power_J3302",
        "power_R3305"
      ],
      "role": "control",
      "x": 560,
      "y": 285,
      "w": 350,
      "h": 184,
      "sheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "sourceSheetIds": [
        "power_3300_PM_DEBUG_HOST_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_J3302",
          "power_R3305"
        ],
        "sheetIds": [
          "power_3300_PM_DEBUG_HOST_INTERFACE"
        ],
        "units": [
          {
            "component": "power_J3302",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3305",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "isolate",
      "title": "Безопасный приём сигналов",
      "subtitle": "",
      "description": "Буфер с поддержкой Ioff разделяет сигналы на границе доменов питания.",
      "refs": [
        "power_U3301",
        "power_D3301",
        "power_C3302",
        "power_R3304",
        "power_C3301",
        "power_R3307"
      ],
      "role": "control",
      "x": 40,
      "y": 565,
      "w": 240,
      "h": 124,
      "sheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
      "sourceSheetIds": [
        "power_3300_PM_DEBUG_HOST_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3301",
          "power_D3301",
          "power_C3302",
          "power_R3304",
          "power_C3301",
          "power_R3307"
        ],
        "sheetIds": [
          "power_3300_PM_DEBUG_HOST_INTERFACE"
        ],
        "units": [
          {
            "component": "power_C3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_C3302",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_D3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3304",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R3307",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_U3301",
            "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "debug_host",
      "from": "debug",
      "to": "host",
      "label": "PM_UART_RX",
      "type": "data",
      "nets": [
        "power_net_ccf5ee78cf75"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "PM_UART_RX",
      "netLabels": [
        "PM_UART_RX"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PM_UART_RX"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "host_isolate",
      "from": "host",
      "to": "isolate",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_9426b571f348",
        "power_net_89bfaea42e83",
        "power_net_be4d01cedfad",
        "power_net_65bf7e1e53cf"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "PM_UART_TX_HOST",
        "MATRIX_PERMIT_HOST",
        "ALL_RAILS_PG_HOST",
        "GLOBAL_PWR_PERMIT_HOST"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ALL_RAILS_PG_HOST",
        "GLOBAL_PWR_PERMIT_HOST",
        "MATRIX_PERMIT_HOST",
        "PM_UART_TX_HOST"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 950,
    "h": 704
  },
  "board": "power",
  "sheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J3301",
      "power_R3301",
      "power_R3306",
      "power_R3302",
      "power_R3303",
      "power_J3302",
      "power_R3305",
      "power_U3301",
      "power_D3301",
      "power_C3302",
      "power_R3304",
      "power_C3301",
      "power_R3307"
    ],
    "sheetIds": [
      "power_3300_PM_DEBUG_HOST_INTERFACE"
    ],
    "units": [
      {
        "component": "power_J3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3302",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3303",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3306",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_J3302",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3305",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_C3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_C3302",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_D3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3304",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R3307",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_U3301",
        "sheet": "power_3300_PM_DEBUG_HOST_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3300_PM_DEBUG_HOST_INTERFACE"
  ],
  "suggestedScenario": "local-power_3300_PM_DEBUG_HOST_INTERFACE",
  "explanationTitleRu": "Связь контроллера питания с основным",
  "sourceSheetId": "power_3300_PM_DEBUG_HOST_INTERFACE",
  "sourceSheetName": "3300_PM_DEBUG_HOST_INTERFACE",
  "sourceFile": "3300_PM_DEBUG_HOST_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "functional-hub",
    "label": "Главный узел и две связанные функции",
    "geometryOnly": true
  },
  "regions": []
};
