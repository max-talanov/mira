/* Editable functional scene: control-fpga */
window.MIRA_FUNCTIONAL.scenes["control-fpga"]={
  "id": "control-fpga",
  "title": "FPGA",
  "subtitle": "ПЛИС, память и быстрые интерфейсы",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet500",
      "title": "500_FPGA_POWER_AND_DECOUPLING",
      "subtitle": "Питание ПЛИС",
      "description": "U500 — одна ПЛИС XC7A200T-2FBG484I с отдельным питанием ядра, вспомогательных узлов и банков ввода-вывода. Каждая группа имеет локальные развязывающие конденсаторы.",
      "refs": [
        "control_U500"
      ],
      "role": "data",
      "x": 40,
      "y": 60,
      "w": 320,
      "h": 170,
      "sceneId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "sheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "sourceSheetIds": [
        "control_500_FPGA_POWER_AND_DECOUPLING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500"
        ],
        "sheetIds": [
          "control_500_FPGA_POWER_AND_DECOUPLING"
        ],
        "units": [
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 9
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 10
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 11
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 12
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 13
          }
        ]
      },
      "explanationTitleRu": "Питание ПЛИС",
      "sourceSheetName": "500_FPGA_POWER_AND_DECOUPLING",
      "sourceSheetId": "control_500_FPGA_POWER_AND_DECOUPLING",
      "sourceFile": "500_FPGA_POWER_AND_DECOUPLING.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet600",
      "title": "600_FPGA_CONFIGURATION_AND_XADC",
      "subtitle": "Загрузка и восстановление ПЛИС",
      "description": "U500 загружает конфигурацию из SPI flash U600. J600, SW600 и U601 обеспечивают отладку и восстановление. FB600 фильтрует питание XADC.",
      "refs": [
        "control_U601",
        "control_J600",
        "control_U500",
        "control_U600"
      ],
      "role": "data",
      "x": 600,
      "y": 310,
      "w": 410,
      "h": 210,
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetIds": [
        "control_600_FPGA_CONFIGURATION_AND_XADC"
      ],
      "circuitGroup": {
        "refs": [
          "control_U601",
          "control_J600",
          "control_U500",
          "control_U600"
        ],
        "sheetIds": [
          "control_600_FPGA_CONFIGURATION_AND_XADC"
        ],
        "units": [
          {
            "component": "control_J600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 2
          },
          {
            "component": "control_U600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U601",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Загрузка и восстановление ПЛИС",
      "sourceSheetName": "600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceFile": "600_FPGA_CONFIGURATION_AND_XADC.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet700",
      "title": "700_FPGA_USB3_FIFO_INTERFACE",
      "subtitle": "USB · от кабеля до данных ПЛИС",
      "description": "J700 подключает компьютер USB Type-C к мосту U707 FT601 через коммутатор ориентации U706. U707 предоставляет ПЛИС U500 32-битный интерфейс FIFO.",
      "refs": [
        "control_U703",
        "control_U706",
        "control_U704",
        "control_U701",
        "control_U707",
        "control_U705"
      ],
      "role": "data",
      "x": 1170,
      "y": 60,
      "w": 350,
      "h": 174,
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U703",
          "control_U706",
          "control_U704",
          "control_U701",
          "control_U707",
          "control_U705"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U701",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U703",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U704",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U705",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U706",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          }
        ]
      },
      "explanationTitleRu": "USB · от кабеля до данных ПЛИС",
      "sourceSheetName": "700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceFile": "700_FPGA_USB3_FIFO_INTERFACE.kicad_sch",
      "layoutRole": "gateway"
    },
    {
      "id": "sheet800",
      "title": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "subtitle": "Память и тактирование ПЛИС",
      "description": "U800 предоставляет ПЛИС U500 512 МиБ памяти DDR3L. Y800 формирует дифференциальное опорное тактирование подсистемы памяти.",
      "refs": [
        "control_U500",
        "control_U800",
        "control_Y800"
      ],
      "role": "data",
      "x": 40,
      "y": 620,
      "w": 320,
      "h": 166,
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceSheetIds": [
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_U800",
          "control_Y800"
        ],
        "sheetIds": [
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
        ],
        "units": [
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 5
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 6
          },
          {
            "component": "control_U800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_U800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 2
          },
          {
            "component": "control_U800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 3
          },
          {
            "component": "control_Y800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Память и тактирование ПЛИС",
      "sourceSheetName": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceSheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceFile": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet900",
      "title": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "subtitle": "Ethernet · от сигнала в кабеле до ПЛИС",
      "description": "Проследите приём Ethernet на одной диаграмме: сетевой разъём, трансформаторная развязка, приём PHY и обработка в ПЛИС. Выберите соединение, чтобы увидеть реальные цепи и выводы.",
      "refs": [
        "control_U500",
        "control_J900",
        "control_U906",
        "control_U902",
        "control_U904",
        "control_U907"
      ],
      "role": "data",
      "x": 1170,
      "y": 620,
      "w": 350,
      "h": 174,
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetIds": [
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_J900",
          "control_U906",
          "control_U902",
          "control_U904",
          "control_U907"
        ],
        "sheetIds": [
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
        ],
        "units": [
          {
            "component": "control_J900",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U902",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U904",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U906",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U907",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Ethernet · от сигнала в кабеле до ПЛИС",
      "sourceSheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceSheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "sourceFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "sheet600_sheet700",
      "from": "sheet600",
      "to": "sheet700",
      "label": "Данные конфигурации",
      "type": "control",
      "nets": [
        "control_net_3591ba357658",
        "control_net_834296c71f70",
        "control_net_52c8c7557923",
        "control_net_92af7290af48",
        "control_net_9e71347ab99c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Данные конфигурации",
      "netLabels": [
        "FPGA_CFG_D2",
        "FPGA_CFG_D3",
        "FPGA_CFG_CS_N",
        "FPGA_CFG_D0",
        "FPGA_CFG_D1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_CFG_CS_N · FPGA_CFG_D0",
        "FPGA_CFG_D1 · FPGA_CFG_D2",
        "FPGA_CFG_D3"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet600_sheet900",
      "from": "sheet600",
      "to": "sheet900",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_3d9d791e8355",
        "control_net_75501c77d10a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "FPGA_DONE",
        "FPGA_INIT_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_DONE",
        "FPGA_INIT_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet700_sheet900",
      "from": "sheet700",
      "to": "sheet900",
      "label": "CHASSIS",
      "type": "data",
      "nets": [
        "control_net_352fe6713403"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "CHASSIS",
      "netLabels": [
        "CHASSIS"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CHASSIS"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 1560,
    "h": 809
  },
  "board": "control",
  "sheetIds": [
    "control_500_FPGA_POWER_AND_DECOUPLING",
    "control_600_FPGA_CONFIGURATION_AND_XADC",
    "control_700_FPGA_USB3_FIFO_INTERFACE",
    "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
    "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U500",
      "control_U601",
      "control_J600",
      "control_U600",
      "control_U703",
      "control_U706",
      "control_U704",
      "control_U701",
      "control_U707",
      "control_U705",
      "control_U800",
      "control_Y800",
      "control_J900",
      "control_U906",
      "control_U902",
      "control_U904",
      "control_U907"
    ],
    "sheetIds": [
      "control_500_FPGA_POWER_AND_DECOUPLING",
      "control_600_FPGA_CONFIGURATION_AND_XADC",
      "control_700_FPGA_USB3_FIFO_INTERFACE",
      "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE"
    ],
    "units": [
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 9
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 10
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 11
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 12
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 13
      },
      {
        "component": "control_J600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 2
      },
      {
        "component": "control_U600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U601",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U701",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U703",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U704",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U705",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U706",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 5
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 6
      },
      {
        "component": "control_U800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_U800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 2
      },
      {
        "component": "control_U800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 3
      },
      {
        "component": "control_Y800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_J900",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U902",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U904",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U906",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U907",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-fpga"
  ],
  "suggestedScenario": "local-control-fpga",
  "explanationTitleRu": "ПЛИС, память и быстрые интерфейсы",
  "sourceSheetId": "control_FPGA",
  "sourceSheetName": "FPGA",
  "sourceFile": "FPGA.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "fpga-domains",
    "label": "Питание, конфигурация, память и внешние интерфейсы",
    "geometryOnly": true
  },
  "regions": []
};
