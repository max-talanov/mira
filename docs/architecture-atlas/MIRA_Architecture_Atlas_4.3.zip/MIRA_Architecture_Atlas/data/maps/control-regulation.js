/* Editable functional scene: control-regulation */
window.MIRA_FUNCTIONAL.scenes["control-regulation"]={
  "id": "control-regulation",
  "title": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "subtitle": "Регулирование напряжения и тока записи",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet2100",
      "title": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "subtitle": "Ограничение напряжения и тока записи",
      "description": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
      "refs": [
        "control_U2100",
        "control_U2103",
        "control_U2104",
        "control_U2109",
        "control_U2105",
        "control_U2106"
      ],
      "role": "analog",
      "x": 40,
      "y": 70,
      "w": 410,
      "h": 210,
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2100",
          "control_U2103",
          "control_U2104",
          "control_U2109",
          "control_U2105",
          "control_U2106"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_U2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2104",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2109",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Ограничение напряжения и тока записи",
      "sourceSheetName": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceFile": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch",
      "layoutRole": "primary"
    }
  ],
  "edges": [],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 490,
    "h": 285
  },
  "board": "control",
  "sheetIds": [
    "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U2100",
      "control_U2103",
      "control_U2104",
      "control_U2109",
      "control_U2105",
      "control_U2106"
    ],
    "sheetIds": [
      "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
    ],
    "units": [
      {
        "component": "control_U2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2104",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2109",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-regulation"
  ],
  "suggestedScenario": "local-control-regulation",
  "explanationTitleRu": "Регулирование напряжения и тока записи",
  "sourceSheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "sourceSheetName": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "sourceFile": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": true,
  "parentScene": "control_PROTECTION",
  "layout": {
    "version": 2,
    "kind": "functional-islands",
    "label": "Функциональные группы; электрические связи не добавлены",
    "geometryOnly": true
  },
  "regions": []
};
