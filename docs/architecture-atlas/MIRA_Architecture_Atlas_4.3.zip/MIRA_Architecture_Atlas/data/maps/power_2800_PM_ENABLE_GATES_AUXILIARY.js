/* Editable functional scene: power_2800_PM_ENABLE_GATES_AUXILIARY */
window.MIRA_FUNCTIONAL.scenes["power_2800_PM_ENABLE_GATES_AUXILIARY"]={
  "id": "power_2800_PM_ENABLE_GATES_AUXILIARY",
  "title": "2800_PM_ENABLE_GATES_AUXILIARY",
  "subtitle": "Разрешения вспомогательных преобразователей",
  "description": "U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением.",
  "nodes": [
    {
      "id": "first",
      "title": "Первая группа разрешений",
      "subtitle": "",
      "description": "Каждый логический элемент объединяет запрос включения с соответствующим аппаратным разрешением.",
      "refs": [
        "power_U2801"
      ],
      "role": "control",
      "x": 40,
      "y": 70,
      "w": 350,
      "h": 184,
      "sheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "sourceSheetIds": [
        "power_2800_PM_ENABLE_GATES_AUXILIARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2801"
        ],
        "sheetIds": [
          "power_2800_PM_ENABLE_GATES_AUXILIARY"
        ],
        "units": [
          {
            "component": "power_U2801",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "second",
      "title": "Вторая группа разрешений",
      "subtitle": "",
      "description": "Остальные логические элементы независимо проверяют запросы своих преобразователей.",
      "refs": [
        "power_U2802"
      ],
      "role": "control",
      "x": 670,
      "y": 70,
      "w": 350,
      "h": 184,
      "sheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "sourceSheetIds": [
        "power_2800_PM_ENABLE_GATES_AUXILIARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2802"
        ],
        "sheetIds": [
          "power_2800_PM_ENABLE_GATES_AUXILIARY"
        ],
        "units": [
          {
            "component": "power_U2802",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "default",
      "title": "Выключение по умолчанию",
      "subtitle": "",
      "description": "Подтягивающие резисторы задают определённые начальные состояния команд.",
      "refs": [
        "power_R2804",
        "power_R2803",
        "power_R2808",
        "power_R2805",
        "power_R2806",
        "power_R2812",
        "power_R2813",
        "power_R2802",
        "power_R2814",
        "power_R2801",
        "power_R2807",
        "power_R2810",
        "power_R2809",
        "power_R2811",
        "power_C2802",
        "power_C2801"
      ],
      "role": "fault",
      "x": 395,
      "y": 510,
      "w": 250,
      "h": 132,
      "sheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
      "sourceSheetIds": [
        "power_2800_PM_ENABLE_GATES_AUXILIARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_R2804",
          "power_R2803",
          "power_R2808",
          "power_R2805",
          "power_R2806",
          "power_R2812",
          "power_R2813",
          "power_R2802",
          "power_R2814",
          "power_R2801",
          "power_R2807",
          "power_R2810",
          "power_R2809",
          "power_R2811",
          "power_C2802",
          "power_C2801"
        ],
        "sheetIds": [
          "power_2800_PM_ENABLE_GATES_AUXILIARY"
        ],
        "units": [
          {
            "component": "power_C2801",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_C2802",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2801",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2802",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2803",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2804",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2805",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2806",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2807",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2808",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2809",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2810",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2811",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2812",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2813",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          },
          {
            "component": "power_R2814",
            "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "first_second",
      "from": "first",
      "to": "second",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_8828c890966d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "GLOBAL_PWR_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "GLOBAL_PWR_PERMIT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "first_default",
      "from": "first",
      "to": "default",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_d1fe7a20e661",
        "power_net_1b4ac01010f8",
        "power_net_5dc0cb853f29",
        "power_net_69d4e38b1bd0",
        "power_net_05ab23d96f3d",
        "power_net_0faf4b6ebbf5",
        "power_net_04b2f0a4c78b",
        "power_net_d07b46e16a3e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "EN_REQ_AUX25",
        "EN_REQ_IO33",
        "EN_REQ_DDR",
        "EN_REQ_PHY",
        "CMD_PHY",
        "CMD_AUX25",
        "CMD_IO33",
        "CMD_DDR"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_AUX25 · CMD_DDR",
        "CMD_IO33 · CMD_PHY",
        "EN_REQ_AUX25 · EN_REQ_DDR",
        "EN_REQ_IO33 · EN_REQ_PHY"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "second_default",
      "from": "second",
      "to": "default",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_2c93a597633f",
        "power_net_12bae3231aaa",
        "power_net_b527a6b82695",
        "power_net_ae048a8edaa8",
        "power_net_664171b20ecf",
        "power_net_55bbd3deed41"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "EN_REQ_VTT",
        "EN_REQ_ANA5",
        "EN_REQ_ANA33",
        "CMD_VTT",
        "CMD_ANA5",
        "CMD_ANA33"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA33 · CMD_ANA5",
        "CMD_VTT · EN_REQ_ANA33",
        "EN_REQ_ANA5 · EN_REQ_VTT"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 1060,
    "h": 647
  },
  "board": "power",
  "sheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 18,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2801",
      "power_U2802",
      "power_R2804",
      "power_R2803",
      "power_R2808",
      "power_R2805",
      "power_R2806",
      "power_R2812",
      "power_R2813",
      "power_R2802",
      "power_R2814",
      "power_R2801",
      "power_R2807",
      "power_R2810",
      "power_R2809",
      "power_R2811",
      "power_C2802",
      "power_C2801"
    ],
    "sheetIds": [
      "power_2800_PM_ENABLE_GATES_AUXILIARY"
    ],
    "units": [
      {
        "component": "power_U2801",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_U2802",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_C2801",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_C2802",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2801",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2802",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2803",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2804",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2805",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2806",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2807",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2808",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2809",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2810",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2811",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2812",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2813",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      },
      {
        "component": "power_R2814",
        "sheet": "power_2800_PM_ENABLE_GATES_AUXILIARY",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2800_PM_ENABLE_GATES_AUXILIARY"
  ],
  "suggestedScenario": "local-power_2800_PM_ENABLE_GATES_AUXILIARY",
  "explanationTitleRu": "Разрешения вспомогательных преобразователей",
  "sourceSheetId": "power_2800_PM_ENABLE_GATES_AUXILIARY",
  "sourceSheetName": "2800_PM_ENABLE_GATES_AUXILIARY",
  "sourceFile": "2800_PM_ENABLE_GATES_AUXILIARY.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "enable-banks-with-default",
    "label": "Две группы разрешений; начальные состояния сбоку от основного пути",
    "geometryOnly": true
  },
  "regions": []
};
