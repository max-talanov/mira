/* Editable functional scene: power_200_INPUT_FUSE_PROTECTION */
window.MIRA_FUNCTIONAL.scenes["power_200_INPUT_FUSE_PROTECTION"]={
  "id": "power_200_INPUT_FUSE_PROTECTION",
  "title": "200_INPUT_FUSE_PROTECTION",
  "subtitle": "Предохранитель и индикация",
  "description": "F201 защищает входную ветвь. D204 показывает напряжение после предохранителя; Q201 управляет красной индикацией его обрыва.",
  "nodes": [
    {
      "id": "fuse",
      "title": "Отключение тяжёлой аварии",
      "subtitle": "",
      "description": "Сменный предохранитель включён последовательно во входное питание.",
      "refs": [
        "power_F201"
      ],
      "role": "power",
      "x": 40,
      "y": 240,
      "w": 360,
      "h": 190,
      "sheetId": "power_200_INPUT_FUSE_PROTECTION",
      "sourceSheetIds": [
        "power_200_INPUT_FUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_F201"
        ],
        "sheetIds": [
          "power_200_INPUT_FUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_F201",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "transient",
      "title": "Ограничение импульса напряжения",
      "subtitle": "",
      "description": "TVS ограничивает кратковременные выбросы напряжения на защищённом входе.",
      "refs": [
        "power_D205"
      ],
      "role": "fault",
      "x": 640,
      "y": 50,
      "w": 270,
      "h": 145,
      "sheetId": "power_200_INPUT_FUSE_PROTECTION",
      "sourceSheetIds": [
        "power_200_INPUT_FUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_D205"
        ],
        "sheetIds": [
          "power_200_INPUT_FUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_D205",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "indicate",
      "title": "Индикация предохранителя и входа",
      "subtitle": "",
      "description": "Диоды и транзистор управляют локальной индикацией питания.",
      "refs": [
        "power_D201",
        "power_D202",
        "power_D203",
        "power_D204",
        "power_Q201",
        "power_R204",
        "power_R201",
        "power_R203",
        "power_R202"
      ],
      "role": "control",
      "x": 640,
      "y": 480,
      "w": 245,
      "h": 128,
      "sheetId": "power_200_INPUT_FUSE_PROTECTION",
      "sourceSheetIds": [
        "power_200_INPUT_FUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_D201",
          "power_D202",
          "power_D203",
          "power_D204",
          "power_Q201",
          "power_R204",
          "power_R201",
          "power_R203",
          "power_R202"
        ],
        "sheetIds": [
          "power_200_INPUT_FUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_D201",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_D202",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_D203",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_D204",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_Q201",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R201",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R202",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R203",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R204",
            "sheet": "power_200_INPUT_FUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "fuse_transient",
      "from": "fuse",
      "to": "transient",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_e5a2750417c1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "+24V_FUSED"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "+24V_FUSED"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fuse_indicate",
      "from": "fuse",
      "to": "indicate",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_6741c8732f40",
        "power_net_e5a2750417c1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "+24V_RAW",
        "+24V_FUSED"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "+24V_RAW",
        "+24V_FUSED"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "transient_indicate",
      "from": "transient",
      "to": "indicate",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_e5a2750417c1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "+24V_FUSED"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "+24V_FUSED"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 15,
    "w": 950,
    "h": 633
  },
  "board": "power",
  "sheetId": "power_200_INPUT_FUSE_PROTECTION",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 11,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_F201",
      "power_D205",
      "power_D201",
      "power_D202",
      "power_D203",
      "power_D204",
      "power_Q201",
      "power_R204",
      "power_R201",
      "power_R203",
      "power_R202"
    ],
    "sheetIds": [
      "power_200_INPUT_FUSE_PROTECTION"
    ],
    "units": [
      {
        "component": "power_F201",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D205",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D201",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D202",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D203",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D204",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_Q201",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R201",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R202",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R203",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R204",
        "sheet": "power_200_INPUT_FUSE_PROTECTION",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_200_INPUT_FUSE_PROTECTION"
  ],
  "suggestedScenario": "local-power_200_INPUT_FUSE_PROTECTION",
  "explanationTitleRu": "Предохранитель и индикация",
  "sourceSheetId": "power_200_INPUT_FUSE_PROTECTION",
  "sourceSheetName": "200_INPUT_FUSE_PROTECTION",
  "sourceFile": "200_INPUT_FUSE_PROTECTION.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-input",
  "layout": {
    "version": 2,
    "kind": "fuse-with-side-protection",
    "label": "Предохранитель в основном пути, TVS и индикация сбоку",
    "geometryOnly": true
  },
  "regions": []
};
