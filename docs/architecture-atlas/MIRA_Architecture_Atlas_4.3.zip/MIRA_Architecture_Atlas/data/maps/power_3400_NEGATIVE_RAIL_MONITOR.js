/* Editable functional scene: power_3400_NEGATIVE_RAIL_MONITOR */
window.MIRA_FUNCTIONAL.scenes["power_3400_NEGATIVE_RAIL_MONITOR"]={
  "id": "power_3400_NEGATIVE_RAIL_MONITOR",
  "title": "3400_NEGATIVE_RAIL_MONITOR",
  "subtitle": "Измерение отрицательной шины",
  "description": "U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току.",
  "nodes": [
    {
      "id": "sense",
      "title": "Преобразование отрицательных измерений",
      "subtitle": "",
      "description": "Сдвоенный усилитель преобразует сигналы отрицательной шины в контрольные сигналы относительно общего провода.",
      "refs": [
        "power_U3401",
        "power_R3405",
        "power_C3402",
        "power_C3401",
        "power_R3406",
        "power_R3403",
        "power_R3401",
        "power_R3404",
        "power_R3409",
        "power_R3402"
      ],
      "role": "analog",
      "x": 40,
      "y": 180,
      "w": 350,
      "h": 184,
      "sheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "sourceSheetIds": [
        "power_3400_NEGATIVE_RAIL_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3401",
          "power_R3405",
          "power_C3402",
          "power_C3401",
          "power_R3406",
          "power_R3403",
          "power_R3401",
          "power_R3404",
          "power_R3409",
          "power_R3402"
        ],
        "sheetIds": [
          "power_3400_NEGATIVE_RAIL_MONITOR"
        ],
        "units": [
          {
            "component": "power_C3401",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C3402",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3401",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3402",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3403",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3404",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3405",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3406",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3409",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_U3401",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "clamp",
      "title": "Защита входов измерения",
      "subtitle": "",
      "description": "Ограничители и фильтры защищают измерительные выходы перед передачей в систему контроля.",
      "refs": [
        "power_D3401",
        "power_D3402",
        "power_D3403",
        "power_R3408",
        "power_R3407",
        "power_C3403",
        "power_C3404"
      ],
      "role": "fault",
      "x": 760,
      "y": 195,
      "w": 260,
      "h": 140,
      "sheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
      "sourceSheetIds": [
        "power_3400_NEGATIVE_RAIL_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_D3401",
          "power_D3402",
          "power_D3403",
          "power_R3408",
          "power_R3407",
          "power_C3403",
          "power_C3404"
        ],
        "sheetIds": [
          "power_3400_NEGATIVE_RAIL_MONITOR"
        ],
        "units": [
          {
            "component": "power_C3403",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C3404",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_D3401",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_D3402",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_D3403",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3407",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R3408",
            "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "sense_clamp",
      "from": "sense",
      "to": "clamp",
      "label": "Измерения напряжения",
      "type": "analog",
      "nets": [
        "power_net_de6034a2bdb7",
        "power_net_28c7570b1cac"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Напряжение",
      "netLabels": [
        "MON_V_N15"
      ],
      "unnamedNetIds": [
        "power_net_28c7570b1cac"
      ],
      "labelLines": [
        "MON_V_N15"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1060,
    "h": 259
  },
  "board": "power",
  "sheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 17,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3401",
      "power_R3405",
      "power_C3402",
      "power_C3401",
      "power_R3406",
      "power_R3403",
      "power_R3401",
      "power_R3404",
      "power_R3409",
      "power_R3402",
      "power_D3401",
      "power_D3402",
      "power_D3403",
      "power_R3408",
      "power_R3407",
      "power_C3403",
      "power_C3404"
    ],
    "sheetIds": [
      "power_3400_NEGATIVE_RAIL_MONITOR"
    ],
    "units": [
      {
        "component": "power_C3401",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C3402",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3401",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3402",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3403",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3404",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3405",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3406",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3409",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_U3401",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C3403",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C3404",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_D3401",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_D3402",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_D3403",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3407",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R3408",
        "sheet": "power_3400_NEGATIVE_RAIL_MONITOR",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3400_NEGATIVE_RAIL_MONITOR"
  ],
  "suggestedScenario": "local-power_3400_NEGATIVE_RAIL_MONITOR",
  "explanationTitleRu": "Измерение отрицательной шины",
  "sourceSheetId": "power_3400_NEGATIVE_RAIL_MONITOR",
  "sourceSheetName": "3400_NEGATIVE_RAIL_MONITOR",
  "sourceFile": "3400_NEGATIVE_RAIL_MONITOR.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-monitoring",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
