/* Editable functional scene: power_2500_PM_WATCHDOGS */
window.MIRA_FUNCTIONAL.scenes["power_2500_PM_WATCHDOGS"]={
  "id": "power_2500_PM_WATCHDOGS",
  "title": "2500_PM_WATCHDOGS",
  "subtitle": "Сторожевой контроль контроллеров",
  "description": "U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера.",
  "nodes": [
    {
      "id": "pm",
      "title": "Контроль контроллера питания",
      "subtitle": "",
      "description": "Сторожевой таймер контролирует импульсы работоспособности и сброс контроллера питания.",
      "refs": [
        "power_U2501",
        "power_J2501",
        "power_C2501",
        "power_R2504",
        "power_R2503",
        "power_R2502",
        "power_R2501"
      ],
      "role": "fault",
      "x": 40,
      "y": 70,
      "w": 350,
      "h": 184,
      "sheetId": "power_2500_PM_WATCHDOGS",
      "sourceSheetIds": [
        "power_2500_PM_WATCHDOGS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2501",
          "power_J2501",
          "power_C2501",
          "power_R2504",
          "power_R2503",
          "power_R2502",
          "power_R2501"
        ],
        "sheetIds": [
          "power_2500_PM_WATCHDOGS"
        ],
        "units": [
          {
            "component": "power_C2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_J2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2503",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2504",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_U2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "host",
      "title": "Контроль основного контроллера",
      "subtitle": "",
      "description": "Отдельный сторожевой таймер контролирует импульсы работоспособности и сброс основного контроллера.",
      "refs": [
        "power_U2502",
        "power_J2502",
        "power_R2507",
        "power_R2506",
        "power_R2509",
        "power_R2508",
        "power_C2503"
      ],
      "role": "fault",
      "x": 650,
      "y": 70,
      "w": 350,
      "h": 184,
      "sheetId": "power_2500_PM_WATCHDOGS",
      "sourceSheetIds": [
        "power_2500_PM_WATCHDOGS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2502",
          "power_J2502",
          "power_R2507",
          "power_R2506",
          "power_R2509",
          "power_R2508",
          "power_C2503"
        ],
        "sheetIds": [
          "power_2500_PM_WATCHDOGS"
        ],
        "units": [
          {
            "component": "power_C2503",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_J2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2506",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2507",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2508",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2509",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_U2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "reset",
      "title": "Объединение запросов сброса",
      "subtitle": "",
      "description": "Диодная сеть и цепи смещения объединяют запросы сброса согласно схеме.",
      "refs": [
        "power_D2501",
        "power_R2505",
        "power_C2502"
      ],
      "role": "fault",
      "x": 380,
      "y": 500,
      "w": 250,
      "h": 130,
      "sheetId": "power_2500_PM_WATCHDOGS",
      "sourceSheetIds": [
        "power_2500_PM_WATCHDOGS"
      ],
      "circuitGroup": {
        "refs": [
          "power_D2501",
          "power_R2505",
          "power_C2502"
        ],
        "sheetIds": [
          "power_2500_PM_WATCHDOGS"
        ],
        "units": [
          {
            "component": "power_C2502",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_D2501",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          },
          {
            "component": "power_R2505",
            "sheet": "power_2500_PM_WATCHDOGS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "pm_reset",
      "from": "pm",
      "to": "reset",
      "label": "2 цепи",
      "type": "control",
      "nets": [
        "power_net_b4c478ffb022",
        "power_net_47577a24d67e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "AON_RESET_N",
        "PM_WDO_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AON_RESET_N",
        "PM_WDO_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 1040,
    "h": 635
  },
  "board": "power",
  "sheetId": "power_2500_PM_WATCHDOGS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 17,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2501",
      "power_J2501",
      "power_C2501",
      "power_R2504",
      "power_R2503",
      "power_R2502",
      "power_R2501",
      "power_U2502",
      "power_J2502",
      "power_R2507",
      "power_R2506",
      "power_R2509",
      "power_R2508",
      "power_C2503",
      "power_D2501",
      "power_R2505",
      "power_C2502"
    ],
    "sheetIds": [
      "power_2500_PM_WATCHDOGS"
    ],
    "units": [
      {
        "component": "power_C2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_J2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2503",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2504",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_U2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_C2503",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_J2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2506",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2507",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2508",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2509",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_U2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_C2502",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_D2501",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      },
      {
        "component": "power_R2505",
        "sheet": "power_2500_PM_WATCHDOGS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2500_PM_WATCHDOGS"
  ],
  "suggestedScenario": "local-power_2500_PM_WATCHDOGS",
  "explanationTitleRu": "Сторожевой контроль контроллеров",
  "sourceSheetId": "power_2500_PM_WATCHDOGS",
  "sourceSheetName": "2500_PM_WATCHDOGS",
  "sourceFile": "2500_PM_WATCHDOGS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "parallel-watchdogs",
    "label": "Два независимых сторожевых канала и общая функция сброса",
    "geometryOnly": true
  },
  "regions": []
};
