/* Editable functional scene: control_1400_MATRIX_SERIAL_CONTROL_REGISTERS */
window.MIRA_FUNCTIONAL.scenes["control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"]={
  "id": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "title": "1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "subtitle": "80-битное состояние ключей",
  "description": "U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий.",
  "nodes": [
    {
      "id": "first",
      "title": "Загрузка битов 0–31",
      "subtitle": "",
      "description": "Первая группа сдвиговых регистров принимает начальную часть 80-битного состояния ключей.",
      "refs": [
        "control_U1400",
        "control_U1401",
        "control_U1402",
        "control_U1403",
        "control_C1403",
        "control_R1407",
        "control_R1415",
        "control_R1403",
        "control_C1400",
        "control_C1402",
        "control_R1411",
        "control_C1401"
      ],
      "role": "control",
      "x": 40,
      "y": 140,
      "w": 290,
      "h": 150,
      "sheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sourceSheetIds": [
        "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1400",
          "control_U1401",
          "control_U1402",
          "control_U1403",
          "control_C1403",
          "control_R1407",
          "control_R1415",
          "control_R1403",
          "control_C1400",
          "control_C1402",
          "control_R1411",
          "control_C1401"
        ],
        "sheetIds": [
          "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
        ],
        "units": [
          {
            "component": "control_C1400",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1401",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1402",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1403",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1403",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1407",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1411",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1415",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1400",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1401",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1402",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1403",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "second",
      "title": "Загрузка битов 32–63",
      "subtitle": "",
      "description": "Последовательная цепочка продолжается через следующие четыре регистра.",
      "refs": [
        "control_U1404",
        "control_U1405",
        "control_U1406",
        "control_U1407",
        "control_C1404",
        "control_R1400",
        "control_C1406",
        "control_R1412",
        "control_R1402",
        "control_R1401",
        "control_R1404",
        "control_R1406",
        "control_R1414",
        "control_C1407",
        "control_R1410",
        "control_C1405",
        "control_R1409",
        "control_R1405",
        "control_R1408",
        "control_R1413"
      ],
      "role": "control",
      "x": 600,
      "y": 125,
      "w": 350,
      "h": 184,
      "sheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sourceSheetIds": [
        "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1404",
          "control_U1405",
          "control_U1406",
          "control_U1407",
          "control_C1404",
          "control_R1400",
          "control_C1406",
          "control_R1412",
          "control_R1402",
          "control_R1401",
          "control_R1404",
          "control_R1406",
          "control_R1414",
          "control_C1407",
          "control_R1410",
          "control_C1405",
          "control_R1409",
          "control_R1405",
          "control_R1408",
          "control_R1413"
        ],
        "sheetIds": [
          "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
        ],
        "units": [
          {
            "component": "control_C1404",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1405",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1406",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1407",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1400",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1401",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1402",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1404",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1405",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1406",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1408",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1409",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1410",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1412",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1413",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_R1414",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1404",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1405",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1406",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1407",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "last",
      "title": "Загрузка битов 64–79",
      "subtitle": "",
      "description": "Последние регистры завершают образ; сигнал фиксации переносит состояние на выходы.",
      "refs": [
        "control_U1408",
        "control_U1409",
        "control_C1408",
        "control_C1409"
      ],
      "role": "control",
      "x": 1200,
      "y": 140,
      "w": 300,
      "h": 156,
      "sheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
      "sourceSheetIds": [
        "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1408",
          "control_U1409",
          "control_C1408",
          "control_C1409"
        ],
        "sheetIds": [
          "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
        ],
        "units": [
          {
            "component": "control_C1408",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_C1409",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1408",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          },
          {
            "component": "control_U1409",
            "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "first_second",
      "from": "first",
      "to": "second",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_5c0da047cc8c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "MAT_CONFIG_LATCH",
        "MAT_ALLOWED",
        "MAT_SPI_SCK",
        "MAT_CHAIN_3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ALLOWED",
        "MAT_CHAIN_3",
        "MAT_CONFIG_LATCH",
        "MAT_SPI_SCK"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "first_last",
      "from": "first",
      "to": "last",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "MAT_CONFIG_LATCH",
        "MAT_ALLOWED",
        "MAT_SPI_SCK"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ALLOWED",
        "MAT_CONFIG_LATCH",
        "MAT_SPI_SCK"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "second_last",
      "from": "second",
      "to": "last",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_c73ef0628409",
        "control_net_2e40141f478d",
        "control_net_d0ee9c0888fb",
        "control_net_770516324e4c",
        "control_net_9f906a4c978b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "MAT_OE_N",
        "MAT_CONFIG_LATCH",
        "MAT_ALLOWED",
        "MAT_SPI_SCK",
        "MAT_CHAIN_7"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ALLOWED",
        "MAT_CHAIN_7",
        "MAT_CONFIG_LATCH",
        "MAT_OE_N",
        "MAT_SPI_SCK"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 90,
    "w": 1540,
    "h": 259
  },
  "board": "control",
  "sheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 36,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1400",
      "control_U1401",
      "control_U1402",
      "control_U1403",
      "control_C1403",
      "control_R1407",
      "control_R1415",
      "control_R1403",
      "control_C1400",
      "control_C1402",
      "control_R1411",
      "control_C1401",
      "control_U1404",
      "control_U1405",
      "control_U1406",
      "control_U1407",
      "control_C1404",
      "control_R1400",
      "control_C1406",
      "control_R1412",
      "control_R1402",
      "control_R1401",
      "control_R1404",
      "control_R1406",
      "control_R1414",
      "control_C1407",
      "control_R1410",
      "control_C1405",
      "control_R1409",
      "control_R1405",
      "control_R1408",
      "control_R1413",
      "control_U1408",
      "control_U1409",
      "control_C1408",
      "control_C1409"
    ],
    "sheetIds": [
      "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
    ],
    "units": [
      {
        "component": "control_C1400",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1401",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1402",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1403",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1403",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1407",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1411",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1415",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1400",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1401",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1402",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1403",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1404",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1405",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1406",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1407",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1400",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1401",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1402",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1404",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1405",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1406",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1408",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1409",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1410",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1412",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1413",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_R1414",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1404",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1405",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1406",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1407",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1408",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_C1409",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1408",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      },
      {
        "component": "control_U1409",
        "sheet": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1400_MATRIX_SERIAL_CONTROL_REGISTERS"
  ],
  "suggestedScenario": "local-control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "explanationTitleRu": "80-битное состояние ключей",
  "sourceSheetId": "control_1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "sourceSheetName": "1400_MATRIX_SERIAL_CONTROL_REGISTERS",
  "sourceFile": "1400_MATRIX_SERIAL_CONTROL_REGISTERS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-routing",
  "layout": {
    "version": 2,
    "kind": "serial-chain",
    "label": "Последовательная загрузка 80-битного образа",
    "geometryOnly": true
  },
  "regions": []
};
