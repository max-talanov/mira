/* Editable functional scene: control_1000_DAC_BL0_31_AND_BUFFERS */
window.MIRA_FUNCTIONAL.scenes["control_1000_DAC_BL0_31_AND_BUFFERS"]={
  "id": "control_1000_DAC_BL0_31_AND_BUFFERS",
  "title": "1000_DAC_BL0_31_AND_BUFFERS",
  "subtitle": "32 напряжения битовых линий",
  "description": "Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы.",
  "nodes": [
    {
      "id": "dac0",
      "title": "Уставки BL0–7",
      "subtitle": "",
      "description": "Восьмиканальный ЦАП задаёт напряжения этой группы битовых линий.",
      "refs": [
        "control_U1000",
        "control_C1002",
        "control_C1001",
        "control_C1006",
        "control_C1005",
        "control_C1004",
        "control_R1000",
        "control_C1003",
        "control_R1001",
        "control_C1000",
        "control_R1002"
      ],
      "role": "analog",
      "x": 40,
      "y": 80,
      "w": 290,
      "h": 145,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1000",
          "control_C1002",
          "control_C1001",
          "control_C1006",
          "control_C1005",
          "control_C1004",
          "control_R1000",
          "control_C1003",
          "control_R1001",
          "control_C1000",
          "control_R1002"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1000",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1003",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1006",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1000",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1000",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "dac1",
      "title": "Уставки BL8–15",
      "subtitle": "",
      "description": "Восьмиканальный ЦАП задаёт напряжения этой группы битовых линий.",
      "refs": [
        "control_U1003",
        "control_C1019",
        "control_C1016",
        "control_C1015",
        "control_R1012",
        "control_C1014",
        "control_R1011",
        "control_R1013",
        "control_C1018",
        "control_C1013",
        "control_C1017"
      ],
      "role": "analog",
      "x": 480,
      "y": 80,
      "w": 290,
      "h": 145,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1003",
          "control_C1019",
          "control_C1016",
          "control_C1015",
          "control_R1012",
          "control_C1014",
          "control_R1011",
          "control_R1013",
          "control_C1018",
          "control_C1013",
          "control_C1017"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1013",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1014",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1015",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1016",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1017",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1018",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1019",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1012",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1013",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1003",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "dac2",
      "title": "Уставки BL16–23",
      "subtitle": "",
      "description": "Восьмиканальный ЦАП задаёт напряжения этой группы битовых линий.",
      "refs": [
        "control_U1006",
        "control_C1030",
        "control_C1027",
        "control_C1026",
        "control_R1024",
        "control_C1029",
        "control_C1031",
        "control_C1032",
        "control_R1022",
        "control_C1028",
        "control_R1023"
      ],
      "role": "analog",
      "x": 920,
      "y": 80,
      "w": 290,
      "h": 145,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1006",
          "control_C1030",
          "control_C1027",
          "control_C1026",
          "control_R1024",
          "control_C1029",
          "control_C1031",
          "control_C1032",
          "control_R1022",
          "control_C1028",
          "control_R1023"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1026",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1027",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1028",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1029",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1030",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1031",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1032",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1022",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1023",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1024",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1006",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "buffer0",
      "title": "Буферы BL0–7",
      "subtitle": "",
      "description": "Прецизионные повторители буферизуют выходы ЦАП перед коммутацией матрицы.",
      "refs": [
        "control_U1001",
        "control_U1002",
        "control_C1011",
        "control_R1004",
        "control_R1009",
        "control_C1007",
        "control_R1010",
        "control_C1012",
        "control_C1008",
        "control_R1007",
        "control_C1010",
        "control_C1009",
        "control_R1008",
        "control_R1006",
        "control_R1005",
        "control_R1003"
      ],
      "role": "analog",
      "x": 40,
      "y": 510,
      "w": 290,
      "h": 155,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1001",
          "control_U1002",
          "control_C1011",
          "control_R1004",
          "control_R1009",
          "control_C1007",
          "control_R1010",
          "control_C1012",
          "control_C1008",
          "control_R1007",
          "control_C1010",
          "control_C1009",
          "control_R1008",
          "control_R1006",
          "control_R1005",
          "control_R1003"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1009",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1012",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1003",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1006",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1009",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "buffer1",
      "title": "Буферы BL8–15",
      "subtitle": "",
      "description": "Прецизионные повторители буферизуют выходы ЦАП перед коммутацией матрицы.",
      "refs": [
        "control_U1004",
        "control_U1005",
        "control_C1024",
        "control_C1022",
        "control_R1021",
        "control_R1015",
        "control_R1014",
        "control_R1019",
        "control_R1017",
        "control_C1023",
        "control_C1021",
        "control_R1018",
        "control_R1020",
        "control_C1025",
        "control_R1016",
        "control_C1020"
      ],
      "role": "analog",
      "x": 480,
      "y": 510,
      "w": 290,
      "h": 155,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1004",
          "control_U1005",
          "control_C1024",
          "control_C1022",
          "control_R1021",
          "control_R1015",
          "control_R1014",
          "control_R1019",
          "control_R1017",
          "control_C1023",
          "control_C1021",
          "control_R1018",
          "control_R1020",
          "control_C1025",
          "control_R1016",
          "control_C1020"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1020",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1021",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1022",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1023",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1024",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1025",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1014",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1015",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1016",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1017",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1018",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1019",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1020",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1021",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "buffer2",
      "title": "Буферы BL16–23",
      "subtitle": "",
      "description": "Прецизионные повторители буферизуют выходы ЦАП перед коммутацией матрицы.",
      "refs": [
        "control_U1007",
        "control_U1008",
        "control_R1031",
        "control_R1032",
        "control_R1029",
        "control_C1035",
        "control_C1036",
        "control_C1034",
        "control_R1030",
        "control_C1038",
        "control_R1027",
        "control_C1037",
        "control_R1026",
        "control_R1028",
        "control_C1033",
        "control_R1025"
      ],
      "role": "analog",
      "x": 920,
      "y": 510,
      "w": 290,
      "h": 155,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1007",
          "control_U1008",
          "control_R1031",
          "control_R1032",
          "control_R1029",
          "control_C1035",
          "control_C1036",
          "control_C1034",
          "control_R1030",
          "control_C1038",
          "control_R1027",
          "control_C1037",
          "control_R1026",
          "control_R1028",
          "control_C1033",
          "control_R1025"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1033",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1034",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1035",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1036",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1037",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1038",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1025",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1026",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1027",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1028",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1029",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1030",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1031",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1032",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "dac3",
      "title": "Уставки BL24–31",
      "subtitle": "",
      "description": "Четвёртый ЦАП завершает набор из 32 независимо задаваемых напряжений.",
      "refs": [
        "control_U1009",
        "control_C1040",
        "control_R1033",
        "control_C1039",
        "control_C1043",
        "control_R1034",
        "control_C1044",
        "control_C1041",
        "control_C1045",
        "control_R1035",
        "control_C1042"
      ],
      "role": "analog",
      "x": 1360,
      "y": 80,
      "w": 290,
      "h": 145,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1009",
          "control_C1040",
          "control_R1033",
          "control_C1039",
          "control_C1043",
          "control_R1034",
          "control_C1044",
          "control_C1041",
          "control_C1045",
          "control_R1035",
          "control_C1042"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1039",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1040",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1041",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1042",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1043",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1044",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1045",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1033",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1034",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1035",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1009",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "buffer3",
      "title": "Буферы BL24–31",
      "subtitle": "",
      "description": "Прецизионные повторители буферизуют последние восемь выходов ЦАП.",
      "refs": [
        "control_U1010",
        "control_U1011",
        "control_R1038",
        "control_C1046",
        "control_R1042",
        "control_R1041",
        "control_R1039",
        "control_R1040",
        "control_R1036",
        "control_R1043",
        "control_C1049",
        "control_C1050",
        "control_C1047",
        "control_R1037",
        "control_C1048",
        "control_C1051"
      ],
      "role": "analog",
      "x": 1360,
      "y": 510,
      "w": 290,
      "h": 155,
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1010",
          "control_U1011",
          "control_R1038",
          "control_C1046",
          "control_R1042",
          "control_R1041",
          "control_R1039",
          "control_R1040",
          "control_R1036",
          "control_R1043",
          "control_C1049",
          "control_C1050",
          "control_C1047",
          "control_R1037",
          "control_C1048",
          "control_C1051"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_C1046",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1047",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1048",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1049",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1050",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_C1051",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1036",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1037",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1038",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1039",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1040",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1041",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1042",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_R1043",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "dac0_buffer0_0",
      "from": "dac0",
      "to": "buffer0",
      "label": "Восемь заданных напряжений",
      "type": "analog",
      "nets": [
        "control_net_47af455af6dc",
        "control_net_b90f47fe887d",
        "control_net_a0db919ee83d",
        "control_net_d6647a4628c8",
        "control_net_8be92a53ce8b",
        "control_net_78ba9d6b88dd",
        "control_net_e1f6195edd21",
        "control_net_561ae5f25bce"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "8 напряжений",
      "netLabels": [
        "BL_DAC_RAW1",
        "BL_DAC_RAW6",
        "BL_DAC_RAW3",
        "BL_DAC_RAW4",
        "BL_DAC_RAW5",
        "BL_DAC_RAW2",
        "BL_DAC_RAW7",
        "BL_DAC_RAW0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL_DAC_RAW0 · BL_DAC_RAW1",
        "BL_DAC_RAW2 · BL_DAC_RAW3",
        "BL_DAC_RAW4 · BL_DAC_RAW5",
        "BL_DAC_RAW6 · BL_DAC_RAW7"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "dac1_buffer1_1",
      "from": "dac1",
      "to": "buffer1",
      "label": "Восемь заданных напряжений",
      "type": "analog",
      "nets": [
        "control_net_45414159a6d3",
        "control_net_be4660552802",
        "control_net_bbe57577edac",
        "control_net_4ff0e756cbd5",
        "control_net_3604545d058f",
        "control_net_781dd31d2aeb",
        "control_net_1de6960dfbf7",
        "control_net_2efabf58bf8f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "8 напряжений",
      "netLabels": [
        "BL_DAC_RAW14",
        "BL_DAC_RAW15",
        "BL_DAC_RAW11",
        "BL_DAC_RAW8",
        "BL_DAC_RAW13",
        "BL_DAC_RAW9",
        "BL_DAC_RAW12",
        "BL_DAC_RAW10"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL_DAC_RAW10 · BL_DAC_RAW11",
        "BL_DAC_RAW12 · BL_DAC_RAW13",
        "BL_DAC_RAW14 · BL_DAC_RAW15",
        "BL_DAC_RAW8 · BL_DAC_RAW9"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "dac2_buffer2_2",
      "from": "dac2",
      "to": "buffer2",
      "label": "Восемь заданных напряжений",
      "type": "analog",
      "nets": [
        "control_net_ceb3c2b7a415",
        "control_net_6629c66bc5c3",
        "control_net_b382ee5d9c95",
        "control_net_fb6a011f184f",
        "control_net_f636a6adf1a1",
        "control_net_6954c1b0f1fe",
        "control_net_5cc4301e4849",
        "control_net_d29f038dfa81"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "8 напряжений",
      "netLabels": [
        "BL_DAC_RAW20",
        "BL_DAC_RAW16",
        "BL_DAC_RAW17",
        "BL_DAC_RAW23",
        "BL_DAC_RAW22",
        "BL_DAC_RAW21",
        "BL_DAC_RAW19",
        "BL_DAC_RAW18"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL_DAC_RAW16 · BL_DAC_RAW17",
        "BL_DAC_RAW18 · BL_DAC_RAW19",
        "BL_DAC_RAW20 · BL_DAC_RAW21",
        "BL_DAC_RAW22 · BL_DAC_RAW23"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "dac3_buffer3_3",
      "from": "dac3",
      "to": "buffer3",
      "label": "Восемь заданных напряжений",
      "type": "analog",
      "nets": [
        "control_net_8f0753af8e50",
        "control_net_6f08013fa83c",
        "control_net_d7416d0b6780",
        "control_net_100f8cbfb278",
        "control_net_392b5704c213",
        "control_net_8b109f39f0b2",
        "control_net_6c1729627b24",
        "control_net_65f84fe93731"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "8 напряжений",
      "netLabels": [
        "BL_DAC_RAW25",
        "BL_DAC_RAW24",
        "BL_DAC_RAW31",
        "BL_DAC_RAW30",
        "BL_DAC_RAW29",
        "BL_DAC_RAW28",
        "BL_DAC_RAW27",
        "BL_DAC_RAW26"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL_DAC_RAW24 · BL_DAC_RAW25",
        "BL_DAC_RAW26 · BL_DAC_RAW27",
        "BL_DAC_RAW28 · BL_DAC_RAW29",
        "BL_DAC_RAW30 · BL_DAC_RAW31"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": -28,
    "y": -9,
    "w": 1746,
    "h": 739
  },
  "board": "control",
  "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 108,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1000",
      "control_C1002",
      "control_C1001",
      "control_C1006",
      "control_C1005",
      "control_C1004",
      "control_R1000",
      "control_C1003",
      "control_R1001",
      "control_C1000",
      "control_R1002",
      "control_U1003",
      "control_C1019",
      "control_C1016",
      "control_C1015",
      "control_R1012",
      "control_C1014",
      "control_R1011",
      "control_R1013",
      "control_C1018",
      "control_C1013",
      "control_C1017",
      "control_U1006",
      "control_C1030",
      "control_C1027",
      "control_C1026",
      "control_R1024",
      "control_C1029",
      "control_C1031",
      "control_C1032",
      "control_R1022",
      "control_C1028",
      "control_R1023",
      "control_U1001",
      "control_U1002",
      "control_C1011",
      "control_R1004",
      "control_R1009",
      "control_C1007",
      "control_R1010",
      "control_C1012",
      "control_C1008",
      "control_R1007",
      "control_C1010",
      "control_C1009",
      "control_R1008",
      "control_R1006",
      "control_R1005",
      "control_R1003",
      "control_U1004",
      "control_U1005",
      "control_C1024",
      "control_C1022",
      "control_R1021",
      "control_R1015",
      "control_R1014",
      "control_R1019",
      "control_R1017",
      "control_C1023",
      "control_C1021",
      "control_R1018",
      "control_R1020",
      "control_C1025",
      "control_R1016",
      "control_C1020",
      "control_U1007",
      "control_U1008",
      "control_R1031",
      "control_R1032",
      "control_R1029",
      "control_C1035",
      "control_C1036",
      "control_C1034",
      "control_R1030",
      "control_C1038",
      "control_R1027",
      "control_C1037",
      "control_R1026",
      "control_R1028",
      "control_C1033",
      "control_R1025",
      "control_U1009",
      "control_C1040",
      "control_R1033",
      "control_C1039",
      "control_C1043",
      "control_R1034",
      "control_C1044",
      "control_C1041",
      "control_C1045",
      "control_R1035",
      "control_C1042",
      "control_U1010",
      "control_U1011",
      "control_R1038",
      "control_C1046",
      "control_R1042",
      "control_R1041",
      "control_R1039",
      "control_R1040",
      "control_R1036",
      "control_R1043",
      "control_C1049",
      "control_C1050",
      "control_C1047",
      "control_R1037",
      "control_C1048",
      "control_C1051"
    ],
    "sheetIds": [
      "control_1000_DAC_BL0_31_AND_BUFFERS"
    ],
    "units": [
      {
        "component": "control_C1000",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1003",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1006",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1000",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1000",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1013",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1014",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1015",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1016",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1017",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1018",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1019",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1012",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1013",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1003",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1026",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1027",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1028",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1029",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1030",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1031",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1032",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1022",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1023",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1024",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1006",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1009",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1012",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1003",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1006",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1009",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_C1020",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1021",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1022",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1023",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1024",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1025",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1014",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1015",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1016",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1017",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1018",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1019",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1020",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1021",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_C1033",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1034",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1035",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1036",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1037",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1038",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1025",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1026",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1027",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1028",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1029",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1030",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1031",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1032",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_C1039",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1040",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1041",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1042",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1043",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1044",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1045",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1033",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1034",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1035",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1009",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1046",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1047",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1048",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1049",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1050",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_C1051",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1036",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1037",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1038",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1039",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1040",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1041",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1042",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_R1043",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1000_DAC_BL0_31_AND_BUFFERS"
  ],
  "suggestedScenario": "local-control_1000_DAC_BL0_31_AND_BUFFERS",
  "explanationTitleRu": "32 напряжения битовых линий",
  "sourceSheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
  "sourceSheetName": "1000_DAC_BL0_31_AND_BUFFERS",
  "sourceFile": "1000_DAC_BL0_31_AND_BUFFERS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-sources",
  "layout": {
    "version": 2,
    "kind": "parallel-banks",
    "label": "Четыре одинаковых канала по восемь линий",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 26,
      "w": 1666,
      "h": 224,
      "title": "ЦАП · четыре банка",
      "kind": "control",
      "nodeIds": [
        "dac0",
        "dac1",
        "dac2",
        "dac3"
      ]
    },
    {
      "x": 12,
      "y": 456,
      "w": 1666,
      "h": 234,
      "title": "Буферы · выходы к матрице",
      "kind": "primary",
      "nodeIds": [
        "buffer0",
        "buffer1",
        "buffer2",
        "buffer3"
      ]
    }
  ]
};
