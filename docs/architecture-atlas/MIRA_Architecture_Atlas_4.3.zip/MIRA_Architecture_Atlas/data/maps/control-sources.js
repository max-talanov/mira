/* Editable functional scene: control-sources */
window.MIRA_FUNCTIONAL.scenes["control-sources"]={
  "id": "control-sources",
  "title": "DAC",
  "subtitle": "Формирование аналоговых уставок",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet1000",
      "title": "1000_DAC_BL0_31_AND_BUFFERS",
      "subtitle": "32 напряжения битовых линий",
      "description": "Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы.",
      "refs": [
        "control_U1005",
        "control_U1010",
        "control_U1009",
        "control_U1008",
        "control_U1001",
        "control_U1007"
      ],
      "role": "analog",
      "x": 40,
      "y": 70,
      "w": 360,
      "h": 180,
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1005",
          "control_U1010",
          "control_U1009",
          "control_U1008",
          "control_U1001",
          "control_U1007"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1009",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          }
        ]
      },
      "explanationTitleRu": "32 напряжения битовых линий",
      "sourceSheetName": "1000_DAC_BL0_31_AND_BUFFERS",
      "sourceSheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "sourceFile": "1000_DAC_BL0_31_AND_BUFFERS.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1100",
      "title": "1100_DAC_SERVICE_AND_FORMING",
      "subtitle": "Уставки READ, WRITE и FORMING",
      "description": "U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING.",
      "refs": [
        "control_U1102",
        "control_U1104",
        "control_U1100",
        "control_U1101",
        "control_U1103"
      ],
      "role": "analog",
      "x": 40,
      "y": 570,
      "w": 360,
      "h": 180,
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sourceSheetIds": [
        "control_1100_DAC_SERVICE_AND_FORMING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1102",
          "control_U1104",
          "control_U1100",
          "control_U1101",
          "control_U1103"
        ],
        "sheetIds": [
          "control_1100_DAC_SERVICE_AND_FORMING"
        ],
        "units": [
          {
            "component": "control_U1100",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 2
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 3
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 4
          },
          {
            "component": "control_U1101",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 5
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 2
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 3
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 4
          },
          {
            "component": "control_U1102",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 5
          },
          {
            "component": "control_U1103",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1104",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 1
          },
          {
            "component": "control_U1104",
            "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
            "unit": 2
          }
        ]
      },
      "explanationTitleRu": "Уставки READ, WRITE и FORMING",
      "sourceSheetName": "1100_DAC_SERVICE_AND_FORMING",
      "sourceSheetId": "control_1100_DAC_SERVICE_AND_FORMING",
      "sourceFile": "1100_DAC_SERVICE_AND_FORMING.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1200",
      "title": "1200_DAC_FPGA_CONTROL_INTERFACE",
      "subtitle": "Управление аналоговыми источниками",
      "description": "Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс.",
      "refs": [
        "control_U500"
      ],
      "role": "analog",
      "x": 850,
      "y": 300,
      "w": 410,
      "h": 210,
      "sceneId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "sheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "sourceSheetIds": [
        "control_1200_DAC_FPGA_CONTROL_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500"
        ],
        "sheetIds": [
          "control_1200_DAC_FPGA_CONTROL_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U500",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 7
          }
        ]
      },
      "explanationTitleRu": "Управление аналоговыми источниками",
      "sourceSheetName": "1200_DAC_FPGA_CONTROL_INTERFACE",
      "sourceSheetId": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "sourceFile": "1200_DAC_FPGA_CONTROL_INTERFACE.kicad_sch",
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "sheet1000_sheet1200",
      "from": "sheet1000",
      "to": "sheet1200",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_90accaec6322",
        "control_net_8543c7028353",
        "control_net_7f616706cf93",
        "control_net_fd8710ab620d",
        "control_net_a2017f4fe37b",
        "control_net_bae01a82acc2",
        "control_net_2889fbee2814",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "CS_BL0",
        "CS_BL3",
        "DAC_SPI_MOSI",
        "CS_BL2",
        "DAC_RESET_N",
        "CS_BL1",
        "DAC_SPI_MISO",
        "DAC_SPI_SCK",
        "DAC_LDAC_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CS_BL0 · CS_BL3",
        "DAC_SPI_MOSI · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1100_sheet1200",
      "from": "sheet1100",
      "to": "sheet1200",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_7f616706cf93",
        "control_net_a2017f4fe37b",
        "control_net_596ada6680f2",
        "control_net_fe5724fe2bab",
        "control_net_2889fbee2814",
        "control_net_168076ddc771",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc",
        "control_net_fad82bf41bcf"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "DAC_SPI_MOSI",
        "DAC_RESET_N",
        "CS_HV",
        "HV_ALERT_N",
        "DAC_SPI_MISO",
        "HV_CLEAR_N",
        "DAC_SPI_SCK",
        "DAC_LDAC_N",
        "CS_CTRL"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DAC_SPI_MOSI · DAC_RESET_N",
        "CS_HV · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sheet1000_sheet1100",
      "from": "sheet1000",
      "to": "sheet1100",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_7f616706cf93",
        "control_net_a2017f4fe37b",
        "control_net_2889fbee2814",
        "control_net_8baeadc9d1f8",
        "control_net_0d0a126b05bc"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "DAC_SPI_MOSI",
        "DAC_RESET_N",
        "DAC_SPI_MISO",
        "DAC_SPI_SCK",
        "DAC_LDAC_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DAC_LDAC_N · DAC_RESET_N",
        "DAC_SPI_MISO · DAC_SPI_MOSI",
        "DAC_SPI_SCK"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 1300,
    "h": 755
  },
  "board": "control",
  "sheetIds": [
    "control_1000_DAC_BL0_31_AND_BUFFERS",
    "control_1100_DAC_SERVICE_AND_FORMING",
    "control_1200_DAC_FPGA_CONTROL_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1005",
      "control_U1010",
      "control_U1009",
      "control_U1008",
      "control_U1001",
      "control_U1007",
      "control_U1102",
      "control_U1104",
      "control_U1100",
      "control_U1101",
      "control_U1103",
      "control_U500"
    ],
    "sheetIds": [
      "control_1000_DAC_BL0_31_AND_BUFFERS",
      "control_1100_DAC_SERVICE_AND_FORMING",
      "control_1200_DAC_FPGA_CONTROL_INTERFACE"
    ],
    "units": [
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1009",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1100",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 2
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 3
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 4
      },
      {
        "component": "control_U1101",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 5
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 2
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 3
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 4
      },
      {
        "component": "control_U1102",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 5
      },
      {
        "component": "control_U1103",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1104",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 1
      },
      {
        "component": "control_U1104",
        "sheet": "control_1100_DAC_SERVICE_AND_FORMING",
        "unit": 2
      },
      {
        "component": "control_U500",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 7
      }
    ]
  },
  "localScenarioIds": [
    "local-control-sources"
  ],
  "suggestedScenario": "local-control-sources",
  "explanationTitleRu": "Формирование аналоговых уставок",
  "sourceSheetId": "control_DAC",
  "sourceSheetName": "DAC",
  "sourceFile": "DAC.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "source-branches",
    "label": "Управление двумя группами аналоговых источников",
    "geometryOnly": true
  },
  "regions": []
};
