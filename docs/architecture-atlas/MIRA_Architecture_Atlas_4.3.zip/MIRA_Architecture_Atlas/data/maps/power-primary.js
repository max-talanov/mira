/* Editable functional scene: power-primary */
window.MIRA_FUNCTIONAL.scenes["power-primary"]={
  "id": "power-primary",
  "title": "PRIMARY_POWER",
  "subtitle": "Формирование основных напряжений",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet500",
      "title": "500_AON_3V3_BUCK",
      "subtitle": "Дежурное питание контроля",
      "description": "U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.",
      "refs": [
        "power_U501"
      ],
      "role": "power",
      "x": 440,
      "y": 40,
      "w": 430,
      "h": 220,
      "sceneId": "power_500_AON_3V3_BUCK",
      "sheetId": "power_500_AON_3V3_BUCK",
      "sourceSheetIds": [
        "power_500_AON_3V3_BUCK"
      ],
      "circuitGroup": {
        "refs": [
          "power_U501"
        ],
        "sheetIds": [
          "power_500_AON_3V3_BUCK"
        ],
        "units": [
          {
            "component": "power_U501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Дежурное питание контроля",
      "sourceSheetName": "500_AON_3V3_BUCK",
      "sourceSheetId": "power_500_AON_3V3_BUCK",
      "sourceFile": "500_AON_3V3_BUCK.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet600",
      "title": "600_USB_5V",
      "subtitle": "Питание USB 5 В",
      "description": "U601 преобразует BUS24 в USB5 для интерфейса USB платы.",
      "refs": [
        "power_U601"
      ],
      "role": "power",
      "x": 40,
      "y": 700,
      "w": 330,
      "h": 174,
      "sceneId": "power_600_USB_5V",
      "sheetId": "power_600_USB_5V",
      "sourceSheetIds": [
        "power_600_USB_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U601"
        ],
        "sheetIds": [
          "power_600_USB_5V"
        ],
        "units": [
          {
            "component": "power_U601",
            "sheet": "power_600_USB_5V",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание USB 5 В",
      "sourceSheetName": "600_USB_5V",
      "sourceSheetId": "power_600_USB_5V",
      "sourceFile": "600_USB_5V.kicad_sch",
      "layoutRole": "support"
    },
    {
      "id": "sheet700",
      "title": "700_SYS_3V3",
      "subtitle": "Питание контроллера 3,3 В",
      "description": "U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.",
      "refs": [
        "power_U701"
      ],
      "role": "power",
      "x": 40,
      "y": 365,
      "w": 410,
      "h": 210,
      "sceneId": "power_700_SYS_3V3",
      "sheetId": "power_700_SYS_3V3",
      "sourceSheetIds": [
        "power_700_SYS_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U701"
        ],
        "sheetIds": [
          "power_700_SYS_3V3"
        ],
        "units": [
          {
            "component": "power_U701",
            "sheet": "power_700_SYS_3V3",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Питание контроллера 3,3 В",
      "sourceSheetName": "700_SYS_3V3",
      "sourceSheetId": "power_700_SYS_3V3",
      "sourceFile": "700_SYS_3V3.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet800",
      "title": "800_FPGA_INTERMEDIATE_5V5",
      "subtitle": "Промежуточное питание ПЛИС",
      "description": "U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.",
      "refs": [
        "power_U801"
      ],
      "role": "power",
      "x": 1030,
      "y": 40,
      "w": 410,
      "h": 210,
      "sceneId": "power_800_FPGA_INTERMEDIATE_5V5",
      "sheetId": "power_800_FPGA_INTERMEDIATE_5V5",
      "sourceSheetIds": [
        "power_800_FPGA_INTERMEDIATE_5V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_U801"
        ],
        "sheetIds": [
          "power_800_FPGA_INTERMEDIATE_5V5"
        ],
        "units": [
          {
            "component": "power_U801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Промежуточное питание ПЛИС",
      "sourceSheetName": "800_FPGA_INTERMEDIATE_5V5",
      "sourceSheetId": "power_800_FPGA_INTERMEDIATE_5V5",
      "sourceFile": "800_FPGA_INTERMEDIATE_5V5.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet900",
      "title": "900_ANALOG_PREREGULATOR_6V",
      "subtitle": "Предстабилизатор аналогового питания",
      "description": "U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.",
      "refs": [
        "power_U901"
      ],
      "role": "power",
      "x": 1030,
      "y": 385,
      "w": 410,
      "h": 210,
      "sceneId": "power_900_ANALOG_PREREGULATOR_6V",
      "sheetId": "power_900_ANALOG_PREREGULATOR_6V",
      "sourceSheetIds": [
        "power_900_ANALOG_PREREGULATOR_6V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U901"
        ],
        "sheetIds": [
          "power_900_ANALOG_PREREGULATOR_6V"
        ],
        "units": [
          {
            "component": "power_U901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Предстабилизатор аналогового питания",
      "sourceSheetName": "900_ANALOG_PREREGULATOR_6V",
      "sourceSheetId": "power_900_ANALOG_PREREGULATOR_6V",
      "sourceFile": "900_ANALOG_PREREGULATOR_6V.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet1000",
      "title": "1000_AFE_POSITIVE_15V",
      "subtitle": "Положительное аналоговое питание",
      "description": "U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.",
      "refs": [
        "power_U1001"
      ],
      "role": "power",
      "x": 1030,
      "y": 775,
      "w": 350,
      "h": 182,
      "sceneId": "power_1000_AFE_POSITIVE_15V",
      "sheetId": "power_1000_AFE_POSITIVE_15V",
      "sourceSheetIds": [
        "power_1000_AFE_POSITIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1001"
        ],
        "sheetIds": [
          "power_1000_AFE_POSITIVE_15V"
        ],
        "units": [
          {
            "component": "power_U1001",
            "sheet": "power_1000_AFE_POSITIVE_15V",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Положительное аналоговое питание",
      "sourceSheetName": "1000_AFE_POSITIVE_15V",
      "sourceSheetId": "power_1000_AFE_POSITIVE_15V",
      "sourceFile": "1000_AFE_POSITIVE_15V.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet1100",
      "title": "1100_AFE_NEGATIVE_15V",
      "subtitle": "Отрицательное аналоговое питание",
      "description": "U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.",
      "refs": [
        "power_U1101",
        "power_U1102"
      ],
      "role": "power",
      "x": 1530,
      "y": 775,
      "w": 350,
      "h": 182,
      "sceneId": "power_1100_AFE_NEGATIVE_15V",
      "sheetId": "power_1100_AFE_NEGATIVE_15V",
      "sourceSheetIds": [
        "power_1100_AFE_NEGATIVE_15V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1101",
          "power_U1102"
        ],
        "sheetIds": [
          "power_1100_AFE_NEGATIVE_15V"
        ],
        "units": [
          {
            "component": "power_U1101",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          },
          {
            "component": "power_U1102",
            "sheet": "power_1100_AFE_NEGATIVE_15V",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Отрицательное аналоговое питание",
      "sourceSheetName": "1100_AFE_NEGATIVE_15V",
      "sourceSheetId": "power_1100_AFE_NEGATIVE_15V",
      "sourceFile": "1100_AFE_NEGATIVE_15V.kicad_sch",
      "layoutRole": "bank"
    }
  ],
  "edges": [],
  "bounds": {
    "x": -28,
    "y": -49,
    "w": 1976,
    "h": 1071
  },
  "board": "power",
  "sheetIds": [
    "power_500_AON_3V3_BUCK",
    "power_600_USB_5V",
    "power_700_SYS_3V3",
    "power_800_FPGA_INTERMEDIATE_5V5",
    "power_900_ANALOG_PREREGULATOR_6V",
    "power_1000_AFE_POSITIVE_15V",
    "power_1100_AFE_NEGATIVE_15V"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U501",
      "power_U601",
      "power_U701",
      "power_U801",
      "power_U901",
      "power_U1001",
      "power_U1101",
      "power_U1102"
    ],
    "sheetIds": [
      "power_500_AON_3V3_BUCK",
      "power_600_USB_5V",
      "power_700_SYS_3V3",
      "power_800_FPGA_INTERMEDIATE_5V5",
      "power_900_ANALOG_PREREGULATOR_6V",
      "power_1000_AFE_POSITIVE_15V",
      "power_1100_AFE_NEGATIVE_15V"
    ],
    "units": [
      {
        "component": "power_U501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_U601",
        "sheet": "power_600_USB_5V",
        "unit": 1
      },
      {
        "component": "power_U701",
        "sheet": "power_700_SYS_3V3",
        "unit": 1
      },
      {
        "component": "power_U801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_U901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_U1001",
        "sheet": "power_1000_AFE_POSITIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1101",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      },
      {
        "component": "power_U1102",
        "sheet": "power_1100_AFE_NEGATIVE_15V",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power-primary"
  ],
  "suggestedScenario": "local-power-primary",
  "explanationTitleRu": "Формирование основных напряжений",
  "sourceSheetId": "power_PRIMARY_POWER",
  "sourceSheetName": "PRIMARY_POWER",
  "sourceFile": "PRIMARY_POWER.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power",
  "layout": {
    "version": 2,
    "kind": "primary-purpose-groups",
    "label": "Дежурная часть, системное питание и аналоговые ветви",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 412,
      "y": -14,
      "w": 486,
      "h": 299,
      "title": "Дежурная часть",
      "kind": "primary",
      "nodeIds": [
        "sheet500"
      ]
    },
    {
      "x": 12,
      "y": 311,
      "w": 466,
      "h": 588,
      "title": "Система и USB",
      "kind": "primary",
      "nodeIds": [
        "sheet600",
        "sheet700"
      ]
    },
    {
      "x": 1002,
      "y": -14,
      "w": 466,
      "h": 634,
      "title": "Промежуточные шины",
      "kind": "primary",
      "nodeIds": [
        "sheet800",
        "sheet900"
      ]
    },
    {
      "x": 1002,
      "y": 721,
      "w": 906,
      "h": 261,
      "title": "Биполярное аналоговое питание",
      "kind": "primary",
      "nodeIds": [
        "sheet1000",
        "sheet1100"
      ]
    }
  ]
};
