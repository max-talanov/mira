/* Editable functional scene: power_900_ANALOG_PREREGULATOR_6V */
window.MIRA_FUNCTIONAL.scenes["power_900_ANALOG_PREREGULATOR_6V"]={
  "id": "power_900_ANALOG_PREREGULATOR_6V",
  "title": "900_ANALOG_PREREGULATOR_6V",
  "subtitle": "Предстабилизатор аналогового питания",
  "description": "U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_900_ANALOG_PREREGULATOR_6V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_900_ANALOG_PREREGULATOR_6V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Аналоговый предстабилизатор: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U901",
        "power_L901",
        "power_R902",
        "power_R903"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_900_ANALOG_PREREGULATOR_6V",
      "sourceSheetIds": [
        "power_900_ANALOG_PREREGULATOR_6V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U901",
          "power_L901",
          "power_R902",
          "power_R903"
        ],
        "sheetIds": [
          "power_900_ANALOG_PREREGULATOR_6V"
        ],
        "units": [
          {
            "component": "power_L901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_R902",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_R903",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_U901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q901",
        "power_R901"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_900_ANALOG_PREREGULATOR_6V",
      "sourceSheetIds": [
        "power_900_ANALOG_PREREGULATOR_6V"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q901",
          "power_R901"
        ],
        "sheetIds": [
          "power_900_ANALOG_PREREGULATOR_6V"
        ],
        "units": [
          {
            "component": "power_Q901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_R901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C904",
        "power_C901",
        "power_C902",
        "power_C903",
        "power_C905",
        "power_R905",
        "power_R904",
        "power_D901"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_900_ANALOG_PREREGULATOR_6V",
      "sourceSheetIds": [
        "power_900_ANALOG_PREREGULATOR_6V"
      ],
      "circuitGroup": {
        "refs": [
          "power_C904",
          "power_C901",
          "power_C902",
          "power_C903",
          "power_C905",
          "power_R905",
          "power_R904",
          "power_D901"
        ],
        "sheetIds": [
          "power_900_ANALOG_PREREGULATOR_6V"
        ],
        "units": [
          {
            "component": "power_C901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_C902",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_C903",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_C904",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_C905",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_D901",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_R904",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          },
          {
            "component": "power_R905",
            "sheet": "power_900_ANALOG_PREREGULATOR_6V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход ANA6",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_900_ANALOG_PREREGULATOR_6V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_900_ANALOG_PREREGULATOR_6V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_44a5bd51b5f3",
        "power_net_bbc855740138"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "ANA_RAW",
        "ANA6"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA_RAW",
        "ANA6"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "ANA6",
      "type": "power",
      "nets": [
        "power_net_bbc855740138"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "ANA6",
      "netLabels": [
        "ANA6"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA6"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_6220152fdd65",
        "power_net_b17423d6c3da"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_ANA",
        "EN_ANA"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA",
        "EN_ANA"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_900_ANALOG_PREREGULATOR_6V",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 14,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U901",
      "power_L901",
      "power_R902",
      "power_R903",
      "power_Q901",
      "power_R901",
      "power_C904",
      "power_C901",
      "power_C902",
      "power_C903",
      "power_C905",
      "power_R905",
      "power_R904",
      "power_D901"
    ],
    "sheetIds": [
      "power_900_ANALOG_PREREGULATOR_6V"
    ],
    "units": [
      {
        "component": "power_L901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_R902",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_R903",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_U901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_Q901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_R901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_C901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_C902",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_C903",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_C904",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_C905",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_D901",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_R904",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      },
      {
        "component": "power_R905",
        "sheet": "power_900_ANALOG_PREREGULATOR_6V",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_900_ANALOG_PREREGULATOR_6V"
  ],
  "suggestedScenario": "local-power_900_ANALOG_PREREGULATOR_6V",
  "explanationTitleRu": "Предстабилизатор аналогового питания",
  "sourceSheetId": "power_900_ANALOG_PREREGULATOR_6V",
  "sourceSheetName": "900_ANALOG_PREREGULATOR_6V",
  "sourceFile": "900_ANALOG_PREREGULATOR_6V.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
