/* Editable functional scene: power_3200_PM_NEGATIVE_OVERCURRENT */
window.MIRA_FUNCTIONAL.scenes["power_3200_PM_NEGATIVE_OVERCURRENT"]={
  "id": "power_3200_PM_NEGATIVE_OVERCURRENT",
  "title": "3200_PM_NEGATIVE_OVERCURRENT",
  "subtitle": "Защита отрицательной шины по току",
  "description": "U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.",
  "nodes": [
    {
      "id": "threshold",
      "title": "Порог тока отрицательной шины",
      "subtitle": "",
      "description": "Делитель и фильтрация задают аппаратный порог сравнения.",
      "refs": [
        "power_R3201",
        "power_R3202",
        "power_R3203",
        "power_C3201",
        "power_C3202"
      ],
      "role": "analog",
      "x": 40,
      "y": 75,
      "w": 250,
      "h": 134,
      "sheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "sourceSheetIds": [
        "power_3200_PM_NEGATIVE_OVERCURRENT"
      ],
      "circuitGroup": {
        "refs": [
          "power_R3201",
          "power_R3202",
          "power_R3203",
          "power_C3201",
          "power_C3202"
        ],
        "sheetIds": [
          "power_3200_PM_NEGATIVE_OVERCURRENT"
        ],
        "units": [
          {
            "component": "power_C3201",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          },
          {
            "component": "power_C3202",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          },
          {
            "component": "power_R3201",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          },
          {
            "component": "power_R3202",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          },
          {
            "component": "power_R3203",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "compare",
      "title": "Превышение тока отрицательной шины",
      "subtitle": "",
      "description": "Компаратор проверяет подготовленный сигнал тока отрицательной шины.",
      "refs": [
        "power_U3201"
      ],
      "role": "fault",
      "x": 620,
      "y": 230,
      "w": 360,
      "h": 194,
      "sheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
      "sourceSheetIds": [
        "power_3200_PM_NEGATIVE_OVERCURRENT"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3201"
        ],
        "sheetIds": [
          "power_3200_PM_NEGATIVE_OVERCURRENT"
        ],
        "units": [
          {
            "component": "power_U3201",
            "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "threshold_compare",
      "from": "threshold",
      "to": "compare",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_4aeb4892b398",
        "power_net_cfd922d13086"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "OC_OK_N"
      ],
      "unnamedNetIds": [
        "power_net_cfd922d13086"
      ],
      "labelLines": [
        "OC_OK_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 40,
    "w": 1020,
    "h": 424
  },
  "board": "power",
  "sheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 6,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_R3201",
      "power_R3202",
      "power_R3203",
      "power_C3201",
      "power_C3202",
      "power_U3201"
    ],
    "sheetIds": [
      "power_3200_PM_NEGATIVE_OVERCURRENT"
    ],
    "units": [
      {
        "component": "power_C3201",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      },
      {
        "component": "power_C3202",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      },
      {
        "component": "power_R3201",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      },
      {
        "component": "power_R3202",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      },
      {
        "component": "power_R3203",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      },
      {
        "component": "power_U3201",
        "sheet": "power_3200_PM_NEGATIVE_OVERCURRENT",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3200_PM_NEGATIVE_OVERCURRENT"
  ],
  "suggestedScenario": "local-power_3200_PM_NEGATIVE_OVERCURRENT",
  "explanationTitleRu": "Защита отрицательной шины по току",
  "sourceSheetId": "power_3200_PM_NEGATIVE_OVERCURRENT",
  "sourceSheetName": "3200_PM_NEGATIVE_OVERCURRENT",
  "sourceFile": "3200_PM_NEGATIVE_OVERCURRENT.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "comparison-with-reference",
    "label": "Компаратор и отдельная цепь задания порогов",
    "geometryOnly": true
  },
  "regions": []
};
