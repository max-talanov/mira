/* Editable functional scene: control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"]={
  "id": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
  "title": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
  "subtitle": "Вход питания платы Control",
  "description": "J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.",
  "nodes": [
    {
      "id": "connector",
      "title": "Приём питания платы",
      "subtitle": "",
      "description": "J400 — входной интерфейс платы Control для напряжений питания и сигналов контроля.",
      "refs": [
        "control_J400",
        "control_R400",
        "control_R401",
        "control_R404",
        "control_R405",
        "control_R406",
        "control_R407"
      ],
      "role": "power",
      "x": 40,
      "y": 235,
      "w": 340,
      "h": 184,
      "sheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sourceSheetIds": [
        "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_J400",
          "control_R400",
          "control_R401",
          "control_R404",
          "control_R405",
          "control_R406",
          "control_R407"
        ],
        "sheetIds": [
          "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
        ],
        "units": [
          {
            "component": "control_J400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R401",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R404",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R405",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R406",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R407",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "host",
      "title": "Безопасный приём состояния",
      "subtitle": "",
      "description": "Приёмники на границах доменов передают состояние контроллеру, не запитывая выключенные домены через сигналы.",
      "refs": [
        "control_U400",
        "control_R403",
        "control_C400"
      ],
      "role": "control",
      "x": 690,
      "y": 50,
      "w": 360,
      "h": 190,
      "sheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sourceSheetIds": [
        "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U400",
          "control_R403",
          "control_C400"
        ],
        "sheetIds": [
          "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R403",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 4
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 5
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "permit",
      "title": "Приём разрешения матрицы",
      "subtitle": "",
      "description": "Отдельный приёмник в домене ввода-вывода передаёт разрешение работы матрицы.",
      "refs": [
        "control_U401",
        "control_R402",
        "control_C401"
      ],
      "role": "fault",
      "x": 690,
      "y": 500,
      "w": 270,
      "h": 146,
      "sheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "sourceSheetIds": [
        "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U401",
          "control_R402",
          "control_C401"
        ],
        "sheetIds": [
          "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C401",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R402",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U401",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "connector_host",
      "from": "connector",
      "to": "host",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "control_net_44af6a0dc05c",
        "control_net_9bddf3e35643",
        "control_net_225bd2a08dfb",
        "control_net_8108fd43e4b2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "PM_UART_TX_POWER",
        "ALL_RAILS_PG_POWER",
        "GLOBAL_PWR_PERMIT_POWER",
        "MATRIX_PERMIT_POWER"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ALL_RAILS_PG_POWER",
        "GLOBAL_PWR_PERMIT_POWER",
        "MATRIX_PERMIT_POWER",
        "PM_UART_TX_POWER"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "connector_permit",
      "from": "connector",
      "to": "permit",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "control_net_8108fd43e4b2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "MATRIX_PERMIT_POWER"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_PERMIT_POWER"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "host_permit",
      "from": "host",
      "to": "permit",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "control_net_8108fd43e4b2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "MATRIX_PERMIT_POWER"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_PERMIT_POWER"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 15,
    "w": 1090,
    "h": 671
  },
  "board": "control",
  "sheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_J400",
      "control_R400",
      "control_R401",
      "control_R404",
      "control_R405",
      "control_R406",
      "control_R407",
      "control_U400",
      "control_R403",
      "control_C400",
      "control_U401",
      "control_R402",
      "control_C401"
    ],
    "sheetIds": [
      "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
    ],
    "units": [
      {
        "component": "control_J400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R401",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R404",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R405",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R406",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R407",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R403",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 5
      },
      {
        "component": "control_C401",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R402",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U401",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
  ],
  "suggestedScenario": "local-control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
  "explanationTitleRu": "Вход питания платы Control",
  "sourceSheetId": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
  "sourceSheetName": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
  "sourceFile": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-boundary",
  "layout": {
    "version": 2,
    "kind": "boundary-receivers",
    "label": "Вход питания и два отдельных приёмника состояния",
    "geometryOnly": true
  },
  "regions": []
};
