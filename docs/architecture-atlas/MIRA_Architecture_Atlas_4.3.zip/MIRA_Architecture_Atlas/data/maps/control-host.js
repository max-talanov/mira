/* Editable functional scene: control-host */
window.MIRA_FUNCTIONAL.scenes["control-host"]={
  "id": "control-host",
  "title": "MCU",
  "subtitle": "Основной контроллер",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet100",
      "title": "100_MCU_POWER_CLOCKS_AND_DEBUG",
      "subtitle": "Основной контроллер · запуск и отладка",
      "description": "U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.",
      "refs": [
        "control_U100",
        "control_J100",
        "control_Y101",
        "control_J101",
        "control_Y100"
      ],
      "role": "data",
      "x": 40,
      "y": 240,
      "w": 430,
      "h": 220,
      "sceneId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_U100",
          "control_J100",
          "control_Y101",
          "control_J101",
          "control_Y100"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_J100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_J101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 4
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 5
          },
          {
            "component": "control_Y100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_Y101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Основной контроллер · запуск и отладка",
      "sourceSheetName": "100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceFile": "100_MCU_POWER_CLOCKS_AND_DEBUG.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet200",
      "title": "200_MCU_FMC_AND_SDRAM",
      "subtitle": "Оперативная память контроллера",
      "description": "Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.",
      "refs": [
        "control_U200",
        "control_U100"
      ],
      "role": "data",
      "x": 690,
      "y": 40,
      "w": 350,
      "h": 180,
      "sceneId": "control_200_MCU_FMC_AND_SDRAM",
      "sheetId": "control_200_MCU_FMC_AND_SDRAM",
      "sourceSheetIds": [
        "control_200_MCU_FMC_AND_SDRAM"
      ],
      "circuitGroup": {
        "refs": [
          "control_U200",
          "control_U100"
        ],
        "sheetIds": [
          "control_200_MCU_FMC_AND_SDRAM"
        ],
        "units": [
          {
            "component": "control_U100",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 2
          },
          {
            "component": "control_U200",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Оперативная память контроллера",
      "sourceSheetName": "200_MCU_FMC_AND_SDRAM",
      "sourceSheetId": "control_200_MCU_FMC_AND_SDRAM",
      "sourceFile": "200_MCU_FMC_AND_SDRAM.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "sheet300",
      "title": "300_MCU_QSPI_MICROSD_AND_CONTROL",
      "subtitle": "Память и управление платой",
      "description": "U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.",
      "refs": [
        "control_U300",
        "control_J300",
        "control_U302",
        "control_U100",
        "control_U301",
        "control_U303"
      ],
      "role": "data",
      "x": 690,
      "y": 465,
      "w": 350,
      "h": 180,
      "sceneId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceSheetIds": [
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_U300",
          "control_J300",
          "control_U302",
          "control_U100",
          "control_U301",
          "control_U303"
        ],
        "sheetIds": [
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_J300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 3
          },
          {
            "component": "control_U300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U301",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U302",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U303",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Память и управление платой",
      "sourceSheetName": "300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceSheetId": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "sourceFile": "300_MCU_QSPI_MICROSD_AND_CONTROL.kicad_sch",
      "layoutRole": "bank"
    }
  ],
  "edges": [],
  "bounds": {
    "x": -28,
    "y": -49,
    "w": 1136,
    "h": 759
  },
  "board": "control",
  "sheetIds": [
    "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
    "control_200_MCU_FMC_AND_SDRAM",
    "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U100",
      "control_J100",
      "control_Y101",
      "control_J101",
      "control_Y100",
      "control_U200",
      "control_U300",
      "control_J300",
      "control_U302",
      "control_U301",
      "control_U303"
    ],
    "sheetIds": [
      "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "control_200_MCU_FMC_AND_SDRAM",
      "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
    ],
    "units": [
      {
        "component": "control_J100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_J101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 4
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 5
      },
      {
        "component": "control_Y100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_Y101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 2
      },
      {
        "component": "control_U200",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_J300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 3
      },
      {
        "component": "control_U300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U301",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U302",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U303",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-host"
  ],
  "suggestedScenario": "local-control-host",
  "explanationTitleRu": "Основной контроллер",
  "sourceSheetId": "control_MCU",
  "sourceSheetName": "MCU",
  "sourceFile": "MCU.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control",
  "layout": {
    "version": 2,
    "kind": "controller-and-storage",
    "label": "Основной контроллер и две группы памяти",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 186,
      "w": 486,
      "h": 299,
      "title": "Контроллер",
      "kind": "primary",
      "nodeIds": [
        "sheet100"
      ]
    },
    {
      "x": 662,
      "y": -14,
      "w": 406,
      "h": 684,
      "title": "Память и периферия",
      "kind": "primary",
      "nodeIds": [
        "sheet200",
        "sheet300"
      ]
    }
  ]
};
