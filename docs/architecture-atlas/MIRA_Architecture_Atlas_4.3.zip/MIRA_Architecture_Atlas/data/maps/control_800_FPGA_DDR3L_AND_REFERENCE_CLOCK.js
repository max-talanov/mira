/* Editable functional scene: control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK */
window.MIRA_FUNCTIONAL.scenes["control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"]={
  "id": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "title": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "subtitle": "Память и тактирование ПЛИС",
  "description": "U800 предоставляет ПЛИС U500 512 МиБ памяти DDR3L. Y800 формирует дифференциальное опорное тактирование подсистемы памяти.",
  "nodes": [
    {
      "id": "clock",
      "title": "Высокочастотная тактовая опора",
      "subtitle": "",
      "description": "Дифференциальный генератор подаёт опорный сигнал 200 МГц в ПЛИС.",
      "refs": [
        "control_Y800",
        "control_C800"
      ],
      "role": "control",
      "x": 40,
      "y": 20,
      "w": 250,
      "h": 140,
      "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceSheetIds": [
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
      ],
      "circuitGroup": {
        "refs": [
          "control_Y800",
          "control_C800"
        ],
        "sheetIds": [
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
        ],
        "units": [
          {
            "component": "control_C800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_Y800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "fpga",
      "title": "Обмен с памятью",
      "subtitle": "",
      "description": "Интерфейс памяти ПЛИС формирует команды и обменивается данными.",
      "refs": [
        "control_U500",
        "control_C810",
        "control_C811",
        "control_C808",
        "control_C806",
        "control_C836",
        "control_C815",
        "control_C814",
        "control_C805",
        "control_C834",
        "control_C803",
        "control_C807",
        "control_C804",
        "control_C812",
        "control_C809",
        "control_C835",
        "control_C837",
        "control_C813"
      ],
      "role": "data",
      "x": 430,
      "y": 230,
      "w": 350,
      "h": 184,
      "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceSheetIds": [
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_C810",
          "control_C811",
          "control_C808",
          "control_C806",
          "control_C836",
          "control_C815",
          "control_C814",
          "control_C805",
          "control_C834",
          "control_C803",
          "control_C807",
          "control_C804",
          "control_C812",
          "control_C809",
          "control_C835",
          "control_C837",
          "control_C813"
        ],
        "sheetIds": [
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
        ],
        "units": [
          {
            "component": "control_C803",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C804",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C805",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C806",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C807",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C808",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C809",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C810",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C811",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C812",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C813",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C814",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C815",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C834",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C835",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C836",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C837",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 5
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 6
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "memory",
      "title": "Буферизация быстрых данных",
      "subtitle": "",
      "description": "DDR3L предоставляет ПЛИС 512 МиБ энергозависимой рабочей памяти.",
      "refs": [
        "control_U800",
        "control_C824",
        "control_C823",
        "control_C816",
        "control_C832",
        "control_C822",
        "control_C825",
        "control_C830",
        "control_C828",
        "control_C818",
        "control_C831",
        "control_C829",
        "control_C833",
        "control_C819",
        "control_C820",
        "control_C826",
        "control_C821",
        "control_C817",
        "control_C827"
      ],
      "role": "data",
      "x": 1130,
      "y": 230,
      "w": 350,
      "h": 184,
      "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceSheetIds": [
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
      ],
      "circuitGroup": {
        "refs": [
          "control_U800",
          "control_C824",
          "control_C823",
          "control_C816",
          "control_C832",
          "control_C822",
          "control_C825",
          "control_C830",
          "control_C828",
          "control_C818",
          "control_C831",
          "control_C829",
          "control_C833",
          "control_C819",
          "control_C820",
          "control_C826",
          "control_C821",
          "control_C817",
          "control_C827"
        ],
        "sheetIds": [
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
        ],
        "units": [
          {
            "component": "control_C816",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C817",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C818",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C819",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C820",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C821",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C822",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C823",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C824",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C825",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C826",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C827",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C828",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C829",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C830",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C831",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C832",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C833",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_U800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_U800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 2
          },
          {
            "component": "control_U800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 3
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "termination",
      "title": "Опорные уровни памяти",
      "subtitle": "",
      "description": "Цепи терминации и опорного напряжения обеспечивают работу интерфейса DDR3L.",
      "refs": [
        "control_R800",
        "control_R801",
        "control_R802",
        "control_R803",
        "control_R804",
        "control_R805",
        "control_R806",
        "control_R807",
        "control_R808",
        "control_R809",
        "control_R810",
        "control_R811",
        "control_R812",
        "control_R813",
        "control_R814",
        "control_R815",
        "control_R816",
        "control_R817",
        "control_R818",
        "control_R819",
        "control_R820",
        "control_R821",
        "control_R822",
        "control_R823",
        "control_R824",
        "control_R825",
        "control_R826",
        "control_R827",
        "control_R828",
        "control_R829",
        "control_R830",
        "control_C802",
        "control_C801"
      ],
      "role": "analog",
      "x": 1145,
      "y": 610,
      "w": 260,
      "h": 140,
      "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "sourceSheetIds": [
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
      ],
      "circuitGroup": {
        "refs": [
          "control_R800",
          "control_R801",
          "control_R802",
          "control_R803",
          "control_R804",
          "control_R805",
          "control_R806",
          "control_R807",
          "control_R808",
          "control_R809",
          "control_R810",
          "control_R811",
          "control_R812",
          "control_R813",
          "control_R814",
          "control_R815",
          "control_R816",
          "control_R817",
          "control_R818",
          "control_R819",
          "control_R820",
          "control_R821",
          "control_R822",
          "control_R823",
          "control_R824",
          "control_R825",
          "control_R826",
          "control_R827",
          "control_R828",
          "control_R829",
          "control_R830",
          "control_C802",
          "control_C801"
        ],
        "sheetIds": [
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
        ],
        "units": [
          {
            "component": "control_C801",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_C802",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R800",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R801",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R802",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R803",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R804",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R805",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R806",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R807",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R808",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R809",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R810",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R811",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R812",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R813",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R814",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R815",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R816",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R817",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R818",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R819",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R820",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R821",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R822",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R823",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R824",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R825",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R826",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R827",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R828",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R829",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          },
          {
            "component": "control_R830",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "clock_fpga_0",
      "from": "clock",
      "to": "fpga",
      "label": "Дифференциальное тактирование 200 МГц",
      "type": "control",
      "nets": [
        "control_net_c31eb8fe07d3",
        "control_net_d44f364a5830",
        "control_net_3bfe72ccfc41",
        "control_net_21a5e9f13f7f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Дифференциальное тактирование 200 МГц",
      "netLabels": [
        "FPGA_SYSCLK_P",
        "FPGA_SYSCLK_N",
        "CLK200_SRC_N",
        "CLK200_SRC_P"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CLK200_SRC_N · CLK200_SRC_P",
        "FPGA_SYSCLK_N · FPGA_SYSCLK_P"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_memory_1",
      "from": "fpga",
      "to": "memory",
      "label": "Адрес / команда / тактирование",
      "type": "control",
      "nets": [
        "control_net_58af204d8c23",
        "control_net_cccff17550b9",
        "control_net_f4bfe5cdab56",
        "control_net_4bb6a512cc3a",
        "control_net_19bcc72c5488",
        "control_net_185955b3a706",
        "control_net_d109bb25230c",
        "control_net_d9ef0a17e785",
        "control_net_fd2bad63a67c",
        "control_net_bb3aaa71ba05",
        "control_net_907e4adf7ca2",
        "control_net_ebaa690e703b",
        "control_net_92d89f9df56c",
        "control_net_c4d0ccc3d16d",
        "control_net_5220b4a56b5c",
        "control_net_d7ba445b9916",
        "control_net_395f29bc0592",
        "control_net_be534772f175",
        "control_net_42df6ae20837",
        "control_net_075227a69d18",
        "control_net_707df60aeb98",
        "control_net_abae69816039",
        "control_net_4baca15034bf",
        "control_net_4143ff0aef6d",
        "control_net_3ddfecb0df47",
        "control_net_1d61ccb9d017"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Адрес / команда",
      "netLabels": [
        "DDR_A7",
        "DDR_A0",
        "DDR_A11",
        "DDR_A6",
        "DDR_A13",
        "DDR_A2",
        "DDR_BA1",
        "DDR_CAS_N",
        "DDR_BA2",
        "DDR_RAS_N",
        "DDR_A12",
        "DDR_RESET_N",
        "DDR_A8",
        "DDR_CK_P",
        "DDR_CK_N",
        "DDR_A4",
        "DDR_ODT",
        "DDR_CKE",
        "DDR_WE_N",
        "DDR_A10",
        "DDR_BA0",
        "DDR_A3",
        "DDR_A5",
        "DDR_A1",
        "DDR_A9",
        "DDR_A14"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DDR_A7 · DDR_A0",
        "DDR_A11 · ещё 23"
      ],
      "allConnectionsLabel": "Все соединения: 26",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_memory_2",
      "from": "fpga",
      "to": "memory",
      "label": "16 бит данных и стробы",
      "type": "data",
      "nets": [
        "control_net_6943e9712d9c",
        "control_net_6dc2bebc3e2e",
        "control_net_ac8599a8c0cd",
        "control_net_c5d6e41ef012",
        "control_net_49b164ada644",
        "control_net_63a08f54a8af",
        "control_net_a46672b578ec",
        "control_net_85a84369e22a",
        "control_net_010b6b6f67c9",
        "control_net_d514c816e952",
        "control_net_3a2594a1e1f9",
        "control_net_9bc7997904a8",
        "control_net_6e031edce63d",
        "control_net_17b46c5249cb",
        "control_net_4ff8255e049a",
        "control_net_18e1c9509d79",
        "control_net_d2bff6eceb03",
        "control_net_dc796dddd274",
        "control_net_184f5bb728b0",
        "control_net_0065f370787e",
        "control_net_710e1e095743",
        "control_net_3a720de9ef0a"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "16-битные данные",
      "netLabels": [
        "DDR_DM0",
        "DDR_DQ3",
        "DDR_DQS_N1",
        "DDR_DQ1",
        "DDR_DQS_P1",
        "DDR_DQ14",
        "DDR_DQ7",
        "DDR_DQ5",
        "DDR_DQ12",
        "DDR_DQ0",
        "DDR_DQ10",
        "DDR_DQ13",
        "DDR_DQ15",
        "DDR_DQS_N0",
        "DDR_DQ2",
        "DDR_DQ11",
        "DDR_DQ8",
        "DDR_DQS_P0",
        "DDR_DQ4",
        "DDR_DQ6",
        "DDR_DQ9",
        "DDR_DM1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DDR_DM0 · DDR_DQ3",
        "DDR_DQS_N1 · ещё 19"
      ],
      "allConnectionsLabel": "Все соединения: 22",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "termination_memory_3",
      "from": "termination",
      "to": "memory",
      "label": "VTT и опорное смещение",
      "type": "power",
      "nets": [
        "control_net_01f75bd2f12a",
        "control_net_5fb1532b0e1e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Опорные уровни DDR",
      "netLabels": [
        "VTT",
        "DDR_VREF"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "VTT",
        "DDR_VREF"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": 0,
    "y": -15,
    "w": 1520,
    "h": 805
  },
  "board": "control",
  "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 72,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_Y800",
      "control_C800",
      "control_U500",
      "control_C810",
      "control_C811",
      "control_C808",
      "control_C806",
      "control_C836",
      "control_C815",
      "control_C814",
      "control_C805",
      "control_C834",
      "control_C803",
      "control_C807",
      "control_C804",
      "control_C812",
      "control_C809",
      "control_C835",
      "control_C837",
      "control_C813",
      "control_U800",
      "control_C824",
      "control_C823",
      "control_C816",
      "control_C832",
      "control_C822",
      "control_C825",
      "control_C830",
      "control_C828",
      "control_C818",
      "control_C831",
      "control_C829",
      "control_C833",
      "control_C819",
      "control_C820",
      "control_C826",
      "control_C821",
      "control_C817",
      "control_C827",
      "control_R800",
      "control_R801",
      "control_R802",
      "control_R803",
      "control_R804",
      "control_R805",
      "control_R806",
      "control_R807",
      "control_R808",
      "control_R809",
      "control_R810",
      "control_R811",
      "control_R812",
      "control_R813",
      "control_R814",
      "control_R815",
      "control_R816",
      "control_R817",
      "control_R818",
      "control_R819",
      "control_R820",
      "control_R821",
      "control_R822",
      "control_R823",
      "control_R824",
      "control_R825",
      "control_R826",
      "control_R827",
      "control_R828",
      "control_R829",
      "control_R830",
      "control_C802",
      "control_C801"
    ],
    "sheetIds": [
      "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
    ],
    "units": [
      {
        "component": "control_C800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_Y800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C803",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C804",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C805",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C806",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C807",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C808",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C809",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C810",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C811",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C812",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C813",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C814",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C815",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C834",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C835",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C836",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C837",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 5
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 6
      },
      {
        "component": "control_C816",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C817",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C818",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C819",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C820",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C821",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C822",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C823",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C824",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C825",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C826",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C827",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C828",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C829",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C830",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C831",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C832",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C833",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_U800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_U800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 2
      },
      {
        "component": "control_U800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 3
      },
      {
        "component": "control_C801",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_C802",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R800",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R801",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R802",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R803",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R804",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R805",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R806",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R807",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R808",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R809",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R810",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R811",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R812",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R813",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R814",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R815",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R816",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R817",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R818",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R819",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R820",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R821",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R822",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R823",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R824",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R825",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R826",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R827",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R828",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R829",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      },
      {
        "component": "control_R830",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK"
  ],
  "suggestedScenario": "local-control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "explanationTitleRu": "Память и тактирование ПЛИС",
  "sourceSheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "sourceSheetName": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
  "sourceFile": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-fpga",
  "layout": {
    "version": 2,
    "kind": "memory-bus",
    "label": "Обмен с памятью, тактирование и согласование",
    "geometryOnly": true
  },
  "regions": []
};
