/* Editable functional scene: power-input */
window.MIRA_FUNCTIONAL.scenes["power-input"]={
  "id": "power-input",
  "title": "POWER_INPUT",
  "subtitle": "Защита входного питания",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet100",
      "title": "100_INPUT_CONNECTOR",
      "subtitle": "Подключение внешних 24 В",
      "description": "J101 принимает внешнее питание постоянного тока. D101/D102 показывают полярность до последующих узлов защиты.",
      "refs": [
        "power_J101"
      ],
      "role": "power",
      "x": 40,
      "y": 210,
      "w": 330,
      "h": 176,
      "sceneId": "power_100_INPUT_CONNECTOR",
      "sheetId": "power_100_INPUT_CONNECTOR",
      "sourceSheetIds": [
        "power_100_INPUT_CONNECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_J101"
        ],
        "sheetIds": [
          "power_100_INPUT_CONNECTOR"
        ],
        "units": [
          {
            "component": "power_J101",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Подключение внешних 24 В",
      "sourceSheetName": "100_INPUT_CONNECTOR",
      "sourceSheetId": "power_100_INPUT_CONNECTOR",
      "sourceFile": "100_INPUT_CONNECTOR.kicad_sch",
      "layoutRole": "gateway"
    },
    {
      "id": "sheet200",
      "title": "200_INPUT_FUSE_PROTECTION",
      "subtitle": "Предохранитель и индикация",
      "description": "F201 защищает входную ветвь. D204 показывает напряжение после предохранителя; Q201 управляет красной индикацией его обрыва.",
      "refs": [],
      "role": "power",
      "x": 520,
      "y": 210,
      "w": 340,
      "h": 176,
      "sceneId": "power_200_INPUT_FUSE_PROTECTION",
      "sheetId": "power_200_INPUT_FUSE_PROTECTION",
      "sourceSheetIds": [
        "power_200_INPUT_FUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_200_INPUT_FUSE_PROTECTION"
        ],
        "units": []
      },
      "explanationTitleRu": "Предохранитель и индикация",
      "sourceSheetName": "200_INPUT_FUSE_PROTECTION",
      "sourceSheetId": "power_200_INPUT_FUSE_PROTECTION",
      "sourceFile": "200_INPUT_FUSE_PROTECTION.kicad_sch",
      "layoutRole": "interface"
    },
    {
      "id": "sheet300",
      "title": "300_INPUT_EFUSE_PROTECTION",
      "subtitle": "Ограничение и отключение питания",
      "description": "U301 TPS26631 и внешние Q301/Q302 обеспечивают управляемую входную защиту, плавное включение и сигналы аварии и состояния.",
      "refs": [
        "power_U301",
        "power_JP301"
      ],
      "role": "power",
      "x": 1030,
      "y": 180,
      "w": 430,
      "h": 220,
      "sceneId": "power_300_INPUT_EFUSE_PROTECTION",
      "sheetId": "power_300_INPUT_EFUSE_PROTECTION",
      "sourceSheetIds": [
        "power_300_INPUT_EFUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_U301",
          "power_JP301"
        ],
        "sheetIds": [
          "power_300_INPUT_EFUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_JP301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_U301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Ограничение и отключение питания",
      "sourceSheetName": "300_INPUT_EFUSE_PROTECTION",
      "sourceSheetId": "power_300_INPUT_EFUSE_PROTECTION",
      "sourceFile": "300_INPUT_EFUSE_PROTECTION.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sheet400",
      "title": "400_INPUT_FILTER_SENSE",
      "subtitle": "Фильтрация защищённой шины 24 В",
      "description": "L401 и локальные конденсаторы фильтруют EFUSE_OUT. R401 служит шунтом входного тока перед BUS24.",
      "refs": [],
      "role": "power",
      "x": 1630,
      "y": 210,
      "w": 350,
      "h": 176,
      "sceneId": "power_400_INPUT_FILTER_SENSE",
      "sheetId": "power_400_INPUT_FILTER_SENSE",
      "sourceSheetIds": [
        "power_400_INPUT_FILTER_SENSE"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_400_INPUT_FILTER_SENSE"
        ],
        "units": []
      },
      "explanationTitleRu": "Фильтрация защищённой шины 24 В",
      "sourceSheetName": "400_INPUT_FILTER_SENSE",
      "sourceSheetId": "power_400_INPUT_FILTER_SENSE",
      "sourceFile": "400_INPUT_FILTER_SENSE.kicad_sch",
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "sheet300_sheet400",
      "from": "sheet300",
      "to": "sheet400",
      "label": "EFUSE_OUT",
      "type": "data",
      "nets": [
        "power_net_a837894762cd"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "EFUSE_OUT",
      "netLabels": [
        "EFUSE_OUT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "EFUSE_OUT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 2020,
    "h": 295
  },
  "board": "power",
  "sheetIds": [
    "power_100_INPUT_CONNECTOR",
    "power_200_INPUT_FUSE_PROTECTION",
    "power_300_INPUT_EFUSE_PROTECTION",
    "power_400_INPUT_FILTER_SENSE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J101",
      "power_U301",
      "power_JP301"
    ],
    "sheetIds": [
      "power_100_INPUT_CONNECTOR",
      "power_200_INPUT_FUSE_PROTECTION",
      "power_300_INPUT_EFUSE_PROTECTION",
      "power_400_INPUT_FILTER_SENSE"
    ],
    "units": [
      {
        "component": "power_J101",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      },
      {
        "component": "power_JP301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_U301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power-input"
  ],
  "suggestedScenario": "local-power-input",
  "explanationTitleRu": "Защита входного питания",
  "sourceSheetId": "power_POWER_INPUT",
  "sourceSheetName": "POWER_INPUT",
  "sourceFile": "POWER_INPUT.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power",
  "layout": {
    "version": 2,
    "kind": "input-protection-trunk",
    "label": "Входной тракт с выделенной управляемой защитой",
    "geometryOnly": true
  },
  "regions": []
};
