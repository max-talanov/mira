/* Editable functional scene: power_1600_DDR_1V35 */
window.MIRA_FUNCTIONAL.scenes["power_1600_DDR_1V35"]={
  "id": "power_1600_DDR_1V35",
  "title": "1600_DDR_1V35",
  "subtitle": "Питание памяти DDR3L",
  "description": "U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход FPGA5V5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1600_DDR_1V35"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1600_DDR_1V35"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Питание памяти DDR3L: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1601",
        "power_L1601",
        "power_R1604",
        "power_R1603",
        "power_R1605",
        "power_R1602"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1600_DDR_1V35",
      "sourceSheetIds": [
        "power_1600_DDR_1V35"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1601",
          "power_L1601",
          "power_R1604",
          "power_R1603",
          "power_R1605",
          "power_R1602"
        ],
        "sheetIds": [
          "power_1600_DDR_1V35"
        ],
        "units": [
          {
            "component": "power_L1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_R1602",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_R1603",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_R1604",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_R1605",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_U1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1601",
        "power_R1601"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1600_DDR_1V35",
      "sourceSheetIds": [
        "power_1600_DDR_1V35"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1601",
          "power_R1601"
        ],
        "sheetIds": [
          "power_1600_DDR_1V35"
        ],
        "units": [
          {
            "component": "power_Q1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_R1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1603",
        "power_C1602",
        "power_C1604",
        "power_C1601",
        "power_R1606"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1600_DDR_1V35",
      "sourceSheetIds": [
        "power_1600_DDR_1V35"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1603",
          "power_C1602",
          "power_C1604",
          "power_C1601",
          "power_R1606"
        ],
        "sheetIds": [
          "power_1600_DDR_1V35"
        ],
        "units": [
          {
            "component": "power_C1601",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_C1602",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_C1603",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_C1604",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          },
          {
            "component": "power_R1606",
            "sheet": "power_1600_DDR_1V35",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход DDR1V35",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1600_DDR_1V35"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1600_DDR_1V35"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_f3a748e4fa19",
        "power_net_978b64498138"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "DDR1V35",
        "DDR_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DDR1V35",
        "DDR_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "DDR1V35",
      "type": "power",
      "nets": [
        "power_net_f3a748e4fa19"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "DDR1V35",
      "netLabels": [
        "DDR1V35"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DDR1V35"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_d07b46e16a3e",
        "power_net_005a44b1c652"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_DDR",
        "EN_DDR"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_DDR",
        "EN_DDR"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1600_DDR_1V35",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1601",
      "power_L1601",
      "power_R1604",
      "power_R1603",
      "power_R1605",
      "power_R1602",
      "power_Q1601",
      "power_R1601",
      "power_C1603",
      "power_C1602",
      "power_C1604",
      "power_C1601",
      "power_R1606"
    ],
    "sheetIds": [
      "power_1600_DDR_1V35"
    ],
    "units": [
      {
        "component": "power_L1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_R1602",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_R1603",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_R1604",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_R1605",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_U1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_Q1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_R1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_C1601",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_C1602",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_C1603",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_C1604",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      },
      {
        "component": "power_R1606",
        "sheet": "power_1600_DDR_1V35",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1600_DDR_1V35"
  ],
  "suggestedScenario": "local-power_1600_DDR_1V35",
  "explanationTitleRu": "Питание памяти DDR3L",
  "sourceSheetId": "power_1600_DDR_1V35",
  "sourceSheetName": "1600_DDR_1V35",
  "sourceFile": "1600_DDR_1V35.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
