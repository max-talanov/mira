/* Editable functional scene: power_1300_FPGA_AUX_1V8 */
window.MIRA_FUNCTIONAL.scenes["power_1300_FPGA_AUX_1V8"]={
  "id": "power_1300_FPGA_AUX_1V8",
  "title": "1300_FPGA_AUX_1V8",
  "subtitle": "Вспомогательное питание ПЛИС 1,8 В",
  "description": "U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход FPGA5V5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1300_FPGA_AUX_1V8"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1300_FPGA_AUX_1V8"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Вспомогательное питание 1,8 В: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1301",
        "power_L1301",
        "power_R1303",
        "power_R1304",
        "power_R1305",
        "power_R1302"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1300_FPGA_AUX_1V8",
      "sourceSheetIds": [
        "power_1300_FPGA_AUX_1V8"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1301",
          "power_L1301",
          "power_R1303",
          "power_R1304",
          "power_R1305",
          "power_R1302"
        ],
        "sheetIds": [
          "power_1300_FPGA_AUX_1V8"
        ],
        "units": [
          {
            "component": "power_L1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_R1302",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_R1303",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_R1304",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_R1305",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_U1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1301",
        "power_R1301"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1300_FPGA_AUX_1V8",
      "sourceSheetIds": [
        "power_1300_FPGA_AUX_1V8"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1301",
          "power_R1301"
        ],
        "sheetIds": [
          "power_1300_FPGA_AUX_1V8"
        ],
        "units": [
          {
            "component": "power_Q1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_R1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1304",
        "power_C1301",
        "power_C1303",
        "power_C1302",
        "power_R1306"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1300_FPGA_AUX_1V8",
      "sourceSheetIds": [
        "power_1300_FPGA_AUX_1V8"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1304",
          "power_C1301",
          "power_C1303",
          "power_C1302",
          "power_R1306"
        ],
        "sheetIds": [
          "power_1300_FPGA_AUX_1V8"
        ],
        "units": [
          {
            "component": "power_C1301",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_C1302",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_C1303",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_C1304",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          },
          {
            "component": "power_R1306",
            "sheet": "power_1300_FPGA_AUX_1V8",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход AUX1V8",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1300_FPGA_AUX_1V8"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1300_FPGA_AUX_1V8"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_e70ca4a7b1de",
        "power_net_72aaeb0dd85a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "AUX1V8",
        "AUX18_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AUX1V8",
        "AUX18_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "AUX1V8",
      "type": "power",
      "nets": [
        "power_net_e70ca4a7b1de"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "AUX1V8",
      "netLabels": [
        "AUX1V8"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AUX1V8"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_9693d69e08e6",
        "power_net_91608c5bec4e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_AUX18",
        "EN_AUX18"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_AUX18",
        "EN_AUX18"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1300_FPGA_AUX_1V8",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1301",
      "power_L1301",
      "power_R1303",
      "power_R1304",
      "power_R1305",
      "power_R1302",
      "power_Q1301",
      "power_R1301",
      "power_C1304",
      "power_C1301",
      "power_C1303",
      "power_C1302",
      "power_R1306"
    ],
    "sheetIds": [
      "power_1300_FPGA_AUX_1V8"
    ],
    "units": [
      {
        "component": "power_L1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_R1302",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_R1303",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_R1304",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_R1305",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_U1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_Q1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_R1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_C1301",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_C1302",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_C1303",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_C1304",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      },
      {
        "component": "power_R1306",
        "sheet": "power_1300_FPGA_AUX_1V8",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1300_FPGA_AUX_1V8"
  ],
  "suggestedScenario": "local-power_1300_FPGA_AUX_1V8",
  "explanationTitleRu": "Вспомогательное питание ПЛИС 1,8 В",
  "sourceSheetId": "power_1300_FPGA_AUX_1V8",
  "sourceSheetName": "1300_FPGA_AUX_1V8",
  "sourceFile": "1300_FPGA_AUX_1V8.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
