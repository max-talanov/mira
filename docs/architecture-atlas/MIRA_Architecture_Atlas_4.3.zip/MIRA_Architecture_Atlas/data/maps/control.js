/* Editable functional scene: control */
window.MIRA_FUNCTIONAL.scenes["control"]={
  "id": "control",
  "title": "MIRA_Control",
  "subtitle": "Плата Control · от команды до измерения",
  "description": "Команды задают время, аналоговые воздействия и соединения матрицы. Измерительный тракт возвращает цифровой результат, а защита контролирует операцию.",
  "nodes": [
    {
      "id": "boundary",
      "title": "INTERCONNECT",
      "subtitle": "Приём питания и разрешений",
      "description": "Питание поступает через J400; приёмники на границах доменов передают состояние основному контроллеру и ПЛИС.",
      "refs": [
        "control_J400",
        "control_U400",
        "control_U401"
      ],
      "role": "power",
      "x": 40,
      "y": 60,
      "w": 300,
      "h": 150,
      "sceneId": "control-boundary",
      "sourceSheetIds": [
        "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_J400",
          "control_U400",
          "control_U401"
        ],
        "sheetIds": [
          "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE"
        ],
        "units": [
          {
            "component": "control_J400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 4
          },
          {
            "component": "control_U400",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 5
          },
          {
            "component": "control_U401",
            "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Приём питания и разрешений",
      "sourceSheetName": "INTERCONNECT",
      "sourceSheetId": "control_INTERCONNECT",
      "sourceFile": "INTERCONNECT.kicad_sch",
      "layoutRole": "gateway"
    },
    {
      "id": "host",
      "title": "MCU",
      "subtitle": "Управление экспериментом",
      "description": "STM32 управляет экспериментами, используя оперативную и постоянную память.",
      "refs": [
        "control_U100",
        "control_J100",
        "control_Y101",
        "control_J101",
        "control_Y100",
        "control_U200",
        "control_U300",
        "control_J300",
        "control_U302",
        "control_U301"
      ],
      "role": "data",
      "x": 510,
      "y": 60,
      "w": 410,
      "h": 210,
      "sceneId": "control-host",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "control_200_MCU_FMC_AND_SDRAM",
        "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
      ],
      "circuitGroup": {
        "refs": [
          "control_U100",
          "control_J100",
          "control_Y101",
          "control_J101",
          "control_Y100",
          "control_U200",
          "control_U300",
          "control_J300",
          "control_U302",
          "control_U301"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
          "control_200_MCU_FMC_AND_SDRAM",
          "control_300_MCU_QSPI_MICROSD_AND_CONTROL"
        ],
        "units": [
          {
            "component": "control_J100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_J101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_J300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 4
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 5
          },
          {
            "component": "control_U100",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 2
          },
          {
            "component": "control_U100",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 3
          },
          {
            "component": "control_U200",
            "sheet": "control_200_MCU_FMC_AND_SDRAM",
            "unit": 1
          },
          {
            "component": "control_U300",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U301",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_U302",
            "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
            "unit": 1
          },
          {
            "component": "control_Y100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_Y101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Управление экспериментом",
      "sourceSheetName": "MCU",
      "sourceSheetId": "control_MCU",
      "sourceFile": "MCU.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "fpga",
      "title": "FPGA",
      "subtitle": "Управление точным временем",
      "description": "ПЛИС загружает конфигурацию, обслуживает USB и Ethernet и управляет быстрым обменом данными.",
      "refs": [
        "control_U500",
        "control_U601",
        "control_J600",
        "control_U600",
        "control_U703",
        "control_U706",
        "control_U704",
        "control_U701",
        "control_U707",
        "control_U705"
      ],
      "role": "data",
      "x": 1010,
      "y": 45,
      "w": 410,
      "h": 210,
      "sceneId": "control-fpga",
      "sourceSheetIds": [
        "control_500_FPGA_POWER_AND_DECOUPLING",
        "control_600_FPGA_CONFIGURATION_AND_XADC",
        "control_700_FPGA_USB3_FIFO_INTERFACE",
        "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_U601",
          "control_J600",
          "control_U600",
          "control_U703",
          "control_U706",
          "control_U704",
          "control_U701",
          "control_U707",
          "control_U705"
        ],
        "sheetIds": [
          "control_500_FPGA_POWER_AND_DECOUPLING",
          "control_600_FPGA_CONFIGURATION_AND_XADC",
          "control_700_FPGA_USB3_FIFO_INTERFACE",
          "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
          "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
          "control_1200_DAC_FPGA_CONTROL_INTERFACE",
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_J600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
            "unit": 7
          },
          {
            "component": "control_U500",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 8
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 9
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 10
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 11
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 12
          },
          {
            "component": "control_U500",
            "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
            "unit": 13
          },
          {
            "component": "control_U500",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 2
          },
          {
            "component": "control_U500",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 5
          },
          {
            "component": "control_U500",
            "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
            "unit": 6
          },
          {
            "component": "control_U500",
            "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U601",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U701",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U703",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U704",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U705",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U706",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          }
        ]
      },
      "explanationTitleRu": "Управление точным временем",
      "sourceSheetName": "FPGA",
      "sourceSheetId": "control_FPGA",
      "sourceFile": "FPGA.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "sources",
      "title": "DAC",
      "subtitle": "Формирование аналоговых уставок",
      "description": "ЦАП и буферы формируют напряжения битовых линий, уставки операций и ограничения тока.",
      "refs": [
        "control_U1005",
        "control_U1010",
        "control_U1009",
        "control_U1008",
        "control_U1001",
        "control_U1007",
        "control_U1004",
        "control_U1011",
        "control_U1002",
        "control_U1006"
      ],
      "role": "analog",
      "x": 1530,
      "y": 60,
      "w": 300,
      "h": 156,
      "sceneId": "control-sources",
      "sourceSheetIds": [
        "control_1000_DAC_BL0_31_AND_BUFFERS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1005",
          "control_U1010",
          "control_U1009",
          "control_U1008",
          "control_U1001",
          "control_U1007",
          "control_U1004",
          "control_U1011",
          "control_U1002",
          "control_U1006"
        ],
        "sheetIds": [
          "control_1000_DAC_BL0_31_AND_BUFFERS"
        ],
        "units": [
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1001",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1002",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1004",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1005",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1006",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1007",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1008",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1009",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1010",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 1
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 2
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 3
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 4
          },
          {
            "component": "control_U1011",
            "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
            "unit": 5
          }
        ]
      },
      "explanationTitleRu": "Формирование аналоговых уставок",
      "sourceSheetName": "DAC",
      "sourceSheetId": "control_DAC",
      "sourceFile": "DAC.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "routing",
      "title": "MATRIX",
      "subtitle": "Коммутация пути через матрицу",
      "description": "Зафиксированная коммутация и селекторы подключают выбранный источник и обратный путь к матрице.",
      "refs": [
        "control_U1319",
        "control_U1306",
        "control_U1305",
        "control_U1304",
        "control_U1312",
        "control_U1313",
        "control_U1301",
        "control_U1320",
        "control_U1315",
        "control_U1316"
      ],
      "role": "analog",
      "x": 1500,
      "y": 465,
      "w": 410,
      "h": 210,
      "sceneId": "control-routing",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1319",
          "control_U1306",
          "control_U1305",
          "control_U1304",
          "control_U1312",
          "control_U1313",
          "control_U1301",
          "control_U1320",
          "control_U1315",
          "control_U1316"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_U1301",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1304",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1305",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1306",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1312",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1313",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1315",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1316",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1319",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1320",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Коммутация пути через матрицу",
      "sourceSheetName": "MATRIX",
      "sourceSheetId": "control_MATRIX",
      "sourceFile": "MATRIX.kicad_sch",
      "layoutRole": "primary"
    },
    {
      "id": "readout",
      "title": "ADC",
      "subtitle": "Преобразование тока матрицы в данные",
      "description": "Усилители и АЦП преобразуют электрический отклик в цифровые отсчёты.",
      "refs": [
        "control_U1901",
        "control_U1902",
        "control_U1900",
        "control_U1903",
        "control_U2000",
        "control_U2001",
        "control_U2002",
        "control_U2003",
        "control_U2004",
        "control_U2005"
      ],
      "role": "analog",
      "x": 990,
      "y": 480,
      "w": 320,
      "h": 165,
      "sceneId": "control-readout",
      "sourceSheetIds": [
        "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1901",
          "control_U1902",
          "control_U1900",
          "control_U1903",
          "control_U2000",
          "control_U2001",
          "control_U2002",
          "control_U2003",
          "control_U2004",
          "control_U2005"
        ],
        "sheetIds": [
          "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
          "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES"
        ],
        "units": [
          {
            "component": "control_U1900",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1901",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1902",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 1
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 2
          },
          {
            "component": "control_U1903",
            "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
            "unit": 3
          },
          {
            "component": "control_U2000",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2001",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2002",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2003",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2004",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          },
          {
            "component": "control_U2005",
            "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Преобразование тока матрицы в данные",
      "sourceSheetName": "ADC",
      "sourceSheetId": "control_ADC",
      "sourceFile": "ADC.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "regulation",
      "title": "PROTECTION",
      "subtitle": "Ограничение источника записи",
      "description": "Общий источник регулирует напряжение или ток перед сетью коммутации.",
      "refs": [
        "control_U2100",
        "control_U2103",
        "control_U2104",
        "control_U2109",
        "control_U2105",
        "control_U2106",
        "control_U2107",
        "control_U2101",
        "control_U2108"
      ],
      "role": "analog",
      "x": 480,
      "y": 470,
      "w": 320,
      "h": 164,
      "sceneId": "control_PROTECTION",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2100",
          "control_U2103",
          "control_U2104",
          "control_U2109",
          "control_U2105",
          "control_U2106",
          "control_U2107",
          "control_U2101",
          "control_U2108"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_U2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2101",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2104",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2108",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2109",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Ограничение источника записи",
      "sourceSheetName": "PROTECTION",
      "sourceSheetId": "control_PROTECTION",
      "sourceFile": "PROTECTION.kicad_sch",
      "layoutRole": "bank"
    },
    {
      "id": "safety",
      "title": "PROTECTION",
      "subtitle": "Остановка опасной операции",
      "description": "Независимая логика защиты запоминает аварию и снимает разрешение.",
      "refs": [
        "control_U2201",
        "control_U2200",
        "control_U2202",
        "control_U2203"
      ],
      "role": "fault",
      "x": 30,
      "y": 485,
      "w": 320,
      "h": 170,
      "sceneId": "control_PROTECTION",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2201",
          "control_U2200",
          "control_U2202",
          "control_U2203"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Остановка опасной операции",
      "sourceSheetName": "PROTECTION",
      "sourceSheetId": "control_PROTECTION",
      "sourceFile": "PROTECTION.kicad_sch",
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "boundary_host",
      "from": "boundary",
      "to": "host",
      "label": "Питание и контроль",
      "type": "power",
      "nets": [
        "control_net_90c4fa851afd",
        "control_net_cb711dcd1752",
        "control_net_df95db02c560",
        "control_net_7f8e95e35104",
        "control_net_9edec24f88a2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Питание / состояние",
      "netLabels": [
        "SYS3V3",
        "PM_UART_TX_HOST",
        "ALL_RAILS_PG_HOST",
        "GLOBAL_PWR_PERMIT_HOST",
        "MATRIX_PERMIT_HOST"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ALL_RAILS_PG_HOST",
        "GLOBAL_PWR_PERMIT_HOST",
        "MATRIX_PERMIT_HOST",
        "PM_UART_TX_HOST",
        "SYS3V3"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "host_fpga",
      "from": "host",
      "to": "fpga",
      "label": "Команды и состояние",
      "type": "control",
      "nets": [
        "control_net_e7c041fd6c4f",
        "control_net_f9eaf352353a",
        "control_net_9aff4b2212a6",
        "control_net_e84839bbf71f",
        "control_net_625cef89ab64",
        "control_net_e8d1c7605faf",
        "control_net_cdd2b08d9db8",
        "control_net_028458bc6a66",
        "control_net_189baa4e46d2",
        "control_net_ff9ff859ce5e",
        "control_net_101ecb817b3a"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Команды",
      "netLabels": [
        "FPGA_DONE_MCU",
        "FPGA_INIT_N_MCU",
        "MCU_FPGA_CS_N",
        "MCU_FPGA_SCK",
        "MCU_FPGA_MISO",
        "MCU_FPGA_MOSI",
        "FPGA_IRQ",
        "MCU_FPGA_MOSI_F",
        "MCU_FPGA_CS_N_F",
        "MCU_FPGA_MISO_F",
        "MCU_FPGA_SCK_F"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_DONE_MCU · FPGA_INIT_N_MCU",
        "MCU_FPGA_CS_N · ещё 8"
      ],
      "allConnectionsLabel": "Все соединения: 11",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_sources",
      "from": "fpga",
      "to": "sources",
      "label": "Последовательные уставки",
      "type": "control",
      "nets": [
        "control_net_8543c7028353",
        "control_net_8baeadc9d1f8",
        "control_net_7f616706cf93",
        "control_net_0d0a126b05bc",
        "control_net_2889fbee2814",
        "control_net_a2017f4fe37b",
        "control_net_90accaec6322",
        "control_net_bae01a82acc2",
        "control_net_fd8710ab620d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Уставки",
      "netLabels": [
        "CS_BL3",
        "DAC_SPI_SCK",
        "DAC_SPI_MOSI",
        "DAC_LDAC_N",
        "DAC_SPI_MISO",
        "DAC_RESET_N",
        "CS_BL0",
        "CS_BL1",
        "CS_BL2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CS_BL3 · DAC_SPI_SCK",
        "DAC_SPI_MOSI · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 9",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sources_routing",
      "from": "sources",
      "to": "routing",
      "label": "32 напряжения битовых линий",
      "type": "analog",
      "nets": [
        "control_net_43c57dc0fd8c",
        "control_net_8d6768741a17",
        "control_net_d7baf045ad36",
        "control_net_beae8f10af57",
        "control_net_08cafd4a06b1",
        "control_net_d2e352168d81",
        "control_net_339e997cde5d",
        "control_net_78c06670fbe2",
        "control_net_ecfae2e6bc3f",
        "control_net_de495400ab4d",
        "control_net_a25f83c5766f",
        "control_net_957e25b7b62b",
        "control_net_6c5bac16ddbe",
        "control_net_b00353d4bc57",
        "control_net_a555576805ce",
        "control_net_795fcecf8d80",
        "control_net_5357ea4931e2",
        "control_net_e3f04569205d",
        "control_net_d3cbff2509ef",
        "control_net_aa72e4d066e3",
        "control_net_9a9cf021ea69",
        "control_net_8ae61bd6427a",
        "control_net_c2ddd031305c",
        "control_net_9a9241c5281b",
        "control_net_a21df6263907",
        "control_net_728a06da1431",
        "control_net_8247058ba4d6",
        "control_net_0b4fec439a85",
        "control_net_053310f9940f",
        "control_net_6a631d5bc074",
        "control_net_05e96fc05120",
        "control_net_c3b76f2a4b40"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "32 аналоговых напряжения",
      "netLabels": [
        "BL_DAC22",
        "BL_DAC26",
        "BL_DAC1",
        "BL_DAC23",
        "BL_DAC6",
        "BL_DAC20",
        "BL_DAC7",
        "BL_DAC30",
        "BL_DAC29",
        "BL_DAC27",
        "BL_DAC28",
        "BL_DAC15",
        "BL_DAC21",
        "BL_DAC4",
        "BL_DAC24",
        "BL_DAC9",
        "BL_DAC31",
        "BL_DAC8",
        "BL_DAC18",
        "BL_DAC13",
        "BL_DAC11",
        "BL_DAC17",
        "BL_DAC25",
        "BL_DAC5",
        "BL_DAC3",
        "BL_DAC19",
        "BL_DAC2",
        "BL_DAC16",
        "BL_DAC12",
        "BL_DAC0",
        "BL_DAC14",
        "BL_DAC10"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BL_DAC22 · BL_DAC26",
        "BL_DAC1 · ещё 29"
      ],
      "allConnectionsLabel": "Все соединения: 32",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "sources_regulation",
      "from": "sources",
      "to": "regulation",
      "label": "Уставки напряжения / тока",
      "type": "analog",
      "nets": [
        "control_net_cac6d1065fe3",
        "control_net_03d282e4ab71",
        "control_net_992a28f1c452",
        "control_net_ca37f2f49804",
        "control_net_ba0a0fb27c13",
        "control_net_9f53cd2eaa32",
        "control_net_a6fb2d1ff68e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Уставки источника",
      "netLabels": [
        "ILIM_FORM",
        "VREAD_SRC",
        "VFORM_SRC",
        "ILIM_RESET",
        "VSET_SRC",
        "VRESET_SRC",
        "ILIM_SET"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ILIM_FORM · ILIM_RESET",
        "ILIM_SET · VFORM_SRC",
        "VREAD_SRC · VRESET_SRC",
        "VSET_SRC"
      ],
      "allConnectionsLabel": "Все соединения: 7",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "regulation_routing",
      "from": "regulation",
      "to": "routing",
      "label": "Регулируемый источник записи",
      "type": "analog",
      "nets": [
        "control_net_1d431849abfd",
        "control_net_87568f65b103",
        "control_net_c52050ba11fe",
        "control_net_55226bb23b92",
        "control_net_f0958a0c0c7d",
        "control_net_38a99a3de8c7",
        "control_net_cfdd109d7d0d",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_1c11014d6a17",
        "control_net_a752af94ed43"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Регулируемое воздействие",
      "netLabels": [
        "MAT_VTARGET",
        "MAT_SOURCE",
        "MAT_DRV_OUTPUT",
        "MAT_RSH_POWER",
        "MAT_REG_ERROR_SELECTED",
        "MAT_REG_ERROR",
        "MAT_SOURCE_OFF",
        "MAT_PI_RAW",
        "MAT_PI_SUM",
        "MAT_PI_RESET_C",
        "MAT_PI_C"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_VTARGET · MAT_SOURCE",
        "MAT_DRV_OUTPUT · ещё 8"
      ],
      "allConnectionsLabel": "Все соединения: 11",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_routing",
      "from": "fpga",
      "to": "routing",
      "label": "Режим, состояние ключей и время",
      "type": "control",
      "nets": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_a0f26e09322b",
        "control_net_770516324e4c",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_f05b5740e1a9",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_c4621dfd0ac4"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Коммутация / время",
      "netLabels": [
        "MAT_VMM_EN_REQ",
        "MAT_WRITE_EN_REQ",
        "MAT_READ_EN_REQ",
        "MAT_SERVICE_EN_REQ",
        "MAT_SPI_LATCH",
        "MAT_SPI_SCK",
        "MAT_PULSE",
        "MAT_SPI_OE_N",
        "MAT_BL_A2_REQ",
        "MAT_BL_A0_REQ",
        "MAT_BL_A1_REQ",
        "MAT_SPI_MOSI",
        "MAT_POLARITY_REQ",
        "MAT_NL_A1_REQ",
        "MAT_RSH_A0_REQ",
        "MAT_NL_A0_REQ",
        "MAT_RSH_A1_REQ",
        "MAT_BL_A4_REQ",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_BL_A3_REQ",
        "MAT_NL_A2_REQ",
        "MAT_FRAME_VALID"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_VMM_EN_REQ · MAT_WRITE_EN_REQ",
        "MAT_READ_EN_REQ · ещё 20"
      ],
      "allConnectionsLabel": "Все соединения: 23",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "routing_readout",
      "from": "routing",
      "to": "readout",
      "label": "Выбранный ток матрицы",
      "type": "analog",
      "nets": [
        "control_net_d65f00f0a2d4"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Ток матрицы",
      "netLabels": [
        "MAT_TIA_IN"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_TIA_IN"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "readout_fpga",
      "from": "readout",
      "to": "fpga",
      "label": "Цифровые результаты измерений",
      "type": "data",
      "nets": [
        "control_net_3be7162ce896",
        "control_net_3d36f9d91f43",
        "control_net_a1f3e5011080",
        "control_net_b97070122e98"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Отсчёты",
      "netLabels": [
        "MAT_ADC_SDO",
        "MAT_ADC_CNV",
        "MAT_ADC_SDI",
        "MAT_ADC_SCK"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ADC_CNV · MAT_ADC_SCK",
        "MAT_ADC_SDI · MAT_ADC_SDO"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "regulation_safety",
      "from": "regulation",
      "to": "safety",
      "label": "Независимый контроль тока источника",
      "type": "analog",
      "nets": [
        "control_net_fc57b8202dba",
        "control_net_7eb34b3468da"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Контроль тока",
      "netLabels": [
        "MAT_CC_SENSE_BUF",
        "MAT_ILIM_SENSE_BUF"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_CC_SENSE_BUF",
        "MAT_ILIM_SENSE_BUF"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "safety_routing",
      "from": "safety",
      "to": "routing",
      "label": "Авария и запрет",
      "type": "fault",
      "nets": [
        "control_net_6e0242cad116",
        "control_net_d4a1fffbf6b9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Авария / запрет",
      "netLabels": [
        "MAT_FAULT_N",
        "MAT_CONFIG_TRIP"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_FAULT_N",
        "MAT_CONFIG_TRIP"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P1",
        "title": "Авария / запрет"
      },
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "boundary_routing",
      "from": "boundary",
      "to": "routing",
      "label": "Разрешение матрицы",
      "type": "fault",
      "nets": [
        "control_net_3db345350ff9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Разрешение",
      "netLabels": [
        "MATRIX_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_PERMIT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "portal": {
        "code": "P2",
        "title": "MATRIX_PERMIT"
      },
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": -10,
    "y": 10,
    "w": 1960,
    "h": 705
  },
  "board": "control",
  "kind": "board",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_J400",
      "control_U400",
      "control_U401",
      "control_U100",
      "control_J100",
      "control_Y101",
      "control_J101",
      "control_Y100",
      "control_U200",
      "control_U300",
      "control_J300",
      "control_U302",
      "control_U301",
      "control_U500",
      "control_U601",
      "control_J600",
      "control_U600",
      "control_U703",
      "control_U706",
      "control_U704",
      "control_U701",
      "control_U707",
      "control_U705",
      "control_U1005",
      "control_U1010",
      "control_U1009",
      "control_U1008",
      "control_U1001",
      "control_U1007",
      "control_U1004",
      "control_U1011",
      "control_U1002",
      "control_U1006",
      "control_U1319",
      "control_U1306",
      "control_U1305",
      "control_U1304",
      "control_U1312",
      "control_U1313",
      "control_U1301",
      "control_U1320",
      "control_U1315",
      "control_U1316",
      "control_U1901",
      "control_U1902",
      "control_U1900",
      "control_U1903",
      "control_U2000",
      "control_U2001",
      "control_U2002",
      "control_U2003",
      "control_U2004",
      "control_U2005",
      "control_U2100",
      "control_U2103",
      "control_U2104",
      "control_U2109",
      "control_U2105",
      "control_U2106",
      "control_U2107",
      "control_U2101",
      "control_U2108",
      "control_U2201",
      "control_U2200",
      "control_U2202",
      "control_U2203"
    ],
    "sheetIds": [
      "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
      "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "control_200_MCU_FMC_AND_SDRAM",
      "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
      "control_500_FPGA_POWER_AND_DECOUPLING",
      "control_600_FPGA_CONFIGURATION_AND_XADC",
      "control_700_FPGA_USB3_FIFO_INTERFACE",
      "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "control_1200_DAC_FPGA_CONTROL_INTERFACE",
      "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "control_1000_DAC_BL0_31_AND_BUFFERS",
      "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
    ],
    "units": [
      {
        "component": "control_J400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U400",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 5
      },
      {
        "component": "control_U401",
        "sheet": "control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_J100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_J101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_J300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 4
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 5
      },
      {
        "component": "control_U100",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 2
      },
      {
        "component": "control_U100",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 3
      },
      {
        "component": "control_U200",
        "sheet": "control_200_MCU_FMC_AND_SDRAM",
        "unit": 1
      },
      {
        "component": "control_U300",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U301",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_U302",
        "sheet": "control_300_MCU_QSPI_MICROSD_AND_CONTROL",
        "unit": 1
      },
      {
        "component": "control_Y100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_Y101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_J600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_1200_DAC_FPGA_CONTROL_INTERFACE",
        "unit": 7
      },
      {
        "component": "control_U500",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 8
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 9
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 10
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 11
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 12
      },
      {
        "component": "control_U500",
        "sheet": "control_500_FPGA_POWER_AND_DECOUPLING",
        "unit": 13
      },
      {
        "component": "control_U500",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 2
      },
      {
        "component": "control_U500",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 5
      },
      {
        "component": "control_U500",
        "sheet": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "unit": 6
      },
      {
        "component": "control_U500",
        "sheet": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U601",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U701",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U703",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U704",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U705",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U706",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1001",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1002",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1004",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1005",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1006",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1007",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1008",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1009",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1010",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 1
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 2
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 3
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 4
      },
      {
        "component": "control_U1011",
        "sheet": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "unit": 5
      },
      {
        "component": "control_U1301",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1304",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1305",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1306",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1312",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1313",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1315",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1316",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1319",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1320",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1900",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1901",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1902",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 1
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 2
      },
      {
        "component": "control_U1903",
        "sheet": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "unit": 3
      },
      {
        "component": "control_U2000",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2001",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2002",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2003",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2004",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2005",
        "sheet": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "unit": 1
      },
      {
        "component": "control_U2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2101",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2104",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2108",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2109",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control"
  ],
  "suggestedScenario": "local-control",
  "explanationTitleRu": "Плата Control · от команды до измерения",
  "sourceSheetId": "control_MIRA_Control",
  "sourceSheetName": "MIRA_Control",
  "sourceFile": "MIRA_Control.kicad_sch",
  "nameSource": "root-filename",
  "hidden": false,
  "parentScene": "system",
  "layout": {
    "version": 2,
    "kind": "control-loop",
    "label": "Команды, воздействие и возврат результатов",
    "geometryOnly": true
  },
  "regions": []
};
