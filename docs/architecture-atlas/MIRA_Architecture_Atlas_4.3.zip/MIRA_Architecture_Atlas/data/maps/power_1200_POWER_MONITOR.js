/* Editable functional scene: power_1200_POWER_MONITOR */
window.MIRA_FUNCTIONAL.scenes["power_1200_POWER_MONITOR"]={
  "id": "power_1200_POWER_MONITOR",
  "title": "1200_POWER_MONITOR",
  "subtitle": "Питание ядра ПЛИС",
  "description": "U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход FPGA5V5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1200_POWER_MONITOR"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Питание ядра ПЛИС: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1201",
        "power_L1201",
        "power_R1202",
        "power_R1204",
        "power_R1208",
        "power_R1207"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1200_POWER_MONITOR",
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1201",
          "power_L1201",
          "power_R1202",
          "power_R1204",
          "power_R1208",
          "power_R1207"
        ],
        "sheetIds": [
          "power_1200_POWER_MONITOR"
        ],
        "units": [
          {
            "component": "power_L1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1202",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1204",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1207",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1208",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_U1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1201",
        "power_R1201"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1200_POWER_MONITOR",
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1201",
          "power_R1201"
        ],
        "sheetIds": [
          "power_1200_POWER_MONITOR"
        ],
        "units": [
          {
            "component": "power_Q1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1212",
        "power_C1206",
        "power_C1210",
        "power_C1207",
        "power_C1203",
        "power_C1202",
        "power_C1201",
        "power_C1209",
        "power_C1208",
        "power_C1204",
        "power_C1211",
        "power_C1205",
        "power_R1205",
        "power_R1203",
        "power_R1206"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1200_POWER_MONITOR",
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1212",
          "power_C1206",
          "power_C1210",
          "power_C1207",
          "power_C1203",
          "power_C1202",
          "power_C1201",
          "power_C1209",
          "power_C1208",
          "power_C1204",
          "power_C1211",
          "power_C1205",
          "power_R1205",
          "power_R1203",
          "power_R1206"
        ],
        "sheetIds": [
          "power_1200_POWER_MONITOR"
        ],
        "units": [
          {
            "component": "power_C1201",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1202",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1203",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1204",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1205",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1206",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1207",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1208",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1209",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1210",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1211",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_C1212",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1203",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1205",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          },
          {
            "component": "power_R1206",
            "sheet": "power_1200_POWER_MONITOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход CORE1V0",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1200_POWER_MONITOR"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1200_POWER_MONITOR"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_ef7fb27c478f",
        "power_net_717170b9d0c3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "CORE1V0",
        "CORE_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CORE1V0",
        "CORE_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "CORE1V0",
      "type": "power",
      "nets": [
        "power_net_ef7fb27c478f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "CORE1V0",
      "netLabels": [
        "CORE1V0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CORE1V0"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_3db57ce8c78a",
        "power_net_0828b35e4b6c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_CORE",
        "EN_CORE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_CORE",
        "EN_CORE"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1200_POWER_MONITOR",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 23,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1201",
      "power_L1201",
      "power_R1202",
      "power_R1204",
      "power_R1208",
      "power_R1207",
      "power_Q1201",
      "power_R1201",
      "power_C1212",
      "power_C1206",
      "power_C1210",
      "power_C1207",
      "power_C1203",
      "power_C1202",
      "power_C1201",
      "power_C1209",
      "power_C1208",
      "power_C1204",
      "power_C1211",
      "power_C1205",
      "power_R1205",
      "power_R1203",
      "power_R1206"
    ],
    "sheetIds": [
      "power_1200_POWER_MONITOR"
    ],
    "units": [
      {
        "component": "power_L1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1202",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1204",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1207",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1208",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_U1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_Q1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1201",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1202",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1203",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1204",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1205",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1206",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1207",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1208",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1209",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1210",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1211",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_C1212",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1203",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1205",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      },
      {
        "component": "power_R1206",
        "sheet": "power_1200_POWER_MONITOR",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1200_POWER_MONITOR"
  ],
  "suggestedScenario": "local-power_1200_POWER_MONITOR",
  "explanationTitleRu": "Питание ядра ПЛИС",
  "sourceSheetId": "power_1200_POWER_MONITOR",
  "sourceSheetName": "1200_POWER_MONITOR",
  "sourceFile": "1200_POWER_MONITOR.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
