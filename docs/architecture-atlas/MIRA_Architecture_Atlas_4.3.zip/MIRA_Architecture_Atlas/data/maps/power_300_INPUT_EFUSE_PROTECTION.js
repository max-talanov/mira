/* Editable functional scene: power_300_INPUT_EFUSE_PROTECTION */
window.MIRA_FUNCTIONAL.scenes["power_300_INPUT_EFUSE_PROTECTION"]={
  "id": "power_300_INPUT_EFUSE_PROTECTION",
  "title": "300_INPUT_EFUSE_PROTECTION",
  "subtitle": "Ограничение и отключение питания",
  "description": "U301 TPS26631 и внешние Q301/Q302 обеспечивают управляемую входную защиту, плавное включение и сигналы аварии и состояния.",
  "nodes": [
    {
      "id": "efuse",
      "title": "Ограничение и отключение тока",
      "subtitle": "",
      "description": "Электронный предохранитель управляет защищённым питанием и реакцией на аварию.",
      "refs": [
        "power_U301",
        "power_R308",
        "power_R310",
        "power_C303",
        "power_C305",
        "power_R302",
        "power_R303",
        "power_R307",
        "power_C304",
        "power_R301",
        "power_R309",
        "power_R305"
      ],
      "role": "power",
      "x": 560,
      "y": 285,
      "w": 350,
      "h": 184,
      "sheetId": "power_300_INPUT_EFUSE_PROTECTION",
      "sourceSheetIds": [
        "power_300_INPUT_EFUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_U301",
          "power_R308",
          "power_R310",
          "power_C303",
          "power_C305",
          "power_R302",
          "power_R303",
          "power_R307",
          "power_C304",
          "power_R301",
          "power_R309",
          "power_R305"
        ],
        "sheetIds": [
          "power_300_INPUT_EFUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_C303",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_C304",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_C305",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R302",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R303",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R305",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R307",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R308",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R309",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R310",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_U301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "reverse",
      "title": "Защита от обратного тока",
      "subtitle": "",
      "description": "Последовательный MOSFET и связанный диод образуют показанный в схеме путь входной защиты.",
      "refs": [
        "power_Q301",
        "power_D301",
        "power_C302",
        "power_C301"
      ],
      "role": "power",
      "x": 40,
      "y": 60,
      "w": 250,
      "h": 136,
      "sheetId": "power_300_INPUT_EFUSE_PROTECTION",
      "sourceSheetIds": [
        "power_300_INPUT_EFUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q301",
          "power_D301",
          "power_C302",
          "power_C301"
        ],
        "sheetIds": [
          "power_300_INPUT_EFUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_C301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_C302",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_D301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_Q301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "enable",
      "title": "Управление и индикация питания",
      "subtitle": "",
      "description": "Цепи управления, перемычка и индикация задают поведение при запуске.",
      "refs": [
        "power_Q302",
        "power_JP301",
        "power_D302",
        "power_R306",
        "power_R304"
      ],
      "role": "control",
      "x": 40,
      "y": 565,
      "w": 240,
      "h": 124,
      "sheetId": "power_300_INPUT_EFUSE_PROTECTION",
      "sourceSheetIds": [
        "power_300_INPUT_EFUSE_PROTECTION"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q302",
          "power_JP301",
          "power_D302",
          "power_R306",
          "power_R304"
        ],
        "sheetIds": [
          "power_300_INPUT_EFUSE_PROTECTION"
        ],
        "units": [
          {
            "component": "power_D302",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_JP301",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_Q302",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R304",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          },
          {
            "component": "power_R306",
            "sheet": "power_300_INPUT_EFUSE_PROTECTION",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "efuse_reverse",
      "from": "efuse",
      "to": "reverse",
      "label": "3 цепи",
      "type": "data",
      "nets": [
        "power_net_a837894762cd",
        "power_net_3dcac14084cf",
        "power_net_3937c8c839ac"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "3 цепи",
      "netLabels": [
        "EFUSE_OUT"
      ],
      "unnamedNetIds": [
        "power_net_3dcac14084cf",
        "power_net_3937c8c839ac"
      ],
      "labelLines": [
        "EFUSE_OUT"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "efuse_enable",
      "from": "efuse",
      "to": "enable",
      "label": "5 цепей",
      "type": "data",
      "nets": [
        "power_net_0118a5d9fdb8",
        "power_net_3dcac14084cf",
        "power_net_fc972acc08ff",
        "power_net_9517f7952aef",
        "power_net_35045b6a457d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "5 цепей",
      "netLabels": [
        "FLT_INPUT_N"
      ],
      "unnamedNetIds": [
        "power_net_0118a5d9fdb8",
        "power_net_3dcac14084cf",
        "power_net_fc972acc08ff",
        "power_net_9517f7952aef"
      ],
      "labelLines": [
        "FLT_INPUT_N"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "reverse_enable",
      "from": "reverse",
      "to": "enable",
      "label": "1 цепь",
      "type": "data",
      "nets": [
        "power_net_3dcac14084cf"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "1 цепь",
      "netLabels": [],
      "unnamedNetIds": [
        "power_net_3dcac14084cf"
      ],
      "labelLines": [],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 950,
    "h": 704
  },
  "board": "power",
  "sheetId": "power_300_INPUT_EFUSE_PROTECTION",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 21,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U301",
      "power_R308",
      "power_R310",
      "power_C303",
      "power_C305",
      "power_R302",
      "power_R303",
      "power_R307",
      "power_C304",
      "power_R301",
      "power_R309",
      "power_R305",
      "power_Q301",
      "power_D301",
      "power_C302",
      "power_C301",
      "power_Q302",
      "power_JP301",
      "power_D302",
      "power_R306",
      "power_R304"
    ],
    "sheetIds": [
      "power_300_INPUT_EFUSE_PROTECTION"
    ],
    "units": [
      {
        "component": "power_C303",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_C304",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_C305",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R302",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R303",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R305",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R307",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R308",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R309",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R310",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_U301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_C301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_C302",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_Q301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_D302",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_JP301",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_Q302",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R304",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      },
      {
        "component": "power_R306",
        "sheet": "power_300_INPUT_EFUSE_PROTECTION",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_300_INPUT_EFUSE_PROTECTION"
  ],
  "suggestedScenario": "local-power_300_INPUT_EFUSE_PROTECTION",
  "explanationTitleRu": "Ограничение и отключение питания",
  "sourceSheetId": "power_300_INPUT_EFUSE_PROTECTION",
  "sourceSheetName": "300_INPUT_EFUSE_PROTECTION",
  "sourceFile": "300_INPUT_EFUSE_PROTECTION.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-input",
  "layout": {
    "version": 2,
    "kind": "functional-hub",
    "label": "Главный узел и две связанные функции",
    "geometryOnly": true
  },
  "regions": []
};
