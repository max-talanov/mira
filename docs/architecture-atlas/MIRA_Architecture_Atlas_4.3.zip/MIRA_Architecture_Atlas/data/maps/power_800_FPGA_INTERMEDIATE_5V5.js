/* Editable functional scene: power_800_FPGA_INTERMEDIATE_5V5 */
window.MIRA_FUNCTIONAL.scenes["power_800_FPGA_INTERMEDIATE_5V5"]={
  "id": "power_800_FPGA_INTERMEDIATE_5V5",
  "title": "800_FPGA_INTERMEDIATE_5V5",
  "subtitle": "Промежуточное питание ПЛИС",
  "description": "U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_800_FPGA_INTERMEDIATE_5V5"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_800_FPGA_INTERMEDIATE_5V5"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Промежуточное питание ПЛИС: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U801",
        "power_L801",
        "power_R801"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_800_FPGA_INTERMEDIATE_5V5",
      "sourceSheetIds": [
        "power_800_FPGA_INTERMEDIATE_5V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_U801",
          "power_L801",
          "power_R801"
        ],
        "sheetIds": [
          "power_800_FPGA_INTERMEDIATE_5V5"
        ],
        "units": [
          {
            "component": "power_L801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_R801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_U801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q801",
        "power_R802"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_800_FPGA_INTERMEDIATE_5V5",
      "sourceSheetIds": [
        "power_800_FPGA_INTERMEDIATE_5V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q801",
          "power_R802"
        ],
        "sheetIds": [
          "power_800_FPGA_INTERMEDIATE_5V5"
        ],
        "units": [
          {
            "component": "power_Q801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_R802",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C814",
        "power_C806",
        "power_C801",
        "power_C811",
        "power_C803",
        "power_C809",
        "power_C808",
        "power_C807",
        "power_C810",
        "power_C804",
        "power_C802",
        "power_C813",
        "power_C805",
        "power_C812",
        "power_R806",
        "power_D801",
        "power_R805",
        "power_R804",
        "power_R803"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_800_FPGA_INTERMEDIATE_5V5",
      "sourceSheetIds": [
        "power_800_FPGA_INTERMEDIATE_5V5"
      ],
      "circuitGroup": {
        "refs": [
          "power_C814",
          "power_C806",
          "power_C801",
          "power_C811",
          "power_C803",
          "power_C809",
          "power_C808",
          "power_C807",
          "power_C810",
          "power_C804",
          "power_C802",
          "power_C813",
          "power_C805",
          "power_C812",
          "power_R806",
          "power_D801",
          "power_R805",
          "power_R804",
          "power_R803"
        ],
        "sheetIds": [
          "power_800_FPGA_INTERMEDIATE_5V5"
        ],
        "units": [
          {
            "component": "power_C801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C802",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C803",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C804",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C805",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C806",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C807",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C808",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C809",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C810",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C811",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C812",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C813",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_C814",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_D801",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_R803",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_R804",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_R805",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          },
          {
            "component": "power_R806",
            "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход FPGA5V5",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_800_FPGA_INTERMEDIATE_5V5"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_800_FPGA_INTERMEDIATE_5V5"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_20b613e14cd0",
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "FPGA_RAW",
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_RAW",
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_7f7616523bf4",
        "power_net_08c3817ee687"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_FPGA",
        "EN_FPGA"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_FPGA",
        "EN_FPGA"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_800_FPGA_INTERMEDIATE_5V5",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 24,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U801",
      "power_L801",
      "power_R801",
      "power_Q801",
      "power_R802",
      "power_C814",
      "power_C806",
      "power_C801",
      "power_C811",
      "power_C803",
      "power_C809",
      "power_C808",
      "power_C807",
      "power_C810",
      "power_C804",
      "power_C802",
      "power_C813",
      "power_C805",
      "power_C812",
      "power_R806",
      "power_D801",
      "power_R805",
      "power_R804",
      "power_R803"
    ],
    "sheetIds": [
      "power_800_FPGA_INTERMEDIATE_5V5"
    ],
    "units": [
      {
        "component": "power_L801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_R801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_U801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_Q801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_R802",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C802",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C803",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C804",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C805",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C806",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C807",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C808",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C809",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C810",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C811",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C812",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C813",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_C814",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_D801",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_R803",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_R804",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_R805",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      },
      {
        "component": "power_R806",
        "sheet": "power_800_FPGA_INTERMEDIATE_5V5",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_800_FPGA_INTERMEDIATE_5V5"
  ],
  "suggestedScenario": "local-power_800_FPGA_INTERMEDIATE_5V5",
  "explanationTitleRu": "Промежуточное питание ПЛИС",
  "sourceSheetId": "power_800_FPGA_INTERMEDIATE_5V5",
  "sourceSheetName": "800_FPGA_INTERMEDIATE_5V5",
  "sourceFile": "800_FPGA_INTERMEDIATE_5V5.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
