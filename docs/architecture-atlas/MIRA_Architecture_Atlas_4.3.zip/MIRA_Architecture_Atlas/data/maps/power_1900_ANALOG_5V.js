/* Editable functional scene: power_1900_ANALOG_5V */
window.MIRA_FUNCTIONAL.scenes["power_1900_ANALOG_5V"]={
  "id": "power_1900_ANALOG_5V",
  "title": "1900_ANALOG_5V",
  "subtitle": "Малошумящее аналоговое питание 5 В",
  "description": "U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход ANA6",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1900_ANALOG_5V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1900_ANALOG_5V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Малошумящее аналоговое питание 5 В: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1901",
        "power_R1902"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1900_ANALOG_5V",
      "sourceSheetIds": [
        "power_1900_ANALOG_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1901",
          "power_R1902"
        ],
        "sheetIds": [
          "power_1900_ANALOG_5V"
        ],
        "units": [
          {
            "component": "power_R1902",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_U1901",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1901",
        "power_R1901"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1900_ANALOG_5V",
      "sourceSheetIds": [
        "power_1900_ANALOG_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1901",
          "power_R1901"
        ],
        "sheetIds": [
          "power_1900_ANALOG_5V"
        ],
        "units": [
          {
            "component": "power_Q1901",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_R1901",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1901",
        "power_C1904",
        "power_C1903",
        "power_C1902",
        "power_R1906",
        "power_R1904",
        "power_R1905",
        "power_R1903"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1900_ANALOG_5V",
      "sourceSheetIds": [
        "power_1900_ANALOG_5V"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1901",
          "power_C1904",
          "power_C1903",
          "power_C1902",
          "power_R1906",
          "power_R1904",
          "power_R1905",
          "power_R1903"
        ],
        "sheetIds": [
          "power_1900_ANALOG_5V"
        ],
        "units": [
          {
            "component": "power_C1901",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_C1902",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_C1903",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_C1904",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_R1903",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_R1904",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_R1905",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          },
          {
            "component": "power_R1906",
            "sheet": "power_1900_ANALOG_5V",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход ANA5",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1900_ANALOG_5V"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1900_ANALOG_5V"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "ANA6",
      "type": "power",
      "nets": [
        "power_net_bbc855740138"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "ANA6",
      "netLabels": [
        "ANA6"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA6"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_99aaef80128f",
        "power_net_664171b20ecf",
        "power_net_f5932d689562",
        "power_net_4716fe94234d",
        "power_net_d033005e565e",
        "power_net_f8cf954155c7"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "PGR_ANA5",
        "CMD_ANA5",
        "ANA5",
        "ANA5_RAW",
        "FB_ANA5",
        "EN_ANA5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA5 · ANA5_RAW",
        "CMD_ANA5 · EN_ANA5",
        "FB_ANA5 · PGR_ANA5"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "ANA5",
      "type": "power",
      "nets": [
        "power_net_f5932d689562"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "ANA5",
      "netLabels": [
        "ANA5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "ANA5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_664171b20ecf",
        "power_net_f8cf954155c7"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_ANA5",
        "EN_ANA5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA5",
        "EN_ANA5"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1900_ANALOG_5V",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 12,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1901",
      "power_R1902",
      "power_Q1901",
      "power_R1901",
      "power_C1901",
      "power_C1904",
      "power_C1903",
      "power_C1902",
      "power_R1906",
      "power_R1904",
      "power_R1905",
      "power_R1903"
    ],
    "sheetIds": [
      "power_1900_ANALOG_5V"
    ],
    "units": [
      {
        "component": "power_R1902",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_U1901",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_Q1901",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_R1901",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_C1901",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_C1902",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_C1903",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_C1904",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_R1903",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_R1904",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_R1905",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      },
      {
        "component": "power_R1906",
        "sheet": "power_1900_ANALOG_5V",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1900_ANALOG_5V"
  ],
  "suggestedScenario": "local-power_1900_ANALOG_5V",
  "explanationTitleRu": "Малошумящее аналоговое питание 5 В",
  "sourceSheetId": "power_1900_ANALOG_5V",
  "sourceSheetName": "1900_ANALOG_5V",
  "sourceFile": "1900_ANALOG_5V.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
