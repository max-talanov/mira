/* Editable functional scene: power_2600_PM_PERMIT_INTERLOCKS */
window.MIRA_FUNCTIONAL.scenes["power_2600_PM_PERMIT_INTERLOCKS"]={
  "id": "power_2600_PM_PERMIT_INTERLOCKS",
  "title": "2600_PM_PERMIT_INTERLOCKS",
  "subtitle": "Аппаратные разрешения и блокировки",
  "description": "Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы.",
  "nodes": [
    {
      "id": "stop",
      "title": "Приём остановки и блокировок",
      "subtitle": "",
      "description": "Внешние контакты и аппаратная блокировка могут снять разрешение.",
      "refs": [
        "power_J2601",
        "power_J2602",
        "power_J2603"
      ],
      "role": "fault",
      "x": 40,
      "y": 190,
      "w": 270,
      "h": 145,
      "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sourceSheetIds": [
        "power_2600_PM_PERMIT_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "power_J2601",
          "power_J2602",
          "power_J2603"
        ],
        "sheetIds": [
          "power_2600_PM_PERMIT_INTERLOCKS"
        ],
        "units": [
          {
            "component": "power_J2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_J2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_J2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "qualify",
      "title": "Проверка условий безопасности",
      "subtitle": "",
      "description": "Аппаратная логика выдаёт разрешение только при выполнении необходимых условий.",
      "refs": [
        "power_U2601",
        "power_U2602",
        "power_C2602",
        "power_R2603",
        "power_C2601"
      ],
      "role": "fault",
      "x": 560,
      "y": 160,
      "w": 370,
      "h": 194,
      "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sourceSheetIds": [
        "power_2600_PM_PERMIT_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2601",
          "power_U2602",
          "power_C2602",
          "power_R2603",
          "power_C2601"
        ],
        "sheetIds": [
          "power_2600_PM_PERMIT_INTERLOCKS"
        ],
        "units": [
          {
            "component": "power_C2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_C2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "memory",
      "title": "Фиксация снятого разрешения",
      "subtitle": "",
      "description": "Триггеры сохраняют разрешение или аварийное состояние до повторного взвода.",
      "refs": [
        "power_U2603",
        "power_R2607",
        "power_C2603",
        "power_R2606"
      ],
      "role": "fault",
      "x": 1140,
      "y": 165,
      "w": 290,
      "h": 158,
      "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sourceSheetIds": [
        "power_2600_PM_PERMIT_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2603",
          "power_R2607",
          "power_C2603",
          "power_R2606"
        ],
        "sheetIds": [
          "power_2600_PM_PERMIT_INTERLOCKS"
        ],
        "units": [
          {
            "component": "power_C2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2606",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2607",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_U2603",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Вывод разрешений и запретов",
      "subtitle": "",
      "description": "Транзисторы формируют показанный на схеме интерфейс разрешения и запрета.",
      "refs": [
        "power_Q2601",
        "power_Q2602",
        "power_R2605",
        "power_R2601",
        "power_R2604",
        "power_R2602"
      ],
      "role": "fault",
      "x": 1140,
      "y": 535,
      "w": 290,
      "h": 150,
      "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
      "sourceSheetIds": [
        "power_2600_PM_PERMIT_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q2601",
          "power_Q2602",
          "power_R2605",
          "power_R2601",
          "power_R2604",
          "power_R2602"
        ],
        "sheetIds": [
          "power_2600_PM_PERMIT_INTERLOCKS"
        ],
        "units": [
          {
            "component": "power_Q2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_Q2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2601",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2602",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2604",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "power_R2605",
            "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "stop_qualify",
      "from": "stop",
      "to": "qualify",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_d27f47724845",
        "power_net_e9a19d60b5ab"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "MATRIX_INHIBIT_N"
      ],
      "unnamedNetIds": [
        "power_net_e9a19d60b5ab"
      ],
      "labelLines": [
        "MATRIX_INHIBIT_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "stop_memory",
      "from": "stop",
      "to": "memory",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_5a1f578d112a",
        "power_net_3b9ee406a281"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "MATRIX_PERMIT",
        "MATRIX_KILL_H"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_PERMIT",
        "MATRIX_KILL_H"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "stop_output",
      "from": "stop",
      "to": "output",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_d27f47724845",
        "power_net_e9a19d60b5ab"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "MATRIX_INHIBIT_N"
      ],
      "unnamedNetIds": [
        "power_net_e9a19d60b5ab"
      ],
      "labelLines": [
        "MATRIX_INHIBIT_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "qualify_memory",
      "from": "qualify",
      "to": "memory",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_8828c890966d",
        "power_net_0d67fdbc5a0d",
        "power_net_bc6b8848cad9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "GLOBAL_PWR_PERMIT",
        "GLOBAL_CLEAR_N",
        "MATRIX_CLEAR_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "GLOBAL_CLEAR_N",
        "GLOBAL_PWR_PERMIT",
        "MATRIX_CLEAR_N"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "qualify_output",
      "from": "qualify",
      "to": "output",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "power_net_d27f47724845",
        "power_net_e9a19d60b5ab"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "MATRIX_INHIBIT_N"
      ],
      "unnamedNetIds": [
        "power_net_e9a19d60b5ab"
      ],
      "labelLines": [
        "MATRIX_INHIBIT_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 125,
    "w": 1470,
    "h": 600
  },
  "board": "power",
  "sheetId": "power_2600_PM_PERMIT_INTERLOCKS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 18,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J2601",
      "power_J2602",
      "power_J2603",
      "power_U2601",
      "power_U2602",
      "power_C2602",
      "power_R2603",
      "power_C2601",
      "power_U2603",
      "power_R2607",
      "power_C2603",
      "power_R2606",
      "power_Q2601",
      "power_Q2602",
      "power_R2605",
      "power_R2601",
      "power_R2604",
      "power_R2602"
    ],
    "sheetIds": [
      "power_2600_PM_PERMIT_INTERLOCKS"
    ],
    "units": [
      {
        "component": "power_J2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_J2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_J2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_C2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_C2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_C2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2606",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2607",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_U2603",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_Q2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_Q2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2601",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2602",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2604",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "power_R2605",
        "sheet": "power_2600_PM_PERMIT_INTERLOCKS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2600_PM_PERMIT_INTERLOCKS"
  ],
  "suggestedScenario": "local-power_2600_PM_PERMIT_INTERLOCKS",
  "explanationTitleRu": "Аппаратные разрешения и блокировки",
  "sourceSheetId": "power_2600_PM_PERMIT_INTERLOCKS",
  "sourceSheetName": "2600_PM_PERMIT_INTERLOCKS",
  "sourceFile": "2600_PM_PERMIT_INTERLOCKS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "permit-qualification",
    "label": "Условия безопасности, память состояния и выход разрешения",
    "geometryOnly": true
  },
  "regions": []
};
