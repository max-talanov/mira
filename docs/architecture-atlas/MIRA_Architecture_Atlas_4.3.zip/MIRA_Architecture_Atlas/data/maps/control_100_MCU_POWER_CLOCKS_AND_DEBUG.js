/* Editable functional scene: control_100_MCU_POWER_CLOCKS_AND_DEBUG */
window.MIRA_FUNCTIONAL.scenes["control_100_MCU_POWER_CLOCKS_AND_DEBUG"]={
  "id": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
  "title": "100_MCU_POWER_CLOCKS_AND_DEBUG",
  "subtitle": "Основной контроллер · запуск и отладка",
  "description": "U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.",
  "nodes": [
    {
      "id": "fast",
      "title": "Основной тактовый источник",
      "subtitle": "",
      "description": "Генератор 25 МГц задаёт тактирование основного контроллера.",
      "refs": [
        "control_Y100",
        "control_R101",
        "control_C129"
      ],
      "role": "control",
      "x": 40,
      "y": 80,
      "w": 260,
      "h": 140,
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_Y100",
          "control_R101",
          "control_C129"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_C129",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_R101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_Y100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "host",
      "title": "Выполнение эксперимента",
      "subtitle": "",
      "description": "STM32H745 выполняет основную программу и контролирует работу платы.",
      "refs": [
        "control_U100",
        "control_R105"
      ],
      "role": "data",
      "x": 565,
      "y": 305,
      "w": 350,
      "h": 190,
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_U100",
          "control_R105"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_R105",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 4
          },
          {
            "component": "control_U100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 5
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "debug",
      "title": "Программирование и отладка",
      "subtitle": "",
      "description": "Через отладочный разъём внешний отладчик программирует STM32 и наблюдает его состояние.",
      "refs": [
        "control_J100",
        "control_R104",
        "control_R103"
      ],
      "role": "data",
      "x": 1180,
      "y": 80,
      "w": 280,
      "h": 148,
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_J100",
          "control_R104",
          "control_R103"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_J100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_R103",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_R104",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "slow",
      "title": "Низкочастотное тактирование",
      "subtitle": "",
      "description": "Отдельный кварц 32,768 кГц обеспечивает низкочастотное тактирование.",
      "refs": [
        "control_Y101",
        "control_C131",
        "control_C130"
      ],
      "role": "control",
      "x": 40,
      "y": 580,
      "w": 260,
      "h": 140,
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_Y101",
          "control_C131",
          "control_C130"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_C130",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C131",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_Y101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "start",
      "title": "Сброс и выбор загрузки",
      "subtitle": "",
      "description": "Кнопка сброса перезапускает контроллер; перемычка BOOT выбирает режим загрузки.",
      "refs": [
        "control_J101",
        "control_SW100",
        "control_R102",
        "control_R106",
        "control_C132"
      ],
      "role": "control",
      "x": 1180,
      "y": 580,
      "w": 260,
      "h": 140,
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_J101",
          "control_SW100",
          "control_R102",
          "control_R106",
          "control_C132"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_C132",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_J101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_R102",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_R106",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_SW100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "supply",
      "title": "Локальное питание контроллера",
      "subtitle": "",
      "description": "Локальные конденсаторы поддерживают питание контроллера и его внутреннего стабилизатора.",
      "refs": [
        "control_C100",
        "control_C101",
        "control_C102",
        "control_C103",
        "control_C104",
        "control_C105",
        "control_C106",
        "control_C107",
        "control_C108",
        "control_C109",
        "control_C110",
        "control_C111",
        "control_C112",
        "control_C113",
        "control_C114",
        "control_C115",
        "control_C116",
        "control_C117",
        "control_C118",
        "control_C119",
        "control_C120",
        "control_C121",
        "control_C122",
        "control_C123",
        "control_C124",
        "control_C128",
        "control_C127",
        "control_C125",
        "control_C126",
        "control_R100"
      ],
      "role": "power",
      "x": 590,
      "y": -80,
      "w": 260,
      "h": 136,
      "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
      "sourceSheetIds": [
        "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
      ],
      "circuitGroup": {
        "refs": [
          "control_C100",
          "control_C101",
          "control_C102",
          "control_C103",
          "control_C104",
          "control_C105",
          "control_C106",
          "control_C107",
          "control_C108",
          "control_C109",
          "control_C110",
          "control_C111",
          "control_C112",
          "control_C113",
          "control_C114",
          "control_C115",
          "control_C116",
          "control_C117",
          "control_C118",
          "control_C119",
          "control_C120",
          "control_C121",
          "control_C122",
          "control_C123",
          "control_C124",
          "control_C128",
          "control_C127",
          "control_C125",
          "control_C126",
          "control_R100"
        ],
        "sheetIds": [
          "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
        ],
        "units": [
          {
            "component": "control_C100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C101",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C102",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C103",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C104",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C105",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C106",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C107",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C108",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C109",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C110",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C111",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C112",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C113",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C114",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C115",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C116",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C117",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C118",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C119",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C120",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C121",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C122",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C123",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C124",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C125",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C126",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C127",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_C128",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          },
          {
            "component": "control_R100",
            "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "fast_host_0",
      "from": "fast",
      "to": "host",
      "label": "Тактирование 25 МГц",
      "type": "control",
      "nets": [
        "control_net_7a4e5a463be4",
        "control_net_a38bef0f0104"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Тактирование 25 МГц",
      "netLabels": [
        "MCU_HSE_CLK",
        "MCU_HSE_XO"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MCU_HSE_CLK",
        "MCU_HSE_XO"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "slow_host_1",
      "from": "slow",
      "to": "host",
      "label": "Низкочастотное тактирование",
      "type": "control",
      "nets": [
        "control_net_03fabe1e0e1e",
        "control_net_78e8fc2cd369"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Низкочастотное тактирование",
      "netLabels": [
        "MCU_LSE_IN",
        "MCU_LSE_OUT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MCU_LSE_IN",
        "MCU_LSE_OUT"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "start_host_2",
      "from": "start",
      "to": "host",
      "label": "Сброс / выбор загрузки",
      "type": "control",
      "nets": [
        "control_net_9529eebe621c",
        "control_net_0cbb519cdc03"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Сброс / выбор загрузки",
      "netLabels": [
        "MCU_BOOT0",
        "HOST_RESET_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MCU_BOOT0",
        "HOST_RESET_N"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "debug_host_3",
      "from": "debug",
      "to": "host",
      "label": "Доступ отладчика",
      "type": "data",
      "nets": [
        "control_net_360449ac40c1",
        "control_net_c76cd2a32b0e",
        "control_net_750a12d376b8",
        "control_net_6d1eda208f89",
        "control_net_e478289ae762"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Доступ отладчика",
      "netLabels": [
        "MCU_SWDIO",
        "MCU_SWCLK",
        "MCU_SWO",
        "DEBUG_SWDIO",
        "DEBUG_SWCLK"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "DEBUG_SWCLK · DEBUG_SWDIO",
        "MCU_SWCLK · MCU_SWDIO",
        "MCU_SWO"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "supply_host_4",
      "from": "supply",
      "to": "host",
      "label": "Питание и локальные конденсаторы",
      "type": "power",
      "nets": [
        "control_net_90c4fa851afd",
        "control_net_d9a5590f95c8",
        "control_net_90afbe6c9420"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Локальное питание",
      "netLabels": [
        "SYS3V3",
        "MCU_VDDA",
        "MCU_VCAP"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MCU_VCAP · MCU_VDDA",
        "SYS3V3"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": -115,
    "w": 1500,
    "h": 875
  },
  "board": "control",
  "sheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 46,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_Y100",
      "control_R101",
      "control_C129",
      "control_U100",
      "control_R105",
      "control_J100",
      "control_R104",
      "control_R103",
      "control_Y101",
      "control_C131",
      "control_C130",
      "control_J101",
      "control_SW100",
      "control_R102",
      "control_R106",
      "control_C132",
      "control_C100",
      "control_C101",
      "control_C102",
      "control_C103",
      "control_C104",
      "control_C105",
      "control_C106",
      "control_C107",
      "control_C108",
      "control_C109",
      "control_C110",
      "control_C111",
      "control_C112",
      "control_C113",
      "control_C114",
      "control_C115",
      "control_C116",
      "control_C117",
      "control_C118",
      "control_C119",
      "control_C120",
      "control_C121",
      "control_C122",
      "control_C123",
      "control_C124",
      "control_C128",
      "control_C127",
      "control_C125",
      "control_C126",
      "control_R100"
    ],
    "sheetIds": [
      "control_100_MCU_POWER_CLOCKS_AND_DEBUG"
    ],
    "units": [
      {
        "component": "control_C129",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_Y100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R105",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 4
      },
      {
        "component": "control_U100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 5
      },
      {
        "component": "control_J100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R103",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R104",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C130",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C131",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_Y101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C132",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_J101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R102",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R106",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_SW100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C101",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C102",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C103",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C104",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C105",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C106",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C107",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C108",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C109",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C110",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C111",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C112",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C113",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C114",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C115",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C116",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C117",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C118",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C119",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C120",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C121",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C122",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C123",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C124",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C125",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C126",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C127",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_C128",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      },
      {
        "component": "control_R100",
        "sheet": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_100_MCU_POWER_CLOCKS_AND_DEBUG"
  ],
  "suggestedScenario": "local-control_100_MCU_POWER_CLOCKS_AND_DEBUG",
  "explanationTitleRu": "Основной контроллер · запуск и отладка",
  "sourceSheetId": "control_100_MCU_POWER_CLOCKS_AND_DEBUG",
  "sourceSheetName": "100_MCU_POWER_CLOCKS_AND_DEBUG",
  "sourceFile": "100_MCU_POWER_CLOCKS_AND_DEBUG.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-host",
  "layout": {
    "version": 2,
    "kind": "processor-hub",
    "label": "Контроллер в центре, обслуживающие функции вокруг",
    "geometryOnly": true
  },
  "regions": []
};
