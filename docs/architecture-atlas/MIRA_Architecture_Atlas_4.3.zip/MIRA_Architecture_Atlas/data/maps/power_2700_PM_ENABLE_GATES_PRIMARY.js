/* Editable functional scene: power_2700_PM_ENABLE_GATES_PRIMARY */
window.MIRA_FUNCTIONAL.scenes["power_2700_PM_ENABLE_GATES_PRIMARY"]={
  "id": "power_2700_PM_ENABLE_GATES_PRIMARY",
  "title": "2700_PM_ENABLE_GATES_PRIMARY",
  "subtitle": "Разрешения основных преобразователей",
  "description": "U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением.",
  "nodes": [
    {
      "id": "first",
      "title": "Первая группа разрешений",
      "subtitle": "",
      "description": "Каждый логический элемент объединяет запрос включения с соответствующим аппаратным разрешением.",
      "refs": [
        "power_U2701"
      ],
      "role": "control",
      "x": 40,
      "y": 70,
      "w": 350,
      "h": 184,
      "sheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "sourceSheetIds": [
        "power_2700_PM_ENABLE_GATES_PRIMARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2701"
        ],
        "sheetIds": [
          "power_2700_PM_ENABLE_GATES_PRIMARY"
        ],
        "units": [
          {
            "component": "power_U2701",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "second",
      "title": "Вторая группа разрешений",
      "subtitle": "",
      "description": "Остальные логические элементы независимо проверяют запросы своих преобразователей.",
      "refs": [
        "power_U2702"
      ],
      "role": "control",
      "x": 670,
      "y": 70,
      "w": 350,
      "h": 184,
      "sheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "sourceSheetIds": [
        "power_2700_PM_ENABLE_GATES_PRIMARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2702"
        ],
        "sheetIds": [
          "power_2700_PM_ENABLE_GATES_PRIMARY"
        ],
        "units": [
          {
            "component": "power_U2702",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "default",
      "title": "Выключение по умолчанию",
      "subtitle": "",
      "description": "Подтягивающие резисторы задают определённые начальные состояния команд.",
      "refs": [
        "power_R2704",
        "power_R2702",
        "power_R2711",
        "power_R2701",
        "power_R2708",
        "power_R2706",
        "power_R2705",
        "power_R2715",
        "power_R2707",
        "power_R2714",
        "power_R2713",
        "power_R2710",
        "power_R2716",
        "power_R2703",
        "power_R2712",
        "power_R2709",
        "power_C2701",
        "power_C2702"
      ],
      "role": "fault",
      "x": 395,
      "y": 510,
      "w": 250,
      "h": 132,
      "sheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
      "sourceSheetIds": [
        "power_2700_PM_ENABLE_GATES_PRIMARY"
      ],
      "circuitGroup": {
        "refs": [
          "power_R2704",
          "power_R2702",
          "power_R2711",
          "power_R2701",
          "power_R2708",
          "power_R2706",
          "power_R2705",
          "power_R2715",
          "power_R2707",
          "power_R2714",
          "power_R2713",
          "power_R2710",
          "power_R2716",
          "power_R2703",
          "power_R2712",
          "power_R2709",
          "power_C2701",
          "power_C2702"
        ],
        "sheetIds": [
          "power_2700_PM_ENABLE_GATES_PRIMARY"
        ],
        "units": [
          {
            "component": "power_C2701",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_C2702",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2701",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2702",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2703",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2704",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2705",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2706",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2707",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2708",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2709",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2710",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2711",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2712",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2713",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2714",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2715",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          },
          {
            "component": "power_R2716",
            "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "first_second",
      "from": "first",
      "to": "second",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_8828c890966d"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "GLOBAL_PWR_PERMIT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "GLOBAL_PWR_PERMIT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "first_default",
      "from": "first",
      "to": "default",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_f4716909bd0c",
        "power_net_c19f5798f458",
        "power_net_c66ec173184e",
        "power_net_83fb386e92c5",
        "power_net_6649c6cdd008",
        "power_net_9020238d369a",
        "power_net_7f7616523bf4",
        "power_net_6220152fdd65"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "EN_REQ_USB",
        "EN_REQ_SYS",
        "EN_REQ_FPGA",
        "EN_REQ_ANA",
        "CMD_USB",
        "CMD_SYS",
        "CMD_FPGA",
        "CMD_ANA"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_ANA · CMD_FPGA",
        "CMD_SYS · CMD_USB",
        "EN_REQ_ANA · EN_REQ_FPGA",
        "EN_REQ_SYS · EN_REQ_USB"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "second_default",
      "from": "second",
      "to": "default",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_c876bbd15aa2",
        "power_net_5a10e16f7ce2",
        "power_net_1f6f0734f873",
        "power_net_afa5c4d57041",
        "power_net_35be90fefcdd",
        "power_net_afd79c7e6e58",
        "power_net_3db57ce8c78a",
        "power_net_9693d69e08e6"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "EN_REQ_P15",
        "EN_REQ_N15",
        "EN_REQ_CORE",
        "EN_REQ_AUX18",
        "CMD_P15",
        "CMD_N15",
        "CMD_CORE",
        "CMD_AUX18"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_AUX18 · CMD_CORE",
        "CMD_N15 · CMD_P15",
        "EN_REQ_AUX18 · EN_REQ_CORE",
        "EN_REQ_N15 · EN_REQ_P15"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 1060,
    "h": 647
  },
  "board": "power",
  "sheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 20,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U2701",
      "power_U2702",
      "power_R2704",
      "power_R2702",
      "power_R2711",
      "power_R2701",
      "power_R2708",
      "power_R2706",
      "power_R2705",
      "power_R2715",
      "power_R2707",
      "power_R2714",
      "power_R2713",
      "power_R2710",
      "power_R2716",
      "power_R2703",
      "power_R2712",
      "power_R2709",
      "power_C2701",
      "power_C2702"
    ],
    "sheetIds": [
      "power_2700_PM_ENABLE_GATES_PRIMARY"
    ],
    "units": [
      {
        "component": "power_U2701",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_U2702",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_C2701",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_C2702",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2701",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2702",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2703",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2704",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2705",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2706",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2707",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2708",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2709",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2710",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2711",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2712",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2713",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2714",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2715",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      },
      {
        "component": "power_R2716",
        "sheet": "power_2700_PM_ENABLE_GATES_PRIMARY",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2700_PM_ENABLE_GATES_PRIMARY"
  ],
  "suggestedScenario": "local-power_2700_PM_ENABLE_GATES_PRIMARY",
  "explanationTitleRu": "Разрешения основных преобразователей",
  "sourceSheetId": "power_2700_PM_ENABLE_GATES_PRIMARY",
  "sourceSheetName": "2700_PM_ENABLE_GATES_PRIMARY",
  "sourceFile": "2700_PM_ENABLE_GATES_PRIMARY.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "enable-banks-with-default",
    "label": "Две группы разрешений; начальные состояния сбоку от основного пути",
    "geometryOnly": true
  },
  "regions": []
};
