/* Editable functional scene: power_100_INPUT_CONNECTOR */
window.MIRA_FUNCTIONAL.scenes["power_100_INPUT_CONNECTOR"]={
  "id": "power_100_INPUT_CONNECTOR",
  "title": "100_INPUT_CONNECTOR",
  "subtitle": "Подключение внешних 24 В",
  "description": "J101 принимает внешнее питание постоянного тока. D101/D102 показывают полярность до последующих узлов защиты.",
  "nodes": [
    {
      "id": "connector",
      "title": "Приём внешнего питания",
      "subtitle": "",
      "description": "Клеммный разъём принимает внешнее положительное питание и общий провод.",
      "refs": [
        "power_J101"
      ],
      "role": "power",
      "x": 40,
      "y": 100,
      "w": 350,
      "h": 184,
      "sheetId": "power_100_INPUT_CONNECTOR",
      "sourceSheetIds": [
        "power_100_INPUT_CONNECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_J101"
        ],
        "sheetIds": [
          "power_100_INPUT_CONNECTOR"
        ],
        "units": [
          {
            "component": "power_J101",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "indicators",
      "title": "Индикация входного питания",
      "subtitle": "",
      "description": "Цепи индикации показывают состояние входного питания согласно схеме.",
      "refs": [
        "power_D101",
        "power_D102",
        "power_R101"
      ],
      "role": "control",
      "x": 660,
      "y": 360,
      "w": 250,
      "h": 132,
      "sheetId": "power_100_INPUT_CONNECTOR",
      "sourceSheetIds": [
        "power_100_INPUT_CONNECTOR"
      ],
      "circuitGroup": {
        "refs": [
          "power_D101",
          "power_D102",
          "power_R101"
        ],
        "sheetIds": [
          "power_100_INPUT_CONNECTOR"
        ],
        "units": [
          {
            "component": "power_D101",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          },
          {
            "component": "power_D102",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          },
          {
            "component": "power_R101",
            "sheet": "power_100_INPUT_CONNECTOR",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "connector_indicators",
      "from": "connector",
      "to": "indicators",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_6741c8732f40"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "+24V_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "+24V_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 65,
    "w": 950,
    "h": 467
  },
  "board": "power",
  "sheetId": "power_100_INPUT_CONNECTOR",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 4,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J101",
      "power_D101",
      "power_D102",
      "power_R101"
    ],
    "sheetIds": [
      "power_100_INPUT_CONNECTOR"
    ],
    "units": [
      {
        "component": "power_J101",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      },
      {
        "component": "power_D101",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      },
      {
        "component": "power_D102",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      },
      {
        "component": "power_R101",
        "sheet": "power_100_INPUT_CONNECTOR",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_100_INPUT_CONNECTOR"
  ],
  "suggestedScenario": "local-power_100_INPUT_CONNECTOR",
  "explanationTitleRu": "Подключение внешних 24 В",
  "sourceSheetId": "power_100_INPUT_CONNECTOR",
  "sourceSheetName": "100_INPUT_CONNECTOR",
  "sourceFile": "100_INPUT_CONNECTOR.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-input",
  "layout": {
    "version": 2,
    "kind": "connector-with-indication",
    "label": "Разъём во входном пути, индикация отдельной ветвью",
    "geometryOnly": true
  },
  "regions": []
};
