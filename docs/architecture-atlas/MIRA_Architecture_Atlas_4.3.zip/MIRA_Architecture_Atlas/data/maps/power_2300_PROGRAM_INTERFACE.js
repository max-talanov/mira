/* Editable functional scene: power_2300_PROGRAM_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["power_2300_PROGRAM_INTERFACE"]={
  "id": "power_2300_PROGRAM_INTERFACE",
  "title": "2300_PROGRAM_INTERFACE",
  "subtitle": "Разъём питания программирования",
  "description": "J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.",
  "nodes": [
    {
      "id": "connector",
      "title": "Вывод питания программирования",
      "subtitle": "",
      "description": "Разъём выводит коммутируемое положительное и отрицательное питание программирования.",
      "refs": [
        "power_J2301"
      ],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 350,
      "h": 184,
      "sheetId": "power_2300_PROGRAM_INTERFACE",
      "sourceSheetIds": [
        "power_2300_PROGRAM_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_J2301"
        ],
        "sheetIds": [
          "power_2300_PROGRAM_INTERFACE"
        ],
        "units": [
          {
            "component": "power_J2301",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "monitor",
      "title": "Подготовка сигнала контроля",
      "subtitle": "",
      "description": "Локальный делитель и ограничитель подготавливают сигнал измерения питания программирования.",
      "refs": [
        "power_D2301",
        "power_R2302",
        "power_R2303",
        "power_R2301",
        "power_C2301"
      ],
      "role": "analog",
      "x": 760,
      "y": 195,
      "w": 280,
      "h": 150,
      "sheetId": "power_2300_PROGRAM_INTERFACE",
      "sourceSheetIds": [
        "power_2300_PROGRAM_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "power_D2301",
          "power_R2302",
          "power_R2303",
          "power_R2301",
          "power_C2301"
        ],
        "sheetIds": [
          "power_2300_PROGRAM_INTERFACE"
        ],
        "units": [
          {
            "component": "power_C2301",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_D2301",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R2301",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R2302",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          },
          {
            "component": "power_R2303",
            "sheet": "power_2300_PROGRAM_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "connector_monitor",
      "from": "connector",
      "to": "monitor",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_7267dc19b659"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "PROG_P15"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PROG_P15"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1080,
    "h": 259
  },
  "board": "power",
  "sheetId": "power_2300_PROGRAM_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 6,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_J2301",
      "power_D2301",
      "power_R2302",
      "power_R2303",
      "power_R2301",
      "power_C2301"
    ],
    "sheetIds": [
      "power_2300_PROGRAM_INTERFACE"
    ],
    "units": [
      {
        "component": "power_J2301",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_C2301",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_D2301",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R2301",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R2302",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      },
      {
        "component": "power_R2303",
        "sheet": "power_2300_PROGRAM_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2300_PROGRAM_INTERFACE"
  ],
  "suggestedScenario": "local-power_2300_PROGRAM_INTERFACE",
  "explanationTitleRu": "Разъём питания программирования",
  "sourceSheetId": "power_2300_PROGRAM_INTERFACE",
  "sourceSheetName": "2300_PROGRAM_INTERFACE",
  "sourceFile": "2300_PROGRAM_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-program",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
