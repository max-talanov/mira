/* Editable functional scene: power_3000_PM_RAIL_READY */
window.MIRA_FUNCTIONAL.scenes["power_3000_PM_RAIL_READY"]={
  "id": "power_3000_PM_RAIL_READY",
  "title": "3000_PM_RAIL_READY",
  "subtitle": "Готовность напряжений питания",
  "description": "U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений.",
  "nodes": [
    {
      "id": "0",
      "title": "Готовность основных шин",
      "subtitle": "",
      "description": "Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.",
      "refs": [
        "power_U3001",
        "power_C3001"
      ],
      "role": "control",
      "x": 40,
      "y": 60,
      "w": 290,
      "h": 154,
      "sheetId": "power_3000_PM_RAIL_READY",
      "sourceSheetIds": [
        "power_3000_PM_RAIL_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3001",
          "power_C3001"
        ],
        "sheetIds": [
          "power_3000_PM_RAIL_READY"
        ],
        "units": [
          {
            "component": "power_C3001",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          },
          {
            "component": "power_U3001",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "1",
      "title": "Готовность вспомогательных шин",
      "subtitle": "",
      "description": "Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.",
      "refs": [
        "power_U3017",
        "power_C3002"
      ],
      "role": "control",
      "x": 40,
      "y": 450,
      "w": 290,
      "h": 154,
      "sheetId": "power_3000_PM_RAIL_READY",
      "sourceSheetIds": [
        "power_3000_PM_RAIL_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3017",
          "power_C3002"
        ],
        "sheetIds": [
          "power_3000_PM_RAIL_READY"
        ],
        "units": [
          {
            "component": "power_C3002",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          },
          {
            "component": "power_U3017",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "2",
      "title": "Итоговая готовность",
      "subtitle": "",
      "description": "Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.",
      "refs": [
        "power_U3018",
        "power_C3003"
      ],
      "role": "control",
      "x": 720,
      "y": 240,
      "w": 370,
      "h": 194,
      "sheetId": "power_3000_PM_RAIL_READY",
      "sourceSheetIds": [
        "power_3000_PM_RAIL_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3018",
          "power_C3003"
        ],
        "sheetIds": [
          "power_3000_PM_RAIL_READY"
        ],
        "units": [
          {
            "component": "power_C3003",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          },
          {
            "component": "power_U3018",
            "sheet": "power_3000_PM_RAIL_READY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "0_2",
      "from": "0",
      "to": "2",
      "label": "2 цепи",
      "type": "control",
      "nets": [
        "power_net_5b1bf737eaa4",
        "power_net_0c68cab570db"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "PG_GROUP_0",
        "PG_GROUP_1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PG_GROUP_0",
        "PG_GROUP_1"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "1_2",
      "from": "1",
      "to": "2",
      "label": "2 цепи",
      "type": "control",
      "nets": [
        "power_net_534223a3e24d",
        "power_net_9d522f9a0fb2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "PG_GROUP_2",
        "PG_GROUP_3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "PG_GROUP_2",
        "PG_GROUP_3"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 1130,
    "h": 619
  },
  "board": "power",
  "sheetId": "power_3000_PM_RAIL_READY",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 6,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3001",
      "power_C3001",
      "power_U3017",
      "power_C3002",
      "power_U3018",
      "power_C3003"
    ],
    "sheetIds": [
      "power_3000_PM_RAIL_READY"
    ],
    "units": [
      {
        "component": "power_C3001",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_U3001",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_C3002",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_U3017",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_C3003",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      },
      {
        "component": "power_U3018",
        "sheet": "power_3000_PM_RAIL_READY",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3000_PM_RAIL_READY"
  ],
  "suggestedScenario": "local-power_3000_PM_RAIL_READY",
  "explanationTitleRu": "Готовность напряжений питания",
  "sourceSheetId": "power_3000_PM_RAIL_READY",
  "sourceSheetName": "3000_PM_RAIL_READY",
  "sourceFile": "3000_PM_RAIL_READY.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "readiness-combiner",
    "label": "Две группы условий сходятся в итоговую готовность",
    "geometryOnly": true
  },
  "regions": []
};
