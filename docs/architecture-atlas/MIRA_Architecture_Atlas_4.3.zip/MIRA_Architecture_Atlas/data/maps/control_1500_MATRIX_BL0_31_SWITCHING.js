/* Editable functional scene: control_1500_MATRIX_BL0_31_SWITCHING */
window.MIRA_FUNCTIONAL.scenes["control_1500_MATRIX_BL0_31_SWITCHING"]={
  "id": "control_1500_MATRIX_BL0_31_SWITCHING",
  "title": "1500_MATRIX_BL0_31_SWITCHING",
  "subtitle": "Коммутация битовых линий матрицы",
  "description": "Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение.",
  "nodes": [
    {
      "id": "bank0",
      "title": "Коммутация BL0–7",
      "subtitle": "",
      "description": "Ключи подключают выходы ЦАП, заземляющие зажимы и выбранный сервисный путь этой группы линий.",
      "refs": [
        "control_U1500",
        "control_U1501",
        "control_U1502",
        "control_U1503",
        "control_U1516",
        "control_R1522",
        "control_R1515",
        "control_C1524",
        "control_C1503",
        "control_R1520",
        "control_R1508",
        "control_R1519",
        "control_R1505",
        "control_R1511",
        "control_C1500",
        "control_R1510",
        "control_C1525",
        "control_C1506",
        "control_R1506",
        "control_R1504",
        "control_R1514",
        "control_R1507",
        "control_C1502",
        "control_R1516",
        "control_R1517",
        "control_R1501",
        "control_R1500",
        "control_C1505",
        "control_C1523",
        "control_R1502",
        "control_C1501",
        "control_R1523",
        "control_R1512",
        "control_R1513",
        "control_C1504",
        "control_R1521",
        "control_R1509",
        "control_R1503",
        "control_R1518"
      ],
      "role": "analog",
      "x": 40,
      "y": 60,
      "w": 330,
      "h": 166,
      "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sourceSheetIds": [
        "control_1500_MATRIX_BL0_31_SWITCHING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1500",
          "control_U1501",
          "control_U1502",
          "control_U1503",
          "control_U1516",
          "control_R1522",
          "control_R1515",
          "control_C1524",
          "control_C1503",
          "control_R1520",
          "control_R1508",
          "control_R1519",
          "control_R1505",
          "control_R1511",
          "control_C1500",
          "control_R1510",
          "control_C1525",
          "control_C1506",
          "control_R1506",
          "control_R1504",
          "control_R1514",
          "control_R1507",
          "control_C1502",
          "control_R1516",
          "control_R1517",
          "control_R1501",
          "control_R1500",
          "control_C1505",
          "control_C1523",
          "control_R1502",
          "control_C1501",
          "control_R1523",
          "control_R1512",
          "control_R1513",
          "control_C1504",
          "control_R1521",
          "control_R1509",
          "control_R1503",
          "control_R1518"
        ],
        "sheetIds": [
          "control_1500_MATRIX_BL0_31_SWITCHING"
        ],
        "units": [
          {
            "component": "control_C1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1523",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1524",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1525",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1516",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1517",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1518",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1519",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1520",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1521",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1522",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1523",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1500",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1501",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1502",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1503",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1516",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "bank1",
      "title": "Коммутация BL8–15",
      "subtitle": "",
      "description": "Вторая группа коммутирует ещё восемь битовых линий.",
      "refs": [
        "control_U1504",
        "control_U1505",
        "control_U1506",
        "control_U1507",
        "control_U1517",
        "control_R1527",
        "control_R1541",
        "control_R1546",
        "control_R1544",
        "control_R1525",
        "control_C1513",
        "control_C1507",
        "control_R1534",
        "control_R1526",
        "control_C1509",
        "control_R1539",
        "control_R1531",
        "control_C1511",
        "control_R1532",
        "control_C1512",
        "control_C1510",
        "control_R1536",
        "control_R1543",
        "control_R1545",
        "control_R1540",
        "control_R1529",
        "control_R1530",
        "control_C1514",
        "control_C1528",
        "control_C1508",
        "control_C1526",
        "control_R1596",
        "control_R1547",
        "control_R1537",
        "control_R1533",
        "control_R1528",
        "control_R1542",
        "control_R1524",
        "control_R1538",
        "control_R1535",
        "control_C1527"
      ],
      "role": "analog",
      "x": 730,
      "y": 60,
      "w": 330,
      "h": 166,
      "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sourceSheetIds": [
        "control_1500_MATRIX_BL0_31_SWITCHING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1504",
          "control_U1505",
          "control_U1506",
          "control_U1507",
          "control_U1517",
          "control_R1527",
          "control_R1541",
          "control_R1546",
          "control_R1544",
          "control_R1525",
          "control_C1513",
          "control_C1507",
          "control_R1534",
          "control_R1526",
          "control_C1509",
          "control_R1539",
          "control_R1531",
          "control_C1511",
          "control_R1532",
          "control_C1512",
          "control_C1510",
          "control_R1536",
          "control_R1543",
          "control_R1545",
          "control_R1540",
          "control_R1529",
          "control_R1530",
          "control_C1514",
          "control_C1528",
          "control_C1508",
          "control_C1526",
          "control_R1596",
          "control_R1547",
          "control_R1537",
          "control_R1533",
          "control_R1528",
          "control_R1542",
          "control_R1524",
          "control_R1538",
          "control_R1535",
          "control_C1527"
        ],
        "sheetIds": [
          "control_1500_MATRIX_BL0_31_SWITCHING"
        ],
        "units": [
          {
            "component": "control_C1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1526",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1527",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1528",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1524",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1525",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1526",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1527",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1528",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1529",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1530",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1531",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1532",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1533",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1534",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1535",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1536",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1537",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1538",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1539",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1540",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1541",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1542",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1543",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1544",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1545",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1546",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1547",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1596",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1504",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1505",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1506",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1507",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1517",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "bank2",
      "title": "Коммутация BL16–23",
      "subtitle": "",
      "description": "Третья группа коммутирует ещё восемь битовых линий.",
      "refs": [
        "control_U1508",
        "control_U1509",
        "control_U1510",
        "control_U1511",
        "control_U1518",
        "control_R1559",
        "control_R1553",
        "control_C1516",
        "control_R1571",
        "control_C1515",
        "control_C1517",
        "control_R1556",
        "control_R1558",
        "control_R1548",
        "control_C1518",
        "control_R1562",
        "control_R1570",
        "control_C1520",
        "control_C1531",
        "control_R1569",
        "control_R1560",
        "control_C1532",
        "control_R1552",
        "control_R1568",
        "control_R1561",
        "control_C1521",
        "control_R1566",
        "control_R1597",
        "control_R1550",
        "control_C1530",
        "control_R1565",
        "control_R1564",
        "control_R1554",
        "control_R1563",
        "control_R1557",
        "control_R1549",
        "control_R1555",
        "control_R1567",
        "control_R1551",
        "control_C1519"
      ],
      "role": "analog",
      "x": 40,
      "y": 470,
      "w": 330,
      "h": 166,
      "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sourceSheetIds": [
        "control_1500_MATRIX_BL0_31_SWITCHING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1508",
          "control_U1509",
          "control_U1510",
          "control_U1511",
          "control_U1518",
          "control_R1559",
          "control_R1553",
          "control_C1516",
          "control_R1571",
          "control_C1515",
          "control_C1517",
          "control_R1556",
          "control_R1558",
          "control_R1548",
          "control_C1518",
          "control_R1562",
          "control_R1570",
          "control_C1520",
          "control_C1531",
          "control_R1569",
          "control_R1560",
          "control_C1532",
          "control_R1552",
          "control_R1568",
          "control_R1561",
          "control_C1521",
          "control_R1566",
          "control_R1597",
          "control_R1550",
          "control_C1530",
          "control_R1565",
          "control_R1564",
          "control_R1554",
          "control_R1563",
          "control_R1557",
          "control_R1549",
          "control_R1555",
          "control_R1567",
          "control_R1551",
          "control_C1519"
        ],
        "sheetIds": [
          "control_1500_MATRIX_BL0_31_SWITCHING"
        ],
        "units": [
          {
            "component": "control_C1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1516",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1517",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1518",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1519",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1520",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1521",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1530",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1531",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1532",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1548",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1549",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1550",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1551",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1552",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1553",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1554",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1555",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1556",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1557",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1558",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1559",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1560",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1561",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1562",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1563",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1564",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1565",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1566",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1567",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1568",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1569",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1570",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1571",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1597",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1508",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1509",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1510",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1511",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1518",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "bank3",
      "title": "Коммутация BL24–31",
      "subtitle": "",
      "description": "Последняя группа завершает 32 канала коммутации битовых линий.",
      "refs": [
        "control_U1512",
        "control_U1513",
        "control_U1514",
        "control_U1515",
        "control_U1519",
        "control_R1576",
        "control_R1580",
        "control_C1541",
        "control_C1529",
        "control_R1584",
        "control_C1534",
        "control_C1538",
        "control_R1593",
        "control_R1594",
        "control_C1536",
        "control_R1591",
        "control_C1522",
        "control_R1577",
        "control_R1598",
        "control_R1575",
        "control_R1573",
        "control_R1599",
        "control_R1578",
        "control_C1542",
        "control_R1572",
        "control_R1586",
        "control_R1590",
        "control_R1588",
        "control_R1574",
        "control_C1537",
        "control_R1581",
        "control_R1585",
        "control_R1592",
        "control_R1595",
        "control_C1540",
        "control_C1533",
        "control_R1582",
        "control_R1583",
        "control_C1539",
        "control_R1579",
        "control_C1543",
        "control_C1535",
        "control_R1587",
        "control_R1589"
      ],
      "role": "analog",
      "x": 730,
      "y": 470,
      "w": 330,
      "h": 166,
      "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
      "sourceSheetIds": [
        "control_1500_MATRIX_BL0_31_SWITCHING"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1512",
          "control_U1513",
          "control_U1514",
          "control_U1515",
          "control_U1519",
          "control_R1576",
          "control_R1580",
          "control_C1541",
          "control_C1529",
          "control_R1584",
          "control_C1534",
          "control_C1538",
          "control_R1593",
          "control_R1594",
          "control_C1536",
          "control_R1591",
          "control_C1522",
          "control_R1577",
          "control_R1598",
          "control_R1575",
          "control_R1573",
          "control_R1599",
          "control_R1578",
          "control_C1542",
          "control_R1572",
          "control_R1586",
          "control_R1590",
          "control_R1588",
          "control_R1574",
          "control_C1537",
          "control_R1581",
          "control_R1585",
          "control_R1592",
          "control_R1595",
          "control_C1540",
          "control_C1533",
          "control_R1582",
          "control_R1583",
          "control_C1539",
          "control_R1579",
          "control_C1543",
          "control_C1535",
          "control_R1587",
          "control_R1589"
        ],
        "sheetIds": [
          "control_1500_MATRIX_BL0_31_SWITCHING"
        ],
        "units": [
          {
            "component": "control_C1522",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1529",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1533",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1534",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1535",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1536",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1537",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1538",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1539",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1540",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1541",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1542",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_C1543",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1572",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1573",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1574",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1575",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1576",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1577",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1578",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1579",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1580",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1581",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1582",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1583",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1584",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1585",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1586",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1587",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1588",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1589",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1590",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1591",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1592",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1593",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1594",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1595",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1598",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_R1599",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1512",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1513",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1514",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          },
          {
            "component": "control_U1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 2
          },
          {
            "component": "control_U1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 3
          },
          {
            "component": "control_U1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 4
          },
          {
            "component": "control_U1515",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 5
          },
          {
            "component": "control_U1519",
            "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    }
  ],
  "edges": [
    {
      "id": "bank0_bank1",
      "from": "bank0",
      "to": "bank1",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "bank0_bank2",
      "from": "bank0",
      "to": "bank2",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "bank0_bank3",
      "from": "bank0",
      "to": "bank3",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "bank1_bank2",
      "from": "bank1",
      "to": "bank2",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "bank1_bank3",
      "from": "bank1",
      "to": "bank3",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "bank2_bank3",
      "from": "bank2",
      "to": "bank3",
      "label": "4 цепи",
      "type": "analog",
      "nets": [
        "control_net_209d9624cc4d",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "MAT_SERVICE_SAFE",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_SERVICE_SAFE"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 1100,
    "h": 651
  },
  "board": "control",
  "sheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 164,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U1500",
      "control_U1501",
      "control_U1502",
      "control_U1503",
      "control_U1516",
      "control_R1522",
      "control_R1515",
      "control_C1524",
      "control_C1503",
      "control_R1520",
      "control_R1508",
      "control_R1519",
      "control_R1505",
      "control_R1511",
      "control_C1500",
      "control_R1510",
      "control_C1525",
      "control_C1506",
      "control_R1506",
      "control_R1504",
      "control_R1514",
      "control_R1507",
      "control_C1502",
      "control_R1516",
      "control_R1517",
      "control_R1501",
      "control_R1500",
      "control_C1505",
      "control_C1523",
      "control_R1502",
      "control_C1501",
      "control_R1523",
      "control_R1512",
      "control_R1513",
      "control_C1504",
      "control_R1521",
      "control_R1509",
      "control_R1503",
      "control_R1518",
      "control_U1504",
      "control_U1505",
      "control_U1506",
      "control_U1507",
      "control_U1517",
      "control_R1527",
      "control_R1541",
      "control_R1546",
      "control_R1544",
      "control_R1525",
      "control_C1513",
      "control_C1507",
      "control_R1534",
      "control_R1526",
      "control_C1509",
      "control_R1539",
      "control_R1531",
      "control_C1511",
      "control_R1532",
      "control_C1512",
      "control_C1510",
      "control_R1536",
      "control_R1543",
      "control_R1545",
      "control_R1540",
      "control_R1529",
      "control_R1530",
      "control_C1514",
      "control_C1528",
      "control_C1508",
      "control_C1526",
      "control_R1596",
      "control_R1547",
      "control_R1537",
      "control_R1533",
      "control_R1528",
      "control_R1542",
      "control_R1524",
      "control_R1538",
      "control_R1535",
      "control_C1527",
      "control_U1508",
      "control_U1509",
      "control_U1510",
      "control_U1511",
      "control_U1518",
      "control_R1559",
      "control_R1553",
      "control_C1516",
      "control_R1571",
      "control_C1515",
      "control_C1517",
      "control_R1556",
      "control_R1558",
      "control_R1548",
      "control_C1518",
      "control_R1562",
      "control_R1570",
      "control_C1520",
      "control_C1531",
      "control_R1569",
      "control_R1560",
      "control_C1532",
      "control_R1552",
      "control_R1568",
      "control_R1561",
      "control_C1521",
      "control_R1566",
      "control_R1597",
      "control_R1550",
      "control_C1530",
      "control_R1565",
      "control_R1564",
      "control_R1554",
      "control_R1563",
      "control_R1557",
      "control_R1549",
      "control_R1555",
      "control_R1567",
      "control_R1551",
      "control_C1519",
      "control_U1512",
      "control_U1513",
      "control_U1514",
      "control_U1515",
      "control_U1519",
      "control_R1576",
      "control_R1580",
      "control_C1541",
      "control_C1529",
      "control_R1584",
      "control_C1534",
      "control_C1538",
      "control_R1593",
      "control_R1594",
      "control_C1536",
      "control_R1591",
      "control_C1522",
      "control_R1577",
      "control_R1598",
      "control_R1575",
      "control_R1573",
      "control_R1599",
      "control_R1578",
      "control_C1542",
      "control_R1572",
      "control_R1586",
      "control_R1590",
      "control_R1588",
      "control_R1574",
      "control_C1537",
      "control_R1581",
      "control_R1585",
      "control_R1592",
      "control_R1595",
      "control_C1540",
      "control_C1533",
      "control_R1582",
      "control_R1583",
      "control_C1539",
      "control_R1579",
      "control_C1543",
      "control_C1535",
      "control_R1587",
      "control_R1589"
    ],
    "sheetIds": [
      "control_1500_MATRIX_BL0_31_SWITCHING"
    ],
    "units": [
      {
        "component": "control_C1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1523",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1524",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1525",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1516",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1517",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1518",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1519",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1520",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1521",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1522",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1523",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1500",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1501",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1502",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1503",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1516",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1526",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1527",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1528",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1524",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1525",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1526",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1527",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1528",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1529",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1530",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1531",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1532",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1533",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1534",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1535",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1536",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1537",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1538",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1539",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1540",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1541",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1542",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1543",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1544",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1545",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1546",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1547",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1596",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1504",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1505",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1506",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1507",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1517",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1516",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1517",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1518",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1519",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1520",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1521",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1530",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1531",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1532",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1548",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1549",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1550",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1551",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1552",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1553",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1554",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1555",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1556",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1557",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1558",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1559",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1560",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1561",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1562",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1563",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1564",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1565",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1566",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1567",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1568",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1569",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1570",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1571",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1597",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1508",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1509",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1510",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1511",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1518",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1522",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1529",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1533",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1534",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1535",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1536",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1537",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1538",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1539",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1540",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1541",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1542",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_C1543",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1572",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1573",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1574",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1575",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1576",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1577",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1578",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1579",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1580",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1581",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1582",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1583",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1584",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1585",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1586",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1587",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1588",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1589",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1590",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1591",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1592",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1593",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1594",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1595",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1598",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_R1599",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1512",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1513",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1514",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      },
      {
        "component": "control_U1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 2
      },
      {
        "component": "control_U1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 3
      },
      {
        "component": "control_U1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 4
      },
      {
        "component": "control_U1515",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 5
      },
      {
        "component": "control_U1519",
        "sheet": "control_1500_MATRIX_BL0_31_SWITCHING",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1500_MATRIX_BL0_31_SWITCHING"
  ],
  "suggestedScenario": "local-control_1500_MATRIX_BL0_31_SWITCHING",
  "explanationTitleRu": "Коммутация битовых линий матрицы",
  "sourceSheetId": "control_1500_MATRIX_BL0_31_SWITCHING",
  "sourceSheetName": "1500_MATRIX_BL0_31_SWITCHING",
  "sourceFile": "1500_MATRIX_BL0_31_SWITCHING.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-routing",
  "layout": {
    "version": 2,
    "kind": "bank-array",
    "label": "Четыре равноправных банка коммутации",
    "geometryOnly": true
  },
  "regions": []
};
