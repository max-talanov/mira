/* Editable functional scene: control_700_FPGA_USB3_FIFO_INTERFACE */
window.MIRA_FUNCTIONAL.scenes["control_700_FPGA_USB3_FIFO_INTERFACE"]={
  "id": "control_700_FPGA_USB3_FIFO_INTERFACE",
  "title": "700_FPGA_USB3_FIFO_INTERFACE",
  "subtitle": "USB · от кабеля до данных ПЛИС",
  "description": "J700 подключает компьютер USB Type-C к мосту U707 FT601 через коммутатор ориентации U706. U707 предоставляет ПЛИС U500 32-битный интерфейс FIFO.",
  "nodes": [
    {
      "id": "connector",
      "title": "Подключение кабеля USB",
      "subtitle": "",
      "description": "Разъём Type-C служит внешним подключением USB.",
      "refs": [
        "control_J700",
        "control_C707",
        "control_R703"
      ],
      "role": "data",
      "x": 40,
      "y": 100,
      "w": 250,
      "h": 136,
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_J700",
          "control_C707",
          "control_R703"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_J700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R703",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "protection",
      "title": "Защита кабельных сигналов",
      "subtitle": "",
      "description": "Малоёмкостная ESD-защита защищает внешние линии данных и CC.",
      "refs": [
        "control_D700",
        "control_U700",
        "control_U701",
        "control_U702",
        "control_U703",
        "control_U704",
        "control_U705",
        "control_C712"
      ],
      "role": "fault",
      "x": 510,
      "y": 95,
      "w": 270,
      "h": 148,
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_D700",
          "control_U700",
          "control_U701",
          "control_U702",
          "control_U703",
          "control_U704",
          "control_U705",
          "control_C712"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C712",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_D700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U701",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U702",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U703",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U704",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U705",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "orientation",
      "title": "Выбор ориентации кабеля",
      "subtitle": "",
      "description": "Контроллер Type-C коммутирует активные пары SuperSpeed с учётом ориентации кабеля.",
      "refs": [
        "control_U706",
        "control_R701",
        "control_C708",
        "control_R702",
        "control_C710",
        "control_C709"
      ],
      "role": "data",
      "x": 1040,
      "y": 85,
      "w": 350,
      "h": 184,
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U706",
          "control_R701",
          "control_C708",
          "control_R702",
          "control_C710",
          "control_C709"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C708",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C709",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C710",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R701",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R702",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U706",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "bridge",
      "title": "USB в параллельные данные",
      "subtitle": "",
      "description": "FT601 преобразует обмен USB в 32-битный синхронный интерфейс FIFO.",
      "refs": [
        "control_U707",
        "control_C718",
        "control_C731",
        "control_C729",
        "control_R709",
        "control_C728",
        "control_R708",
        "control_R705",
        "control_R711",
        "control_R710",
        "control_C705",
        "control_C730",
        "control_R713",
        "control_C704",
        "control_R712",
        "control_R707",
        "control_C706",
        "control_C727"
      ],
      "role": "data",
      "x": 1030,
      "y": 510,
      "w": 350,
      "h": 184,
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U707",
          "control_C718",
          "control_C731",
          "control_C729",
          "control_R709",
          "control_C728",
          "control_R708",
          "control_R705",
          "control_R711",
          "control_R710",
          "control_C705",
          "control_C730",
          "control_R713",
          "control_C704",
          "control_R712",
          "control_R707",
          "control_C706",
          "control_C727"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C704",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C705",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C706",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C718",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C727",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C728",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C729",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C730",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C731",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R705",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R708",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R709",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R710",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R711",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R712",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R713",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 2
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 3
          },
          {
            "component": "control_U707",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "fpga",
      "title": "Обработка потока данных",
      "subtitle": "",
      "description": "Логика ПЛИС обменивается словами данных и сигналами управления потоком с мостом FIFO.",
      "refs": [
        "control_U500",
        "control_R700",
        "control_C702",
        "control_R706",
        "control_C703",
        "control_C701"
      ],
      "role": "data",
      "x": 510,
      "y": 525,
      "w": 350,
      "h": 184,
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_R700",
          "control_C702",
          "control_R706",
          "control_C703",
          "control_C701"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C701",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C702",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C703",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R706",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 4
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "support",
      "title": "Тактирование и контроль питания",
      "subtitle": "",
      "description": "Кварц и буфер контроля сброса обеспечивают работу моста USB.",
      "refs": [
        "control_Y700",
        "control_U708",
        "control_FB700",
        "control_FB701",
        "control_C700",
        "control_C725",
        "control_C719",
        "control_C711",
        "control_C713",
        "control_C717",
        "control_C714",
        "control_C723",
        "control_C726",
        "control_C724",
        "control_C722",
        "control_C721",
        "control_C715",
        "control_C720",
        "control_C716",
        "control_R704",
        "control_C732",
        "control_R714"
      ],
      "role": "control",
      "x": 40,
      "y": 540,
      "w": 260,
      "h": 132,
      "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "sourceSheetIds": [
        "control_700_FPGA_USB3_FIFO_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_Y700",
          "control_U708",
          "control_FB700",
          "control_FB701",
          "control_C700",
          "control_C725",
          "control_C719",
          "control_C711",
          "control_C713",
          "control_C717",
          "control_C714",
          "control_C723",
          "control_C726",
          "control_C724",
          "control_C722",
          "control_C721",
          "control_C715",
          "control_C720",
          "control_C716",
          "control_R704",
          "control_C732",
          "control_R714"
        ],
        "sheetIds": [
          "control_700_FPGA_USB3_FIFO_INTERFACE"
        ],
        "units": [
          {
            "component": "control_C700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C711",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C713",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C714",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C715",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C716",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C717",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C719",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C720",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C721",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C722",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C723",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C724",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C725",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C726",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_C732",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_FB700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_FB701",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R704",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_R714",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U708",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_Y700",
            "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "connector_protection",
      "from": "connector",
      "to": "protection",
      "label": "13 цепей",
      "type": "data",
      "nets": [
        "control_net_8a18244b5094",
        "control_net_cd5767d1244a",
        "control_net_4a77ae0a5e9e",
        "control_net_81e7ad5ba413",
        "control_net_dfb816a62c27",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_bb9ef2893216",
        "control_net_3e4cca7b1d3b",
        "control_net_9cc415b59d1d",
        "control_net_3fea9522f27f",
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "13 цепей",
      "netLabels": [
        "USB_VBUS",
        "USB_RX2_P",
        "USB_RX2_N",
        "USB_CC2",
        "USB_CC1",
        "USB_RX1_N",
        "USB_RX1_P",
        "USB_TX1_N",
        "USB_TX1_P",
        "USB_TX2_N",
        "USB_TX2_P",
        "USB_DP",
        "USB_DM"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB_VBUS · USB_RX2_P",
        "USB_RX2_N · ещё 10"
      ],
      "allConnectionsLabel": "Все соединения: 13",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "connector_orientation",
      "from": "connector",
      "to": "orientation",
      "label": "11 цепей",
      "type": "data",
      "nets": [
        "control_net_8a18244b5094",
        "control_net_cd5767d1244a",
        "control_net_4a77ae0a5e9e",
        "control_net_81e7ad5ba413",
        "control_net_dfb816a62c27",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_bb9ef2893216",
        "control_net_3e4cca7b1d3b",
        "control_net_9cc415b59d1d",
        "control_net_3fea9522f27f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "11 цепей",
      "netLabels": [
        "USB_VBUS",
        "USB_RX2_P",
        "USB_RX2_N",
        "USB_CC2",
        "USB_CC1",
        "USB_RX1_N",
        "USB_RX1_P",
        "USB_TX1_N",
        "USB_TX1_P",
        "USB_TX2_N",
        "USB_TX2_P"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB_VBUS · USB_RX2_P",
        "USB_RX2_N · ещё 8"
      ],
      "allConnectionsLabel": "Все соединения: 11",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "connector_bridge",
      "from": "connector",
      "to": "bridge",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "USB_DP",
        "USB_DM"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB_DP",
        "USB_DM"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "connector_support",
      "from": "connector",
      "to": "support",
      "label": "USB_VBUS_DIV",
      "type": "data",
      "nets": [
        "control_net_c2bfc8a41b5f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "USB_VBUS_DIV",
      "netLabels": [
        "USB_VBUS_DIV"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB_VBUS_DIV"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "protection_orientation",
      "from": "protection",
      "to": "orientation",
      "label": "11 цепей",
      "type": "data",
      "nets": [
        "control_net_8a18244b5094",
        "control_net_cd5767d1244a",
        "control_net_4a77ae0a5e9e",
        "control_net_81e7ad5ba413",
        "control_net_dfb816a62c27",
        "control_net_7293b201db23",
        "control_net_c17cad38b3b9",
        "control_net_bb9ef2893216",
        "control_net_3e4cca7b1d3b",
        "control_net_9cc415b59d1d",
        "control_net_3fea9522f27f"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "11 цепей",
      "netLabels": [
        "USB_VBUS",
        "USB_RX2_P",
        "USB_RX2_N",
        "USB_CC2",
        "USB_CC1",
        "USB_RX1_N",
        "USB_RX1_P",
        "USB_TX1_N",
        "USB_TX1_P",
        "USB_TX2_N",
        "USB_TX2_P"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB_VBUS · USB_RX2_P",
        "USB_RX2_N · ещё 8"
      ],
      "allConnectionsLabel": "Все соединения: 11",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "protection_bridge",
      "from": "protection",
      "to": "bridge",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_95ec31f2c17b",
        "control_net_93c1caa5f020"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "USB_DP",
        "USB_DM"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "USB_DP",
        "USB_DM"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "orientation_bridge",
      "from": "orientation",
      "to": "bridge",
      "label": "4 цепи",
      "type": "data",
      "nets": [
        "control_net_4e0bed631879",
        "control_net_ee1064f82d57",
        "control_net_90ccce2c8039",
        "control_net_4ab70b5a5d2e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "4 цепи",
      "netLabels": [
        "FT_RX_P",
        "FT_RX_N",
        "FT_TX_P",
        "FT_TX_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FT_RX_N · FT_RX_P",
        "FT_TX_N · FT_TX_P"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "bridge_fpga",
      "from": "bridge",
      "to": "fpga",
      "label": "32-битные данные и управление обменом",
      "type": "fault",
      "nets": [
        "control_net_5d12a42f13a7",
        "control_net_a3e916588f1a",
        "control_net_55817c8282e0",
        "control_net_e44786acaa30",
        "control_net_a6a3fee83c7f",
        "control_net_ae2900dc7735",
        "control_net_708de604029c",
        "control_net_fb7db09ec7c3",
        "control_net_67008bb4401d",
        "control_net_38b9badc71df",
        "control_net_c39dacef288b",
        "control_net_93963a89c623",
        "control_net_080b1c6e773b",
        "control_net_c4ab00cc76ca",
        "control_net_f2e37bb320d3",
        "control_net_adca8d8efad4",
        "control_net_fb2e9fe80e2d",
        "control_net_0aa940b07213",
        "control_net_5f4121b0067b",
        "control_net_45ad74d728ee",
        "control_net_34a5458782a9",
        "control_net_a0ccf5710062",
        "control_net_77550a265a38",
        "control_net_95229f960617",
        "control_net_76c093c7625c",
        "control_net_0c2767ceedce",
        "control_net_e4fd6a071815",
        "control_net_81564ca10d04",
        "control_net_2e89b83a9cd1",
        "control_net_01a067f231f5",
        "control_net_4a9a6e85b720",
        "control_net_08fb6faf20a6",
        "control_net_d35e6450ec18",
        "control_net_90cbd311d743",
        "control_net_fb90ec6e0d11",
        "control_net_b19700dbe4c4",
        "control_net_9a988f0c62fc",
        "control_net_f1f55e7a2140",
        "control_net_cbf683fe7e90",
        "control_net_6d1b692341f6",
        "control_net_ea07dd504c63",
        "control_net_edfa87483431",
        "control_net_576fff37cf3a",
        "control_net_88588227b7a2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "32-битные данные",
      "netLabels": [
        "FT_RST_LOC_N",
        "FT_D0",
        "FT_D1",
        "FT_D2",
        "FT_D3",
        "FT_D4",
        "FT_D5",
        "FT_D6",
        "FT_D7",
        "FT_D8",
        "FT_D9",
        "FT_D10",
        "FT_D11",
        "FT_D12",
        "FT_D13",
        "FT_D14",
        "FT_D15",
        "FT_OE_N",
        "FT_WR_N",
        "FT_RD_N",
        "FT_BE0",
        "FT_BE1",
        "FT_BE2",
        "FT_BE3",
        "FT_TXE_N",
        "FT_RXF_N",
        "FT_SIWU_N",
        "FT_CLK",
        "FT_D26",
        "FT_D22",
        "FT_D27",
        "FT_D23",
        "FT_D30",
        "FT_D31",
        "FT_D28",
        "FT_D29",
        "FT_D24",
        "FT_D20",
        "FT_D21",
        "FT_D16",
        "FT_D25",
        "FT_D17",
        "FT_D18",
        "FT_D19"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FT_RST_LOC_N · FT_D0",
        "FT_D1 · ещё 41"
      ],
      "allConnectionsLabel": "Все соединения: 44",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "bridge_support",
      "from": "bridge",
      "to": "support",
      "label": "6 цепей",
      "type": "data",
      "nets": [
        "control_net_3ab09453d63e",
        "control_net_b1490930ce10",
        "control_net_db15969a3ef3",
        "control_net_62e5d80fdc50",
        "control_net_66452339ef9c",
        "control_net_b6e5a544d44c"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "6 цепей",
      "netLabels": [
        "FT1V0",
        "FT_PLL1V0",
        "FT_XI",
        "FT_A3V3",
        "FT_XO",
        "FT_VBUS_DET"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FT1V0 · FT_A3V3",
        "FT_PLL1V0 · FT_VBUS_DET",
        "FT_XI · FT_XO"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 50,
    "w": 1430,
    "h": 699
  },
  "board": "control",
  "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 63,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_J700",
      "control_C707",
      "control_R703",
      "control_D700",
      "control_U700",
      "control_U701",
      "control_U702",
      "control_U703",
      "control_U704",
      "control_U705",
      "control_C712",
      "control_U706",
      "control_R701",
      "control_C708",
      "control_R702",
      "control_C710",
      "control_C709",
      "control_U707",
      "control_C718",
      "control_C731",
      "control_C729",
      "control_R709",
      "control_C728",
      "control_R708",
      "control_R705",
      "control_R711",
      "control_R710",
      "control_C705",
      "control_C730",
      "control_R713",
      "control_C704",
      "control_R712",
      "control_R707",
      "control_C706",
      "control_C727",
      "control_U500",
      "control_R700",
      "control_C702",
      "control_R706",
      "control_C703",
      "control_C701",
      "control_Y700",
      "control_U708",
      "control_FB700",
      "control_FB701",
      "control_C700",
      "control_C725",
      "control_C719",
      "control_C711",
      "control_C713",
      "control_C717",
      "control_C714",
      "control_C723",
      "control_C726",
      "control_C724",
      "control_C722",
      "control_C721",
      "control_C715",
      "control_C720",
      "control_C716",
      "control_R704",
      "control_C732",
      "control_R714"
    ],
    "sheetIds": [
      "control_700_FPGA_USB3_FIFO_INTERFACE"
    ],
    "units": [
      {
        "component": "control_C707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_J700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R703",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C712",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_D700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U701",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U702",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U703",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U704",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U705",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C708",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C709",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C710",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R701",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R702",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U706",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C704",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C705",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C706",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C718",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C727",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C728",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C729",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C730",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C731",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R705",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R708",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R709",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R710",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R711",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R712",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R713",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 2
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 3
      },
      {
        "component": "control_U707",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_C701",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C702",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C703",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R706",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 4
      },
      {
        "component": "control_C700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C711",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C713",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C714",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C715",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C716",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C717",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C719",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C720",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C721",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C722",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C723",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C724",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C725",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C726",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_C732",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_FB700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_FB701",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R704",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_R714",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U708",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_Y700",
        "sheet": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_700_FPGA_USB3_FIFO_INTERFACE"
  ],
  "suggestedScenario": "local-control_700_FPGA_USB3_FIFO_INTERFACE",
  "explanationTitleRu": "USB · от кабеля до данных ПЛИС",
  "sourceSheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
  "sourceSheetName": "700_FPGA_USB3_FIFO_INTERFACE",
  "sourceFile": "700_FPGA_USB3_FIFO_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-fpga",
  "layout": {
    "version": 2,
    "kind": "folded-process",
    "label": "Путь от кабеля к словам параллельного интерфейса",
    "geometryOnly": true
  },
  "regions": []
};
