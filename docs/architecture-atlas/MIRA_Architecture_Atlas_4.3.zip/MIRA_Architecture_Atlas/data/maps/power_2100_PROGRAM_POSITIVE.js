/* Editable functional scene: power_2100_PROGRAM_POSITIVE */
window.MIRA_FUNCTIONAL.scenes["power_2100_PROGRAM_POSITIVE"]={
  "id": "power_2100_PROGRAM_POSITIVE",
  "title": "2100_PROGRAM_POSITIVE",
  "subtitle": "Коммутация положительного питания записи",
  "description": "Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов.",
  "nodes": [
    {
      "id": "switch",
      "title": "Подключение положительной шины",
      "subtitle": "",
      "description": "Последовательные ключи подключают положительное питание программирования при наличии разрешения.",
      "refs": [
        "power_Q2101",
        "power_Q2102",
        "power_Q2103",
        "power_Q2104",
        "power_R2103",
        "power_C2101",
        "power_R2106",
        "power_R2101",
        "power_R2102"
      ],
      "role": "power",
      "x": 620,
      "y": 220,
      "w": 370,
      "h": 194,
      "sheetId": "power_2100_PROGRAM_POSITIVE",
      "sourceSheetIds": [
        "power_2100_PROGRAM_POSITIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q2101",
          "power_Q2102",
          "power_Q2103",
          "power_Q2104",
          "power_R2103",
          "power_C2101",
          "power_R2106",
          "power_R2101",
          "power_R2102"
        ],
        "sheetIds": [
          "power_2100_PROGRAM_POSITIVE"
        ],
        "units": [
          {
            "component": "power_C2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_Q2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_Q2102",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_Q2103",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_Q2104",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2102",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2103",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2106",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "control",
      "title": "Передача команды включения",
      "subtitle": "",
      "description": "Оптопара и управляющие компоненты формируют управление затворами положительной шины.",
      "refs": [
        "power_U2101",
        "power_Q2105",
        "power_R2105",
        "power_R2107"
      ],
      "role": "control",
      "x": 40,
      "y": 60,
      "w": 270,
      "h": 144,
      "sheetId": "power_2100_PROGRAM_POSITIVE",
      "sourceSheetIds": [
        "power_2100_PROGRAM_POSITIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_U2101",
          "power_Q2105",
          "power_R2105",
          "power_R2107"
        ],
        "sheetIds": [
          "power_2100_PROGRAM_POSITIVE"
        ],
        "units": [
          {
            "component": "power_Q2105",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2105",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2107",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_U2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "stop",
      "title": "Быстрый разряд затвора",
      "subtitle": "",
      "description": "Зажимные элементы снимают управление затвором и обеспечивают выключенное состояние.",
      "refs": [
        "power_Q2106",
        "power_Q2107",
        "power_D2101",
        "power_D2102",
        "power_D2103",
        "power_D2104",
        "power_R2104",
        "power_C2103",
        "power_C2102",
        "power_R2109",
        "power_R2108",
        "power_R2110"
      ],
      "role": "fault",
      "x": 55,
      "y": 510,
      "w": 250,
      "h": 132,
      "sheetId": "power_2100_PROGRAM_POSITIVE",
      "sourceSheetIds": [
        "power_2100_PROGRAM_POSITIVE"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q2106",
          "power_Q2107",
          "power_D2101",
          "power_D2102",
          "power_D2103",
          "power_D2104",
          "power_R2104",
          "power_C2103",
          "power_C2102",
          "power_R2109",
          "power_R2108",
          "power_R2110"
        ],
        "sheetIds": [
          "power_2100_PROGRAM_POSITIVE"
        ],
        "units": [
          {
            "component": "power_C2102",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_C2103",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_D2101",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_D2102",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_D2103",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_D2104",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_Q2106",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_Q2107",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2104",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2108",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2109",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          },
          {
            "component": "power_R2110",
            "sheet": "power_2100_PROGRAM_POSITIVE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "switch_control",
      "from": "switch",
      "to": "control",
      "label": "3 цепи",
      "type": "data",
      "nets": [
        "power_net_46ab17b8adeb",
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "3 цепи",
      "netLabels": [
        "MATRIX_OPTO_K",
        "MATRIX_P_GATE",
        "MATRIX_P_SOURCE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_OPTO_K",
        "MATRIX_P_GATE",
        "MATRIX_P_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "switch_stop",
      "from": "switch",
      "to": "stop",
      "label": "Разрешение",
      "type": "fault",
      "nets": [
        "power_net_5a1f578d112a",
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Разрешение",
      "netLabels": [
        "MATRIX_PERMIT",
        "MATRIX_P_GATE",
        "MATRIX_P_SOURCE"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MATRIX_PERMIT",
        "MATRIX_P_GATE",
        "MATRIX_P_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "control_stop",
      "from": "control",
      "to": "stop",
      "label": "3 цепи",
      "type": "data",
      "nets": [
        "power_net_4ec3a13ab6a0",
        "power_net_877d9e8f0cbb",
        "power_net_3340775b1468"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "3 цепи",
      "netLabels": [
        "MATRIX_P_GATE",
        "MATRIX_P_SOURCE"
      ],
      "unnamedNetIds": [
        "power_net_3340775b1468"
      ],
      "labelLines": [
        "MATRIX_P_GATE",
        "MATRIX_P_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 3",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 1030,
    "h": 657
  },
  "board": "power",
  "sheetId": "power_2100_PROGRAM_POSITIVE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 25,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_Q2101",
      "power_Q2102",
      "power_Q2103",
      "power_Q2104",
      "power_R2103",
      "power_C2101",
      "power_R2106",
      "power_R2101",
      "power_R2102",
      "power_U2101",
      "power_Q2105",
      "power_R2105",
      "power_R2107",
      "power_Q2106",
      "power_Q2107",
      "power_D2101",
      "power_D2102",
      "power_D2103",
      "power_D2104",
      "power_R2104",
      "power_C2103",
      "power_C2102",
      "power_R2109",
      "power_R2108",
      "power_R2110"
    ],
    "sheetIds": [
      "power_2100_PROGRAM_POSITIVE"
    ],
    "units": [
      {
        "component": "power_C2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2102",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2103",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2104",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2102",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2103",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2106",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2105",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2105",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2107",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_U2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_C2102",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_C2103",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_D2101",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_D2102",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_D2103",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_D2104",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2106",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_Q2107",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2104",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2108",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2109",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      },
      {
        "component": "power_R2110",
        "sheet": "power_2100_PROGRAM_POSITIVE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_2100_PROGRAM_POSITIVE"
  ],
  "suggestedScenario": "local-power_2100_PROGRAM_POSITIVE",
  "explanationTitleRu": "Коммутация положительного питания записи",
  "sourceSheetId": "power_2100_PROGRAM_POSITIVE",
  "sourceSheetName": "2100_PROGRAM_POSITIVE",
  "sourceFile": "2100_PROGRAM_POSITIVE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-program",
  "layout": {
    "version": 2,
    "kind": "switch-with-control",
    "label": "Силовые ключи, команда управления и отдельная защита",
    "geometryOnly": true
  },
  "regions": []
};
