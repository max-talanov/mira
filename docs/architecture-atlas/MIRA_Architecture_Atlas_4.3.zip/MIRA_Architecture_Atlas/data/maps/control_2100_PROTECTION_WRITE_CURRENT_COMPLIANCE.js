/* Editable functional scene: control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE */
window.MIRA_FUNCTIONAL.scenes["control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"]={
  "id": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "title": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "subtitle": "Ограничение напряжения и тока записи",
  "description": "Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.",
  "nodes": [
    {
      "id": "commands",
      "title": "Выбор ограничений напряжения и тока",
      "subtitle": "",
      "description": "Аналоговые селекторы выбирают уставки активной операции.",
      "refs": [
        "control_U2100",
        "control_U2103",
        "control_R2105",
        "control_R2106",
        "control_R2107",
        "control_R2108",
        "control_R2100",
        "control_C2100",
        "control_C2101",
        "control_C2109",
        "control_C2110",
        "control_C2115",
        "control_C2116"
      ],
      "role": "analog",
      "x": 40,
      "y": 60,
      "w": 280,
      "h": 146,
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2100",
          "control_U2103",
          "control_R2105",
          "control_R2106",
          "control_R2107",
          "control_R2108",
          "control_R2100",
          "control_C2100",
          "control_C2101",
          "control_C2109",
          "control_C2110",
          "control_C2115",
          "control_C2116"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_C2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2101",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2109",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2110",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2115",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2116",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2108",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "sense",
      "title": "Измерение тока источника",
      "subtitle": "",
      "description": "Кельвиновское подключение и измерительный усилитель измеряют ток общего источника.",
      "refs": [
        "control_U2104",
        "control_U2109",
        "control_R2129",
        "control_C2111",
        "control_C2112",
        "control_C2113",
        "control_C2114"
      ],
      "role": "analog",
      "x": 40,
      "y": 550,
      "w": 280,
      "h": 146,
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2104",
          "control_U2109",
          "control_R2129",
          "control_C2111",
          "control_C2112",
          "control_C2113",
          "control_C2114"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_C2111",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2112",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2113",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2114",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2129",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2104",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2109",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "control",
      "title": "Регулирование напряжения или тока",
      "subtitle": "",
      "description": "Усилители регулятора управляют источником по уставкам и измеренным сигналам.",
      "refs": [
        "control_U2105",
        "control_U2106",
        "control_U2107",
        "control_R2104",
        "control_R2110",
        "control_R2111",
        "control_R2138",
        "control_R2112",
        "control_R2139",
        "control_R2113",
        "control_R2114",
        "control_R2115",
        "control_R2116",
        "control_R2117",
        "control_R2118",
        "control_R2119",
        "control_R2120",
        "control_R2124",
        "control_R2125",
        "control_R2126",
        "control_R2127",
        "control_R2103",
        "control_R2128",
        "control_R2130",
        "control_R2131",
        "control_R2132",
        "control_C2103",
        "control_C2106",
        "control_C2107",
        "control_C2117",
        "control_C2118"
      ],
      "role": "analog",
      "x": 610,
      "y": 285,
      "w": 350,
      "h": 184,
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2105",
          "control_U2106",
          "control_U2107",
          "control_R2104",
          "control_R2110",
          "control_R2111",
          "control_R2138",
          "control_R2112",
          "control_R2139",
          "control_R2113",
          "control_R2114",
          "control_R2115",
          "control_R2116",
          "control_R2117",
          "control_R2118",
          "control_R2119",
          "control_R2120",
          "control_R2124",
          "control_R2125",
          "control_R2126",
          "control_R2127",
          "control_R2103",
          "control_R2128",
          "control_R2130",
          "control_R2131",
          "control_R2132",
          "control_C2103",
          "control_C2106",
          "control_C2107",
          "control_C2117",
          "control_C2118"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_C2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2117",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2118",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2104",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2110",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2111",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2112",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2113",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2114",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2115",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2116",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2117",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2118",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2119",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2120",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2124",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2125",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2126",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2127",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2128",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2130",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2131",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2132",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2138",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2139",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2106",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 2
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 3
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 4
          },
          {
            "component": "control_U2107",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 5
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "drive",
      "title": "Выход регулируемого источника",
      "subtitle": "",
      "description": "Выходной усилитель подаёт воздействие на последующую коммутацию матрицы.",
      "refs": [
        "control_U2101",
        "control_R2102",
        "control_C2104",
        "control_C2105"
      ],
      "role": "analog",
      "x": 1210,
      "y": 300,
      "w": 350,
      "h": 184,
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2101",
          "control_R2102",
          "control_C2104",
          "control_C2105"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_C2104",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2105",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2102",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2101",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "reset",
      "title": "Ограничение и сброс регулятора",
      "subtitle": "",
      "description": "Цепи ограничения и сброса ограничивают отклонения регулятора между операциями.",
      "refs": [
        "control_U2108",
        "control_D2100",
        "control_D2101",
        "control_D2102",
        "control_D2103",
        "control_R2101",
        "control_R2121",
        "control_R2122",
        "control_R2123",
        "control_C2102",
        "control_C2108"
      ],
      "role": "control",
      "x": 640,
      "y": -90,
      "w": 260,
      "h": 140,
      "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "sourceSheetIds": [
        "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2108",
          "control_D2100",
          "control_D2101",
          "control_D2102",
          "control_D2103",
          "control_R2101",
          "control_R2121",
          "control_R2122",
          "control_R2123",
          "control_C2102",
          "control_C2108"
        ],
        "sheetIds": [
          "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
        ],
        "units": [
          {
            "component": "control_C2102",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_C2108",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_D2100",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_D2101",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_D2102",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_D2103",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2101",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2121",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2122",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_R2123",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          },
          {
            "component": "control_U2108",
            "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "commands_sense",
      "from": "commands",
      "to": "sense",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_87568f65b103",
        "control_net_c2d31e9a7d3a"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_SOURCE",
        "CC_KELVIN_P"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_SOURCE",
        "CC_KELVIN_P"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "commands_control",
      "from": "commands",
      "to": "control",
      "label": "2 цепи",
      "type": "data",
      "nets": [
        "control_net_87568f65b103",
        "control_net_ee356dd4a609"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "2 цепи",
      "netLabels": [
        "MAT_SOURCE",
        "CC_ILIM_MID"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_SOURCE",
        "CC_ILIM_MID"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sense_control",
      "from": "sense",
      "to": "control",
      "label": "5 цепей",
      "type": "data",
      "nets": [
        "control_net_87568f65b103",
        "control_net_5b5c009b1508",
        "control_net_81a816b03060",
        "control_net_edfd1164669d",
        "control_net_13ff4635cb1b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "5 цепей",
      "netLabels": [
        "MAT_SOURCE",
        "MAT_PI_RAW",
        "MAT_PI_SUM",
        "MAT_CC_SENSE",
        "MAT_DRV_CMD"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_CC_SENSE · MAT_DRV_CMD",
        "MAT_PI_RAW · MAT_PI_SUM",
        "MAT_SOURCE"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sense_drive",
      "from": "sense",
      "to": "drive",
      "label": "MAT_DRV_CMD",
      "type": "data",
      "nets": [
        "control_net_13ff4635cb1b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_DRV_CMD",
      "netLabels": [
        "MAT_DRV_CMD"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_DRV_CMD"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "sense_reset",
      "from": "sense",
      "to": "reset",
      "label": "MAT_DRV_CMD",
      "type": "data",
      "nets": [
        "control_net_13ff4635cb1b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_DRV_CMD",
      "netLabels": [
        "MAT_DRV_CMD"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_DRV_CMD"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "control_drive",
      "from": "control",
      "to": "drive",
      "label": "MAT_DRV_CMD",
      "type": "data",
      "nets": [
        "control_net_13ff4635cb1b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_DRV_CMD",
      "netLabels": [
        "MAT_DRV_CMD"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_DRV_CMD"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "control_reset",
      "from": "control",
      "to": "reset",
      "label": "11 цепей",
      "type": "data",
      "nets": [
        "control_net_c27d9f1c5177",
        "control_net_13ff4635cb1b",
        "control_net_f58cc678464d",
        "control_net_2860e727c5a6",
        "control_net_2b71697338af",
        "control_net_4b7c47b539e3",
        "control_net_f423ec67f84e",
        "control_net_affe5a5b3b9b",
        "control_net_1d37a4d602ee",
        "control_net_10974d5ea208",
        "control_net_91d1f89a3eb2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "11 цепей",
      "netLabels": [
        "MAT_ILIM_SENSE",
        "MAT_DRV_CMD",
        "CC_MV_N",
        "CC_MV_OUT",
        "CC_MI_N",
        "CC_MI_OUT",
        "CC_LOW_N",
        "CC_LOW_OUT",
        "CC_HIGH_N",
        "CC_HIGH_OUT",
        "CC_EMAX"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ILIM_SENSE · MAT_DRV_CMD",
        "CC_MV_N · ещё 8"
      ],
      "allConnectionsLabel": "Все соединения: 11",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    },
    {
      "id": "drive_reset",
      "from": "drive",
      "to": "reset",
      "label": "MAT_DRV_CMD",
      "type": "data",
      "nets": [
        "control_net_13ff4635cb1b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "MAT_DRV_CMD",
      "netLabels": [
        "MAT_DRV_CMD"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_DRV_CMD"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": 0,
    "y": -125,
    "w": 1600,
    "h": 861
  },
  "board": "control",
  "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 66,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U2100",
      "control_U2103",
      "control_R2105",
      "control_R2106",
      "control_R2107",
      "control_R2108",
      "control_R2100",
      "control_C2100",
      "control_C2101",
      "control_C2109",
      "control_C2110",
      "control_C2115",
      "control_C2116",
      "control_U2104",
      "control_U2109",
      "control_R2129",
      "control_C2111",
      "control_C2112",
      "control_C2113",
      "control_C2114",
      "control_U2105",
      "control_U2106",
      "control_U2107",
      "control_R2104",
      "control_R2110",
      "control_R2111",
      "control_R2138",
      "control_R2112",
      "control_R2139",
      "control_R2113",
      "control_R2114",
      "control_R2115",
      "control_R2116",
      "control_R2117",
      "control_R2118",
      "control_R2119",
      "control_R2120",
      "control_R2124",
      "control_R2125",
      "control_R2126",
      "control_R2127",
      "control_R2103",
      "control_R2128",
      "control_R2130",
      "control_R2131",
      "control_R2132",
      "control_C2103",
      "control_C2106",
      "control_C2107",
      "control_C2117",
      "control_C2118",
      "control_U2101",
      "control_R2102",
      "control_C2104",
      "control_C2105",
      "control_U2108",
      "control_D2100",
      "control_D2101",
      "control_D2102",
      "control_D2103",
      "control_R2101",
      "control_R2121",
      "control_R2122",
      "control_R2123",
      "control_C2102",
      "control_C2108"
    ],
    "sheetIds": [
      "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
    ],
    "units": [
      {
        "component": "control_C2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2101",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2109",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2110",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2115",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2116",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2108",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2111",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2112",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2113",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2114",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2129",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2104",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2109",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2117",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2118",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2104",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2110",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2111",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2112",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2113",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2114",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2115",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2116",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2117",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2118",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2119",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2120",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2124",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2125",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2126",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2127",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2128",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2130",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2131",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2132",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2138",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2139",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2106",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 2
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 3
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 4
      },
      {
        "component": "control_U2107",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 5
      },
      {
        "component": "control_C2104",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2105",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2102",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2101",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2102",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_C2108",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_D2100",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_D2101",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_D2102",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_D2103",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2101",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2121",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2122",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_R2123",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      },
      {
        "component": "control_U2108",
        "sheet": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE"
  ],
  "suggestedScenario": "local-control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "explanationTitleRu": "Ограничение напряжения и тока записи",
  "sourceSheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "sourceSheetName": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
  "sourceFile": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control_PROTECTION",
  "layout": {
    "version": 2,
    "kind": "feedback-control",
    "label": "Уставка и измерение сходятся в контуре регулирования",
    "geometryOnly": true
  },
  "regions": []
};
