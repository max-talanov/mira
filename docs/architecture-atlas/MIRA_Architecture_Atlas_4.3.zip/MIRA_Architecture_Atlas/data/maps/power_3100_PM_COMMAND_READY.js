/* Editable functional scene: power_3100_PM_COMMAND_READY */
window.MIRA_FUNCTIONAL.scenes["power_3100_PM_COMMAND_READY"]={
  "id": "power_3100_PM_COMMAND_READY",
  "title": "3100_PM_COMMAND_READY",
  "subtitle": "Готовность команд включения",
  "description": "U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин.",
  "nodes": [
    {
      "id": "0",
      "title": "Готовность основных шин",
      "subtitle": "",
      "description": "Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.",
      "refs": [
        "power_U3101",
        "power_C3101"
      ],
      "role": "control",
      "x": 40,
      "y": 60,
      "w": 290,
      "h": 154,
      "sheetId": "power_3100_PM_COMMAND_READY",
      "sourceSheetIds": [
        "power_3100_PM_COMMAND_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3101",
          "power_C3101"
        ],
        "sheetIds": [
          "power_3100_PM_COMMAND_READY"
        ],
        "units": [
          {
            "component": "power_C3101",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          },
          {
            "component": "power_U3101",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "1",
      "title": "Готовность вспомогательных шин",
      "subtitle": "",
      "description": "Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.",
      "refs": [
        "power_U3102",
        "power_C3102"
      ],
      "role": "control",
      "x": 40,
      "y": 450,
      "w": 290,
      "h": 154,
      "sheetId": "power_3100_PM_COMMAND_READY",
      "sourceSheetIds": [
        "power_3100_PM_COMMAND_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3102",
          "power_C3102"
        ],
        "sheetIds": [
          "power_3100_PM_COMMAND_READY"
        ],
        "units": [
          {
            "component": "power_C3102",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          },
          {
            "component": "power_U3102",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "2",
      "title": "Итоговая готовность",
      "subtitle": "",
      "description": "Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.",
      "refs": [
        "power_U3103",
        "power_C3103"
      ],
      "role": "control",
      "x": 720,
      "y": 240,
      "w": 370,
      "h": 194,
      "sheetId": "power_3100_PM_COMMAND_READY",
      "sourceSheetIds": [
        "power_3100_PM_COMMAND_READY"
      ],
      "circuitGroup": {
        "refs": [
          "power_U3103",
          "power_C3103"
        ],
        "sheetIds": [
          "power_3100_PM_COMMAND_READY"
        ],
        "units": [
          {
            "component": "power_C3103",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          },
          {
            "component": "power_U3103",
            "sheet": "power_3100_PM_COMMAND_READY",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "0_2",
      "from": "0",
      "to": "2",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_39d8ddb40bfa",
        "power_net_722d31de17d3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "CMD_GROUP_0",
        "CMD_GROUP_1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_GROUP_0",
        "CMD_GROUP_1"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "1_2",
      "from": "1",
      "to": "2",
      "label": "Команда включения",
      "type": "control",
      "nets": [
        "power_net_4053a009016f",
        "power_net_78f1e98d41b3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Команда включения",
      "netLabels": [
        "CMD_GROUP_2",
        "CMD_GROUP_3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_GROUP_2",
        "CMD_GROUP_3"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 25,
    "w": 1130,
    "h": 619
  },
  "board": "power",
  "sheetId": "power_3100_PM_COMMAND_READY",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 6,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U3101",
      "power_C3101",
      "power_U3102",
      "power_C3102",
      "power_U3103",
      "power_C3103"
    ],
    "sheetIds": [
      "power_3100_PM_COMMAND_READY"
    ],
    "units": [
      {
        "component": "power_C3101",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_U3101",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_C3102",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_U3102",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_C3103",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      },
      {
        "component": "power_U3103",
        "sheet": "power_3100_PM_COMMAND_READY",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_3100_PM_COMMAND_READY"
  ],
  "suggestedScenario": "local-power_3100_PM_COMMAND_READY",
  "explanationTitleRu": "Готовность команд включения",
  "sourceSheetId": "power_3100_PM_COMMAND_READY",
  "sourceSheetName": "3100_PM_COMMAND_READY",
  "sourceFile": "3100_PM_COMMAND_READY.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-supervisor",
  "layout": {
    "version": 2,
    "kind": "readiness-combiner",
    "label": "Две группы условий сходятся в итоговую готовность",
    "geometryOnly": true
  },
  "regions": []
};
