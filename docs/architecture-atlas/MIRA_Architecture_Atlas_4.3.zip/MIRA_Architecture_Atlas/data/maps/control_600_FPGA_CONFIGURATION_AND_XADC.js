/* Editable functional scene: control_600_FPGA_CONFIGURATION_AND_XADC */
window.MIRA_FUNCTIONAL.scenes["control_600_FPGA_CONFIGURATION_AND_XADC"]={
  "id": "control_600_FPGA_CONFIGURATION_AND_XADC",
  "title": "600_FPGA_CONFIGURATION_AND_XADC",
  "subtitle": "Загрузка и восстановление ПЛИС",
  "description": "U500 загружает конфигурацию из SPI flash U600. J600, SW600 и U601 обеспечивают отладку и восстановление. FB600 фильтрует питание XADC.",
  "nodes": [
    {
      "id": "flash",
      "title": "Хранение конфигурации ПЛИС",
      "subtitle": "",
      "description": "Конфигурационная flash-память хранит битовый поток для загрузки при запуске.",
      "refs": [
        "control_U600",
        "control_R601",
        "control_C600",
        "control_R602",
        "control_R606"
      ],
      "role": "data",
      "x": 40,
      "y": 90,
      "w": 300,
      "h": 150,
      "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetIds": [
        "control_600_FPGA_CONFIGURATION_AND_XADC"
      ],
      "circuitGroup": {
        "refs": [
          "control_U600",
          "control_R601",
          "control_C600",
          "control_R602",
          "control_R606"
        ],
        "sheetIds": [
          "control_600_FPGA_CONFIGURATION_AND_XADC"
        ],
        "units": [
          {
            "component": "control_C600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R601",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R602",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R606",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          }
        ]
      },
      "layoutRole": "bank"
    },
    {
      "id": "fpga",
      "title": "Загрузка программируемой логики",
      "subtitle": "",
      "description": "ПЛИС загружает конфигурацию и сообщает состояние через INIT и DONE.",
      "refs": [
        "control_U500",
        "control_R603",
        "control_R604"
      ],
      "role": "data",
      "x": 600,
      "y": 300,
      "w": 350,
      "h": 190,
      "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetIds": [
        "control_600_FPGA_CONFIGURATION_AND_XADC"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_R603",
          "control_R604"
        ],
        "sheetIds": [
          "control_600_FPGA_CONFIGURATION_AND_XADC"
        ],
        "units": [
          {
            "component": "control_R603",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R604",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 2
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "jtag",
      "title": "Восстановление и отладка",
      "subtitle": "",
      "description": "JTAG обеспечивает независимый путь программирования и восстановления.",
      "refs": [
        "control_J600"
      ],
      "role": "data",
      "x": 40,
      "y": 590,
      "w": 280,
      "h": 145,
      "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetIds": [
        "control_600_FPGA_CONFIGURATION_AND_XADC"
      ],
      "circuitGroup": {
        "refs": [
          "control_J600"
        ],
        "sheetIds": [
          "control_600_FPGA_CONFIGURATION_AND_XADC"
        ],
        "units": [
          {
            "component": "control_J600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "recover",
      "title": "Запрос повторной конфигурации",
      "subtitle": "",
      "description": "Кнопка или буфер контроллера с открытым стоком перезапускает конфигурацию ПЛИС.",
      "refs": [
        "control_U601",
        "control_SW600",
        "control_C603",
        "control_R605",
        "control_R607",
        "control_R600"
      ],
      "role": "control",
      "x": 1220,
      "y": 90,
      "w": 260,
      "h": 140,
      "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetIds": [
        "control_600_FPGA_CONFIGURATION_AND_XADC"
      ],
      "circuitGroup": {
        "refs": [
          "control_U601",
          "control_SW600",
          "control_C603",
          "control_R605",
          "control_R607",
          "control_R600"
        ],
        "sheetIds": [
          "control_600_FPGA_CONFIGURATION_AND_XADC"
        ],
        "units": [
          {
            "component": "control_C603",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R605",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_R607",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_SW600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_U601",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Фильтр питания внутреннего контроля",
      "subtitle": "",
      "description": "Феррит и локальные конденсаторы фильтруют питание XADC.",
      "refs": [
        "control_FB600",
        "control_C602",
        "control_C601"
      ],
      "role": "power",
      "x": 1220,
      "y": 590,
      "w": 260,
      "h": 140,
      "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "sourceSheetIds": [
        "control_600_FPGA_CONFIGURATION_AND_XADC"
      ],
      "circuitGroup": {
        "refs": [
          "control_FB600",
          "control_C602",
          "control_C601"
        ],
        "sheetIds": [
          "control_600_FPGA_CONFIGURATION_AND_XADC"
        ],
        "units": [
          {
            "component": "control_C601",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_C602",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          },
          {
            "component": "control_FB600",
            "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    }
  ],
  "edges": [
    {
      "id": "flash_fpga_0",
      "from": "flash",
      "to": "fpga",
      "label": "Конфигурационный поток по SPI",
      "type": "data",
      "nets": [
        "control_net_52c8c7557923",
        "control_net_834296c71f70",
        "control_net_3591ba357658",
        "control_net_6bc6649476ec",
        "control_net_9e71347ab99c",
        "control_net_92af7290af48"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Конфигурация",
      "netLabels": [
        "FPGA_CFG_CS_N",
        "FPGA_CFG_D3",
        "FPGA_CFG_D2",
        "FPGA_CFG_CLK",
        "FPGA_CFG_D1",
        "FPGA_CFG_D0"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_CFG_CLK · FPGA_CFG_CS_N",
        "FPGA_CFG_D0 · FPGA_CFG_D1",
        "FPGA_CFG_D2 · FPGA_CFG_D3"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "jtag_fpga_1",
      "from": "jtag",
      "to": "fpga",
      "label": "Программирование JTAG",
      "type": "data",
      "nets": [
        "control_net_ba92e944f30f",
        "control_net_0b94eea9a209",
        "control_net_c251169eb896",
        "control_net_61b4ba86f12f"
      ],
      "bidirectional": true,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Программирование JTAG",
      "netLabels": [
        "FPGA_JTAG_TCK",
        "FPGA_JTAG_TMS",
        "FPGA_JTAG_TDI",
        "FPGA_JTAG_TDO"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_JTAG_TCK · FPGA_JTAG_TDI",
        "FPGA_JTAG_TDO · FPGA_JTAG_TMS"
      ],
      "allConnectionsLabel": "Все соединения: 4",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "recover_fpga_2",
      "from": "recover",
      "to": "fpga",
      "label": "Перезапуск конфигурации",
      "type": "control",
      "nets": [
        "control_net_4701afd22aa9"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Переконфигурация",
      "netLabels": [
        "FPGA_PROGRAM_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_PROGRAM_N"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    },
    {
      "id": "filter_fpga_3",
      "from": "filter",
      "to": "fpga",
      "label": "Фильтрованное питание XADC",
      "type": "power",
      "nets": [
        "control_net_00eadc59f9af"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Питание XADC",
      "netLabels": [
        "FPGA_VCCADC"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA_VCCADC"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 55,
    "w": 1520,
    "h": 720
  },
  "board": "control",
  "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 18,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U600",
      "control_R601",
      "control_C600",
      "control_R602",
      "control_R606",
      "control_U500",
      "control_R603",
      "control_R604",
      "control_J600",
      "control_U601",
      "control_SW600",
      "control_C603",
      "control_R605",
      "control_R607",
      "control_R600",
      "control_FB600",
      "control_C602",
      "control_C601"
    ],
    "sheetIds": [
      "control_600_FPGA_CONFIGURATION_AND_XADC"
    ],
    "units": [
      {
        "component": "control_C600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R601",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R602",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R606",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R603",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R604",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 2
      },
      {
        "component": "control_J600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_C603",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R605",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_R607",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_SW600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_U601",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_C601",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_C602",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      },
      {
        "component": "control_FB600",
        "sheet": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_600_FPGA_CONFIGURATION_AND_XADC"
  ],
  "suggestedScenario": "local-control_600_FPGA_CONFIGURATION_AND_XADC",
  "explanationTitleRu": "Загрузка и восстановление ПЛИС",
  "sourceSheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
  "sourceSheetName": "600_FPGA_CONFIGURATION_AND_XADC",
  "sourceFile": "600_FPGA_CONFIGURATION_AND_XADC.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-fpga",
  "layout": {
    "version": 2,
    "kind": "configuration-hub",
    "label": "Загрузка, восстановление и служебное питание ПЛИС",
    "geometryOnly": true
  },
  "regions": []
};
