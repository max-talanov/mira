/* Editable functional scene: power_500_AON_3V3_BUCK */
window.MIRA_FUNCTIONAL.scenes["power_500_AON_3V3_BUCK"]={
  "id": "power_500_AON_3V3_BUCK",
  "title": "500_AON_3V3_BUCK",
  "subtitle": "Дежурное питание контроля",
  "description": "U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход BUS24",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_500_AON_3V3_BUCK"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_500_AON_3V3_BUCK"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Дежурное питание 3,3 В: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U501",
        "power_L501",
        "power_R501",
        "power_R502"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_500_AON_3V3_BUCK",
      "sourceSheetIds": [
        "power_500_AON_3V3_BUCK"
      ],
      "circuitGroup": {
        "refs": [
          "power_U501",
          "power_L501",
          "power_R501",
          "power_R502"
        ],
        "sheetIds": [
          "power_500_AON_3V3_BUCK"
        ],
        "units": [
          {
            "component": "power_L501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_R501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_R502",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_U501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C502",
        "power_C503",
        "power_C501",
        "power_C504",
        "power_C505",
        "power_R504",
        "power_R503",
        "power_D501"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_500_AON_3V3_BUCK",
      "sourceSheetIds": [
        "power_500_AON_3V3_BUCK"
      ],
      "circuitGroup": {
        "refs": [
          "power_C502",
          "power_C503",
          "power_C501",
          "power_C504",
          "power_C505",
          "power_R504",
          "power_R503",
          "power_D501"
        ],
        "sheetIds": [
          "power_500_AON_3V3_BUCK"
        ],
        "units": [
          {
            "component": "power_C501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_C502",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_C503",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_C504",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_C505",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_D501",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_R503",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          },
          {
            "component": "power_R504",
            "sheet": "power_500_AON_3V3_BUCK",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход AON",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_500_AON_3V3_BUCK"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_500_AON_3V3_BUCK"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "BUS24",
      "type": "power",
      "nets": [
        "power_net_46d0d8d77ef1"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "BUS24",
      "netLabels": [
        "BUS24"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_67006db669b3",
        "power_net_bfbd5cdcdcfd",
        "power_net_c7b4c78d37bb",
        "power_net_478d89e5a433",
        "power_net_abd71ae65884"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "AON",
        "AON_FB",
        "AON_RAW",
        "AON_CB",
        "AON_SW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AON · AON_CB",
        "AON_FB · AON_RAW",
        "AON_SW"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "AON",
      "type": "power",
      "nets": [
        "power_net_67006db669b3"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "AON",
      "netLabels": [
        "AON"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "AON"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 338
  },
  "board": "power",
  "sheetId": "power_500_AON_3V3_BUCK",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 12,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U501",
      "power_L501",
      "power_R501",
      "power_R502",
      "power_C502",
      "power_C503",
      "power_C501",
      "power_C504",
      "power_C505",
      "power_R504",
      "power_R503",
      "power_D501"
    ],
    "sheetIds": [
      "power_500_AON_3V3_BUCK"
    ],
    "units": [
      {
        "component": "power_L501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_R501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_R502",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_U501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_C501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_C502",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_C503",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_C504",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_C505",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_D501",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_R503",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      },
      {
        "component": "power_R504",
        "sheet": "power_500_AON_3V3_BUCK",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_500_AON_3V3_BUCK"
  ],
  "suggestedScenario": "local-power_500_AON_3V3_BUCK",
  "explanationTitleRu": "Дежурное питание контроля",
  "sourceSheetId": "power_500_AON_3V3_BUCK",
  "sourceSheetName": "500_AON_3V3_BUCK",
  "sourceFile": "500_AON_3V3_BUCK.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-primary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
