/* Editable functional scene: control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS */
window.MIRA_FUNCTIONAL.scenes["control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"]={
  "id": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "title": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "subtitle": "Проверка согласованности операции",
  "description": "U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния.",
  "nodes": [
    {
      "id": "fpga",
      "title": "Запрос операции с матрицей",
      "subtitle": "",
      "description": "Выходы ПЛИС задают запросы режима, адреса и времени операции.",
      "refs": [
        "control_U500",
        "control_C1304",
        "control_C1302",
        "control_C1303",
        "control_R1303"
      ],
      "role": "control",
      "x": 40,
      "y": 280,
      "w": 280,
      "h": 150,
      "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U500",
          "control_C1304",
          "control_C1302",
          "control_C1303",
          "control_R1303"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_C1302",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1303",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1304",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_R1303",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U500",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 8
          }
        ]
      },
      "layoutRole": "gateway"
    },
    {
      "id": "capture",
      "title": "Фиксация активного запроса",
      "subtitle": "",
      "description": "Регистры фиксируют поля операции на время её выполнения.",
      "refs": [
        "control_U1301",
        "control_U1327",
        "control_U1328",
        "control_C1307",
        "control_C1333",
        "control_C1334"
      ],
      "role": "control",
      "x": 560,
      "y": 40,
      "w": 300,
      "h": 150,
      "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1301",
          "control_U1327",
          "control_U1328",
          "control_C1307",
          "control_C1333",
          "control_C1334"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_C1307",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1333",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1334",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1301",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1327",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1328",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "compare",
      "title": "Контроль изменения запроса",
      "subtitle": "",
      "description": "Компараторы сравнивают запрошенные поля с зафиксированными.",
      "refs": [
        "control_U1329",
        "control_U1330",
        "control_C1335"
      ],
      "role": "fault",
      "x": 1120,
      "y": 40,
      "w": 260,
      "h": 140,
      "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1329",
          "control_U1330",
          "control_C1335"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_C1335",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1329",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1330",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "permissions",
      "title": "Проверка разрешения на запуск",
      "subtitle": "",
      "description": "Логика проверяет питание, режим и блокировки перед разрешением коммутации.",
      "refs": [
        "control_U1300",
        "control_U1301",
        "control_U1302",
        "control_U1303",
        "control_U1304",
        "control_U1305",
        "control_U1306",
        "control_U1307",
        "control_U1308",
        "control_U1309",
        "control_U1310",
        "control_U1311",
        "control_U1312",
        "control_U1313",
        "control_U1314",
        "control_U1315",
        "control_U1316",
        "control_U1317",
        "control_U1318",
        "control_U1319",
        "control_U1320",
        "control_U1321",
        "control_U1322",
        "control_U1323",
        "control_U1324",
        "control_U1325",
        "control_U1326",
        "control_C1317",
        "control_C1318",
        "control_C1319",
        "control_C1326",
        "control_C1316",
        "control_C1327",
        "control_R1300",
        "control_C1306",
        "control_C1328",
        "control_C1314",
        "control_C1321",
        "control_C1324",
        "control_C1305",
        "control_C1322",
        "control_C1313",
        "control_C1301",
        "control_C1311",
        "control_C1325",
        "control_C1309",
        "control_C1312",
        "control_C1300",
        "control_C1320",
        "control_C1310",
        "control_C1315",
        "control_R1301",
        "control_C1308",
        "control_C1323",
        "control_C1329",
        "control_C1330",
        "control_C1331",
        "control_R1304"
      ],
      "role": "fault",
      "x": 1120,
      "y": 540,
      "w": 350,
      "h": 184,
      "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1300",
          "control_U1301",
          "control_U1302",
          "control_U1303",
          "control_U1304",
          "control_U1305",
          "control_U1306",
          "control_U1307",
          "control_U1308",
          "control_U1309",
          "control_U1310",
          "control_U1311",
          "control_U1312",
          "control_U1313",
          "control_U1314",
          "control_U1315",
          "control_U1316",
          "control_U1317",
          "control_U1318",
          "control_U1319",
          "control_U1320",
          "control_U1321",
          "control_U1322",
          "control_U1323",
          "control_U1324",
          "control_U1325",
          "control_U1326",
          "control_C1317",
          "control_C1318",
          "control_C1319",
          "control_C1326",
          "control_C1316",
          "control_C1327",
          "control_R1300",
          "control_C1306",
          "control_C1328",
          "control_C1314",
          "control_C1321",
          "control_C1324",
          "control_C1305",
          "control_C1322",
          "control_C1313",
          "control_C1301",
          "control_C1311",
          "control_C1325",
          "control_C1309",
          "control_C1312",
          "control_C1300",
          "control_C1320",
          "control_C1310",
          "control_C1315",
          "control_R1301",
          "control_C1308",
          "control_C1323",
          "control_C1329",
          "control_C1330",
          "control_C1331",
          "control_R1304"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_C1300",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1301",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1305",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1306",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1308",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1309",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1310",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1311",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1312",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1313",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1314",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1315",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1316",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1317",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1318",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1319",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1320",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1321",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1322",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1323",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1324",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1325",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1326",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1327",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1328",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1329",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1330",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1331",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_R1300",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_R1301",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_R1304",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1300",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1301",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1302",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1303",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1304",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1305",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1306",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1307",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1308",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1309",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1310",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1311",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1312",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1313",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1314",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1315",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1316",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1317",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1318",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1319",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1320",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1321",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1322",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1323",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1324",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1325",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1326",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "decode",
      "title": "Выбор операции",
      "subtitle": "",
      "description": "Логика режима и зафиксированного адреса выбирает коммутацию и безопасные рабочие состояния.",
      "refs": [
        "control_U1331",
        "control_U1332",
        "control_U1333",
        "control_U1334",
        "control_U1335",
        "control_U1336",
        "control_U1337",
        "control_U1338",
        "control_U1339",
        "control_U1340",
        "control_U1341",
        "control_U1342",
        "control_U1343",
        "control_U1344",
        "control_U1345",
        "control_U1346",
        "control_U1347",
        "control_U1348",
        "control_U1349",
        "control_U1350",
        "control_U1351",
        "control_U1352",
        "control_R1302",
        "control_C1332",
        "control_C1336",
        "control_C1337",
        "control_C1338",
        "control_C1339",
        "control_C1340",
        "control_C1341",
        "control_C1342",
        "control_C1343",
        "control_C1344",
        "control_C1345",
        "control_C1346",
        "control_C1347",
        "control_C1348",
        "control_C1349",
        "control_C1350",
        "control_C1351",
        "control_C1352",
        "control_C1353",
        "control_C1354",
        "control_C1355",
        "control_C1356",
        "control_C1357",
        "control_C1358"
      ],
      "role": "control",
      "x": 550,
      "y": 545,
      "w": 350,
      "h": 184,
      "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "sourceSheetIds": [
        "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
      ],
      "circuitGroup": {
        "refs": [
          "control_U1331",
          "control_U1332",
          "control_U1333",
          "control_U1334",
          "control_U1335",
          "control_U1336",
          "control_U1337",
          "control_U1338",
          "control_U1339",
          "control_U1340",
          "control_U1341",
          "control_U1342",
          "control_U1343",
          "control_U1344",
          "control_U1345",
          "control_U1346",
          "control_U1347",
          "control_U1348",
          "control_U1349",
          "control_U1350",
          "control_U1351",
          "control_U1352",
          "control_R1302",
          "control_C1332",
          "control_C1336",
          "control_C1337",
          "control_C1338",
          "control_C1339",
          "control_C1340",
          "control_C1341",
          "control_C1342",
          "control_C1343",
          "control_C1344",
          "control_C1345",
          "control_C1346",
          "control_C1347",
          "control_C1348",
          "control_C1349",
          "control_C1350",
          "control_C1351",
          "control_C1352",
          "control_C1353",
          "control_C1354",
          "control_C1355",
          "control_C1356",
          "control_C1357",
          "control_C1358"
        ],
        "sheetIds": [
          "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
        ],
        "units": [
          {
            "component": "control_C1332",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1336",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1337",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1338",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1339",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1340",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1341",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1342",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1343",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1344",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1345",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1346",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1347",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1348",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1349",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1350",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1351",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1352",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1353",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1354",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1355",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1356",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1357",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_C1358",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_R1302",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1331",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1332",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1333",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1334",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1335",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1336",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1337",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1338",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1339",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1340",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1341",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1342",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1343",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1344",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1345",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1346",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1347",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1348",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1349",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1350",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1351",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          },
          {
            "component": "control_U1352",
            "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    }
  ],
  "edges": [
    {
      "id": "fpga_capture",
      "from": "fpga",
      "to": "capture",
      "label": "13 цепей",
      "type": "analog",
      "nets": [
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "13 цепей",
      "netLabels": [
        "MAT_BL_A2_REQ",
        "MAT_BL_A0_REQ",
        "MAT_BL_A1_REQ",
        "MAT_POLARITY_REQ",
        "MAT_NL_A1_REQ",
        "MAT_RSH_A0_REQ",
        "MAT_NL_A0_REQ",
        "MAT_RSH_A1_REQ",
        "MAT_BL_A4_REQ",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_BL_A3_REQ",
        "MAT_NL_A2_REQ"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A2_REQ · MAT_BL_A0_REQ",
        "MAT_BL_A1_REQ · ещё 10"
      ],
      "allConnectionsLabel": "Все соединения: 13",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_compare",
      "from": "fpga",
      "to": "compare",
      "label": "13 цепей",
      "type": "analog",
      "nets": [
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "13 цепей",
      "netLabels": [
        "MAT_BL_A2_REQ",
        "MAT_BL_A0_REQ",
        "MAT_BL_A1_REQ",
        "MAT_POLARITY_REQ",
        "MAT_NL_A1_REQ",
        "MAT_RSH_A0_REQ",
        "MAT_NL_A0_REQ",
        "MAT_RSH_A1_REQ",
        "MAT_BL_A4_REQ",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_BL_A3_REQ",
        "MAT_NL_A2_REQ"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_BL_A2_REQ · MAT_BL_A0_REQ",
        "MAT_BL_A1_REQ · ещё 10"
      ],
      "allConnectionsLabel": "Все соединения: 13",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_permissions",
      "from": "fpga",
      "to": "permissions",
      "label": "Аппаратная защита",
      "type": "fault",
      "nets": [
        "control_net_30006651dbc3",
        "control_net_889281b6cc29",
        "control_net_429d3a1721ef",
        "control_net_d2248f535667",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_6e0242cad116",
        "control_net_1a607d7041f2"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Защита",
      "netLabels": [
        "MAT_VMM_EN_REQ",
        "MAT_WRITE_EN_REQ",
        "MAT_READ_EN_REQ",
        "MAT_SERVICE_EN_REQ",
        "MAT_PULSE",
        "MAT_SPI_OE_N",
        "MAT_FAULT_N",
        "MAT_FAULT_CLEAR_N"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_FAULT_CLEAR_N",
        "MAT_FAULT_N",
        "MAT_PULSE",
        "MAT_READ_EN_REQ",
        "MAT_SERVICE_EN_REQ",
        "MAT_SPI_OE_N",
        "MAT_VMM_EN_REQ",
        "MAT_WRITE_EN_REQ"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "fpga_decode",
      "from": "fpga",
      "to": "decode",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_a0f26e09322b",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_c4621dfd0ac4"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "MAT_SPI_LATCH",
        "MAT_PULSE",
        "MAT_SPI_OE_N",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_FRAME_VALID"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_FRAME_VALID",
        "MAT_PULSE",
        "MAT_SPI_LATCH",
        "MAT_SPI_OE_N",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ"
      ],
      "allConnectionsLabel": "Все соединения: 6",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "capture_compare",
      "from": "capture",
      "to": "compare",
      "label": "32 цепи",
      "type": "analog",
      "nets": [
        "control_net_5f9f5680becf",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_2690ba9f85c2",
        "control_net_1060da4e1062",
        "control_net_8e945f7df341",
        "control_net_103f84ec6132",
        "control_net_c6ecade8f839",
        "control_net_8e9184bc5c46",
        "control_net_ba2ab40384c6",
        "control_net_c254fca78b2c",
        "control_net_f16f12a0707d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_2a00cc654f3d",
        "control_net_5130997c4fe8",
        "control_net_942f92e36dcb",
        "control_net_c3b957dc2a05",
        "control_net_53c8d7c2e621",
        "control_net_68c0b1b9f3d9",
        "control_net_4cbb94b58c81",
        "control_net_5a48e06ad240",
        "control_net_11d0bca5a9c3",
        "control_net_5adbbaca70af",
        "control_net_5d5a8a88fb46",
        "control_net_3f65bb4e6c1b",
        "control_net_24511a425a2f",
        "control_net_558e432b5f50",
        "control_net_12757af1d119",
        "control_net_7a2e58dd0886",
        "control_net_b0ef82a04563"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "32 цепи",
      "netLabels": [
        "MAT_REQUEST_VALID",
        "MAT_READ_REQ",
        "MAT_SERVICE_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_BL_A2_REQ",
        "MAT_BL_A0_REQ",
        "MAT_BL_A1_REQ",
        "MAT_POLARITY_REQ",
        "MAT_NL_A1_REQ",
        "MAT_RSH_A0_REQ",
        "MAT_NL_A0_REQ",
        "MAT_RSH_A1_REQ",
        "MAT_BL_A4_REQ",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_BL_A3_REQ",
        "MAT_NL_A2_REQ",
        "MAT_SERVICE_REQ_RAW",
        "MAT_SRC_A0",
        "MAT_SRC_A1",
        "MAT_RSH_A0",
        "MAT_RSH_A1",
        "MAT_POLARITY",
        "MAT_BL_A0",
        "MAT_BL_A1",
        "MAT_BL_A2",
        "MAT_BL_A3",
        "MAT_BL_A4",
        "MAT_NL_A0",
        "MAT_NL_A1",
        "MAT_NL_A2",
        "MAT_REQUEST_VALID_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_REQUEST_VALID · MAT_READ_REQ",
        "MAT_SERVICE_REQ · ещё 29"
      ],
      "allConnectionsLabel": "Все соединения: 32",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "capture_permissions",
      "from": "capture",
      "to": "permissions",
      "label": "Выбор и фиксация управления",
      "type": "control",
      "nets": [
        "control_net_5f9f5680becf",
        "control_net_2e40141f478d",
        "control_net_87fe3b573357",
        "control_net_69257bd28c2b",
        "control_net_4e127893a2c9",
        "control_net_d0ee9c0888fb",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_942f92e36dcb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Зафиксированный выбор",
      "netLabels": [
        "MAT_REQUEST_VALID",
        "MAT_CONFIG_LATCH",
        "MAT_ARM_DATA",
        "MAT_IMAGE_ARMED",
        "MAT_ALLOWED",
        "MAT_READ_REQ",
        "MAT_SERVICE_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_SERVICE_REQ_RAW"
      ],
      "unnamedNetIds": [
        "control_net_69257bd28c2b"
      ],
      "labelLines": [
        "MAT_REQUEST_VALID · MAT_CONFIG_LATCH",
        "MAT_ARM_DATA · ещё 6"
      ],
      "allConnectionsLabel": "Все соединения: 10",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "capture_decode",
      "from": "capture",
      "to": "decode",
      "label": "Выбор и фиксация управления",
      "type": "control",
      "nets": [
        "control_net_2e40141f478d",
        "control_net_87fe3b573357",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_b0ef82a04563"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Зафиксированный выбор",
      "netLabels": [
        "MAT_CONFIG_LATCH",
        "MAT_ARM_DATA",
        "MAT_READ_REQ",
        "MAT_SERVICE_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_REQUEST_VALID_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_ARM_DATA",
        "MAT_CONFIG_LATCH",
        "MAT_READ_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_REQUEST_VALID_RAW",
        "MAT_SERVICE_REQ",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "compare_permissions",
      "from": "compare",
      "to": "permissions",
      "label": "5 цепей",
      "type": "data",
      "nets": [
        "control_net_5f9f5680becf",
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_942f92e36dcb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "5 цепей",
      "netLabels": [
        "MAT_REQUEST_VALID",
        "MAT_READ_REQ",
        "MAT_SERVICE_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_SERVICE_REQ_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_READ_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_REQUEST_VALID",
        "MAT_SERVICE_REQ",
        "MAT_SERVICE_REQ_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 5",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "compare_decode",
      "from": "compare",
      "to": "decode",
      "label": "8 цепей",
      "type": "data",
      "nets": [
        "control_net_6e69a2fb065e",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_d095506d8145",
        "control_net_df16aaaa5404",
        "control_net_b0ef82a04563",
        "control_net_7474db4906c0",
        "control_net_5d90f9633abb"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "8 цепей",
      "netLabels": [
        "MAT_READ_REQ",
        "MAT_SERVICE_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ",
        "MAT_REQUEST_VALID_RAW",
        "MAT_CONFIG_DIFF_0",
        "MAT_CONFIG_DIFF_1"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_CONFIG_DIFF_0",
        "MAT_CONFIG_DIFF_1",
        "MAT_READ_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_REQUEST_VALID_RAW",
        "MAT_SERVICE_REQ",
        "MAT_SRC_A0_REQ",
        "MAT_SRC_A1_REQ"
      ],
      "allConnectionsLabel": "Все соединения: 8",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "bottom",
      "toSide": "top"
    },
    {
      "id": "permissions_decode",
      "from": "permissions",
      "to": "decode",
      "label": "Последовательные команды",
      "type": "control",
      "nets": [
        "control_net_b544695cd7b3",
        "control_net_49fde52ce0ed",
        "control_net_2e40141f478d",
        "control_net_87fe3b573357",
        "control_net_6e69a2fb065e",
        "control_net_a263c7c6e291",
        "control_net_8e443662774e",
        "control_net_93d867935f6d",
        "control_net_d846a1ae0de8",
        "control_net_0831bf7686e1",
        "control_net_390c067b3ead",
        "control_net_ae0baa487445",
        "control_net_4680bd4e9f98"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Последовательные команды",
      "netLabels": [
        "MAT_RUN",
        "MAT_RUN_INTENT",
        "MAT_CONFIG_LATCH",
        "MAT_ARM_DATA",
        "MAT_READ_REQ",
        "MAT_WRITE_REQ",
        "MAT_SERVICE_REQ",
        "MAT_READ_REQ_RAW",
        "MAT_PULSE",
        "MAT_SPI_OE_N",
        "MAT_VMM_REQ",
        "MAT_VMM_REQ_RAW",
        "MAT_REQUEST_BASE_VALID_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "MAT_RUN · MAT_RUN_INTENT",
        "MAT_CONFIG_LATCH · ещё 10"
      ],
      "allConnectionsLabel": "Все соединения: 13",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "left",
      "toSide": "right"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 5,
    "w": 1510,
    "h": 764
  },
  "board": "control",
  "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 118,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U500",
      "control_C1304",
      "control_C1302",
      "control_C1303",
      "control_R1303",
      "control_U1301",
      "control_U1327",
      "control_U1328",
      "control_C1307",
      "control_C1333",
      "control_C1334",
      "control_U1329",
      "control_U1330",
      "control_C1335",
      "control_U1300",
      "control_U1302",
      "control_U1303",
      "control_U1304",
      "control_U1305",
      "control_U1306",
      "control_U1307",
      "control_U1308",
      "control_U1309",
      "control_U1310",
      "control_U1311",
      "control_U1312",
      "control_U1313",
      "control_U1314",
      "control_U1315",
      "control_U1316",
      "control_U1317",
      "control_U1318",
      "control_U1319",
      "control_U1320",
      "control_U1321",
      "control_U1322",
      "control_U1323",
      "control_U1324",
      "control_U1325",
      "control_U1326",
      "control_C1317",
      "control_C1318",
      "control_C1319",
      "control_C1326",
      "control_C1316",
      "control_C1327",
      "control_R1300",
      "control_C1306",
      "control_C1328",
      "control_C1314",
      "control_C1321",
      "control_C1324",
      "control_C1305",
      "control_C1322",
      "control_C1313",
      "control_C1301",
      "control_C1311",
      "control_C1325",
      "control_C1309",
      "control_C1312",
      "control_C1300",
      "control_C1320",
      "control_C1310",
      "control_C1315",
      "control_R1301",
      "control_C1308",
      "control_C1323",
      "control_C1329",
      "control_C1330",
      "control_C1331",
      "control_R1304",
      "control_U1331",
      "control_U1332",
      "control_U1333",
      "control_U1334",
      "control_U1335",
      "control_U1336",
      "control_U1337",
      "control_U1338",
      "control_U1339",
      "control_U1340",
      "control_U1341",
      "control_U1342",
      "control_U1343",
      "control_U1344",
      "control_U1345",
      "control_U1346",
      "control_U1347",
      "control_U1348",
      "control_U1349",
      "control_U1350",
      "control_U1351",
      "control_U1352",
      "control_R1302",
      "control_C1332",
      "control_C1336",
      "control_C1337",
      "control_C1338",
      "control_C1339",
      "control_C1340",
      "control_C1341",
      "control_C1342",
      "control_C1343",
      "control_C1344",
      "control_C1345",
      "control_C1346",
      "control_C1347",
      "control_C1348",
      "control_C1349",
      "control_C1350",
      "control_C1351",
      "control_C1352",
      "control_C1353",
      "control_C1354",
      "control_C1355",
      "control_C1356",
      "control_C1357",
      "control_C1358"
    ],
    "sheetIds": [
      "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
    ],
    "units": [
      {
        "component": "control_C1302",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1303",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1304",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_R1303",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U500",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 8
      },
      {
        "component": "control_C1307",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1333",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1334",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1301",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1327",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1328",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1335",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1329",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1330",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1300",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1301",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1305",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1306",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1308",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1309",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1310",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1311",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1312",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1313",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1314",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1315",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1316",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1317",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1318",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1319",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1320",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1321",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1322",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1323",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1324",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1325",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1326",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1327",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1328",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1329",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1330",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1331",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_R1300",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_R1301",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_R1304",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1300",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1302",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1303",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1304",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1305",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1306",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1307",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1308",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1309",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1310",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1311",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1312",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1313",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1314",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1315",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1316",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1317",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1318",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1319",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1320",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1321",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1322",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1323",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1324",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1325",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1326",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1332",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1336",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1337",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1338",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1339",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1340",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1341",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1342",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1343",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1344",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1345",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1346",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1347",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1348",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1349",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1350",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1351",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1352",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1353",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1354",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1355",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1356",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1357",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_C1358",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_R1302",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1331",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1332",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1333",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1334",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1335",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1336",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1337",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1338",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1339",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1340",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1341",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1342",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1343",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1344",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1345",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1346",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1347",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1348",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1349",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1350",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1351",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      },
      {
        "component": "control_U1352",
        "sheet": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS"
  ],
  "suggestedScenario": "local-control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "explanationTitleRu": "Проверка согласованности операции",
  "sourceSheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "sourceSheetName": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
  "sourceFile": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "control-routing",
  "layout": {
    "version": 2,
    "kind": "interlock-loop",
    "label": "Запрос, фиксация, проверка и разрешённое действие",
    "geometryOnly": true
  },
  "regions": []
};
