/* Editable functional scene: power_400_INPUT_FILTER_SENSE */
window.MIRA_FUNCTIONAL.scenes["power_400_INPUT_FILTER_SENSE"]={
  "id": "power_400_INPUT_FILTER_SENSE",
  "title": "400_INPUT_FILTER_SENSE",
  "subtitle": "Фильтрация защищённой шины 24 В",
  "description": "L401 и локальные конденсаторы фильтруют EFUSE_OUT. R401 служит шунтом входного тока перед BUS24.",
  "nodes": [
    {
      "id": "filter",
      "title": "Фильтрация помех шины",
      "subtitle": "",
      "description": "Фильтр и локальные конденсаторы подавляют помехи на защищённой шине питания.",
      "refs": [
        "power_L401",
        "power_C402",
        "power_C403",
        "power_C401"
      ],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 350,
      "h": 184,
      "sheetId": "power_400_INPUT_FILTER_SENSE",
      "sourceSheetIds": [
        "power_400_INPUT_FILTER_SENSE"
      ],
      "circuitGroup": {
        "refs": [
          "power_L401",
          "power_C402",
          "power_C403",
          "power_C401"
        ],
        "sheetIds": [
          "power_400_INPUT_FILTER_SENSE"
        ],
        "units": [
          {
            "component": "power_C401",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_C402",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_C403",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_L401",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "sense",
      "title": "Контроль входной мощности",
      "subtitle": "",
      "description": "Измерительные и индикаторные цепи предоставляют сигналы состояния входа для остальных узлов.",
      "refs": [
        "power_D401",
        "power_R404",
        "power_R402",
        "power_R403",
        "power_R401"
      ],
      "role": "analog",
      "x": 760,
      "y": 195,
      "w": 280,
      "h": 150,
      "sheetId": "power_400_INPUT_FILTER_SENSE",
      "sourceSheetIds": [
        "power_400_INPUT_FILTER_SENSE"
      ],
      "circuitGroup": {
        "refs": [
          "power_D401",
          "power_R404",
          "power_R402",
          "power_R403",
          "power_R401"
        ],
        "sheetIds": [
          "power_400_INPUT_FILTER_SENSE"
        ],
        "units": [
          {
            "component": "power_D401",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_R401",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_R402",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_R403",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          },
          {
            "component": "power_R404",
            "sheet": "power_400_INPUT_FILTER_SENSE",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    }
  ],
  "edges": [
    {
      "id": "filter_sense",
      "from": "filter",
      "to": "sense",
      "label": "Локальная связь по питанию",
      "type": "power",
      "nets": [
        "power_net_8174cad108e5"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.",
      "undirected": true,
      "flow": "association",
      "shortLabel": "Локальная связь по питанию",
      "netLabels": [
        "BUS24_PRE_SHUNT"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "BUS24_PRE_SHUNT"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    }
  ],
  "bounds": {
    "x": 0,
    "y": 145,
    "w": 1080,
    "h": 259
  },
  "board": "power",
  "sheetId": "power_400_INPUT_FILTER_SENSE",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 9,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_L401",
      "power_C402",
      "power_C403",
      "power_C401",
      "power_D401",
      "power_R404",
      "power_R402",
      "power_R403",
      "power_R401"
    ],
    "sheetIds": [
      "power_400_INPUT_FILTER_SENSE"
    ],
    "units": [
      {
        "component": "power_C401",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_C402",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_C403",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_L401",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_D401",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_R401",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_R402",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_R403",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      },
      {
        "component": "power_R404",
        "sheet": "power_400_INPUT_FILTER_SENSE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_400_INPUT_FILTER_SENSE"
  ],
  "suggestedScenario": "local-power_400_INPUT_FILTER_SENSE",
  "explanationTitleRu": "Фильтрация защищённой шины 24 В",
  "sourceSheetId": "power_400_INPUT_FILTER_SENSE",
  "sourceSheetName": "400_INPUT_FILTER_SENSE",
  "sourceFile": "400_INPUT_FILTER_SENSE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-input",
  "layout": {
    "version": 2,
    "kind": "paired-functions",
    "label": "Основной узел и связанная функция",
    "geometryOnly": true
  },
  "regions": []
};
