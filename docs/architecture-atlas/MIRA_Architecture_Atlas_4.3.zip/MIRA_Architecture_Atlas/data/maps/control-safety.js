/* Editable functional scene: control-safety */
window.MIRA_FUNCTIONAL.scenes["control-safety"]={
  "id": "control-safety",
  "title": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "subtitle": "Остановка и фиксация аварий матрицы",
  "description": "Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.",
  "nodes": [
    {
      "id": "sheet2200",
      "title": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "subtitle": "Аппаратная остановка матрицы",
      "description": "U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.",
      "refs": [
        "control_U2201",
        "control_U2200",
        "control_U2202",
        "control_U2203"
      ],
      "role": "analog",
      "x": 40,
      "y": 70,
      "w": 410,
      "h": 210,
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetIds": [
        "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
      ],
      "circuitGroup": {
        "refs": [
          "control_U2201",
          "control_U2200",
          "control_U2202",
          "control_U2203"
        ],
        "sheetIds": [
          "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
        ],
        "units": [
          {
            "component": "control_U2200",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2201",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2202",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          },
          {
            "component": "control_U2203",
            "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
            "unit": 1
          }
        ]
      },
      "explanationTitleRu": "Аппаратная остановка матрицы",
      "sourceSheetName": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceSheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "sourceFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
      "layoutRole": "primary"
    }
  ],
  "edges": [],
  "bounds": {
    "x": 0,
    "y": 35,
    "w": 490,
    "h": 285
  },
  "board": "control",
  "sheetIds": [
    "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
  ],
  "kind": "section",
  "depth": 1,
  "terminal": false,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "control_U2201",
      "control_U2200",
      "control_U2202",
      "control_U2203"
    ],
    "sheetIds": [
      "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE"
    ],
    "units": [
      {
        "component": "control_U2200",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2201",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2202",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      },
      {
        "component": "control_U2203",
        "sheet": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-control-safety"
  ],
  "suggestedScenario": "local-control-safety",
  "explanationTitleRu": "Остановка и фиксация аварий матрицы",
  "sourceSheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "sourceSheetName": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
  "sourceFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": true,
  "parentScene": "control_PROTECTION",
  "layout": {
    "version": 2,
    "kind": "functional-islands",
    "label": "Функциональные группы; электрические связи не добавлены",
    "geometryOnly": true
  },
  "regions": []
};
