/* Editable functional scene: power_1500_FPGA_IO_3V3 */
window.MIRA_FUNCTIONAL.scenes["power_1500_FPGA_IO_3V3"]={
  "id": "power_1500_FPGA_IO_3V3",
  "title": "1500_FPGA_IO_3V3",
  "subtitle": "Питание выводов ПЛИС 3,3 В",
  "description": "U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.",
  "nodes": [
    {
      "id": "input",
      "title": "Вход FPGA5V5",
      "subtitle": "",
      "description": "Входная шина питания этого преобразователя.",
      "refs": [],
      "role": "power",
      "x": 40,
      "y": 180,
      "w": 230,
      "h": 128,
      "sourceSheetIds": [
        "power_1500_FPGA_IO_3V3"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1500_FPGA_IO_3V3"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    },
    {
      "id": "convert",
      "title": "Преобразование и стабилизация",
      "subtitle": "",
      "description": "Питание выводов ПЛИС: напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.",
      "refs": [
        "power_U1501",
        "power_L1501",
        "power_R1505",
        "power_R1502",
        "power_R1503",
        "power_R1504"
      ],
      "role": "power",
      "x": 510,
      "y": 155,
      "w": 350,
      "h": 184,
      "sheetId": "power_1500_FPGA_IO_3V3",
      "sourceSheetIds": [
        "power_1500_FPGA_IO_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_U1501",
          "power_L1501",
          "power_R1505",
          "power_R1502",
          "power_R1503",
          "power_R1504"
        ],
        "sheetIds": [
          "power_1500_FPGA_IO_3V3"
        ],
        "units": [
          {
            "component": "power_L1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_R1502",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_R1503",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_R1504",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_R1505",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_U1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "primary"
    },
    {
      "id": "enable",
      "title": "Приём команды включения",
      "subtitle": "",
      "description": "Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.",
      "refs": [
        "power_Q1501",
        "power_R1501"
      ],
      "role": "control",
      "x": 535,
      "y": 560,
      "w": 260,
      "h": 138,
      "sheetId": "power_1500_FPGA_IO_3V3",
      "sourceSheetIds": [
        "power_1500_FPGA_IO_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_Q1501",
          "power_R1501"
        ],
        "sheetIds": [
          "power_1500_FPGA_IO_3V3"
        ],
        "units": [
          {
            "component": "power_Q1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_R1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "support"
    },
    {
      "id": "filter",
      "title": "Обратная связь и фильтрация",
      "subtitle": "",
      "description": "Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.",
      "refs": [
        "power_C1503",
        "power_C1502",
        "power_C1501",
        "power_C1504",
        "power_R1506"
      ],
      "role": "power",
      "x": 1060,
      "y": 180,
      "w": 250,
      "h": 140,
      "sheetId": "power_1500_FPGA_IO_3V3",
      "sourceSheetIds": [
        "power_1500_FPGA_IO_3V3"
      ],
      "circuitGroup": {
        "refs": [
          "power_C1503",
          "power_C1502",
          "power_C1501",
          "power_C1504",
          "power_R1506"
        ],
        "sheetIds": [
          "power_1500_FPGA_IO_3V3"
        ],
        "units": [
          {
            "component": "power_C1501",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_C1502",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_C1503",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_C1504",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          },
          {
            "component": "power_R1506",
            "sheet": "power_1500_FPGA_IO_3V3",
            "unit": 1
          }
        ]
      },
      "layoutRole": "interface"
    },
    {
      "id": "output",
      "title": "Выход IO3V3",
      "subtitle": "",
      "description": "Сформированная шина поступает к потребителям и цепям контроля.",
      "refs": [],
      "role": "power",
      "x": 1540,
      "y": 180,
      "w": 250,
      "h": 140,
      "sourceSheetIds": [
        "power_1500_FPGA_IO_3V3"
      ],
      "circuitGroup": {
        "refs": [],
        "sheetIds": [
          "power_1500_FPGA_IO_3V3"
        ],
        "units": []
      },
      "layoutRole": "gateway"
    }
  ],
  "edges": [
    {
      "id": "input_convert",
      "from": "input",
      "to": "convert",
      "label": "FPGA5V5",
      "type": "power",
      "nets": [
        "power_net_cd1e0a0c9a0e"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "FPGA5V5",
      "netLabels": [
        "FPGA5V5"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "FPGA5V5"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "convert_filter",
      "from": "convert",
      "to": "filter",
      "label": "Стабилизированный выход",
      "type": "power",
      "nets": [
        "power_net_6c6a12e16365",
        "power_net_33017e9a066b"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Стабилизированное питание",
      "netLabels": [
        "IO3V3",
        "IO33_RAW"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "IO3V3",
        "IO33_RAW"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "filter_output",
      "from": "filter",
      "to": "output",
      "label": "IO3V3",
      "type": "power",
      "nets": [
        "power_net_6c6a12e16365"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "IO3V3",
      "netLabels": [
        "IO3V3"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "IO3V3"
      ],
      "allConnectionsLabel": "Все соединения: 1",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "right",
      "toSide": "left"
    },
    {
      "id": "enable_convert",
      "from": "enable",
      "to": "convert",
      "label": "Разрешённое включение",
      "type": "control",
      "nets": [
        "power_net_04b2f0a4c78b",
        "power_net_ae3413231f47"
      ],
      "bidirectional": false,
      "scope": "electrical",
      "description": "",
      "shortLabel": "Включение",
      "netLabels": [
        "CMD_IO33",
        "EN_IO33"
      ],
      "unnamedNetIds": [],
      "labelLines": [
        "CMD_IO33",
        "EN_IO33"
      ],
      "allConnectionsLabel": "Все соединения: 2",
      "namePolicy": "Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.",
      "fromSide": "top",
      "toSide": "bottom"
    }
  ],
  "bounds": {
    "x": -28,
    "y": 66,
    "w": 1886,
    "h": 672
  },
  "board": "power",
  "sheetId": "power_1500_FPGA_IO_3V3",
  "detailPolicy": "Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.",
  "sourceComponentCount": 13,
  "kind": "module",
  "depth": 2,
  "terminal": true,
  "navigationPolicy": "Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.",
  "circuitGroup": {
    "refs": [
      "power_U1501",
      "power_L1501",
      "power_R1505",
      "power_R1502",
      "power_R1503",
      "power_R1504",
      "power_Q1501",
      "power_R1501",
      "power_C1503",
      "power_C1502",
      "power_C1501",
      "power_C1504",
      "power_R1506"
    ],
    "sheetIds": [
      "power_1500_FPGA_IO_3V3"
    ],
    "units": [
      {
        "component": "power_L1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_R1502",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_R1503",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_R1504",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_R1505",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_U1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_Q1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_R1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_C1501",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_C1502",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_C1503",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_C1504",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      },
      {
        "component": "power_R1506",
        "sheet": "power_1500_FPGA_IO_3V3",
        "unit": 1
      }
    ]
  },
  "localScenarioIds": [
    "local-power_1500_FPGA_IO_3V3"
  ],
  "suggestedScenario": "local-power_1500_FPGA_IO_3V3",
  "explanationTitleRu": "Питание выводов ПЛИС 3,3 В",
  "sourceSheetId": "power_1500_FPGA_IO_3V3",
  "sourceSheetName": "1500_FPGA_IO_3V3",
  "sourceFile": "1500_FPGA_IO_3V3.kicad_sch",
  "nameSource": "kicad-sheetname",
  "hidden": false,
  "parentScene": "power-secondary",
  "layout": {
    "version": 2,
    "kind": "power-conversion",
    "label": "Путь энергии и отдельный вход разрешения",
    "geometryOnly": true
  },
  "regions": [
    {
      "x": 12,
      "y": 101,
      "w": 1806,
      "h": 263,
      "title": "Преобразование питания",
      "kind": "power",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ]
    }
  ]
};
