/* Module: 1900_ADC_TIA_AND_MONITOR_SELECTOR.kicad_sch */
window.MIRA_CONTENT.modules["1900_ADC_TIA_AND_MONITOR_SELECTOR.kicad_sch"]={
  "purpose": "U1900 converts selected matrix current into a voltage. U1901 selects the feedback range; U1902 chooses the monitored analog node.",
  "inputs": [
    "MAT_TIA_IN receives the selected READ current.",
    "MAT_TIA_A0…2 select TIA feedback.",
    "MAT_SENSE_A0…2 select the measured node.",
    "MAT_CC_SENSE and MAT_ILIM_SENSE arrive from the CV/CC stage."
  ],
  "outputs": [
    "MAT_TIA_OUT is the current-to-voltage result.",
    "MAT_MONITOR_RAW feeds the ADC input buffer.",
    "MAT_CC_SENSE_BUF and MAT_ILIM_SENSE_BUF isolate control/trip measurements."
  ],
  "operation": [
    "U1900 holds the TIA input near ground and converts current using its selected effective feedback impedance.",
    "U1901 chooses a paired feedback R/C branch in parallel with the permanent feedback network.",
    "U1903 buffers current sense and current target.",
    "U1902 selects TIA, BL/NL service or buffered compliance signals for conversion."
  ],
  "notes": [
    "TIA gain includes switch resistance and the permanent 10 Mohm branch.",
    "The source proposes initial validation at no more than 100 kSPS with a 20 us post-change delay; actual settling must be verified."
  ],
  "category": "Acquisition",
  "source": "Schematic labels and explanatory notes in 1900_ADC_TIA_AND_MONITOR_SELECTOR.kicad_sch"
};
