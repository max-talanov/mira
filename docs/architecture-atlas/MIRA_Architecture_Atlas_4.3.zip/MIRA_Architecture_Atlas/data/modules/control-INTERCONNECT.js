/* Module: INTERCONNECT.kicad_sch */
window.MIRA_CONTENT.modules["INTERCONNECT.kicad_sch"]={
  "purpose": "Control-side power inputs, receiving domains and the return path for hardware inhibition.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Interconnect",
  "source": "Reachable hierarchy in INTERCONNECT.kicad_sch"
};
