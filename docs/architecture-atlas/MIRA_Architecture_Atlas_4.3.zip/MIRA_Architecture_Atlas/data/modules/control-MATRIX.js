/* Module: MATRIX.kicad_sch */
window.MIRA_CONTENT.modules["MATRIX.kicad_sch"]={
  "purpose": "Held digital configuration, line masks, analog selection and the crossbar socket.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Matrix routing",
  "source": "Reachable hierarchy in MATRIX.kicad_sch"
};
