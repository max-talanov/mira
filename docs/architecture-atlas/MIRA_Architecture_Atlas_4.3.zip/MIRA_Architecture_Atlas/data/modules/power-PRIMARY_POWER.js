/* Module: PRIMARY_POWER.kicad_sch */
window.MIRA_CONTENT.modules["PRIMARY_POWER.kicad_sch"]={
  "purpose": "BUS24-derived always-on, system, USB, FPGA intermediate and analog/AFE supplies.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Power conversion",
  "source": "Reachable hierarchy in PRIMARY_POWER.kicad_sch"
};
