/* Module: 2500_PM_WATCHDOGS.kicad_sch */
window.MIRA_CONTENT.modules["2500_PM_WATCHDOGS.kicad_sch"]={
  "purpose": "U2501 and U2502 independently supervise the power controller and host supplies/heartbeats.",
  "inputs": [
    "AON and SYS3V3 are supervised.",
    "PM_WDI and HOST_WDI carry heartbeat edges.",
    "J2501/J2502 provide manual reset contacts."
  ],
  "outputs": [
    "AON_RESET_N and HOST_RESET_N report reset conditions.",
    "PM_WDO_N and HOST_WDO_N report watchdog expiry.",
    "PM_RESET_N combines AON reset and the PM watchdog event."
  ],
  "operation": [
    "A supply fault or manual reset asserts the corresponding reset.",
    "Heartbeat activity prevents external watchdog expiry.",
    "A watchdog event reaches the permit interlocks; PM expiry also resets U2401.",
    "Reset release and permission re-arm are separate actions."
  ],
  "notes": [
    "The source nominal watchdog timeout is 1.60 s; firmware must meet its minimum specified interval.",
    "Host readiness is also required while SYS3V3 is absent."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 2500_PM_WATCHDOGS.kicad_sch"
};
