/* Module: 3700_MONITOR_FPGA_CORE_AUX_IO.kicad_sch */
window.MIRA_CONTENT.modules["3700_MONITOR_FPGA_CORE_AUX_IO.kicad_sch"]={
  "purpose": "U3701–U3704 monitor the FPGA core, auxiliary and I/O rails.",
  "inputs": [
    "Upstream RAW and delivered rail nodes span each current shunt.",
    "AON powers the sense amplifiers and clamp references."
  ],
  "outputs": [
    "MON_I_CORE reports conditioned current.",
    "MON_I_AUX18 reports conditioned current.",
    "MON_I_AUX25 reports conditioned current.",
    "MON_I_IO33 reports conditioned current.",
    "MON_V_CORE reports conditioned load voltage.",
    "MON_V_AUX18 reports conditioned load voltage.",
    "MON_V_AUX25 reports conditioned load voltage.",
    "MON_V_IO33 reports conditioned load voltage.",
    "OC_OK_N joins open-drain hardware current alerts."
  ],
  "operation": [
    "Current amplifiers measure the shunt voltage.",
    "Voltage dividers measure the delivered rail and clamps limit monitor-node excursions.",
    "Paired MON_I/MON_V signals continue to the telemetry multiplexers.",
    "INA301 alert outputs can assert OC_OK_N independently of ADC polling."
  ],
  "notes": [
    "Hardware alert and filtered telemetry have different signal paths.",
    "Thresholds must be reviewed against converter, load and inrush limits."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 3700_MONITOR_FPGA_CORE_AUX_IO.kicad_sch"
};
