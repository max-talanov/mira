/* Module: 2100_PROGRAM_POSITIVE.kicad_sch */
window.MIRA_CONTENT.modules["2100_PROGRAM_POSITIVE.kicad_sch"]={
  "purpose": "The opposed Q2102/Q2103 PMOS pair connects P15 to PROG_P15 under MATRIX_PERMIT; the surrounding devices control gate clamp and discharge.",
  "inputs": [
    "P15 supplies the positive programming branch.",
    "MATRIX_PERMIT is the hardware authorization.",
    "AON supplies the optocoupler control side."
  ],
  "outputs": [
    "PROG_P15 is the switched positive rail.",
    "MATRIX_OPTO_K drives the optocoupler network shared with the negative branch."
  ],
  "operation": [
    "Permit enables the pass-gate pull-down path and disables the OFF clamps.",
    "The opposed MOSFETs connect the upstream rail while blocking both body-diode directions when off.",
    "Loss of permit clamps the gates back to their sources.",
    "The discharge path removes stored output charge after its own gate transition."
  ],
  "notes": [
    "This is a power switch; the upstream regulator sets the rail voltage.",
    "The RC and output capacitance create finite turn-off/discharge times."
  ],
  "category": "Programming power",
  "source": "Schematic labels and explanatory notes in 2100_PROGRAM_POSITIVE.kicad_sch"
};
