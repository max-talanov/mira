/* Module: 2200_PROGRAM_NEGATIVE.kicad_sch */
window.MIRA_CONTENT.modules["2200_PROGRAM_NEGATIVE.kicad_sch"]={
  "purpose": "Q2201/Q2202 form the opposed NMOS negative programming switch, with optocoupler control, OFF clamp and discharge.",
  "inputs": [
    "N15 supplies the negative programming branch.",
    "MATRIX_OPTO_K sinks the optocoupler LED currents.",
    "AON supplies the control-side LED network."
  ],
  "outputs": [
    "PROG_N15 is the switched negative rail."
  ],
  "operation": [
    "The optocouplers shift enable control into the negative gate domain.",
    "The opposed MOSFET pair connects N15 while permission is active.",
    "Without drive, the gate clamp returns the pass pair to OFF.",
    "Q2204 and the discharge resistors remove output charge."
  ],
  "notes": [
    "The rail follows N15 and switch/interconnect loss; no voltage conversion occurs here.",
    "The 10 V zeners protect gate-source stress rather than setting stimulus amplitude."
  ],
  "category": "Programming power",
  "source": "Schematic labels and explanatory notes in 2200_PROGRAM_NEGATIVE.kicad_sch"
};
