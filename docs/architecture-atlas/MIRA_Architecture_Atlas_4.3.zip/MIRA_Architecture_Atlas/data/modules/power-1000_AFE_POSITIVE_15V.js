/* Module: 1000_AFE_POSITIVE_15V.kicad_sch */
window.MIRA_CONTENT.modules["1000_AFE_POSITIVE_15V.kicad_sch"]={
  "purpose": "U1001 converts BUS24 into P15 for the positive analog-front-end domain.",
  "inputs": [
    "BUS24 is the upstream supply.",
    "CMD_P15 drives the local enable path to EN_P15."
  ],
  "outputs": [
    "P15_RAW is the regulated node before the current-sense shunt.",
    "P15 is the delivered load-side rail."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_P15.",
    "EN_P15 enables U1001 only after the upstream supply is available.",
    "The switching stage and output filter establish P15_RAW.",
    "The output shunt separates P15_RAW from P15; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1000_AFE_POSITIVE_15V.kicad_sch"
};
