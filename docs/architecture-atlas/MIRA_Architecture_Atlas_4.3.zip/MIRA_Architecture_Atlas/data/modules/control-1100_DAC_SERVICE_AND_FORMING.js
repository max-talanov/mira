/* Module: 1100_DAC_SERVICE_AND_FORMING.kicad_sch */
window.MIRA_CONTENT.modules["1100_DAC_SERVICE_AND_FORMING.kicad_sch"]={
  "purpose": "U1100 generates READ/SET/RESET, word-line, current-limit and bias commands. U1103/U1104 create the separate FORMING voltage target.",
  "inputs": [
    "CS_CTRL selects U1100; CS_HV selects U1103.",
    "The common DAC_SPI_* bus and DAC_LDAC_N / DAC_RESET_N control the converters.",
    "P15/N15 and PROG_P15/PROG_N15 supply the indicated buffers."
  ],
  "outputs": [
    "VREAD_SRC, VSET_SRC, VRESET_SRC and VFORM_SRC feed voltage-target selection.",
    "VWL_SRC drives the shared word-line source.",
    "ILIM_SET, ILIM_RESET and ILIM_FORM command current compliance.",
    "MATRIX_BIAS_SRC feeds optional socket bias."
  ],
  "operation": [
    "U1100 outputs the service voltage and current commands.",
    "U1101 amplifies the READ/SET/RESET targets and buffers word-line voltage.",
    "U1102 buffers current limits and socket bias.",
    "U1103 provides the FORMING command; U1104 buffers it.",
    "U1601 selects a voltage target while the source-side CV/CC stage supplies DUT power."
  ],
  "notes": [
    "WRITE voltage targets use a positive range; MAT_POLARITY sets the DUT sign.",
    "READ and SET share ILIM_SET.",
    "Service DAC changes during intended WRITE are monitored by the digital protection logic."
  ],
  "category": "Analog sources",
  "source": "Schematic labels and explanatory notes in 1100_DAC_SERVICE_AND_FORMING.kicad_sch"
};
