/* Module: 1800_DDR_VTT_REFERENCE.kicad_sch */
window.MIRA_CONTENT.modules["1800_DDR_VTT_REFERENCE.kicad_sch"]={
  "purpose": "U1801 generates a source/sink DDR termination supply and a tracking reference from DDR1V35.",
  "inputs": [
    "DDR1V35 establishes the tracking level.",
    "CMD_VTT drives the local enable path.",
    "AON provides control/status bias."
  ],
  "outputs": [
    "VTT is the tracking termination supply.",
    "DDR_VREF is the quiet DDR reference.",
    "PGR_VTT returns power-good status."
  ],
  "operation": [
    "The input/reference network derives the half-DDR target.",
    "The enable path releases U1801 when the upstream DDR rail is valid.",
    "The regulator sources or sinks termination current to hold VTT near the target.",
    "DDR_VREF is carried separately to the memory and FPGA reference inputs."
  ],
  "notes": [
    "VTT must source and sink; it is not interchangeable with a passive divider.",
    "Available current and ramp behavior depend on the actual thermal and loading conditions."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1800_DDR_VTT_REFERENCE.kicad_sch"
};
