/* Module: 800_FPGA_INTERMEDIATE_5V5.kicad_sch */
window.MIRA_CONTENT.modules["800_FPGA_INTERMEDIATE_5V5.kicad_sch"]={
  "purpose": "U801 converts BUS24 into FPGA5V5 for the downstream FPGA, DDR and PHY converters.",
  "inputs": [
    "BUS24 is the upstream supply.",
    "CMD_FPGA drives the local enable path to EN_FPGA."
  ],
  "outputs": [
    "FPGA_RAW is the regulated node before the current-sense shunt.",
    "FPGA5V5 is the delivered load-side rail.",
    "PG_FPGA reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_FPGA.",
    "EN_FPGA enables U801 only after the upstream supply is available.",
    "The switching stage and output filter establish FPGA_RAW.",
    "The output shunt separates FPGA_RAW from FPGA5V5; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 800_FPGA_INTERMEDIATE_5V5.kicad_sch"
};
