/* Module: 600_FPGA_CONFIGURATION_AND_XADC.kicad_sch */
window.MIRA_CONTENT.modules["600_FPGA_CONFIGURATION_AND_XADC.kicad_sch"]={
  "purpose": "U500 loads configuration from U600 SPI flash; J600, SW600 and U601 provide debug and recovery paths. FB600 filters the XADC supply.",
  "inputs": [
    "IO3V3 powers the configuration flash and configuration bank.",
    "MCU_RESET_FPGA_N drives open-drain U601.",
    "J600 accepts JTAG TCK, TMS and TDI.",
    "AUX1V8 feeds FB600."
  ],
  "outputs": [
    "FPGA_CFG_CLK / CS_N / D0…D3 connect U500 and U600.",
    "FPGA_DONE and FPGA_INIT_N report configuration state.",
    "FPGA_PROGRAM_N can be pulled low by SW600 or U601.",
    "FPGA_VCCADC supplies the internal monitor circuitry."
  ],
  "operation": [
    "The fixed mode straps select Master SPI configuration.",
    "U500 issues configuration-clock and flash-select activity and reads the bitstream through its flash interface.",
    "DONE and INIT status continue through U901 on sheet 900 to the MCU.",
    "A low pulse on FPGA_PROGRAM_N followed by release restarts configuration; J600 provides a separate recovery path."
  ],
  "notes": [
    "Configuration completion is distinct from application readiness.",
    "The XADC external analog/reference inputs shown here are grounded.",
    "This educational sequence does not emulate the vendor configuration engine."
  ],
  "category": "Configuration",
  "source": "Schematic labels and explanatory notes in 600_FPGA_CONFIGURATION_AND_XADC.kicad_sch"
};
