/* Module: FPGA.kicad_sch */
window.MIRA_CONTENT.modules["FPGA.kicad_sch"]={
  "purpose": "One U500 FPGA package with supply, configuration, USB FIFO, DDR3L, Ethernet and MCU-link circuitry.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "FPGA",
  "source": "Reachable hierarchy in FPGA.kicad_sch"
};
