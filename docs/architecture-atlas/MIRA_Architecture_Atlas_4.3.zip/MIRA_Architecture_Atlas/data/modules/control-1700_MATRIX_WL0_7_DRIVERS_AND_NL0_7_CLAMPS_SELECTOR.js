/* Module: 1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR.kicad_sch */
window.MIRA_CONTENT.modules["1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR.kicad_sch"]={
  "purpose": "U1700/U1701 select word-line drive or ground. U1702/U1703 clamp neuron lines; U1705 selects one NL for the common analog return.",
  "inputs": [
    "VWL_SRC is the common word-line drive level.",
    "MAT_WL_ON_0…7 and MAT_NL_ZERO_0…7 come from the serial image.",
    "MAT_NL_A0…2 choose the measured neuron line."
  ],
  "outputs": [
    "WL0…WL7 and NL0…NL7 connect to J1800.",
    "MAT_NL_SERVICE carries the selected neuron-line signal."
  ],
  "operation": [
    "Each word line selects GND or VWL_SRC according to its image bit.",
    "Each neuron line has its own programmable ground clamp.",
    "U1705 selects one NL when the qualified service or VMM path permits it.",
    "The selected NL continues through the polarity router to the common TIA during READ."
  ],
  "notes": [
    "Release the selected NL clamp before measurement.",
    "VMM read uses MAT_POLARITY=1 in the source operating note.",
    "The optional NL bleeders are DNP; the word-line loads remain fitted."
  ],
  "category": "Matrix routing",
  "source": "Schematic labels and explanatory notes in 1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR.kicad_sch"
};
