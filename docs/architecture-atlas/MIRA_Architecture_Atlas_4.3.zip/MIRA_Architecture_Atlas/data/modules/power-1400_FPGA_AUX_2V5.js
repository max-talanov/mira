/* Module: 1400_FPGA_AUX_2V5.kicad_sch */
window.MIRA_CONTENT.modules["1400_FPGA_AUX_2V5.kicad_sch"]={
  "purpose": "U1401 converts FPGA5V5 into AUX2V5 for the separate 2.5 V auxiliary branch.",
  "inputs": [
    "FPGA5V5 is the upstream supply.",
    "CMD_AUX25 drives the local enable path to EN_AUX25."
  ],
  "outputs": [
    "AUX25_RAW is the regulated node before the current-sense shunt.",
    "AUX2V5 is the delivered load-side rail.",
    "PGR_AUX25 reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_AUX25.",
    "EN_AUX25 enables U1401 only after the upstream supply is available.",
    "The switching stage and output filter establish AUX25_RAW.",
    "The output shunt separates AUX25_RAW from AUX2V5; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay.",
    "AUX2V5 is present in Power but is not an input of the current Control J400 interface."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1400_FPGA_AUX_2V5.kicad_sch"
};
