/* Module: ADC.kicad_sch */
window.MIRA_CONTENT.modules["ADC.kicad_sch"]={
  "purpose": "Current conversion, monitor selection, balanced converter drive and precision acquisition.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Acquisition",
  "source": "Reachable hierarchy in ADC.kicad_sch"
};
