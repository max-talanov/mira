/* Module: 200_MCU_FMC_AND_SDRAM.kicad_sch */
window.MIRA_CONTENT.modules["200_MCU_FMC_AND_SDRAM.kicad_sch"]={
  "purpose": "The FMC interface of U100 connects to U200, a 64 MiB SDRAM used by the host MCU.",
  "inputs": [
    "SYS3V3 powers U200.",
    "FMC_A0…FMC_A12 and FMC_BA0 / FMC_BA1 address the memory.",
    "FMC_SDCLK and the FMC command signals control access."
  ],
  "outputs": [
    "FMC_D0…FMC_D15 carry bidirectional data.",
    "FMC_NBL0 and FMC_NBL1 mask individual bytes."
  ],
  "operation": [
    "The MCU selects a memory row, bank and column using the FMC address/command interface.",
    "Source resistors damp the command and address lines; R222 separately damps FMC_SDCLK.",
    "U200 returns or accepts a 16-bit word on FMC_D0…FMC_D15.",
    "R223 and R224 keep select and clock-enable states defined before the MCU drives them."
  ],
  "notes": [
    "The 64 MiB FMC SDRAM is separate from U800 FPGA DDR3L.",
    "Initialization, refresh and timing values must be implemented for the exact memory."
  ],
  "category": "Memory",
  "source": "Schematic labels and explanatory notes in 200_MCU_FMC_AND_SDRAM.kicad_sch"
};
