/* Module: 1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS.kicad_sch */
window.MIRA_CONTENT.modules["1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS.kicad_sch"]={
  "purpose": "J1800 is the physical crossbar socket carrying 32 BL, eight WL, eight NL and configurable case/reference connections.",
  "inputs": [
    "BL0…BL31 arrive from bit-line routing.",
    "WL0…WL7 and NL0…NL7 arrive from row/neuron routing.",
    "MATRIX_BIAS_SRC is available through optional bias selectors."
  ],
  "outputs": [
    "J1800 contacts expose the matrix terminals.",
    "MAT_ADAPTER_CASE and MAT_ADAPTER_VSUB connect to the chosen jumper positions."
  ],
  "operation": [
    "The two J1800 units describe one physical socket with one contact numbering map.",
    "J1801 selects the contact-48 reference between GND and MATRIX_BIAS_SRC.",
    "J1802 selects the case connection between GND and MATRIX_BIAS_SRC.",
    "Use the ground positions as the default, then configure bias for the installed crossbar."
  ],
  "notes": [
    "Socket pin numbering follows the crossbar-specific mapping, not a generic source board.",
    "The optional R1800/R1801 return resistors are DNP."
  ],
  "category": "Matrix interface",
  "source": "Schematic labels and explanatory notes in 1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS.kicad_sch"
};
