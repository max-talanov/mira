/* Module: 100_INPUT_CONNECTOR.kicad_sch */
window.MIRA_CONTENT.modules["100_INPUT_CONNECTOR.kicad_sch"]={
  "purpose": "J101 receives the external DC supply. D101/D102 indicate input polarity before downstream protection.",
  "inputs": [
    "External source enters J101 pin 1; J101 pin 2 is the input return."
  ],
  "outputs": [
    "+24V_RAW continues to F201."
  ],
  "operation": [
    "The input voltage appears across the connector and the antiparallel indicator LEDs.",
    "R101 limits indicator current.",
    "Correct polarity lights D102; reverse polarity lights D101."
  ],
  "notes": [
    "The indicator reports polarity only. It does not prove downstream supply readiness."
  ],
  "category": "Power input",
  "source": "Schematic labels and explanatory notes in 100_INPUT_CONNECTOR.kicad_sch"
};
