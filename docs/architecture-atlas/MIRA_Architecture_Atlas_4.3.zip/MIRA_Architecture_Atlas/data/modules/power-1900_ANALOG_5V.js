/* Module: 1900_ANALOG_5V.kicad_sch */
window.MIRA_CONTENT.modules["1900_ANALOG_5V.kicad_sch"]={
  "purpose": "U1901 regulates ANA6 into low-noise ANA5 for the 5 V analog domain and next LDO.",
  "inputs": [
    "ANA6 is the upstream supply.",
    "CMD_ANA5 drives the local enable path to EN_ANA5."
  ],
  "outputs": [
    "ANA5_RAW is the regulated node before the current-sense shunt.",
    "ANA5 is the delivered load-side rail.",
    "PGR_ANA5 reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_ANA5.",
    "EN_ANA5 enables U1901 only after the upstream supply is available.",
    "The linear regulator and bypass network establish ANA5_RAW.",
    "The output shunt separates ANA5_RAW from ANA5; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay.",
    "Enable after ANA6 is stable; the current budget also includes the downstream ANA3V3 stage."
  ],
  "category": "Low-noise power",
  "source": "Schematic labels and explanatory notes in 1900_ANALOG_5V.kicad_sch"
};
