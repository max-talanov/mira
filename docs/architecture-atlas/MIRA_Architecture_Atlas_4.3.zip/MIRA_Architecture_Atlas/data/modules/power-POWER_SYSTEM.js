/* Module: POWER_SYSTEM.kicad_sch */
window.MIRA_CONTENT.modules["POWER_SYSTEM.kicad_sch"]={
  "purpose": "The older Power project supplies input protection, always-on control, switched rails, hardware permits and telemetry.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "System overview",
  "source": "Reachable hierarchy in POWER_SYSTEM.kicad_sch"
};
