/* Module: 1300_FPGA_AUX_1V8.kicad_sch */
window.MIRA_CONTENT.modules["1300_FPGA_AUX_1V8.kicad_sch"]={
  "purpose": "U1301 converts FPGA5V5 into AUX1V8 for the FPGA auxiliary circuits.",
  "inputs": [
    "FPGA5V5 is the upstream supply.",
    "CMD_AUX18 drives the local enable path to EN_AUX18."
  ],
  "outputs": [
    "AUX18_RAW is the regulated node before the current-sense shunt.",
    "AUX1V8 is the delivered load-side rail.",
    "PGR_AUX18 reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_AUX18.",
    "EN_AUX18 enables U1301 only after the upstream supply is available.",
    "The switching stage and output filter establish AUX18_RAW.",
    "The output shunt separates AUX18_RAW from AUX1V8; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1300_FPGA_AUX_1V8.kicad_sch"
};
