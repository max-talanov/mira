/* Module: 1200_POWER_MONITOR.kicad_sch */
window.MIRA_CONTENT.modules["1200_POWER_MONITOR.kicad_sch"]={
  "purpose": "U1201 converts FPGA5V5 into CORE1V0 for U500 internal logic and block RAM.",
  "inputs": [
    "FPGA5V5 is the upstream supply.",
    "CMD_CORE drives the local enable path to EN_CORE."
  ],
  "outputs": [
    "CORE_RAW is the regulated node before the current-sense shunt.",
    "CORE1V0 is the delivered load-side rail.",
    "PGR_CORE reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_CORE.",
    "EN_CORE enables U1201 only after the upstream supply is available.",
    "The switching stage and output filter establish CORE_RAW.",
    "The output shunt separates CORE_RAW from CORE1V0; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1200_POWER_MONITOR.kicad_sch"
};
