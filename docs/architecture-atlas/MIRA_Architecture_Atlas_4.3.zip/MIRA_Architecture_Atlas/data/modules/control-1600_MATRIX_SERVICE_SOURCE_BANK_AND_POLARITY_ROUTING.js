/* Module: 1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch */
window.MIRA_CONTENT.modules["1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch"]={
  "purpose": "The service router selects the BL bank, voltage target and polarity, connects the return path, and resets the source controller while disabled.",
  "inputs": [
    "MAT_BL_BANK_0…3 arrive from the BL selectors.",
    "VREAD_SRC, VSET_SRC, VRESET_SRC and VFORM_SRC are high-impedance voltage commands.",
    "MAT_SRC_A0/A1, MAT_POLARITY and safe-enable signals are captured controls."
  ],
  "outputs": [
    "MAT_BL_SERVICE and MAT_NL_SERVICE connect the selected matrix terminals.",
    "MAT_VTARGET feeds the CV/CC stage.",
    "MAT_TIA_IN carries the READ return; MAT_RETURN / MAT_RSH_POWER serve the WRITE path."
  ],
  "operation": [
    "Select a BL group and the required service voltage target.",
    "Polarity routing swaps the source and return relationship at the selected matrix terminals.",
    "READ connects the return to the TIA; WRITE uses the source-current path.",
    "When MAT_SOURCE_SAFE is removed, the reset switches clear the controller state and permit discharge through the selected shunt."
  ],
  "notes": [
    "U1601 selects a command; it does not directly supply DUT power.",
    "Source OFF, discharge and settling precede route/range/polarity changes.",
    "R1600/R1601 remain DNP for low-current operation."
  ],
  "category": "Matrix routing",
  "source": "Schematic labels and explanatory notes in 1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch"
};
