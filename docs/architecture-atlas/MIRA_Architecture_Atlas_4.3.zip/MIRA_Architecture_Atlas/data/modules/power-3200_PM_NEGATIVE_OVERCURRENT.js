/* Module: 3200_PM_NEGATIVE_OVERCURRENT.kicad_sch */
window.MIRA_CONTENT.modules["3200_PM_NEGATIVE_OVERCURRENT.kicad_sch"]={
  "purpose": "U3201 independently checks conditioned negative-rail current against an AON-derived threshold.",
  "inputs": [
    "OC_I_N15 comes from the U3401 negative-rail current monitor."
  ],
  "outputs": [
    "OC_OK_N is pulled low on excess current and joins the shared hardware-fault line."
  ],
  "operation": [
    "The reference divider creates the comparator threshold.",
    "The conditioned current signal is compared against that reference.",
    "An excess current pulls OC_OK_N low, allowing the interlock to revoke power permission."
  ],
  "notes": [
    "The threshold depends on the sense gain and shunt as well as this divider.",
    "A legacy note on this sheet says the source is absent; the reachable 3400 sheet now provides OC_I_N15."
  ],
  "category": "Protection",
  "source": "Schematic labels and explanatory notes in 3200_PM_NEGATIVE_OVERCURRENT.kicad_sch"
};
