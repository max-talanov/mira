/* Module: POWER_CONTROL.kicad_sch */
window.MIRA_CONTENT.modules["POWER_CONTROL.kicad_sch"]={
  "purpose": "The independent AON-powered sequencer, watchdogs, permission memory and enable/readiness logic.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Power supervision",
  "source": "Reachable hierarchy in POWER_CONTROL.kicad_sch"
};
