/* Module: 3900_TELEMETRY_MULTIPLEXERS.kicad_sch */
window.MIRA_CONTENT.modules["3900_TELEMETRY_MULTIPLEXERS.kicad_sch"]={
  "purpose": "U3901/U3902 select paired current and voltage measurements for one of 16 supply domains.",
  "inputs": [
    "MON_I_* and MON_V_* arrive from the rail monitors.",
    "MUX_A0…MUX_A3 select the common channel.",
    "MUX_DISABLE disconnects both selectors when high."
  ],
  "outputs": [
    "MUX_I_COM carries selected current telemetry.",
    "MUX_V_COM carries the matching voltage telemetry."
  ],
  "operation": [
    "Disable the pair while changing the channel address.",
    "Select the same numbered current/voltage domain with shared address lines.",
    "Enable the selectors and allow the path to settle.",
    "Read both downstream ADC inputs as one supply measurement pair."
  ],
  "notes": [
    "These are conditioned analog monitor signals, not the power rails themselves.",
    "Hardware overcurrent protection does not wait for scanning."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 3900_TELEMETRY_MULTIPLEXERS.kicad_sch"
};
