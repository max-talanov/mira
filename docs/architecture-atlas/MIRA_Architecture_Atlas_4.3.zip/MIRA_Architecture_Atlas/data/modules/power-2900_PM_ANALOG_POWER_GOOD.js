/* Module: 2900_PM_ANALOG_POWER_GOOD.kicad_sch */
window.MIRA_CONTENT.modules["2900_PM_ANALOG_POWER_GOOD.kicad_sch"]={
  "purpose": "U2901 compares conditioned USB, analog-preregulator and bipolar AFE monitor voltages with AON-derived thresholds.",
  "inputs": [
    "MON_V_USB, MON_V_ANA6, MON_V_P15 and MON_V_N15 are conditioned rail measurements."
  ],
  "outputs": [
    "PG_USB, PG_ANA, PG_P15 and PG_N15 report independent level checks."
  ],
  "operation": [
    "Each monitor is compared against its resistor-set reference.",
    "A monitor above reference releases its open-collector status high.",
    "The rail-ready tree combines these statuses with regulator PGR outputs."
  ],
  "notes": [
    "These channels are level checks, not overvoltage windows or fault latches.",
    "Negative voltage must first be translated into the GND-to-AON input range."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 2900_PM_ANALOG_POWER_GOOD.kicad_sch"
};
