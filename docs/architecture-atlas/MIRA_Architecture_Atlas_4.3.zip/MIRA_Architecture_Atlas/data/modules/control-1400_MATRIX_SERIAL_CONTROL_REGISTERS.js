/* Module: 1400_MATRIX_SERIAL_CONTROL_REGISTERS.kicad_sch */
window.MIRA_CONTENT.modules["1400_MATRIX_SERIAL_CONTROL_REGISTERS.kicad_sch"]={
  "purpose": "U1400–U1409 form an 80-bit serial image containing bit-line drive/clamp masks and word/neuron-line controls.",
  "inputs": [
    "MAT_SPI_MOSI enters U1400 and MAT_SPI_SCK shifts the chain.",
    "MAT_CONFIG_LATCH updates output storage.",
    "MAT_ALLOWED clears shift registers; MAT_OE_N / MAT_VMM_OE_N qualify outputs."
  ],
  "outputs": [
    "MAT_BL_VMM_0…31 select bit-line DAC drive.",
    "MAT_BL_ZERO_0…31 select bit-line ground clamps.",
    "MAT_WL_ON_0…7 and MAT_NL_ZERO_0…7 control word/neuron lines."
  ],
  "operation": [
    "Shift data through U1400, U1401 and onward to U1409.",
    "Commit all 80 stored bits with the protected latch edge.",
    "Separate output-enable controls expose the VMM bank and the remaining masks.",
    "Downstream bias resistors establish defaults while outputs are high impedance."
  ],
  "notes": [
    "Shift-register clear does not itself update the output-storage registers.",
    "Do not simultaneously enable a bit-line DAC path and its ground clamp."
  ],
  "category": "Matrix control",
  "source": "Schematic labels and explanatory notes in 1400_MATRIX_SERIAL_CONTROL_REGISTERS.kicad_sch"
};
