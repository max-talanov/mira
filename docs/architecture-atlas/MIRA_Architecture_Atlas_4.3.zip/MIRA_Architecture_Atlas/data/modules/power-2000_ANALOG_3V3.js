/* Module: 2000_ANALOG_3V3.kicad_sch */
window.MIRA_CONTENT.modules["2000_ANALOG_3V3.kicad_sch"]={
  "purpose": "U2001 regulates ANA5 into low-noise ANA3V3 for the low-noise 3.3 V analog domain.",
  "inputs": [
    "ANA5 is the upstream supply.",
    "CMD_ANA33 drives the local enable path to EN_ANA33."
  ],
  "outputs": [
    "ANA33_RAW is the regulated node before the current-sense shunt.",
    "ANA3V3 is the delivered load-side rail.",
    "PGR_ANA33 reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_ANA33.",
    "EN_ANA33 enables U2001 only after the upstream supply is available.",
    "The linear regulator and bypass network establish ANA33_RAW.",
    "The output shunt separates ANA33_RAW from ANA3V3; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay.",
    "Enable after ANA5 is stable."
  ],
  "category": "Low-noise power",
  "source": "Schematic labels and explanatory notes in 2000_ANALOG_3V3.kicad_sch"
};
