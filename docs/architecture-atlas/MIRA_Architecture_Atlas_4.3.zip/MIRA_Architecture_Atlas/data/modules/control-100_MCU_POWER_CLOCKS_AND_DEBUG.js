/* Module: 100_MCU_POWER_CLOCKS_AND_DEBUG.kicad_sch */
window.MIRA_CONTENT.modules["100_MCU_POWER_CLOCKS_AND_DEBUG.kicad_sch"]={
  "purpose": "U100 is the STM32H745IIT6 host processor. This sheet supplies its power domains, clock sources, reset, boot selection and debug access.",
  "inputs": [
    "SYS3V3 supplies the MCU and its local reservoirs.",
    "FPGA_DONE_MCU and FPGA_INIT_N_MCU report FPGA configuration state.",
    "J100 accepts a debug probe; SW100 and J101 provide reset and boot controls."
  ],
  "outputs": [
    "MCU_HSE_CLK carries the clock from Y100 through R101.",
    "MCU_LSE_IN / MCU_LSE_OUT connect Y101 to the backup clock circuitry.",
    "MCU_SWDIO, MCU_SWCLK and MCU_SWO expose debug access."
  ],
  "operation": [
    "SYS3V3 reaches the supply pins with local bypass capacitors; R100 separates the MCU_VDDA analog branch.",
    "C119 and C120 support MCU_VCAP, the internal regulator reservoir.",
    "Y100 provides the 25 MHz HSE input; Y101 provides the 32.768 kHz LSE crystal network.",
    "SW100 pulls HOST_RESET_N low. The boot strap and SWD interface permit startup selection and recovery."
  ],
  "notes": [
    "U100 units on sheets 100, 200 and 300 are one physical MCU.",
    "MCU_VCAP is an internal regulator reservoir, not a supply for external loads.",
    "FPGA configuration status does not prove application, DDR or network readiness."
  ],
  "category": "Host processor",
  "source": "Schematic labels and explanatory notes in 100_MCU_POWER_CLOCKS_AND_DEBUG.kicad_sch"
};
