/* Module: 1700_PHY_1V05.kicad_sch */
window.MIRA_CONTENT.modules["1700_PHY_1V05.kicad_sch"]={
  "purpose": "U1701 converts FPGA5V5 into PHY1V05 for the Ethernet PHY core.",
  "inputs": [
    "FPGA5V5 is the upstream supply.",
    "CMD_PHY drives the local enable path to EN_PHY."
  ],
  "outputs": [
    "PHY_RAW is the regulated node before the current-sense shunt.",
    "PHY1V05 is the delivered load-side rail.",
    "PGR_PHY reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_PHY.",
    "EN_PHY enables U1701 only after the upstream supply is available.",
    "The switching stage and output filter establish PHY_RAW.",
    "The output shunt separates PHY_RAW from PHY1V05; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1700_PHY_1V05.kicad_sch"
};
