/* Module: 2700_PM_ENABLE_GATES_PRIMARY.kicad_sch */
window.MIRA_CONTENT.modules["2700_PM_ENABLE_GATES_PRIMARY.kicad_sch"]={
  "purpose": "U2701/U2702 qualify converter enable requests with the independent global-power permit.",
  "inputs": [
    "GLOBAL_PWR_PERMIT authorizes all channels.",
    "EN_REQ_USB requests its branch.",
    "EN_REQ_SYS requests its branch.",
    "EN_REQ_FPGA requests its branch.",
    "EN_REQ_ANA requests its branch.",
    "EN_REQ_P15 requests its branch.",
    "EN_REQ_N15 requests its branch.",
    "EN_REQ_CORE requests its branch.",
    "EN_REQ_AUX18 requests its branch."
  ],
  "outputs": [
    "CMD_USB drives its converter enable path.",
    "CMD_SYS drives its converter enable path.",
    "CMD_FPGA drives its converter enable path.",
    "CMD_ANA drives its converter enable path.",
    "CMD_P15 drives its converter enable path.",
    "CMD_N15 drives its converter enable path.",
    "CMD_CORE drives its converter enable path.",
    "CMD_AUX18 drives its converter enable path."
  ],
  "operation": [
    "The firmware selects the required EN_REQ line.",
    "The hardware AND gate produces CMD only while GLOBAL_PWR_PERMIT is high.",
    "Clearing the permit removes every command in this bank.",
    "Pull-down resistors keep request and command defaults low."
  ],
  "notes": [
    "Logic gating adds authorization, not a verified startup delay.",
    "An enabled command does not prove a healthy output voltage."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 2700_PM_ENABLE_GATES_PRIMARY.kicad_sch"
};
