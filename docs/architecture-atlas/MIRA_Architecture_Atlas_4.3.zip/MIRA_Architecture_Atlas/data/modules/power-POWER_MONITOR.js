/* Module: POWER_MONITOR.kicad_sch */
window.MIRA_CONTENT.modules["POWER_MONITOR.kicad_sch"]={
  "purpose": "Rail current/voltage monitoring, negative-domain translation, paired multiplexers and ADC buffers.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Telemetry",
  "source": "Reachable hierarchy in POWER_MONITOR.kicad_sch"
};
