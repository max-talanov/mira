/* Module: 500_AON_3V3_BUCK.kicad_sch */
window.MIRA_CONTENT.modules["500_AON_3V3_BUCK.kicad_sch"]={
  "purpose": "U501 generates AON directly from BUS24 for sequencing, monitoring, watchdogs and hardware interlocks.",
  "inputs": [
    "BUS24 powers U501 VIN and EN."
  ],
  "outputs": [
    "AON_RAW is the regulated voltage before R503.",
    "AON powers the always-on control domain after the shunt."
  ],
  "operation": [
    "Input power enables U501 without an EN_REQ or CMD signal.",
    "The switching stage and L501/C504/C505 produce AON_RAW.",
    "R503 introduces a load-dependent drop before AON.",
    "AON permits the sequencer and fault chain to operate while switched rails remain disabled."
  ],
  "notes": [
    "The source nominal AON_RAW is 3.28 V; delivered AON depends on load and shunt drop.",
    "Removing BUS24 also removes AON."
  ],
  "category": "Always-on power",
  "source": "Schematic labels and explanatory notes in 500_AON_3V3_BUCK.kicad_sch"
};
