/* Module: 700_FPGA_USB3_FIFO_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["700_FPGA_USB3_FIFO_INTERFACE.kicad_sch"]={
  "purpose": "J700 connects a USB Type-C host to U707 FT601 through U706 lane orientation control. U707 exposes a 32-bit FIFO to U500.",
  "inputs": [
    "J700 receives USB differential data, CC1/CC2 and USB_VBUS.",
    "USB5 powers U706; IO3V3 powers the FIFO interface and VBUS receiver.",
    "FT_RXF_N and FT_TXE_N report FIFO availability."
  ],
  "outputs": [
    "FT_D0…FT_D31 carry bidirectional FIFO data.",
    "FT_BE0…FT_BE3 mark valid bytes.",
    "FT_CLK, FT_RD_N, FT_WR_N and FT_OE_N coordinate FPGA transfers.",
    "FT_VBUS_DET reports conditioned host VBUS."
  ],
  "operation": [
    "U706 detects Type-C orientation and routes the SuperSpeed lanes.",
    "U707 terminates the USB transport and buffers data in its parallel FIFO.",
    "U500 observes FIFO flags and transfers words using the FT_* control lines.",
    "U708 conditions VBUS detection and isolates the FT601 detection path when IO3V3 is disabled."
  ],
  "notes": [
    "USB_VBUS and the board-generated USB5 are distinct nets.",
    "The animation illustrates FIFO transfers; a host driver and FPGA logic are still required."
  ],
  "category": "Host communication",
  "source": "Schematic labels and explanatory notes in 700_FPGA_USB3_FIFO_INTERFACE.kicad_sch"
};
