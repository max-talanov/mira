/* Module: 900_ANALOG_PREREGULATOR_6V.kicad_sch */
window.MIRA_CONTENT.modules["900_ANALOG_PREREGULATOR_6V.kicad_sch"]={
  "purpose": "U901 converts BUS24 into ANA6 for the low-noise analog regulator chain.",
  "inputs": [
    "BUS24 is the upstream supply.",
    "CMD_ANA drives the local enable path to EN_ANA."
  ],
  "outputs": [
    "ANA_RAW is the regulated node before the current-sense shunt.",
    "ANA6 is the delivered load-side rail."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_ANA.",
    "EN_ANA enables U901 only after the upstream supply is available.",
    "The switching stage and output filter establish ANA_RAW.",
    "The output shunt separates ANA_RAW from ANA6; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 900_ANALOG_PREREGULATOR_6V.kicad_sch"
};
