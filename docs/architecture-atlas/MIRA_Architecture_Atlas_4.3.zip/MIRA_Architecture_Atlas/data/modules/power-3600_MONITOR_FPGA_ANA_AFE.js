/* Module: 3600_MONITOR_FPGA_ANA_AFE.kicad_sch */
window.MIRA_CONTENT.modules["3600_MONITOR_FPGA_ANA_AFE.kicad_sch"]={
  "purpose": "U3601–U3603 monitor the FPGA intermediate, analog preregulator and positive AFE rails.",
  "inputs": [
    "Upstream RAW and delivered rail nodes span each current shunt.",
    "AON powers the sense amplifiers and clamp references."
  ],
  "outputs": [
    "MON_I_FPGA reports conditioned current.",
    "MON_I_ANA6 reports conditioned current.",
    "MON_I_P15 reports conditioned current.",
    "MON_V_FPGA reports conditioned load voltage.",
    "MON_V_ANA6 reports conditioned load voltage.",
    "MON_V_P15 reports conditioned load voltage.",
    "OC_OK_N joins open-drain hardware current alerts."
  ],
  "operation": [
    "Current amplifiers measure the shunt voltage.",
    "Voltage dividers measure the delivered rail and clamps limit monitor-node excursions.",
    "Paired MON_I/MON_V signals continue to the telemetry multiplexers.",
    "INA301 alert outputs can assert OC_OK_N independently of ADC polling."
  ],
  "notes": [
    "Hardware alert and filtered telemetry have different signal paths.",
    "Thresholds must be reviewed against converter, load and inrush limits."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 3600_MONITOR_FPGA_ANA_AFE.kicad_sch"
};
