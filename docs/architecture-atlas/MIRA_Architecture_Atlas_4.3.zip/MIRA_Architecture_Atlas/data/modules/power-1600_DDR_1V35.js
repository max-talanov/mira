/* Module: 1600_DDR_1V35.kicad_sch */
window.MIRA_CONTENT.modules["1600_DDR_1V35.kicad_sch"]={
  "purpose": "U1601 converts FPGA5V5 into DDR1V35 for DDR memory and the tracking termination stage.",
  "inputs": [
    "FPGA5V5 is the upstream supply.",
    "CMD_DDR drives the local enable path to EN_DDR."
  ],
  "outputs": [
    "DDR_RAW is the regulated node before the current-sense shunt.",
    "DDR1V35 is the delivered load-side rail.",
    "PGR_DDR reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_DDR.",
    "EN_DDR enables U1601 only after the upstream supply is available.",
    "The switching stage and output filter establish DDR_RAW.",
    "The output shunt separates DDR_RAW from DDR1V35; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1600_DDR_1V35.kicad_sch"
};
