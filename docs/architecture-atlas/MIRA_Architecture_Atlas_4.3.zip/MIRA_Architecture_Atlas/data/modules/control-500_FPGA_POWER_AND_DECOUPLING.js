/* Module: 500_FPGA_POWER_AND_DECOUPLING.kicad_sch */
window.MIRA_CONTENT.modules["500_FPGA_POWER_AND_DECOUPLING.kicad_sch"]={
  "purpose": "U500 is one XC7A200T-2FBG484I FPGA with separate core, auxiliary and I/O supply groups and local bypass capacitors.",
  "inputs": [
    "CORE1V0 feeds the internal logic and block RAM.",
    "AUX1V8 feeds auxiliary circuitry.",
    "IO3V3 and DDR1V35 feed the indicated I/O banks."
  ],
  "outputs": [
    "Local supply connections reach the U500 VCCINT, VCCBRAM, VCCAUX and VCCO pins."
  ],
  "operation": [
    "The core and auxiliary rails power different internal circuits.",
    "Each VCCO bank follows the voltage used by its attached interface.",
    "Bulk and local capacitors supply transient current close to the package.",
    "All shown ground balls connect to the common ground return."
  ],
  "notes": [
    "Every U500 section elsewhere in the atlas belongs to this same physical FPGA.",
    "The diagram shows connectivity; package placement, impedance and current budgets require PCB analysis."
  ],
  "category": "FPGA",
  "source": "Schematic labels and explanatory notes in 500_FPGA_POWER_AND_DECOUPLING.kicad_sch"
};
