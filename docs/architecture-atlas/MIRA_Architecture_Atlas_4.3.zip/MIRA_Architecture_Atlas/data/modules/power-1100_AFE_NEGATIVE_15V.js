/* Module: 1100_AFE_NEGATIVE_15V.kicad_sch */
window.MIRA_CONTENT.modules["1100_AFE_NEGATIVE_15V.kicad_sch"]={
  "purpose": "U1102 generates N15 with an inverting buck-boost connection. U1101 transfers enable control into the negative local domain.",
  "inputs": [
    "BUS24 provides input energy.",
    "CMD_N15 drives the U1101 optocoupler LED."
  ],
  "outputs": [
    "N15_RAW is the negative regulated node.",
    "N15 supplies the negative AFE domain after R1107."
  ],
  "operation": [
    "CMD_N15 transfers through U1101 to EN_N15.",
    "U1102 switches relative to its local ground N15_RAW, with L1101 returning to system ground.",
    "The output network filters the negative voltage.",
    "R1107 provides current sensing before the delivered N15 rail."
  ],
  "notes": [
    "U1102 local ground is N15_RAW, not system GND.",
    "Inverting output-current capability is lower than the IC buck rating."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1100_AFE_NEGATIVE_15V.kicad_sch"
};
