/* Module: 200_INPUT_FUSE_PROTECTION.kicad_sch */
window.MIRA_CONTENT.modules["200_INPUT_FUSE_PROTECTION.kicad_sch"]={
  "purpose": "F201 protects the input branch. D204 indicates fused voltage; Q201 controls the red loss-of-fuse indication.",
  "inputs": [
    "+24V_RAW arrives from J101."
  ],
  "outputs": [
    "+24V_FUSED feeds the eFuse stage."
  ],
  "operation": [
    "An intact F201 carries current from raw to fused input.",
    "The divider drives Q201 on, bypassing red LED D202 while green D204 indicates fused voltage.",
    "If fused voltage disappears while raw voltage remains, Q201 releases the red indicator.",
    "D205 suppresses transients across the fused input."
  ],
  "notes": [
    "Fuse operation depends on its time-current characteristic and available source fault current.",
    "The present source labels F201 as 5 A / 125 V."
  ],
  "category": "Power input",
  "source": "Schematic labels and explanatory notes in 200_INPUT_FUSE_PROTECTION.kicad_sch"
};
