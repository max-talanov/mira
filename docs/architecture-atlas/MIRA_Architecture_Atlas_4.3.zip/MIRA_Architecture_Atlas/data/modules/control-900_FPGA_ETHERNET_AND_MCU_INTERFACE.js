/* Module: 900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch"]={
  "purpose": "J900 and T900 connect the Ethernet cable to PHY U902. U902 exchanges RGMII data with U500. U900/U901 bridge MCU and FPGA control domains.",
  "inputs": [
    "Four ETH_* cable pairs enter J900 and T900.",
    "PHY1V05 powers the PHY core; IO3V3 powers I/O and U903 generates PHY2V5.",
    "Y900 supplies the PHY crystal reference.",
    "MCU_FPGA_* and HOST_ALIVE enter the domain buffer path."
  ],
  "outputs": [
    "PHY_RXC, PHY_RX_CTL and PHY_RXD0…3 carry received RGMII data to U500.",
    "PHY_TXC, PHY_TX_CTL and PHY_TXD0…3 carry FPGA transmit data to U902.",
    "PHY_MDC / PHY_MDIO provide management; PHY_INT_N returns events.",
    "U901 returns MCU_FPGA_MISO, FPGA_IRQ, FPGA_DONE_MCU and FPGA_INIT_N_MCU."
  ],
  "operation": [
    "A cable waveform reaches J900 and crosses T900 magnetics to the PHY MDI_* pairs.",
    "U902 handles the physical link and presents received symbols as a digital RGMII interface.",
    "U500 must implement MAC framing and the chosen protocol processing.",
    "Transmit data follows the reverse functional path: FPGA RGMII, PHY, magnetics, cable.",
    "U900/U901 independently buffer the MCU control/status link in the receiving power domains."
  ],
  "notes": [
    "A copper-pair waveform is not the RGMII bit pattern drawn on a digital trace.",
    "MAC, TCP/UDP, DHCP and application commands are implementation choices beyond the schematic.",
    "Ethernet animation is illustrative and does not simulate 1000BASE-T coding or PHY equalization."
  ],
  "category": "Host communication",
  "source": "Schematic labels and explanatory notes in 900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch"
};
