/* Module: 400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch"]={
  "purpose": "J400 is the Control-side power and supervision boundary. It receives the external rails and presents separate status receivers for the MCU and matrix logic.",
  "inputs": [
    "J400 receives AON, SYS3V3, IO3V3, CORE1V0, AUX1V8, DDR1V35, VTT, DDR_VREF, PHY1V05, USB5 and analog rails.",
    "ALL_RAILS_PG_POWER, GLOBAL_PWR_PERMIT_POWER, MATRIX_PERMIT_POWER and PM_UART_TX_POWER enter from Power."
  ],
  "outputs": [
    "U400 creates the *_HOST status nets in the SYS3V3 domain.",
    "U401 independently produces MATRIX_PERMIT in the IO3V3 domain.",
    "HOST_WDI, HOST_ALIVE and HOST_UART_TX return host activity.",
    "MATRIX_INHIBIT_N returns the matrix hardware inhibit to the power supervisor."
  ],
  "operation": [
    "Supply contacts carry each named rail into Control, with several parallel high-current and return contacts.",
    "U400 receives supervisor outputs for the MCU; U401 receives the common matrix permission separately.",
    "Ioff-capable receivers prevent disabled receiving domains from being driven through these outputs.",
    "The open-drain MATRIX_INHIBIT_N return allows a local matrix fault to request inhibition at Power."
  ],
  "notes": [
    "J400 is a prototype Control-side pin assignment; the mating Power connector is not verified.",
    "Matching rail names between board projects do not establish a physical connector pin mapping.",
    "AON must be available before SYS3V3/IO3V3; VTT and DDR_VREF track DDR1V35/2."
  ],
  "category": "Interconnect",
  "source": "Schematic labels and explanatory notes in 400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch"
};
