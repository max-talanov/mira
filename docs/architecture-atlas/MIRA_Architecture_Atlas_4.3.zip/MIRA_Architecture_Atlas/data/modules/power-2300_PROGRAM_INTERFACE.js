/* Module: 2300_PROGRAM_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["2300_PROGRAM_INTERFACE.kicad_sch"]={
  "purpose": "J2301 exports PROG_P15, ground and PROG_N15. A divider provides a filtered positive-rail measurement.",
  "inputs": [
    "PROG_P15 and PROG_N15 arrive from their switches.",
    "AON is the monitor clamp reference."
  ],
  "outputs": [
    "J2301 pins 1/2/3 expose positive/return/negative programming power.",
    "PROG_V_P15 reaches the power-manager ADC."
  ],
  "operation": [
    "The two switched rails pass to the interface connector.",
    "R2301/R2302 scale positive voltage by 1/5.7.",
    "R2303/C2301 filter the measurement.",
    "D2301 limits the monitor node toward GND/AON."
  ],
  "notes": [
    "The monitor averages short pulses; it does not resolve their peak waveform.",
    "Connector mapping between this older Power source and current Control is unverified."
  ],
  "category": "Programming power",
  "source": "Schematic labels and explanatory notes in 2300_PROGRAM_INTERFACE.kicad_sch"
};
