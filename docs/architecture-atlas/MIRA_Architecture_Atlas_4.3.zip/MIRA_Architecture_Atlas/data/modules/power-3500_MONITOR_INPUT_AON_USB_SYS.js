/* Module: 3500_MONITOR_INPUT_AON_USB_SYS.kicad_sch */
window.MIRA_CONTENT.modules["3500_MONITOR_INPUT_AON_USB_SYS.kicad_sch"]={
  "purpose": "U3501–U3504 monitor the input bus, always-on, USB and system rails.",
  "inputs": [
    "Upstream RAW and delivered rail nodes span each current shunt.",
    "AON powers the sense amplifiers and clamp references."
  ],
  "outputs": [
    "MON_I_INPUT reports conditioned current.",
    "MON_I_AON reports conditioned current.",
    "MON_I_USB reports conditioned current.",
    "MON_I_SYS reports conditioned current.",
    "MON_V_INPUT reports conditioned load voltage.",
    "MON_V_AON reports conditioned load voltage.",
    "MON_V_USB reports conditioned load voltage.",
    "MON_V_SYS reports conditioned load voltage.",
    "OC_OK_N joins open-drain hardware current alerts."
  ],
  "operation": [
    "Current amplifiers measure the shunt voltage.",
    "Voltage dividers measure the delivered rail and clamps limit monitor-node excursions.",
    "Paired MON_I/MON_V signals continue to the telemetry multiplexers.",
    "INA301 alert outputs can assert OC_OK_N independently of ADC polling."
  ],
  "notes": [
    "Hardware alert and filtered telemetry have different signal paths.",
    "Thresholds must be reviewed against converter, load and inrush limits.",
    "U3501 provides input-current telemetry without an INA301 hardware alert."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 3500_MONITOR_INPUT_AON_USB_SYS.kicad_sch"
};
