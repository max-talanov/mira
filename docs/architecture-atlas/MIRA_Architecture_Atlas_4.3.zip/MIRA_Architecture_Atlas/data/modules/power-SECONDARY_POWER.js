/* Module: SECONDARY_POWER.kicad_sch */
window.MIRA_CONTENT.modules["SECONDARY_POWER.kicad_sch"]={
  "purpose": "FPGA core/auxiliary/I/O, DDR, PHY, termination/reference and low-noise analog regulators.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Power conversion",
  "source": "Reachable hierarchy in SECONDARY_POWER.kicad_sch"
};
