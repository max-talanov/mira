/* Module: 3800_MONITOR_DDR_PHY_ANALOG.kicad_sch */
window.MIRA_CONTENT.modules["3800_MONITOR_DDR_PHY_ANALOG.kicad_sch"]={
  "purpose": "U3801–U3804 monitor the DDR, Ethernet PHY and low-noise analog rails.",
  "inputs": [
    "Upstream RAW and delivered rail nodes span each current shunt.",
    "AON powers the sense amplifiers and clamp references."
  ],
  "outputs": [
    "MON_I_DDR reports conditioned current.",
    "MON_I_ANA5 reports conditioned current.",
    "MON_I_PHY reports conditioned current.",
    "MON_I_ANA33 reports conditioned current.",
    "MON_V_DDR reports conditioned load voltage.",
    "MON_V_ANA5 reports conditioned load voltage.",
    "MON_V_PHY reports conditioned load voltage.",
    "MON_V_ANA33 reports conditioned load voltage.",
    "OC_OK_N joins open-drain hardware current alerts."
  ],
  "operation": [
    "Current amplifiers measure the shunt voltage.",
    "Voltage dividers measure the delivered rail and clamps limit monitor-node excursions.",
    "Paired MON_I/MON_V signals continue to the telemetry multiplexers.",
    "INA301 alert outputs can assert OC_OK_N independently of ADC polling."
  ],
  "notes": [
    "Hardware alert and filtered telemetry have different signal paths.",
    "Thresholds must be reviewed against converter, load and inrush limits."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 3800_MONITOR_DDR_PHY_ANALOG.kicad_sch"
};
