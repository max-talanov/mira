/* Module: DAC.kicad_sch */
window.MIRA_CONTENT.modules["DAC.kicad_sch"]={
  "purpose": "Bit-line voltages and service voltage/current targets with FPGA serial control.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Analog sources",
  "source": "Reachable hierarchy in DAC.kicad_sch"
};
