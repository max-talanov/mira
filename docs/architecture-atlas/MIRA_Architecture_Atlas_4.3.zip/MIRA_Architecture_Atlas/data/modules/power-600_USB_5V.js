/* Module: 600_USB_5V.kicad_sch */
window.MIRA_CONTENT.modules["600_USB_5V.kicad_sch"]={
  "purpose": "U601 converts BUS24 into USB5 for the board USB interface.",
  "inputs": [
    "BUS24 is the upstream supply.",
    "CMD_USB drives the local enable path to EN_USB."
  ],
  "outputs": [
    "USB_RAW is the regulated node before the current-sense shunt.",
    "USB5 is the delivered load-side rail."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_USB.",
    "EN_USB enables U601 only after the upstream supply is available.",
    "The switching stage and output filter establish USB_RAW.",
    "The output shunt separates USB_RAW from USB5; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay.",
    "USB5 is a board supply and is distinct from the external USB_VBUS net in Control."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 600_USB_5V.kicad_sch"
};
