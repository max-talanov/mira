/* Module: 300_MCU_QSPI_MICROSD_AND_CONTROL.kicad_sch */
window.MIRA_CONTENT.modules["300_MCU_QSPI_MICROSD_AND_CONTROL.kicad_sch"]={
  "purpose": "U100 connects to QSPI flash U300, removable microSD J300, the FPGA command interface and the independent power manager.",
  "inputs": [
    "MCU_QSPI_IO0…MCU_QSPI_IO3 exchange nonvolatile data with U300.",
    "MCU_SD_CD_N reports card insertion.",
    "ALL_RAILS_PG_HOST, GLOBAL_PWR_PERMIT_HOST, MATRIX_PERMIT_HOST and PM_UART_TX_HOST return supervisor status."
  ],
  "outputs": [
    "MCU_QSPI_CLK / MCU_QSPI_CS_N control flash transfers.",
    "MCU_SD_CLK, MCU_SD_CMD and MCU_SD_D0…D3 connect to the card through series resistors.",
    "MCU_FPGA_SCK / MOSI / MISO / CS_N form the command link; FPGA_IRQ returns events.",
    "HOST_ALIVE, HOST_WDI and HOST_UART_TX serve the power-manager handshake."
  ],
  "operation": [
    "U300 stores data over the four-line QSPI interface.",
    "J300 connects the SD clock, command and four data lines, with U301–U303 providing connector protection.",
    "The MCU sends commands to the FPGA through the domain buffers on sheet 900.",
    "Power-manager status and heartbeats remain independent of matrix timing and the local hardware fault chain."
  ],
  "notes": [
    "Message formats and FPGA register maps are software/HDL responsibilities.",
    "MCU_RESET_FPGA_N requests reconfiguration through U601 on sheet 600."
  ],
  "category": "Host processor",
  "source": "Schematic labels and explanatory notes in 300_MCU_QSPI_MICROSD_AND_CONTROL.kicad_sch"
};
