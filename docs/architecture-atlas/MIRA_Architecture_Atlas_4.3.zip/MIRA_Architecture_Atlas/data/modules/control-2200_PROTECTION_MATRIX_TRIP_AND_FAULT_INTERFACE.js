/* Module: 2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch"]={
  "purpose": "U2200 provides backup overcurrent comparison. U2202 remembers overcurrent or configuration faults and asserts local shutdown plus MATRIX_INHIBIT_N.",
  "inputs": [
    "MAT_CC_SENSE_BUF and MAT_ILIM_SENSE_BUF enter the backup comparison.",
    "MAT_WRITE_SAFE qualifies the analog trip branch.",
    "MAT_CONFIG_TRIP enters independently of WRITE_SAFE.",
    "MAT_FAULT_CLEAR_N explicitly resets the latch."
  ],
  "outputs": [
    "MAT_TRIP clocks U2202.",
    "MAT_FAULT_Q / MAT_FAULT_N disable matrix operation locally.",
    "Q2203 asserts the open-drain MATRIX_INHIBIT_N return to Power."
  ],
  "operation": [
    "U2200 compares the normalized source-current sense against the coarse current-target threshold.",
    "U2201 qualifies the analog event; U2203 combines it with a configuration trip.",
    "U2202 stores the event so recovery of the comparator alone does not resume operation.",
    "The fault outputs remove local enable and assert the external inhibit without waiting for MCU or ADC."
  ],
  "notes": [
    "This comparator is backup shutdown, not the precision current regulator or a calibrated low-current meter.",
    "Total stopping time includes the complete analog, logic, actuator and switch path.",
    "Clear, zero-source discharge and a fresh qualified frame are required before re-arming."
  ],
  "category": "Protection",
  "source": "Schematic labels and explanatory notes in 2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch"
};
