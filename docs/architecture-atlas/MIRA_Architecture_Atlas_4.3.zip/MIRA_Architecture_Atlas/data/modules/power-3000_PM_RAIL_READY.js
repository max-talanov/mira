/* Module: 3000_PM_RAIL_READY.kicad_sch */
window.MIRA_CONTENT.modules["3000_PM_RAIL_READY.kicad_sch"]={
  "purpose": "U3001, U3017 and U3018 form the measured-rail readiness tree.",
  "inputs": [
    "PG_USB, PG_SYS, PG_FPGA, PG_ANA, PG_P15 and PG_N15 report primary rails.",
    "Nine PGR_* signals report secondary rails."
  ],
  "outputs": [
    "ALL_RAILS_PG is high only when every included status is high."
  ],
  "operation": [
    "The first logic stage combines four status groups.",
    "The final AND stage combines PG_GROUP_0…PG_GROUP_3.",
    "A missing rail removes ALL_RAILS_PG and therefore one matrix-permission condition."
  ],
  "notes": [
    "The actual schematic annotations are U3001, U3017 and U3018.",
    "There is no per-rail bypass or qualification timer on this sheet."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 3000_PM_RAIL_READY.kicad_sch"
};
