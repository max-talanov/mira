/* Module: 1500_FPGA_IO_3V3.kicad_sch */
window.MIRA_CONTENT.modules["1500_FPGA_IO_3V3.kicad_sch"]={
  "purpose": "U1501 converts FPGA5V5 into IO3V3 for the FPGA I/O domain.",
  "inputs": [
    "FPGA5V5 is the upstream supply.",
    "CMD_IO33 drives the local enable path to EN_IO33."
  ],
  "outputs": [
    "IO33_RAW is the regulated node before the current-sense shunt.",
    "IO3V3 is the delivered load-side rail.",
    "PGR_IO33 reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_IO33.",
    "EN_IO33 enables U1501 only after the upstream supply is available.",
    "The switching stage and output filter establish IO33_RAW.",
    "The output shunt separates IO33_RAW from IO3V3; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 1500_FPGA_IO_3V3.kicad_sch"
};
