/* Module: PROTECTION.kicad_sch */
window.MIRA_CONTENT.modules["PROTECTION.kicad_sch"]={
  "purpose": "Shared source-side CV/CC control and remembered matrix faults.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Protection",
  "source": "Reachable hierarchy in PROTECTION.kicad_sch"
};
