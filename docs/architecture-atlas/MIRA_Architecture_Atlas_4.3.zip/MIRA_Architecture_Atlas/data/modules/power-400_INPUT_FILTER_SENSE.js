/* Module: 400_INPUT_FILTER_SENSE.kicad_sch */
window.MIRA_CONTENT.modules["400_INPUT_FILTER_SENSE.kicad_sch"]={
  "purpose": "L401 and local capacitors filter EFUSE_OUT. R401 provides the input-current shunt before BUS24.",
  "inputs": [
    "EFUSE_OUT arrives from the protected input stage."
  ],
  "outputs": [
    "BUS24_PRE_SHUNT is the filtered pre-shunt bus.",
    "BUS24 supplies the converters after R401."
  ],
  "operation": [
    "L401 attenuates high-frequency noise while C401–C403 provide local filtering.",
    "All downstream current crosses the 20 mOhm R401 shunt.",
    "D401 indicates delivered bus voltage.",
    "R403/R404 provide a slow discharge path when input power is removed."
  ],
  "notes": [
    "The shunt drop is 20 mV/A and is measured by U3501.",
    "Ferrite impedance at 100 MHz is not its DC resistance."
  ],
  "category": "Power input",
  "source": "Schematic labels and explanatory notes in 400_INPUT_FILTER_SENSE.kicad_sch"
};
