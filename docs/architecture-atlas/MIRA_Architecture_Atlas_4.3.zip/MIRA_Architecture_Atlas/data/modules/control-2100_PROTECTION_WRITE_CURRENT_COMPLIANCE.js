/* Module: 2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch */
window.MIRA_CONTENT.modules["2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch"]={
  "purpose": "The source-side CV/CC controller powers the selected DUT route, senses source current through a selectable shunt and bounds the actuator command.",
  "inputs": [
    "MAT_VTARGET is the selected voltage target.",
    "ILIM_SET / ILIM_RESET / ILIM_FORM provide current targets.",
    "MAT_RSH_A0/A1 select the source-current range.",
    "MAT_SOURCE_SAFE enables the source actuator."
  ],
  "outputs": [
    "MAT_SOURCE and MAT_DRV_OUTPUT drive the service route.",
    "MAT_CC_SENSE reports normalized source-current sense.",
    "MAT_ILIM_SENSE reports the selected current target.",
    "MAT_REG_ERROR and PI nodes implement voltage/current regulation."
  ],
  "operation": [
    "The source selection chooses matching voltage and current commands.",
    "A selected Kelvin-sensed shunt converts delivered source current into a differential voltage.",
    "The voltage and current error paths regulate the common source actuator.",
    "Command bounding, controller reset and anti-windup paths limit stored control error when the source is off or clamped."
  ],
  "notes": [
    "Measured source current includes DUT current, leakage and line-charging current.",
    "The design intentionally avoids a reservoir after the current shunt.",
    "The CV/CC loop, range stability and pulse energy require bench validation."
  ],
  "category": "Protection",
  "source": "Schematic labels and explanatory notes in 2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch"
};
