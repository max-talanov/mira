/* Module: 800_FPGA_DDR3L_AND_REFERENCE_CLOCK.kicad_sch */
window.MIRA_CONTENT.modules["800_FPGA_DDR3L_AND_REFERENCE_CLOCK.kicad_sch"]={
  "purpose": "U800 provides 512 MiB DDR3L to U500. Y800 supplies the differential reference clock for the FPGA memory subsystem.",
  "inputs": [
    "DDR1V35 supplies U800 and U500 banks 15/16.",
    "VTT terminates the indicated address/control lines; DDR_VREF sets the receiver reference.",
    "FPGA_SYSCLK_P / FPGA_SYSCLK_N receive Y800 through AC coupling and bias networks."
  ],
  "outputs": [
    "DDR_DQ0…DDR_DQ15 exchange memory data.",
    "DDR_DQS_P0/N0 and DDR_DQS_P1/N1 strobe the two byte lanes.",
    "DDR_A*, DDR_BA*, DDR_CK_P/N and command lines control memory access."
  ],
  "operation": [
    "The FPGA memory controller drives address, commands and differential memory clock.",
    "U800 exchanges data on two byte lanes, each with its own DQS pair and mask.",
    "Termination and reference networks establish the intended signaling conditions.",
    "Y800 supplies the 200 MHz differential reference through C801/C802 and the input-bias network."
  ],
  "notes": [
    "U800 is independent of the host MCU SDRAM.",
    "Calibration and controller timing must match the device, pin map and PCB routing."
  ],
  "category": "Memory",
  "source": "Schematic labels and explanatory notes in 800_FPGA_DDR3L_AND_REFERENCE_CLOCK.kicad_sch"
};
