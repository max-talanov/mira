/* Module: 1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch */
window.MIRA_CONTENT.modules["1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch"]={
  "purpose": "U500 requests matrix operations. Discrete capture, comparison and qualification logic freeze the route and permit only the prepared image to run.",
  "inputs": [
    "MATRIX_PERMIT, MAT_FAULT_N and MAT_FAULT_CLEAR_N form authorization conditions.",
    "MAT_SPI_* carries the image; *_REQ address/mode nets carry requested configuration.",
    "MAT_FRAME_VALID is an FPGA assertion that the full image is valid."
  ],
  "outputs": [
    "MAT_CONFIG_LATCH commits image and route controls while outputs are disabled.",
    "Captured MAT_BL_A*, MAT_NL_A*, MAT_SRC_A*, MAT_RSH_A* and MAT_POLARITY drive analog selection.",
    "MAT_READ_SAFE, MAT_WRITE_SAFE, MAT_SERVICE_SAFE and MAT_SOURCE_SAFE qualify operations.",
    "MAT_CONFIG_TRIP requests a remembered fault on unsafe route/DAC changes."
  ],
  "operation": [
    "With outputs disabled, shift a complete image and make the qualified MAT_CONFIG_LATCH edge.",
    "U1327/U1328 capture routing fields; U1329/U1330 compare the request against the captured state.",
    "Operation is allowed only when permission, frame-arm and mode conditions agree.",
    "A request mismatch or guarded DAC change during intended WRITE blocks RUN and requests a fault."
  ],
  "notes": [
    "The schematic does not contain an external frame-length counter or CRC checker.",
    "The source notes require at least 1 us between qualified LATCH and OE falling, plus analog settling.",
    "Never change OE while LATCH is high; clearing a fault requires a new validated frame and commit."
  ],
  "category": "Matrix control",
  "source": "Schematic labels and explanatory notes in 1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch"
};
