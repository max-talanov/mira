/* Module: 2000_ADC_CONVERTER_AND_PRECISION_REFERENCES.kicad_sch */
window.MIRA_CONTENT.modules["2000_ADC_CONVERTER_AND_PRECISION_REFERENCES.kicad_sch"]={
  "purpose": "The analog monitor passes through a high-impedance buffer and balanced differential driver into AD4003 U2004, using a dedicated precision reference.",
  "inputs": [
    "MAT_MONITOR_RAW is the selected analog signal.",
    "P15 feeds reference preregulator U2006; ANA5 feeds the differential driver.",
    "MAT_ADC_CNV / SCK / SDI control the converter from U500."
  ],
  "outputs": [
    "MAT_ADC_SDO returns conversion data.",
    "MAT_ADC_REF is the precision reference.",
    "MAT_ADC_INP / MAT_ADC_INN are the balanced converter inputs."
  ],
  "operation": [
    "U2006 supplies the ADR4550 reference U2000; U2001 buffers half-reference common mode.",
    "U2002 isolates the monitor source from the THP210 gain network.",
    "U2003 converts the bipolar monitor level to a differential signal centered on half-reference.",
    "U2004 samples the input pair and returns its serial result to U500."
  ],
  "notes": [
    "The source ideal differential gain is -0.15; convert codes using this gain and calibration.",
    "Initial rate/settling values are validation starting points, not a verified 2 MSPS performance claim."
  ],
  "category": "Acquisition",
  "source": "Schematic labels and explanatory notes in 2000_ADC_CONVERTER_AND_PRECISION_REFERENCES.kicad_sch"
};
