/* Module: 2400_PM_CONTROLLER.kicad_sch */
window.MIRA_CONTENT.modules["2400_PM_CONTROLLER.kicad_sch"]={
  "purpose": "U2401 STM32G0B1 is the AON-powered sequencer, telemetry reader and host supervisor for the power subsystem.",
  "inputs": [
    "PG_*, PGR_* and ALL_RAILS_PG report rail readiness.",
    "GLOBAL_PWR_PERMIT and MATRIX_PERMIT report hardware latch state.",
    "ADC_I / ADC_V, ADC_VTT and PROG_V_P15 report telemetry.",
    "PM_UART_RX receives host communication."
  ],
  "outputs": [
    "EN_REQ_* request individual converters.",
    "PWR_ARM_PULSE and MATRIX_ARM_PULSE arm permissions.",
    "PWR_KILL_GPIO / MATRIX_KILL_GPIO request shutdown.",
    "MUX_A0…A3, MUX_DISABLE, PM_WDI and PM_UART_TX serve telemetry and supervision."
  ],
  "operation": [
    "Boot in the always-on domain and keep enable requests in defined states.",
    "Request branches in a suitable firmware sequence and verify their measured readiness.",
    "Scan paired current/voltage telemetry using the common mux address.",
    "Service the watchdog and arm the matrix only after the required supply and host conditions are valid."
  ],
  "notes": [
    "The schematic does not define the final firmware sequence, timeouts or command protocol.",
    "Hardware permission gates can revoke a request independently of firmware."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 2400_PM_CONTROLLER.kicad_sch"
};
