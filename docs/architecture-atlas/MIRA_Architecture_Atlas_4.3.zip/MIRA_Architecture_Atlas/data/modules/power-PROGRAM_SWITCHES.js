/* Module: PROGRAM_SWITCHES.kicad_sch */
window.MIRA_CONTENT.modules["PROGRAM_SWITCHES.kicad_sch"]={
  "purpose": "Permission-controlled positive and negative programming rails and their output interface.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Programming power",
  "source": "Reachable hierarchy in PROGRAM_SWITCHES.kicad_sch"
};
