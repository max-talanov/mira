/* Module: 3100_PM_COMMAND_READY.kicad_sch */
window.MIRA_CONTENT.modules["3100_PM_COMMAND_READY.kicad_sch"]={
  "purpose": "U3101–U3103 check whether all included rail-enable commands are asserted.",
  "inputs": [
    "Fifteen CMD_* lines represent the requested switched-rail state."
  ],
  "outputs": [
    "ALL_COMMANDS_ON is the command-side matrix-interlock condition."
  ],
  "operation": [
    "The first stage groups commands into CMD_GROUP_0…CMD_GROUP_3.",
    "The final AND gate asserts ALL_COMMANDS_ON only when every command is high.",
    "Any disabled included branch removes this condition."
  ],
  "notes": [
    "This checks command intent, not voltage, current or settling.",
    "Measured readiness remains a separate ALL_RAILS_PG requirement."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 3100_PM_COMMAND_READY.kicad_sch"
};
