/* Module: 1200_DAC_FPGA_CONTROL_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["1200_DAC_FPGA_CONTROL_INTERFACE.kicad_sch"]={
  "purpose": "This U500 section controls the six DACs and receives FORMING status over their shared serial interface.",
  "inputs": [
    "DAC_SPI_MISO and HV_ALERT_N return converter status/data.",
    "IO3V3 supplies the FPGA I/O bank."
  ],
  "outputs": [
    "DAC_SPI_SCK / DAC_SPI_MOSI distribute serial writes.",
    "CS_BL0…3, CS_CTRL and CS_HV select individual converters.",
    "DAC_LDAC_N, DAC_RESET_N and HV_CLEAR_N control updates and clearing."
  ],
  "operation": [
    "Select one converter before shifting a serial command.",
    "Write the intended output values using the shared DAC bus.",
    "Use LDAC and reset according to each converter configuration.",
    "Establish known setpoints before enabling the analog routing."
  ],
  "notes": [
    "Select pull-ups keep the devices inactive while U500 is undriven.",
    "HV_ALERT_N is DAC status and does not replace matrix permission or the hardware fault latch."
  ],
  "category": "Analog sources",
  "source": "Schematic labels and explanatory notes in 1200_DAC_FPGA_CONTROL_INTERFACE.kicad_sch"
};
