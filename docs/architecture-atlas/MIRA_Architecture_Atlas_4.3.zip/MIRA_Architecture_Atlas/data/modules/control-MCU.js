/* Module: MCU.kicad_sch */
window.MIRA_CONTENT.modules["MCU.kicad_sch"]={
  "purpose": "U100 host processing, supply/clock/debug, FMC SDRAM, QSPI, microSD and supervisory communication.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Host processor",
  "source": "Reachable hierarchy in MCU.kicad_sch"
};
