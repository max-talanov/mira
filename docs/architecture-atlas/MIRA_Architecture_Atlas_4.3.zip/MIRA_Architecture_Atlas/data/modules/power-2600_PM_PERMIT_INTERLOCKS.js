/* Module: 2600_PM_PERMIT_INTERLOCKS.kicad_sch */
window.MIRA_CONTENT.modules["2600_PM_PERMIT_INTERLOCKS.kicad_sch"]={
  "purpose": "The AON-powered U2601/U2602 qualification gates and U2603 dual latch grant separate global-power and matrix permissions.",
  "inputs": [
    "PG_INPUT, FLT_INPUT_N, AON_RESET_N, PM reset/watchdog and OC_OK_N qualify global power.",
    "ALL_RAILS_PG, ALL_COMMANDS_ON, host reset/watchdog and matrix stop qualify matrix operation.",
    "PWR_ARM_PULSE / MATRIX_ARM_PULSE request explicit arm events.",
    "MATRIX_INHIBIT_N and the kill/stop paths request shutdown."
  ],
  "outputs": [
    "GLOBAL_PWR_PERMIT qualifies converter commands.",
    "MATRIX_PERMIT enables programming and matrix operation.",
    "MATRIX_KILL_H provides the inverse matrix permission."
  ],
  "operation": [
    "A valid global condition releases the first latch clear.",
    "A rising PWR_ARM_PULSE sets global permission.",
    "Supply/command/host readiness then permits a separate matrix arm edge.",
    "A fault asynchronously clears the corresponding latch and requires deliberate re-arm."
  ],
  "notes": [
    "A global fault clears both permissions; a matrix fault can leave ordinary rails powered.",
    "The close-to-trip stop contacts do not detect an open cable."
  ],
  "category": "Protection",
  "source": "Schematic labels and explanatory notes in 2600_PM_PERMIT_INTERLOCKS.kicad_sch"
};
