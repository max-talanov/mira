/* Module: MIRA_Control.kicad_sch */
window.MIRA_CONTENT.modules["MIRA_Control.kicad_sch"]={
  "purpose": "The current Control project combines the host MCU, FPGA, external communication, analog sources, matrix routing, acquisition and local protection.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "System overview",
  "source": "Reachable hierarchy in MIRA_Control.kicad_sch"
};
