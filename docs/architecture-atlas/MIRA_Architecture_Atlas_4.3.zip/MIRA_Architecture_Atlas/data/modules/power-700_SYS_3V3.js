/* Module: 700_SYS_3V3.kicad_sch */
window.MIRA_CONTENT.modules["700_SYS_3V3.kicad_sch"]={
  "purpose": "U701 converts BUS24 into SYS3V3 for the host and system logic.",
  "inputs": [
    "BUS24 is the upstream supply.",
    "CMD_SYS drives the local enable path to EN_SYS."
  ],
  "outputs": [
    "SYS_RAW is the regulated node before the current-sense shunt.",
    "SYS3V3 is the delivered load-side rail.",
    "PG_SYS reports the regulator power-good state to supervision."
  ],
  "operation": [
    "The power manager requests this branch and the permit gate produces CMD_SYS.",
    "EN_SYS enables U701 only after the upstream supply is available.",
    "The switching stage and output filter establish SYS_RAW.",
    "The output shunt separates SYS_RAW from SYS3V3; monitoring measures its drop and the delivered voltage."
  ],
  "notes": [
    "Feedback is taken before the shunt, so the delivered rail falls with load current.",
    "This diagram explains connectivity and enable dependency; it does not prescribe a validated startup delay."
  ],
  "category": "Power conversion",
  "source": "Schematic labels and explanatory notes in 700_SYS_3V3.kicad_sch"
};
