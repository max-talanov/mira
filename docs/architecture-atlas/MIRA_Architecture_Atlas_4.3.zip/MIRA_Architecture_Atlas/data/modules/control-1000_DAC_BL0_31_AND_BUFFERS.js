/* Module: 1000_DAC_BL0_31_AND_BUFFERS.kicad_sch */
window.MIRA_CONTENT.modules["1000_DAC_BL0_31_AND_BUFFERS.kicad_sch"]={
  "purpose": "Four AD5676R DACs generate 32 bit-line voltage setpoints; OPA4192 followers buffer them for the matrix switching network.",
  "inputs": [
    "DAC_SPI_SCK / MOSI and CS_BL0…CS_BL3 select and load the DACs.",
    "DAC_LDAC_N and DAC_RESET_N control update/reset.",
    "ANA5, IO3V3, P15 and N15 supply analog and logic domains."
  ],
  "outputs": [
    "BL_DAC_RAW0…BL_DAC_RAW31 are raw converter outputs.",
    "BL_DAC0…BL_DAC31 are buffered outputs to sheet 1500.",
    "DAC_SPI_MISO is the shared serial return."
  ],
  "operation": [
    "U1000, U1003, U1006 and U1009 each generate eight setpoints.",
    "Local follower channels buffer each raw DAC output.",
    "A 4.7 ohm resistor separates each amplifier output from its BL_DAC route.",
    "The matrix mask determines whether a given source actually reaches the crossbar."
  ],
  "notes": [
    "These sources are not permanently wired to BL0…BL31.",
    "DAC hardware gain and reset straps must be reflected in the code-to-voltage conversion."
  ],
  "category": "Analog sources",
  "source": "Schematic labels and explanatory notes in 1000_DAC_BL0_31_AND_BUFFERS.kicad_sch"
};
