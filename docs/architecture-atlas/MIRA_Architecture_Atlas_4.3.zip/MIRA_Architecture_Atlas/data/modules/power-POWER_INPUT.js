/* Module: POWER_INPUT.kicad_sch */
window.MIRA_CONTENT.modules["POWER_INPUT.kicad_sch"]={
  "purpose": "Connector, fuse, eFuse, input filtering and current sensing before the common bus.",
  "inputs": [],
  "outputs": [],
  "operation": [
    "Open a child circuit to inspect its actual components and connections.",
    "Repeated component references identify units of the same physical package within this board."
  ],
  "notes": [
    "This is a hierarchy/navigation sheet; it adds no separate circuitry."
  ],
  "category": "Power input",
  "source": "Reachable hierarchy in POWER_INPUT.kicad_sch"
};
