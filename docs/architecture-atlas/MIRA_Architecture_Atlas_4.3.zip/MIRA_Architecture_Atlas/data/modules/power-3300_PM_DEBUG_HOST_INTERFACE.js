/* Module: 3300_PM_DEBUG_HOST_INTERFACE.kicad_sch */
window.MIRA_CONTENT.modules["3300_PM_DEBUG_HOST_INTERFACE.kicad_sch"]={
  "purpose": "J3301 provides power-manager SWD. J3302 and U3301 connect UART, watchdog and status signals to the host domain.",
  "inputs": [
    "SYS3V3 powers the host-side U3301 receiver outputs.",
    "HOST_UART_TX reaches PM_UART_RX through R3305.",
    "HOST_WDI returns host heartbeat.",
    "VTT feeds a separate filtered monitor."
  ],
  "outputs": [
    "PM_UART_TX_HOST, MATRIX_PERMIT_HOST, ALL_RAILS_PG_HOST and GLOBAL_PWR_PERMIT_HOST reach J3302.",
    "ADC_VTT reaches U2401.",
    "PM_SWDIO_MCU / PM_SWCLK_MCU permit debug access."
  ],
  "operation": [
    "U3301 buffers supervisor outputs using the host power domain.",
    "UART and heartbeat provide the host/PM handshake.",
    "J3301 exposes reset and SWD with a sense-only voltage reference.",
    "The VTT divider/filter path supplies the independent ADC check."
  ],
  "notes": [
    "Current Control also contains its own status receivers at J400; do not assume J3302 pins mate directly to J400.",
    "Reference pins are rail references for external tools to sense."
  ],
  "category": "Interconnect",
  "source": "Schematic labels and explanatory notes in 3300_PM_DEBUG_HOST_INTERFACE.kicad_sch"
};
