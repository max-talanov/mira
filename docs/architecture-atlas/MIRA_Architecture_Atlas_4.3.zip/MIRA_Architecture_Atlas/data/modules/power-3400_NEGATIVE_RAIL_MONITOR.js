/* Module: 3400_NEGATIVE_RAIL_MONITOR.kicad_sch */
window.MIRA_CONTENT.modules["3400_NEGATIVE_RAIL_MONITOR.kicad_sch"]={
  "purpose": "U3401 translates the negative AFE rail and its shunt voltage into positive telemetry and hardware-overcurrent signals.",
  "inputs": [
    "N15_RAW and N15 span the upstream current shunt.",
    "AON and N15_RAW power the amplifier."
  ],
  "outputs": [
    "MON_I_N15 is filtered negative-rail current telemetry.",
    "MON_V_N15 is a positive scaled voltage measurement.",
    "OC_I_N15 is the separate overcurrent-comparator signal."
  ],
  "operation": [
    "One amplifier channel senses the current-shunt voltage with positive scaling.",
    "The other translates the negative output voltage into a positive signal.",
    "Telemetry branches are filtered before reaching the multiplexers.",
    "OC_I_N15 takes a separate path to the comparator without the telemetry capacitor."
  ],
  "notes": [
    "The source ideal scaling is 2 V/A for current and -0.1 times N15 for voltage.",
    "Measurements during rail transitions require settling and valid AON."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 3400_NEGATIVE_RAIL_MONITOR.kicad_sch"
};
