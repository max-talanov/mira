/* Module: 300_INPUT_EFUSE_PROTECTION.kicad_sch */
window.MIRA_CONTENT.modules["300_INPUT_EFUSE_PROTECTION.kicad_sch"]={
  "purpose": "U301 TPS26631 and external Q301/Q302 provide controlled input protection, a limited startup ramp and fault/status outputs.",
  "inputs": [
    "+24V_FUSED supplies the pass/protection stage.",
    "AON pulls up the status interface.",
    "JP301 can assert the local shutdown input."
  ],
  "outputs": [
    "EFUSE_OUT is the protected input supply.",
    "PG_INPUT reports output threshold and pass-device readiness.",
    "FLT_INPUT_N reports the eFuse fault state."
  ],
  "operation": [
    "The UVLO/OVP dividers establish the allowed input window.",
    "U301 controls the external reverse-protection path and raises EFUSE_OUT with its slew setting.",
    "The current-limit setting and selected mode determine overload behavior.",
    "PG_INPUT is accepted by the permit chain together with fault and supervisor conditions."
  ],
  "notes": [
    "The source notes specify latch-off after sustained overload; restart is a separate action.",
    "No animation substitutes for validating startup/inrush or protection thresholds."
  ],
  "category": "Power input",
  "source": "Schematic labels and explanatory notes in 300_INPUT_EFUSE_PROTECTION.kicad_sch"
};
