/* Module: 2800_PM_ENABLE_GATES_AUXILIARY.kicad_sch */
window.MIRA_CONTENT.modules["2800_PM_ENABLE_GATES_AUXILIARY.kicad_sch"]={
  "purpose": "U2801/U2802 qualify converter enable requests with the independent global-power permit.",
  "inputs": [
    "GLOBAL_PWR_PERMIT authorizes all channels.",
    "EN_REQ_AUX25 requests its branch.",
    "EN_REQ_IO33 requests its branch.",
    "EN_REQ_DDR requests its branch.",
    "EN_REQ_PHY requests its branch.",
    "EN_REQ_VTT requests its branch.",
    "EN_REQ_ANA5 requests its branch.",
    "EN_REQ_ANA33 requests its branch."
  ],
  "outputs": [
    "CMD_AUX25 drives its converter enable path.",
    "CMD_IO33 drives its converter enable path.",
    "CMD_DDR drives its converter enable path.",
    "CMD_PHY drives its converter enable path.",
    "CMD_VTT drives its converter enable path.",
    "CMD_ANA5 drives its converter enable path.",
    "CMD_ANA33 drives its converter enable path."
  ],
  "operation": [
    "The firmware selects the required EN_REQ line.",
    "The hardware AND gate produces CMD only while GLOBAL_PWR_PERMIT is high.",
    "Clearing the permit removes every command in this bank.",
    "Pull-down resistors keep request and command defaults low."
  ],
  "notes": [
    "Logic gating adds authorization, not a verified startup delay.",
    "An enabled command does not prove a healthy output voltage."
  ],
  "category": "Power supervision",
  "source": "Schematic labels and explanatory notes in 2800_PM_ENABLE_GATES_AUXILIARY.kicad_sch"
};
