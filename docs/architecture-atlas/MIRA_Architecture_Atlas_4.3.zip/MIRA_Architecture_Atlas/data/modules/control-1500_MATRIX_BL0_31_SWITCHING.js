/* Module: 1500_MATRIX_BL0_31_SWITCHING.kicad_sch */
window.MIRA_CONTENT.modules["1500_MATRIX_BL0_31_SWITCHING.kicad_sch"]={
  "purpose": "BL0–BL31 each have an independent DAC-drive switch, ground-clamp switch and a selectable service connection.",
  "inputs": [
    "BL_DAC0…31 arrive from the buffered DACs.",
    "MAT_BL_VMM_0…31 and MAT_BL_ZERO_0…31 control the two per-line paths.",
    "MAT_BL_A0…2 and MAT_SERVICE_SAFE select/enable service access."
  ],
  "outputs": [
    "BL0…BL31 go to the socket.",
    "MAT_BL_BANK_0…3 carry one selected line per group to the service router."
  ],
  "operation": [
    "A VMM switch connects each permitted BL_DAC source to its bit line.",
    "An independent clamp can connect that line to ground.",
    "U1516–U1519 each select one of eight bit lines.",
    "The service-router bank selection chooses which group continues to MAT_BL_SERVICE."
  ],
  "notes": [
    "Optional 1 Mohm line bleeders are DNP to avoid bypassing WRITE sensing.",
    "With both paths open a bit line may float; choose a deliberate clamp/discharge state."
  ],
  "category": "Matrix routing",
  "source": "Schematic labels and explanatory notes in 1500_MATRIX_BL0_31_SWITCHING.kicad_sch"
};
