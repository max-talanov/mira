/* Module: 4000_TELEMETRY_ADC_BUFFERS.kicad_sch */
window.MIRA_CONTENT.modules["4000_TELEMETRY_ADC_BUFFERS.kicad_sch"]={
  "purpose": "U4001 buffers the paired telemetry mux outputs into the power-manager ADC inputs.",
  "inputs": [
    "MUX_I_COM and MUX_V_COM are the selected analog monitors."
  ],
  "outputs": [
    "ADC_I drives the U2401 current input.",
    "ADC_V drives the U2401 voltage input.",
    "Pull resistors define MUX_A0…3, MUX_DISABLE and OC_OK_N defaults."
  ],
  "operation": [
    "The two unity-gain followers isolate telemetry sources from ADC sampling current.",
    "Output resistors and small capacitors provide local isolation/filtering.",
    "The controller acquires ADC_I and ADC_V after channel and amplifier settling."
  ],
  "notes": [
    "MUX_DISABLE defaults high so the analog selectors start disconnected.",
    "OC_OK_N is a separate hardware-fault signal, not an ADC result."
  ],
  "category": "Telemetry",
  "source": "Schematic labels and explanatory notes in 4000_TELEMETRY_ADC_BUFFERS.kicad_sch"
};
