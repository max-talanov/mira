/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "matrix-write",
  "title": "Apply a controlled WRITE",
  "description": "Follow held routing and the shared source-side CV/CC actuator through a representative WRITE operation. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Load the target while disabled",
      "body": "Prepare SET, RESET or FORM voltage and the matching current-limit DAC value before requesting WRITE. Voltage targets use the defined positive source range.",
      "board": "control",
      "sheetFile": "1100_DAC_SERVICE_AND_FORMING.kicad_sch",
      "refs": [
        "U1100",
        "U1102",
        "U1103",
        "U1104"
      ],
      "nets": [
        "VSET_SRC",
        "VRESET_SRC",
        "VFORM_SRC",
        "ILIM_SET",
        "ILIM_RESET",
        "ILIM_FORM"
      ]
    },
    {
      "title": "Capture and validate the route",
      "body": "Capture source, shunt range, polarity and BL/NL addresses with the qualified image commit. A later request change during intended WRITE produces a configuration trip.",
      "board": "control",
      "sheetFile": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch",
      "refs": [
        "U1327",
        "U1328",
        "U1329",
        "U1330"
      ],
      "nets": [
        "MAT_CONFIG_LATCH",
        "MAT_CONFIG_MATCH",
        "MAT_WRITE_SAFE",
        "MAT_SOURCE_SAFE"
      ]
    },
    {
      "title": "Regulate delivered source current",
      "body": "The selected shunt and sense amplifier observe source current. Voltage and current error paths regulate the same actuator with bounded command and reset behavior.",
      "board": "control",
      "sheetFile": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE.kicad_sch",
      "refs": [
        "U2104",
        "U2105",
        "U2106",
        "U2107"
      ],
      "nets": [
        "MAT_VTARGET",
        "MAT_ILIM_SENSE",
        "MAT_CC_SENSE",
        "MAT_SOURCE",
        "MAT_SOURCE_SAFE"
      ]
    },
    {
      "title": "Apply the selected polarity",
      "body": "The held analog route connects the controlled source and return to the chosen matrix terminals. No charged pulse switch is placed after the source-current sense in this architecture.",
      "board": "control",
      "sheetFile": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch",
      "refs": [
        "U1602"
      ],
      "nets": [
        "MAT_SOURCE",
        "MAT_RETURN",
        "MAT_POLARITY",
        "MAT_BL_SERVICE",
        "MAT_NL_SERVICE"
      ]
    },
    {
      "title": "Reach the DUT socket",
      "body": "The selected BL/NL and WL nets reach their actual J1800 contacts. The socket view preserves component annotation and pin numbering from KiCad.",
      "board": "control",
      "sheetFile": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS.kicad_sch",
      "refs": [
        "J1800"
      ],
      "nets": [
        "BL0",
        "NL0",
        "WL0"
      ]
    },
    {
      "title": "Observe independent backup shutdown",
      "body": "The coarse comparator and remembered configuration/overcurrent fault path remain separate from precision CV/CC regulation.",
      "board": "control",
      "sheetFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
      "refs": [
        "U2200",
        "U2201",
        "U2202",
        "U2203"
      ],
      "nets": [
        "MAT_OC_TRIP",
        "MAT_CONFIG_TRIP",
        "MAT_FAULT_Q"
      ]
    },
    {
      "title": "Turn off and discharge before rerouting",
      "body": "Remove source enable, discharge through the defined path and allow the selected range to settle before changing polarity or routing.",
      "board": "control",
      "sheetFile": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch",
      "refs": [
        "U1603"
      ],
      "nets": [
        "MAT_SOURCE_OFF",
        "MAT_SOURCE_SAFE",
        "MAT_PI_RESET_C"
      ]
    }
  ]
});
