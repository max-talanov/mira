/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "matrix-read",
  "title": "Read the matrix",
  "description": "Walk through source preparation, a qualified route, current conversion and ADC capture. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Prepare the READ target",
      "body": "U1100 and U1101 establish VREAD_SRC. READ uses the shared current target ILIM_SET; setpoints are prepared before enabling the route.",
      "board": "control",
      "sheetFile": "1100_DAC_SERVICE_AND_FORMING.kicad_sch",
      "refs": [
        "U1100",
        "U1101",
        "U1102"
      ],
      "nets": [
        "VREAD_SRC",
        "ILIM_SET",
        "VWL_SRC"
      ]
    },
    {
      "title": "Commit the prepared route",
      "body": "With outputs disabled, commit the complete validated image and captured address/mode fields. MATRIX_PERMIT and fault state qualify operation.",
      "board": "control",
      "sheetFile": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch",
      "refs": [
        "U1327",
        "U1328",
        "U1329",
        "U1330"
      ],
      "nets": [
        "MAT_CONFIG_LATCH",
        "MAT_READ_SAFE",
        "MAT_SERVICE_SAFE",
        "MATRIX_PERMIT"
      ]
    },
    {
      "title": "Expose the line-control image",
      "body": "The 80-bit register chain presents the BL masks, word-line selection and neuron-line clamps. The selected measurement path must be unclamped.",
      "board": "control",
      "sheetFile": "1400_MATRIX_SERIAL_CONTROL_REGISTERS.kicad_sch",
      "refs": [
        "U1400",
        "U1408",
        "U1409"
      ],
      "nets": [
        "MAT_BL_VMM_0",
        "MAT_WL_ON_0",
        "MAT_NL_ZERO_0",
        "MAT_OE_N"
      ]
    },
    {
      "title": "Connect service source and READ return",
      "body": "The captured selector/polarity state connects the prepared source/return topology. MAT_VTARGET is a command; the source controller supplies the DUT path.",
      "board": "control",
      "sheetFile": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING.kicad_sch",
      "refs": [
        "U1600",
        "U1601",
        "U1602"
      ],
      "nets": [
        "MAT_VTARGET",
        "MAT_BL_SERVICE",
        "MAT_NL_SERVICE",
        "MAT_TIA_IN",
        "MAT_READ_SAFE"
      ]
    },
    {
      "title": "Select the neuron return",
      "body": "U1705 selects one NL while its clamp is released. Word-line switches present VWL_SRC or ground according to the held mask.",
      "board": "control",
      "sheetFile": "1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR.kicad_sch",
      "refs": [
        "U1700",
        "U1701",
        "U1705"
      ],
      "nets": [
        "MAT_NL_SERVICE",
        "MAT_NL_A0",
        "MAT_NL_A1",
        "MAT_NL_A2",
        "VWL_SRC"
      ]
    },
    {
      "title": "Convert current to voltage",
      "body": "U1900 converts the returned current to MAT_TIA_OUT. U1901 chooses feedback range and U1902 selects the monitored output.",
      "board": "control",
      "sheetFile": "1900_ADC_TIA_AND_MONITOR_SELECTOR.kicad_sch",
      "refs": [
        "U1900",
        "U1901",
        "U1902"
      ],
      "nets": [
        "MAT_TIA_IN",
        "MAT_TIA_OUT",
        "MAT_MONITOR_RAW"
      ]
    },
    {
      "title": "Sample and return a conversion",
      "body": "The buffer and THP210 driver feed AD4003 U2004. U500 issues CNV/serial clocks and receives MAT_ADC_SDO after the required settling.",
      "board": "control",
      "sheetFile": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES.kicad_sch",
      "refs": [
        "U2002",
        "U2003",
        "U2004"
      ],
      "nets": [
        "MAT_MONITOR_RAW",
        "MAT_ADC_CNV",
        "MAT_ADC_SCK",
        "MAT_ADC_SDO"
      ]
    }
  ]
});
