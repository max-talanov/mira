/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "ethernet-rx",
  "title": "Receive an Ethernet message",
  "description": "Follow cable-side analog activity into the PHY, then observe the digital receive interface of U500. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Cable waveform reaches J900",
      "body": "The cable carries analog differential activity on four pairs. The pulse drawing is an educational signal shape, not a 1000BASE-T line-code simulation.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "J900"
      ],
      "nets": [
        "ETH_A_P",
        "ETH_A_N",
        "ETH_B_P",
        "ETH_B_N"
      ]
    },
    {
      "title": "Cross the magnetics",
      "body": "T900 transfers the pair activity across the magnetic coupling to the PHY-side MDI nets. Cable and PHY sides remain distinct electrical nets.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "T900"
      ],
      "nets": [
        "ETH_A_P",
        "ETH_A_N",
        "MDI_A_P",
        "MDI_A_N"
      ]
    },
    {
      "title": "PHY receives and recovers data",
      "body": "U902 performs physical-link reception and presents its recovered receive data and clock to the FPGA interface.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U902"
      ],
      "nets": [
        "MDI_A_P",
        "MDI_A_N",
        "PHY_RXC",
        "PHY_RX_CTL"
      ]
    },
    {
      "title": "Observe RGMII receive data",
      "body": "PHY_RXD0…3 carry receive symbols alongside PHY_RXC and PHY_RX_CTL. The digital microscope uses a synthetic byte example rather than decoding the analog cable sketch.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U902",
        "U500"
      ],
      "nets": [
        "PHY_RXC",
        "PHY_RX_CTL",
        "PHY_RXD0",
        "PHY_RXD1",
        "PHY_RXD2",
        "PHY_RXD3"
      ]
    },
    {
      "title": "Interpret the message in FPGA logic",
      "body": "The selected FPGA design must provide Ethernet MAC behavior and its chosen protocol/application processing. A bitstream or command implementation is not included in this schematic atlas.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U500"
      ],
      "nets": [
        "PHY_RXD0",
        "PHY_RXD1",
        "PHY_RXD2",
        "PHY_RXD3"
      ]
    }
  ]
});
