/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "fpga-config",
  "title": "Configure and recover the FPGA",
  "description": "Follow the configuration flash path, status return and open-drain reconfiguration control. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Power the FPGA domains",
      "body": "The selected core, auxiliary and I/O rails reach the one physical U500 package. The final rail sequence is outside this illustrative flow.",
      "board": "control",
      "sheetFile": "500_FPGA_POWER_AND_DECOUPLING.kicad_sch",
      "refs": [
        "U500"
      ],
      "nets": [
        "CORE1V0",
        "AUX1V8",
        "IO3V3"
      ]
    },
    {
      "title": "Read the configuration flash",
      "body": "The mode straps select Master SPI. U500 clocks U600 and reads configuration data through the named flash interface.",
      "board": "control",
      "sheetFile": "600_FPGA_CONFIGURATION_AND_XADC.kicad_sch",
      "refs": [
        "U500",
        "U600"
      ],
      "nets": [
        "FPGA_CFG_CLK",
        "FPGA_CFG_CS_N",
        "FPGA_CFG_D0",
        "FPGA_CFG_D1",
        "FPGA_CFG_D2",
        "FPGA_CFG_D3"
      ]
    },
    {
      "title": "Observe configuration status",
      "body": "FPGA_INIT_N and FPGA_DONE report configuration state. Their meaning is narrower than application, DDR or network readiness.",
      "board": "control",
      "sheetFile": "600_FPGA_CONFIGURATION_AND_XADC.kicad_sch",
      "refs": [
        "U500"
      ],
      "nets": [
        "FPGA_INIT_N",
        "FPGA_DONE"
      ]
    },
    {
      "title": "Return status to the MCU domain",
      "body": "SYS3V3-powered U901 returns configuration status as FPGA_DONE_MCU and FPGA_INIT_N_MCU without joining the receiver power domains.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U901"
      ],
      "nets": [
        "FPGA_DONE",
        "FPGA_INIT_N",
        "FPGA_DONE_MCU",
        "FPGA_INIT_N_MCU"
      ]
    },
    {
      "title": "Read status at U100",
      "body": "U100 receives FPGA_DONE_MCU and FPGA_INIT_N_MCU on its assigned status pins. Firmware decides how to report configuration progress.",
      "board": "control",
      "sheetFile": "100_MCU_POWER_CLOCKS_AND_DEBUG.kicad_sch",
      "refs": [
        "U100"
      ],
      "nets": [
        "FPGA_DONE_MCU",
        "FPGA_INIT_N_MCU"
      ]
    },
    {
      "title": "Request reconfiguration or use JTAG",
      "body": "MCU_RESET_FPGA_N drives open-drain U601 to pull PROGRAM_B low, then release it. SW600 and J600 provide manual/direct recovery access.",
      "board": "control",
      "sheetFile": "600_FPGA_CONFIGURATION_AND_XADC.kicad_sch",
      "refs": [
        "U601",
        "SW600",
        "J600"
      ],
      "nets": [
        "MCU_RESET_FPGA_N",
        "FPGA_PROGRAM_N",
        "FPGA_JTAG_TCK",
        "FPGA_JTAG_TMS"
      ]
    }
  ]
});
