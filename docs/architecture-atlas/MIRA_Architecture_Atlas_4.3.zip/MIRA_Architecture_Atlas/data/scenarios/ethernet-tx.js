/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "ethernet-tx",
  "title": "Transmit an Ethernet message",
  "description": "Observe the reverse functional route from FPGA transmit pins to the external cable. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Prepare outgoing data",
      "body": "Application logic and the chosen network stack supply an outgoing message to the FPGA MAC. This processing is a logical explanation, not an extracted firmware implementation.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U500"
      ],
      "nets": [
        "PHY_TXD0",
        "PHY_TXD1",
        "PHY_TXD2",
        "PHY_TXD3"
      ]
    },
    {
      "title": "Drive the RGMII transmit interface",
      "body": "U500 presents digital data, transmit control and transmit clock to the PHY on the exact PHY_TX* nets.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U500",
        "U902"
      ],
      "nets": [
        "PHY_TXC",
        "PHY_TX_CTL",
        "PHY_TXD0",
        "PHY_TXD1",
        "PHY_TXD2",
        "PHY_TXD3"
      ]
    },
    {
      "title": "Convert to physical-link signaling",
      "body": "U902 converts the transmit interface into cable-link activity on its MDI pairs. Analog line coding and echo cancellation are not simulated.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "U902"
      ],
      "nets": [
        "MDI_A_P",
        "MDI_A_N",
        "MDI_B_P",
        "MDI_B_N"
      ]
    },
    {
      "title": "Cross T900 and leave J900",
      "body": "The physical-link signal crosses T900 and reaches J900 cable-side pairs. The simplified moving waveform represents activity only.",
      "board": "control",
      "sheetFile": "900_FPGA_ETHERNET_AND_MCU_INTERFACE.kicad_sch",
      "refs": [
        "T900",
        "J900"
      ],
      "nets": [
        "MDI_A_P",
        "MDI_A_N",
        "ETH_A_P",
        "ETH_A_N"
      ]
    }
  ]
});
