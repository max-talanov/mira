/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "matrix-fault",
  "title": "Trip and remember a matrix fault",
  "description": "Follow the local hardware fault memory and its logical request to the Power interlock. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Detect excessive current",
      "body": "U2200 compares buffered current sense against the coarse backup threshold. The analog event is qualified by MAT_WRITE_SAFE.",
      "board": "control",
      "sheetFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
      "refs": [
        "U2200",
        "U2201"
      ],
      "nets": [
        "MAT_CC_SENSE_BUF",
        "MAT_ILIM_SENSE_BUF",
        "MAT_OC_TRIP",
        "MAT_WRITE_SAFE"
      ]
    },
    {
      "title": "Combine fault sources",
      "body": "U2203 combines the qualified overcurrent event with MAT_CONFIG_TRIP. The configuration branch is not masked by WRITE_SAFE.",
      "board": "control",
      "sheetFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
      "refs": [
        "U2203"
      ],
      "nets": [
        "MAT_CONFIG_TRIP",
        "MAT_OC_TRIP",
        "MAT_TRIP"
      ]
    },
    {
      "title": "Latch shutdown locally",
      "body": "U2202 stores the event. Q2200 asserts MAT_FAULT_N and Q2203 pulls the inhibit return low. The action does not wait for ADC polling.",
      "board": "control",
      "sheetFile": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE.kicad_sch",
      "refs": [
        "U2202",
        "Q2200",
        "Q2203"
      ],
      "nets": [
        "MAT_FAULT_Q",
        "MAT_FAULT_N",
        "MATRIX_INHIBIT_N"
      ]
    },
    {
      "title": "Remove local authorization",
      "body": "The fault state removes MAT_ALLOWED and blocks the qualified run/source window. A new valid image is needed after explicit fault clearing.",
      "board": "control",
      "sheetFile": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS.kicad_sch",
      "refs": [
        "U1300",
        "U1301"
      ],
      "nets": [
        "MAT_FAULT_N",
        "MAT_ALLOWED",
        "MAT_SOURCE_SAFE",
        "MAT_RUN"
      ]
    },
    {
      "title": "Export the inhibit request",
      "body": "J400 exposes the open-drain MATRIX_INHIBIT_N return. This is a logical cross-board handoff; the mating Power pin mapping remains unverified.",
      "board": "control",
      "sheetFile": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch",
      "refs": [
        "J400"
      ],
      "nets": [
        "MATRIX_INHIBIT_N"
      ]
    },
    {
      "title": "Clear matrix permission at Power",
      "body": "The Power interlock also uses MATRIX_INHIBIT_N. A valid electrical mating interface would allow that low request to clear matrix permission; this atlas does not assume the missing connector contract is proven.",
      "board": "power",
      "sheetFile": "2600_PM_PERMIT_INTERLOCKS.kicad_sch",
      "refs": [
        "U2602",
        "U2603"
      ],
      "nets": [
        "MATRIX_INHIBIT_N",
        "MATRIX_CLEAR_N",
        "MATRIX_PERMIT"
      ]
    },
    {
      "title": "Disable the programming switch",
      "body": "Loss of MATRIX_PERMIT returns the positive switch to OFF and enables its discharge path. The actual rail decay includes finite gate and capacitor timing.",
      "board": "power",
      "sheetFile": "2100_PROGRAM_POSITIVE.kicad_sch",
      "refs": [
        "Q2102",
        "Q2103",
        "Q2107"
      ],
      "nets": [
        "MATRIX_PERMIT",
        "PROG_P15"
      ]
    }
  ]
});
