/* Illustrative operation scenario; source identities are validated. */
window.MIRA_CONTENT.scenarios.push({
  "id": "power-up",
  "title": "Power up MIRA",
  "description": "Follow the input path, always-on supervisor and an example branch dependency. This is not the final rail sequencing specification. Illustrative logical order only; timing, firmware and analog performance are not verified by this animation.",
  "kind": "illustrative",
  "steps": [
    {
      "title": "Connect the external source",
      "body": "The source appears at J101. Correct polarity produces the green input indication; the raw input continues to the fuse.",
      "board": "power",
      "sheetFile": "100_INPUT_CONNECTOR.kicad_sch",
      "refs": [
        "J101"
      ],
      "nets": [
        "+24V_RAW"
      ]
    },
    {
      "title": "Pass the fused input",
      "body": "F201 feeds the protected downstream branch. The indicators distinguish raw-present/fused-absent conditions.",
      "board": "power",
      "sheetFile": "200_INPUT_FUSE_PROTECTION.kicad_sch",
      "refs": [
        "F201",
        "Q201"
      ],
      "nets": [
        "+24V_RAW",
        "+24V_FUSED"
      ]
    },
    {
      "title": "Ramp the protected bus",
      "body": "U301 qualifies the input window and limits the EFUSE_OUT startup slew. PG_INPUT and FLT_INPUT_N enter the supervisor conditions.",
      "board": "power",
      "sheetFile": "300_INPUT_EFUSE_PROTECTION.kicad_sch",
      "refs": [
        "U301",
        "Q301",
        "Q302"
      ],
      "nets": [
        "+24V_FUSED",
        "EFUSE_OUT",
        "PG_INPUT",
        "FLT_INPUT_N"
      ]
    },
    {
      "title": "Filter and measure input current",
      "body": "L401 and the capacitors filter the supply. Current crosses R401 before BUS24 reaches the converters.",
      "board": "power",
      "sheetFile": "400_INPUT_FILTER_SENSE.kicad_sch",
      "refs": [
        "L401",
        "R401"
      ],
      "nets": [
        "EFUSE_OUT",
        "BUS24_PRE_SHUNT",
        "BUS24"
      ]
    },
    {
      "title": "Start the always-on domain",
      "body": "U501 begins from BUS24 without a separate command. AON now supports the controller, watchdogs and interlocks.",
      "board": "power",
      "sheetFile": "500_AON_3V3_BUCK.kicad_sch",
      "refs": [
        "U501"
      ],
      "nets": [
        "BUS24",
        "AON_RAW",
        "AON"
      ]
    },
    {
      "title": "Establish hardware permission",
      "body": "Only valid global conditions permit a PWR_ARM_PULSE to set GLOBAL_PWR_PERMIT. A cleared fault does not arm the latch automatically.",
      "board": "power",
      "sheetFile": "2600_PM_PERMIT_INTERLOCKS.kicad_sch",
      "refs": [
        "U2601",
        "U2603"
      ],
      "nets": [
        "PWR_ARM_PULSE",
        "GLOBAL_PWR_PERMIT",
        "GLOBAL_CLEAR_N"
      ]
    },
    {
      "title": "Qualify an example rail request",
      "body": "EN_REQ_FPGA is gated with GLOBAL_PWR_PERMIT to form CMD_FPGA. The same rule applies to the other enable channels.",
      "board": "power",
      "sheetFile": "2700_PM_ENABLE_GATES_PRIMARY.kicad_sch",
      "refs": [
        "U2701"
      ],
      "nets": [
        "EN_REQ_FPGA",
        "GLOBAL_PWR_PERMIT",
        "CMD_FPGA"
      ]
    },
    {
      "title": "Produce the FPGA intermediate rail",
      "body": "U801 generates FPGA5V5. A final implementation checks actual settling and readiness before enabling dependent supplies.",
      "board": "power",
      "sheetFile": "800_FPGA_INTERMEDIATE_5V5.kicad_sch",
      "refs": [
        "U801",
        "L801"
      ],
      "nets": [
        "CMD_FPGA",
        "FPGA_RAW",
        "FPGA5V5",
        "PG_FPGA"
      ]
    },
    {
      "title": "Produce an example load rail",
      "body": "U1201 produces CORE1V0 from FPGA5V5. This illustrates an upstream/downstream dependency, not the complete FPGA rail order.",
      "board": "power",
      "sheetFile": "1200_POWER_MONITOR.kicad_sch",
      "refs": [
        "U1201"
      ],
      "nets": [
        "FPGA5V5",
        "CORE_RAW",
        "CORE1V0",
        "PGR_CORE"
      ]
    },
    {
      "title": "Check measured readiness",
      "body": "The status tree forms ALL_RAILS_PG only when all included rails report ready. Command readiness is checked separately.",
      "board": "power",
      "sheetFile": "3000_PM_RAIL_READY.kicad_sch",
      "refs": [
        "U3001",
        "U3017",
        "U3018"
      ],
      "nets": [
        "ALL_RAILS_PG"
      ]
    },
    {
      "title": "Receive rails on Control",
      "body": "J400 is the receiving interface. Identical rail names establish logical associations only; mating connector pins between these source versions remain unverified.",
      "board": "control",
      "sheetFile": "400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE.kicad_sch",
      "refs": [
        "J400",
        "U400",
        "U401"
      ],
      "nets": [
        "CORE1V0",
        "SYS3V3",
        "MATRIX_PERMIT_POWER",
        "MATRIX_PERMIT"
      ]
    }
  ]
});
