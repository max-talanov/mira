/* Main architecture overview. Source-bound scenes; plain Russian; manual narration. */
window.MIRA_OVERVIEW_TOUR={
  "version": 1,
  "title": "MIRA — понятный обзор всей архитектуры",
  "duration": "10–15 минут",
  "chapters": [
    {
      "id": "overview-whole",
      "title": "Общая идея",
      "summary": "Свяжем энергию, команду, матрицу и измерение в один цикл."
    },
    {
      "id": "overview-power",
      "title": "Подготовка питания",
      "summary": "Защита входа, дежурная часть, питающие ветви и проверка готовности."
    },
    {
      "id": "overview-control",
      "title": "Управление и запуск",
      "summary": "Роли контроллера и ПЛИС, загрузка рабочей конфигурации."
    },
    {
      "id": "overview-link",
      "title": "Связь с компьютером",
      "summary": "Проследим входящие данные и согласование цифровых узлов."
    },
    {
      "id": "overview-matrix",
      "title": "Воздействие и матрица",
      "summary": "Создадим напряжения и выберем, по каким линиям они пойдут."
    },
    {
      "id": "overview-readout",
      "title": "Измерение и сбор данных",
      "summary": "Ток матрицы превратится в цифровой результат."
    },
    {
      "id": "overview-safety",
      "title": "Защита и результат",
      "summary": "Ограничим запись, разберём аварийный запрет и вернём данные компьютеру."
    }
  ],
  "steps": [
    {
      "id": "overview-01",
      "kind": "main",
      "chapterId": "overview-whole",
      "title": "MIRA: полный путь от команды до результата",
      "sceneId": "system",
      "nodeIds": [
        "power",
        "host",
        "links",
        "fpga",
        "drive",
        "matrix",
        "readout"
      ],
      "edgeIds": [
        "host_links",
        "links_fpga",
        "fpga_drive",
        "drive_matrix",
        "matrix_readout",
        "readout_fpga"
      ],
      "lead": "Плата связывает цифровое управление с реальным электрическим опытом.",
      "body": [
        "Устройство решает две связанные задачи. Сначала питание подготавливает узлы к работе. Затем команда компьютера проходит через цифровую часть, превращается в электрическое воздействие и поступает к мемристорной матрице — исследуемому устройству, состояние которого можно измерять и изменять.",
        "Отклик матрицы проходит обратный путь: измерительная часть превращает его в числа, а интерфейс возвращает их компьютеру. Проследим этот круг; защита и контроль питания будут сопровождать его на каждом этапе."
      ],
      "path": [
        "Питание",
        "Команда",
        "Воздействие",
        "Измерение",
        "Результат"
      ],
      "why": "Важно видеть и полезный сигнал, и условия, при которых разрешена работа.",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e",
          "control_net_8543c7028353",
          "control_net_8baeadc9d1f8",
          "control_net_7f616706cf93",
          "control_net_2889fbee2814",
          "control_net_90accaec6322",
          "control_net_bae01a82acc2",
          "control_net_fd8710ab620d",
          "control_net_43c57dc0fd8c",
          "control_net_8d6768741a17",
          "control_net_d7baf045ad36",
          "control_net_beae8f10af57",
          "control_net_08cafd4a06b1",
          "control_net_d2e352168d81",
          "control_net_339e997cde5d",
          "control_net_78c06670fbe2",
          "control_net_ecfae2e6bc3f",
          "control_net_de495400ab4d",
          "control_net_a25f83c5766f",
          "control_net_957e25b7b62b",
          "control_net_6c5bac16ddbe",
          "control_net_b00353d4bc57",
          "control_net_a555576805ce",
          "control_net_795fcecf8d80",
          "control_net_5357ea4931e2",
          "control_net_e3f04569205d",
          "control_net_d3cbff2509ef",
          "control_net_aa72e4d066e3",
          "control_net_9a9cf021ea69",
          "control_net_8ae61bd6427a",
          "control_net_c2ddd031305c",
          "control_net_9a9241c5281b",
          "control_net_a21df6263907",
          "control_net_728a06da1431",
          "control_net_8247058ba4d6",
          "control_net_0b4fec439a85",
          "control_net_053310f9940f",
          "control_net_6a631d5bc074",
          "control_net_05e96fc05120",
          "control_net_c3b76f2a4b40",
          "control_net_d65f00f0a2d4",
          "control_net_3be7162ce896",
          "control_net_3d36f9d91f43",
          "control_net_a1f3e5011080",
          "control_net_b97070122e98"
        ]
      }
    },
    {
      "id": "overview-02",
      "kind": "main",
      "chapterId": "overview-power",
      "title": "Внешние 24 В проходят входную защиту",
      "sceneId": "power-input",
      "nodeIds": [
        "sheet100",
        "sheet200",
        "sheet300",
        "sheet400"
      ],
      "edgeIds": [
        "sheet300_sheet400"
      ],
      "lead": "Вход подготавливает питание для последующих преобразователей.",
      "body": [
        "Внешний источник подключается к разъёму питания. Дальше расположены предохранитель, электронная защита и фильтрация. Эти участки ограничивают последствия неисправности, позволяют отключить нагрузку и уменьшают помехи, распространяющиеся по питающей линии.",
        "После этой цепочки питание попадает на общую защищённую шину. От неё работают последующие источники напряжений. Поэтому на общей карте перед разветвлением стоит единый входной тракт: каждая нагрузка питается через подготовленный путь."
      ],
      "path": [
        "Источник 24 В",
        "Защита",
        "Фильтр",
        "Общая питающая шина"
      ],
      "why": "Неисправность на входе затрагивает сразу всё устройство.",
      "source": {
        "sheetId": "power_POWER_INPUT",
        "sheetName": "POWER_INPUT",
        "board": "power",
        "netIds": [
          "power_net_a837894762cd"
        ]
      }
    },
    {
      "id": "overview-03",
      "kind": "main",
      "chapterId": "overview-power",
      "title": "Дежурная часть запускается раньше нагрузки",
      "sceneId": "power_500_AON_3V3_BUCK",
      "nodeIds": [
        "input",
        "convert",
        "filter",
        "output"
      ],
      "edgeIds": [
        "input_convert",
        "convert_filter",
        "filter_output"
      ],
      "lead": "Сначала нужно запитать тот узел, который будет управлять остальными.",
      "body": [
        "От защищённой шины отдельный преобразователь создаёт дежурное питание 3,3 В. Оно питает контрольную часть до включения основных потребителей. Преобразователь поддерживает выходной уровень, а фильтрация сглаживает его пульсации.",
        "Так появляется возможность сначала оценить исходное состояние, а затем выдавать команды другим источникам. Здесь важна последовательность: цифровая команда запуска и реальное появление напряжения — разные события. Дежурная часть обеспечивает управление этим переходом."
      ],
      "path": [
        "Защищённые 24 В",
        "Дежурные 3,3 В",
        "Контроль запуска"
      ],
      "why": "Контроль должен быть готов раньше управляемых им нагрузок.",
      "source": {
        "sheetId": "power_500_AON_3V3_BUCK",
        "sheetName": "500_AON_3V3_BUCK",
        "board": "power",
        "netIds": [
          "power_net_46d0d8d77ef1",
          "power_net_67006db669b3",
          "power_net_bfbd5cdcdcfd",
          "power_net_c7b4c78d37bb",
          "power_net_478d89e5a433",
          "power_net_abd71ae65884"
        ]
      }
    },
    {
      "id": "overview-04",
      "kind": "main",
      "chapterId": "overview-power",
      "title": "Контроллер питания организует запуск",
      "sceneId": "power",
      "nodeIds": [
        "primary",
        "supervisor",
        "monitor"
      ],
      "edgeIds": [
        "primary_supervisor",
        "supervisor_primary",
        "monitor_supervisor"
      ],
      "lead": "У системы питания есть собственная логика управления и обратная связь.",
      "body": [
        "Контроллер питания получает дежурное напряжение и формирует последовательность команд для остальных ветвей. К нему также поступают сведения о состоянии источников. Контур замкнут: команда уходит к преобразователям, информация об их состоянии возвращается обратно.",
        "Рядом работают аппаратные разрешения и сторожевые цепи. Они связывают включение нагрузки с допустимыми условиями. Поэтому наличие программы ещё не означает, что любое напряжение или воздействие разрешено в каждый момент времени."
      ],
      "path": [
        "Дежурное питание",
        "Контроллер",
        "Команды включения",
        "Обратная связь"
      ],
      "why": "Последовательность запуска и проверка условий работают вместе.",
      "source": {
        "sheetId": "power_POWER_SYSTEM",
        "sheetName": "POWER_SYSTEM",
        "board": "power",
        "netIds": [
          "power_net_67006db669b3",
          "power_net_6649c6cdd008",
          "power_net_9020238d369a",
          "power_net_7f7616523bf4",
          "power_net_35be90fefcdd",
          "power_net_afd79c7e6e58",
          "power_net_4aeb4892b398",
          "power_net_393e02135991",
          "power_net_f632ebdd7344"
        ]
      }
    },
    {
      "id": "overview-05",
      "kind": "main",
      "chapterId": "overview-power",
      "title": "Для разных задач создаются разные напряжения",
      "sceneId": "power",
      "nodeIds": [
        "primary",
        "secondary",
        "program",
        "supervisor"
      ],
      "edgeIds": [
        "primary_secondary",
        "primary_program",
        "supervisor_secondary",
        "supervisor_program"
      ],
      "lead": "Цифровая логика, аналоговая часть и запись требуют разных питающих ветвей.",
      "body": [
        "Основные преобразователи создают промежуточные напряжения. Отдельные ступени питают ядро и выводы ПЛИС, память, сетевой интерфейс и аналоговые узлы. Измерительные цепи получают малошумящее питание; усилителям также нужны положительная и отрицательная ветви.",
        "Питание записи проходит через собственные управляемые ключи. Их разрешение управляет подключением нагрузки. Одинаковый номинал напряжения у двух ветвей ещё не делает их одной цепью: у них разные потребители, шумовые требования и условия включения."
      ],
      "path": [
        "Основные источники",
        "Отдельные домены",
        "Цифровая и аналоговая нагрузка"
      ],
      "why": "Питание разделено по функции, условиям работы и требованиям к шуму.",
      "source": {
        "sheetId": "power_POWER_SYSTEM",
        "sheetName": "POWER_SYSTEM",
        "board": "power",
        "netIds": [
          "power_net_bbc855740138",
          "power_net_cd1e0a0c9a0e",
          "power_net_f5932d689562",
          "power_net_ae048a8edaa8",
          "power_net_664171b20ecf",
          "power_net_55bbd3deed41",
          "power_net_05ab23d96f3d",
          "power_net_0faf4b6ebbf5",
          "power_net_04b2f0a4c78b",
          "power_net_d07b46e16a3e",
          "power_net_3db57ce8c78a",
          "power_net_9693d69e08e6",
          "power_net_a18264aeba79",
          "power_net_c215e379dc64",
          "power_net_89bfaea42e83",
          "power_net_65bf7e1e53cf",
          "power_net_5a1f578d112a",
          "power_net_8828c890966d"
        ]
      }
    },
    {
      "id": "overview-06",
      "kind": "main",
      "chapterId": "overview-power",
      "title": "Готовность подтверждается измерением и разрешениями",
      "sceneId": "power",
      "nodeIds": [
        "secondary",
        "monitor",
        "supervisor",
        "program"
      ],
      "edgeIds": [
        "secondary_monitor",
        "monitor_supervisor",
        "supervisor_secondary",
        "supervisor_program"
      ],
      "lead": "Команду «включить» нужно сопоставить с фактическим состоянием устройства.",
      "body": [
        "Датчики наблюдают напряжения и токи питающих ветвей. Переключатели выбирают точки контроля, а подготовленные сигналы поступают к контроллеру. Управление получает сведения о состоянии ветвей после команды.",
        "Другие аппаратные цепи собирают признаки готовности и проверяют разрешения. Если необходимые условия не выполнены, дальнейшая работа должна оставаться запрещённой. Для рассказа достаточно этой связи: источники питают нагрузку, наблюдение возвращает состояние, а разрешение допускает следующий этап."
      ],
      "path": [
        "Выходы источников",
        "Измерение",
        "Проверка состояния",
        "Разрешение работы"
      ],
      "why": "Фактическая готовность важнее самого факта выдачи команды.",
      "source": {
        "sheetId": "power_POWER_SYSTEM",
        "sheetName": "POWER_SYSTEM",
        "board": "power",
        "netIds": [
          "power_net_ae048a8edaa8",
          "power_net_664171b20ecf",
          "power_net_55bbd3deed41",
          "power_net_05ab23d96f3d",
          "power_net_0faf4b6ebbf5",
          "power_net_04b2f0a4c78b",
          "power_net_d07b46e16a3e",
          "power_net_3db57ce8c78a",
          "power_net_9693d69e08e6",
          "power_net_0673bddb62dd",
          "power_net_710c162550a1",
          "power_net_68f62ae4eb87",
          "power_net_de6034a2bdb7",
          "power_net_217501fd4a1b",
          "power_net_d2e17a0e1422",
          "power_net_ca640db2f885",
          "power_net_df57fc034b72",
          "power_net_80ed0592af12",
          "power_net_e14830d3e0bb",
          "power_net_8165c7e0e80c",
          "power_net_006931c58e47",
          "power_net_072a5b0d730e",
          "power_net_92a8731620d4",
          "power_net_56f70873fed6",
          "power_net_493e78469ebd",
          "power_net_747203f7ea20",
          "power_net_0937e82a0391",
          "power_net_06b222f621c5",
          "power_net_bb20ea345245",
          "power_net_223314db53b0",
          "power_net_84769727a28d",
          "power_net_c5bc442d624e",
          "power_net_01417a8fa2e7",
          "power_net_a632dd3fa2a2",
          "power_net_071bab851593",
          "power_net_2f3224d5b90a",
          "power_net_5c97037182dc",
          "power_net_324fb6a46e24",
          "power_net_0b315650a930",
          "power_net_b8182397a510",
          "power_net_9ac6d4c8f874",
          "power_net_4aeb4892b398",
          "power_net_393e02135991",
          "power_net_f632ebdd7344",
          "power_net_89bfaea42e83",
          "power_net_65bf7e1e53cf",
          "power_net_5a1f578d112a",
          "power_net_8828c890966d"
        ]
      }
    },
    {
      "id": "overview-07",
      "kind": "main",
      "chapterId": "overview-control",
      "title": "Контроллер и ПЛИС делят задачи управления",
      "sceneId": "control",
      "nodeIds": [
        "host",
        "fpga"
      ],
      "edgeIds": [
        "host_fpga"
      ],
      "lead": "Программа координирует опыт, а цифровая логика согласует быстрые действия.",
      "body": [
        "Микроконтроллер STM32 — процессор, исполняющий программу управления. Он обеспечивает координацию сценария, работу с состоянием устройства и обмен с ПЛИС. Программе доступны память, тактирование и отладка.",
        "ПЛИС — программируемая логическая схема. Её конфигурация задаёт аппаратные связи между интерфейсами, управлением матрицей и приёмом отсчётов. Так программа задаёт сценарий, а аппаратные действия выполняются с согласованным временем."
      ],
      "path": [
        "Программа управления",
        "Обмен командами",
        "Аппаратные действия"
      ],
      "why": "Гибкое управление и точное время решают разные задачи.",
      "source": {
        "sheetId": "control_MIRA_Control",
        "sheetName": "MIRA_Control",
        "board": "control",
        "netIds": [
          "control_net_e7c041fd6c4f",
          "control_net_f9eaf352353a",
          "control_net_9aff4b2212a6",
          "control_net_e84839bbf71f",
          "control_net_625cef89ab64",
          "control_net_e8d1c7605faf",
          "control_net_cdd2b08d9db8",
          "control_net_028458bc6a66",
          "control_net_189baa4e46d2",
          "control_net_ff9ff859ce5e",
          "control_net_101ecb817b3a"
        ]
      }
    },
    {
      "id": "overview-08",
      "kind": "main",
      "chapterId": "overview-control",
      "title": "ПЛИС сначала загружает рабочую конфигурацию",
      "sceneId": "control_600_FPGA_CONFIGURATION_AND_XADC",
      "nodeIds": [
        "flash",
        "fpga",
        "recover"
      ],
      "edgeIds": [
        "flash_fpga_0",
        "recover_fpga_2"
      ],
      "lead": "После питания программируемой логике ещё нужно получить своё устройство.",
      "body": [
        "Конфигурационная память хранит описание работы ПЛИС. При загрузке этот поток настраивает внутреннюю логику и соединения. После конфигурации появляются предусмотренные интерфейсы и управляющие узлы; одной подачи питания для этого недостаточно.",
        "Для отладки предусмотрено подключение программатора. Также есть путь запроса повторной конфигурации от контроллера. Эти средства относятся к запуску и восстановлению цифровой части. Память конфигурации хранит аппаратное описание, а не результаты очередного измерения."
      ],
      "path": [
        "Память конфигурации",
        "Загрузка",
        "Рабочая логика ПЛИС"
      ],
      "why": "Конфигурация определяет, какой аппаратурой станет программируемая микросхема.",
      "source": {
        "sheetId": "control_600_FPGA_CONFIGURATION_AND_XADC",
        "sheetName": "600_FPGA_CONFIGURATION_AND_XADC",
        "board": "control",
        "netIds": [
          "control_net_52c8c7557923",
          "control_net_834296c71f70",
          "control_net_3591ba357658",
          "control_net_6bc6649476ec",
          "control_net_9e71347ab99c",
          "control_net_92af7290af48",
          "control_net_4701afd22aa9"
        ]
      }
    },
    {
      "id": "overview-09",
      "kind": "main",
      "chapterId": "overview-link",
      "title": "Компьютер передаёт параметры будущего опыта",
      "sceneId": "system",
      "nodeIds": [
        "host",
        "links",
        "fpga"
      ],
      "edgeIds": [
        "host_links",
        "links_fpga"
      ],
      "lead": "Начинается путь полезной команды от оператора к аппаратуре.",
      "body": [
        "На компьютере выбираются параметры: какое действие требуется, какие уровни нужно установить и какие измерения получить. По кабелю передаются цифровые данные. Напряжение воздействия на матрицу пока существует только как числовое задание.",
        "Интерфейс доставляет данные в цифровую часть платы. Дальше логика и программа должны разобрать запрос, подготовить источники и выбрать путь сигнала. На схеме предусмотрены два внешних канала связи — Ethernet и USB; рассмотрим оба пути."
      ],
      "path": [
        "Оператор",
        "Цифровой запрос",
        "Интерфейс",
        "Управление опытом"
      ],
      "why": "Передача команды и выполнение электрической операции — отдельные этапы.",
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e"
        ]
      }
    },
    {
      "id": "overview-10",
      "kind": "main",
      "chapterId": "overview-link",
      "title": "Ethernet переводит сигнал кабеля в цифровые данные",
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "nodeIds": [
        "connector",
        "isolation",
        "phy",
        "fpga"
      ],
      "edgeIds": [
        "connector_isolation_0",
        "isolation_phy_1",
        "phy_fpga_2"
      ],
      "lead": "Между сетевым разъёмом и ПЛИС расположены развязка и приёмопередатчик.",
      "body": [
        "Разъём принимает электрический сигнал сетевого кабеля. Трансформатор обеспечивает гальваническую развязку: информация проходит, а прямое электрическое соединение сторон разделено. Далее сигнал поступает к микросхеме физического интерфейса Ethernet.",
        "Эта микросхема восстанавливает цифровые данные и передаёт их ПЛИС. Обработка сетевых кадров, адресов и команд относится уже к цифровой логике и программному обеспечению. Сама микросхема возле разъёма не решает, какой опыт нужно выполнить с матрицей."
      ],
      "path": [
        "Кабель",
        "Развязка",
        "Приёмопередатчик Ethernet",
        "Цифровая логика"
      ],
      "why": "Физическая передача и смысл команды обрабатываются на разных уровнях.",
      "source": {
        "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "sheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_eb689a40d9d8",
          "control_net_a0be4ca78cf4",
          "control_net_783e9d027a80",
          "control_net_e72d81f71514",
          "control_net_75386a9fba9e",
          "control_net_40965b12abcc",
          "control_net_46a7e4543439",
          "control_net_a5f76ff3f3d9",
          "control_net_e227481650c4",
          "control_net_2b9e82ff1f9a",
          "control_net_b7668147936d",
          "control_net_f14d9beef5b0",
          "control_net_bdf65fc018f7",
          "control_net_c7652af8ac7f",
          "control_net_c06d53ceafd7",
          "control_net_c72c6f1d768f",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_cc90c66f0af7",
          "control_net_5682aa39e237",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc"
        ]
      }
    },
    {
      "id": "overview-11",
      "kind": "main",
      "chapterId": "overview-link",
      "title": "USB преобразуется в удобный цифровой обмен",
      "sceneId": "control_700_FPGA_USB3_FIFO_INTERFACE",
      "nodeIds": [
        "connector",
        "protection",
        "orientation",
        "bridge",
        "fpga"
      ],
      "edgeIds": [
        "connector_orientation",
        "orientation_bridge",
        "bridge_fpga"
      ],
      "lead": "Другой кабель ведёт к той же цифровой части устройства.",
      "body": [
        "Вход USB проходит через защиту и узел, учитывающий ориентацию разъёма. Затем микросхема моста переводит обмен USB в параллельный интерфейс для ПЛИС. Буфер передаёт поток словами, а сигналы управления показывают готовность сторон к обмену.",
        "Мост меняет способ передачи данных. Входящий запрос должен попасть в управление опытом, исходящие измерения — вернуться компьютеру. Наличие аппаратного канала создаёт основу для обмена; формат сообщений задаётся цифровой частью и программой."
      ],
      "path": [
        "Кабель USB",
        "Подготовка соединения",
        "Мост USB",
        "ПЛИС"
      ],
      "why": "Мост согласует внешний протокол с аппаратным интерфейсом платы.",
      "source": {
        "sheetId": "control_700_FPGA_USB3_FIFO_INTERFACE",
        "sheetName": "700_FPGA_USB3_FIFO_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_8a18244b5094",
          "control_net_cd5767d1244a",
          "control_net_4a77ae0a5e9e",
          "control_net_81e7ad5ba413",
          "control_net_dfb816a62c27",
          "control_net_7293b201db23",
          "control_net_c17cad38b3b9",
          "control_net_bb9ef2893216",
          "control_net_3e4cca7b1d3b",
          "control_net_9cc415b59d1d",
          "control_net_3fea9522f27f",
          "control_net_4e0bed631879",
          "control_net_ee1064f82d57",
          "control_net_90ccce2c8039",
          "control_net_4ab70b5a5d2e",
          "control_net_5d12a42f13a7",
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_0aa940b07213",
          "control_net_5f4121b0067b",
          "control_net_45ad74d728ee",
          "control_net_34a5458782a9",
          "control_net_a0ccf5710062",
          "control_net_77550a265a38",
          "control_net_95229f960617",
          "control_net_76c093c7625c",
          "control_net_0c2767ceedce",
          "control_net_e4fd6a071815",
          "control_net_81564ca10d04",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2"
        ]
      }
    },
    {
      "id": "overview-12",
      "kind": "main",
      "chapterId": "overview-link",
      "title": "Контроллер и ПЛИС обмениваются командами и состоянием",
      "sceneId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
      "nodeIds": [
        "management",
        "fpga"
      ],
      "edgeIds": [
        "management_fpga_5"
      ],
      "lead": "Внешний запрос нужно согласовать с внутренней последовательностью работы.",
      "body": [
        "Контроллер связан с ПЛИС отдельным цифровым интерфейсом. По нему программа может передавать управляющую информацию и получать её состояние. Буферные элементы подготавливают сигналы между узлами, а линии управления задают порядок обмена.",
        "Здесь сходятся две стороны опыта: что хочет выполнить программа и что готова сделать аппаратная логика. Дальше команды расходятся к источникам напряжений, переключателям и измерению. Поэтому связь контроллера с ПЛИС — часть общего цикла управления, а не ещё один внешний кабель."
      ],
      "path": [
        "Программа STM32",
        "Внутренний интерфейс",
        "Логика ПЛИС",
        "Аппаратные узлы"
      ],
      "why": "Команда должна учитывать состояние и готовность исполнителя.",
      "source": {
        "sheetId": "control_900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "sheetName": "900_FPGA_ETHERNET_AND_MCU_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_028458bc6a66",
          "control_net_189baa4e46d2",
          "control_net_d586ee5fe950",
          "control_net_ff9ff859ce5e",
          "control_net_101ecb817b3a",
          "control_net_b754ba5a60da"
        ]
      }
    },
    {
      "id": "overview-13",
      "kind": "main",
      "chapterId": "overview-matrix",
      "title": "Числа становятся напряжениями для 32 линий",
      "sceneId": "control_1000_DAC_BL0_31_AND_BUFFERS",
      "nodeIds": [
        "dac0",
        "buffer0"
      ],
      "edgeIds": [
        "dac0_buffer0_0"
      ],
      "lead": "Цифроаналоговые преобразователи создают реальные уровни воздействия.",
      "body": [
        "ПЛИС передаёт числовые уставки в цифроаналоговые преобразователи — ЦАП. Для основных битовых линий предусмотрены 32 канала. Каналы задают разные уровни, поэтому линии могут получать разные напряжения в рамках выбранной операции.",
        "За преобразователями стоят буферные усилители. Они передают заданные уровни дальше с подходящими условиями нагрузки. Сам ЦАП ещё не выбирает ячейку матрицы: его выход сначала должен пройти через управляемые соединения, которые направят воздействие к нужным линиям."
      ],
      "path": [
        "Числовые уставки",
        "ЦАП",
        "Буферные усилители",
        "Входы переключателей"
      ],
      "why": "Величина воздействия задаётся отдельно от выбора его маршрута.",
      "source": {
        "sheetId": "control_1000_DAC_BL0_31_AND_BUFFERS",
        "sheetName": "1000_DAC_BL0_31_AND_BUFFERS",
        "board": "control",
        "netIds": [
          "control_net_47af455af6dc",
          "control_net_b90f47fe887d",
          "control_net_a0db919ee83d",
          "control_net_d6647a4628c8",
          "control_net_8be92a53ce8b",
          "control_net_78ba9d6b88dd",
          "control_net_e1f6195edd21",
          "control_net_561ae5f25bce"
        ]
      }
    },
    {
      "id": "overview-14",
      "kind": "main",
      "chapterId": "overview-matrix",
      "title": "Чтение и изменение состояния используют свои источники",
      "sceneId": "control_1100_DAC_SERVICE_AND_FORMING",
      "nodeIds": [
        "commands",
        "buffer",
        "forming",
        "formbuffer"
      ],
      "edgeIds": [
        "commands_buffer",
        "forming_formbuffer"
      ],
      "lead": "Кроме основных линий предусмотрены отдельные служебные уровни.",
      "body": [
        "Служебные преобразователи задают напряжения для чтения, установки и сброса состояния. Отдельный канал предусмотрен для формовки — начальной подготовки мемристора. Задания через отдельные усилители поступают к узлам выбора источника.",
        "Так один экспериментальный тракт может получать разные воздействия для разных задач. Источник создаёт нужный уровень, переключатели определяют его направление, а управление задаёт длительность операции. Для изменения состояния также нужны ограничение тока и аппаратные разрешения; рассмотрим их после измерения."
      ],
      "path": [
        "Тип операции",
        "Служебная уставка",
        "Источник напряжения",
        "Выбор маршрута"
      ],
      "why": "Разные операции требуют разных уровней и условий воздействия.",
      "source": {
        "sheetId": "control_1100_DAC_SERVICE_AND_FORMING",
        "sheetName": "1100_DAC_SERVICE_AND_FORMING",
        "board": "control",
        "netIds": [
          "control_net_e7bd9de88b26",
          "control_net_5f3aa6ac02ea",
          "control_net_872644d0a844",
          "control_net_5c53c9973c60",
          "control_net_245f41faaafc",
          "control_net_c1240dda3ce7",
          "control_net_3c3ad73203dc",
          "control_net_a29863c03d26",
          "control_net_5980e068f72a"
        ]
      }
    },
    {
      "id": "overview-15",
      "kind": "main",
      "chapterId": "overview-matrix",
      "title": "Перед операцией фиксируются запрос и разрешения",
      "sceneId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
      "nodeIds": [
        "fpga",
        "capture",
        "compare",
        "permissions",
        "decode"
      ],
      "edgeIds": [
        "fpga_capture",
        "capture_compare",
        "compare_permissions",
        "permissions_decode"
      ],
      "lead": "Ключи должны выполнять одну согласованную команду.",
      "body": [
        "ПЛИС выдаёт запрос на работу с матрицей. Аппаратная часть фиксирует активный запрос, проверяет его согласованность и учитывает разрешающие условия. Только после этой проверки формируются управляющие сигналы для выбранного режима.",
        "Настройка и выполнение происходят последовательно. Если управляющие данные меняются во время активной операции, это должно быть замечено контрольной логикой. Поэтому путь к матрице включает проверку команды, а не только прямое включение ключа по одному сигналу."
      ],
      "path": [
        "Запрос ПЛИС",
        "Фиксация",
        "Проверка разрешений",
        "Выбор операции"
      ],
      "why": "Во время воздействия состояние управления должно оставаться согласованным.",
      "source": {
        "sheetId": "control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "sheetName": "1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS",
        "board": "control",
        "netIds": [
          "control_net_2690ba9f85c2",
          "control_net_1060da4e1062",
          "control_net_8e945f7df341",
          "control_net_103f84ec6132",
          "control_net_c6ecade8f839",
          "control_net_8e9184bc5c46",
          "control_net_ba2ab40384c6",
          "control_net_c254fca78b2c",
          "control_net_f16f12a0707d",
          "control_net_d095506d8145",
          "control_net_df16aaaa5404",
          "control_net_2a00cc654f3d",
          "control_net_5130997c4fe8",
          "control_net_5f9f5680becf",
          "control_net_6e69a2fb065e",
          "control_net_8e443662774e",
          "control_net_93d867935f6d",
          "control_net_942f92e36dcb",
          "control_net_c3b957dc2a05",
          "control_net_53c8d7c2e621",
          "control_net_68c0b1b9f3d9",
          "control_net_4cbb94b58c81",
          "control_net_5a48e06ad240",
          "control_net_11d0bca5a9c3",
          "control_net_5adbbaca70af",
          "control_net_5d5a8a88fb46",
          "control_net_3f65bb4e6c1b",
          "control_net_24511a425a2f",
          "control_net_558e432b5f50",
          "control_net_12757af1d119",
          "control_net_7a2e58dd0886",
          "control_net_b0ef82a04563",
          "control_net_b544695cd7b3",
          "control_net_49fde52ce0ed",
          "control_net_2e40141f478d",
          "control_net_87fe3b573357",
          "control_net_a263c7c6e291",
          "control_net_d846a1ae0de8",
          "control_net_0831bf7686e1",
          "control_net_390c067b3ead",
          "control_net_ae0baa487445",
          "control_net_4680bd4e9f98"
        ]
      }
    },
    {
      "id": "overview-16",
      "kind": "main",
      "chapterId": "overview-matrix",
      "title": "Ключи выбирают линии воздействия и измерения",
      "sceneId": "control-routing",
      "nodeIds": [
        "sheet1300",
        "sheet1400",
        "sheet1500",
        "sheet1700",
        "sheet1800"
      ],
      "edgeIds": [
        "sheet1300_sheet1400",
        "sheet1400_sheet1500",
        "sheet1400_sheet1700",
        "sheet1500_sheet1800",
        "sheet1700_sheet1800"
      ],
      "lead": "Матрицу окружает управляемая сеть электрических соединений.",
      "body": [
        "Последовательные регистры сохраняют состояние множества ключей. Конфигурация управляет битовыми линиями, выбором строк и обратными измерительными линиями. Цифровое управление разветвляется к группам переключателей вокруг разъёма матрицы.",
        "Битовые линии подводят подготовленные напряжения. Строковые драйверы задают состояние выбранных строк, а обратные линии связываются с измерением; неактивные линии имеют предусмотренные цепи фиксации. Поэтому выбор ячейки или группы определяется совместной настройкой нескольких участков, а не одним адресным проводом."
      ],
      "path": [
        "Сохранённая конфигурация",
        "Группы ключей",
        "Выбранные линии",
        "Матрица"
      ],
      "why": "Нужны одновременно путь воздействия и определённый обратный путь.",
      "source": {
        "sheetId": "control_MATRIX",
        "sheetName": "MATRIX",
        "board": "control",
        "netIds": [
          "control_net_57236d4b4e50",
          "control_net_70c03a238d66",
          "control_net_7e66df34c1cb",
          "control_net_e2ace5299f00",
          "control_net_f498b034d47c",
          "control_net_dfebfa8ce954",
          "control_net_8cec06d0a68e",
          "control_net_91367f0adb00",
          "control_net_4e889b41bce9",
          "control_net_4f58db14a2f0",
          "control_net_8ae298951006",
          "control_net_c7a227845fc4",
          "control_net_aa8081055225",
          "control_net_38aa1b871436",
          "control_net_30da3c89e6b0",
          "control_net_27e11deab85a",
          "control_net_77dec07465d1",
          "control_net_76168421ae64",
          "control_net_01c0ad0ef8f8",
          "control_net_5e01c47f5c29",
          "control_net_35c00105d395",
          "control_net_48fcc210d1f6",
          "control_net_31367ce75c40",
          "control_net_282ba042f616",
          "control_net_acd932993b7b",
          "control_net_2f56e21bf1c8",
          "control_net_e9062516eb43",
          "control_net_d24d5fdebd2d",
          "control_net_e542c28a3215",
          "control_net_c20b4b863473",
          "control_net_adcb6c1bfe2e",
          "control_net_2595b3f207c1",
          "control_net_3e8175ead30c",
          "control_net_699b10c0cb1f",
          "control_net_928a45524bd4",
          "control_net_51b3012894bb",
          "control_net_853be9b7ad24",
          "control_net_48cbd08d5e88",
          "control_net_5e93332cd041",
          "control_net_45c19501bad5",
          "control_net_db3c5d849c82",
          "control_net_37fa60099550",
          "control_net_b211580c8101",
          "control_net_4aefa7bda0e0",
          "control_net_2bbd0dc06c6f",
          "control_net_c8a58330532e",
          "control_net_24fd3915e934",
          "control_net_a3db8189ec60",
          "control_net_287cfdf7ef3f",
          "control_net_ac7e9e00c8b3",
          "control_net_42dd32d2dba8",
          "control_net_ad6ab5928142",
          "control_net_cc7e68c63366",
          "control_net_c771f664cff1",
          "control_net_d948d4dd3369",
          "control_net_fbc93a9a1f13",
          "control_net_bb256500c151",
          "control_net_724ff3a3348c",
          "control_net_323da0f3bc1f",
          "control_net_39c83bb6d20e",
          "control_net_dcf3a56694f7",
          "control_net_a275f9d9677f",
          "control_net_aad969376bf0",
          "control_net_e85cee5f43f2",
          "control_net_410ce51ce77b",
          "control_net_5b7588c91934",
          "control_net_96843655892a",
          "control_net_ef57e67af6ee",
          "control_net_a38212b18dab",
          "control_net_cb9a53bc7e2d",
          "control_net_b1a7be433721",
          "control_net_5a6f03bbf06c",
          "control_net_f237bfeb4d31",
          "control_net_7deb95e626ac",
          "control_net_dee259c78870",
          "control_net_30db039e0318",
          "control_net_538bdbb480c1",
          "control_net_9aa6ed5fa484",
          "control_net_af268a134ce7",
          "control_net_2661b7e1d1d8",
          "control_net_7443657d6bc7",
          "control_net_8c1f7a16a91f",
          "control_net_9037a6d55684",
          "control_net_e59cadbe90ef",
          "control_net_77eb74275447",
          "control_net_331bcbe5832b",
          "control_net_da64d12ab5ef",
          "control_net_668f023fd21c",
          "control_net_15a5f03664b6",
          "control_net_0066c578f4fd",
          "control_net_ae5aa8c25d68",
          "control_net_76481426c5c9",
          "control_net_36b8e2744fa2",
          "control_net_06c41da37048",
          "control_net_093450c5090e",
          "control_net_a3c1624fed4f",
          "control_net_6597f27cfc2b",
          "control_net_52153a3ca99d",
          "control_net_45ab5f0aea68",
          "control_net_09be2b97e593",
          "control_net_1f62e25a43f4",
          "control_net_6cd7e17461df",
          "control_net_582519679d90",
          "control_net_03726fa80526",
          "control_net_18924996523a",
          "control_net_86b7951f0b9b",
          "control_net_6f8884418f43",
          "control_net_be1982fe6067",
          "control_net_b2b91481bc2e",
          "control_net_a335d291d1da",
          "control_net_df58d9efe6ea",
          "control_net_c04b6da19edd",
          "control_net_c494e5a21fb7",
          "control_net_5ef23046b636",
          "control_net_747cc492238d",
          "control_net_945cddbc767f",
          "control_net_3762f1a58fed",
          "control_net_b0ea7c0c27c3",
          "control_net_edac321adbf1",
          "control_net_5212ff00c1ac",
          "control_net_3c196a06fe86",
          "control_net_d380ae123eb3",
          "control_net_79947d226d73",
          "control_net_fca0e6b6f6af",
          "control_net_e8ccb5161adb",
          "control_net_072af1a28ea6",
          "control_net_e4379a2b0f61",
          "control_net_919f25939ba9",
          "control_net_d0ee9c0888fb",
          "control_net_c73ef0628409",
          "control_net_2e40141f478d",
          "control_net_f05b5740e1a9",
          "control_net_770516324e4c",
          "control_net_671137df6d42",
          "control_net_0831bf7686e1"
        ]
      }
    },
    {
      "id": "overview-17",
      "kind": "main",
      "chapterId": "overview-matrix",
      "title": "Выбираются источник, группа линий и полярность",
      "sceneId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
      "nodeIds": [
        "source",
        "bank",
        "polarity",
        "return"
      ],
      "edgeIds": [
        "source_bank",
        "bank_polarity",
        "polarity_return"
      ],
      "lead": "Служебное воздействие должно попасть на правильную сторону матрицы.",
      "body": [
        "Один узел выбирает служебный источник. Следующий подключает нужную группу битовых линий, затем определяется полярность воздействия. Подготовленные уровни используются для разных операций без отдельного источника на каждый путь.",
        "Важен возвратный путь: электрическая операция требует замкнутой цепи. Схема также связывает переключение режима с состоянием регулятора. Здесь хорошо видно отличие уставки от реального подключения: правильное напряжение становится полезным только при правильной коммутации."
      ],
      "path": [
        "Источник",
        "Группа линий",
        "Полярность",
        "Возвратный путь"
      ],
      "why": "Маршрут определяет, где и в каком направлении действует напряжение.",
      "source": {
        "sheetId": "control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "sheetName": "1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING",
        "board": "control",
        "netIds": [
          "control_net_209d9624cc4d",
          "control_net_2c4dffd5842a",
          "control_net_45e2821ea470"
        ]
      }
    },
    {
      "id": "overview-18",
      "kind": "main",
      "chapterId": "overview-matrix",
      "title": "Разъём соединяет плату с матрицей",
      "sceneId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
      "nodeIds": [
        "socket",
        "bias"
      ],
      "edgeIds": [
        "socket_bias"
      ],
      "lead": "Разъём объединяет линии воздействия, выбора и электрического отклика.",
      "body": [
        "От переключателей сигналы доходят до разъёма экспериментальной матрицы. На этой границе сходятся битовые, строковые и обратные линии. Дополнительные цепи адаптера задают предусмотренные условия смещения для подключённой структуры.",
        "Сама матрица отвечает на приложенное воздействие электрическим током. Величина зависит от её состояния и режима. Поэтому матрица связана сразу с двумя задачами платы: подать управляемый сигнал и отвести отклик в измерительный тракт."
      ],
      "path": [
        "Подготовленные линии",
        "Разъём матрицы",
        "Мемристорная структура",
        "Электрический отклик"
      ],
      "why": "На этой границе подготовленное воздействие встречается с исследуемым устройством.",
      "source": {
        "sheetId": "control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "sheetName": "1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS",
        "board": "control",
        "netIds": [
          "control_net_6380a00471f5",
          "control_net_b538393eaff5"
        ]
      }
    },
    {
      "id": "overview-19",
      "kind": "main",
      "chapterId": "overview-readout",
      "title": "Малый ток превращается в измеряемое напряжение",
      "sceneId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
      "nodeIds": [
        "current",
        "range",
        "monitor",
        "buffer"
      ],
      "edgeIds": [
        "current_range",
        "current_monitor",
        "monitor_buffer"
      ],
      "lead": "Измерительному преобразователю нужно подготовить электрический отклик.",
      "body": [
        "Ток матрицы поступает на специальный усилитель, преобразующий ток в напряжение. Это трансимпедансный усилитель. Переключаемая обратная связь позволяет выбирать чувствительность: одинаковый ток может давать разный выходной уровень в зависимости от диапазона.",
        "Затем селектор выбирает сигнал для наблюдения и измерения. Буфер помогает передать выбранный уровень, меньше нагружая исходную точку. Здесь ещё нет цифрового результата: аналоговый сигнал только приводится к форме, с которой сможет работать следующая ступень."
      ],
      "path": [
        "Ток матрицы",
        "Преобразование в напряжение",
        "Выбор сигнала",
        "Буфер"
      ],
      "why": "Подготовка сигнала определяет пригодный диапазон последующего измерения.",
      "source": {
        "sheetId": "control_1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "sheetName": "1900_ADC_TIA_AND_MONITOR_SELECTOR",
        "board": "control",
        "netIds": [
          "control_net_d65f00f0a2d4",
          "control_net_f993730bd850",
          "control_net_fc57b8202dba",
          "control_net_7eb34b3468da"
        ]
      }
    },
    {
      "id": "overview-20",
      "kind": "main",
      "chapterId": "overview-readout",
      "title": "АЦП сравнивает подготовленный сигнал с опорой",
      "sceneId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
      "nodeIds": [
        "reference",
        "monitor",
        "differential",
        "adc"
      ],
      "edgeIds": [
        "monitor_differential",
        "differential_adc",
        "reference_adc"
      ],
      "lead": "Аналого-цифровой преобразователь превращает напряжение в цифровой отсчёт.",
      "body": [
        "Перед преобразователем усилитель подготавливает дифференциальный вход: полезный сигнал передаётся парой связанных напряжений. Рядом работает источник опорного уровня. Он задаёт масштаб, относительно которого аналоговый вход превращается в числовое значение.",
        "Сам аналого-цифровой преобразователь — АЦП — выдаёт отсчёты цифровой части. На качество измерения влияют также предыдущий усилитель, опорное напряжение и питание. На диаграмме эти обеспечивающие ветви подходят к тому же измерительному узлу."
      ],
      "path": [
        "Подготовленный сигнал",
        "Входной усилитель",
        "АЦП и опора",
        "Цифровой отсчёт"
      ],
      "why": "Число имеет смысл только вместе с устойчивым масштабом измерения.",
      "source": {
        "sheetId": "control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "sheetName": "2000_ADC_CONVERTER_AND_PRECISION_REFERENCES",
        "board": "control",
        "netIds": [
          "control_net_18acc164b68f",
          "control_net_a636afc1774d",
          "control_net_87a4861c654c",
          "control_net_d96556e65ebd"
        ]
      }
    },
    {
      "id": "overview-21",
      "kind": "main",
      "chapterId": "overview-readout",
      "title": "Память помогает согласовать сбор и передачу данных",
      "sceneId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
      "nodeIds": [
        "clock",
        "fpga",
        "memory"
      ],
      "edgeIds": [
        "clock_fpga_0",
        "fpga_memory_1",
        "fpga_memory_2"
      ],
      "lead": "Быстрое измерение и передача по кабелю не обязаны совпадать по времени.",
      "body": [
        "Для приёма отсчётов предусмотрена цифровая логика, а внешнюю память можно использовать как временный буфер потока. На этой диаграмме показаны отдельные линии данных, адресов и команд между ПЛИС и памятью. Так приём измерений можно согласовать с дальнейшей обработкой и выдачей.",
        "Для согласованной работы предусмотрен опорный тактовый источник: он задаёт временную основу цифровых действий. Рабочая память отличается от конфигурационной. Первая служит обмену данными, вторая хранит загружаемое при запуске описание аппаратуры."
      ],
      "path": [
        "Принятые отсчёты",
        "Логика сбора",
        "Рабочая память",
        "Дальнейшая передача"
      ],
      "why": "Буфер разделяет темп получения данных и темп их передачи.",
      "source": {
        "sheetId": "control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "sheetName": "800_FPGA_DDR3L_AND_REFERENCE_CLOCK",
        "board": "control",
        "netIds": [
          "control_net_c31eb8fe07d3",
          "control_net_d44f364a5830",
          "control_net_3bfe72ccfc41",
          "control_net_21a5e9f13f7f",
          "control_net_58af204d8c23",
          "control_net_cccff17550b9",
          "control_net_f4bfe5cdab56",
          "control_net_4bb6a512cc3a",
          "control_net_19bcc72c5488",
          "control_net_185955b3a706",
          "control_net_d109bb25230c",
          "control_net_d9ef0a17e785",
          "control_net_fd2bad63a67c",
          "control_net_bb3aaa71ba05",
          "control_net_907e4adf7ca2",
          "control_net_ebaa690e703b",
          "control_net_92d89f9df56c",
          "control_net_c4d0ccc3d16d",
          "control_net_5220b4a56b5c",
          "control_net_d7ba445b9916",
          "control_net_395f29bc0592",
          "control_net_be534772f175",
          "control_net_42df6ae20837",
          "control_net_075227a69d18",
          "control_net_707df60aeb98",
          "control_net_abae69816039",
          "control_net_4baca15034bf",
          "control_net_4143ff0aef6d",
          "control_net_3ddfecb0df47",
          "control_net_1d61ccb9d017",
          "control_net_6943e9712d9c",
          "control_net_6dc2bebc3e2e",
          "control_net_ac8599a8c0cd",
          "control_net_c5d6e41ef012",
          "control_net_49b164ada644",
          "control_net_63a08f54a8af",
          "control_net_a46672b578ec",
          "control_net_85a84369e22a",
          "control_net_010b6b6f67c9",
          "control_net_d514c816e952",
          "control_net_3a2594a1e1f9",
          "control_net_9bc7997904a8",
          "control_net_6e031edce63d",
          "control_net_17b46c5249cb",
          "control_net_4ff8255e049a",
          "control_net_18e1c9509d79",
          "control_net_d2bff6eceb03",
          "control_net_dc796dddd274",
          "control_net_184f5bb728b0",
          "control_net_0065f370787e",
          "control_net_710e1e095743",
          "control_net_3a720de9ef0a"
        ]
      }
    },
    {
      "id": "overview-22",
      "kind": "main",
      "chapterId": "overview-safety",
      "title": "Запись регулируется по напряжению и току",
      "sceneId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
      "nodeIds": [
        "commands",
        "sense",
        "control",
        "drive"
      ],
      "edgeIds": [
        "commands_control",
        "sense_control",
        "control_drive"
      ],
      "lead": "Изменение состояния матрицы требует контроля самого воздействия.",
      "body": [
        "При записи задаются источник и маршрут. Узел регулирования получает заданные уровни и сигнал измерения тока. Обратная связь управляет выходным каскадом для соблюдения предусмотренных ограничений.",
        "Ограничение тока помогает не превратить нужную операцию в неконтролируемую нагрузку. Параметры задаёт управление, но допустимые значения и длительности должны соответствовать подключённой матрице. Поэтому этот участок расположен рядом с основным аналоговым трактом и аппаратными цепями аварийного запрета."
      ],
      "path": [
        "Заданные уровни",
        "Измеренный ток",
        "Регулятор",
        "Ограниченное воздействие"
      ],
      "why": "При изменении сопротивления матрицы ток тоже меняется.",
      "source": {
        "sheetId": "control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "sheetName": "2100_PROTECTION_WRITE_CURRENT_COMPLIANCE",
        "board": "control",
        "netIds": [
          "control_net_87568f65b103",
          "control_net_ee356dd4a609",
          "control_net_5b5c009b1508",
          "control_net_81a816b03060",
          "control_net_edfd1164669d",
          "control_net_13ff4635cb1b"
        ]
      }
    },
    {
      "id": "overview-23",
      "kind": "main",
      "chapterId": "overview-safety",
      "title": "Аппаратная защита может остановить воздействие",
      "sceneId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
      "nodeIds": [
        "compare",
        "qualify",
        "remember",
        "inhibit"
      ],
      "edgeIds": [
        "compare_qualify",
        "qualify_remember",
        "remember_inhibit"
      ],
      "lead": "Опасное состояние должно влиять на разрешение работы напрямую.",
      "body": [
        "Сигналы контроля поступают к схемам сравнения и проверки условий. При срабатывании формируется аварийное состояние, которое запоминается аппаратной частью. Далее сигнал запрета снимает разрешение на продолжение воздействия и передаёт сведения о неисправности другим узлам.",
        "Это самостоятельный аппаратный путь. Управляющая программа может получить состояние и организовать восстановление, но аварийный запрет формируется аппаратными цепями. Здесь защита связывает измерение условий с возможностью отключить опасный режим."
      ],
      "path": [
        "Нарушение условия",
        "Проверка",
        "Фиксация аварии",
        "Запрет воздействия"
      ],
      "why": "Информация об аварии и прекращение воздействия — связанные, но разные действия.",
      "source": {
        "sheetId": "control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "sheetName": "2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE",
        "board": "control",
        "netIds": [
          "control_net_7b06e5d6a4d9",
          "control_net_9269f101a22a",
          "control_net_d44a94d9b4fd"
        ]
      }
    },
    {
      "id": "overview-24",
      "kind": "main",
      "chapterId": "overview-safety",
      "title": "Результат возвращается компьютеру, цикл замыкается",
      "sceneId": "system",
      "nodeIds": [
        "power",
        "mcu",
        "fpga",
        "drive",
        "matrix",
        "readout",
        "links",
        "host"
      ],
      "edgeIds": [
        "mcu_fpga",
        "fpga_drive",
        "drive_matrix",
        "matrix_readout",
        "readout_fpga",
        "links_fpga",
        "host_links"
      ],
      "lead": "Теперь поток проходит от измерителя через цифровую часть к оператору.",
      "body": [
        "Цифровая часть получает отсчёты и состояние аппаратуры. Программа обмена должна связать эти данные с выполненным запросом и передать их через выбранный интерфейс. Подсветка идёт обратно от измерения через ПЛИС к компьютеру.",
        "Полученные данные можно отобразить, сохранить и использовать для следующего опыта. Цикл замкнулся: подготовить питание, принять задачу, задать напряжения, выбрать соединения, измерить ответ и вернуть результат. Условия запуска, ограничение тока и аварийная защита сопровождают этот путь."
      ],
      "path": [
        "Измерение",
        "Сбор данных",
        "Ethernet или USB",
        "Компьютер"
      ],
      "why": "Результат завершает одну операцию и может стать основой следующей.",
      "edgeDirections": {
        "links_fpga": "reverse",
        "host_links": "reverse"
      },
      "source": {
        "sheetId": null,
        "sheetName": "MIRA",
        "board": null,
        "netIds": [
          "control_net_a3e916588f1a",
          "control_net_55817c8282e0",
          "control_net_e44786acaa30",
          "control_net_a6a3fee83c7f",
          "control_net_ae2900dc7735",
          "control_net_708de604029c",
          "control_net_fb7db09ec7c3",
          "control_net_67008bb4401d",
          "control_net_38b9badc71df",
          "control_net_c39dacef288b",
          "control_net_93963a89c623",
          "control_net_080b1c6e773b",
          "control_net_c4ab00cc76ca",
          "control_net_f2e37bb320d3",
          "control_net_adca8d8efad4",
          "control_net_fb2e9fe80e2d",
          "control_net_2e89b83a9cd1",
          "control_net_01a067f231f5",
          "control_net_4a9a6e85b720",
          "control_net_08fb6faf20a6",
          "control_net_d35e6450ec18",
          "control_net_90cbd311d743",
          "control_net_fb90ec6e0d11",
          "control_net_b19700dbe4c4",
          "control_net_9a988f0c62fc",
          "control_net_f1f55e7a2140",
          "control_net_cbf683fe7e90",
          "control_net_6d1b692341f6",
          "control_net_ea07dd504c63",
          "control_net_edfa87483431",
          "control_net_576fff37cf3a",
          "control_net_88588227b7a2",
          "control_net_14e361774b31",
          "control_net_7a2cc9ad1aae",
          "control_net_842a1bd896e7",
          "control_net_cc90c66f0af7",
          "control_net_dbd1a2d49097",
          "control_net_f755d28cb131",
          "control_net_5682aa39e237",
          "control_net_af615c537cb1",
          "control_net_e773796fd1f6",
          "control_net_e39e2c0118dc",
          "control_net_bb18f917ddd6",
          "control_net_4b92eab01e5e",
          "control_net_9aff4b2212a6",
          "control_net_e84839bbf71f",
          "control_net_625cef89ab64",
          "control_net_e8d1c7605faf",
          "control_net_cdd2b08d9db8",
          "control_net_028458bc6a66",
          "control_net_189baa4e46d2",
          "control_net_ff9ff859ce5e",
          "control_net_101ecb817b3a",
          "control_net_8543c7028353",
          "control_net_8baeadc9d1f8",
          "control_net_7f616706cf93",
          "control_net_2889fbee2814",
          "control_net_90accaec6322",
          "control_net_bae01a82acc2",
          "control_net_fd8710ab620d",
          "control_net_43c57dc0fd8c",
          "control_net_8d6768741a17",
          "control_net_d7baf045ad36",
          "control_net_beae8f10af57",
          "control_net_08cafd4a06b1",
          "control_net_d2e352168d81",
          "control_net_339e997cde5d",
          "control_net_78c06670fbe2",
          "control_net_ecfae2e6bc3f",
          "control_net_de495400ab4d",
          "control_net_a25f83c5766f",
          "control_net_957e25b7b62b",
          "control_net_6c5bac16ddbe",
          "control_net_b00353d4bc57",
          "control_net_a555576805ce",
          "control_net_795fcecf8d80",
          "control_net_5357ea4931e2",
          "control_net_e3f04569205d",
          "control_net_d3cbff2509ef",
          "control_net_aa72e4d066e3",
          "control_net_9a9cf021ea69",
          "control_net_8ae61bd6427a",
          "control_net_c2ddd031305c",
          "control_net_9a9241c5281b",
          "control_net_a21df6263907",
          "control_net_728a06da1431",
          "control_net_8247058ba4d6",
          "control_net_0b4fec439a85",
          "control_net_053310f9940f",
          "control_net_6a631d5bc074",
          "control_net_05e96fc05120",
          "control_net_c3b76f2a4b40",
          "control_net_d65f00f0a2d4",
          "control_net_3be7162ce896",
          "control_net_3d36f9d91f43",
          "control_net_a1f3e5011080",
          "control_net_b97070122e98"
        ]
      }
    }
  ]
};
