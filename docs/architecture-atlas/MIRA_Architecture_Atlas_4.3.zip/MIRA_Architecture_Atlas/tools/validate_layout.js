#!/usr/bin/env node
/* Geometry checks against the real renderer and the last electrical snapshot. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),cp=require('child_process'),assert=require('assert');
const root=path.resolve(__dirname,'..'),ctx={window:{}},html=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g))vm.runInNewContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx,{filename:m[1]});
let renderer=fs.readFileSync(path.join(root,'js/functional.js'),'utf8');
renderer=renderer.replace('window.MiraFunctional={mount};','window.MiraFunctional={mount,routeEdge,portalGeometry,placeLabel,words};');
vm.runInNewContext(renderer,ctx);
vm.runInNewContext(renderer.slice(renderer.indexOf('function pointOnSegments('),renderer.indexOf('function tick(')),ctx);
const f=ctx.window.MIRA_FUNCTIONAL,geo=ctx.window.MiraFunctional;
const failures=[],labelWarnings=[],roles={},kinds={},sizes=new Set();let routeSegments=0,portals=0,sourceChecks=0;
const overlap=(a,b)=>a.x<b.x+b.w-0.01&&a.x+a.w>b.x+0.01&&a.y<b.y+b.h-0.01&&a.y+a.h>b.y+0.01;
function hits(a,b,r){
 if(Math.abs(a.x-b.x)<.001)return a.x>r.x+.001&&a.x<r.x+r.w-.001&&Math.max(a.y,b.y)>r.y+.001&&Math.min(a.y,b.y)<r.y+r.h-.001;
 if(Math.abs(a.y-b.y)<.001)return a.y>r.y+.001&&a.y<r.y+r.h-.001&&Math.max(a.x,b.x)>r.x+.001&&Math.min(a.x,b.x)<r.x+r.w-.001;
 return true;
}
function onSegment(p,a,b){return Math.abs(Math.hypot(p.x-a.x,p.y-a.y)+Math.hypot(p.x-b.x,p.y-b.y)-Math.hypot(b.x-a.x,b.y-a.y))<.001;}
for(const [id,s] of Object.entries(f.scenes)){
 const used=[],codes=new Set();kinds[s.layout?.kind||'unspecified']=(kinds[s.layout?.kind||'unspecified']||0)+1;
 for(const n of s.nodes){roles[n.layoutRole||'unspecified']=(roles[n.layoutRole||'unspecified']||0)+1;sizes.add(n.w+'x'+n.h);}
 for(let i=0;i<s.nodes.length;i++)for(let j=i+1;j<s.nodes.length;j++)if(overlap(s.nodes[i],s.nodes[j]))failures.push({type:'nodeOverlap',scene:id,nodes:[s.nodes[i].id,s.nodes[j].id]});
 for(const e of s.edges){
  const a=s.nodes.find(n=>n.id===e.from),b=s.nodes.find(n=>n.id===e.to);assert(a&&b);
  let segments;
  if(e.portal){
   portals++;if(codes.has(e.portal.code))failures.push({type:'duplicatePortalCode',scene:id,edge:e.id,code:e.portal.code});codes.add(e.portal.code);
   const p=geo.portalGeometry(a,b,e,s.nodes,used);assert(p.ends.length===2&&p.segments.length===2);assert((p.d.match(/M /g)||[]).length===2,'Portal must use two separate SVG path moves');
   for(const end of p.ends){for(const n of s.nodes)if(overlap(end.box,n))failures.push({type:'portalNodeOverlap',scene:id,edge:e.id,node:n.id,box:end.box});for(const prior of used)if(overlap(end.box,prior))failures.push({type:'portalLabelOverlap',scene:id,edge:e.id,box:end.box});used.push(end.box);}
   segments=p.segments;
   for(let t=0;t<=100;t++){const point=ctx.pointOnSegments(segments,t/100);if(!segments.some(ss=>ss.slice(1).some((b,i)=>onSegment(point,ss[i],b))))failures.push({type:'portalAnimationInGap',scene:id,edge:e.id,t});}
  }else{
   const peers=s.edges.filter(peer=>peer.from===e.from&&peer.to===e.to||peer.from===e.to&&peer.to===e.from),portOffset=(peers.findIndex(peer=>peer.id===e.id)-(peers.length-1)/2)*28;
   const points=geo.routeEdge(a,b,{...e,portOffset},s.nodes,0);segments=[points];
   const lines=((s.sheetId||s.kind==='module')&&e.labelLines?.length?e.labelLines:(s.kind==='section'?geo.words(e.shortLabel||e.label||'',14,3):[e.shortLabel||e.label||''])).filter(Boolean);
   if(lines.length){const w=Math.max(34,...lines.map(t=>String(t).length*7.4+24)),h=Math.max(24,lines.length*17+10);geo.placeLabel(points,w,h,s.nodes,used);const r=used.at(-1);for(const n of s.nodes)if(overlap(r,n))labelWarnings.push({type:'labelNodeOverlap',scene:id,edge:e.id,node:n.id});for(const prior of used.slice(0,-1))if(overlap(r,prior))labelWarnings.push({type:'labelLabelOverlap',scene:id,edge:e.id});}
  }
  for(const points of segments)for(let i=1;i<points.length;i++){routeSegments++;for(const n of s.nodes)if(n.id!==a.id&&n.id!==b.id&&hits(points[i-1],points[i],n))failures.push({type:'routeCrossesNode',scene:id,edge:e.id,node:n.id,segment:[points[i-1],points[i]]});}
 }
}
const baseline=process.argv.find(x=>x.endsWith('.zip'))||path.resolve(root,'../../MIRA_Architecture_Atlas_3.2.zip');
if(fs.existsSync(baseline)){
 const oldScripts=JSON.parse(cp.execFileSync('python3',['-c',`import zipfile,json,re,sys
with zipfile.ZipFile(sys.argv[1]) as z:
 prefix='MIRA_Architecture_Atlas/'
 html=z.read(prefix+'index.html').decode()
 files=re.findall(r'<script[^>]+src="(data/[^\\"]+)"',html)
 print(json.dumps([z.read(prefix+p).decode() for p in files]))`,baseline],{maxBuffer:40*1024*1024}));
 const old={window:{}};oldScripts.forEach(s=>vm.runInNewContext(s,old));const before=old.window.MIRA_FUNCTIONAL;
 assert.deepStrictEqual(Object.keys(f.scenes).sort(),Object.keys(before.scenes).sort(),'Scene IDs changed');
 const stable=(actual,original,keys,context)=>{for(const key of keys){assert.equal(JSON.stringify(actual[key]),JSON.stringify(original[key]),context+'/'+key);sourceChecks++;}};
 for(const [id,s] of Object.entries(before.scenes)){
  const now=f.scenes[id];assert.equal(JSON.stringify(now.nodes.map(n=>n.id).sort()),JSON.stringify(s.nodes.map(n=>n.id).sort()));assert.equal(JSON.stringify(now.edges.map(e=>e.id).sort()),JSON.stringify(s.edges.map(e=>e.id).sort()));
  for(const n of s.nodes){const current=now.nodes.find(v=>v.id===n.id);stable(current,n,Object.keys(n).filter(k=>!['x','y','w','h','fixed','layoutRole'].includes(k)),id+'/'+n.id);}
  for(const e of s.edges){const current=now.edges.find(v=>v.id===e.id);stable(current,e,Object.keys(e).filter(k=>!['fromSide','toSide','sourceSide','targetSide','waypoints','portOffset','portal'].includes(k)),id+'/'+e.id);}
 }
 assert.equal(JSON.stringify(f.scenarios),JSON.stringify(before.scenarios),'Story data changed');
 assert.equal(JSON.stringify(ctx.window.MIRA_ATLAS),JSON.stringify(old.window.MIRA_ATLAS),'Electrical source extraction changed');
}
const report={passed:failures.length===0&&labelWarnings.length===0,scenes:Object.keys(f.scenes).length,layoutKinds:kinds,visualRoles:roles,nodeSizes:sizes.size,portalEdges:portals,routeSegments,sourceIdentityChecks:sourceChecks,failures,labelWarnings};
console.log(JSON.stringify(report,null,2));
if(process.argv.includes('--report'))fs.writeFileSync(path.join(root,'data/layout-validation.json'),JSON.stringify(report,null,2)+'\n');
if(!report.passed)process.exitCode=1;
