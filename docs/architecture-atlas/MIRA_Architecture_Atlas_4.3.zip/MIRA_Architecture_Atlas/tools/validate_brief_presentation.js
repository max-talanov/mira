#!/usr/bin/env node
/* Check that the short story stays concise, traceable and understandable. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..'),ctx={window:{}},html=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g))vm.runInNewContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx,{filename:m[1]});
const {MIRA_BRIEF_TOUR:tour,MIRA_COMPONENT_HELP:help,MIRA_FUNCTIONAL:f,MIRA_ATLAS:a}=ctx.window;
assert(tour&&help&&f&&a,'Brief route, component glossary and source data must all be loaded by index.html');
assert.equal(tour.steps.length,12,'Short route contains twelve episodes');
assert(/4\s*[–-]\s*6/.test(tour.duration),'Short route communicates its expected duration');
const chapters=new Set(tour.chapters.map(c=>c.id)),ids=new Set(),scenes=new Set(),refPattern=/\b(?:FB|SW|JP|U|Q|J|T|Y|K|L|D|R|C|F)\d+[A-Z]?\b/g;
let words=0,nodes=0,edges=0,reversed=0;
for(const step of tour.steps){
 assert(!ids.has(step.id),'Duplicate short episode '+step.id);ids.add(step.id);
 assert(chapters.has(step.chapterId),'Unknown chapter '+step.id);assert.equal(step.kind,'main','Short route avoids component-level episodes');
 const scene=f.scenes[step.sceneId];assert(scene&&!scene.hidden,'Unknown/hidden scene '+step.id);scenes.add(scene.id);
 assert(step.title&&step.lead&&/[А-Яа-яЁё]/.test(step.title+step.lead),'Missing Russian explanation '+step.id);
 assert(Array.isArray(step.body)&&step.body.length===1&&step.body[0].length>=100,'Need one compact, substantive paragraph '+step.id);
 assert(Array.isArray(step.path)&&step.path.length>=3&&step.path.length<=5,'Need a short readable signal path '+step.id);
 const visible=[step.title,step.lead,...step.body,step.why||'',...step.path].join(' '),count=visible.trim().split(/\s+/).length;words+=count;
 assert(count<=90,'Episode is too long for the short presentation '+step.id+' ('+count+' words)');
 assert(!refPattern.test(visible),'Raw component designator in brief text '+step.id);refPattern.lastIndex=0;
 assert(!/\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b|\b(?:control|power)_(?:net_|[A-Z0-9])|\.kicad_sch\b/.test(visible),'Source filename/net dump in brief text '+step.id);
 assert((step.source?.sheetId||null)===(scene.sourceSheetId||null),'Incorrect KiCad sheet binding '+step.id);
 if(step.source?.sheetId){const source=a.sheets[step.source.sheetId];assert(source,'Unknown source sheet '+step.id);assert.equal(step.source.sheetName,source.file.replace(/\.kicad_sch$/,''),'Preserve exact KiCad sheet filename');assert.equal(step.source.board,source.board,'Preserve board identity');}
 const nodeIds=new Set(scene.nodes.map(n=>n.id)),edgeById=new Map(scene.edges.map(e=>[e.id,e]));
 assert(step.nodeIds?.length&&step.edgeIds?.length,'Episode must highlight blocks and a signal path '+step.id);
 for(const id of step.nodeIds){assert(nodeIds.has(id),'Unknown highlighted node '+step.id+'/'+id);nodes++;}
 for(const id of step.edgeIds){const edge=edgeById.get(id);assert(edge,'Unknown highlighted edge '+step.id+'/'+id);assert(nodeIds.has(edge.from)&&nodeIds.has(edge.to),'Edge has invalid endpoints '+step.id+'/'+id);edges++;}
 for(const [id,direction] of Object.entries(step.edgeDirections||{})){assert(step.edgeIds.includes(id),'Direction applies only to a selected edge '+step.id+'/'+id);assert(['forward','reverse'].includes(direction),'Invalid direction '+step.id+'/'+id);if(direction==='reverse'){assert(edgeById.get(id).bidirectional,'Cannot reverse one-way source relationship '+step.id+'/'+id);reversed++;}}
}
assert(tour.steps[0].sceneId==='system'&&tour.steps.at(-1).sceneId==='system','Short story starts and finishes with the whole architecture');
const covers=(sceneId,...edgeIds)=>tour.steps.some(s=>s.sceneId===sceneId&&edgeIds.every(id=>s.edgeIds.includes(id)));
for(const [label,scene,...edgeIds] of [
 ['power preparation','power','input_primary','primary_secondary'],
 ['controller and programmable logic','control','host_fpga'],
 ['Ethernet receive path','control_900_FPGA_ETHERNET_AND_MCU_INTERFACE','connector_isolation_0','isolation_phy_1','phy_fpga_2'],
 ['USB receive path','control_700_FPGA_USB3_FIFO_INTERFACE','connector_orientation','orientation_bridge','bridge_fpga'],
 ['digital-to-analog drive','control','fpga_sources','sources_routing'],
 ['matrix switching','control','fpga_routing','routing_readout'],
 ['measurement and collection','control','routing_readout','readout_fpga'],
 ['independent protection','control','sources_regulation','regulation_safety','safety_routing']
])assert(covers(scene,...edgeIds),'Missing full-cycle stage: '+label);
const returnStep=tour.steps.find(s=>s.sceneId==='system'&&s.edgeDirections?.links_fpga==='reverse'&&s.edgeDirections?.host_links==='reverse');
assert(returnStep&&returnStep.edgeIds.includes('readout_fpga'),'Results must visibly travel back from measurement to the computer');
const overviewEdges=new Set(tour.steps.filter(s=>s.sceneId==='system').flatMap(s=>s.edgeIds));
for(const id of ['host_links','links_fpga','fpga_drive','drive_matrix','matrix_readout','readout_fpga','matrix_safety'])assert(overviewEdges.has(id),'Whole-system cycle misses '+id);
const glossary=help.components,required=Object.values(a.components).filter(c=>!c.virtual&&/^[UQJTY]\d+[A-Z]?$/.test(c.ref));
for(const [id,entry] of Object.entries(glossary)){
 const component=a.components[id];assert(component&&!component.virtual,'Glossary key must identify a physical source component '+id);
 assert.equal(id,component.board+'_'+component.ref,'Glossary preserves exact board and KiCad designator');
 assert.equal(entry.ref,component.ref,'Glossary reference mismatch '+id);assert.equal(entry.board,component.board,'Glossary board mismatch '+id);assert.equal(entry.model,component.value,'Glossary model mismatch '+id);
 assert(typeof entry.name==='string'&&entry.name.length>=5&&/[А-Яа-яЁё]/.test(entry.name),'Russian functional component name missing '+id);
 assert(typeof entry.purpose==='string'&&entry.purpose.length>=25&&/[А-Яа-яЁё]/.test(entry.purpose),'Russian role explanation missing '+id);
 assert(!/уточняется|нет описания|неизвестн/i.test(entry.name+' '+entry.purpose),'Placeholder component description '+id);
}
for(const component of required)assert(glossary[component.id],'Active/connector component lacks a role explanation '+component.id);
const control=glossary.control_U2001,power=glossary.power_U2001;
assert(control&&power&&control.name!==power.name&&control.purpose!==power.purpose,'Same-number components on different boards need independent explanations');
assert(/опор|АЦП/i.test(control.name+' '+control.purpose)&&/стабилизатор|питан/i.test(power.name+' '+power.purpose),'U2001 roles must match their actual source circuit');
vm.runInNewContext(fs.readFileSync(path.join(root,'js/component-info.js'),'utf8'),ctx,{filename:'js/component-info.js'});
const info=ctx.window.MiraComponentInfo;
assert.equal(info.get('U2001','control').id,'control_U2001');assert.equal(info.get('U2001','power').id,'power_U2001');assert.equal(info.get('U2001'),null,'Ambiguous bare designator must not silently choose a board');
const mention=info.format('<проверка> U2001','power');assert(mention.includes('&lt;проверка&gt;')&&mention.includes('data-component-help="power_U2001"')&&mention.includes(power.name),'Technical mentions need an escaped, readable, board-aware component explanation');
const report={passed:true,briefSteps:tour.steps.length,chapters:chapters.size,scenes:scenes.size,visibleWords:words,maxWordsPerEpisode:90,highlightedNodes:nodes,highlightedEdges:edges,validReturnDirections:reversed,glossaryEntries:Object.keys(glossary).length,physicalActiveAndConnectorComponentsCovered:required.length,fullArchitectureCycle:true,plainRussianNarration:true,boardAwareComponentLookup:true};
console.log(JSON.stringify(report,null,2));if(process.argv.includes('--report'))fs.writeFileSync(path.join(root,'data/brief-presentation-validation.json'),JSON.stringify(report,null,2)+'\n');
