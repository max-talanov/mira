#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..'),ctx={window:{}},html=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g))vm.runInNewContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx,{filename:m[1]});
const a=ctx.window.MIRA_ATLAS,f=ctx.window.MIRA_FUNCTIONAL;
const assert=(v,s)=>{if(!v)throw Error(s);};assert(a&&f,'Missing data');
let nodes=0,edges=0,leafCount=0,grouped=0;
for(const[id,s]of Object.entries(f.scenes)){
 const ids=new Set(s.nodes.map(n=>n.id));assert(ids.size===s.nodes.length,'Duplicate node IDs: '+id);nodes+=s.nodes.length;edges+=s.edges.length;
 for(const n of s.nodes){for(const cid of n.refs||[])assert(a.components[cid],'Missing component: '+cid);if(n.sceneId)assert(f.scenes[n.sceneId],'Missing scene: '+n.sceneId);assert(Number.isFinite(n.x)&&Number.isFinite(n.y)&&n.w>0&&n.h>0,'Invalid node geometry: '+id);}
 for(const e of s.edges){assert(ids.has(e.from)&&ids.has(e.to),'Invalid edge: '+id+'/'+e.id);for(const nid of e.nets||[])assert(a.nets[nid],'Missing net: '+nid);}
 const leaf=a.sheets[id];if(leaf&&!leaf.children.length){leafCount++;const refs=new Set(s.nodes.flatMap(n=>n.refs||[]));for(const cid of leaf.components)if(!a.components[cid].virtual){assert(refs.has(cid),'Ungrouped component: '+id+'/'+cid);grouped++;}}
 for(let i=0;i<s.nodes.length;i++)for(let j=i+1;j<s.nodes.length;j++){const u=s.nodes[i],v=s.nodes[j];assert(!(u.x<v.x+v.w&&u.x+u.w>v.x&&u.y<v.y+v.h&&u.y+u.h>v.y),'Overlapping nodes: '+id+'/'+u.id+'/'+v.id);}
}
assert(leafCount===a.stats.circuitSheets,'Missing circuit scene');
let storySteps=0,pinHighlights=0;
for(const [id,scene] of Object.entries(f.scenes)){
 if(scene.sourceSheetId){const source=a.sheets[scene.sourceSheetId],expected=source.parent?source.name:source.file.replace(/\.kicad_sch$/,'');assert(scene.title===expected,'Incorrect KiCad sheet name: '+id);assert(/[А-Яа-яЁё]/.test(scene.subtitle),'Missing Russian explanation: '+id);}else assert(id==='system','Unbound scene: '+id);
 assert(f.scenarios.some(story=>story.sceneId===id),'Missing local story: '+id);
 if(scene.terminal)assert(scene.nodes.every(n=>!n.sceneId&&!n.detailSceneId),'Component page below terminal module: '+id);
 for(const e of scene.edges)for(const name of e.netLabels||[])assert((e.nets||[]).some(n=>a.nets[n]?.name===name),'Non-source inline net name: '+id+'/'+name);
 for(const node of scene.nodes)for(const unit of node.circuitGroup?.units||[])assert(a.sheets[unit.sheet]?.drawing?.symbols?.some(s=>s.component===unit.component&&String(s.unit)===String(unit.unit)),'Missing source symbol unit: '+id+'/'+unit.component);
}
for(const story of f.scenarios){
 assert(/[А-Яа-яЁё]/.test(story.title),'Missing Russian story title: '+story.id);
 for(const step of story.steps){storySteps++;
  for(const id of step.netIds||[])assert(a.nets[id],'Missing step net: '+story.id+'/'+id);
  for(const p of step.pinHighlights||[]){pinHighlights++;assert(a.components[p.component]?.pins?.some(q=>String(q.number)===String(p.pin)&&q.net===p.netId),'Invalid highlighted source terminal: '+story.id+'/'+p.component+'.'+p.pin);}
 }
}
assert(html.includes('src="js/presentation.js"')&&html.includes('src="data/presentation-tour.js"')&&html.includes('id="presentation-toggle"'),'Integrated presentation missing');
for(const s of f.scenarios){assert(f.scenes[s.sceneId],'Scenario scene missing: '+s.id);for(const step of s.steps){const sc=f.scenes[step.sceneId||s.sceneId];assert(sc,'Frame scene missing');for(const id of step.nodes||[])assert(sc.nodes.some(n=>n.id===id),'Frame node missing: '+s.id+'/'+id);for(const id of step.edges||[])assert(sc.edges.some(e=>e.id===id),'Frame edge missing: '+s.id+'/'+id);}}
console.log(JSON.stringify({passed:true,scenes:Object.keys(f.scenes).length,functionalNodes:nodes,functionalConnections:edges,circuitModuleScenes:leafCount,groupedComponentPlacements:grouped,scenarios:f.scenarios.length,storySteps,pinHighlights,allScenesHaveStories:true,russianContent:true,sourceSheetNames:true,sourceSheetBindings:Object.keys(f.sheetScenes||{}).length,noComponentPages:true,integratedPresentationMode:true,noNodeOverlaps:true,sourceIdentityPreserved:true},null,2));
