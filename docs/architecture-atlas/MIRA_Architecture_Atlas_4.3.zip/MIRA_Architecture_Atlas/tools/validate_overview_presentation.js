#!/usr/bin/env node
/* Validate the medium-length architecture explanation against the live KiCad atlas. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..'),ctx={window:{}},html=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g))vm.runInNewContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx,{filename:m[1]});
const {MIRA_OVERVIEW_TOUR:tour,MIRA_BRIEF_TOUR:brief,MIRA_FUNCTIONAL:f,MIRA_ATLAS:a,MIRA_COMPONENT_HELP:help}=ctx.window;
assert(tour&&brief&&f&&a&&help,'Index must load the overview and retained source content');
assert.equal(tour.steps.length,24,'Main overview contains 24 episodes');
assert.equal(brief.steps.length,12,'The optional short route remains available');
assert(/10\s*[–-]\s*15/.test(tour.duration),'Main overview communicates its 10–15 minute duration');
assert(tour.chapters.length>=6&&tour.chapters.length<=8,'Overview has a readable architecture chapter structure');
const chapters=new Set(tour.chapters.map(c=>c.id)),ids=new Set(),scenes=new Set(),refPattern=/\b(?:FB|SW|JP|U|Q|J|T|Y|K|L|D|R|C|F)\d+[A-Z]?\b/g;
assert.equal(chapters.size,tour.chapters.length,'Every chapter has its own identity');
let words=0,nodes=0,edges=0,reversed=0,stories=0,largestEpisode=0;
for(const step of tour.steps){
 assert(!ids.has(step.id),'Duplicate overview episode '+step.id);ids.add(step.id);
 assert(chapters.has(step.chapterId),'Unknown chapter '+step.id);assert.equal(step.kind,'main','Main overview avoids component-level detail episodes');
 const scene=f.scenes[step.sceneId];assert(scene&&!scene.hidden,'Unknown or hidden scene '+step.id);scenes.add(scene.id);
 assert(step.title&&step.lead&&/[А-Яа-яЁё]/.test(step.title+step.lead),'Russian framing is required '+step.id);
 assert(Array.isArray(step.body)&&step.body.length>=1&&step.body.length<=2&&step.body.every(p=>typeof p==='string'&&p.length>=70),'Each episode needs one or two substantive paragraphs '+step.id);
 assert(Array.isArray(step.path)&&step.path.length>=3&&step.path.length<=5,'Episode needs a short input-to-output path '+step.id);
 const visible=[step.title,step.lead,...step.body,step.why||'',...step.path].join(' '),count=visible.trim().split(/\s+/).length;
 words+=count;largestEpisode=Math.max(largestEpisode,count);assert(count>=65&&count<=125,'Episode depth must remain useful and presentable '+step.id+' ('+count+' words)');
 assert(!/\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b|\b(?:control|power)_(?:net_|[A-Z0-9])|\.kicad_sch\b/.test(visible),'Friendly overview must not dump net or sheet identifiers '+step.id);
 assert(!refPattern.test([step.title,step.lead,...step.path].join(' ')),'Headings and signal path use function names, not bare designators '+step.id);refPattern.lastIndex=0;
 for(const paragraph of step.body){for(const match of paragraph.matchAll(refPattern)){const id=(scene.board||step.source?.board)+'_'+match[0];assert(a.components[id]&&help.components[id],'A mentioned component needs an exact board-aware explanation '+step.id+'/'+match[0]);const context=paragraph.slice(Math.max(0,match.index-90),match.index+match[0].length+90);assert(/[А-Яа-яЁё]{4,}/.test(context),'Component mention lacks a nearby plain-language role '+step.id+'/'+match[0]);}}
 assert((step.source?.sheetId||null)===(scene.sourceSheetId||null),'Incorrect source-sheet binding '+step.id);
 if(step.source?.sheetId){const source=a.sheets[step.source.sheetId];assert(source,'Unknown source sheet '+step.id);assert.equal(step.source.sheetName,source.file.replace(/\.kicad_sch$/,''),'Preserve exact KiCad sheet filename');assert.equal(step.source.board,source.board,'Preserve board identity');}
 for(const id of step.source?.netIds||[])assert(a.nets[id],'Unknown exact source net '+step.id+'/'+id);
 const nodeIds=new Set(scene.nodes.map(n=>n.id)),edgeById=new Map(scene.edges.map(e=>[e.id,e]));
 assert(step.nodeIds?.length&&step.edgeIds?.length,'Every episode must highlight a functional route '+step.id);
 for(const id of step.nodeIds){assert(nodeIds.has(id),'Unknown highlighted node '+step.id+'/'+id);nodes++;}
 for(const id of step.edgeIds){const edge=edgeById.get(id);assert(edge,'Unknown highlighted edge '+step.id+'/'+id);assert(nodeIds.has(edge.from)&&nodeIds.has(edge.to),'Invalid route endpoint '+step.id+'/'+id);edges++;}
 for(const [id,direction] of Object.entries(step.edgeDirections||{})){assert(step.edgeIds.includes(id),'Direction override requires a selected edge '+step.id+'/'+id);assert(['forward','reverse'].includes(direction),'Invalid flow direction '+step.id+'/'+id);if(direction==='reverse'){assert(edgeById.get(id).bidirectional,'Cannot reverse a one-way source relationship '+step.id+'/'+id);reversed++;}}
 if(step.storyId){const story=f.scenarios.find(s=>s.id===step.storyId);assert(story&&story.sceneId===scene.id,'Unknown or wrong-scene story '+step.id);assert(Number.isInteger(step.storyStep)&&story.steps[step.storyStep],'Invalid bound story step '+step.id);stories++;}
}
assert(words>=1800&&words<=2200,'Overview must restore meaningful context while remaining a 10–15 minute route ('+words+' words)');
assert.deepEqual(tour.chapters.flatMap(c=>tour.steps.filter(s=>s.chapterId===c.id).map(s=>s.id)),tour.steps.map(s=>s.id),'Chapter navigation preserves the authored beginning-to-end sequence');
assert(tour.steps[0].sceneId==='system'&&tour.steps.at(-1).sceneId==='system','Overview begins and ends with the complete system');
const indexOf=prefix=>tour.steps.findIndex(s=>s.sceneId===prefix||s.sceneId.startsWith(prefix));
for(const [purpose,scene] of [
 ['protected input','power-input'],['always-on control supply','power_500_AON_3V3_BUCK'],['power readiness and domains','power'],
 ['controller and FPGA roles','control'],['FPGA configuration','control_600_FPGA_CONFIGURATION_AND_XADC'],
 ['Ethernet','control_900_FPGA_ETHERNET_AND_MCU_INTERFACE'],['USB','control_700_FPGA_USB3_FIFO_INTERFACE'],
 ['matrix drive sources','control_1000_DAC_BL0_31_AND_BUFFERS'],['service and forming sources','control_1100_DAC_SERVICE_AND_FORMING'],
 ['matrix control','control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS'],['matrix switching','control-routing'],
 ['polarity selection','control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING'],['matrix connection','control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS'],
 ['current measurement','control_1900_ADC_TIA_AND_MONITOR_SELECTOR'],['digitizing and reference','control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES'],
 ['sample memory','control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK'],['write-current compliance','control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE'],
 ['fault interlocks','control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE']
])assert(tour.steps.some(s=>s.sceneId===scene),'Missing architecture role: '+purpose);
assert(indexOf('power-input')<indexOf('control_900_FPGA_ETHERNET')&&indexOf('control_700_FPGA_USB3')<indexOf('control_1000_DAC'),'Prepare the hardware and receive a command before analog actuation');
assert(indexOf('control_1800_MATRIX')<indexOf('control_1900_ADC')&&indexOf('control_1900_ADC')<indexOf('control_2000_ADC'),'Trace the response from matrix through current measurement to digital conversion');
const result=tour.steps.find(s=>s.sceneId==='system'&&s.edgeDirections?.links_fpga==='reverse'&&s.edgeDirections?.host_links==='reverse');
assert(result&&result.edgeIds.includes('readout_fpga'),'Collected measurements must visibly return to the computer');
const report={passed:true,overviewSteps:tour.steps.length,retainedBriefSteps:brief.steps.length,chapters:chapters.size,scenes:scenes.size,visibleWords:words,largestEpisodeWords:largestEpisode,highlightedNodes:nodes,highlightedEdges:edges,validReverseDirections:reversed,verifiedStoryBindings:stories,fullArchitectureCycle:true,exactSourceIdentity:true,friendlyRussianExplanation:true};
console.log(JSON.stringify(report,null,2));if(process.argv.includes('--report'))fs.writeFileSync(path.join(root,'data/overview-presentation-validation.json'),JSON.stringify(report,null,2)+'\n');
