#!/usr/bin/env python3
"""Build an auditable, offline MIRA atlas graph from reachable KiCad schematics.

No KiCad installation or third-party Python packages are required. This reads
source geometry; it is not an ERC, circuit simulator, or KiCad netlist exporter.
Coordinates are in schematic millimetres. Unnamed net display names are explicitly
atlas-generated. Do not interpret graph coverage as circuit correctness.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import math
import shutil
import tempfile
from pathlib import Path
import re
from datetime import datetime, timezone

KNOWN_SOURCE_PROVENANCE = {'c3e71f8d19e542d124a0c49ada519c3b32de85e3364279ad8a48655baca3e80b': {'board': 'control', 'archive': 'MIRA_Control_Organized.zip', 'libraryId': 'libfile_fcf2a2ca45e88191a71e8ebabae695e2', 'libraryVersion': 5, 'snapshotDescription': 'Current materialized Control archive, version 5', 'materializedFileId': 'file_000000002c7481f5a0f13703c16d6aae'}, 'c8eaabc4774e80536bd00a59818d96aa29be04778da7d4d7cdc536ab97a2dbca': {'board': 'power', 'archive': 'MIRA_RevA_Full_KiCad.zip', 'libraryId': 'libfile_c8b445091d30819199c8e60fd67d52e7', 'libraryVersion': 1, 'snapshotDescription': 'Power-only POWER_SYSTEM subtree from older full archive; other old board sections excluded'}}

TOKEN = re.compile(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+')

def parse(text):
    stack=[]; root=None
    for m in TOKEN.finditer(text):
        t=m.group()
        if t=='(':
            node=[]
            if stack: stack[-1].append(node)
            elif root is not None: raise ValueError('More than one root expression')
            else: root=node
            stack.append(node)
        elif t==')':
            if not stack: raise ValueError('Unexpected closing parenthesis')
            stack.pop()
        else:
            if not stack: raise ValueError('Atom outside root expression')
            if t.startswith('"'):
                # KiCad strings use C-like escapes; preserve any unknown escapes.
                def unescape(m):
                    return {'n':'\n','r':'\r','t':'\t','"':'"','\\':'\\'}.get(m[1], '\\'+m[1])
                t=re.sub(r'\\(.)', unescape, t[1:-1])
            stack[-1].append(t)
    if stack: raise ValueError('Unclosed expression')
    if not root or root[0]!='kicad_sch': raise ValueError('Expected kicad_sch root')
    return root

def children(node,key):
    return [c for c in node[1:] if isinstance(c,list) and c and c[0]==key]
def child(node,key,default=None):
    return next((c for c in node[1:] if isinstance(c,list) and c and c[0]==key),default)
def value(node,key,default=None):
    v=child(node,key)
    return v[1] if v and len(v)>1 else default
def props(node):
    return {p[1]:p[2] for p in children(node,'property') if len(p)>2}
def xy(node):
    return (round(float(node[1]),5),round(float(node[2]),5))
def safe(text):
    return re.sub(r'[^A-Za-z0-9_-]+','_',str(text)).strip('_') or 'item'
def digest(text): return hashlib.sha256(text.encode()).hexdigest()[:12]
def natural(text):
    return [int(s) if s.isdigit() else s.lower() for s in re.split(r'(\d+)',str(text))]
def flag(node,key):
    entry=child(node,key)
    return entry is not None and (len(entry)==1 or entry[1] not in ('no','false','0'))

class UnionFind:
    def __init__(self): self.parent={};self.rank={}
    def add(self,x):
        if x not in self.parent:self.parent[x]=x;self.rank[x]=0
        return x
    def find(self,x):
        p=self.parent[x]
        if p!=x:self.parent[x]=self.find(p)
        return self.parent[x]
    def union(self,a,b):
        a=self.find(a);b=self.find(b)
        if a==b:return
        if self.rank[a]<self.rank[b]:a,b=b,a
        self.parent[b]=a
        if self.rank[a]==self.rank[b]:self.rank[a]+=1

def transform(x,y,ox,oy,angle,mirror=None):
    """KiCad symbol coordinates use Y up; sheet coordinates use Y down.

    Rotation is applied before mirror in sheet axes. At 90deg local +X points
    up. `mirror x` reflects sheet Y, and `mirror y` reflects sheet X.
    """
    a=math.radians(angle);cx=x*math.cos(a)-y*math.sin(a);cy=-x*math.sin(a)-y*math.cos(a)
    if mirror=='x':cy=-cy
    elif mirror=='y':cx=-cx
    return (round(ox+cx,5),round(oy+cy,5))

# A vector from a lib-symbol pin terminal towards its body.
def pin_body(pin,transformer):
    at=child(pin,'at');x,y=map(float,at[1:3]);a=math.radians(float(at[3]) if len(at)>3 else 0)
    length=float(value(pin,'length',0))
    return transformer(x+length*math.cos(a),y+length*math.sin(a))

def infer_kind(name,pins):
    n=name.upper()
    if re.search(r'(^|[_/])(?:AGND|DGND|PGND|GND|GNDA|GNDD|VSS|GROUND)(?:$|[_/])',n): return 'ground'
    if re.search(r'(^[+\-]|^V(?:CC|DD|SS|BAT|BUS|CORE|REF|IN|OUT)|(?:^|_)(?:\dV\d|\d+V|PWR|POWER|SUPPLY|VCC|VDD|RAIL|BUS24)(?:_|$))',n): return 'power'
    if re.search(r'CLK|CLOCK|HSE|LSE|XTAL|OSC|(^|_)RXC$|(^|_)TXC$',n): return 'clock'
    if re.search(r'FAULT|TRIP|INHIBIT|RESET|RST|ENABLE|(^|_)EN($|_)|PGOOD|PWR_GOOD|READY|PERMIT|ARM|KILL|PROGRAM|INIT|DONE',n): return 'control'
    if re.search(r'(^|_)(?:ADC|DAC|AIN|AOUT|TIA|SENSE|MON|VREAD|VSET|VRESET|VFORM|IWRITE|VPROG|BL|WL|NL)(?:\d|_|$)',n): return 'analog'
    if re.search(r'RX|TX|DATA|MDI|MDC|SPI|MISO|MOSI|SCK|SDIO|QSPI|FMC|DDR|DQS|USB|FIFO|I2C|SDA|SCL|UART|JTAG|TMS|TDI|TDO|SWD',n): return 'data'
    if pins and all(p['type'] in ('power_in','power_out') for p in pins):return 'power'
    return 'signal'

class Extractor:
    def __init__(self,snapshot_root=None):
        self.snapshot_root=snapshot_root;self.board_roots={};self.provenance=[]
        self.atlas={'meta':{},'boards':[],'sheets':{},'components':{},'nets':{},'stats':{},'diagnostics':[]}
        self.uf=UnionFind();self.labels=[];self.rawpins=[];self.source_entries=[];self.sheetdata={};self.connections=[]
        self.global_names={};self.local_names={};self.physical_pins={};self.rawcounts=collections.Counter()
        self.coverage={'formatVersion':1,'scope':'Reachable source hierarchy only; extraction coverage, not ERC validation','sheets':{},'boards':{},'checks':{},'unresolved':[]}
    def diagnostic(self,code,message,**extra):
        obj={'code':code,'message':message,**extra};self.atlas['diagnostics'].append(obj)
        if code in ('missing_library_symbol','missing_sheet','unmatched_hierarchical_label','unsupported_bus','missing_symbol_unit','hierarchy_cycle','conflicting_reference'):
            self.coverage['unresolved'].append(obj)
    def node(self,sid,p):return self.uf.add((sid,*p))
    def add_label(self,sid,name,p,scope,origin='label'):
        n=self.node(sid,p);item={'sheet':sid,'name':name,'x':p[0],'y':p[1],'scope':scope,'origin':origin,'node':n}
        self.labels.append(item)
        local=(sid,name)
        if local in self.local_names:self.uf.union(n,self.local_names[local])
        else:self.local_names[local]=n
        if scope=='global':
            if name in self.global_names:self.uf.union(n,self.global_names[name])
            else:self.global_names[name]=n
        return item
    def load_board(self,bid,path,title):
        path=Path(path).resolve()
        self.board_roots[bid]=path.parent
        known=KNOWN_SOURCE_PROVENANCE.get(hashlib.sha256(path.read_bytes()).hexdigest())
        if known and known['board']==bid:self.provenance.append(dict(known))
        root=parse(path.read_text());rootuuid=value(root,'uuid','root')
        board={'id':bid,'title':title,'source':path.name,'sourceVersion':value(root,'version'),'rootSheet':None,'connectionPolicy':'Electrical net namespaces are independent per board; cross-board links require explicit verified connector mapping.'}
        self.atlas['boards'].append(board)
        # Keep global power and signal labels scoped to this board.
        self.global_names={};self.local_names={};self.physical_pins={}
        board['rootSheet']=self.walk(path,bid,title,None,'/'+rootuuid,[],root)
        # Finish joining labels whose name coincides with global labels, including
        # local labels encountered before their first global counterpart.
        for (sid,name),node in self.local_names.items():
            if name in self.global_names:self.uf.union(node,self.global_names[name])
    def walk(self,path,bid,name,parent,instance_path,ancestors,parsed=None):
        path=path.resolve()
        if path in ancestors:
            self.diagnostic('hierarchy_cycle','Cyclic sheet inclusion',board=bid,file=path.name);return None
        if not path.exists():
            self.diagnostic('missing_sheet','Referenced child sheet is unavailable',board=bid,file=path.name);return None
        raw=path.read_bytes();root=parsed or parse(raw.decode())
        # Sheet IDs are filename-based for ordinary files, path-suffixed for reused sheets.
        sid=bid+'_'+safe(path.stem)
        if sid in self.atlas['sheets']:sid+='_'+digest(instance_path)[:6]
        tb=child(root,'title_block',[]);title=value(tb,'title',name) or name
        prefix=re.match(r'(\d+)',path.stem);number=int(prefix[1]) if prefix else 0
        notes=[t[1] for t in children(root,'text') if len(t)>1 and len(t[1])<10000]
        source={'board':bid,'sheet':sid,'file':path.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'uuid':value(root,'uuid'),'instancePath':instance_path}
        if self.snapshot_root:
            relative=path.relative_to(self.board_roots[bid]) if path.is_relative_to(self.board_roots[bid]) else Path('_external')/path.name
            snapshot=self.snapshot_root/bid/relative;snapshot.parent.mkdir(parents=True,exist_ok=True)
            if path.resolve()!=snapshot.resolve():shutil.copyfile(path,snapshot)
            source['snapshot']='sources/'+bid+'/'+relative.as_posix()
        self.source_entries.append(source)
        sheet={'id':sid,'board':bid,'file':path.name,'title':title,'name':name,'number':number,'parent':parent,'children':[],
               'description':next((n.replace('\n',' ') for n in notes if len(n)>75),title),'notes':notes,
               'components':[],'nets':[],'drawing':{'symbols':[],'wires':[],'labels':[],'junctions':[],'noConnects':[],'sheetPins':[],'graphicLines':[],'texts':[],'bounds':{}},
               'source':source,'paper':value(root,'paper','A3'),'sourceRevision':value(tb,'rev','')}
        self.atlas['sheets'][sid]=sheet
        sd={'points':set(),'wires':[],'symbols':[],'pins':[],'labels':[],'junctions':[],'noConnects':[],'childPins':[],'hierLabels':[],'root':root};self.sheetdata[sid]=sd
        # Embedded library definitions carry all original pin numbers/names.
        libs={s[1]:s for s in children(child(root,'lib_symbols',[]),'symbol')}
        for s in children(root,'symbol'):
            pr=props(s);libid=value(s,'lib_id','');lib=libs.get(libid);ref=pr.get('Reference','?')
            # Prefer matching per-instance annotation for reused hierarchy.
            inst=child(s,'instances',[])
            for project in children(inst,'project'):
                for sp in children(project,'path'):
                    if sp[1]==instance_path:ref=value(sp,'reference',ref)
            unit=int(value(s,'unit',1));convert=int(value(s,'convert',1));at=child(s,'at',['at','0','0','0']);ox,oy=map(float,at[1:3]);angle=float(at[3]) if len(at)>3 else 0;mirror=value(s,'mirror')
            component_id=bid+'_'+safe(ref)
            virtual=ref.startswith('#')
            if component_id not in self.atlas['components']:
                self.atlas['components'][component_id]={'id':component_id,'ref':ref,'value':pr.get('Value',''),'lib':libid,'description':pr.get('Description','') or props(lib or []).get('Description',''),
                    'board':bid,'sheets':[],'pins':[],'virtual':virtual,'footprint':pr.get('Footprint',''),'datasheet':pr.get('Datasheet',''),'manufacturer':pr.get('Manufacturer',''),'mpn':pr.get('MPN','')}
            comp=self.atlas['components'][component_id]
            if comp['lib']!=libid:self.diagnostic('conflicting_reference','One physical reference has differing library symbols',component=component_id,sheet=sid,libs=[comp['lib'],libid])
            if sid not in comp['sheets']:comp['sheets'].append(sid)
            if component_id not in sheet['components']:sheet['components'].append(component_id)
            placed={'component':component_id,'ref':ref,'unit':unit,'x':ox,'y':oy,'angle':angle,'mirror':mirror,'pins':[],'box':{},'graphics':[],'uuid':value(s,'uuid','')}
            sd['symbols'].append(placed);sheet['drawing']['symbols'].append(placed);self.rawcounts['placedSymbols']+=1
            if not lib:
                self.diagnostic('missing_library_symbol','Placed symbol has no embedded library definition',sheet=sid,component=component_id,lib=libid);placed['box']={'x':ox-2.5,'y':oy-2.5,'w':5,'h':5};continue
            trans=lambda x,y:transform(x,y,ox,oy,angle,mirror)
            subs=[]
            # Include common (unit 0 / conversion 0) and requested unit + conversion.
            for sub in children(lib,'symbol'):
                m=re.search(r'_(\d+)_(\d+)$',sub[1])
                if m and int(m[1]) in (0,unit) and int(m[2]) in (0,convert):subs.append(sub)
            selected_pins=[p for sub in subs for p in children(sub,'pin')]
            if not selected_pins:self.diagnostic('missing_symbol_unit','No pins found for placed symbol unit',sheet=sid,component=component_id,unit=unit)
            bbox=[]
            for sub in subs:
                for g in sub[2:]:
                    if not isinstance(g,list) or not g:continue
                    typ=g[0];pts=[]
                    if typ=='rectangle':pts=[trans(*xy(child(g,'start'))),trans(*xy(child(g,'end')))]
                    elif typ in ('polyline','bezier'):pts=[trans(*xy(p)) for p in child(g,'pts',[])[1:] if isinstance(p,list)]
                    elif typ=='circle':
                        cen=xy(child(g,'center'));r=float(value(g,'radius',0));pts=[trans(cen[0]-r,cen[1]-r),trans(cen[0]+r,cen[1]+r)]
                    elif typ=='arc':pts=[trans(*xy(child(g,k))) for k in ('start','mid','end') if child(g,k)]
                    if pts:
                        bbox.extend(pts);placed['graphics'].append({'type':typ,'points':[[x,y] for x,y in pts]})
            for p in selected_pins:
                num=value(p,'number','');pname=value(p,'name','');ptype=p[1];px,py=trans(*xy(child(p,'at')));body=pin_body(p,trans)
                n=self.node(sid,(px,py));sd['points'].add((px,py));hidden=flag(p,'hide') or 'hide' in p
                rp={'component':component_id,'ref':ref,'number':num,'name':pname,'type':ptype,'sheet':sid,'unit':unit,'x':px,'y':py,'bodyX':body[0],'bodyY':body[1],'hidden':hidden,'node':n,'virtual':virtual}
                self.rawpins.append(rp);sd['pins'].append(rp);placed['pins'].append(rp);self.rawcounts['placedPins']+=1
                same=(component_id,num)
                if same in self.physical_pins:self.uf.union(n,self.physical_pins[same])
                else:self.physical_pins[same]=n
                power=child(lib,'power')
                if power is not None and ('PWR_FLAG' not in libid):
                    scope='local' if len(power)>1 and power[1]=='local' else 'global'
                    self.add_label(sid,pr.get('Value') or pname,(px,py),scope,'power_symbol')
                elif hidden and ptype=='power_in' and pname and pname!='~':
                    self.add_label(sid,pname,(px,py),'global','hidden_power_pin')
            if not bbox:bbox=[(p['x'],p['y']) for p in placed['pins']] or [(ox-2.5,oy-2.5),(ox+2.5,oy+2.5)]
            minx,miny=min(p[0] for p in bbox),min(p[1] for p in bbox);maxx,maxy=max(p[0] for p in bbox),max(p[1] for p in bbox)
            placed['box']={'x':minx,'y':miny,'w':max(.7,maxx-minx),'h':max(.7,maxy-miny)}
        for typ in ('label','global_label','hierarchical_label'):
            for lab in children(root,typ):
                p=xy(child(lab,'at'));item=self.add_label(sid,lab[1],p,'global' if typ=='global_label' else 'local',typ)
                sd['points'].add(p);sd['labels'].append(item);self.rawcounts['labels']+=1
                if typ=='hierarchical_label':sd['hierLabels'].append(item)
        for j in children(root,'junction'):
            p=xy(child(j,'at'));n=self.node(sid,p);sd['points'].add(p);sd['junctions'].append({'x':p[0],'y':p[1],'node':n});self.rawcounts['junctions']+=1
        for j in children(root,'no_connect'):
            p=xy(child(j,'at'));n=self.node(sid,p);sd['points'].add(p);sd['noConnects'].append({'x':p[0],'y':p[1],'node':n});self.rawcounts['noConnects']+=1
        for w in children(root,'wire'):
            pts=child(w,'pts',[])
            if len(pts)<3:continue
            a,b=xy(pts[1]),xy(pts[2]);na,nb=self.node(sid,a),self.node(sid,b);sd['points'].update((a,b));self.uf.union(na,nb)
            sd['wires'].append({'x1':a[0],'y1':a[1],'x2':b[0],'y2':b[1],'node':na,'uuid':value(w,'uuid','')});self.rawcounts['wires']+=1
        for typ in ('polyline','rectangle'):
            for g in children(root,typ):
                if typ=='polyline':pts=[list(xy(p)) for p in child(g,'pts',[])[1:]]
                else:pts=[list(xy(child(g,'start'))),list(xy(child(g,'end')))]
                sheet['drawing']['graphicLines'].append({'type':typ,'points':pts})
        for t in children(root,'text'):
            at=child(t,'at')
            if at:sheet['drawing']['texts'].append({'text':t[1],'x':float(at[1]),'y':float(at[2])})
        for typ in ('bus','bus_entry','bus_alias'):
            if children(root,typ):self.diagnostic('unsupported_bus','Bus geometry requires KiCad expansion and is not silently interpreted as wires',sheet=sid,type=typ,count=len(children(root,typ)))
        # Traverse only sheet references. Archive/history files never enter the graph.
        for sh in children(root,'sheet'):
            pr=props(sh);filename=pr.get('Sheetfile')
            if not filename:continue
            kidpath=instance_path+'/'+value(sh,'uuid','unknown')
            kid=self.walk(path.parent/filename,bid,pr.get('Sheetname',filename),sid,kidpath,ancestors+[path])
            if kid:sheet['children'].append(kid)
            for p in children(sh,'pin'):
                pos=xy(child(p,'at'));pn=self.node(sid,pos);sd['points'].add(pos)
                entry={'name':p[1],'type':p[2] if len(p)>2 else 'unspecified','x':pos[0],'y':pos[1],'node':pn,'child':kid};sd['childPins'].append(entry)
                matches=[h for h in self.sheetdata[kid]['hierLabels'] if h['name']==p[1]] if kid else []
                if not matches:self.diagnostic('unmatched_hierarchical_label','Parent sheet pin has no matching child hierarchical label',sheet=sid,child=kid,name=p[1])
                for h in matches:self.uf.union(pn,h['node'])
        # Explicit terminal points along a wire connect; arbitrary crossing wires do
        # not connect unless an endpoint, pin, label or junction occurs there.
        for w in sd['wires']:
            ax,ay,bx,by=w['x1'],w['y1'],w['x2'],w['y2'];dx,dy=bx-ax,by-ay
            for x,y in sd['points']:
                if min(ax,bx)-1e-5<=x<=max(ax,bx)+1e-5 and min(ay,by)-1e-5<=y<=max(ay,by)+1e-5 and abs(dx*(y-ay)-dy*(x-ax))<1e-4:
                    self.uf.union(w['node'],(sid,x,y))
        return sid
    def finalize(self):
        groups={}
        for node in self.uf.parent:
            root=self.uf.find(node);groups.setdefault(root,{'nodes':[],'pins':[],'labels':[]})['nodes'].append(node)
        for pin in self.rawpins:groups[self.uf.find(pin['node'])]['pins'].append(pin)
        for lab in self.labels:groups[self.uf.find(lab['node'])]['labels'].append(lab)
        root_to_id={}
        for root,g in groups.items():
            sid=g['nodes'][0][0];bid=self.atlas['sheets'][sid]['board']
            labels=sorted(set(l['name'] for l in g['labels'] if l['name']),key=natural)
            # Stable identity is based on physical terminals; geometry only for nets
            # which have no component terminal. It never merges different boards.
            pin_keys=sorted(set(p['component']+'.'+p['number'] for p in g['pins']))
            signature='|'.join(pin_keys or sorted(':'.join(map(str,n)) for n in g['nodes']))
            nid=bid+'_net_'+digest(signature);root_to_id[root]=nid
            preferred=sorted(g['labels'],key=lambda l:({'global_label':0,'power_symbol':1,'hierarchical_label':2,'label':3,'hidden_power_pin':4}.get(l['origin'],5),natural(l['name'])))
            physical=sorted([p for p in g['pins'] if not p['virtual']],key=lambda p:(natural(p['ref']),natural(p['number'])))
            if labels:name=preferred[0]['name'];name_source='schematic'
            elif physical:name='UNNAMED_'+physical[0]['ref']+'_'+physical[0]['number'];name_source='atlas-generated'
            else:name='UNNAMED_WIRE_'+digest(signature)[:6];name_source='atlas-generated'
            pins=[]
            for p in g['pins']:
                pins.append({'component':p['component'],'pin':p['number'],'name':p['name'],'type':p['type'],'sheet':p['sheet'],'unit':p['unit'],'x':p['x'],'y':p['y'],'virtual':p['virtual']})
            sheets=sorted(set(n[0] for n in g['nodes']))
            self.atlas['nets'][nid]={'id':nid,'name':name,'aliases':labels,'kind':infer_kind(name,pins),'kindSource':'inferred from names and pin types','board':bid,'sheets':sheets,'pins':pins,'nameSource':name_source,
                'connectionCount':len(pin_keys),'physicalPinCount':len(set(p['component']+'.'+p['number'] for p in physical)),
                'terminals':[{'sheet':l['sheet'],'name':l['name'],'scope':l['scope'],'origin':l['origin'],'x':l['x'],'y':l['y']} for l in g['labels']]}
            for sh in sheets:self.atlas['sheets'][sh]['nets'].append(nid)
        net_at=lambda n:root_to_id[self.uf.find(n)]
        for p in self.rawpins:
            nid=net_at(p['node']);p['net']=nid
            cp={k:v for k,v in p.items() if k not in ('node','component','ref','virtual')}
            self.atlas['components'][p['component']]['pins'].append(cp)
        for sid,sd in self.sheetdata.items():
            sheet=self.atlas['sheets'][sid];d=sheet['drawing'];allcoords=[]
            for typ in ('wires','junctions','noConnects'):
                d[typ]=[{**{k:v for k,v in o.items() if k!='node'},'net':net_at(o['node'])} for o in sd[typ]]
            d['labels']=[{**{k:v for k,v in o.items() if k not in ('node','sheet')},'net':net_at(o['node'])} for o in sd['labels']]
            d['sheetPins']=[{**{k:v for k,v in o.items() if k!='node'},'net':net_at(o['node'])} for o in sd['childPins']]
            for s in d['symbols']:
                s['pins']=[{k:v for k,v in p.items() if k not in ('node','ref','virtual','sheet','unit','component')} for p in s['pins']]
                b=s['box'];allcoords.extend(((b['x'],b['y']),(b['x']+b['w'],b['y']+b['h'])))
            for w in d['wires']:allcoords.extend(((w['x1'],w['y1']),(w['x2'],w['y2'])))
            if allcoords:
                minx,miny=min(p[0] for p in allcoords),min(p[1] for p in allcoords);maxx,maxy=max(p[0] for p in allcoords),max(p[1] for p in allcoords)
                d['bounds']={'x':minx-6,'y':miny-6,'w':maxx-minx+12,'h':maxy-miny+12}
            else:d['bounds']={'x':0,'y':0,'w':420,'h':297}
            ncpoints={(o['x'],o['y']) for o in sd['noConnects']}
            pins=sd['pins'];physicalpins=[p for p in pins if not p['virtual']]
            # This is coverage, not a claim that all terminal pairs form valid circuits.
            item={'board':sheet['board'],'file':sheet['file'],'placedSymbols':len(sd['symbols']),'physicalComponents':len([c for c in sheet['components'] if not self.atlas['components'][c]['virtual']]),
                'placedPins':len(pins),'physicalPlacedPins':len(physicalpins),'wires':len(sd['wires']),'labels':len(sd['labels']),'junctions':len(sd['junctions']),'noConnectMarkers':len(sd['noConnects']),
                'representedPins':len([p for p in pins if p.get('net')]),'representedWires':len(d['wires']),'nets':len(sheet['nets']),
                'pinsWithNoConnectMarker':len([p for p in pins if (p['x'],p['y']) in ncpoints]),'unresolvedItems':len([e for e in self.coverage['unresolved'] if e.get('sheet')==sid])}
            self.coverage['sheets'][sid]=item;sheet['coverage']=item
            for p in physicalpins:
                if (p['x'],p['y']) in ncpoints:p['noConnect']=True
        # Explicit no-connect status is placed pin specific and also available in
        # component views, after graph identities are fixed.
        for comp in self.atlas['components'].values():
            for p in comp['pins']:
                nc=self.sheetdata[p['sheet']]['noConnects'];p['noConnect']=any(o['x']==p['x'] and o['y']==p['y'] for o in nc)
        physical=[c for c in self.atlas['components'].values() if not c['virtual']]
        self.atlas['stats']={'boards':len(self.atlas['boards']),'sheets':len(self.atlas['sheets']),'circuitSheets':sum(not s['children'] for s in self.atlas['sheets'].values()),'components':len(physical),
            'virtualSymbols':len(self.atlas['components'])-len(physical),'nets':len(self.atlas['nets']),**dict(self.rawcounts),'unnamedNets':sum(n['nameSource']=='atlas-generated' for n in self.atlas['nets'].values()),'unresolvedItems':len(self.coverage['unresolved']),'uniquePhysicalPins':len(set((p['component'],p['number']) for p in self.rawpins if not p['virtual']))}
        for b in self.atlas['boards']:
            bid=b['id'];ss=[s for s in self.atlas['sheets'].values() if s['board']==bid];cc=[c for c in physical if c['board']==bid];nn=[n for n in self.atlas['nets'].values() if n['board']==bid]
            self.coverage['boards'][bid]={'sheets':len(ss),'components':len(cc),'nets':len(nn),'placedPins':sum(s['coverage']['placedPins'] for s in ss),'wires':sum(s['coverage']['wires'] for s in ss)}
        self.coverage['checks']={'allPlacedPinsRepresented':all(s['placedPins']==s['representedPins'] for s in self.coverage['sheets'].values()),'allWireSegmentsRepresented':all(s['wires']==s['representedWires'] for s in self.coverage['sheets'].values()),'allNetPinReferencesResolve':all(p['component'] in self.atlas['components'] for n in self.atlas['nets'].values() for p in n['pins']), 'noNetSpansBoards':all(all(self.atlas['sheets'][sid]['board']==n['board'] for sid in n['sheets']) for n in self.atlas['nets'].values()),'allNoConnectMarkersRepresented':sum(len(s['drawing']['noConnects']) for s in self.atlas['sheets'].values())==self.rawcounts['noConnects']}
        self.atlas['meta']={'formatVersion':1,'title':'MIRA interactive architecture atlas','generatedAt':datetime.now(timezone.utc).isoformat(),'sourceType':'KiCad schematic source geometry','sources':self.source_entries,'sourceArchives':self.provenance,
            'electricalScope':'Only included boards and their reachable hierarchy. Board net namespaces are electrically separate. No archival files are loaded.',
            'limitations':['Extraction coverage is not ERC, SPICE validation, timing verification, or PCB readiness approval.','Kind classification is inferred. Names, references, values, pin identities, wire coordinates and labels come from source schematics.','UNNAMED_* names are deterministic atlas display identifiers, not official KiCad auto-generated net names.','Power symbols create implicit named nets; no-connect markers remain available per placed pin.','Cross-board connector mapping and all educational animations are separate authored layers.'],
            'coverage':self.coverage['checks']}
        return self.atlas

def self_test():
    # Validate against KiCad's convention: rotation is counter-clockwise on the
    # page; mirror x reflects page Y after rotation (90deg + mirror x -> down).
    assert transform(2,3,10,10,0)==(12,7)
    assert transform(2,3,10,10,90)==(7,8)
    assert transform(2,3,10,10,180)==(8,13)
    assert transform(2,3,10,10,270)==(13,12)
    assert transform(2,3,10,10,90,'x')==(7,12)
    assert transform(2,3,10,10,90,'y')==(13,8)
    u=UnionFind();u.add('a');u.add('b');u.union('a','b');assert u.find('a')==u.find('b')
    assert parse('(kicad_sch (text "a\\nb \\\"q\\\""))')[1][1]=='a\nb "q"'

    # Synthetic source graph tests exercise crossings, junctions, label scope,
    # hierarchy mapping and independent board net namespaces.
    lib='(lib_symbols (symbol "Device:R" (property "Description" "Test resistor") (symbol "R_0_1" (pin passive line (at 0 0 0) (length 0) (name "Common") (number "3"))) (symbol "R_1_1" (pin passive line (at -1 0 0) (length 1) (name "A") (number "1")) (pin passive line (at 1 0 180) (length 1) (name "B") (number "2")))))'
    placed='(symbol (lib_id "Device:R") (at 10 10 0) (unit 1) (property "Reference" "R1") (property "Value" "1k"))'
    child_source='(kicad_sch (uuid "child") '+lib+placed+' (hierarchical_label "H" (at 9 10 0)) (label "LOCAL" (at 11 10 0)) (no_connect (at 10 10)))'
    parent_source='(kicad_sch (uuid "root") '+lib+' (wire (pts (xy 0 0) (xy 4 0))) (wire (pts (xy 2 -2) (xy 2 2))) (global_label "GLOBAL" (at 0 0 0)) (label "LOCAL" (at 2 -2 0)) (sheet (at 20 20) (size 5 5) (uuid "kid") (property "Sheetname" "Child") (property "Sheetfile" "child.kicad_sch") (pin "H" input (at 4 0 0))))'
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);(td/'root.kicad_sch').write_text(parent_source);(td/'child.kicad_sch').write_text(child_source)
        ex=Extractor();ex.load_board('a',td/'root.kicad_sch','A');ex.load_board('b',td/'root.kicad_sch','B');a=ex.finalize()
        # Crossing segments with no explicit point at their crossing stay apart.
        sh=a['sheets']['a_root'];assert sh['drawing']['wires'][0]['net']!=sh['drawing']['wires'][1]['net']
        comp=a['components']['a_R1'];pins={p['number']:p for p in comp['pins']}
        assert len(pins)==3 and pins['3']['noConnect']
        assert pins['1']['net']==sh['drawing']['wires'][0]['net'] # hierarchy parent pin -> H
        assert pins['2']['net']!=sh['drawing']['wires'][1]['net'] # LOCAL is sheet-scoped
        ga=next(n for n in a['nets'].values() if n['board']=='a' and n['name']=='GLOBAL')
        gb=next(n for n in a['nets'].values() if n['board']=='b' and n['name']=='GLOBAL')
        assert ga['id']!=gb['id'] and all(a['components'][p['component']]['board']=='a' for p in ga['pins'])
        assert all(a['meta']['coverage'].values())
        # Adding an explicit junction makes a crossing electrically connected.
        (td/'root.kicad_sch').write_text(parent_source[:-1]+' (junction (at 2 0)))')
        ex=Extractor();ex.load_board('a',td/'root.kicad_sch','A');a=ex.finalize();w=a['sheets']['a_root']['drawing']['wires'];assert w[0]['net']==w[1]['net']

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--control',type=Path);ap.add_argument('--power',type=Path);ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'data');ap.add_argument('--self-test',action='store_true')
    args=ap.parse_args();self_test()
    if args.self_test and not(args.control or args.power):print('Extractor invariant tests passed');return
    if not(args.control or args.power):ap.error('Provide --control and/or --power root schematic')
    ex=Extractor(args.output/'..'/'sources')
    if args.control:ex.load_board('control',args.control,'MIRA Control')
    if args.power:ex.load_board('power',args.power,'MIRA Power')
    atlas=ex.finalize();args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'atlas.json').write_text(json.dumps(atlas,ensure_ascii=False,separators=(',',':')))
    (args.output/'atlas.js').write_text('/* Generated from reachable KiCad source. See coverage.json and tools/extract_kicad.py. */\nwindow.MIRA_ATLAS='+json.dumps(atlas,ensure_ascii=False,separators=(',',':'))+';\n')
    (args.output/'coverage.json').write_text(json.dumps(ex.coverage,ensure_ascii=False,indent=2))
    print(json.dumps({'stats':atlas['stats'],'coverageChecks':ex.coverage['checks'],'unresolved':len(ex.coverage['unresolved'])},indent=2))
    if ex.coverage['unresolved']:print(json.dumps(ex.coverage['unresolved'][:8],indent=2))

if __name__=='__main__':main()
