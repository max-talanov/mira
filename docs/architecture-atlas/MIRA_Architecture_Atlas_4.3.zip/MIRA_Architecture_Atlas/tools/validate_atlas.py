#!/usr/bin/env python3
"""Audit MIRA atlas extraction and run source-based graph fixtures.

Run after extract_kicad.py. Reports source coverage and graph invariants; does not
perform electrical-rule checking or certify hardware correctness.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import tempfile
from extract_kicad import Extractor, parse, children, child, props, self_test


def fixture_geometry():
    """Hand-specified absolute terminals exercise all orthogonal orientations.

    Expected coordinates are literal fixture annotations, not produced by the
    transform function under test. The common unit and alternative symbol body
    are included to catch common-pin loss and accidental conversion mixing.
    """
    cases=[
        ('A',20,20,0,None, {'1':(18,19),'2':(23,24),'3':(20,20)}),
        ('B',60,20,90,None, {'1':(59,22),'2':(64,17),'3':(60,20)}),
        ('C',100,20,180,None, {'1':(102,21),'2':(97,16),'3':(100,20)}),
        ('D',140,20,270,None, {'1':(141,18),'2':(136,23),'3':(140,20)}),
        ('E',20,60,90,'x', {'1':(19,58),'2':(24,63),'3':(20,60)}),
        ('F',60,60,90,'y', {'1':(61,62),'2':(56,57),'3':(60,60)}),
        ('G',100,60,0,'x', {'1':(98,61),'2':(103,56),'3':(100,60)}),
        ('H',140,60,0,'y', {'1':(142,59),'2':(137,64),'3':(140,60)}),
    ]
    lib='''(lib_symbols (symbol "Fixture:Asymmetric"
        (symbol "Asymmetric_0_1" (pin passive line (at 0 0 0) (length 0) (name "COMMON") (number "3")))
        (symbol "Asymmetric_1_1"
            (pin input line (at -2 1 0) (length 1) (name "A") (number "1"))
            (pin output line (at 3 -4 180) (length 1) (name "B") (number "2")))
        (symbol "Asymmetric_1_2" (pin input line (at 50 50 0) (length 1) (name "ALT") (number "99")))))'''
    forms=[]
    for suffix,x,y,angle,mirror,expected in cases:
        mi='(mirror '+mirror+')' if mirror else ''
        forms.append(f'(symbol (lib_id "Fixture:Asymmetric") (at {x} {y} {angle}) {mi} (unit 1) (property "Reference" "U{suffix}") (property "Value" "Test"))')
        for number,(px,py) in expected.items():
            if number=='3':forms.append(f'(no_connect (at {px} {py}))')
            else:forms.append(f'(label "{suffix}_{number}" (at {px} {py} 0))')
    text='(kicad_sch (uuid "fixture") '+lib+' '.join(forms)+')'
    with tempfile.TemporaryDirectory() as td:
        path=Path(td)/'geometry.kicad_sch';path.write_text(text)
        ex=Extractor();ex.load_board('fixture',path,'Fixture');a=ex.finalize()
        for suffix,x,y,angle,mirror,expected in cases:
            pins={p['number']:p for p in a['components']['fixture_U'+suffix]['pins']}
            assert set(pins)==set(expected),('unit/conversion selection',suffix,pins)
            for number,point in expected.items():
                p=pins[number];assert (p['x'],p['y'])==point,('absolute terminal',suffix,number,p,point)
                if number=='3':assert p['noConnect']
                else:assert a['nets'][p['net']]['name']==suffix+'_'+number,('label assignment',suffix,number)
        assert len(a['sheets']['fixture_geometry']['drawing']['noConnects'])==8


def fixture_power_semantics():
    powerlib='''(lib_symbols
        (symbol "Fixture:Power" (power global) (symbol "Power_1_1" (pin power_in line (at 0 0 270) (length 0) (name "") (number "1"))))
        (symbol "Fixture:Logic" (symbol "Logic_1_1" (pin power_in line (at 0 0 270) (length 0) (hide yes) (name "VCC") (number "1")))))'''
    def symbol(lib,ref,val,x):return f'(symbol (lib_id "Fixture:{lib}") (at {x} 10 0) (unit 1) (property "Reference" "{ref}") (property "Value" "{val}"))'
    content='(kicad_sch (uuid "pwr") '+powerlib+symbol('Power','#PWR1','+3V3_TEST',10)+symbol('Power','#PWR2','+3V3_TEST',30)+symbol('Logic','U1','Logic',50)+symbol('Logic','U2','Logic',70)+')'
    with tempfile.TemporaryDirectory() as td:
        path=Path(td)/'power_fixture.kicad_sch';path.write_text(content);ex=Extractor();ex.load_board('f',path,'Fixture');a=ex.finalize()
        def pn(ref):return next(c for c in a['components'].values() if c['ref']==ref)['pins'][0]['net']
        assert pn('#PWR1')==pn('#PWR2') and a['nets'][pn('#PWR1')]['name']=='+3V3_TEST'
        assert pn('U1')==pn('U2') and a['nets'][pn('U1')]['name']=='VCC'
        assert pn('U1')!=pn('#PWR1')


def audit(atlas_path):
    a=json.loads(atlas_path.read_text());base=atlas_path.parent.parent
    c=json.loads((atlas_path.parent/'coverage.json').read_text());checks={}
    expected_counts=collections.Counter();source_sheets=set()
    for source in a['meta']['sources']:
        snapshot=base/source['snapshot'];raw=snapshot.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==source['sha256'],('source SHA256 mismatch',source['file'])
        root=parse(raw.decode());sid=source['sheet'];s=a['sheets'][sid];d=s['drawing'];source_sheets.add(sid)
        counts={'placedSymbols':len(children(root,'symbol')),'wires':len(children(root,'wire')),
                'labels':sum(len(children(root,t)) for t in ('label','global_label','hierarchical_label')),
                'junctions':len(children(root,'junction')),'noConnects':len(children(root,'no_connect'))}
        expected_counts.update(counts)
        assert len(d['symbols'])==counts['placedSymbols'],('source symbols missing',sid)
        assert len(d['wires'])==counts['wires'],('source wire missing',sid)
        assert len(d['labels'])==counts['labels'],('source labels missing',sid)
        assert len(d['junctions'])==counts['junctions'],('source junction missing',sid)
        assert len(d['noConnects'])==counts['noConnects'],('source no-connect missing',sid)
        # Original endpoints are retained exactly, not approximated by layout.
        raw_wires=collections.Counter(tuple(round(float(v),5) for p in child(w,'pts')[1:] for v in p[1:3]) for w in children(root,'wire'))
        out_wires=collections.Counter((w['x1'],w['y1'],w['x2'],w['y2']) for w in d['wires'])
        assert raw_wires==out_wires,('wire geometry changed',sid)
        for sym in d['symbols']:
            assert sym['component'] in a['components']
            for p in sym['pins']:assert p['net'] in a['nets']
        for obj in d['wires']+d['labels']+d['junctions']+d['noConnects']+d['sheetPins']:assert obj['net'] in a['nets']
        if s['parent']:assert sid in a['sheets'][s['parent']]['children']
        assert set(d['symbols'][i]['component'] for i in range(len(d['symbols'])))==set(s['components'])
    assert source_sheets==set(a['sheets'])
    assert all(a['stats'][key]==count for key,count in expected_counts.items())
    checks['sourceHashesAndGeometryMatch']=True;checks['sourceCountsMatch']=True
    checks['sourceHierarchyOnly']=not any('/archive/' in s['snapshot'].lower() or '_restore' in s['snapshot'].lower() for s in a['meta']['sources'])
    physical_pin_nets={}
    for nid,n in a['nets'].items():
        assert nid==n['id'];assert set(n['sheets'])<=set(a['sheets'])
        assert all(a['sheets'][sid]['board']==n['board'] for sid in n['sheets'])
        for p in n['pins']:
            comp=a['components'][p['component']];assert comp['board']==n['board']
            key=(p['component'],p['pin']);physical_pin_nets.setdefault(key,set()).add(nid)
    assert all(len(ids)==1 for ids in physical_pin_nets.values()),'One physical pin split into differing nets'
    checks['oneNetPerPhysicalPin']=True;checks['boardNamespacesIndependent']=True
    for component in a['components'].values():
        for p in component['pins']:
            net=a['nets'][p['net']]
            assert any(t['component']==component['id'] and t['pin']==p['number'] and t['sheet']==p['sheet'] and t['unit']==p['unit'] for t in net['pins'])
    checks['componentNetRoundTrip']=True
    critical={
        ('control','PHY_RXD0'):{('U902','33'),('U500','AB17'),('R909','2'),('R910','1')},
        ('control','PHY_RXC'):{('U902','32'),('U500','W11')},
        ('control','PHY_TXD0'):{('U902','28'),('U500','Y17')},
        ('control','MCU_HSE_CLK'):{('U100','31'),('R101','2')},
        ('power','+24V_RAW'):{('J101','1'),('F201','1'),('R201','1'),('R101','2')},
        ('power','PWR_ARM_PULSE'):{('U2401','13'),('U2603','3'),('R2606','1')},
    }
    tested=[]
    for (board,name),expected in critical.items():
        if not any(b['id']==board for b in a['boards']):continue
        ns=[n for n in a['nets'].values() if n['board']==board and name in (n['aliases']+[n['name']])]
        assert len(ns)==1,('critical named net nonunique',board,name)
        actual={(a['components'][p['component']]['ref'],p['pin']) for p in ns[0]['pins'] if not p['virtual']}
        assert actual==expected,('critical source net changed',board,name,actual,expected)
        tested.append(board+':'+name)
    checks['criticalNetsMatchSourceSnapshot']=True
    assert all(c['checks'].values()) and all(checks.values())
    # Same-name ground networks must remain independent despite their spelling.
    ground=[n for n in a['nets'].values() if n['name']=='GND']
    if len(a['boards'])>1:assert len({n['board'] for n in ground})==len(a['boards'])
    return {'passed':True,'description':'Source extraction audit; not electrical rule checking or hardware certification','checks':checks,
            'graphFixtureChecks':['junction and unjoined crossing','local versus global scope','hierarchical sheet port mapping','independent board namespaces','common pins and selected unit','all orthogonal rotations and mirrors with literal terminal coordinates','hidden power inputs and dynamic power-symbol values','explicit no-connect marker retention'],
            'criticalNets':tested,'sourceCounts':dict(expected_counts),'stats':a['stats'],'unresolvedItems':len(c['unresolved'])}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--atlas',type=Path,default=Path(__file__).resolve().parents[1]/'data'/'atlas.json');ap.add_argument('--report',type=Path);args=ap.parse_args()
    self_test();fixture_geometry();fixture_power_semantics();result=audit(args.atlas)
    if args.report:args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
