#!/usr/bin/env node
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..'),ctx={window:{}},html=fs.readFileSync(path.join(root,'index.html'),'utf8');
for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g))vm.runInNewContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx,{filename:m[1]});
if(!ctx.window.MIRA_TOUR)vm.runInNewContext(fs.readFileSync(path.join(root,'data/presentation-tour.js'),'utf8'),ctx);
const {MIRA_TOUR:tour,MIRA_FUNCTIONAL:f,MIRA_ATLAS:a}=ctx.window;
assert(tour&&f&&a,'Missing presentation/source data');
const chapters=new Set(tour.chapters.map(c=>c.id)),ids=new Set(),covered=new Set(),missingWords=[],refs=new Set(Object.values(a.components).map(c=>c.ref)),netNames=new Set(Object.values(a.nets).map(n=>n.name));
let main=0,detail=0,edges=0,nodeRefs=0,words=0,reverseEdges=0;
for(const step of tour.steps){
 assert(!ids.has(step.id),'Duplicate step '+step.id);ids.add(step.id);
 assert(chapters.has(step.chapterId),'Unknown chapter '+step.id);assert(['main','detail'].includes(step.kind),'Unknown step kind');
 step.kind==='main'?main++:detail++;
 const s=f.scenes[step.sceneId];assert(s&&!s.hidden,'Unknown/hidden scene '+step.id+'/'+step.sceneId);
 if(s.sourceSheetId)covered.add(s.sourceSheetId);
 assert(step.title&&step.lead&&step.why,'Missing explanation '+step.id);assert(/[А-Яа-яЁё]/.test(step.lead),'Non-Russian lead');
 assert(Array.isArray(step.body)&&step.body.length===2&&step.body.every(p=>p.length>45),'Need two substantive paragraphs '+step.id);
 assert(Array.isArray(step.path)&&step.path.length>=2,'Missing path '+step.id);
 for(const id of step.nodeIds||[]){assert(s.nodes.some(n=>n.id===id),'Unknown highlighted node '+step.id+'/'+id);nodeRefs++;}
 for(const id of step.edgeIds||[]){assert(s.edges.some(e=>e.id===id),'Unknown highlighted edge '+step.id+'/'+id);edges++;}
 for(const [id,direction] of Object.entries(step.edgeDirections||{})){assert(step.edgeIds.includes(id),'Unselected direction override '+step.id+'/'+id);assert(['forward','reverse'].includes(direction),'Invalid flow override');reverseEdges++;}
 if(s.edges.length&&step.kind==='main')assert(step.edgeIds.length,'Main step has no highlighted signal '+step.id);
 if(step.storyId){const st=f.scenarios.find(st=>st.id===step.storyId);assert(st&&st.sceneId===s.id,'Unknown/wrong local story '+step.id);assert(Number.isInteger(step.storyStep)&&st.steps[step.storyStep],'Unknown story step '+step.id);}
 assert((step.source.sheetId||null)===(s.sourceSheetId||null),'Incorrect source binding '+step.id);
 for(const netId of step.source.netIds)assert(a.nets[netId],'Unknown source net '+step.id+'/'+netId);
 const text=[step.title,step.lead,...step.body,step.why,...step.path].join(' ');words+=text.split(/\s+/).length;
 for(const ref of text.match(/\b[UQJTRCFDY]\d+\b/g)||[])assert(refs.has(ref),'Unknown component designator '+step.id+'/'+ref);
 for(const token of text.match(/\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b/g)||[]){if(netNames.has(token)||[...netNames].some(n=>n.startsWith(token))||Object.values(a.sheets).some(s=>s.name===token)||token==='XADC')continue;missingWords.push({step:step.id,token});}
}
const expected=new Set(Object.values(f.scenes).filter(s=>!s.hidden&&s.sourceSheetId).map(s=>s.sourceSheetId));
for(const id of expected)assert(covered.has(id),'Missing source sheet '+id);
assert(expected.size===77&&covered.size===77,'Expected all 77 source sheets');
const mains=tour.steps.filter(s=>s.kind==='main');assert(mains[0].sceneId==='system'&&mains.at(-1).sceneId==='system','Narrative needs global start/finish');
assert(mains.some(s=>s.sceneId.includes('300_INPUT_EFUSE'))&&mains.some(s=>s.sceneId.includes('2000_ADC_CONVERTER'))&&mains.some(s=>s.id==='main-39'&&s.edgeDirections),'Missing full power-to-result route');
assert(missingWords.length===0,'Non-source named identifiers: '+JSON.stringify(missingWords));
const report={passed:true,steps:tour.steps.length,mainSteps:main,detailSteps:detail,chapters:chapters.size,sourceSheetsCovered:covered.size,expectedSourceSheets:expected.size,highlightedNodeReferences:nodeRefs,highlightedEdgeReferences:edges,explicitDirectionOverrides:reverseEdges,words,manualNavigationOnly:true,sourceIdentifiersVerified:true,storyBindingsVerified:true};
console.log(JSON.stringify(report,null,2));
if(process.argv.includes('--report'))fs.writeFileSync(path.join(root,'data/presentation-content-validation.json'),JSON.stringify(report,null,2)+'\n');
