"""Role-based presentation geometry over immutable functional identities.

This pass only changes visual layout. It does not add electrical connections,
change net membership, rename source items, or rewrite stories. It may run after
sheet-name assignment in the generator or patch existing split scene files.
"""
from pathlib import Path
from collections import Counter
import json, re, math

VERSION=2


def apply_semantic_layouts(scenes):
    def place(s, positions, kind, label):
        byid={n['id']:n for n in s['nodes']}
        for nid, spec in positions.items():
            if nid not in byid: continue
            x,y,role,*dims=spec
            n=byid[nid]
            source=bool(n.get('sourceSheetName'))
            default={'primary':(350,174) if source else (320,164),
                     'support':(300,162) if source else (240,124),
                     'gateway':(320,164) if source else (250,136),
                     'bank':(320,166) if source else (260,140),
                     'interface':(320,166) if source else (260,140)}
            w,h=dims if dims else default[role]
            n.update(x=x,y=y,w=w,h=h,layoutRole=role)
        assert set(byid)==set(positions),(s['id'],'Unplaced nodes',set(byid)-set(positions))
        s['layout']={'version':VERSION,'kind':kind,'label':label,'geometryOnly':True}
        s.pop('fitBoundsStrict',None)
        s['regions']=[]
        for e in s['edges']:
            for key in ('waypoints','fromSide','toSide','sourceSide','targetSide','portal'):
                e.pop(key,None)
        update_bounds(s)
    def coords(items): return {nid:spec for nid,*spec in items}
    def custom(s,positions,kind,label): place(s,positions,kind,label)
    def region(s,title,ids,kind='primary',subtitle=''):
        ns=[n for n in s['nodes'] if n['id'] in ids]
        if not ns:return
        x=min(n['x'] for n in ns)-28;y=min(n['y'] for n in ns)-54
        r={'x':x,'y':y,'w':max(n['x']+n['w'] for n in ns)-x+28,
           'h':max(n['y']+n['h'] for n in ns)-y+25,'title':title,'kind':kind,'nodeIds':ids}
        if subtitle:r['subtitle']=subtitle
        s['regions'].append(r)
    for s in scenes.values():
        sid=s['id']; ns=s['nodes']; ids=[n['id'] for n in ns]; idset=set(ids)
        if sid=='system':
            custom(s,{
                'host':(40,300,'gateway',250,145),'links':(510,295,'interface',370,162),
                'fpga':(1100,280,'primary',330,184),'drive':(1620,285,'bank',270,160),
                'matrix':(1620,620,'primary',330,180),'readout':(1090,635,'bank',290,152),
                'mcu':(1085,-90,'primary',290,150),'safety':(480,650,'support',280,140),
                'supply':(40,-80,'gateway',250,140),'power':(500,-90,'primary',320,160)
            },'system-loop','Главный тракт, управление и отдельная ветвь питания')
            region(s,'Данные и воздействие',['host','links','fpga','drive','matrix','readout'])
        elif sid=='power':
            custom(s,{'input':(40,185,'gateway',300,150),'primary':(530,160,'primary',340,174),
                'secondary':(1110,160,'primary',340,174),'program':(1125,565,'bank',310,150),
                'supervisor':(530,565,'primary',340,174),'monitor':(40,590,'support',300,150)},
                'power-tree','Путь энергии сверху, контроль и разрешения снизу')
        elif sid=='control':
            custom(s,{'boundary':(40,60,'gateway',300,150),'host':(510,60,'primary',320,164),
                'fpga':(1010,45,'primary',340,188),'sources':(1530,60,'bank',300,156),
                'routing':(1500,465,'primary',360,190),'readout':(990,480,'bank',320,165),
                'regulation':(480,470,'bank',320,164),'safety':(30,485,'support',290,150)},
                'control-loop','Команды, воздействие и возврат результатов')
        elif sid=='control_900_FPGA_ETHERNET_AND_MCU_INTERFACE':
            custom(s,{'connector':(40,230,'gateway',250,138),'isolation':(450,230,'interface',250,148),
                'phy':(870,215,'primary',350,184),'fpga':(1450,215,'primary',350,184),
                'management':(1460,570,'support',260,140),'support':(870,570,'support',260,140)},
                'signal-with-branches','Физический сигнал превращается в цифровые данные')
            region(s,'Путь сигнала',['connector','isolation','phy','fpga'])
        elif sid=='control_700_FPGA_USB3_FIFO_INTERFACE':
            custom(s,{'connector':(40,100,'gateway'),'protection':(510,95,'interface',270,148),
                'orientation':(1040,85,'primary',320,164),'bridge':(1030,510,'primary',340,180),
                'fpga':(510,525,'primary',320,164),'support':(40,540,'support',270,132)},
                'folded-process','Путь от кабеля к словам параллельного интерфейса')
        elif sid=='control_100_MCU_POWER_CLOCKS_AND_DEBUG':
            custom(s,{'host':(565,305,'primary',350,190),'fast':(40,80,'support',260,140),
                'slow':(40,580,'support',260,140),'debug':(1180,80,'gateway',280,148),
                'start':(1180,580,'support',280,148),'supply':(590,-80,'support',300,136)},
                'processor-hub','Контроллер в центре, обслуживающие функции вокруг')
        elif sid=='control_200_MCU_FMC_AND_SDRAM':
            custom(s,{'host':(40,160,'primary'),'bus':(590,180,'interface',280,145),
                'memory':(1140,160,'primary'),'bypass':(1160,530,'support',280,132)},
                'memory-bus','Обмен по шине и отдельная поддержка питания')
        elif sid=='control_300_MCU_QSPI_MICROSD_AND_CONTROL':
            custom(s,{'host':(40,280,'primary',350,180),'flash':(710,40,'bank',300,150),
                'card':(710,520,'gateway',300,150),'protect':(1210,530,'support',270,136)},
                'storage-branches','Два независимых вида памяти вокруг контроллера')
        elif sid=='control_600_FPGA_CONFIGURATION_AND_XADC':
            custom(s,{'fpga':(600,300,'primary',350,190),'flash':(40,90,'bank',300,150),
                'jtag':(40,590,'gateway',280,145),'recover':(1220,90,'support',300,145),
                'filter':(1220,590,'support',300,145)},
                'configuration-hub','Загрузка, восстановление и служебное питание ПЛИС')
        elif sid=='control_800_FPGA_DDR3L_AND_REFERENCE_CLOCK':
            custom(s,{'fpga':(430,230,'primary',330,184),'memory':(1130,230,'primary',340,184),
                'clock':(40,20,'support',250,140),'termination':(1145,610,'support',310,140)},
                'memory-bus','Обмен с памятью, тактирование и согласование')
        elif sid=='control_1000_DAC_BL0_31_AND_BUFFERS':
            pos={}
            for i in range(4):
                pos['dac'+str(i)]=(40+i*440,80,'bank',290,145)
                pos['buffer'+str(i)]=(40+i*440,510,'bank',290,155)
            custom(s,pos,'parallel-banks','Четыре одинаковых канала по восемь линий')
            region(s,'ЦАП · четыре банка',['dac0','dac1','dac2','dac3'],'control')
            region(s,'Буферы · выходы к матрице',['buffer0','buffer1','buffer2','buffer3'],'primary')
        elif sid=='control_1100_DAC_SERVICE_AND_FORMING':
            custom(s,{'commands':(40,80,'primary',320,164),'buffer':(690,80,'bank',300,154),
                'forming':(40,520,'primary',320,164),'formbuffer':(690,520,'bank',300,154)},
                'parallel-sources','Служебные воздействия и FORMING отдельными ветвями')
        elif sid=='control_1300_MATRIX_FPGA_CONTROL_AND_INTERLOCKS':
            custom(s,{'fpga':(40,280,'gateway',280,150),'capture':(560,40,'interface',300,150),
                'compare':(1120,40,'support',290,146),'permissions':(1120,540,'primary',340,176),
                'decode':(550,545,'primary',330,176)},
                'interlock-loop','Запрос, фиксация, проверка и разрешённое действие')
        elif sid=='control_1400_MATRIX_SERIAL_CONTROL_REGISTERS':
            custom(s,{'first':(40,140,'gateway',290,150),'second':(600,125,'primary',330,176),
                'last':(1200,140,'interface',300,156)},'serial-chain','Последовательная загрузка 80-битного образа')
        elif sid=='control_1500_MATRIX_BL0_31_SWITCHING':
            custom(s,{f'bank{i}':(40+(i%2)*690,60+(i//2)*410,'bank',330,166) for i in range(4)},
                'bank-array','Четыре равноправных банка коммутации')
        elif sid=='control_1600_MATRIX_SERVICE_SOURCE_BANK_AND_POLARITY_ROUTING':
            custom(s,{'source':(40,80,'gateway',290,150),'bank':(600,80,'primary',330,176),
                'polarity':(1150,80,'interface',300,156),'return':(600,540,'support',320,148)},
                'source-selection','Выбор источника и пути, возврат отдельной ветвью')
        elif sid=='control_1700_MATRIX_WL0_7_DRIVERS_AND_NL0_7_CLAMPS_SELECTOR':
            custom(s,{'word':(40,80,'bank',310,158),'clamp':(40,520,'bank',310,158),
                'selection':(760,295,'primary',340,184),'permit':(780,-80,'support',300,145)},
                'routing-fan-in','Выбор строк и измерительного пути')
        elif sid=='control_1900_ADC_TIA_AND_MONITOR_SELECTOR':
            custom(s,{'current':(40,160,'primary',330,170),'monitor':(610,170,'interface',300,154),
                'buffer':(1190,160,'primary',330,170),'range':(55,575,'support',300,140)},
                'measurement-path','Ток преобразуется в напряжение, затем выбирается сигнал')
        elif sid=='control_2000_ADC_CONVERTER_AND_PRECISION_REFERENCES':
            custom(s,{'monitor':(40,80,'bank',280,145),'differential':(570,80,'primary',330,170),
                'adc':(1170,80,'primary',340,184),'reference':(570,540,'support',300,145),
                'supply':(1190,550,'support',300,140)},
                'converter-with-support','Подготовка сигнала, АЦП, опорное напряжение и питание')
        elif sid=='control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE':
            custom(s,{'commands':(40,60,'gateway',280,146),'sense':(40,550,'interface',280,146),
                'control':(610,285,'primary',350,184),'drive':(1210,300,'primary',330,170),
                'reset':(640,-90,'support',290,140)},
                'feedback-control','Уставка и измерение сходятся в контуре регулирования')
        elif sid=='control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE':
            custom(s,{'compare':(40,150,'gateway',290,150),'qualify':(600,140,'interface',310,162),
                'remember':(1180,140,'primary',340,176),'inhibit':(1185,570,'support',330,150)},
                'latched-protection','Обнаружение, подтверждение, память аварии и запрет')
        elif idset >= {'input','convert','filter','output'}:
            pos={'input':(40,180,'gateway',230,128),'convert':(510,155,'primary',320,176),
                 'filter':(1060,180,'interface',250,140),'output':(1540,180,'gateway',250,140)}
            if 'enable' in idset:pos['enable']=(535,560,'support',270,138)
            custom(s,pos,'power-conversion','Путь энергии и отдельный вход разрешения')
            region(s,'Преобразование питания',['input','convert','filter','output'],'power')
        elif sid=='power-supervisor':
            custom(s,{'sheet2400':(600,340,'primary',380,190),'sheet2500':(40,40,'support'),
                'sheet2600':(40,650,'primary',350,178),'sheet2700':(1200,40,'bank'),
                'sheet2800':(1200,650,'bank'),'sheet2900':(40,350,'interface'),
                'sheet3000':(600,40,'interface'),'sheet3100':(1770,345,'interface'),
                'sheet3200':(600,920,'support'),'sheet3300':(1200,960,'gateway')},
                'supervision-hub','Контроллер, проверки, разрешения и интерфейс')
        elif sid=='power-monitoring':
            custom(s,{'sheet3400':(40,40,'bank'),'sheet3500':(40,380,'bank'),
                'sheet3600':(40,720,'bank'),'sheet3700':(490,40,'bank'),
                'sheet3800':(490,720,'bank'),'sheet3900':(940,365,'primary',350,190),
                'sheet4000':(1490,380,'interface')},
                'telemetry-fan-in','Параллельные измерения сходятся к мультиплексорам')
        elif sid=='control-routing':
            custom(s,{'sheet1300':(40,300,'primary',350,180),'sheet1400':(520,70,'interface',330,174),
                'sheet1500':(1010,70,'bank',330,174),'sheet1600':(520,620,'bank',330,174),
                'sheet1700':(1010,620,'bank',330,174),'sheet1800':(1490,320,'primary',350,190)},
                'matrix-routing','Разрешённые команды, банки ключей и разъём матрицы')
        elif sid=='control-fpga':
            custom(s,{'sheet500':(40,60,'support'),'sheet600':(600,310,'primary',360,180),
                'sheet700':(1170,60,'gateway',350,174),'sheet800':(40,620,'bank'),
                'sheet900':(1170,620,'gateway',350,174)},
                'fpga-domains','Питание, конфигурация, память и внешние интерфейсы')
        elif sid=='control-sources':
            custom(s,{'sheet1000':(40,70,'bank',360,180),'sheet1100':(40,570,'bank',360,180),
                'sheet1200':(850,300,'primary',380,190)},
                'source-branches','Управление двумя группами аналоговых источников')
        elif sid=='control-host':
            custom(s,{'sheet100':(40,240,'primary',430,220),
                'sheet200':(690,40,'bank',350,180),
                'sheet300':(690,465,'bank',350,180)},
                'controller-and-storage','Основной контроллер и две группы памяти')
            region(s,'Контроллер',['sheet100'])
            region(s,'Память и периферия',['sheet200','sheet300'])
        elif sid=='power-input':
            custom(s,{'sheet100':(40,210,'gateway',330,176),
                'sheet200':(520,210,'interface',340,176),
                'sheet300':(1030,180,'primary',430,220),
                'sheet400':(1630,210,'interface',350,176)},
                'input-protection-trunk','Входной тракт с выделенной управляемой защитой')
        elif sid=='power-primary':
            # This source section has no extracted inter-sheet edges: spatial
            # groups explain purpose without inventing a power-tree conductor.
            custom(s,{'sheet500':(440,40,'primary',430,220),
                'sheet600':(40,700,'support',330,174),
                'sheet700':(40,365,'primary',400,204),
                'sheet800':(1030,40,'primary',410,204),
                'sheet900':(1030,385,'primary',410,204),
                'sheet1000':(1030,775,'bank',350,182),
                'sheet1100':(1530,775,'bank',350,182)},
                'primary-purpose-groups','Дежурная часть, системное питание и аналоговые ветви')
            region(s,'Дежурная часть',['sheet500'])
            region(s,'Система и USB',['sheet600','sheet700'])
            region(s,'Промежуточные шины',['sheet800','sheet900'])
            region(s,'Биполярное аналоговое питание',['sheet1000','sheet1100'])
        elif sid=='power-secondary':
            custom(s,{'sheet1200':(380,300,'primary',430,220),
                'sheet1300':(40,40,'support',330,172),
                'sheet1400':(40,640,'support',330,172),
                'sheet1500':(520,40,'bank',350,182),
                'sheet1600':(1070,70,'primary',410,210),
                'sheet1800':(1110,475,'support',330,172),
                'sheet1700':(1650,70,'interface',330,174),
                'sheet1900':(1650,395,'bank',350,182),
                'sheet2000':(1650,720,'bank',350,182)},
                'secondary-domain-clusters','Домены ПЛИС, памяти и малошумящего аналогового питания')
            region(s,'ПЛИС · ядро и вспомогательные домены',['sheet1200','sheet1300','sheet1400','sheet1500'])
            region(s,'Память DDR',['sheet1600','sheet1800'])
            region(s,'Аналоговые домены',['sheet1900','sheet2000'])
        elif sid=='power-program':
            custom(s,{'sheet2100':(40,65,'bank',380,200),
                'sheet2200':(40,470,'bank',380,200),
                'sheet2300':(800,265,'gateway',350,184)},
                'bipolar-program-branches','Две равноправные полярности и отдельный выход к нагрузке')
        elif sid=='power_200_INPUT_FUSE_PROTECTION':
            custom(s,{'fuse':(40,240,'primary',360,190),
                'transient':(640,50,'interface',270,145),
                'indicate':(640,480,'support',245,128)},
                'fuse-with-side-protection','Предохранитель в основном пути, TVS и индикация сбоку')
        elif sid in {'power_2100_PROGRAM_POSITIVE','power_2200_PROGRAM_NEGATIVE'}:
            secondary='stop' if 'stop' in idset else 'clamp'
            custom(s,{'switch':(620,220,'primary',370,194),
                'control':(40,60,'interface',270,144),
                secondary:(55,510,'support',250,132)},
                'switch-with-control','Силовые ключи, команда управления и отдельная защита')
        elif sid=='power_2500_PM_WATCHDOGS':
            custom(s,{'pm':(40,70,'primary',350,184),
                'host':(650,70,'primary',350,184),
                'reset':(380,500,'support',250,130)},
                'parallel-watchdogs','Два независимых сторожевых канала и общая функция сброса')
        elif sid in {'power_2700_PM_ENABLE_GATES_PRIMARY','power_2800_PM_ENABLE_GATES_AUXILIARY'}:
            custom(s,{'first':(40,70,'bank',350,184),
                'second':(670,70,'bank',350,184),
                'default':(395,510,'support',250,132)},
                'enable-banks-with-default','Две группы разрешений; начальные состояния сбоку от основного пути')
        elif sid in {'power_3000_PM_RAIL_READY','power_3100_PM_COMMAND_READY'}:
            custom(s,{'0':(40,60,'bank',290,154),
                '1':(40,450,'bank',290,154),
                '2':(720,240,'primary',370,194)},
                'readiness-combiner','Две группы условий сходятся в итоговую готовность')
        elif sid=='power_2600_PM_PERMIT_INTERLOCKS':
            custom(s,{'stop':(40,190,'gateway',270,145),
                'qualify':(560,160,'primary',370,194),
                'memory':(1140,165,'interface',290,158),
                'output':(1140,535,'interface',290,150)},
                'permit-qualification','Условия безопасности, память состояния и выход разрешения')
        elif sid in {'power_3500_MONITOR_INPUT_AON_USB_SYS','power_3600_MONITOR_FPGA_ANA_AFE',
                     'power_3700_MONITOR_FPGA_CORE_AUX_IO','power_3800_MONITOR_DDR_PHY_ANALOG'}:
            # These are parallel instances of the same measurement function,
            # not an arbitrary main/secondary hierarchy inferred from degree.
            patterns={3:[(40,60),(630,210),(1220,60)],
                      4:[(40,60),(620,60),(1220,60),(620,490)]}
            custom(s,{nid:(*xy,'bank',310,164) for nid,xy in zip(ids,patterns[len(ids)])},
                'parallel-measurement-banks','Равноправные измерительные каналы разных шин')
            region(s,'Параллельные измерения тока и напряжения',ids,'analog')
        elif sid=='control_500_FPGA_POWER_AND_DECOUPLING':
            custom(s,{'core':(590,250,'primary',370,198),
                'reservoir':(40,70,'support',250,132),
                'aux':(40,545,'support',260,140)},
                'fpga-power-support','Домен ядра и отдельные группы локального питания')
        elif sid=='control_400_SYSTEM_POWER_AND_SUPERVISION_INTERFACE':
            custom(s,{'connector':(40,235,'gateway',340,184),
                'host':(690,50,'primary',360,190),
                'permit':(690,500,'interface',270,146)},
                'boundary-receivers','Вход питания и два отдельных приёмника состояния')
        elif sid in {'power_2900_PM_ANALOG_POWER_GOOD','power_3200_PM_NEGATIVE_OVERCURRENT'}:
            custom(s,{'threshold':(40,75,'support',250,134),
                'compare':(620,230,'primary',360,194)},
                'comparison-with-reference','Компаратор и отдельная цепь задания порогов')
        elif sid=='power_3900_TELEMETRY_MULTIPLEXERS':
            custom(s,{'current':(40,100,'bank',330,174),
                'voltage':(690,100,'bank',330,174)},
                'paired-measurement-selectors','Равноправный выбор тока и напряжения одним адресом')
        elif sid=='control_1200_DAC_FPGA_CONTROL_INTERFACE':
            custom(s,{'fpga':(40,100,'primary',360,194),
                'bias':(680,360,'support',250,132)},
                'control-with-safe-defaults','Основной интерфейс управления и начальные состояния')
        elif sid=='control_1800_MATRIX_CROSSBAR_SOCKET_AND_BIAS':
            custom(s,{'socket':(40,100,'primary',370,198),
                'bias':(720,350,'support',250,132)},
                'connector-with-bias','Разъём матрицы и вспомогательная настройка смещения')
        elif sid=='power_100_INPUT_CONNECTOR':
            custom(s,{'connector':(40,100,'primary',350,184),
                'indicators':(660,360,'support',250,132)},
                'connector-with-indication','Разъём во входном пути, индикация отдельной ветвью')
        elif s.get('kind')=='section' and not s['edges']:
            # These source sheets are functional islands: no rail edges are invented.
            cols=3 if len(ns)>4 else 2 if len(ns)>1 else 1
            pos={n['id']:(40+(i%cols)*520,70+(i//cols)*330,'bank' if len(ns)>1 else 'primary',340,178) for i,n in enumerate(ns)}
            custom(s,pos,'functional-islands','Функциональные группы; электрические связи не добавлены')
        else:
            # Topology-aware fallback for small source fragments and section maps.
            degree=Counter()
            for e in s['edges']:degree[e['from']]+=1;degree[e['to']]+=1
            main=max(ns,key=lambda n:(degree[n['id']],len(n.get('refs',[])))) if ns else None
            count=len(ns); pos={}
            if count==1:
                pos[ids[0]]=(100,90,'primary',360,180)
                kind='single-function';label='Один функциональный узел'
            elif count==2:
                first,second=ids
                pos[first]=(40,180,'primary',340 if ns[0].get('sourceSheetName') else 310,174)
                pos[second]=(760,195,'support' if len(ns[1].get('refs',[]))<len(ns[0].get('refs',[])) else 'interface',320 if ns[1].get('sourceSheetName') else 280,150)
                kind='paired-functions';label='Основной узел и связанная функция'
            elif count==3:
                mid=main['id']; others=[i for i in ids if i!=mid]
                pos[mid]=(560,285,'primary',360 if main.get('sourceSheetName') else 330,180)
                pos[others[0]]=(40,60,'gateway');pos[others[1]]=(40,565,'support')
                kind='functional-hub';label='Главный узел и две связанные функции'
            elif count==4 and max(degree.values(),default=0)>=3:
                mid=main['id'];others=[i for i in ids if i!=mid]
                pos[mid]=(570,300,'primary',360 if main.get('sourceSheetName') else 330,180)
                for nid,p in zip(others,[(40,60),(40,600),(1190,310)]):pos[nid]=(*p,'support' if nid in {'default','support','clamp'} else 'interface')
                kind='functional-hub';label='Центральная функция и боковые ветви'
            else:
                # Equal banks remain equal; flow columns are separated by role.
                columns=3 if count>4 else 2
                for i,n in enumerate(ns):
                    role='primary' if n['id']==main['id'] else 'support' if n['id'] in {'enable','default','support','clamp','indicate'} else 'bank'
                    pos[n['id']]=(40+(i%columns)*570,90+(i//columns)*370,role)
                kind='functional-groups';label='Группы по назначению с выделением главной функции'
            custom(s,pos,kind,label)
        # A visible, consistent hierarchy matters even when source sheet titles
        # require a minimum width. Equal parallel banks deliberately stay equal.
        for n in ns:
            role=n.get('layoutRole');source=bool(n.get('sourceSheetName'))
            if role=='primary':
                n['w']=max(n['w'],410 if source else 350)
                n['h']=max(n['h'],210 if source else 184)
            elif role=='support':
                n['w']=max(320,min(n['w'],340)) if source else min(n['w'],260)
                n['h']=max(170,min(n['h'],180)) if source else min(n['h'],140)
        for r in s.get('regions',[]):
            members=[n for n in ns if n['id'] in r.get('nodeIds',[])]
            if members:
                r['x']=min(n['x'] for n in members)-28;r['y']=min(n['y'] for n in members)-54
                r['w']=max(n['x']+n['w'] for n in members)-r['x']+28
                r['h']=max(n['y']+n['h'] for n in members)-r['y']+25
        update_bounds(s)
        # Only distant auxiliary links become paired named continuation markers.
        # Main data / analog paths remain continuously drawn on this canvas.
        portal_ids={
            'system':{'power_fpga','power_drive','power_mcu','safety_power'},
            'control':{'boundary_routing','safety_routing'},
            'power':{'supervisor_secondary','supervisor_program'},
        }.get(sid,set())
        lookup={n['id']:n for n in ns}
        pnum=0
        for e in s['edges']:
            a,b=lookup[e['from']],lookup[e['to']]
            dx=(b['x']+b['w']/2)-(a['x']+a['w']/2);dy=(b['y']+b['h']/2)-(a['y']+a['h']/2)
            distance=math.hypot(dx,dy)
            # Section rail-ready and shared protection lines otherwise obscure the core.
            auxiliary=(e['type'] in {'power','fault','control'} and distance>1250 and s.get('kind')=='section')
            if e['id'] in portal_ids or auxiliary:
                pnum+=1
                exact=e.get('netLabels',[])
                title=exact[0] if len(exact)==1 else e.get('shortLabel') or e.get('label') or 'Связь'
                e['portal']={'code':'P'+str(pnum),'title':title}
            # Prefer a clear row/column connection; never infer new direction.
            if abs(dx)>abs(dy)*1.3:
                e['fromSide']='right' if dx>0 else 'left';e['toSide']='left' if dx>0 else 'right'
            else:
                e['fromSide']='bottom' if dy>0 else 'top';e['toSide']='top' if dy>0 else 'bottom'
        update_bounds(s)
    return scenes


def update_bounds(s):
    boxes=s['nodes']+s.get('regions',[])
    if not boxes:return
    x=min(n['x'] for n in boxes)-40;y=min(n['y'] for n in boxes)-35
    s['bounds']={'x':x,'y':y,'w':max(n['x']+n['w'] for n in boxes)-x+40,
                 'h':max(n['y']+n['h'] for n in boxes)-y+40}


def identity_view(scene):
    scene=json.loads(json.dumps(scene))
    for key in ('bounds','regions','layout','fitBoundsStrict'):scene.pop(key,None)
    for n in scene['nodes']:
        for key in ('x','y','w','h','layoutRole'):n.pop(key,None)
    for e in scene['edges']:
        for key in ('waypoints','fromSide','toSide','sourceSide','targetSide','portal'):e.pop(key,None)
    return scene


def patch_existing(root):
    root=Path(root)
    scenes={};paths={}
    for p in sorted((root/'data/maps').glob('*.js')):
        m=re.search(r'\]=\s*(\{[\s\S]*\});?\s*$',p.read_text())
        if m:
            s=json.loads(m[1]);scenes[s['id']]=s;paths[s['id']]=p
    before={sid:identity_view(s) for sid,s in scenes.items()}
    apply_semantic_layouts(scenes)
    identity_differences=[sid for sid,s in scenes.items() if identity_view(s)!=before[sid]]
    assert not identity_differences,identity_differences
    for sid,s in scenes.items():
        paths[sid].write_text('/* Editable functional scene: '+sid+' */\nwindow.MIRA_FUNCTIONAL.scenes['+json.dumps(sid)+']='+json.dumps(s,ensure_ascii=False,indent=2)+';\n')
    report=validate(scenes)
    report.update(comparedScenes=len(scenes),sourceAndStoryIdentityPreserved=not identity_differences,identityDifferences=identity_differences)
    (root/'data/semantic-layout-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    assert report['passed'],report
    print(json.dumps(report,ensure_ascii=False))


def validate(scenes):
    errors=[];kinds=Counter();portals=0;sizes=set()
    for sid,s in scenes.items():
        kinds[s['layout']['kind']]+=1
        for i,a in enumerate(s['nodes']):
            sizes.add((a['w'],a['h']))
            for b in s['nodes'][i+1:]:
                if a['x']<b['x']+b['w']+20 and b['x']<a['x']+a['w']+20 and a['y']<b['y']+b['h']+20 and b['y']<a['y']+a['h']+20:
                    errors.append([sid,'overlap',a['id'],b['id']])
        codes=[e['portal']['code'] for e in s['edges'] if e.get('portal')]
        if len(set(codes))!=len(codes):errors.append([sid,'portal code collision'])
        portals+=len(codes)
    return {'passed':not errors,'scenes':len(scenes),'layoutKinds':dict(kinds),'nodeSizes':len(sizes),'pairedContinuations':portals,'noNodeOverlaps':not errors,'errors':errors,'identityChanges':False}

if __name__=='__main__':
    patch_existing(Path(__file__).resolve().parents[1])
