#!/usr/bin/env node
/* Exercise visible particles on every real connection, every story step and overview frame. */
'use strict';
const fs=require('fs'),vm=require('vm');
const harness=fs.readFileSync(__dirname+'/test_manual_playback.js','utf8').split('const A=ctx.MIRA_ATLAS')[0];
const test=String.raw`
Element.prototype.cloneNode=function(deep){const n=new Element(this.tagName);n.attrs={...this.attrs};n.style={...this.style};n._text=this._text;n.hidden=this.hidden;if(deep)this.children.forEach(c=>n.append(c.cloneNode(true)));return n;};
const maps=ctx.MIRA_FUNCTIONAL,scenes=Object.values(maps.scenes),sourceSnapshot=JSON.stringify(maps),failures=[];
const host=new Element('div'),engine=ctx.MiraFunctional.mount(host,{atlas:ctx.MIRA_ATLAS,maps,content:ctx.MIRA_CONTENT,sceneId:'system'});
const check=(ok,reason,context)=>{if(!ok)failures.push({reason,...context});};
const sample=index=>host.querySelectorAll('.mf-particle').slice(index*3,index*3+3).map(p=>({x:Number(p.getAttribute('cx')),y:Number(p.getAttribute('cy')),visible:p.style.display!=='none'}));
const changed=(before,after)=>before.some((p,i)=>Math.hypot(p.x-after[i]?.x,p.y-after[i]?.y)>.05);
let edgeChecks=0,undirectedChecks=0,storyChecks=0,nodeOnlyStorySteps=0,pauseChecks=0,presentationChecks=0,portalChecks=0;
function inspectActive(scene,edgeIds,context){
 frames(1);const indexes=edgeIds.map(id=>scene.edges.findIndex(e=>e.id===id));
 const before=indexes.map(sample);frames(31);const after=indexes.map(sample);
 indexes.forEach((index,i)=>{
  const edge=scene.edges[index];check(index>=0,'Unknown edge in active frame',context);
  check(before[i].length===3&&before[i].every(p=>p.visible&&Number.isFinite(p.x)&&Number.isFinite(p.y)),'Active connection has visible finite particles',{...context,edgeId:edge?.id});
  check(changed(before[i],after[i]),'Playing connection remains static',{...context,edgeId:edge?.id,undirected:!!(edge?.undirected||edge?.direction==='none')});
  check(after[i].some((p,j)=>j&&Math.hypot(p.x-after[i][0].x,p.y-after[i][0].y)>.01),'Connection has nonzero drawable length',{...context,edgeId:edge?.id});
  if(edge?.portal){portalChecks++;const d=host.querySelectorAll('.mf-edge-line')[index]?.getAttribute('d')||'';check((d.match(/M /g)||[]).length===2,'Continuation retains two separate path segments',{...context,edgeId:edge.id});}
 });
 return indexes;
}
for(const scene of scenes){
 engine.setScene(scene.id);const local=maps.scenarios.find(s=>s.sceneId===scene.id);if(local)engine.setScenario(local.id);
 for(const[index,edge]of scene.edges.entries()){
  fire(host.querySelectorAll('.mf-edge-hit')[index]);engine.play();
  inspectActive(scene,[edge.id],{mode:'selected-connection',sceneId:scene.id});edgeChecks++;
  if(edge.undirected||edge.direction==='none'){undirectedChecks++;check(!host.querySelectorAll('.mf-edge')[index]?.querySelector('.mf-edge-arrow'),'Animation invents an arrow on an undirected connection',{sceneId:scene.id,edgeId:edge.id});}
  const beforePause=JSON.stringify(sample(index));engine.pause();frames(1);const paused=JSON.stringify(sample(index));check(paused===beforePause,'Pausing jumps to a different signal position',{sceneId:scene.id,edgeId:edge.id});frames(23);check(JSON.stringify(sample(index))===paused,'Pause does not freeze visible signal',{sceneId:scene.id,edgeId:edge.id});pauseChecks++;
 }
}
for(const scenario of maps.scenarios){
 engine.setScene(scenario.sceneId||'system');engine.setScenario(scenario.id);const scene=maps.scenes[scenario.sceneId||'system'];
 for(const[index,step]of scenario.steps.entries()){
  engine.seek(index);engine.play();const before=engine.getState();
  if(step.edges?.length)inspectActive(scene,step.edges,{mode:'story-step',sceneId:scene.id,storyId:scenario.id,step:index});else{frames(32);nodeOnlyStorySteps++;}
  const after=engine.getState();check(before.stepIndex===after.stepIndex&&before.sceneId===after.sceneId&&JSON.stringify(before.camera)===JSON.stringify(after.camera),'Signal playback changes narration or camera',{storyId:scenario.id,step:index});storyChecks++;
 }
}
async function advance(promise){let done=false,result,error;promise.then(v=>{result=v;done=true;},e=>{error=e;done=true;});for(let i=0;i<2000&&!done;i++){frames(1);await Promise.resolve();}if(error)throw error;assert(done,'Explicit frame resolves');return result;}
(async()=>{
 engine.beginPresentation();
 for(const step of ctx.MIRA_OVERVIEW_TOUR.steps){
  await advance(engine.presentFrame({...step,scenarioId:step.storyId,audience:'general',animateSignals:true,duration:0}));
  const scene=maps.scenes[step.sceneId];if(step.edgeIds?.length)inspectActive(scene,step.edgeIds,{mode:'overview-frame',sceneId:scene.id,stepId:step.id});presentationChecks++;
 }
 engine.setPresentationSignals(false);frames(1);const last=JSON.stringify(host.querySelectorAll('.mf-particle').map(p=>[p.getAttribute('cx'),p.getAttribute('cy')]));frames(60);check(JSON.stringify(host.querySelectorAll('.mf-particle').map(p=>[p.getAttribute('cx'),p.getAttribute('cy')]))===last,'Guided pause restarts motion',{});
 engine.endPresentation();engine.destroy();check(raf.size===0,'Destroy leaks animation frames',{});
 ctx.matchMedia=()=>({matches:true});const reducedHost=new Element('div'),reduced=ctx.MiraFunctional.mount(reducedHost,{atlas:ctx.MIRA_ATLAS,maps,sceneId:'control_700_FPGA_USB3_FIFO_INTERFACE'});
 reduced.setScenario('local-control_700_FPGA_USB3_FIFO_INTERFACE');reduced.seek(1);reduced.play();frames(1);const staticPosition=JSON.stringify(reducedHost.querySelectorAll('.mf-particle').map(p=>[p.getAttribute('cx'),p.getAttribute('cy')]));frames(60);check(JSON.stringify(reducedHost.querySelectorAll('.mf-particle').map(p=>[p.getAttribute('cx'),p.getAttribute('cy')]))===staticPosition,'Reduced motion moves particles',{});reduced.destroy();
 check(JSON.stringify(maps)===sourceSnapshot,'Animation modifies source electrical identities',{});
 const report={passed:failures.length===0,scenes:scenes.length,connectedScenes:scenes.filter(s=>s.edges.length).length,connectionChecks:edgeChecks,undirectedConnectionChecks:undirectedChecks,storySteps:storyChecks,nodeOnlyStorySteps,overviewFrames:presentationChecks,pauseChecks,portalChecks,reducedMotion:true,sourceIdentityPreserved:JSON.stringify(maps)===sourceSnapshot,failures};
 if(process.argv.includes('--report'))fs.writeFileSync(root+'/data/signal-motion-validation.json',JSON.stringify(report,null,2)+'\n');
 const failureKinds=failures.reduce((counts,f)=>(counts[f.reason]=(counts[f.reason]||0)+1,counts),{});console.log(JSON.stringify({...report,failures:failures.slice(0,8),totalFailures:failures.length,failureKinds},null,2));if(failures.length)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});`;
vm.runInNewContext(harness+test,{require,__dirname,console,process},{filename:'signal-motion-real-canvas-test.js'});
