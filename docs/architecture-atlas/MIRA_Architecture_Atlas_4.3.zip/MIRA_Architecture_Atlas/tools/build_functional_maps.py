"""Generate functional teaching maps over the frozen KiCad extraction.

Real component and net identity is retained; functional relationships between
boards are explicitly distinguished from verified electrical nets.
"""
import json, re, math, sys
from pathlib import Path
from collections import defaultdict

ROOT=Path(__file__).resolve().parents[1]
A=json.loads((ROOT/'data/atlas.json').read_text())
S=A['sheets']; C=A['components']; N=A['nets']; scenes={}
LEAVES={k:v for k,v in S.items() if v['components']}
by_num={(s['board'],s['number']):sid for sid,s in LEAVES.items()}
CONTENT={}
for path in (ROOT/'data/modules').glob('*.js'):
    st=path.read_text(); match=re.search(r'\]=\s*(\{[\s\S]*\});?\s*$',st)
    if match:
        CONTENT[path.name.split('-',1)[1][:-3]+'.kicad_sch']=json.loads(match.group(1))

def sid(board,num):
    hits=[k for k,s in LEAVES.items() if s['board']==board and s['file'].startswith(str(num)+'_')]
    assert len(hits)==1,(board,num,hits)
    return hits[0]
def content(sheet): return CONTENT.get(S[sheet]['file'],{})
def refs(board,*names): return [board+'_'+x for x in names if board+'_'+x in C]
def nums(board,prefix,start,end): return refs(board,*[prefix+str(i) for i in range(start,end+1)])
def allrefs(sheet):return [cid for cid in S[sheet]['components'] if not C[cid]['virtual']]
def nets(pattern,board=None,sheet=None):
    candidates=S[sheet]['nets'] if sheet else N
    return [nid for nid in candidates if (not board or N[nid]['board']==board) and re.search(pattern,N[nid]['name'])]
def common_rail(n):
    # The source classifier calls *_POWER UART/permit nets "power" too.
    # Do not discard actual signals merely because that heuristic fired.
    return bool(re.fullmatch(r'GND|AON|SYS3V3|IO3V3|P15|N15|ANA5|ANA3V3|ANA6|CORE1V0|AUX1V8|AUX2V5|DDR1V35|VTT|DDR_VREF|PHY1V05|PHY2V5|USB5|FPGA5V5|PROG_P15|PROG_N15|BUS24(?:_\w+)?|\+24V(?:_\w+)?',n['name']))
def between(a,b,sheet=None,exclude_common=True):
    aa=set(a);bb=set(b);out=[]
    for nid in (S[sheet]['nets'] if sheet else N):
        n=N[nid]
        if n['kind']=='ground' or n['name']=='GND':continue
        if exclude_common and common_rail(n):continue
        pins={p['component'] for p in n['pins'] if not p.get('virtual') and (not sheet or p['sheet']==sheet)}
        if pins&aa and pins&bb:out.append(nid)
    return out
def node(nid,title,description='',refs_=None,role='data',scene=None,sheet=None,x=40,y=40,subtitle=''):
    return dict(id=nid,title=title,subtitle=subtitle,description=description,refs=refs_ or [],role=role,x=x,y=y,w=230,h=124,**({'sceneId':scene} if scene else {}),**({'sheetId':sheet} if sheet else {}))
def edge(eid,src,dst,label,typ='data',netids=None,bi=False,scope='electrical',description='',**kw):
    return dict(id=eid,**{'from':src,'to':dst},label=label,type=typ,nets=list(dict.fromkeys(netids or [])),bidirectional=bi,scope=scope,description=description,**kw)
def layout(nodes,cols=3):
    for i,n in enumerate(nodes): n.update(x=40+(i%cols)*340,y=40+(i//cols)*205)
def scene(sceneid,title,description,nodes_,edges_,board=None,sheet=None,cols=3):
    if not any(n.get('fixed') for n in nodes_):layout(nodes_,cols)
    maxx=max((n['x']+n['w'] for n in nodes_),default=0)+50
    maxy=max((n['y']+n['h'] for n in nodes_),default=0)+65
    scenes[sceneid]=dict(id=sceneid,title=title,subtitle='Follow the function. Open a block to go deeper.',description=description,nodes=nodes_,edges=edges_,bounds=dict(x=0,y=0,w=maxx,h=maxy),**({'board':board} if board else {}),**({'sheetId':sheet} if sheet else {}))
    return scenes[sceneid]
def grouping(sheet,defs,title=None,description=None,explicit=None):
    """defs: functional node id, heading, explanation, exact seeds, optional role.
    Unseeded passives attach to a directly connected function or nearest seeded
    functional block. This grouping changes no electrical connectivity.
    """
    groups=[]; owners={}; physical=allrefs(sheet)
    for d in defs:
        nid,heading,explain,seeds,*rest=d
        seeds=[cid for cid in seeds if cid in physical]
        groups.append(node(nid,heading,explain,seeds,rest[0] if rest else 'data',sheet=sheet))
        for cid in seeds:owners[cid]=nid
    def pos(cid):
        pp=[p for p in C[cid]['pins'] if p['sheet']==sheet]
        return (sum(p['bodyX'] for p in pp)/max(1,len(pp)),sum(p['bodyY'] for p in pp)/max(1,len(pp)))
    centers={g['id']:[pos(c) for c in g['refs']] for g in groups}
    for cid in physical:
        if cid in owners:continue
        px,py=pos(cid);scores={g['id']:0.0 for g in groups}
        for p in C[cid]['pins']:
            nid=p.get('net')
            if p['sheet']!=sheet or not nid:continue
            n=N[nid]
            if n['kind']=='ground' or common_rail(n):continue
            for p2 in n['pins']:
                owner=owners.get(p2['component'])
                if owner and p2['sheet']==sheet:scores[owner]+=1.0/max(1,n.get('physicalPinCount',1))
        for g in groups:
            pts=centers[g['id']]
            dist=min((math.hypot(px-x,py-y) for x,y in pts),default=500)
            scores[g['id']]+=0.10/(1+dist)
        winner=max(groups,key=lambda g:scores[g['id']]);winner['refs'].append(cid)
    es=[]
    if explicit:
        for d in explicit:
            src,dst,label,typ,pat,*rest=d
            ns=nets(pat,sheet=sheet) if isinstance(pat,str) else pat
            es.append(edge(src+'_'+dst+'_'+str(len(es)),src,dst,label,typ,ns,rest[0] if rest else False))
    else:
        for i,a in enumerate(groups):
            for b in groups[i+1:]:
                ns=between(a['refs'],b['refs'],sheet)
                if ns:
                    names=[N[n]['name'] for n in ns]
                    label=netlabel(names)
                    typ=nettype(names)
                    es.append(edge(a['id']+'_'+b['id'],a['id'],b['id'],label,typ,ns,False,description='Grouped exact electrical connections. This summary does not infer signal direction. Open the connection to inspect every member net and pin.',undirected=True,flow='association'))
        if not es:
            # A connector/indicator or controller/bypass leaf may be linked only
            # by its supply rail. Retain that real relation in the teaching map.
            for i,a in enumerate(groups):
                for b in groups[i+1:]:
                    ns=between(a['refs'],b['refs'],sheet,exclude_common=False)
                    if ns:
                        es.append(edge(a['id']+'_'+b['id'],a['id'],b['id'],'Local supply connection','power',ns,False,description='The listed exact nets connect these functional groups. Open source detail for all terminals.',undirected=True,flow='association'))
    purpose=description or content(sheet).get('purpose') or S[sheet].get('description','')
    obj=scene(sheet,title or S[sheet]['title'],purpose,groups,es,S[sheet]['board'],sheet)
    obj['detailPolicy']='All physical source components are assigned to functional blocks. Exact nets and pins remain available in Source detail.'
    obj['sourceComponentCount']=len(physical)
    return obj
def nettype(names):
    text=' '.join(names)
    if re.search(r'FAULT|TRIP|INHIBIT|OC_|STOP|PERMIT',text):return 'fault'
    if re.search(r'RESET|EN_|CMD_|PGR_|PG_|CLK|SCK|CS_|ADDR|SEL|MUX_A|LDAC|LATCH|SCLK|MODE|RUN|ARM',text):return 'control'
    if re.search(r'^MON_|TIA|BL_|WL|NL|VREF|VSET|VREAD|VFORM|WRITE|PROG_|ADC_IN|AIN',text):return 'analog'
    return 'data'
def netlabel(names):
    text=' '.join(names)
    families=[(r'PHY_RX','Received digital data'),(r'PHY_TX','Outgoing digital data'),(r'FMC_','Memory address, data and commands'),(r'MCU_QSPI','Persistent data'),(r'CFG_','Configuration data'),(r'FT_D','32-bit data and handshakes'),(r'DDR_','Memory transfers'),(r'BL_DAC_RAW','Programmed analog voltages'),(r'BL_DAC','Bit-line voltages'),(r'MON_I_','Current measurements'),(r'MON_V_','Voltage measurements'),(r'MUX_','Selected measurement'),(r'OC_|FAULT|TRIP|INHIBIT','Hardware protection'),(r'PERMIT','Permission'),(r'SPI|SDI|SCLK','Serial commands'),(r'SEL|ADDR|MUX_A|LATCH','Selection and held control'),(r'EN_|CMD_','Enable command')]
    for pat,label in families:
        if re.search(pat,text):return label
    return names[0] if len(names)==1 and not names[0].startswith('UNNAMED') else str(len(names))+' electrical connections'

# CONTROL: teaching groups retain exact reference identity in their secondary data.
b='control';r=lambda *x:refs(b,*x);rn=lambda p,a,z:nums(b,p,a,z)
grouping(sid(b,100),[
 ('fast','Main timing reference','The 25 MHz oscillator supplies the host processor clock.',r('Y100'),'control'),
 ('host','Run the experiment','The STM32H745 runs the host application and supervises board operation.',r('U100'),'data'),
 ('debug','Program and inspect','The debug connector lets an external debugger program and inspect the STM32.',r('J100'),'data'),
 ('slow','Low-speed timekeeping','A separate 32.768 kHz crystal supports low-speed clock functions.',r('Y101'),'control'),
 ('start','Reset and boot choice','The reset button restarts the MCU; the boot jumper selects the startup request.',r('J101','SW100'),'control'),
 ('supply','Keep the processor supplied','Local capacitors support the MCU supply and internal regulator.',rn('C',100,124),'power')
],title='Host processor · clocks, startup and debug',explicit=[('fast','host','25 MHz clock','control',r'MCU_HSE_CLK|MCU_HSE_XO'),('slow','host','Low-speed clock','control',r'MCU_LSE_'),('start','host','Reset / boot request','control',r'HOST_RESET_N|MCU_BOOT0'),('debug','host','Debug access','data',r'SWD|SWCLK|SWO',True),('supply','host','Supply and local reservoirs','power',r'^SYS3V3$|MCU_VDDA|MCU_VCAP')])
grouping(sid(b,200),[
 ('host','Request a memory access','The MCU memory controller produces the address and SDRAM command.',r('U100'),'data'),
 ('bus','Condition the memory bus','Series resistors damp address, command and clock transitions.',rn('R',200,222),'control'),
 ('memory','Hold working data','The SDRAM provides 64 MiB of volatile MCU working memory.',r('U200'),'data'),
 ('bypass','Support memory power','Nearby capacitors support the memory supply.',rn('C',200,211),'power')],title='MCU working memory',explicit=[('host','bus','Addresses, clock and commands','control',r'^FMC_(?!D\d)'),('bus','memory','Conditioned bus signals','control',r'^UNNAMED_R2'),('host','memory','16-bit data bus','data',r'^FMC_D\d',True),('bypass','memory','3.3 V memory supply','power',r'^SYS3V3$')])
grouping(sid(b,300),[
 ('host','Host processor','The STM32 reads persistent data, removable storage and board status.',r('U100'),'data'),
 ('flash','Keep persistent data','Quad-SPI flash stores programs and data after power is removed.',r('U300'),'data'),
 ('card','Use removable storage','The microSD socket connects removable storage to the MCU.',r('J300'),'data'),
 ('protect','Protect the card signals','ESD devices limit discharges entering from the card socket.',r('U301','U302','U303'),'fault')],title='MCU storage and board control')
grouping(sid(b,400),[
 ('connector','Receive board power','J400 is the explicit Control-side interface for incoming rails and supervisory signals.',r('J400'),'power'),
 ('host','Receive status safely','Power-domain receivers deliver status to the host without joining disabled domains.',r('U400'),'control'),
 ('permit','Receive matrix permission','A separate I/O-domain receiver supplies the matrix permit signal.',r('U401'),'fault')],title='Power enters the Control board')
grouping(sid(b,500),[
 ('core','FPGA internal logic','CORE1V0 supplies the FPGA logic and block memory.',r('U500'),'power'),
 ('reservoir','Core energy reservoirs','Bulk and local capacitors support the core power domain.',rn('C',500,539),'power'),
 ('aux','Auxiliary and bank reservoirs','Local capacitors support the auxiliary supply and separate I/O banks.',rn('C',540,596),'power')],title='Supply the FPGA',explicit=[('reservoir','core','CORE1V0','power',r'^CORE1V0$'),('aux','core','Auxiliary / I/O / memory domains','power',r'^AUX1V8$|^IO3V3$|^DDR1V35$')])
grouping(sid(b,600),[
 ('flash','Store the FPGA design','Configuration flash holds the bitstream used at startup.',r('U600'),'data'),
 ('fpga','Load programmable logic','The FPGA loads configuration data and reports INIT and DONE status.',r('U500'),'data'),
 ('jtag','Recover and debug','JTAG provides an independent programming and recovery path.',r('J600'),'data'),
 ('recover','Request reconfiguration','The button or open-drain MCU buffer can restart FPGA configuration.',r('U601','SW600'),'control'),
 ('filter','Filter internal monitoring supply','The ferrite and local capacitors condition the XADC supply.',r('FB600'),'power')],title='Load and recover the FPGA',explicit=[('flash','fpga','Bitstream over configuration SPI','data',r'^FPGA_CFG_',True),('jtag','fpga','JTAG programming','data',r'^FPGA_JTAG_',True),('recover','fpga','Restart configuration','control',r'^FPGA_PROGRAM_N$'),('filter','fpga','Filtered XADC supply','power',r'^FPGA_VCCADC$')])
grouping(sid(b,700),[
 ('connector','Connect a USB cable','The Type-C receptacle is the external USB connection.',r('J700'),'data'),
 ('protection','Protect cable signals','Low-capacitance ESD devices protect external data and CC lines.',r('D700')+rn('U',700,705),'fault'),
 ('orientation','Choose cable orientation','The Type-C controller routes the active SuperSpeed pairs.',r('U706'),'data'),
 ('bridge','Translate USB to parallel data','The FT601 converts USB traffic into a 32-bit synchronous FIFO interface.',r('U707'),'data'),
 ('fpga','Process the data stream','FPGA logic exchanges words and flow-control signals with the FIFO bridge.',r('U500'),'data'),
 ('support','Clock and power detection','The crystal and reset-sense buffer support USB-bridge operation.',r('Y700','U708','FB700','FB701'),'control')],title='USB · cable data becomes FPGA words')
grouping(sid(b,800),[
 ('clock','Provide a fast reference','The differential oscillator supplies the FPGA 200 MHz reference.',r('Y800'),'control'),
 ('fpga','Request memory transfers','The FPGA memory interface drives commands and exchanges data.',r('U500'),'data'),
 ('memory','Buffer high-speed data','DDR3L provides 512 MiB of volatile FPGA working memory.',r('U800'),'data'),
 ('termination','Set memory signal bias','Termination and reference networks support the DDR3L interface.',rn('R',800,830),'analog')],title='FPGA memory and timing',explicit=[('clock','fpga','200 MHz differential clock','control',r'CLK200_SRC|FPGA_SYSCLK'),('fpga','memory','Address / command / clock','control',r'^DDR_(A|BA|RAS|CAS|WE|CK|RESET|ODT)'),('fpga','memory','16 data bits and strobes','data',r'^DDR_(DQ|DM)',True),('termination','memory','VTT and reference bias','power',r'^VTT$|^DDR_VREF$')])
ether=grouping(sid(b,900),[
 ('connector','Network connector','The cable brings electrical Ethernet waveforms to the RJ45 connector.',r('J900'),'data'),
 ('isolation','Electrical isolation','Four transformer pairs carry the data while separating cable and board electrical domains.',r('T900'),'analog'),
 ('phy','Recover Ethernet data','The PHY converts the cable signalling into a clocked digital RGMII interface.',r('U902'),'data'),
 ('fpga','Process network frames','The FPGA receives digital data. MAC and higher protocols are implemented inside programmable logic or firmware.',r('U500'),'data'),
 ('management','Link host and FPGA domains','Separate buffers carry MCU commands, responses and configuration status between power domains.',r('U900','U901'),'control'),
 ('support','Support the link','The 25 MHz crystal, analog regulator and ESD devices support the PHY and external connection.',r('Y900','U903')+rn('U',904,907),'power')],title='Ethernet · from cable waveform to FPGA data',description='Follow an Ethernet receive path across one canvas: network connector, transformer isolation, physical-layer recovery and FPGA processing. Select a connection for actual net and pin detail.',explicit=[('connector','isolation','Four cable pairs','analog',r'^ETH_[ABCD]_[PN]$',True),('isolation','phy','Isolated physical-layer signal','analog',r'^MDI_[ABCD]_[PN]$',True),('phy','fpga','Receive: data + clock + valid','data',r'^PHY_RX'),('fpga','phy','Transmit: data + clock + valid','data',r'^PHY_TX'),('fpga','phy','Configure and inspect the link','control',r'^PHY_MDC$|^PHY_MDIO$|^PHY_RESET_N$|^PHY_INT_N$',True),('management','fpga','Buffered MCU commands / status','control',r'MCU_FPGA_.*_F$|FPGA_IRQ_F|HOST_ALIVE_F',True),('support','phy','Reference and analog supply','power',r'PHY2V5|PHY_XI|PHY_XO')])
ether['suggestedScenario']='ethernet-local-rx'
grouping(sid(b,1000),[
 ('dac0','Set bit lines 0–7','An eight-channel DAC sets this bank of analog voltages.',r('U1000'),'analog'),
 ('dac1','Set bit lines 8–15','An eight-channel DAC sets this bank of analog voltages.',r('U1003'),'analog'),
 ('dac2','Set bit lines 16–23','An eight-channel DAC sets this bank of analog voltages.',r('U1006'),'analog'),
 ('buffer0','Drive bit lines 0–7','Precision followers buffer the DAC outputs before matrix routing.',r('U1001','U1002'),'analog'),
 ('buffer1','Drive bit lines 8–15','Precision followers buffer the DAC outputs before matrix routing.',r('U1004','U1005'),'analog'),
 ('buffer2','Drive bit lines 16–23','Precision followers buffer the DAC outputs before matrix routing.',r('U1007','U1008'),'analog'),
 ('dac3','Set bit lines 24–31','The fourth DAC completes the 32 independently set voltages.',r('U1009'),'analog'),
 ('buffer3','Drive bit lines 24–31','Precision followers buffer the final eight DAC outputs.',r('U1010','U1011'),'analog')],title='Create 32 analog bit-line voltages',explicit=[('dac0','buffer0','Eight programmed voltages','analog',r'^BL_DAC_RAW[0-7]$'),('dac1','buffer1','Eight programmed voltages','analog',r'^BL_DAC_RAW(8|9|1[0-5])$'),('dac2','buffer2','Eight programmed voltages','analog',r'^BL_DAC_RAW(1[6-9]|2[0-3])$'),('dac3','buffer3','Eight programmed voltages','analog',r'^BL_DAC_RAW(2[4-9]|3[01])$')])
grouping(sid(b,1100),[
 ('commands','Set experiment voltages','The service DAC produces voltage and current-limit commands.',r('U1100'),'analog'),
 ('buffer','Buffer service commands','Precision followers buffer service references before the selected source and regulator.',r('U1101','U1102'),'analog'),
 ('forming','Set the forming voltage','A separate precision DAC sets the forming source.',r('U1103'),'analog'),
 ('formbuffer','Buffer the forming source','The forming amplifier drives the next analog stage.',r('U1104'),'analog')],title='Set READ, WRITE and FORMING commands')
grouping(sid(b,1200),[
 ('fpga','Issue analog setpoints','The FPGA supplies the serial control interface for the DAC bank.',r('U500'),'control'),
 ('bias','Define safe idle states','Pull resistors keep select, reset and latch controls defined during startup.',rn('R',1200,1213),'control')],title='Tell the analog sources what to output')
grouping(sid(b,1300),[
 ('fpga','Request a matrix operation','FPGA outputs request modes, addresses and timing.',r('U500'),'control'),
 ('capture','Hold the active request','Registers capture the operation fields used during a run.',r('U1301','U1327','U1328'),'control'),
 ('compare','Detect a changed request','Comparators check the requested fields against the captured fields.',r('U1329','U1330'),'fault'),
 ('permissions','Check permission to run','Logic combines power, mode and interlock conditions before enabling routes.',rn('U',1300,1326),'fault'),
 ('decode','Select the operation','Mode and held-address logic selects routing and safe operating states.',rn('U',1331,1352),'control')],title='Allow only a consistent matrix operation')
grouping(sid(b,1400),[
 ('first','Load switch bits 0–31','The first shift-register section accepts a serial portion of the 80-bit image.',rn('U',1400,1403),'control'),
 ('second','Load switch bits 32–63','The chain continues through the next four registers.',rn('U',1404,1407),'control'),
 ('last','Load switch bits 64–79','The final registers complete the image; latch control applies the held outputs.',rn('U',1408,1409),'control')],title='Store the 80-bit switch image')
grouping(sid(b,1500),[
 ('bank0','Route bit lines 0–7','Switches connect DAC drives, clamps and the selected service path for this bank.',rn('U',1500,1503)+r('U1516'),'analog'),
 ('bank1','Route bit lines 8–15','The second bank routes another eight bit lines.',rn('U',1504,1507)+r('U1517'),'analog'),
 ('bank2','Route bit lines 16–23','The third bank routes another eight bit lines.',rn('U',1508,1511)+r('U1518'),'analog'),
 ('bank3','Route bit lines 24–31','The final bank completes 32 bit-line routing channels.',rn('U',1512,1515)+r('U1519'),'analog')],title='Connect the selected analog drive to the matrix')
grouping(sid(b,1600),[
 ('source','Choose a service source','A selector chooses the service voltage used by the operation.',r('U1601'),'analog'),
 ('bank','Choose a bit-line bank','The bank selector chooses the service destination.',r('U1600'),'analog'),
 ('polarity','Choose programming polarity','Routing switches select the required source polarity.',r('U1602'),'analog'),
 ('return','Select READ return and reset','The switches connect the READ return and reset the source-controller state while the source is disabled.',r('U1603'),'analog')],title='Select service voltage, bank and polarity')
grouping(sid(b,1700),[
 ('word','Drive selected word lines','Word-line switches connect the selected drive state to eight WL lines.',r('U1700','U1701'),'analog'),
 ('clamp','Hold inactive neuron lines','Clamp switches define inactive NL states.',r('U1702','U1703'),'analog'),
 ('selection','Select the measured neuron line','The analog selector connects one NL path to the readout.',r('U1705'),'analog'),
 ('permit','Qualify routing controls','Logic combines the controls used by the line-selection network.',r('U1704'),'control')],title='Select matrix rows and readout lines')
grouping(sid(b,1800),[
 ('socket','Connect the memristor crossbar','The socket exposes bit lines, word lines, neuron lines and bias contacts.',r('J1800'),'analog'),
 ('bias','Choose adapter bias','Bias jumpers define the adapter bias connections shown in the source.',r('J1801','J1802'),'analog')],title='The experimental crossbar connection')
grouping(sid(b,1900),[
 ('current','Convert current to voltage','The transimpedance amplifier turns matrix return current into a measurable voltage.',r('U1900'),'analog'),
 ('range','Choose current sensitivity','Feedback selection changes the current-to-voltage conversion range.',r('U1901'),'control'),
 ('monitor','Choose a monitor point','An analog selector chooses a diagnostic or source-monitor signal.',r('U1902'),'analog'),
 ('buffer','Observe without loading','High-impedance buffers isolate compliance monitor nodes from the selector.',r('U1903'),'analog')],title='Turn matrix current into a measurable signal')
grouping(sid(b,2000),[
 ('reference','Define the measurement scale','The precision reference establishes the ADC scale.',r('U2000','U2001'),'analog'),
 ('monitor','Buffer the selected signal','The selected monitor signal is buffered before differential conversion.',r('U2002'),'analog'),
 ('differential','Prepare a balanced ADC input','The differential amplifier produces the two ADC input voltages.',r('U2003'),'analog'),
 ('adc','Convert voltage to a number','The ADC samples the prepared analog signal and returns digital results.',r('U2004'),'data'),
 ('supply','Supply the converter domains','Local regulators provide the ADC and driver support rails.',r('U2005','U2006'),'power')],title='Digitize the matrix measurement')
grouping(sid(b,2100),[
 ('commands','Choose voltage and current limits','Analog selectors choose the active operation commands.',r('U2100','U2103'),'analog'),
 ('sense','Measure source-side current','Kelvin sense amplification measures the current delivered by the shared source.',r('U2104','U2109'),'analog'),
 ('control','Regulate voltage or current','The shared control amplifiers regulate the source using command and sense signals.',r('U2105','U2106','U2107'),'analog'),
 ('drive','Drive the regulated source','The output amplifier feeds the downstream matrix source routing.',r('U2101'),'analog'),
 ('reset','Bound and reset the controller','Clamp and reset circuitry limit controller excursions between operations.',r('U2108')+rn('D',2100,2103),'control')],title='Limit programming voltage and current')
grouping(sid(b,2200),[
 ('compare','Detect excessive current','A fast comparator compares sensed write current with the backup trip threshold.',r('U2200'),'fault'),
 ('qualify','Qualify protection events','Logic combines current and configuration trip conditions.',r('U2201','U2203'),'fault'),
 ('remember','Remember the fault','The latch keeps the fault asserted until the defined reset sequence.',r('U2202'),'fault'),
 ('inhibit','Withdraw power permission','Transistors provide the fault and inhibit interface to the Power system.',rn('Q',2200,2203),'fault')],title='Stop an unsafe matrix operation')

# POWER: preserve every circuit leaf, but explain it as a handful of functions.
b='power';r=lambda *x:refs(b,*x);rn=lambda p,a,z:nums(b,p,a,z)
power_titles={100:'Connect the external 24 V supply',200:'Protect and indicate the input fuse',300:'Limit and disconnect input power',400:'Filter the protected 24 V bus',500:'Keep supervision always powered',600:'Generate the USB 5 V supply',700:'Generate host-system 3.3 V',800:'Create the FPGA intermediate supply',900:'Prepare the low-noise analog supply',1000:'Generate the positive analog rail',1100:'Generate the negative analog rail',1200:'Generate FPGA core voltage',1300:'Generate FPGA auxiliary 1.8 V',1400:'Generate auxiliary 2.5 V',1500:'Generate FPGA I/O 3.3 V',1600:'Generate DDR3L memory voltage',1700:'Generate Ethernet PHY core voltage',1800:'Track the DDR termination reference',1900:'Clean up analog 5 V',2000:'Clean up analog 3.3 V',2100:'Switch the positive programming rail',2200:'Switch the negative programming rail',2300:'Connect the programming supplies',2400:'Coordinate the power sequence',2500:'Watch both controllers',2600:'Grant or withdraw hardware permission',2700:'Gate the primary converter commands',2800:'Gate the auxiliary converter commands',2900:'Check analog supply windows',3000:'Combine actual rail readiness',3100:'Combine commanded operating readiness',3200:'Detect negative-rail overcurrent',3300:'Link power supervision and host control',3400:'Measure the negative rail safely',3500:'Measure input and system power',3600:'Measure FPGA, analog and positive rails',3700:'Measure FPGA core and I/O domains',3800:'Measure memory, PHY and analog domains',3900:'Choose which supply to measure',4000:'Buffer measurements for the controller'}
grouping(sid(b,100),[('connector','Accept external DC power','The terminal provides the external positive supply and return.',r('J101'),'power'),('indicators','Show input status','Indicator circuits show the input conditions represented in the schematic.',r('D101','D102'),'control')],title=power_titles[100])
grouping(sid(b,200),[('fuse','Interrupt a severe input fault','The replaceable fuse sits in the incoming supply path.',r('F201'),'power'),('transient','Clamp a brief surge','The TVS limits transient voltage at the protected input.',r('D205'),'fault'),('indicate','Show fuse and input state','Diodes and the transistor drive the local supply indicators.',r('D201','D202','D203','D204','Q201'),'control')],title=power_titles[200])
grouping(sid(b,300),[('efuse','Limit and disconnect input current','The electronic fuse controls the protected supply and its response to faults.',r('U301'),'power'),('reverse','Control reverse-current path','The series MOSFET and associated diode form the shown input protection path.',r('Q301','D301'),'power'),('enable','Request and show the supply state','The local control, jumper and indication components set startup behavior.',r('Q302','JP301','D302'),'control')],title=power_titles[300])
grouping(sid(b,400),[('filter','Reduce bus noise','The filter and local capacitors condition the protected supply bus.',r('L401'),'power'),('sense','Observe delivered input power','The local sense and indicator parts expose the input conditions used elsewhere.',r('D401'),'analog')],title=power_titles[400])

# Uniform converter diagrams deliberately use ports, conversion and supervision,
# rather than separate cards for every passive component.
converters={
 500:('Always-on 3.3 V','BUS24','AON','U501','L501',None),
 600:('USB supply','BUS24','USB5','U601','L601','Q601'),
 700:('Host-system supply','BUS24','SYS3V3','U701','L701','Q701'),
 800:('FPGA intermediate supply','BUS24','FPGA5V5','U801','L801','Q801'),
 900:('Analog preregulator','BUS24','ANA6','U901','L901','Q901'),
 1000:('Positive analog rail','BUS24','P15','U1001','L1001','Q1001'),
 1100:('Negative analog rail','BUS24','N15','U1102','L1101','U1101'),
 1200:('FPGA core rail','FPGA5V5','CORE1V0','U1201','L1201','Q1201'),
 1300:('Auxiliary 1.8 V','FPGA5V5','AUX1V8','U1301','L1301','Q1301'),
 1400:('Auxiliary 2.5 V','FPGA5V5','AUX2V5','U1401','L1401','Q1401'),
 1500:('FPGA I/O rail','FPGA5V5','IO3V3','U1501','L1501','Q1501'),
 1600:('DDR3L memory rail','FPGA5V5','DDR1V35','U1601','L1601','Q1601'),
 1700:('Ethernet PHY core rail','FPGA5V5','PHY1V05','U1701','L1701','Q1701'),
 1800:('Tracking termination supply','DDR1V35','VTT','U1801',None,'Q1801'),
 1900:('Low-noise analog 5 V','ANA6','ANA5','U1901',None,'Q1901'),
 2000:('Low-noise analog 3.3 V','ANA5','ANA3V3','U2001',None,'Q2001')}
for num,(heading,inp,out,ic,ind,gate) in converters.items():
 sh=sid(b,num)
 # Assign discrete support inside the power-conversion and control functions.
 defs=[('convert','Convert and regulate',heading+' is generated by the source regulator and its local energy-storage or filter components.',r(ic,*([ind] if ind else [])),'power')]
 if gate:defs.append(('enable','Accept the enable command','The command gate connects controller permission to the regulator enable input.',r(gate),'control'))
 defs.append(('filter','Set and filter the output','Feedback, local capacitors and output sensing establish the delivered rail.',[cid for cid in allrefs(sh) if C[cid]['ref'].startswith('C')],'power'))
 obj=grouping(sh,defs,title=power_titles[num])
 ns=obj['nodes'];layout(ns,3)
 # Explicit port blocks simplify the entire power path on the same canvas.
 portin=node('input','Receive '+inp,'Incoming rail used by this converter.',role='power',x=40,y=40)
 core=next(n for n in ns if n['id']=='convert');core.update(x=380,y=40)
 filt=next(n for n in ns if n['id']=='filter');filt.update(x=720,y=40)
 output=node('output','Deliver '+out,'The generated rail continues to its consumers and monitoring circuits.',role='power',x=720,y=270)
 for n in ns:
  if n['id']=='enable':n.update(x=380,y=270)
 ns.insert(0,portin);ns.append(output)
 es=[edge('input_convert','input','convert',inp,'power',nets('^'+inp+'$',sheet=sh)),edge('convert_filter','convert','filter','Regulated output','power',nets(re.escape(out)+r'|_RAW$',sheet=sh)),edge('filter_output','filter','output',out,'power',nets('^'+out+'$',sheet=sh))]
 if gate:es.append(edge('enable_convert','enable','convert','Qualified enable','control',nets(r'^EN_|^CMD_',sheet=sh)))
 obj['edges']=es;obj['bounds']={'x':0,'y':0,'w':1000,'h':470}

grouping(sid(b,2100),[('switch','Connect the positive rail','Series switching devices connect the positive programming supply when permitted.',r('Q2101','Q2102','Q2103','Q2104'),'power'),('control','Translate the enable request','The optocoupler and control devices implement the shown positive-rail gate drive.',r('U2101','Q2105'),'control'),('stop','Discharge the gate quickly','The clamp devices remove gate drive and define the off state.',r('Q2106','Q2107')+rn('D',2101,2104),'fault')],title=power_titles[2100])
grouping(sid(b,2200),[('switch','Connect the negative rail','Switching devices connect or isolate the negative programming supply.',r('Q2201','Q2202','Q2203','Q2204'),'power'),('control','Translate isolated commands','Optocouplers transfer the control requests into the negative gate-drive domain.',r('U2201','U2202','U2203'),'control'),('clamp','Bound gate and output voltage','The diode network provides the source protection and clamp paths shown in the schematic.',rn('D',2201,2204),'fault')],title=power_titles[2200])
grouping(sid(b,2300),[('connector','Expose the programming rails','The connector exposes switched positive and negative programming supplies.',r('J2301'),'power'),('monitor','Condition the monitor output','The local divider and clamp condition the program-supply sense signal.',r('D2301'),'analog')],title=power_titles[2300])
grouping(sid(b,2400),[('controller','Sequence and supervise','The STM32G0 power manager issues rail requests and reads telemetry and status.',r('U2401'),'control'),('support','Support controller startup','Local supply and startup support components keep the manager operating.',[cid for cid in allrefs(sid(b,2400)) if C[cid]['ref'].startswith(('C','R'))],'power')],title=power_titles[2400])
grouping(sid(b,2500),[('pm','Watch the power manager','A watchdog supervises the power-manager heartbeat and reset path.',r('U2501','J2501'),'fault'),('host','Watch the host processor','A separate watchdog supervises the host heartbeat and reset path.',r('U2502','J2502'),'fault'),('reset','Combine reset requests','The diode and bias network implements the shown reset combination.',r('D2501'),'fault')],title=power_titles[2500])
grouping(sid(b,2600),[('stop','Accept stop and interlock inputs','External contacts and the hardware interlock can withdraw permission.',r('J2601','J2602','J2603'),'fault'),('qualify','Combine safety conditions','Hardware logic requires the relevant conditions before a permit can exist.',r('U2601','U2602'),'fault'),('memory','Remember withdrawn permission','The flip-flops retain the hardware enable or trip state until rearmed.',r('U2603'),'fault'),('output','Drive permit boundaries','Transistors implement the shown permit and inhibit interface.',r('Q2601','Q2602'),'fault')],title=power_titles[2600])
for num,ics in [(2700,['U2701','U2702']),(2800,['U2801','U2802'])]:
 grouping(sid(b,num),[('first','Qualify the first enable group','Each gate combines the requested state with the corresponding hardware permission.',r(ics[0]),'control'),('second','Qualify the second enable group','The remaining gates independently qualify their converter requests.',r(ics[1]),'control'),('default','Default commands to off','Pull resistors give the command network defined startup states.',[cid for cid in allrefs(sid(b,num)) if C[cid]['ref'].startswith('R')],'fault')],title=power_titles[num])
grouping(sid(b,2900),[('threshold','Set acceptable analog windows','Divider networks define the comparator thresholds for analog supply checks.',rn('R',2901,2915),'analog'),('compare','Check analog rails','The quad comparator turns the rail measurements into digital readiness signals.',r('U2901'),'fault')],title=power_titles[2900])
for num,ics in [(3000,['U3001','U3017','U3018']),(3100,['U3101','U3102','U3103'])]:
 grouping(sid(b,num),[(str(i),'Combine '+label,'Hardware logic combines this group of readiness conditions; open exact connections to inspect every input.',r(ic),'control') for i,(ic,label) in enumerate(zip(ics,['primary readiness','auxiliary readiness','final readiness']))],title=power_titles[num])
grouping(sid(b,3200),[('threshold','Define the negative-current limit','The divider and filtering establish the hardware comparison threshold.',rn('R',3201,3207),'analog'),('compare','Detect negative overcurrent','The comparator checks the conditioned negative-current measurement.',r('U3201'),'fault')],title=power_titles[3200])
grouping(sid(b,3300),[('debug','Program the power manager','The SWD connector gives a debugger access to the power-manager MCU.',r('J3301'),'data'),('host','Connect host supervision','The host connector carries UART, watchdog and status signals.',r('J3302'),'control'),('isolate','Receive host signals safely','The Ioff buffer separates signals across supply-domain boundaries.',r('U3301','D3301'),'control')],title=power_titles[3300])
grouping(sid(b,3400),[('sense','Translate negative voltage and current','The dual amplifier converts negative-rail information into ground-referenced monitor signals.',r('U3401'),'analog'),('clamp','Protect the monitor inputs','Clamps and filtering bound the measurement outputs before telemetry.',r('D3401','D3402','D3403'),'fault')],title=power_titles[3400])
monitor_groups={3500:[('input','External input','U3501'),('aon','Always-on supply','U3502'),('usb','USB supply','U3503'),('system','Host-system supply','U3504')],3600:[('fpga','FPGA intermediate supply','U3601'),('analog','Analog preregulator','U3602'),('positive','Positive analog rail','U3603')],3700:[('core','FPGA core supply','U3701'),('aux18','1.8 V auxiliary supply','U3702'),('aux25','2.5 V auxiliary supply','U3703'),('io','FPGA I/O supply','U3704')],3800:[('ddr','DDR3L memory supply','U3801'),('ana5','Analog 5 V supply','U3802'),('phy','Ethernet core supply','U3803'),('ana33','Analog 3.3 V supply','U3804')]}
for num,defs in monitor_groups.items():
 grouping(sid(b,num),[(key,'Measure '+heading.lower(),'A current-sense amplifier and local conditioning produce voltage/current telemetry for this rail. Hardware alerts act independently of scanned telemetry.',r(ic),'analog') for key,heading,ic in defs],title=power_titles[num])
grouping(sid(b,3900),[('current','Choose a current measurement','The 16-way selector connects one rail current monitor to the common current path.',r('U3901'),'analog'),('voltage','Choose the matching voltage','The paired selector uses the same address to select that rail voltage.',r('U3902'),'analog')],title=power_titles[3900])
grouping(sid(b,4000),[('buffer','Drive the controller ADC','Two unity-gain buffers isolate the selected current and voltage from ADC sampling load.',r('U4001'),'analog'),('default','Define selection and alert defaults','Bias, output isolation and filter components define startup and ADC-drive behavior.',[cid for cid in allrefs(sid(b,4000)) if C[cid]['ref'].startswith(('R','C'))],'control')],title=power_titles[4000])

# Section scenes are functional navigation, not lists of component symbols.
sections={
 'power-input':('power','Protect incoming power',[100,200,300,400]),
 'power-primary':('power','Create the main supply branches',[500,600,700,800,900,1000,1100]),
 'power-secondary':('power','Generate the load-specific rails',[1200,1300,1400,1500,1600,1700,1800,1900,2000]),
 'power-program':('power','Enable programming power',[2100,2200,2300]),
 'power-supervisor':('power','Coordinate startup and hardware safety',[2400,2500,2600,2700,2800,2900,3000,3100,3200,3300]),
 'power-monitoring':('power','Observe every supply branch',[3400,3500,3600,3700,3800,3900,4000]),
 'control-host':('control','Run the host application',[100,200,300]),
 'control-boundary':('control','Receive supplies and power permission',[400]),
 'control-fpga':('control','Load the FPGA and connect fast links',[500,600,700,800,900]),
 'control-sources':('control','Create analog experiment commands',[1000,1100,1200]),
 'control-routing':('control','Hold and route a matrix operation',[1300,1400,1500,1600,1700,1800]),
 'control-readout':('control','Turn matrix current into data',[1900,2000]),
 'control-regulation':('control','Regulate programming current and voltage',[2100]),
 'control-safety':('control','Stop and remember matrix faults',[2200])}

def sheets_nets(shs):return set(n for sh in shs for n in S[sh]['nets'])
def section_edges(nodes_,sheetsets,board,limit=12):
    candidates=[]
    for i,a in enumerate(nodes_):
        for z in nodes_[i+1:]:
            common=sheetsets[a['id']]&sheetsets[z['id']]
            common=[n for n in common if N[n]['kind']!='ground' and not common_rail(N[n])]
            if common:
                candidates.append(edge(a['id']+'_'+z['id'],a['id'],z['id'],netlabel([N[n]['name'] for n in common]),nettype([N[n]['name'] for n in common]),common,False,undirected=True,flow='association',description='These functions share the listed exact source nets. Direction is not inferred by this summary.'))
    return sorted(candidates,key=lambda e:(len(e['nets'])<2,-len(e['nets'])))[:limit]
for sec,(board,title,ns) in sections.items():
    nodes_=[];sets={}
    for number in ns:
        sh=sid(board,number);child=scenes[sh]
        nid='sheet'+str(number)
        nodes_.append(node(nid,child['title'],child['description'],[c for c in allrefs(sh) if C[c]['ref'][0] in 'UJTY'][:6],role='power' if board=='power' and number<2400 else ('analog' if board=='control' and number>=1000 else 'data'),scene=sh,sheet=sh))
        sets[nid]=sheets_nets([sh])
    obj=scene(sec,title,'Open a function to inspect its own teaching diagram. Shared connections stay linked to their exact source names.',nodes_,section_edges(nodes_,sets,board),board=board,cols=3)
    obj['sheetIds']=[sid(board,n) for n in ns]

# Match the existing PROTECTION hierarchy with one two-module overview.
protection_ids=[sid('control',2100),sid('control',2200)]
protection_nodes=[];protection_sets={}
for i,sh in enumerate(protection_ids):
    nid='sheet'+str(S[sh]['number'])
    protection_nodes.append(node(nid,scenes[sh]['title'],scenes[sh]['description'],[c for c in allrefs(sh) if C[c]['ref'][0] in 'UJTY'][:6],role='analog' if i==0 else 'fault',scene=sh,sheet=sh,x=40+i*340,y=40))
    protection_sets[nid]=sheets_nets([sh])
protection=scene('control_PROTECTION','Защита и регулирование матричного тракта','Регулятор ограничивает напряжение и ток программирования, а аппаратная защита фиксирует аварии и отзывает разрешение.',protection_nodes,section_edges(protection_nodes,protection_sets,'control'),board='control')
protection['sheetIds']=protection_ids

# A handful of deliberate board-level routes keep the teaching maps legible.
def sectionnode(nid,title,desc,sec,role='data'):
    board,_,ns=sections[sec];rr=[]
    for num in ns:
        sh=sid(board,num)
        rr.extend(c for c in allrefs(sh) if C[c]['ref'][0] in 'UJTY')
    return node(nid,title,desc,list(dict.fromkeys(rr))[:10],role,scene=sec)
pn=[sectionnode('input','Protect the 24 V input','Receive the external supply, interrupt faults and condition the bus.','power-input','power'),sectionnode('primary','Create main supply branches','Generate always-on, host, intermediate FPGA and analog supplies.','power-primary','power'),sectionnode('secondary','Supply each load domain','Generate FPGA, memory, PHY and quiet analog rails from the main branches.','power-secondary','power'),sectionnode('supervisor','Coordinate safe startup','A dedicated controller and hardware logic qualify the rail commands.','power-supervisor','control'),sectionnode('monitor','Observe voltage and current','Sense each rail and route a selected pair of measurements to the power manager.','power-monitoring','analog'),sectionnode('program','Enable programming rails','Switch the positive and negative rails used by the experiment source.','power-program','power')]
pe=[edge('input_primary','input','primary','Protected 24 V bus','power',nets(r'^BUS24$',board='power')),edge('primary_secondary','primary','secondary','Intermediate supply branches','power',nets(r'^FPGA5V5$|^ANA6$|^ANA5$',board='power')),edge('primary_supervisor','primary','supervisor','Always-on supervision','power',nets(r'^AON$',board='power')),edge('supervisor_primary','supervisor','primary','Qualified primary commands','control',nets(r'^CMD_(USB|SYS|FPGA|ANA6|P15|N15)$',board='power')),edge('supervisor_secondary','supervisor','secondary','Qualified load commands','control',nets(r'^CMD_(CORE|AUX18|AUX25|IO33|DDR|PHY|VTT|ANA5|ANA33)$',board='power')),edge('secondary_monitor','secondary','monitor','Measure delivered rails','analog',nets(r'^MON_[VI]_',board='power')),edge('monitor_supervisor','monitor','supervisor','Selected voltage and current','analog',nets(r'^ADC_[IV]$|^OC_OK_N$',board='power')),edge('primary_program','primary','program','Positive / negative analog rails','power',nets(r'^P15$|^N15$',board='power')),edge('supervisor_program','supervisor','program','Programming permission','fault',nets(r'PERMIT|^CMD_PROG',board='power'))]
scene('power','Power board · turn one input into safe supplies','Follow the energy path and the independent supervision path on the same diagram. Open any block for the next level.',pn,pe,'power')

cn=[sectionnode('boundary','Receive power and permission','Power arrives at J400; domain-safe receivers bring supervisory status to the host and FPGA.','control-boundary','power'),sectionnode('host','Run experiment software','The STM32 uses its own working memory and storage to supervise experiments.','control-host','data'),sectionnode('fpga','Execute precise timing','The FPGA loads its design, connects USB and Ethernet, and coordinates fast data movement.','control-fpga','data'),sectionnode('sources','Create analog setpoints','DACs and buffers produce bit-line voltages, service commands and current limits.','control-sources','analog'),sectionnode('routing','Connect the selected matrix path','Held routing and line selectors connect the chosen source and return paths to the crossbar.','control-routing','analog'),sectionnode('readout','Turn matrix current into data','Amplifiers and the ADC turn the electrical response into digital samples.','control-readout','analog'),sectionnode('regulation','Limit the programming source','A shared source regulates voltage or current before the routing network.','control-regulation','analog'),sectionnode('safety','Stop an unsafe operation','Independent trip logic remembers faults and withdraws permission.','control-safety','fault')]
ce=[edge('boundary_host','boundary','host','Supply + supervision','power',nets(r'^SYS3V3$|_HOST$',board='control')),edge('host_fpga','host','fpga','Commands and status','control',nets(r'^MCU_FPGA_|^FPGA_IRQ$|FPGA_DONE_MCU|FPGA_INIT_N_MCU',board='control'),True),edge('fpga_sources','fpga','sources','Serial setpoints','control',nets(r'^DAC_SPI_|^CS_BL|DAC_LDAC|DAC_RESET',board='control')),edge('sources_routing','sources','routing','32 bit-line voltages','analog',nets(r'^BL_DAC\d+$',board='control')),edge('sources_regulation','sources','regulation','Voltage / current commands','analog',nets(r'^V(READ|SET|RESET|FORM)_SRC$|^ILIM_(SET|RESET|FORM)$',board='control')),edge('regulation_routing','regulation','routing','Regulated programming source','analog',nets(r'^MAT_(SOURCE$|DRV_OUTPUT$|RSH_POWER$|REG_ERROR|VTARGET$|PI_|SOURCE_OFF$)',board='control')),edge('fpga_routing','fpga','routing','Mode, held image and timing','control',nets(r'^MAT_(SPI_|PULSE$|READ_EN_REQ$|VMM_EN_REQ$|SERVICE_EN_REQ$|WRITE_EN_REQ$|.*_A[0-4]_REQ$|POLARITY_REQ$|FRAME_VALID$)',board='control')),edge('routing_readout','routing','readout','Selected matrix current','analog',nets(r'TIA_IN|NL_READ|MATRIX_READ_RETURN',board='control')),edge('readout_fpga','readout','fpga','Digital measurement results','data',nets(r'^MAT_ADC_(SDO|SDI|SCK|CNV)$',board='control')),edge('regulation_safety','regulation','safety','Independent source-current sense','analog',nets(r'^MAT_(CC_SENSE_BUF|ILIM_SENSE_BUF)$',board='control')),edge('safety_routing','safety','routing','Trip and inhibit','fault',nets(r'^MAT_FAULT_N$|^MAT_CONFIG_TRIP$',board='control')),edge('boundary_routing','boundary','routing','Matrix permission','fault',nets(r'^MATRIX_PERMIT$',board='control'))]
scene('control','Control board · from a command to a measurement','Commands become precise timing, analog drive, matrix connections and digitized results. Protection stays active beside the measurement path.',cn,ce,'control')

# The system map intentionally uses functional associations at board boundaries;
# no line claims a verified Power-side mating connector pin assignment.
sn=[node('supply','External DC supply','The external source supplies energy to the Power board.',role='power',x=40,y=40),node('power','Create and sequence power','The Power board protects the input and creates the supply rails used throughout MIRA.',refs('power','J101','U2401','U301'),'power',scene='power',x=380,y=40),node('safety','Keep the operation safe','Hardware interlocks, current limits and remembered faults can stop a matrix operation.',refs('power','U2603')+refs('control','U2200','U2202'),'fault',scene='control-safety',x=720,y=40),node('mcu','Coordinate the experiment','The STM32 host stores the experiment and exchanges commands and status with the FPGA.',refs('control','U100'),'data',scene='control-host',x=1060,y=40),node('host','Computer and operator','The computer sends experiment commands and receives measurements.',role='data',x=40,y=245),node('links','Bring commands onto the board','Ethernet or USB converts the external connection into a digital interface for FPGA logic.',refs('control','J900','T900','U902','J700','U707'),'data',scene=sid('control',900),x=380,y=245),node('fpga','Execute timing and data flow','Programmable logic coordinates matrix switching, DAC commands, ADC capture and fast communication.',refs('control','U500'),'data',scene='control-fpga',x=720,y=245),node('drive','Create the analog drive','DAC setpoints and the shared regulated source create voltages and bounded programming current.',refs('control','U1000','U1100','U2101'),'analog',scene='control-sources',x=1060,y=245),node('readout','Convert the response to data','The readout converts current into voltage, prepares it for the ADC and returns digital samples.',refs('control','U1900','U2003','U2004'),'analog',scene='control-readout',x=720,y=450),node('matrix','Connect and test the crossbar','Held switches route the chosen drive through the experimental memristor array.',refs('control','J1800'),'analog',scene='control-routing',x=1060,y=450)]
for n in sn:n['fixed']=True
def functional(eid,src,dst,label,typ,ns=None,bi=False,**kw):return edge(eid,src,dst,label,typ,ns,bi,'functional','Functional relationship for explanation. Open the board or exact connection detail for source nets; cross-board mating pins are not asserted here.',**kw)
se=[functional('supply_power','supply','power','24 V input','power',nets(r'^\+24V_RAW$|^VIN_RAW$|^BUS24_RAW$',board='power')),functional('power_fpga','power','fpga','Sequenced digital supplies','power',nets(r'^CORE1V0$|^AUX1V8$|^IO3V3$',board='control')),functional('power_drive','power','drive','Analog supply rails','power',nets(r'^ANA5$|^ANA3V3$|^P15$|^N15$',board='control')),functional('power_mcu','power','mcu','Host supply and status','power',nets(r'^SYS3V3$|ALL_RAILS_PG_HOST',board='control')),functional('host_links','host','links','Commands and results','data',[],True),functional('links_fpga','links','fpga','Digital receive / transmit','data',nets(r'^PHY_[RT]X|^FT_D',board='control'),True),functional('mcu_fpga','mcu','fpga','Experiment commands / status','control',nets(r'^MCU_FPGA_|^FPGA_IRQ$',board='control'),True),functional('fpga_drive','fpga','drive','Analog setpoints','control',nets(r'^DAC_SPI_|^CS_BL',board='control')),functional('drive_matrix','drive','matrix','Selected voltage and current','analog',nets(r'^BL_DAC\d+$|WRITE_SRC',board='control')),functional('fpga_matrix','fpga','matrix','Switch image and exact timing','control',nets(r'^MAT_(SPI_|PULSE$|READ_EN_REQ$|VMM_EN_REQ$|SERVICE_EN_REQ$|WRITE_EN_REQ$|FRAME_VALID$)',board='control')),functional('matrix_readout','matrix','readout','Measured electrical response','analog',nets(r'TIA_IN|NL_READ',board='control')),functional('readout_fpga','readout','fpga','ADC samples','data',nets(r'^MAT_ADC_(SDO|SDI|SCK|CNV)$',board='control')),functional('matrix_safety','matrix','safety','Current / configuration events','fault',nets(r'^MAT_(CONFIG_TRIP|CC_SENSE_BUF|ILIM_SENSE_BUF)$',board='control')),functional('safety_power','safety','power','Withdraw hardware permission','fault',nets(r'MATRIX_INHIBIT_N',board='control'))]
scene('system','MIRA · an experiment, end to end','Start with what each part does. Follow one highlighted story across the same canvas, then open a block when you want more detail.',sn,se,cols=4)
scenes['system']['subtitle']='One device. Power, commands, analog activity and results.'
system_card_text={
 'supply':('DC supply','Energy for both boards'),
 'power':('Power system','Protect input · start supply rails'),
 'safety':('Safety interlocks','Stop unsafe operations'),
 'mcu':('Experiment controller','Prepare commands · track state'),
 'host':('Computer','Set up experiments · collect results'),
 'links':('Ethernet / USB','Bring commands to the FPGA'),
 'fpga':('FPGA engine','Precise timing · data movement'),
 'drive':('Analog drive','Set the voltages applied to cells'),
 'readout':('Measure the response','Convert matrix current into data'),
 'matrix':('Memristor matrix','Apply signals · observe the response')
}
for n in scenes['system']['nodes']:
    n['title'],n['subtitle']=system_card_text[n['id']]

def step(title,text,nodes_,edges_,sceneid='system'):
    return dict(title=title,text=text,body=text,nodes=nodes_,edges=edges_,sceneId=sceneid)
def scenario(i,title,desc,steps,sceneid='system'):
    return dict(id=i,title=title,description=desc,sceneId=sceneid,steps=steps,frames=steps,educational=True)
scenarios=[
scenario('power-up','Apply power','Watch energy reach supervision, the host, programmable logic and analog functions. The sequence is a teaching story, not a timing simulation.',[
step('Connect the supply','Energy enters the input protection on the Power board.',['supply','power'],['supply_power']),
step('Wake supervision','Always-on circuitry lets the power manager check conditions before granting the other requests.',['power','safety'],[]),
step('Power the host','The host supply and status receivers become available.',['power','mcu'],['power_mcu']),
step('Power programmable logic','Controlled digital rails feed the FPGA and interface domains.',['power','fpga'],['power_fpga']),
step('Prepare analog functions','The analog rails supply the precision sources and measurement path.',['power','drive','readout'],['power_drive']),
step('Ready for the experiment','Software readiness and hardware permits must both agree before an operation.',['mcu','fpga','safety','matrix'],['mcu_fpga','fpga_matrix'])]),
scenario('ethernet-rx','Receive a computer command','Follow a command into the physical link and onward to programmable processing.',[
step('The operator sends a request','A command begins on the external computer.',['host','links'],['host_links']),
step('Cable signal becomes digital data','The connector, transformer and PHY bring the electrical link into a digital interface.',['links','fpga'],['links_fpga']),
step('Process the request','The chosen MAC, protocol and application logic interpret the received request. These are implementation layers within the FPGA system.',['fpga','mcu'],['mcu_fpga']),
step('Prepare an experiment','Validated commands select analog setpoints and a held matrix route.',['fpga','drive','matrix'],['fpga_drive','fpga_matrix'])]),
scenario('ethernet-tx','Return results to the computer','Follow the measured data back through the communication path.',[
step('Acquire a response','The matrix readout converts the electrical result into ADC samples.',['matrix','readout'],['matrix_readout']),
step('Collect digital samples','FPGA logic receives the digitized measurement.',['readout','fpga'],['readout_fpga']),
step('Send data to the link','The selected communication implementation passes result data to the physical link.',['fpga','links'],['links_fpga']),
step('Display the result','The computer receives and presents the returned data.',['links','host'],['host_links'])]),
scenario('matrix-read','Read the matrix','See the relation between commands, analog drive, matrix response and numerical result.',[
step('Choose a read operation','The host and FPGA prepare the experiment and operation timing.',['mcu','fpga'],['mcu_fpga']),
step('Set read voltages','DAC commands establish the analog read setpoints.',['fpga','drive'],['fpga_drive']),
step('Apply the held route','Routing connects the selected drive and return path to the crossbar.',['drive','fpga','matrix'],['drive_matrix','fpga_matrix']),
step('Measure the response','Selected matrix current reaches current-to-voltage conversion and the ADC front end.',['matrix','readout'],['matrix_readout']),
step('Return a number','The ADC result reaches FPGA capture and can be sent to the computer.',['readout','fpga','links','host'],['readout_fpga','links_fpga','host_links'])]),
scenario('matrix-write','Program a matrix element','Explain bounded programming drive and held routing without claiming device-specific pulse values.',[
step('Prepare voltage and current limits','The requested programming conditions become DAC setpoints for the shared source.',['fpga','drive'],['fpga_drive']),
step('Check the operation','Hardware permissions and the captured request must be consistent.',['safety','fpga','matrix'],['fpga_matrix']),
step('Apply the programming drive','The selected route connects the regulated source for the requested operation.',['drive','matrix'],['drive_matrix']),
step('Monitor the operation','Source-current and configuration conditions remain observable to independent protection.',['matrix','safety'],['matrix_safety']),
step('End and verify','After the programming operation, a read operation can measure the resulting state.',['matrix','readout','fpga'],['matrix_readout','readout_fpga'])]),
scenario('matrix-fault','Trigger a hardware fault','Show why protection has a direct path independent of normal data processing.',[
step('An unsafe condition occurs','A source-current or configuration event reaches the hardware protection.',['matrix','safety'],['matrix_safety']),
step('Remember the event','Fault memory holds the stop condition until the defined reset or rearm procedure.',['safety'],[]),
step('Withdraw permission','The inhibit path reaches the power-permit boundary.',['safety','power'],['safety_power']),
step('Inspect before rearming','The host can examine status and telemetry before a deliberate recovery sequence.',['power','mcu','safety'],['power_mcu'])]),
scenario('fpga-config','Load the FPGA design','Explain configuration storage, startup status and the separate ready-for-application decision.',[
step('Establish FPGA supplies','The Power board provides the FPGA core, auxiliary and bank supplies.',['power','fpga'],['power_fpga']),
step('Load the bitstream','The FPGA configuration interface loads its hardware design from local flash. Open the FPGA configuration block to inspect the exact path.',['fpga'],[]),
step('Report INIT and DONE','Configuration status reaches the host through the domain-buffer path.',['fpga','mcu'],['mcu_fpga']),
step('Check application readiness','The loaded application must establish its own communication and memory readiness before experiments.',['fpga','mcu','links'],['mcu_fpga','links_fpga'])]),
scenario('ethernet-local-rx','Ethernet: receive in detail','Watch the nature of the signal change from cable waveform to parallel digital data.',[
step('Arrive at the connector','The cable waveform enters the RJ45 connector J900. This is an analog physical-layer signal.',['connector'],[],sid('control',900)),
step('Cross the isolation barrier','T900 transfers the physical-layer signal magnetically between the cable and PHY sides.',['connector','isolation'],['connector_isolation_0'],sid('control',900)),
step('Recover the physical link','U902 recovers the physical link and presents digital receive data. Cable coding is not reproduced by this teaching animation.',['isolation','phy'],['isolation_phy_1'],sid('control',900)),
step('Deliver digital receive data','PHY_RXC, PHY_RX_CTL and PHY_RXD0…3 connect the PHY to U500. Open the edge for exact pin and waveform detail.',['phy','fpga'],['phy_fpga_2'],sid('control',900)),
step('Handle the frame','The chosen MAC and protocol implementation inside the FPGA system handles the received frame.',['fpga'],[],sid('control',900))],sid('control',900))]

# Short canvas labels stay distinct from the full names shown on selection.
short_by_scene={
 'system':{'supply_power':'24 V','power_fpga':'Digital power','power_drive':'Analog power','power_mcu':'Host power','host_links':'Commands / results','links_fpga':'Digital data','mcu_fpga':'Commands / status','fpga_drive':'Setpoints','drive_matrix':'Analog drive','fpga_matrix':'Timing','matrix_readout':'Response','readout_fpga':'Samples','matrix_safety':'Trip inputs','safety_power':'Inhibit'},
 'power':{'input_primary':'Protected 24 V','primary_secondary':'Intermediate rails','primary_supervisor':'Always-on power','supervisor_primary':'Enable','supervisor_secondary':'Enable','secondary_monitor':'Measurements','monitor_supervisor':'Telemetry','primary_program':'±15 V','supervisor_program':'Permission'},
 'control':{'boundary_host':'Power / status','host_fpga':'Commands / status','fpga_sources':'Setpoints','sources_routing':'32 analog voltages','sources_regulation':'Source commands','regulation_routing':'Regulated drive','fpga_routing':'Routes / timing','routing_readout':'Matrix current','readout_fpga':'Samples','regulation_safety':'Current sense','safety_routing':'Trip / inhibit','boundary_routing':'Permission'},
 sid('control',900):{'connector_isolation_0':'Cable pairs','isolation_phy_1':'Isolated signal','phy_fpga_2':'RX data','fpga_phy_3':'TX data','fpga_phy_4':'Link control','management_fpga_5':'MCU link','support_phy_6':'Clock / supply'}
}
short_by_label={'Addresses, clock and commands':'Address / command','Conditioned bus signals':'Conditioned bus','16-bit data bus':'16-bit data','Supply and local reservoirs':'Local power','Bitstream over configuration SPI':'Bitstream','Restart configuration':'Reconfigure','Filtered XADC supply':'XADC power','Address / command / clock':'Address / command','16 data bits and strobes':'16-bit data','VTT and reference bias':'DDR bias','Eight programmed voltages':'8 voltages','Qualified enable':'Enable','Regulated output':'Regulated power','Current measurements':'Current','Voltage measurements':'Voltage','Memory address, data and commands':'Memory bus','Selection and held control':'Held selection','32-bit data and handshakes':'32-bit data','Hardware protection':'Protection','Programmed analog voltages':'Analog voltages'}
for sceneid,obj in scenes.items():
    for e in obj['edges']:
        e['shortLabel']=short_by_scene.get(sceneid,{}).get(e['id'],short_by_label.get(e['label'],e['label']))
        if len(e['shortLabel'])>27:
            e['shortLabel']={'power':'Supply','data':'Data','control':'Control','analog':'Analog signal','fault':'Protection'}.get(e['type'],'Connection')

# Russian functional narratives remain separate from source/net identity.
from functional_ru import localize_scenes, localize_scenarios
from local_stories import add_local_stories
localize_scenes(scenes)
localize_scenarios(scenarios)

# Functional modules are terminal diagrams; their symbols open on this canvas.
# Section/board navigation never opens a component-only page.
for sceneid,obj in scenes.items():
    obj['kind']='module' if sceneid in LEAVES else ('system' if sceneid=='system' else ('board' if sceneid in ('power','control') else 'section'))
    obj['depth']={'system':0,'board':1,'section':1,'module':2}[obj['kind']]
    obj['terminal']=sceneid in LEAVES
    obj['navigationPolicy']='Компоненты раскрываются на текущем полотне; отдельные страницы компонентов не создаются.'
    sheetids=[sceneid] if sceneid in LEAVES else obj.get('sheetIds',[])
    if not sheetids:
        sheetids=list(dict.fromkeys(p['sheet'] for nd in obj['nodes'] for cid in nd['refs'] for p in C[cid]['pins']))
    for nd in obj['nodes']:
        sourceids=([obj['sheetId']] if obj.get('sheetId') else ([nd['sheetId']] if nd.get('sheetId') else list(dict.fromkeys(p['sheet'] for cid in nd['refs'] for p in C[cid]['pins']))))
        nd['sourceSheetIds']=sourceids
        units=list({(cid,p['sheet'],p['unit']) for cid in nd['refs'] for p in C[cid]['pins'] if p['sheet'] in sourceids})
        nd['circuitGroup']={'refs':nd['refs'],'sheetIds':sourceids,'units':[{'component':cid,'sheet':sh,'unit':unit} for cid,sh,unit in sorted(units)]}
        if sceneid in LEAVES:nd.pop('sceneId',None)
    obj['circuitGroup']={'refs':list(dict.fromkeys(c for nd in obj['nodes'] for c in nd['refs'])),'sheetIds':sheetids,'units':list({(u['component'],u['sheet'],u['unit']):u for nd in obj['nodes'] for u in nd['circuitGroup']['units']}.values())}
    for e in obj['edges']:
        exact=[N[nid]['name'] for nid in e['nets'] if N[nid].get('nameSource')=='schematic']
        unnamed=[nid for nid in e['nets'] if N[nid].get('nameSource')!='schematic']
        e['netLabels']=list(dict.fromkeys(exact))
        e['unnamedNetIds']=unnamed
        if sceneid==sid('control',900) and e['id'] in ('connector_isolation_0','isolation_phy_1'):
            prefix='ETH_' if e['id']=='connector_isolation_0' else 'MDI_'
            e['labelLines']=[prefix+letter+'_P · '+prefix+letter+'_N' for letter in 'ABCD']
        else:
            shown=e['netLabels'][:3]
            if len(e['netLabels'])<=2:e['labelLines']=shown
            elif len(e['netLabels'])<=8:
                names=sorted(e['netLabels'])
                e['labelLines']=names if max(map(len,names))>13 else [' · '.join(names[i:i+2]) for i in range(0,len(names),2)]
            elif shown:e['labelLines']=[shown[0]+' · '+shown[1],shown[2]+(' · ещё '+str(len(e['netLabels'])-3) if len(e['netLabels'])>3 else '')]
            else:e['labelLines']=[e['shortLabel']]
        e['allConnectionsLabel']='Все соединения: '+str(len(e['nets']))
        e['namePolicy']='Имена цепей из KiCad; безымянные участки раскрываются по реальным выводам.'

# Reserve space for exact pair names directly between the Ethernet blocks.
for i,n in enumerate(scenes[sid('control',900)]['nodes']):
    n.update(x=40+(i%3)*510,y=40+(i//3)*250,w=250,h=124)
scenes[sid('control',900)]['bounds']={'x':0,'y':0,'w':1360,'h':480}
add_local_stories(scenes,scenarios,A)

from sheet_names import apply_sheet_names, source_name
sheet_scenes=apply_sheet_names(A,scenes)

# Geometry follows the function; source identities and story targets stay fixed.
from semantic_layouts import apply_semantic_layouts
apply_semantic_layouts(scenes)

# Validation is part of generation: every physical component is retained, every
# scene/step target exists, and no invented electrical identity is introduced.
errors=[]
for sceneid,obj in scenes.items():
    ids={n['id'] for n in obj['nodes']};eids={e['id'] for e in obj['edges']}
    for n in obj['nodes']:
        for cid in n['refs']:
            if cid not in C:errors.append(('component',sceneid,cid))
        if n.get('sceneId') and n['sceneId'] not in scenes:errors.append(('scene',sceneid,n['sceneId']))
    for e in obj['edges']:
        if e['from'] not in ids or e['to'] not in ids:errors.append(('endpoint',sceneid,e))
        for nid in e['nets']:
            if nid not in N:errors.append(('net',sceneid,nid))
    if sceneid in LEAVES:
        covered={c for n in obj['nodes'] for c in n['refs']}
        missing=set(allrefs(sceneid))-covered
        if missing:errors.append(('unmapped components',sceneid,list(missing)))
for s in scenarios:
    for frame in s['steps']:
        obj=scenes[frame['sceneId']]; ids={n['id'] for n in obj['nodes']};eids={e['id'] for e in obj['edges']}
        if set(frame['nodes'])-ids:errors.append(('scenario node',s['id'],frame['nodes']))
        if set(frame['edges'])-eids:errors.append(('scenario edge',s['id'],frame['edges']))
assert not errors,errors
assert set(LEAVES)<=set(scenes)
assert all(obj.get('localScenarioIds') for obj in scenes.values()),'Scene without a local story'
assert all(not n.get('sceneId') for sceneid in LEAVES for n in scenes[sceneid]['nodes']),'Component-level page navigation'
for story in scenarios:
    for frame in story['steps']:
        for nid in frame.get('netIds',[]):assert nid in N,(story['id'],nid)
        for pin in frame.get('pinHighlights',[]):
            assert pin['component'] in C
            assert any(str(p['number'])==str(pin['pin']) and p.get('net')==pin['netId'] for p in C[pin['component']]['pins']),(story['id'],pin)
result={'version':'4.1','sheetScenes':sheet_scenes,'namingPolicy':'Имена листов из KiCad; пояснения и истории на русском','language':'ru','model':'functional-first','note':'Функциональные объяснения с точными обозначениями KiCad. Межплатные связи на общей карте показывают назначение; соответствие ответных контактов не заявляется.','scenes':scenes,'scenarios':scenarios,'coverage':{'circuitSheets':len(LEAVES),'coveredCircuitSheets':len(set(LEAVES)&set(scenes)),'allPhysicalComponentsGrouped':True,'validatedComponentReferences':True,'validatedNetReferences':True,'scenesWithLocalStories':len(scenes),'localStories':sum(1 for s in scenarios if s.get('local')),'educationalSteps':sum(len(s['steps']) for s in scenarios),'exactConnectionLabels':True,'terminalFunctionalModules':len(LEAVES)}}
result.update(layoutVersion=1,layoutStrategy='Роль блока, основной тракт, боковые ветви и парные переходы')
mapdir=ROOT/'data/maps';flowdir=ROOT/'data/flows'
mapdir.mkdir(parents=True,exist_ok=True);flowdir.mkdir(parents=True,exist_ok=True)
tags=[]
for sceneid,obj in scenes.items():
    name=re.sub(r'[^A-Za-z0-9_-]','_',sceneid)+'.js'
    rel='data/maps/'+name
    (ROOT/rel).write_text('/* Editable functional scene: '+sceneid+' */\nwindow.MIRA_FUNCTIONAL.scenes['+json.dumps(sceneid)+']='+json.dumps(obj,ensure_ascii=False,indent=2)+';\n')
    tags.append('  <script defer src="'+rel+'"></script>')
for obj in scenarios:
    rel='data/flows/'+re.sub(r'[^A-Za-z0-9_-]','_',obj['id'])+'.js'
    (ROOT/rel).write_text('/* Educational animation path; no hardware control. */\nwindow.MIRA_FUNCTIONAL.scenarios.push('+json.dumps(obj,ensure_ascii=False,indent=2)+');\n')
    tags.append('  <script defer src="'+rel+'"></script>')
header={**result,'scenes':{},'scenarios':[]}
(ROOT/'data/functional-maps.js').write_text('/* Shared functional map metadata. Individual scenes: data/maps; animation paths: data/flows. */\nwindow.MIRA_FUNCTIONAL='+json.dumps(header,ensure_ascii=False,indent=2)+';\n')
marker='  <!-- Functional scene and flow files -->'
endmarker='  <!-- End functional scene and flow files -->'
block=marker+'\n'+'\n'.join(tags)+'\n'+endmarker+'\n'
index=(ROOT/'index.html').read_text()
if marker in index:index=re.sub(re.escape(marker)+r'[\s\S]*?'+re.escape(endmarker)+r'\n?',lambda _:block,index)
else:index=index.replace('  <script defer src="js/functional.js"></script>',block+'  <script defer src="js/functional.js"></script>')
if '--no-index' not in sys.argv:(ROOT/'index.html').write_text(index)
(ROOT/'data/functional-script-manifest.txt').write_text('\n'.join(tags)+'\n')
# Localize technical prose without altering the immutable KiCad source snapshot.
module_updates={}
for sceneid,obj in scenes.items():
    if sceneid not in LEAVES:continue
    ss=S[sceneid]; ns=obj['nodes']; named=[N[nid]['name'] for nid in ss['nets'] if N[nid].get('nameSource')=='schematic' and N[nid]['name']!='GND']
    story=next((st for st in scenarios if st['id']==obj['suggestedScenario']),None)
    module_updates[ss['file']]={'title':obj['title'],'purpose':obj['description'],'operation':[st['text'] for st in story['steps']] if story else [n['description'] for n in ns],'inputs':['Питание и управляющие / сигнальные входы показаны по реальным выводам на фрагменте схемотехники.'],'outputs':['Выходы и двунаправленные связи раскрываются по именам цепей и выводам выбранного функционального блока.'],'notes':['Обозначения компонентов, цепей и выводов сохранены из KiCad.','История показывает назначение и путь сигнала; электрические параметры не моделируются.','Цепи узла: '+', '.join(named[:16])+(' и другие.' if len(named)>16 else '.')]}
hierarchy_titles={'control_MIRA_Control':'Плата Control · функциональная структура','control_MCU':'Хост-контроллер, память и надзор','control_INTERCONNECT':'Входы питания и аппаратные разрешения','control_FPGA':'ПЛИС, память и внешние интерфейсы','control_DAC':'Аналоговые команды и буферы источников','control_MATRIX':'Фиксация маршрутов, драйверы линий и разъём матрицы','control_ADC':'Преобразование тока и точное измерение','control_PROTECTION':'Общий регулятор напряжения / тока и память аварии','power_POWER_SYSTEM':'Плата Power · система питания','power_POWER_INPUT':'Вход и защита питания','power_POWER_CONTROL':'Управление питанием и безопасность','power_PRIMARY_POWER':'Основные преобразователи','power_PROGRAM_SWITCHES':'Коммутация программирующих шин','power_POWER_MONITOR':'Измерение напряжений и токов','power_SECONDARY_POWER':'Преобразователи нагрузочных доменов'}
for sceneid,title in hierarchy_titles.items():
    ss=S[sceneid]
    module_updates[ss['file']]={'title':title,'purpose':'Этот обзор объединяет функциональные узлы раздела «'+title+'». Выберите узел, чтобы проследить его работу и точные подключения.','inputs':['Входные цепи приведены на соответствующих функциональных диаграммах.'],'outputs':['Выходные цепи продолжаются к связанным узлам схемы.'],'operation':['Выберите дочерний функциональный узел, чтобы увидеть его локальную историю и подключения.'],'notes':['Иерархический лист объединяет дочерние листы и не является дополнительной схемотехникой.','Имена компонентов и цепей совпадают с исходными файлами KiCad.']}
net_descriptions={}
for nid,n in N.items():
    if n.get('nameSource')!='schematic':continue
    endpoints=list(dict.fromkeys(C[p['component']]['ref']+'.'+str(p['pin']) for p in n['pins'] if not p.get('virtual')))
    text='Цепь '+n['name']+' на плате '+('Control' if n['board']=='control' else 'Power')+'. Подключения: '+', '.join(endpoints[:8])+(' · ещё '+str(len(endpoints)-8)+' выводов.' if len(endpoints)>8 else '.')
    if re.match(r'^ETH_[ABCD]_[PN]$',n['name']):text='Кабельная сторона Ethernet: провод дифференциальной пары между J900 и T900. '+text
    elif re.match(r'^MDI_[ABCD]_[PN]$',n['name']):text='Сторона PHY: провод дифференциальной пары между T900 и U902. '+text
    elif re.match(r'^PHY_RX(D[0-3]|C|_CTL)$',n['name']):text='Приёмный тракт RGMII от PHY U902 к ПЛИС U500. '+text
    elif re.match(r'^PHY_TX(D[0-3]|C|_CTL)$',n['name']):text='Передающий тракт RGMII от ПЛИС U500 к PHY U902. '+text
    net_descriptions[n['board']+':'+n['name']]=text
all_titles={sid:source_name(ss) for sid,ss in S.items()}
for ss in S.values():
    update=module_updates[ss['file']]
    update['explanationTitleRu']=scenes[sheet_scenes[ss['id']]].get('explanationTitleRu',update['title'])
    update['title']=source_name(ss)
js='/* Russian explanations; exact source identifiers remain unchanged. */\n(function(){const C=window.MIRA_CONTENT;if(!C)return;C.language=\"ru\";C.sheetTitles='+json.dumps(all_titles,ensure_ascii=False)+';const updates='+json.dumps(module_updates,ensure_ascii=False)+';for(const[id,value]of Object.entries(updates)){if(C.modules[id])Object.assign(C.modules[id],value);} C.netDescriptions='+json.dumps(net_descriptions,ensure_ascii=False)+'; Object.assign(C.meta,'+json.dumps({'language':'ru','title':'MIRA · функциональное устройство и подключения','scope':'22 функциональных листа Control, 40 листов Power и иерархические обзоры.','controlSource':'Организованный снимок MIRA_Control v5 от 18 октября 2026 года.','powerSource':'Доступное поддерево POWER_SYSTEM из архива MIRA_RevA_Full_KiCad; отдельный более ранний снимок.','behavior':'Учебные истории объясняют работу узлов; прошивка, электрические задержки и физические формы сигналов не моделируются.','identity':'Компоненты, цепи и выводы проверены по исходным листам. Секции одного корпуса сохраняют физическую идентичность внутри своей платы.','interboard':'Совпадающие имена шин показывают логическое назначение. Ответные контакты Control J400 и разъёмов Power не проверены как пара.','connectionRoles':'Имена и подключения взяты из схемы; подсветка истории показывает рассматриваемый тракт.'},ensure_ascii=False)+'); C.proposedLinks=(C.proposedLinks||[]).map(p=>({...p,description:\"Логическая связь одноимённых шин \"+p.powerNet+\" между платами Power и Control.\",status:\"Назначение ответных контактов не подтверждено\"})); C.localization={language:\"ru\",sourceNamesPreserved:true};})();\n'
(ROOT/'data/ru-content.js').write_text(js)
print(json.dumps({'scenes':len(scenes),'leafScenes':len(LEAVES),'scenarios':len(scenarios),'modularFiles':len(tags),'validation':'passed'}))
