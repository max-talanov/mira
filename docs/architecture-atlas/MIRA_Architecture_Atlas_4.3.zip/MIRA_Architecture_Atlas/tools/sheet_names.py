"""Use KiCad hierarchy names for navigation, keeping explanations in Russian."""
from pathlib import Path

SECTION_SHEETS = {
    'power-input': 'power_POWER_INPUT',
    'power-primary': 'power_PRIMARY_POWER',
    'power-secondary': 'power_SECONDARY_POWER',
    'power-program': 'power_PROGRAM_SWITCHES',
    'power-supervisor': 'power_POWER_CONTROL',
    'power-monitoring': 'power_POWER_MONITOR',
    'control-host': 'control_MCU',
    'control-boundary': 'control_INTERCONNECT',
    'control-fpga': 'control_FPGA',
    'control-sources': 'control_DAC',
    'control-routing': 'control_MATRIX',
    'control-readout': 'control_ADC',
    'control_PROTECTION': 'control_PROTECTION',
}

def source_name(sheet):
    # Root sheets have no parent Sheetname property. Their file tab is the
    # authoritative fallback; child names were extracted from Sheetname.
    return sheet['name'] if sheet.get('parent') else Path(sheet['file']).stem

def apply_sheet_names(atlas, scenes):
    sheets = atlas['sheets']
    bindings = {sid: sid for sid in sheets if sid in scenes}
    bindings.update({scene: sheet for scene, sheet in SECTION_SHEETS.items() if scene in scenes})
    bindings.update({'control': 'control_MIRA_Control', 'power': 'power_POWER_SYSTEM'})
    # Keep old URLs/story IDs usable while the public hierarchy uses PROTECTION.
    legacy = {'control-regulation': 'control_2100_PROTECTION_WRITE_CURRENT_COMPLIANCE',
              'control-safety': 'control_2200_PROTECTION_MATRIX_TRIP_AND_FAULT_INTERFACE'}
    bindings.update(legacy)
    canonical = {}
    for sceneid, sheetid in bindings.items():
        scene, sheet = scenes[sceneid], sheets[sheetid]
        scene['explanationTitleRu'] = scene['title']
        scene['title'] = source_name(sheet)
        scene['subtitle'] = scene['explanationTitleRu']
        scene['sourceSheetId'] = sheetid
        scene['sourceSheetName'] = source_name(sheet)
        scene['sourceFile'] = sheet['file']
        scene['nameSource'] = 'kicad-sheetname' if sheet.get('parent') else 'root-filename'
        scene['hidden'] = sceneid in legacy
        if not scene['hidden']:
            canonical[sheetid] = sceneid
    for sceneid, scene in scenes.items():
        if sceneid == 'system':
            scene['title'] = 'MIRA'
            scene['subtitle'] = 'Общая структура · названия разделов и модулей совпадают с KiCad'
        source = sheets.get(scene.get('sourceSheetId'))
        if source:
            scene['parentScene'] = canonical.get(source.get('parent'), 'system')
        for node in scene['nodes']:
            target = node.get('sceneId') or node.get('detailSceneId')
            if target in legacy:
                node['sceneId'] = 'control_PROTECTION'
                target = 'control_PROTECTION'
            destination = scenes.get(target)
            if not destination or not destination.get('sourceSheetId'):
                continue
            node['explanationTitleRu'] = node['title']
            node['title'] = destination['sourceSheetName']
            node['subtitle'] = node['explanationTitleRu']
            node['sourceSheetName'] = destination['sourceSheetName']
            node['sourceSheetId'] = destination['sourceSheetId']
            node['sourceFile'] = destination['sourceFile']
    assert set(canonical) == set(sheets), ('Source sheets without a diagram', set(sheets)-set(canonical))
    return canonical
