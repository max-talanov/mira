#!/usr/bin/env node
/* Real functional-engine regression test with a small in-process DOM and RAF clock. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const decode=s=>String(s).replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
function one(el,sel){
 sel=sel.trim();const tag=sel.match(/^[A-Za-z][\w-]*/);if(tag&&el.tagName.toLowerCase()!==tag[0].toLowerCase())return false;
 for(const m of sel.matchAll(/\.([\w-]+)/g))if(!el.classList.contains(m[1]))return false;
 for(const m of sel.matchAll(/\[([^\]=]+)(?:=["']?([^\]"']+)["']?)?\]/g))if(!el.hasAttribute(m[1])||(m[2]!==undefined&&el.getAttribute(m[1])!==m[2]))return false;
 return true;
}
function matches(el,selector){return selector.split(',').some(s=>{const parts=s.trim().split(/\s+/);if(!one(el,parts.pop()))return false;let p=el.parentNode;while(parts.length){const part=parts.pop();while(p&&!one(p,part))p=p.parentNode;if(!p)return false;p=p.parentNode;}return true;});}
class Element{
 constructor(tag){this.tagName=String(tag).toUpperCase();this.attrs={};this.children=[];this.parentNode=null;this.style={};this.listeners={};this._text='';this.hidden=false;}
 get className(){return this.attrs.class||'';}set className(s){this.attrs.class=String(s);}
 get classList(){const e=this;return{contains:c=>e.className.split(/\s+/).includes(c),add(...cs){const set=new Set(e.className.split(/\s+/).filter(Boolean));cs.forEach(c=>set.add(c));e.className=[...set].join(' ');},remove(...cs){e.className=e.className.split(/\s+/).filter(c=>c&&!cs.includes(c)).join(' ');},toggle(c,v){const yes=v===undefined?!this.contains(c):!!v;yes?this.add(c):this.remove(c);return yes;}};}
 get dataset(){const e=this;return new Proxy({},{get:(_,key)=>e.attrs['data-'+String(key).replace(/[A-Z]/g,c=>'-'+c.toLowerCase())]});}
 setAttribute(k,v){this.attrs[k]=String(v);if(k==='hidden')this.hidden=true;}
 getAttribute(k){return Object.hasOwn(this.attrs,k)?this.attrs[k]:null;}
 hasAttribute(k){return Object.hasOwn(this.attrs,k);}
 removeAttribute(k){delete this.attrs[k];if(k==='hidden')this.hidden=false;}
 appendChild(n){if(n.parentNode)n.remove();this.children.push(n);n.parentNode=this;return n;}
 append(...ns){ns.forEach(n=>this.appendChild(n));}
 replaceChildren(...ns){this.children.forEach(n=>n.parentNode=null);this.children=[];this._text='';this.append(...ns);}
 remove(){if(this.parentNode){const a=this.parentNode.children;a.splice(a.indexOf(this),1);this.parentNode=null;}}
 contains(n){while(n){if(n===this)return true;n=n.parentNode;}return false;}
 matches(s){return matches(this,s);}
 closest(s){let n=this;while(n){if(matches(n,s))return n;n=n.parentNode;}return null;}
 querySelectorAll(s){const result=[];const walk=e=>{for(const c of e.children){if(matches(c,s))result.push(c);walk(c);}};walk(this);return result;}
 querySelector(s){return this.querySelectorAll(s)[0]||null;}
 addEventListener(t,fn){(this.listeners[t]??=[]).push(fn);}
 removeEventListener(t,fn){this.listeners[t]=(this.listeners[t]||[]).filter(f=>f!==fn);}
 get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
 set textContent(s){this.replaceChildren();this._text=String(s);}
 get innerHTML(){return this._text+this.children.map(c=>'<'+c.tagName+' '+JSON.stringify(c.attrs)+'>'+c.innerHTML+'</'+c.tagName+'>').join('');}
 set innerHTML(html){
  this.replaceChildren();const stack=[this],voids=new Set(['INPUT','BR','HR','IMG','META','LINK']);
  for(const token of String(html).matchAll(/<[^>]+>|[^<]+/g)){const t=token[0];if(t.startsWith('</')){if(stack.length>1)stack.pop();continue;}if(t.startsWith('<')){if(t.startsWith('<!'))continue;const tag=t.match(/^<([\w-]+)/)?.[1];if(!tag)continue;const n=new Element(tag);for(const m of t.slice(tag.length+1,-1).matchAll(/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))n.setAttribute(m[1],decode(m[2]??m[3]??m[4]??''));stack.at(-1).appendChild(n);if(!voids.has(n.tagName)&&!t.endsWith('/>'))stack.push(n);}else stack.at(-1)._text+=decode(t);}
 }
 getBoundingClientRect(){return{width:this.classList.contains('mf-bottom')?900:1280,height:this.classList.contains('mf-bottom')?185:800,left:0,top:0};}
 focus(){}setPointerCapture(){}releasePointerCapture(){}
}
const document={createElement:t=>new Element(t),createElementNS:(_,t)=>new Element(t),fullscreenElement:null};
const persisted=new Map(),raf=new Map();let nextRaf=0,time=0;
const ctx={console,document,localStorage:{getItem:k=>persisted.get(k)||null,setItem:(k,v)=>persisted.set(k,String(v))},ResizeObserver:class{observe(){}disconnect(){}},requestAnimationFrame:f=>{raf.set(++nextRaf,f);return nextRaf;},cancelAnimationFrame:id=>raf.delete(id),setTimeout:()=>1,clearTimeout(){},matchMedia:()=>({matches:false}),addEventListener(){},removeEventListener(){}};
ctx.window=ctx;vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g))vm.runInContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx,{filename:m[1]});
vm.runInContext(fs.readFileSync(path.join(root,'js/functional.js'),'utf8'),ctx,{filename:'js/functional.js'});
let circuitMounts=0,lastCircuit=null;
ctx.MiraCircuit={mount(host,options){circuitMounts++;const c={options,selection:options,camera:{x:0,y:0,w:1000,h:650},destroyed:false,destroy(){this.destroyed=true;},setSelection(v){this.selection=v;},getViewport(){return{...this.camera};},zoom(v){this.camera.w/=v;this.camera.h/=v;},fit(){}};lastCircuit=c;return c;}};
function frames(n){for(let i=0;i<n;i++){time+=1000/60;const callbacks=[...raf];raf.clear();callbacks.forEach(([,f])=>f(time));}}
function fire(target,type='click',extra={}){assert(target,'Missing event target');const ev={target,defaultPrevented:false,preventDefault(){this.defaultPrevented=true;},stopPropagation(){this.stopped=true;},...extra};let el=target;while(el){for(const fn of el.listeners[type]||[])fn(ev);if(ev.stopped)break;el=el.parentNode;}}
const A=ctx.MIRA_ATLAS,maps=ctx.MIRA_FUNCTIONAL,sceneId='control_900_FPGA_ETHERNET_AND_MCU_INTERFACE',story=maps.scenarios.find(s=>s.id==='local-'+sceneId);assert(story?.steps.length>=4);
const host=new Element('div'),engine=ctx.MiraFunctional.mount(host,{atlas:A,maps,content:ctx.MIRA_CONTENT,sceneId});
engine.setScenario(story.id);engine.zoom(1.2);engine.play();
const camera=JSON.stringify(engine.getState().camera),svg=host.querySelector('.mf-svg'),storyDom=host.querySelector('.mf-story-text'),firstText=storyDom.textContent;
frames(36000); // Ten minutes on a 60 Hz animation clock.
assert.equal(engine.getState().stepIndex,0,'Signals never advance narration after ten minutes');assert(engine.getState().playing,'Signal animation still running');assert.strictEqual(host.querySelector('.mf-story-text'),storyDom,'RAF does not recreate explanatory text');assert.equal(storyDom.textContent,firstText);assert.equal(JSON.stringify(engine.getState().camera),camera);assert.strictEqual(host.querySelector('.mf-svg'),svg);
const last=story.steps.length-1;engine.seek(last);assert(engine.getState().playing,'Seeking manually keeps animation running');engine.pause();engine.play();assert.equal(engine.getState().stepIndex,last,'Play on last step never restarts story');const lastText=host.querySelector('.mf-story-text').textContent;frames(18000);assert.equal(engine.getState().stepIndex,last);assert.equal(host.querySelector('.mf-story-text').textContent,lastText);
engine.step(-1);assert.equal(engine.getState().stepIndex,last-1);assert(engine.getState().playing);engine.step(1);engine.step(1);assert.equal(engine.getState().stepIndex,last);assert(engine.getState().playing,'Last step stays animated without wrapping');
fire(host.querySelector('[data-step="0"]'));assert.equal(engine.getState().stepIndex,0);assert(engine.getState().playing);assert(host.querySelector('[data-act="play"]').getAttribute('aria-label').includes('сигналы'));assert(host.querySelector('.mf-story-mode').textContent.includes('вручную'));
engine.setView('circuit');const group=engine.getState().circuitNodeId,mounts=circuitMounts,circuit=lastCircuit;circuit.zoom(1.2);const circuitCamera=JSON.stringify(circuit.getViewport());
engine.seek(3);frames(18000);assert.equal(engine.getState().circuitNodeId,group,'Story cannot switch the chosen UGO group');assert.equal(circuitMounts,mounts,'Step highlights do not remount UGO');assert.equal(JSON.stringify(circuit.getViewport()),circuitCamera);assert(circuit.selection.pinHighlights.length,'Current story still updates real pin highlights');assert(!host.querySelector('[data-follow-story]'),'No automatic UGO-group checkbox');assert.equal(engine.getState().followStory,false);
const picker=host.querySelector('[data-circuit-group]');picker.value='phy';fire(picker,'change');assert.equal(engine.getState().circuitNodeId,'phy','User can select a different group');const manualCircuit=lastCircuit;engine.seek(last);assert.strictEqual(lastCircuit,manualCircuit);assert.equal(engine.getState().circuitNodeId,'phy');
engine.setView('functional');assert.equal(JSON.stringify(engine.getState().camera),camera);engine.destroy();assert.equal(raf.size,0,'Destroy cancels animation');
const restored=ctx.MiraFunctional.mount(host,{atlas:A,maps,content:ctx.MIRA_CONTENT,sceneId});assert.equal(restored.getState().stepIndex,last,'Manual narration position survives remount');assert.equal(restored.getState().scenarioId,story.id);assert.equal(restored.getState().playing,false);restored.destroy();
console.log(JSON.stringify({passed:true,realFunctionalEngine:true,simulatedMinutes:20,noTimedStepAdvance:true,lastStepDoesNotRestart:true,textAndCameraStable:true,manualNextBackAndProgress:true,animationContinuesOnManualNavigation:true,ugoGroupOnlyChangesManually:true,pinHighlightsStillUpdate:true,storyPositionRestored:true},null,2));
