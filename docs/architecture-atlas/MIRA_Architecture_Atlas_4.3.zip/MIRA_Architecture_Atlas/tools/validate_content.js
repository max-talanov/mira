#!/usr/bin/env node
/* Optional Node.js validation; the atlas itself needs no Node runtime. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script[^>]+src="([^"]+)"/g)].map(m=>m[1]);
const styles=[...html.matchAll(/<link[^>]+href="([^"]+)"/g)].map(m=>m[1]);
const assert=(ok,msg)=>{if(!ok)throw new Error(msg);};
for(const f of [...scripts,...styles]){assert(!/^(https?:|\/\/)/.test(f),'External runtime dependency: '+f);assert(fs.existsSync(path.join(root,f)),'Missing asset: '+f);}
const ctx={window:{}};for(const f of scripts){const src=fs.readFileSync(path.join(root,f),'utf8');new vm.Script(src,{filename:f});if(f.startsWith('data/'))vm.runInNewContext(src,ctx,{filename:f});}
const a=ctx.window.MIRA_ATLAS,c=ctx.window.MIRA_CONTENT;
assert(a&&c,'Atlas and content must be loaded.');
assert(Object.keys(c.modules).length===Object.keys(a.sheets).length,'Each source sheet needs a module description.');
for(const s of Object.values(a.sheets)){assert(c.modules[s.file],'Missing description: '+s.file);assert(fs.existsSync(path.join(root,s.source.snapshot)),'Missing source snapshot: '+s.file);}
let steps=0;for(const scenario of c.scenarios){assert(scenario.kind==='illustrative','Scenario must declare its interpretation: '+scenario.id);for(const step of scenario.steps){steps++;const s=Object.values(a.sheets).find(s=>s.board===step.board&&s.file===step.sheetFile);assert(s,'Scenario sheet missing: '+scenario.id+' / '+step.sheetFile);for(const ref of step.refs||[])assert(s.components.some(id=>a.components[id].ref===ref),'Unknown scenario reference: '+scenario.id+' / '+ref);for(const name of step.nets||[])assert(s.nets.some(id=>a.nets[id].name===name||a.nets[id].aliases.includes(name)),'Unknown scenario net: '+scenario.id+' / '+name);}}
const desc=c.netDescriptions||{};const named=Object.values(a.nets).filter(n=>!String(n.nameSource).includes('generated'));for(const n of named)assert(desc[n.board+':'+n.name]||desc[n.name],'Missing named-net explanation: '+n.board+':'+n.name);
for(const f of scripts.filter(f=>f.startsWith('js/'))){const src=fs.readFileSync(path.join(root,f),'utf8');assert(!/\b(fetch|XMLHttpRequest|WebSocket)\s*\(/.test(src),'Network operation in '+f);}
console.log(JSON.stringify({passed:true,localScripts:scripts.length,localStyles:styles.length,moduleDescriptions:Object.keys(c.modules).length,scenarios:c.scenarios.length,scenarioSteps:steps,namedNetsWithDescriptions:named.length,offlineRuntime:true},null,2));
