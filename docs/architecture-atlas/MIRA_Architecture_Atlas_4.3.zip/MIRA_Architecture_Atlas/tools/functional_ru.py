"""Deterministic Russian teaching text for the functional atlas.

Only narrative properties are translated. Component references, net identifiers,
source filenames, protocol names and graph identities are left untouched.
Keep translations separate from the source-derived topology so another language
can be added without changing circuit data.
"""
import re


def _pairs(text):
    return dict(line.split("|", 1) for line in text.strip().splitlines() if line.strip())


TEXT = _pairs("""
Follow the function. Open a block to go deeper.|Выберите блок и проследите, как он работает.
One device. Power, commands, analog activity and results.|Одно устройство: питание, команды, аналоговые сигналы и результаты.
Open a function to inspect its own teaching diagram. Shared connections stay linked to their exact source names.|Выберите функцию, чтобы увидеть её работу. Соединения подписаны именами цепей из KiCad.
Grouped exact electrical connections. This summary does not infer signal direction. Open the connection to inspect every member net and pin.|Связь объединяет реальные электрические цепи. Направление сигнала здесь не предполагается. Выберите линию, чтобы увидеть все цепи и выводы.
These functions share the listed exact source nets. Direction is not inferred by this summary.|Эти функции связаны перечисленными цепями исходной схемы. Направление сигнала здесь не предполагается.
The listed exact nets connect these functional groups. Open source detail for all terminals.|Эти функциональные группы соединены указанными цепями. В схемотехнике доступны все выводы.
All physical source components are assigned to functional blocks. Exact nets and pins remain available in Source detail.|Компоненты исходной схемы сгруппированы по функциям. В режиме схемотехники доступны точные цепи и выводы.
Functional relationship for explanation. Open the board or exact connection detail for source nets; cross-board mating pins are not asserted here.|Функциональная связь для объяснения работы. Имена цепей доступны в подробностях. Соответствие контактов между платами здесь не задано.
MIRA · an experiment, end to end|MIRA · от команды до результата
Start with what each part does. Follow one highlighted story across the same canvas, then open a block when you want more detail.|Посмотрите, за что отвечает каждый блок. Запустите историю и проследите весь путь на одной диаграмме; затем раскройте нужный модуль.
DC supply|Источник питания
Energy for both boards|Питание обеих плат
The external source supplies energy to the Power board.|Внешний источник подаёт питание на плату Power.
Power system|Система питания
Protect input · start supply rails|Защита входа · запуск питания
The Power board protects the input and creates the supply rails used throughout MIRA.|Плата Power защищает вход и формирует напряжения питания всех узлов MIRA.
Safety interlocks|Аппаратная защита
Stop unsafe operations|Остановка опасных операций
Hardware interlocks, current limits and remembered faults can stop a matrix operation.|Аппаратные блокировки, ограничение тока и фиксация аварий могут остановить операцию с матрицей.
Experiment controller|Контроллер эксперимента
Prepare commands · track state|Подготовка команд · контроль состояния
The STM32 host stores the experiment and exchanges commands and status with the FPGA.|Основной STM32 хранит эксперимент и обменивается командами и состоянием с ПЛИС.
Computer|Компьютер
Set up experiments · collect results|Настройка эксперимента · сбор результатов
The computer sends experiment commands and receives measurements.|Компьютер отправляет команды эксперимента и получает результаты измерений.
Bring commands to the FPGA|Передача команд в ПЛИС
Ethernet or USB converts the external connection into a digital interface for FPGA logic.|Ethernet и USB преобразуют внешнее соединение в цифровой интерфейс ПЛИС.
FPGA engine|ПЛИС
Precise timing · data movement|Точное время · передача данных
Programmable logic coordinates matrix switching, DAC commands, ADC capture and fast communication.|Программируемая логика управляет коммутацией матрицы, командами ЦАП, приёмом данных АЦП и быстрым обменом.
Analog drive|Аналоговое воздействие
Set the voltages applied to cells|Формирование напряжений на ячейках
DAC setpoints and the shared regulated source create voltages and bounded programming current.|Уставки ЦАП и общий регулируемый источник задают напряжения и ограничивают ток программирования.
Measure the response|Измерение отклика
Convert matrix current into data|Преобразование тока матрицы в данные
The readout converts current into voltage, prepares it for the ADC and returns digital samples.|Измерительный тракт преобразует ток в напряжение, подготавливает сигнал для АЦП и выдаёт цифровые отсчёты.
Memristor matrix|Мемристорная матрица
Apply signals · observe the response|Воздействие · наблюдение отклика
Held switches route the chosen drive through the experimental memristor array.|Зафиксированное состояние ключей направляет выбранное воздействие через экспериментальную мемристорную матрицу.
Control board · from a command to a measurement|Плата Control · от команды до измерения
Commands become precise timing, analog drive, matrix connections and digitized results. Protection stays active beside the measurement path.|Команды задают время, аналоговые воздействия и соединения матрицы. Измерительный тракт возвращает цифровой результат, а защита контролирует операцию.
Receive power and permission|Приём питания и разрешений
Power arrives at J400; domain-safe receivers bring supervisory status to the host and FPGA.|Питание поступает через J400; приёмники на границах доменов передают состояние основному контроллеру и ПЛИС.
Run experiment software|Управление экспериментом
The STM32 uses its own working memory and storage to supervise experiments.|STM32 управляет экспериментами, используя оперативную и постоянную память.
Execute precise timing|Управление точным временем
The FPGA loads its design, connects USB and Ethernet, and coordinates fast data movement.|ПЛИС загружает конфигурацию, обслуживает USB и Ethernet и управляет быстрым обменом данными.
Create analog setpoints|Формирование аналоговых уставок
DACs and buffers produce bit-line voltages, service commands and current limits.|ЦАП и буферы формируют напряжения битовых линий, уставки операций и ограничения тока.
Connect the selected matrix path|Коммутация пути через матрицу
Held routing and line selectors connect the chosen source and return paths to the crossbar.|Зафиксированная коммутация и селекторы подключают выбранный источник и обратный путь к матрице.
Turn matrix current into data|Преобразование тока матрицы в данные
Amplifiers and the ADC turn the electrical response into digital samples.|Усилители и АЦП преобразуют электрический отклик в цифровые отсчёты.
Limit the programming source|Ограничение источника записи
A shared source regulates voltage or current before the routing network.|Общий источник регулирует напряжение или ток перед сетью коммутации.
Stop an unsafe operation|Остановка опасной операции
Independent trip logic remembers faults and withdraws permission.|Независимая логика защиты запоминает аварию и снимает разрешение.
Power board · turn one input into safe supplies|Плата Power · питание и аппаратная защита
Follow the energy path and the independent supervision path on the same diagram. Open any block for the next level.|Проследите путь питания и независимый путь контроля на одной диаграмме. Выберите блок, чтобы рассмотреть его работу.
Protect the 24 V input|Защита входа 24 В
Receive the external supply, interrupt faults and condition the bus.|Приём внешнего питания, отключение при аварии и фильтрация шины.
Create main supply branches|Основные ветви питания
Generate always-on, host, intermediate FPGA and analog supplies.|Формирование дежурного питания, питания контроллера и промежуточных напряжений ПЛИС и аналоговых узлов.
Supply each load domain|Питание отдельных доменов
Generate FPGA, memory, PHY and quiet analog rails from the main branches.|Формирование питания ПЛИС, памяти, PHY и малошумящих аналоговых шин из основных ветвей.
Coordinate safe startup|Безопасный запуск
A dedicated controller and hardware logic qualify the rail commands.|Отдельный контроллер и аппаратная логика проверяют разрешения на включение напряжений.
Observe voltage and current|Контроль напряжения и тока
Sense each rail and route a selected pair of measurements to the power manager.|Измерение каждой шины и передача выбранной пары напряжение/ток контроллеру питания.
Enable programming rails|Включение питания записи
Switch the positive and negative rails used by the experiment source.|Коммутация положительной и отрицательной шин источника экспериментальных воздействий.
External DC supply|Внешний источник питания
Create and sequence power|Питание и порядок запуска
Keep the operation safe|Аппаратная безопасность
Coordinate the experiment|Управление экспериментом
Computer and operator|Компьютер и оператор
Bring commands onto the board|Приём внешних команд
Execute timing and data flow|Временная логика и обмен
Create the analog drive|Формирование воздействия
Convert the response to data|Оцифровка отклика
Connect and test the crossbar|Коммутация и проверка матрицы
Protect incoming power|Защита входного питания
Create the main supply branches|Формирование основных напряжений
Generate the load-specific rails|Питание отдельных нагрузок
Enable programming power|Питание программирования
Coordinate startup and hardware safety|Запуск и аппаратная безопасность
Observe every supply branch|Контроль всех ветвей питания
Run the host application|Основной контроллер
Receive supplies and power permission|Приём питания и разрешений
Load the FPGA and connect fast links|ПЛИС, память и быстрые интерфейсы
Create analog experiment commands|Формирование аналоговых уставок
Hold and route a matrix operation|Фиксация и коммутация операции
Regulate programming current and voltage|Регулирование напряжения и тока записи
Stop and remember matrix faults|Остановка и фиксация аварий матрицы
Host processor · clocks, startup and debug|Основной контроллер · запуск и отладка
MCU working memory|Оперативная память контроллера
MCU storage and board control|Память и управление платой
Power enters the Control board|Вход питания платы Control
Supply the FPGA|Питание ПЛИС
Load and recover the FPGA|Загрузка и восстановление ПЛИС
USB · cable data becomes FPGA words|USB · от кабеля до данных ПЛИС
FPGA memory and timing|Память и тактирование ПЛИС
Ethernet · from cable waveform to FPGA data|Ethernet · от сигнала в кабеле до ПЛИС
Create 32 analog bit-line voltages|32 напряжения битовых линий
Set READ, WRITE and FORMING commands|Уставки READ, WRITE и FORMING
Tell the analog sources what to output|Управление аналоговыми источниками
Allow only a consistent matrix operation|Проверка согласованности операции
Store the 80-bit switch image|80-битное состояние ключей
Connect the selected analog drive to the matrix|Коммутация битовых линий матрицы
Select service voltage, bank and polarity|Выбор источника, банка и полярности
Select matrix rows and readout lines|Выбор строк и измерительных линий
The experimental crossbar connection|Подключение экспериментальной матрицы
Turn matrix current into a measurable signal|Преобразование тока матрицы в напряжение
Digitize the matrix measurement|Оцифровка сигнала матрицы
Limit programming voltage and current|Ограничение напряжения и тока записи
Stop an unsafe matrix operation|Аппаратная остановка матрицы
Connect the external 24 V supply|Подключение внешних 24 В
Protect and indicate the input fuse|Предохранитель и индикация
Limit and disconnect input power|Ограничение и отключение питания
Filter the protected 24 V bus|Фильтрация защищённой шины 24 В
Keep supervision always powered|Дежурное питание контроля
Generate the USB 5 V supply|Питание USB 5 В
Generate host-system 3.3 V|Питание контроллера 3,3 В
Create the FPGA intermediate supply|Промежуточное питание ПЛИС
Prepare the low-noise analog supply|Предстабилизатор аналогового питания
Generate the positive analog rail|Положительное аналоговое питание
Generate the negative analog rail|Отрицательное аналоговое питание
Generate FPGA core voltage|Питание ядра ПЛИС
Generate FPGA auxiliary 1.8 V|Вспомогательное питание ПЛИС 1,8 В
Generate auxiliary 2.5 V|Вспомогательное питание 2,5 В
Generate FPGA I/O 3.3 V|Питание выводов ПЛИС 3,3 В
Generate DDR3L memory voltage|Питание памяти DDR3L
Generate Ethernet PHY core voltage|Питание ядра Ethernet PHY
Track the DDR termination reference|Питание и опора терминации DDR
Clean up analog 5 V|Малошумящее аналоговое питание 5 В
Clean up analog 3.3 V|Малошумящее аналоговое питание 3,3 В
Switch the positive programming rail|Коммутация положительного питания записи
Switch the negative programming rail|Коммутация отрицательного питания записи
Connect the programming supplies|Разъём питания программирования
Coordinate the power sequence|Контроллер последовательности питания
Watch both controllers|Сторожевой контроль контроллеров
Grant or withdraw hardware permission|Аппаратные разрешения и блокировки
Gate the primary converter commands|Разрешения основных преобразователей
Gate the auxiliary converter commands|Разрешения вспомогательных преобразователей
Check analog supply windows|Проверка допустимых напряжений
Combine actual rail readiness|Готовность напряжений питания
Combine commanded operating readiness|Готовность команд включения
Detect negative-rail overcurrent|Защита отрицательной шины по току
Link power supervision and host control|Связь контроллера питания с основным
Measure the negative rail safely|Измерение отрицательной шины
Measure input and system power|Контроль входа и системного питания
Measure FPGA, analog and positive rails|Контроль ПЛИС и аналогового питания
Measure FPGA core and I/O domains|Контроль питания ядра и выводов ПЛИС
Measure memory, PHY and analog domains|Контроль памяти, PHY и аналоговых шин
Choose which supply to measure|Выбор измеряемой шины
Buffer measurements for the controller|Буферы измерений для контроллера
Main timing reference|Основной тактовый источник
The 25 MHz oscillator supplies the host processor clock.|Генератор 25 МГц задаёт тактирование основного контроллера.
Run the experiment|Выполнение эксперимента
The STM32H745 runs the host application and supervises board operation.|STM32H745 выполняет основную программу и контролирует работу платы.
Program and inspect|Программирование и отладка
The debug connector lets an external debugger program and inspect the STM32.|Через отладочный разъём внешний отладчик программирует STM32 и наблюдает его состояние.
Low-speed timekeeping|Низкочастотное тактирование
A separate 32.768 kHz crystal supports low-speed clock functions.|Отдельный кварц 32,768 кГц обеспечивает низкочастотное тактирование.
Reset and boot choice|Сброс и выбор загрузки
The reset button restarts the MCU; the boot jumper selects the startup request.|Кнопка сброса перезапускает контроллер; перемычка BOOT выбирает режим загрузки.
Keep the processor supplied|Локальное питание контроллера
Local capacitors support the MCU supply and internal regulator.|Локальные конденсаторы поддерживают питание контроллера и его внутреннего стабилизатора.
Request a memory access|Запрос обращения к памяти
The MCU memory controller produces the address and SDRAM command.|Контроллер памяти STM32 формирует адрес и команду SDRAM.
Condition the memory bus|Согласование шины памяти
Series resistors damp address, command and clock transitions.|Последовательные резисторы уменьшают звон фронтов адресных, командных и тактовых сигналов.
Hold working data|Хранение рабочих данных
The SDRAM provides 64 MiB of volatile MCU working memory.|SDRAM предоставляет контроллеру 64 МиБ энергозависимой оперативной памяти.
Support memory power|Локальное питание памяти
Nearby capacitors support the memory supply.|Локальные конденсаторы поддерживают питание памяти.
Host processor|Основной контроллер
The STM32 reads persistent data, removable storage and board status.|STM32 читает постоянную память, съёмный носитель и состояние платы.
Keep persistent data|Хранение постоянных данных
Quad-SPI flash stores programs and data after power is removed.|Flash-память Quad-SPI сохраняет программы и данные после выключения питания.
Use removable storage|Съёмный накопитель
The microSD socket connects removable storage to the MCU.|Разъём microSD подключает съёмный накопитель к контроллеру.
Protect the card signals|Защита сигналов карты
ESD devices limit discharges entering from the card socket.|ESD-защита ограничивает электростатические разряды со стороны разъёма карты.
Receive board power|Приём питания платы
J400 is the explicit Control-side interface for incoming rails and supervisory signals.|J400 — входной интерфейс платы Control для напряжений питания и сигналов контроля.
Receive status safely|Безопасный приём состояния
Power-domain receivers deliver status to the host without joining disabled domains.|Приёмники на границах доменов передают состояние контроллеру, не запитывая выключенные домены через сигналы.
Receive matrix permission|Приём разрешения матрицы
A separate I/O-domain receiver supplies the matrix permit signal.|Отдельный приёмник в домене ввода-вывода передаёт разрешение работы матрицы.
FPGA internal logic|Внутренняя логика ПЛИС
CORE1V0 supplies the FPGA logic and block memory.|CORE1V0 питает внутреннюю логику и блочную память ПЛИС.
Core energy reservoirs|Конденсаторы питания ядра
Bulk and local capacitors support the core power domain.|Накопительные и локальные конденсаторы поддерживают домен питания ядра.
Auxiliary and bank reservoirs|Питание банков и вспомогательных узлов
Local capacitors support the auxiliary supply and separate I/O banks.|Локальные конденсаторы поддерживают вспомогательное питание и отдельные банки ввода-вывода.
Store the FPGA design|Хранение конфигурации ПЛИС
Configuration flash holds the bitstream used at startup.|Конфигурационная flash-память хранит битовый поток для загрузки при запуске.
Load programmable logic|Загрузка программируемой логики
The FPGA loads configuration data and reports INIT and DONE status.|ПЛИС загружает конфигурацию и сообщает состояние через INIT и DONE.
Recover and debug|Восстановление и отладка
JTAG provides an independent programming and recovery path.|JTAG обеспечивает независимый путь программирования и восстановления.
Request reconfiguration|Запрос повторной конфигурации
The button or open-drain MCU buffer can restart FPGA configuration.|Кнопка или буфер контроллера с открытым стоком перезапускает конфигурацию ПЛИС.
Filter internal monitoring supply|Фильтр питания внутреннего контроля
The ferrite and local capacitors condition the XADC supply.|Феррит и локальные конденсаторы фильтруют питание XADC.
Connect a USB cable|Подключение кабеля USB
The Type-C receptacle is the external USB connection.|Разъём Type-C служит внешним подключением USB.
Protect cable signals|Защита кабельных сигналов
Low-capacitance ESD devices protect external data and CC lines.|Малоёмкостная ESD-защита защищает внешние линии данных и CC.
Choose cable orientation|Выбор ориентации кабеля
The Type-C controller routes the active SuperSpeed pairs.|Контроллер Type-C коммутирует активные пары SuperSpeed с учётом ориентации кабеля.
Translate USB to parallel data|USB в параллельные данные
The FT601 converts USB traffic into a 32-bit synchronous FIFO interface.|FT601 преобразует обмен USB в 32-битный синхронный интерфейс FIFO.
Process the data stream|Обработка потока данных
FPGA logic exchanges words and flow-control signals with the FIFO bridge.|Логика ПЛИС обменивается словами данных и сигналами управления потоком с мостом FIFO.
Clock and power detection|Тактирование и контроль питания
The crystal and reset-sense buffer support USB-bridge operation.|Кварц и буфер контроля сброса обеспечивают работу моста USB.
Provide a fast reference|Высокочастотная тактовая опора
The differential oscillator supplies the FPGA 200 MHz reference.|Дифференциальный генератор подаёт опорный сигнал 200 МГц в ПЛИС.
Request memory transfers|Обмен с памятью
The FPGA memory interface drives commands and exchanges data.|Интерфейс памяти ПЛИС формирует команды и обменивается данными.
Buffer high-speed data|Буферизация быстрых данных
DDR3L provides 512 MiB of volatile FPGA working memory.|DDR3L предоставляет ПЛИС 512 МиБ энергозависимой рабочей памяти.
Set memory signal bias|Опорные уровни памяти
Termination and reference networks support the DDR3L interface.|Цепи терминации и опорного напряжения обеспечивают работу интерфейса DDR3L.
Network connector|Сетевой разъём
The cable brings electrical Ethernet waveforms to the RJ45 connector.|По кабелю электрический сигнал Ethernet поступает в разъём RJ45.
Electrical isolation|Гальваническая развязка
Four transformer pairs carry the data while separating cable and board electrical domains.|Четыре трансформаторные пары передают сигнал, электрически разделяя кабель и плату.
Recover Ethernet data|Приём сигнала Ethernet
The PHY converts the cable signalling into a clocked digital RGMII interface.|PHY преобразует кабельный сигнал в синхронный цифровой интерфейс RGMII.
Process network frames|Обработка сетевых кадров
The FPGA receives digital data. MAC and higher protocols are implemented inside programmable logic or firmware.|ПЛИС принимает цифровые данные. MAC и протоколы верхних уровней реализуются в программируемой логике или прошивке.
Link host and FPGA domains|Связь MCU и ПЛИС
Separate buffers carry MCU commands, responses and configuration status between power domains.|Отдельные буферы передают команды контроллера, ответы и состояние конфигурации между доменами питания.
Support the link|Обеспечение связи
The 25 MHz crystal, analog regulator and ESD devices support the PHY and external connection.|Кварц 25 МГц, аналоговый стабилизатор и ESD-защита обеспечивают работу PHY и внешнего соединения.
An eight-channel DAC sets this bank of analog voltages.|Восьмиканальный ЦАП задаёт напряжения этой группы битовых линий.
Precision followers buffer the DAC outputs before matrix routing.|Прецизионные повторители буферизуют выходы ЦАП перед коммутацией матрицы.
The fourth DAC completes the 32 independently set voltages.|Четвёртый ЦАП завершает набор из 32 независимо задаваемых напряжений.
Precision followers buffer the final eight DAC outputs.|Прецизионные повторители буферизуют последние восемь выходов ЦАП.
Set experiment voltages|Уставки напряжений эксперимента
The service DAC produces voltage and current-limit commands.|Сервисный ЦАП формирует уставки напряжений и ограничений тока.
Buffer service commands|Буферы сервисных уставок
Precision followers buffer service references before the selected source and regulator.|Прецизионные повторители буферизуют сервисные уставки перед выбором источника и регулированием.
Set the forming voltage|Уставка напряжения FORMING
A separate precision DAC sets the forming source.|Отдельный прецизионный ЦАП задаёт напряжение источника FORMING.
Buffer the forming source|Буфер источника FORMING
The forming amplifier drives the next analog stage.|Усилитель FORMING управляет следующим аналоговым каскадом.
Issue analog setpoints|Передача аналоговых уставок
The FPGA supplies the serial control interface for the DAC bank.|ПЛИС управляет группой ЦАП через последовательный интерфейс.
Define safe idle states|Безопасные начальные состояния
Pull resistors keep select, reset and latch controls defined during startup.|Подтягивающие резисторы задают определённые состояния выбора, сброса и фиксации при запуске.
Request a matrix operation|Запрос операции с матрицей
FPGA outputs request modes, addresses and timing.|Выходы ПЛИС задают запросы режима, адреса и времени операции.
Hold the active request|Фиксация активного запроса
Registers capture the operation fields used during a run.|Регистры фиксируют поля операции на время её выполнения.
Detect a changed request|Контроль изменения запроса
Comparators check the requested fields against the captured fields.|Компараторы сравнивают запрошенные поля с зафиксированными.
Check permission to run|Проверка разрешения на запуск
Logic combines power, mode and interlock conditions before enabling routes.|Логика проверяет питание, режим и блокировки перед разрешением коммутации.
Select the operation|Выбор операции
Mode and held-address logic selects routing and safe operating states.|Логика режима и зафиксированного адреса выбирает коммутацию и безопасные рабочие состояния.
The first shift-register section accepts a serial portion of the 80-bit image.|Первая группа сдвиговых регистров принимает начальную часть 80-битного состояния ключей.
The chain continues through the next four registers.|Последовательная цепочка продолжается через следующие четыре регистра.
The final registers complete the image; latch control applies the held outputs.|Последние регистры завершают образ; сигнал фиксации переносит состояние на выходы.
Switches connect DAC drives, clamps and the selected service path for this bank.|Ключи подключают выходы ЦАП, заземляющие зажимы и выбранный сервисный путь этой группы линий.
The second bank routes another eight bit lines.|Вторая группа коммутирует ещё восемь битовых линий.
The third bank routes another eight bit lines.|Третья группа коммутирует ещё восемь битовых линий.
The final bank completes 32 bit-line routing channels.|Последняя группа завершает 32 канала коммутации битовых линий.
Choose a service source|Выбор сервисного источника
A selector chooses the service voltage used by the operation.|Селектор выбирает сервисное напряжение для текущей операции.
Choose a bit-line bank|Выбор группы битовых линий
The bank selector chooses the service destination.|Селектор группы выбирает, куда направить сервисное воздействие.
Choose programming polarity|Выбор полярности записи
Routing switches select the required source polarity.|Коммутирующие ключи выбирают требуемую полярность источника.
Select READ return and reset|Возврат READ и сброс регулятора
The switches connect the READ return and reset the source-controller state while the source is disabled.|Ключи подключают обратный путь READ и сбрасывают состояние регулятора, пока источник выключен.
Drive selected word lines|Управление выбранными строками
Word-line switches connect the selected drive state to eight WL lines.|Ключи строк подключают выбранное воздействие к восьми линиям WL.
Hold inactive neuron lines|Фиксация неактивных линий NL
Clamp switches define inactive NL states.|Зажимные ключи задают состояние неактивных линий NL.
Select the measured neuron line|Выбор измеряемой линии NL
The analog selector connects one NL path to the readout.|Аналоговый селектор подключает одну линию NL к измерительному тракту.
Qualify routing controls|Проверка команд коммутации
Logic combines the controls used by the line-selection network.|Логика объединяет управляющие сигналы сети выбора линий.
Connect the memristor crossbar|Подключение мемристорной матрицы
The socket exposes bit lines, word lines, neuron lines and bias contacts.|Разъём выводит битовые линии, строки, нейронные линии и контакты смещения.
Choose adapter bias|Выбор смещения адаптера
Bias jumpers define the adapter bias connections shown in the source.|Перемычки задают подключения смещения адаптера согласно исходной схеме.
Convert current to voltage|Преобразование тока в напряжение
The transimpedance amplifier turns matrix return current into a measurable voltage.|Трансимпедансный усилитель преобразует возвращающийся ток матрицы в измеряемое напряжение.
Choose current sensitivity|Выбор чувствительности по току
Feedback selection changes the current-to-voltage conversion range.|Выбор обратной связи меняет диапазон преобразования тока в напряжение.
Choose a monitor point|Выбор точки контроля
An analog selector chooses a diagnostic or source-monitor signal.|Аналоговый селектор выбирает диагностический сигнал или сигнал контроля источника.
Observe without loading|Наблюдение без нагрузки
High-impedance buffers isolate compliance monitor nodes from the selector.|Высокоомные буферы изолируют контрольные точки регулятора от нагрузки селектора.
Define the measurement scale|Опорный уровень измерения
The precision reference establishes the ADC scale.|Прецизионный источник опорного напряжения задаёт масштаб АЦП.
Buffer the selected signal|Буфер выбранного сигнала
The selected monitor signal is buffered before differential conversion.|Выбранный контрольный сигнал буферизуется перед дифференциальным преобразованием.
Prepare a balanced ADC input|Дифференциальный вход АЦП
The differential amplifier produces the two ADC input voltages.|Дифференциальный усилитель формирует два входных напряжения АЦП.
Convert voltage to a number|Преобразование напряжения в число
The ADC samples the prepared analog signal and returns digital results.|АЦП измеряет подготовленный аналоговый сигнал и выдаёт цифровой результат.
Supply the converter domains|Питание измерительного тракта
Local regulators provide the ADC and driver support rails.|Локальные стабилизаторы формируют питание АЦП и входного драйвера.
Choose voltage and current limits|Выбор ограничений напряжения и тока
Analog selectors choose the active operation commands.|Аналоговые селекторы выбирают уставки активной операции.
Measure source-side current|Измерение тока источника
Kelvin sense amplification measures the current delivered by the shared source.|Кельвиновское подключение и измерительный усилитель измеряют ток общего источника.
Regulate voltage or current|Регулирование напряжения или тока
The shared control amplifiers regulate the source using command and sense signals.|Усилители регулятора управляют источником по уставкам и измеренным сигналам.
Drive the regulated source|Выход регулируемого источника
The output amplifier feeds the downstream matrix source routing.|Выходной усилитель подаёт воздействие на последующую коммутацию матрицы.
Bound and reset the controller|Ограничение и сброс регулятора
Clamp and reset circuitry limit controller excursions between operations.|Цепи ограничения и сброса ограничивают отклонения регулятора между операциями.
Detect excessive current|Обнаружение превышения тока
A fast comparator compares sensed write current with the backup trip threshold.|Быстрый компаратор сравнивает измеренный ток записи с резервным порогом отключения.
Qualify protection events|Объединение причин отключения
Logic combines current and configuration trip conditions.|Логика объединяет превышение тока и ошибку конфигурации.
Remember the fault|Фиксация аварии
The latch keeps the fault asserted until the defined reset sequence.|Защёлка удерживает аварийное состояние до предусмотренной последовательности сброса.
Withdraw power permission|Снятие разрешения питания
Transistors provide the fault and inhibit interface to the Power system.|Транзисторы передают аварию и запрет в систему питания Power.
Incoming rail used by this converter.|Входная шина питания этого преобразователя.
Convert and regulate|Преобразование и стабилизация
Accept the enable command|Приём команды включения
The command gate connects controller permission to the regulator enable input.|Разрешающая логика передаёт разрешение контроллера на вход включения стабилизатора.
Set and filter the output|Обратная связь и фильтрация
Feedback, local capacitors and output sensing establish the delivered rail.|Обратная связь, локальные конденсаторы и контроль выхода формируют выходное напряжение.
The generated rail continues to its consumers and monitoring circuits.|Сформированная шина поступает к потребителям и цепям контроля.
Accept external DC power|Приём внешнего питания
The terminal provides the external positive supply and return.|Клеммный разъём принимает внешнее положительное питание и общий провод.
Show input status|Индикация входного питания
Indicator circuits show the input conditions represented in the schematic.|Цепи индикации показывают состояние входного питания согласно схеме.
Interrupt a severe input fault|Отключение тяжёлой аварии
The replaceable fuse sits in the incoming supply path.|Сменный предохранитель включён последовательно во входное питание.
Clamp a brief surge|Ограничение импульса напряжения
The TVS limits transient voltage at the protected input.|TVS ограничивает кратковременные выбросы напряжения на защищённом входе.
Show fuse and input state|Индикация предохранителя и входа
Diodes and the transistor drive the local supply indicators.|Диоды и транзистор управляют локальной индикацией питания.
Limit and disconnect input current|Ограничение и отключение тока
The electronic fuse controls the protected supply and its response to faults.|Электронный предохранитель управляет защищённым питанием и реакцией на аварию.
Control reverse-current path|Защита от обратного тока
The series MOSFET and associated diode form the shown input protection path.|Последовательный MOSFET и связанный диод образуют показанный в схеме путь входной защиты.
Request and show the supply state|Управление и индикация питания
The local control, jumper and indication components set startup behavior.|Цепи управления, перемычка и индикация задают поведение при запуске.
Reduce bus noise|Фильтрация помех шины
The filter and local capacitors condition the protected supply bus.|Фильтр и локальные конденсаторы подавляют помехи на защищённой шине питания.
Observe delivered input power|Контроль входной мощности
The local sense and indicator parts expose the input conditions used elsewhere.|Измерительные и индикаторные цепи предоставляют сигналы состояния входа для остальных узлов.
Connect the positive rail|Подключение положительной шины
Series switching devices connect the positive programming supply when permitted.|Последовательные ключи подключают положительное питание программирования при наличии разрешения.
Translate the enable request|Передача команды включения
The optocoupler and control devices implement the shown positive-rail gate drive.|Оптопара и управляющие компоненты формируют управление затворами положительной шины.
Discharge the gate quickly|Быстрый разряд затвора
The clamp devices remove gate drive and define the off state.|Зажимные элементы снимают управление затвором и обеспечивают выключенное состояние.
Connect the negative rail|Подключение отрицательной шины
Switching devices connect or isolate the negative programming supply.|Ключи подключают или изолируют отрицательное питание программирования.
Translate isolated commands|Развязанная передача команд
Optocouplers transfer the control requests into the negative gate-drive domain.|Оптопары передают команды в домен управления затворами отрицательной шины.
Bound gate and output voltage|Ограничение затвора и выхода
The diode network provides the source protection and clamp paths shown in the schematic.|Диодная сеть формирует показанные на схеме защитные и ограничивающие пути источника.
Expose the programming rails|Вывод питания программирования
The connector exposes switched positive and negative programming supplies.|Разъём выводит коммутируемое положительное и отрицательное питание программирования.
Condition the monitor output|Подготовка сигнала контроля
The local divider and clamp condition the program-supply sense signal.|Локальный делитель и ограничитель подготавливают сигнал измерения питания программирования.
Sequence and supervise|Последовательность запуска и контроль
The STM32G0 power manager issues rail requests and reads telemetry and status.|Контроллер питания STM32G0 выдаёт запросы включения шин и читает измерения и состояние.
Support controller startup|Обеспечение запуска контроллера
Local supply and startup support components keep the manager operating.|Локальные цепи питания и запуска обеспечивают работу контроллера питания.
Watch the power manager|Контроль контроллера питания
A watchdog supervises the power-manager heartbeat and reset path.|Сторожевой таймер контролирует импульсы работоспособности и сброс контроллера питания.
Watch the host processor|Контроль основного контроллера
A separate watchdog supervises the host heartbeat and reset path.|Отдельный сторожевой таймер контролирует импульсы работоспособности и сброс основного контроллера.
Combine reset requests|Объединение запросов сброса
The diode and bias network implements the shown reset combination.|Диодная сеть и цепи смещения объединяют запросы сброса согласно схеме.
Accept stop and interlock inputs|Приём остановки и блокировок
External contacts and the hardware interlock can withdraw permission.|Внешние контакты и аппаратная блокировка могут снять разрешение.
Combine safety conditions|Проверка условий безопасности
Hardware logic requires the relevant conditions before a permit can exist.|Аппаратная логика выдаёт разрешение только при выполнении необходимых условий.
Remember withdrawn permission|Фиксация снятого разрешения
The flip-flops retain the hardware enable or trip state until rearmed.|Триггеры сохраняют разрешение или аварийное состояние до повторного взвода.
Drive permit boundaries|Вывод разрешений и запретов
Transistors implement the shown permit and inhibit interface.|Транзисторы формируют показанный на схеме интерфейс разрешения и запрета.
Qualify the first enable group|Первая группа разрешений
Each gate combines the requested state with the corresponding hardware permission.|Каждый логический элемент объединяет запрос включения с соответствующим аппаратным разрешением.
Qualify the second enable group|Вторая группа разрешений
The remaining gates independently qualify their converter requests.|Остальные логические элементы независимо проверяют запросы своих преобразователей.
Default commands to off|Выключение по умолчанию
Pull resistors give the command network defined startup states.|Подтягивающие резисторы задают определённые начальные состояния команд.
Set acceptable analog windows|Задание допустимых диапазонов
Divider networks define the comparator thresholds for analog supply checks.|Делители задают пороги компараторов для проверки аналогового питания.
Check analog rails|Проверка аналоговых напряжений
The quad comparator turns the rail measurements into digital readiness signals.|Четырёхканальный компаратор преобразует измеренные напряжения в цифровые сигналы готовности.
Combine primary readiness|Готовность основных шин
Combine auxiliary readiness|Готовность вспомогательных шин
Combine final readiness|Итоговая готовность
Hardware logic combines this group of readiness conditions; open exact connections to inspect every input.|Аппаратная логика объединяет эту группу условий готовности. Все входы доступны в точных соединениях.
Define the negative-current limit|Порог тока отрицательной шины
The divider and filtering establish the hardware comparison threshold.|Делитель и фильтрация задают аппаратный порог сравнения.
Detect negative overcurrent|Превышение тока отрицательной шины
The comparator checks the conditioned negative-current measurement.|Компаратор проверяет подготовленный сигнал тока отрицательной шины.
Program the power manager|Программирование контроллера питания
The SWD connector gives a debugger access to the power-manager MCU.|Разъём SWD предоставляет отладчику доступ к контроллеру питания.
Connect host supervision|Связь с основным контроллером
The host connector carries UART, watchdog and status signals.|Межконтроллерный разъём передаёт UART, сигналы сторожевого контроля и состояния.
Receive host signals safely|Безопасный приём сигналов
The Ioff buffer separates signals across supply-domain boundaries.|Буфер с поддержкой Ioff разделяет сигналы на границе доменов питания.
Translate negative voltage and current|Преобразование отрицательных измерений
The dual amplifier converts negative-rail information into ground-referenced monitor signals.|Сдвоенный усилитель преобразует сигналы отрицательной шины в контрольные сигналы относительно общего провода.
Protect the monitor inputs|Защита входов измерения
Clamps and filtering bound the measurement outputs before telemetry.|Ограничители и фильтры защищают измерительные выходы перед передачей в систему контроля.
A current-sense amplifier and local conditioning produce voltage/current telemetry for this rail. Hardware alerts act independently of scanned telemetry.|Измерительный усилитель тока и локальные цепи формируют сигналы напряжения и тока этой шины. Аппаратная аварийная сигнализация действует независимо от опроса измерений.
Choose a current measurement|Выбор измеряемого тока
The 16-way selector connects one rail current monitor to the common current path.|Селектор 16:1 подключает сигнал тока одной шины к общему измерительному пути.
Choose the matching voltage|Выбор соответствующего напряжения
The paired selector uses the same address to select that rail voltage.|Парный селектор по тому же адресу выбирает напряжение этой шины.
Drive the controller ADC|Буферы перед АЦП контроллера
Two unity-gain buffers isolate the selected current and voltage from ADC sampling load.|Два повторителя изолируют выбранные сигналы тока и напряжения от импульсной нагрузки входов АЦП.
Define selection and alert defaults|Начальные состояния выбора и аварий
Bias, output isolation and filter components define startup and ADC-drive behavior.|Цепи смещения, выходной развязки и фильтрации задают поведение при запуске и работе с АЦП.
""")

TEXT.update(_pairs("""
Configuration data|Данные конфигурации
Serial commands|Последовательные команды
Supply + supervision|Питание и контроль
Power / status|Питание / состояние
Commands and status|Команды и состояние
Commands / status|Команды
Serial setpoints|Последовательные уставки
Setpoints|Уставки
32 bit-line voltages|32 напряжения битовых линий
32 analog voltages|32 аналоговых напряжения
Voltage / current commands|Уставки напряжения / тока
Source commands|Уставки источника
Regulated programming source|Регулируемый источник записи
Regulated drive|Регулируемое воздействие
Mode, held image and timing|Режим, состояние ключей и время
Routes / timing|Коммутация / время
Selected matrix current|Выбранный ток матрицы
Matrix current|Ток матрицы
Digital measurement results|Цифровые результаты измерений
Samples|Отсчёты
Independent source-current sense|Независимый контроль тока источника
Current sense|Контроль тока
Trip and inhibit|Авария и запрет
Trip / inhibit|Авария / запрет
Matrix permission|Разрешение матрицы
Permission|Разрешение
Eight programmed voltages|Восемь заданных напряжений
8 voltages|8 напряжений
25 MHz clock|Тактирование 25 МГц
Low-speed clock|Низкочастотное тактирование
Reset / boot request|Сброс / выбор загрузки
Debug access|Доступ отладчика
Supply and local reservoirs|Питание и локальные конденсаторы
Local power|Локальное питание
Hardware protection|Аппаратная защита
Protection|Защита
Selection and held control|Выбор и фиксация управления
Held selection|Зафиксированный выбор
Addresses, clock and commands|Адреса, тактирование и команды
Address / command|Адрес / команда
Conditioned bus signals|Сигналы после согласования
Conditioned bus|Согласованная шина
16-bit data bus|16-битная шина данных
16-bit data|16-битные данные
3.3 V memory supply|Питание памяти 3,3 В
Persistent data|Постоянные данные
Auxiliary / I/O / memory domains|Вспомогательное питание / банки / память
Supply|Питание
Bitstream over configuration SPI|Конфигурационный поток по SPI
Bitstream|Конфигурация
JTAG programming|Программирование JTAG
Restart configuration|Перезапуск конфигурации
Reconfigure|Переконфигурация
Filtered XADC supply|Фильтрованное питание XADC
XADC power|Питание XADC
32-bit data and handshakes|32-битные данные и управление обменом
32-bit data|32-битные данные
200 MHz differential clock|Дифференциальное тактирование 200 МГц
Address / command / clock|Адрес / команда / тактирование
16 data bits and strobes|16 бит данных и стробы
VTT and reference bias|VTT и опорное смещение
DDR bias|Опорные уровни DDR
Four cable pairs|Четыре кабельные пары
Cable pairs|Кабельные пары
Isolated physical-layer signal|Сигнал после гальванической развязки
Isolated signal|Развязанный сигнал
Receive: data + clock + valid|Приём: данные, тактирование, достоверность
RX data|Данные приёма
Transmit: data + clock + valid|Передача: данные, тактирование, достоверность
TX data|Данные передачи
Configure and inspect the link|Настройка и контроль соединения
Link control|Управление соединением
Buffered MCU commands / status|Буферизованные команды / состояние MCU
MCU link|Связь с контроллером
Reference and analog supply|Тактирование и аналоговое питание
Clock / supply|Тактирование / питание
Current measurements|Измерения тока
Current|Ток
Selected measurement|Выбранное измерение
Enable command|Команда включения
Protected 24 V bus|Защищённая шина 24 В
Protected 24 V|Защищённые 24 В
Intermediate supply branches|Промежуточные ветви питания
Intermediate rails|Промежуточные шины
Always-on supervision|Дежурное питание контроля
Always-on power|Дежурное питание
Qualified primary commands|Разрешённые команды основных шин
Enable|Включение
Qualified load commands|Разрешённые команды нагрузок
Measure delivered rails|Контроль выходных шин
Measurements|Измерения
Selected voltage and current|Выбранные напряжение и ток
Telemetry|Измеренные параметры
Positive / negative analog rails|Положительная / отрицательная шины
Programming permission|Разрешение программирования
Regulated output|Стабилизированный выход
Regulated power|Стабилизированное питание
Qualified enable|Разрешённое включение
Local supply connection|Локальная связь по питанию
Voltage measurements|Измерения напряжения
Voltage|Напряжение
24 V input|Вход 24 В
24 V|24 В
±15 V|±15 В
Sequenced digital supplies|Последовательно включаемое цифровое питание
Digital power|Цифровое питание
Analog supply rails|Аналоговые шины питания
Analog power|Аналоговое питание
Host supply and status|Питание и состояние контроллера
Host power|Питание контроллера
Commands and results|Команды и результаты
Commands / results|Команды / результаты
Digital receive / transmit|Цифровой приём / передача
Digital data|Цифровые данные
Experiment commands / status|Команды эксперимента / состояние
Analog setpoints|Аналоговые уставки
Switch image and exact timing|Состояние ключей и точное время
Timing|Временная логика
Measured electrical response|Измеряемый электрический отклик
Response|Отклик
ADC samples|Отсчёты АЦП
Current / configuration events|События тока / конфигурации
Trip inputs|Входы защиты
Withdraw hardware permission|Снятие аппаратного разрешения
Inhibit|Запрет
Data|Данные
Control|Управление
Analog signal|Аналоговый сигнал
Connection|Соединение
Received digital data|Принятые цифровые данные
Outgoing digital data|Исходящие цифровые данные
Memory address, data and commands|Адреса, данные и команды памяти
Memory bus|Шина памяти
Memory transfers|Обмен с памятью
Programmed analog voltages|Заданные аналоговые напряжения
Analog voltages|Аналоговые напряжения
Bit-line voltages|Напряжения битовых линий
"""))

# Purpose texts come from module files rather than generator literals. Keep them
# here too: updating a module description never changes any electrical identity.
TEXT.update(_pairs("""
Four AD5676R DACs generate 32 bit-line voltage setpoints; OPA4192 followers buffer them for the matrix switching network.|Четыре ЦАП AD5676R формируют 32 уставки напряжений битовых линий. Повторители OPA4192 буферизуют их перед сетью коммутации матрицы.
U100 is the STM32H745IIT6 host processor. This sheet supplies its power domains, clock sources, reset, boot selection and debug access.|U100 — основной контроллер STM32H745IIT6. Здесь находятся его питание, тактовые источники, сброс, выбор загрузки и интерфейс отладки.
U1100 generates READ/SET/RESET, word-line, current-limit and bias commands. U1103/U1104 create the separate FORMING voltage target.|U1100 формирует уставки READ/SET/RESET, строк, ограничения тока и смещения. U1103/U1104 задают отдельное напряжение FORMING.
This U500 section controls the six DACs and receives FORMING status over their shared serial interface.|Эта секция U500 управляет шестью ЦАП и получает состояние FORMING через общий последовательный интерфейс.
U500 requests matrix operations. Discrete capture, comparison and qualification logic freeze the route and permit only the prepared image to run.|U500 запрашивает операции с матрицей. Логика фиксации, сравнения и разрешений сохраняет коммутацию и допускает запуск только подготовленного состояния.
U1400–U1409 form an 80-bit serial image containing bit-line drive/clamp masks and word/neuron-line controls.|U1400–U1409 хранят 80-битное состояние: маски управления и зажимов битовых линий, команды строк и нейронных линий.
BL0–BL31 each have an independent DAC-drive switch, ground-clamp switch and a selectable service connection.|Каждая линия BL0–BL31 имеет отдельный ключ выхода ЦАП, ключ зажима на общий провод и выбираемое сервисное соединение.
The service router selects the BL bank, voltage target and polarity, connects the return path, and resets the source controller while disabled.|Сервисный коммутатор выбирает группу BL, уставку напряжения и полярность, подключает обратный путь и сбрасывает регулятор при выключенном источнике.
U1700/U1701 select word-line drive or ground. U1702/U1703 clamp neuron lines; U1705 selects one NL for the common analog return.|U1700/U1701 подключают строки к воздействию или общему проводу. U1702/U1703 зажимают нейронные линии, U1705 выбирает одну NL для общего аналогового возврата.
J1800 is the physical crossbar socket carrying 32 BL, eight WL, eight NL and configurable case/reference connections.|J1800 — разъём матрицы: 32 BL, восемь WL, восемь NL и настраиваемые соединения корпуса и опорного уровня.
U1900 converts selected matrix current into a voltage. U1901 selects the feedback range; U1902 chooses the monitored analog node.|U1900 преобразует выбранный ток матрицы в напряжение. U1901 выбирает диапазон обратной связи, U1902 — контролируемую аналоговую точку.
The analog monitor passes through a high-impedance buffer and balanced differential driver into AD4003 U2004, using a dedicated precision reference.|Контрольный аналоговый сигнал проходит через высокоомный буфер и дифференциальный драйвер в АЦП AD4003 U2004. Масштаб задаёт отдельный прецизионный источник опоры.
The FMC interface of U100 connects to U200, a 64 MiB SDRAM used by the host MCU.|Интерфейс FMC контроллера U100 подключён к U200 — оперативной памяти SDRAM объёмом 64 МиБ.
The source-side CV/CC controller powers the selected DUT route, senses source current through a selectable shunt and bounds the actuator command.|Регулятор CV/CC питает выбранный путь исследуемого устройства, измеряет ток через выбираемый шунт и ограничивает управляющее воздействие.
U2200 provides backup overcurrent comparison. U2202 remembers overcurrent or configuration faults and asserts local shutdown plus MATRIX_INHIBIT_N.|U2200 выполняет резервную проверку превышения тока. U2202 фиксирует превышение тока или ошибку конфигурации, вызывает локальное отключение и формирует MATRIX_INHIBIT_N.
U100 connects to QSPI flash U300, removable microSD J300, the FPGA command interface and the independent power manager.|U100 подключён к flash-памяти QSPI U300, карте microSD через J300, командному интерфейсу ПЛИС и независимому контроллеру питания.
J400 is the Control-side power and supervision boundary. It receives the external rails and presents separate status receivers for the MCU and matrix logic.|J400 — граница питания и контроля платы Control. Через него приходят напряжения; отдельные приёмники передают состояние контроллеру и логике матрицы.
U500 is one XC7A200T-2FBG484I FPGA with separate core, auxiliary and I/O supply groups and local bypass capacitors.|U500 — одна ПЛИС XC7A200T-2FBG484I с отдельным питанием ядра, вспомогательных узлов и банков ввода-вывода. Каждая группа имеет локальные развязывающие конденсаторы.
U500 loads configuration from U600 SPI flash; J600, SW600 and U601 provide debug and recovery paths. FB600 filters the XADC supply.|U500 загружает конфигурацию из SPI flash U600. J600, SW600 и U601 обеспечивают отладку и восстановление. FB600 фильтрует питание XADC.
J700 connects a USB Type-C host to U707 FT601 through U706 lane orientation control. U707 exposes a 32-bit FIFO to U500.|J700 подключает компьютер USB Type-C к мосту U707 FT601 через коммутатор ориентации U706. U707 предоставляет ПЛИС U500 32-битный интерфейс FIFO.
U800 provides 512 MiB DDR3L to U500. Y800 supplies the differential reference clock for the FPGA memory subsystem.|U800 предоставляет ПЛИС U500 512 МиБ памяти DDR3L. Y800 формирует дифференциальное опорное тактирование подсистемы памяти.
Follow an Ethernet receive path across one canvas: network connector, transformer isolation, physical-layer recovery and FPGA processing. Select a connection for actual net and pin detail.|Проследите приём Ethernet на одной диаграмме: сетевой разъём, трансформаторная развязка, приём PHY и обработка в ПЛИС. Выберите соединение, чтобы увидеть реальные цепи и выводы.
U1001 converts BUS24 into P15 for the positive analog-front-end domain.|U1001 преобразует BUS24 в P15 для положительного питания аналогового тракта.
J101 receives the external DC supply. D101/D102 indicate input polarity before downstream protection.|J101 принимает внешнее питание постоянного тока. D101/D102 показывают полярность до последующих узлов защиты.
U1102 generates N15 with an inverting buck-boost connection. U1101 transfers enable control into the negative local domain.|U1102 формирует N15 по инвертирующей схеме buck-boost. U1101 передаёт команду включения в локальный отрицательный домен.
U1201 converts FPGA5V5 into CORE1V0 for U500 internal logic and block RAM.|U1201 преобразует FPGA5V5 в CORE1V0 для внутренней логики и блочной памяти U500.
U1301 converts FPGA5V5 into AUX1V8 for the FPGA auxiliary circuits.|U1301 преобразует FPGA5V5 в AUX1V8 для вспомогательных цепей ПЛИС.
U1401 converts FPGA5V5 into AUX2V5 for the separate 2.5 V auxiliary branch.|U1401 преобразует FPGA5V5 в AUX2V5 для отдельной вспомогательной ветви 2,5 В.
U1501 converts FPGA5V5 into IO3V3 for the FPGA I/O domain.|U1501 преобразует FPGA5V5 в IO3V3 для домена ввода-вывода ПЛИС.
U1601 converts FPGA5V5 into DDR1V35 for DDR memory and the tracking termination stage.|U1601 преобразует FPGA5V5 в DDR1V35 для памяти DDR и следящего источника терминации.
U1701 converts FPGA5V5 into PHY1V05 for the Ethernet PHY core.|U1701 преобразует FPGA5V5 в PHY1V05 для ядра Ethernet PHY.
U1801 generates a source/sink DDR termination supply and a tracking reference from DDR1V35.|U1801 формирует из DDR1V35 питание терминации DDR, способное отдавать и принимать ток, и следующее за ним опорное напряжение.
U1901 regulates ANA6 into low-noise ANA5 for the 5 V analog domain and next LDO.|U1901 стабилизирует ANA6 в малошумящую шину ANA5 для аналогового домена 5 В и следующего LDO.
U2001 regulates ANA5 into low-noise ANA3V3 for the low-noise 3.3 V analog domain.|U2001 стабилизирует ANA5 в малошумящую шину ANA3V3 для аналогового домена 3,3 В.
F201 protects the input branch. D204 indicates fused voltage; Q201 controls the red loss-of-fuse indication.|F201 защищает входную ветвь. D204 показывает напряжение после предохранителя; Q201 управляет красной индикацией его обрыва.
The opposed Q2102/Q2103 PMOS pair connects P15 to PROG_P15 under MATRIX_PERMIT; the surrounding devices control gate clamp and discharge.|Встречно включённая пара PMOS Q2102/Q2103 подключает P15 к PROG_P15 по разрешению MATRIX_PERMIT. Остальные элементы управляют зажимом и разрядом затворов.
Q2201/Q2202 form the opposed NMOS negative programming switch, with optocoupler control, OFF clamp and discharge.|Встречно включённые NMOS Q2201/Q2202 коммутируют отрицательное питание записи; оптопары управляют ключами, зажимом выключенного состояния и разрядом.
J2301 exports PROG_P15, ground and PROG_N15. A divider provides a filtered positive-rail measurement.|J2301 выводит PROG_P15, общий провод и PROG_N15. Делитель формирует фильтрованный сигнал измерения положительной шины.
U2401 STM32G0B1 is the AON-powered sequencer, telemetry reader and host supervisor for the power subsystem.|U2401 STM32G0B1 питается от AON, управляет последовательностью запуска, читает измерения и контролирует связь с основным контроллером.
U2501 and U2502 independently supervise the power controller and host supplies/heartbeats.|U2501 и U2502 независимо контролируют питание и импульсы работоспособности контроллера питания и основного контроллера.
The AON-powered U2601/U2602 qualification gates and U2603 dual latch grant separate global-power and matrix permissions.|Логика разрешений U2601/U2602 и двойная защёлка U2603 питаются от AON и отдельно разрешают общее питание и работу матрицы.
U2701/U2702 qualify converter enable requests with the independent global-power permit.|U2701/U2702 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением.
U2801/U2802 qualify converter enable requests with the independent global-power permit.|U2801/U2802 объединяют запросы включения преобразователей с независимым общим аппаратным разрешением.
U2901 compares conditioned USB, analog-preregulator and bipolar AFE monitor voltages with AON-derived thresholds.|U2901 сравнивает подготовленные измерения USB, аналогового предстабилизатора и двухполярного AFE с порогами, сформированными от AON.
U3001, U3017 and U3018 form the measured-rail readiness tree.|U3001, U3017 и U3018 объединяют результаты проверки фактической готовности напряжений.
U301 TPS26631 and external Q301/Q302 provide controlled input protection, a limited startup ramp and fault/status outputs.|U301 TPS26631 и внешние Q301/Q302 обеспечивают управляемую входную защиту, плавное включение и сигналы аварии и состояния.
U3101–U3103 check whether all included rail-enable commands are asserted.|U3101–U3103 проверяют, активны ли все включённые в проверку команды запуска шин.
U3201 independently checks conditioned negative-rail current against an AON-derived threshold.|U3201 независимо сравнивает подготовленный сигнал тока отрицательной шины с порогом, сформированным от AON.
J3301 provides power-manager SWD. J3302 and U3301 connect UART, watchdog and status signals to the host domain.|J3301 предоставляет SWD контроллера питания. J3302 и U3301 передают UART, сигналы сторожевого контроля и состояния в домен основного контроллера.
U3401 translates the negative AFE rail and its shunt voltage into positive telemetry and hardware-overcurrent signals.|U3401 преобразует напряжение отрицательной шины AFE и её шунта в положительные измерительные сигналы и сигнал аппаратной защиты по току.
U3501–U3504 monitor the input bus, always-on, USB and system rails.|U3501–U3504 измеряют входную шину, дежурное питание, питание USB и системную шину.
U3601–U3603 monitor the FPGA intermediate, analog preregulator and positive AFE rails.|U3601–U3603 измеряют промежуточное питание ПЛИС, аналоговый предстабилизатор и положительную шину AFE.
U3701–U3704 monitor the FPGA core, auxiliary and I/O rails.|U3701–U3704 измеряют питание ядра, вспомогательных узлов и выводов ПЛИС.
U3801–U3804 monitor the DDR, Ethernet PHY and low-noise analog rails.|U3801–U3804 измеряют питание DDR, Ethernet PHY и малошумящие аналоговые шины.
U3901/U3902 select paired current and voltage measurements for one of 16 supply domains.|U3901/U3902 выбирают согласованную пару измерений тока и напряжения одного из 16 доменов питания.
U4001 buffers the paired telemetry mux outputs into the power-manager ADC inputs.|U4001 буферизует выходы парных измерительных мультиплексоров перед входами АЦП контроллера питания.
L401 and local capacitors filter EFUSE_OUT. R401 provides the input-current shunt before BUS24.|L401 и локальные конденсаторы фильтруют EFUSE_OUT. R401 служит шунтом входного тока перед BUS24.
U501 generates AON directly from BUS24 for sequencing, monitoring, watchdogs and hardware interlocks.|U501 формирует AON непосредственно из BUS24 для последовательности запуска, измерений, сторожевых таймеров и аппаратных блокировок.
U601 converts BUS24 into USB5 for the board USB interface.|U601 преобразует BUS24 в USB5 для интерфейса USB платы.
U701 converts BUS24 into SYS3V3 for the host and system logic.|U701 преобразует BUS24 в SYS3V3 для основного контроллера и системной логики.
U801 converts BUS24 into FPGA5V5 for the downstream FPGA, DDR and PHY converters.|U801 преобразует BUS24 в FPGA5V5 для последующих преобразователей ПЛИС, DDR и PHY.
U901 converts BUS24 into ANA6 for the low-noise analog regulator chain.|U901 преобразует BUS24 в ANA6 для цепочки малошумящих аналоговых стабилизаторов.
"""))

TEXT.update(_pairs("""
Return results to the computer|Передача результатов на компьютер
Follow the measured data back through the communication path.|Проследите обратный путь измеренных данных через интерфейс связи.
Acquire a response|Получение отклика
The matrix readout converts the electrical result into ADC samples.|Измерительный тракт матрицы преобразует электрический отклик в отсчёты АЦП.
Collect digital samples|Сбор цифровых отсчётов
FPGA logic receives the digitized measurement.|Логика ПЛИС принимает оцифрованное измерение.
Send data to the link|Передача данных в интерфейс
The selected communication implementation passes result data to the physical link.|Выбранная реализация связи передаёт результаты на физический интерфейс.
Display the result|Отображение результата
The computer receives and presents the returned data.|Компьютер принимает и отображает полученные данные.
Load the FPGA design|Загрузка конфигурации ПЛИС
Explain configuration storage, startup status and the separate ready-for-application decision.|Посмотрите, где хранится конфигурация, как проходит запуск и чем загрузка отличается от готовности прикладной логики.
Establish FPGA supplies|Включение питания ПЛИС
The Power board provides the FPGA core, auxiliary and bank supplies.|Плата Power подаёт питание ядра, вспомогательных узлов и банков ПЛИС.
Load the bitstream|Загрузка конфигурационного потока
The FPGA configuration interface loads its hardware design from local flash. Open the FPGA configuration block to inspect the exact path.|Интерфейс конфигурации загружает аппаратный проект ПЛИС из локальной flash-памяти. Точный путь показан в модуле конфигурации ПЛИС.
Report INIT and DONE|Сигналы INIT и DONE
Configuration status reaches the host through the domain-buffer path.|Состояние конфигурации передаётся основному контроллеру через буферы между доменами.
Check application readiness|Проверка готовности программы
The loaded application must establish its own communication and memory readiness before experiments.|Перед экспериментами загруженная прикладная логика должна проверить готовность связи и памяти.
Apply power|Подать питание
Watch energy reach supervision, the host, programmable logic and analog functions. The sequence is a teaching story, not a timing simulation.|Посмотрите, как питание достигает контроллеров, ПЛИС и аналоговых узлов. Последовательность объясняет работу; точные временные задержки не моделируются.
Connect the supply|Подключение источника
Energy enters the input protection on the Power board.|Питание поступает во входную защиту платы Power.
Wake supervision|Запуск контроля питания
Always-on circuitry lets the power manager check conditions before granting the other requests.|Дежурное питание позволяет контроллеру питания проверить условия перед разрешением остальных запросов.
Power the host|Включение основного контроллера
The host supply and status receivers become available.|Становятся доступны питание основного контроллера и приёмники сигналов состояния.
Power programmable logic|Включение ПЛИС
Controlled digital rails feed the FPGA and interface domains.|Управляемые цифровые шины питают ПЛИС и домены интерфейсов.
Prepare analog functions|Подготовка аналоговых узлов
The analog rails supply the precision sources and measurement path.|Аналоговые шины питают прецизионные источники и измерительный тракт.
Ready for the experiment|Готовность к эксперименту
Software readiness and hardware permits must both agree before an operation.|Для начала операции одновременно нужны программная готовность и аппаратные разрешения.
Receive a computer command|Принять команду компьютера
Follow a command into the physical link and onward to programmable processing.|Проследите путь команды через физический интерфейс к обработке в программируемой логике.
The operator sends a request|Оператор отправляет запрос
A command begins on the external computer.|Команда формируется на внешнем компьютере.
Cable signal becomes digital data|Кабельный сигнал становится данными
The connector, transformer and PHY bring the electrical link into a digital interface.|Разъём, трансформатор и PHY преобразуют кабельный сигнал в цифровой интерфейс.
Process the request|Обработка запроса
The chosen MAC, protocol and application logic interpret the received request. These are implementation layers within the FPGA system.|Выбранные реализации MAC, протоколов и прикладной логики обрабатывают запрос. Эти уровни реализуются внутри системы на ПЛИС.
Prepare an experiment|Подготовка эксперимента
Validated commands select analog setpoints and a held matrix route.|Проверенные команды задают аналоговые уставки и фиксированную коммутацию матрицы.
Ethernet: receive in detail|Ethernet: подробный приём
Watch the nature of the signal change from cable waveform to parallel digital data.|Посмотрите, как сигнал в кабеле превращается в параллельные цифровые данные.
Arrive at the connector|Сигнал на разъёме
The cable waveform enters the RJ45 connector J900. This is an analog physical-layer signal.|Кабельный сигнал поступает в разъём RJ45 J900. Здесь это аналоговый сигнал физического уровня.
Cross the isolation barrier|Прохождение гальванической развязки
T900 transfers the physical-layer signal magnetically between the cable and PHY sides.|T900 передаёт сигнал физического уровня магнитной связью между стороной кабеля и стороной PHY.
Recover the physical link|Приём физического сигнала
U902 recovers the physical link and presents digital receive data. Cable coding is not reproduced by this teaching animation.|U902 принимает физический сигнал и выдаёт цифровые данные. Учебная анимация условно показывает кабельный сигнал без воспроизведения его точного кодирования.
Deliver digital receive data|Передача цифровых данных приёма
PHY_RXC, PHY_RX_CTL and PHY_RXD0…3 connect the PHY to U500. Open the edge for exact pin and waveform detail.|PHY_RXC, PHY_RX_CTL и PHY_RXD0…3 соединяют PHY с U500. Выберите линию, чтобы увидеть конкретные выводы и представление сигналов.
Handle the frame|Обработка кадра
The chosen MAC and protocol implementation inside the FPGA system handles the received frame.|Выбранная реализация MAC и протоколов внутри системы на ПЛИС обрабатывает принятый кадр.
Read the matrix|Прочитать матрицу
See the relation between commands, analog drive, matrix response and numerical result.|Посмотрите связь между командами, аналоговым воздействием, откликом матрицы и числовым результатом.
Choose a read operation|Выбор операции чтения
The host and FPGA prepare the experiment and operation timing.|Основной контроллер и ПЛИС подготавливают эксперимент и время операции.
Set read voltages|Установка напряжений чтения
DAC commands establish the analog read setpoints.|Команды ЦАП задают аналоговые уставки чтения.
Apply the held route|Применение зафиксированной коммутации
Routing connects the selected drive and return path to the crossbar.|Коммутатор подключает выбранное воздействие и обратный путь к матрице.
Selected matrix current reaches current-to-voltage conversion and the ADC front end.|Выбранный ток матрицы поступает в преобразователь ток-напряжение и входной тракт АЦП.
Return a number|Получение числового результата
The ADC result reaches FPGA capture and can be sent to the computer.|ПЛИС принимает результат АЦП и может передать его на компьютер.
Trigger a hardware fault|Аппаратная авария
Show why protection has a direct path independent of normal data processing.|Проследите прямой путь защиты, который действует независимо от обычной обработки данных.
An unsafe condition occurs|Возникновение опасного условия
A source-current or configuration event reaches the hardware protection.|Событие превышения тока источника или ошибки конфигурации поступает в аппаратную защиту.
Remember the event|Фиксация события
Fault memory holds the stop condition until the defined reset or rearm procedure.|Память аварии удерживает остановку до предусмотренного сброса или повторного взвода.
Withdraw permission|Снятие разрешения
The inhibit path reaches the power-permit boundary.|Сигнал запрета достигает аппаратной границы разрешения питания.
Inspect before rearming|Проверка перед повторным взводом
The host can examine status and telemetry before a deliberate recovery sequence.|Перед осознанным восстановлением основной контроллер может проверить состояние и измеренные параметры.
Program a matrix element|Запрограммировать ячейку матрицы
Explain bounded programming drive and held routing without claiming device-specific pulse values.|Посмотрите, как ограничивается воздействие записи и фиксируется коммутация. Конкретные параметры импульса зависят от исследуемой ячейки.
Prepare voltage and current limits|Подготовка ограничений напряжения и тока
The requested programming conditions become DAC setpoints for the shared source.|Запрошенные условия записи преобразуются в уставки ЦАП для общего источника.
Check the operation|Проверка операции
Hardware permissions and the captured request must be consistent.|Аппаратные разрешения должны соответствовать зафиксированному запросу.
Apply the programming drive|Подача воздействия записи
The selected route connects the regulated source for the requested operation.|Выбранная коммутация подключает регулируемый источник для запрошенной операции.
Monitor the operation|Контроль операции
Source-current and configuration conditions remain observable to independent protection.|Независимая защита продолжает контролировать ток источника и состояние конфигурации.
End and verify|Завершение и проверка
After the programming operation, a read operation can measure the resulting state.|После записи операцией чтения можно измерить полученное состояние.
"""))

RAIL_HEADINGS = _pairs("""
Always-on 3.3 V|Дежурное питание 3,3 В
USB supply|Питание USB
Host-system supply|Системное питание контроллера
FPGA intermediate supply|Промежуточное питание ПЛИС
Analog preregulator|Аналоговый предстабилизатор
Positive analog rail|Положительная аналоговая шина
Negative analog rail|Отрицательная аналоговая шина
FPGA core rail|Питание ядра ПЛИС
Auxiliary 1.8 V|Вспомогательное питание 1,8 В
Auxiliary 2.5 V|Вспомогательное питание 2,5 В
FPGA I/O rail|Питание выводов ПЛИС
DDR3L memory rail|Питание памяти DDR3L
Ethernet PHY core rail|Питание ядра Ethernet PHY
Tracking termination supply|Следящее питание терминации
Low-noise analog 5 V|Малошумящее аналоговое питание 5 В
Low-noise analog 3.3 V|Малошумящее аналоговое питание 3,3 В
""")

MEASURE_HEADINGS = _pairs("""
external input|входного питания
always-on supply|дежурного питания
usb supply|питания USB
host-system supply|системного питания
fpga intermediate supply|промежуточного питания ПЛИС
analog preregulator|аналогового предстабилизатора
positive analog rail|положительной аналоговой шины
fpga core supply|питания ядра ПЛИС
1.8 v auxiliary supply|вспомогательного питания 1,8 В
2.5 v auxiliary supply|вспомогательного питания 2,5 В
fpga i/o supply|питания выводов ПЛИС
ddr3l memory supply|питания памяти DDR3L
analog 5 v supply|аналогового питания 5 В
ethernet core supply|питания ядра Ethernet
analog 3.3 v supply|аналогового питания 3,3 В
""")


def translate(value):
    """Translate a known narrative string; preserve source names byte for byte.

    Unknown text is deliberately returned unchanged. Use unresolved_strings after
    generation to catch new authored English rather than silently inventing text.
    """
    if not isinstance(value, str) or not value:
        return value
    if value in TEXT:
        return TEXT[value]
    if re.search(r"[А-Яа-яЁё]", value):
        return value
    m = re.fullmatch(r"(\d+) electrical connections", value)
    if m:
        count = int(m.group(1))
        suffix = 'цепь' if count % 10 == 1 and count % 100 != 11 else ('цепи' if count % 10 in (2, 3, 4) and count % 100 not in (12, 13, 14) else 'цепей')
        return f'{count} {suffix}'
    m = re.fullmatch(r"(Receive|Deliver) ([A-Z][A-Z0-9_]*)", value)
    if m:
        return ('Вход ' if m.group(1) == 'Receive' else 'Выход ') + m.group(2)
    m = re.fullmatch(r"(Set|Drive|Route) bit lines ([0-9]+[–-][0-9]+)", value)
    if m:
        return {'Set': 'Уставки BL', 'Drive': 'Буферы BL', 'Route': 'Коммутация BL'}[m.group(1)] + m.group(2)
    m = re.fullmatch(r"Load switch bits ([0-9]+[–-][0-9]+)", value)
    if m:
        return 'Загрузка битов ' + m.group(1)
    suffix = ' is generated by the source regulator and its local energy-storage or filter components.'
    if value.endswith(suffix) and value[:-len(suffix)] in RAIL_HEADINGS:
        return RAIL_HEADINGS[value[:-len(suffix)]] + ': напряжение формируют стабилизатор и его локальные накопительные или фильтрующие элементы.'
    if value.startswith('Measure ') and value[8:].lower() in MEASURE_HEADINGS:
        return 'Измерение ' + MEASURE_HEADINGS[value[8:].lower()]
    return value


NARRATIVE_KEYS = frozenset(('title', 'subtitle', 'description', 'detailPolicy',
                            'label', 'shortLabel', 'text', 'body', 'summary',
                            'purpose', 'explanation', 'caption', 'note'))


def _localize(obj):
    if isinstance(obj, dict):
        for key, value in list(obj.items()):
            if key in NARRATIVE_KEYS and isinstance(value, str):
                obj[key] = translate(value)
            elif isinstance(value, (dict, list)):
                _localize(value)
    elif isinstance(obj, list):
        for item in obj:
            _localize(item)
    return obj


def localize_scenes(scenes):
    """Mutate a scene dictionary or list in place and return the same object."""
    return _localize(scenes)


def localize_scenarios(scenarios):
    """Mutate scenario/step prose in place without changing any target IDs."""
    return _localize(scenarios)


def unresolved_strings(obj):
    """Return new English prose strings; exact nets/protocol names are allowed."""
    unresolved = set()
    allowed = {'Ethernet / USB', 'Ethernet', 'USB', 'JTAG', 'SPI', 'RGMII',
               'DDR3L', 'MAC', 'ADC', 'DAC', 'FPGA', 'MCU'}
    def walk(item):
        if isinstance(item, dict):
            for key, value in item.items():
                if key in NARRATIVE_KEYS and isinstance(value, str):
                    if value and not re.search(r'[А-Яа-яЁё]', value) and re.search(r'[a-z]', value) and value not in allowed:
                        unresolved.add(value)
                elif isinstance(value, (dict, list)):
                    walk(value)
        elif isinstance(item, list):
            for value in item:
                walk(value)
    walk(obj)
    return sorted(unresolved)


