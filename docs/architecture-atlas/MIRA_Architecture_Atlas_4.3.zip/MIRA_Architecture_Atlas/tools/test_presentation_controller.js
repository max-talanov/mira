#!/usr/bin/env node
/* Exercise the real tour controller with delayed engine frames and DOM events. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const decode=s=>String(s).replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
function simple(el,selector){
 const tag=selector.match(/^[A-Za-z][\w-]*/);if(tag&&el.tagName!==tag[0].toUpperCase())return false;
 for(const m of selector.matchAll(/#([\w-]+)/g))if(el.id!==m[1])return false;
 for(const m of selector.matchAll(/\.([\w-]+)/g))if(!el.classList.contains(m[1]))return false;
 for(const m of selector.matchAll(/\[([^\]=]+)(?:=["']?([^\]"']+)["']?)?\]/g))if(!el.hasAttribute(m[1])||(m[2]!==undefined&&el.getAttribute(m[1])!==m[2]))return false;
 return true;
}
function matches(el,selector){return selector.split(',').some(s=>{const parts=s.trim().split(/\s+/);if(!simple(el,parts.pop()))return false;let p=el.parentNode;while(parts.length){const part=parts.pop();while(p&&!simple(p,part))p=p.parentNode;if(!p)return false;p=p.parentNode;}return true;});}
class Element{
 constructor(tag){this.tagName=String(tag).toUpperCase();this.attrs={};this.children=[];this.parentNode=null;this.listeners={};this._text='';this.hidden=false;this.disabled=false;this.checked=false;this.value='';this.style={setProperty(k,v){this[k]=v;},removeProperty(k){delete this[k];}};}
 get id(){return this.attrs.id||'';}set id(v){this.attrs.id=v;}
 get className(){return this.attrs.class||'';}set className(s){this.attrs.class=String(s);}
 get classList(){const e=this;return{contains:c=>e.className.split(/\s+/).includes(c),add(...cs){e.className=[...new Set([...e.className.split(/\s+/).filter(Boolean),...cs])].join(' ');},remove(...cs){e.className=e.className.split(/\s+/).filter(c=>!cs.includes(c)).join(' ');},toggle(c,v){const yes=v===undefined?!this.contains(c):!!v;yes?this.add(c):this.remove(c);return yes;}};}
 get dataset(){const e=this;return new Proxy({},{get:(_,key)=>e.attrs['data-'+String(key).replace(/[A-Z]/g,c=>'-'+c.toLowerCase())]});}
 setAttribute(k,v){this.attrs[k]=String(v);}getAttribute(k){return Object.hasOwn(this.attrs,k)?this.attrs[k]:null;}hasAttribute(k){return Object.hasOwn(this.attrs,k);}removeAttribute(k){delete this.attrs[k];}
 append(...ns){ns.forEach(n=>{n.parentNode=this;this.children.push(n);});}remove(){if(this.parentNode){this.parentNode.children.splice(this.parentNode.children.indexOf(this),1);this.parentNode=null;}}
 replaceChildren(...ns){this.children=[];this._text='';this.append(...ns);}
 matches(s){return matches(this,s);}
 closest(s){let n=this;while(n){if(matches(n,s))return n;n=n.parentNode;}return null;}
 querySelectorAll(s){const out=[];for(const c of this.children){if(matches(c,s))out.push(c);out.push(...c.querySelectorAll(s));}return out;}
 querySelector(s){return this.querySelectorAll(s)[0]||null;}
 addEventListener(t,f){(this.listeners[t]??=[]).push(f);}
 get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}set textContent(v){this.replaceChildren();this._text=String(v);}
 set innerHTML(html){this.replaceChildren();const stack=[this],voids=new Set(['INPUT','BR','HR','IMG','META','LINK']);for(const token of String(html).matchAll(/<[^>]+>|[^<]+/g)){const t=token[0];if(t.startsWith('</')){if(stack.length>1)stack.pop();continue;}if(t.startsWith('<')){const tag=t.match(/^<([\w-]+)/)?.[1];if(!tag)continue;const n=new Element(tag);for(const m of t.slice(tag.length+1,-1).matchAll(/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g))n.setAttribute(m[1],decode(m[2]??m[3]??m[4]??''));stack.at(-1).append(n);if(!voids.has(n.tagName)&&!t.endsWith('/>'))stack.push(n);}else stack.at(-1)._text+=decode(t);}}
 getBoundingClientRect(){return{width:1200,height:this.classList.contains('mp-caption')?340:800,left:0,top:0};}
 focus(){this.focused=true;}
}
function event(target,type='click',extra={}){return{target,type,defaultPrevented:false,preventDefault(){this.defaultPrevented=true;},stopPropagation(){this.stopped=true;},...extra};}
function fire(target,type='click',extra={}){assert(target);if(type==='click'&&target.disabled)return;const e=event(target,type,extra);let n=target;while(n){for(const f of n.listeners[type]||[])f(e);if(e.stopped)break;n=n.parentNode;}return e;}
const document={body:new Element('body'),documentElement:new Element('html'),listeners:{},createElement:t=>new Element(t),addEventListener(t,f){(this.listeners[t]??=[]).push(f);},querySelector(s){return this.body.querySelector(s);}};
const button=new Element('button');button.id='presentation-toggle';document.body.append(button);
const storage=new Map(),location={hash:'#overview?scene=control_900_FPGA_ETHERNET_AND_MCU_INTERFACE'},callbacks=[];
const original={sceneId:'control_900_FPGA_ETHERNET_AND_MCU_INTERFACE',camera:{x:-74,y:33,scale:1.15},scenarioId:'ethernet-local-rx',stepIndex:2,playing:false,viewMode:'circuit'};let state={...original,camera:{...original.camera}},snapshot=null,endedWhileActive=false;
const frames=[];let audience='technical';
const engine={
 getState:()=>({...state}),beginPresentation(){snapshot=JSON.stringify(state);},
 presentFrame(spec){audience=spec.audience;const call={spec,resolve:null};frames.push(call);return new Promise(resolve=>call.resolve=resolve);},
 setPresentationSignals(v){state.playing=v;},setPresentationAudience(v){audience=v;},setPresentationViewportPadding(){},fit(){},
 endPresentation(){endedWhileActive=ctx.MiraPresentation.isActive();state=JSON.parse(snapshot);}
};
const ctx={console,document,location,URLSearchParams,innerWidth:1440,innerHeight:900,history:{replaceState(_,__,hash){location.hash=hash;}},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},ResizeObserver:class{observe(){}disconnect(){}},HashChangeEvent:class{constructor(t){this.type=t;}},dispatchEvent(e){callbacks.push(e.type);},setTimeout(){throw Error('Controller must not schedule narration timers');}};
ctx.window=ctx;ctx.MiraApp={preparePresentation:()=>engine};vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');for(const m of html.matchAll(/<script[^>]+src="(data\/[^\"]+)"/g)){if(fs.existsSync(path.join(root,m[1])))vm.runInContext(fs.readFileSync(path.join(root,m[1]),'utf8'),ctx);}
assert(ctx.MIRA_TOUR&&ctx.MIRA_BRIEF_TOUR&&ctx.MIRA_OVERVIEW_TOUR,'All presentation routes must be authored before controller QA');
vm.runInContext(fs.readFileSync(path.join(root,'js/presentation.js'),'utf8'),ctx,{filename:'js/presentation.js'});
const api=ctx.MiraPresentation,T=ctx.MIRA_TOUR,B=ctx.MIRA_BRIEF_TOUR,O=ctx.MIRA_OVERVIEW_TOUR,overview=O.chapters.flatMap(c=>O.steps.filter(s=>s.chapterId===c.id)),brief=B.chapters.flatMap(c=>B.steps.filter(s=>s.chapterId===c.id)),main=T.chapters.flatMap(c=>T.steps.filter(s=>s.chapterId===c.id&&s.kind!=='detail'));
const flush=async()=>{await Promise.resolve();await Promise.resolve();};
async function finish(call=frames.at(-1),completed=true){if(completed&&call===frames.at(-1)){state.sceneId=call.spec.sceneId;state.playing=call.spec.animateSignals;}call.resolve({completed});await flush();}
const q=s=>document.querySelector(s);
function selectMode(mode){const select=q('.mp-format select');assert(select,'Presentation format selector exists');select.value=mode;fire(select,'change');return frames.at(-1);}

async function testAppDeepLink(mode='architecture',{bare=false}={}){
 const body=new Element('body');body.innerHTML=html.match(/<body>([\s\S]*)<\/body>/)[1];
 const doc={body,documentElement:new Element('html'),listeners:{},createElement:t=>new Element(t),getElementById:id=>body.querySelector('#'+id),querySelector:s=>body.querySelector(s),querySelectorAll:s=>body.querySelectorAll(s),addEventListener(t,f){(this.listeners[t]??=[]).push(f);}};
 const target=mode==='overview'?overview[1]:mode==='brief'?brief[1]:mode==='all'?T.steps.find(s=>s.kind==='detail'):main[1],loc={hash:'#presentation?step='+encodeURIComponent(target.id)+(!bare&&['brief','overview'].includes(mode)?'&mode='+mode:'')},listeners={};let mounted=null;
 const appCtx={console,document:doc,location:loc,URLSearchParams,innerWidth:1440,innerHeight:900,MIRA_ATLAS:ctx.MIRA_ATLAS,MIRA_CONTENT:ctx.MIRA_CONTENT,MIRA_FUNCTIONAL:ctx.MIRA_FUNCTIONAL,MIRA_TOUR:T,MIRA_BRIEF_TOUR:B,MIRA_OVERVIEW_TOUR:O,history:{replaceState(_,__,hash){loc.hash=hash;}},localStorage:{getItem(){return null;},setItem(){}},ResizeObserver:class{observe(){}disconnect(){}},HashChangeEvent:class{constructor(type){this.type=type;}},addEventListener(t,f){(listeners[t]??=[]).push(f);},dispatchEvent(e){for(const f of listeners[e.type]||[])f(e);},setTimeout(){return 1;},clearTimeout(){}};
 appCtx.window=appCtx;
 appCtx.MiraFunctional={mount(host,opts){let st={sceneId:opts.sceneId,camera:{x:15,y:22,scale:1},playing:false};const copy={...st,camera:{...st.camera}};mounted={getState:()=>({...st}),beginPresentation(){},presentFrame(spec){st.sceneId=spec.sceneId;st.playing=spec.animateSignals;opts.onSceneChange(st.sceneId);return Promise.resolve({completed:true});},endPresentation(){st={...copy};opts.onSceneChange(st.sceneId);},setPresentationSignals(v){st.playing=v;},setPresentationViewportPadding(){},destroy(){},fit(){},openCircuit(){},setScene(id){st.sceneId=id;opts.onSceneChange(id);}};opts.onSceneChange(st.sceneId);return mounted;}};
 vm.createContext(appCtx);vm.runInContext(fs.readFileSync(path.join(root,'js/app.js'),'utf8'),appCtx,{filename:'js/app.js'});
 assert(loc.hash.startsWith('#presentation?'),'App boot must preserve presentation deep link before controller loads');
 vm.runInContext(fs.readFileSync(path.join(root,'js/presentation.js'),'utf8'),appCtx,{filename:'js/presentation.js'});await flush();
 assert(appCtx.MiraPresentation.isActive());assert.equal(appCtx.MiraPresentation.getState().stepId,target.id,'Direct URL opens requested episode');assert.equal(appCtx.MiraPresentation.getState().mode,mode,'Deep link preserves/infer its format');
 loc.hash='#sources';appCtx.dispatchEvent(new appCtx.HashChangeEvent('hashchange'));assert.equal(loc.hash,'#sources','External navigation is not overwritten by restored engine scene');assert(!appCtx.MiraPresentation.isActive());assert.equal(appCtx.MiraApp.getState().tab,'sources');
 return true;
}

async function testAppNavigation(){
 const body=new Element('body');body.innerHTML=html.match(/<body>([\s\S]*)<\/body>/)[1];const doc={body,documentElement:new Element('html'),listeners:{},createElement:t=>new Element(t),getElementById:id=>body.querySelector('#'+id),querySelector:s=>body.querySelector(s),querySelectorAll:s=>body.querySelectorAll(s),addEventListener(t,f){(this.listeners[t]??=[]).push(f);}};
 const loc={hash:'#overview'},requests=[],memory=new Map();let mounts=0,setSceneCalls=0;
 const appCtx={console,document:doc,location:loc,URLSearchParams,MIRA_ATLAS:ctx.MIRA_ATLAS,MIRA_CONTENT:ctx.MIRA_CONTENT,MIRA_FUNCTIONAL:ctx.MIRA_FUNCTIONAL,history:{replaceState(_,__,hash){loc.hash=hash;}},localStorage:{getItem:k=>memory.get(k)||null,setItem:(k,v)=>memory.set(k,v)},addEventListener(){},setTimeout(){return 1;},clearTimeout(){}};appCtx.window=appCtx;
 appCtx.MiraFunctional={mount(host,opts){mounts++;let current=opts.sceneId;opts.onSceneChange(current);return{navigateScene(id){let resolve;const promise=new Promise(r=>resolve=r);requests.push({id,finish(completed){if(completed){current=id;opts.onSceneChange(id);}resolve({completed,sceneId:current});}});return promise;},setScene(){setSceneCalls++;},destroy(){}};}};
 vm.createContext(appCtx);vm.runInContext(fs.readFileSync(path.join(root,'js/app.js'),'utf8'),appCtx,{filename:'js/app.js'});const app=appCtx.MiraApp,target='control_900_FPGA_ETHERNET_AND_MCU_INTERFACE',initialHash=loc.hash;
 app.openFunctional(target);assert.equal(mounts,1,'An in-canvas open reuses the current engine');assert.equal(setSceneCalls,0,'External module opening uses deliberate navigation');assert.equal(requests.at(-1).id,target);assert.equal(app.getState().scene,'system','App location is not committed before arrival');assert.equal(loc.hash,initialHash,'Address remains at the actual current scene while travelling');assert.equal(memory.get('mira.functional.lastScene'),'system');requests.at(-1).finish(false);await flush();assert.equal(app.getState().scene,'system');assert.equal(loc.hash,initialHash,'Cancelled arrival does not commit a destination URL');
 app.openFunctional(target);requests.at(-1).finish(true);await flush();assert.equal(app.getState().scene,target);assert(loc.hash.includes('scene='+target));assert.equal(memory.get('mira.functional.lastScene'),target,'App storage commits when the engine announces arrival');assert.equal(mounts,1);return true;
}

(async()=>{
 api.start();assert(api.isActive());assert.equal(frames.length,1);assert.equal(q('.mp-title').textContent,overview[0].title);assert.equal(api.getState().mode,'overview');assert.equal(api.getState().total,24);assert.equal(frames[0].spec.audience,'general');assert(document.body.classList.contains('mp-overview'));assert.equal(q('.mp-format select').getAttribute('aria-label'),'Формат презентации');assert.equal(q('.mp-format select').querySelectorAll('option').length,4);assert.equal(q('.mp-episodes select').querySelectorAll('option').length,24,'Overview selector exposes the complete route');await finish();
 const firstTitle=q('.mp-title').textContent;assert.equal(api.getState().index,0);assert.equal(state.playing,true);
 // Delayed and out-of-order frame completions must not replace current narration.
 const one=api.next(),f1=frames.at(-1),two=api.next(),f2=frames.at(-1);assert.equal(q('.mp-title').textContent,firstTitle,'Narration remains visible while camera transitions');await finish(f2);assert.equal(api.getState().index,2);assert.equal(q('.mp-title').textContent,overview[2].title);await finish(f1);await Promise.all([one,two]);assert.equal(api.getState().index,2,'An older frame must not win');
 const beforePause=api.getState().index;fire(q('[data-mp="signals"]'));assert.equal(api.getState().signals,false);assert.equal(state.playing,false);assert.equal(api.getState().index,beforePause,'Signalpause cannotadvance narration');
 // User signal intent while a transition is pending must survive its completion.
 fire(q('[data-mp="signals"]'));const moving=api.next(),pausedFrame=frames.at(-1);fire(q('[data-mp="signals"]'));assert.equal(api.getState().signals,false);await finish(pausedFrame);await moving;assert.equal(state.playing,false,'A completed zoom must not restart paused signals');
 const beforeCancel=api.getState().index,cancelled=api.next(),cancelledFrame=frames.at(-1);await finish(cancelledFrame,false);await cancelled;assert.equal(api.getState().pendingStepId,null,'User-interrupted zoom releases pending navigation');assert.equal(api.getState().index,beforeCancel,'Interrupted move preserves the explanation');const resumed=api.next();await finish();await resumed;assert.equal(api.getState().index,beforeCancel+1,'Narrative can resume after manual camera interaction');
 // Every format uses the same live canvas and keeps the user's signal pause.
 selectMode('brief');assert.equal(frames.at(-1).spec.audience,'general');await finish();assert.equal(api.getState().total,brief.length);assert.equal(api.getState().mode,'brief');assert.equal(api.getState().signals,false);assert(document.body.classList.contains('mp-brief'));assert(!document.body.classList.contains('mp-overview'));assert.equal(q('.mp-episodes select').querySelectorAll('option').length,12,'Brief selector still exposes all twelve episodes');
 selectMode('architecture');assert.equal(frames.at(-1).spec.audience,'technical');await finish();assert.equal(api.getState().total,main.length);assert.equal(api.getState().mode,'architecture');assert.equal(api.getState().signals,false);assert(!document.body.classList.contains('mp-brief'));
 selectMode('all');await finish();assert.equal(api.getState().total,T.steps.length);assert.equal(api.getState().full,true);assert.equal(api.getState().mode,'all');assert(location.hash.includes('mode=all')&&location.hash.includes('full=1'));assert(!q('.mp-details input'),'Retired detail checkbox is absent');
 const represented=new Set(T.steps.map(s=>ctx.MIRA_FUNCTIONAL.scenes[s.sceneId]?.sourceSheetId).filter(Boolean));assert.equal(represented.size,77,'Fullroute must coverall77source sheets');
 const lastChapter=T.chapters.at(-1),chapter=q('.mp-chapters select');chapter.value=lastChapter.id;fire(chapter,'change');await finish();assert.equal(T.steps.find(s=>s.id===api.getState().stepId).chapterId,lastChapter.id);
 const episode=q('.mp-episodes select'),target=T.steps.find(s=>s.chapterId===lastChapter.id&&s.kind==='detail')||T.steps.filter(s=>s.chapterId===lastChapter.id).at(-1);episode.value=target.id;fire(episode,'change');await finish();assert.equal(api.getState().stepId,target.id);
 // Changing formats during an in-flight deep transition must discard its completion.
 const oldTitle=q('.mp-title').textContent,oldModeFrame=selectMode('brief'),latestModeFrame=selectMode('architecture');assert.equal(q('.mp-title').textContent,oldTitle,'Format transitions retain the explanation');await finish(latestModeFrame);const committed=api.getState().stepId;await finish(oldModeFrame);assert.equal(api.getState().stepId,committed);assert.equal(api.getState().mode,'architecture');assert.equal(q('.mp-format select').value,'architecture','An older completion cannot reset the selected format');
 // A cancelled all -> brief transition must never strand an index beyond 12.
 selectMode('all');await finish();const end=T.chapters.flatMap(c=>T.steps.filter(s=>s.chapterId===c.id)).at(-1),deep=api.goTo(end.id);await finish();await deep;assert(api.getState().index>=brief.length);
 const cancelledModeFrame=selectMode('brief');assert.equal(audience,'general');await finish(cancelledModeFrame,false);assert.equal(api.getState().pendingStepId,null);assert(api.getState().stepId&&api.getState().index<api.getState().total,'Interrupted format switch retains a valid current episode');assert.equal(api.getState().mode,'all','Interrupted format switch restores committed route');assert.equal(api.getState().stepId,end.id);assert.equal(q('.mp-format select').value,'all');assert.equal(audience,'technical','Interrupted format switch restores labels for committed audience');const continueAfterModeCancel=api.previous();await finish();await continueAfterModeCancel;assert.equal(api.getState().index,T.steps.length-2,'Narration resumes after cancelled format switch');
 // The new main overview also restores its friendly labels after a cancelled deep dive.
 selectMode('overview');await finish();const overviewPosition=api.goTo(overview[7].id);await finish();await overviewPosition;assert.equal(api.getState().mode,'overview');assert.equal(q('.mp-episodes select').querySelectorAll('option').length,24);const cancelledDeepDive=selectMode('all');assert.equal(audience,'technical');await finish(cancelledDeepDive,false);assert.equal(api.getState().mode,'overview');assert.equal(api.getState().stepId,overview[7].id);assert.equal(audience,'general');assert.equal(q('.mp-format select').value,'overview');assert.equal(api.getState().signals,false,'Cancelled format change preserves signal pause');
 const olderOverview=selectMode('brief'),newerOverview=selectMode('overview');await finish(newerOverview);const latestOverviewId=api.getState().stepId;await finish(olderOverview);assert.equal(api.getState().mode,'overview');assert.equal(api.getState().stepId,latestOverviewId,'A stale brief frame cannot overwrite the overview');assert.equal(audience,'general');
 // The persistent canvas location bar uses the same committed presentation route.
 const nested=api.goTo(overview[9].id);await finish();await nested;const nestedTitle=q('.mp-title').textContent;
 const canvas=new Element('section');canvas.className='mf';const wayfinding=new Element('nav');wayfinding.className='mf-wayfinding';const ancestor=new Element('button');ancestor.setAttribute('data-scene','system');wayfinding.append(ancestor);canvas.append(wayfinding);document.body.append(canvas);
 const ancestorClick=event(ancestor);for(const listener of document.listeners.click||[]){listener(ancestorClick);if(ancestorClick.stopped)break;}assert(ancestorClick.defaultPrevented,'Ancestor route is intercepted by the presentation controller');assert.equal(frames.at(-1).spec.sceneId,'system');assert.equal(q('.mp-title').textContent,nestedTitle,'Ancestor navigation retains the current narration until arrival');assert.equal(frames.at(-1).spec.animateSignals,false,'Ancestor navigation respects paused signals');await finish();assert.equal(api.getState().stepId,overview[0].id);assert.equal(q('.mp-title').textContent,overview[0].title,'Arrival updates the explanation to match the chosen ancestor');assert.equal(api.getState().signals,false);canvas.remove();
 const oldHash='#overview?scene=control_900_FPGA_ETHERNET_AND_MCU_INTERFACE';api.stop();assert(!api.isActive());assert.equal(JSON.stringify(state),snapshot,'Explore view and camera restore');assert.equal(location.hash,oldHash);assert(!q('#mira-presentation'));assert(endedWhileActive,'Restoration must be suppressed from explore routing until finished');
 // Leaving by another route must not overwrite that route.
 api.start({stepId:main[0].id});await finish();location.hash='#sources';api.beforeCanvasDestroy();assert.equal(location.hash,'#sources');
 // Direct old/new presentation URLs should start the requested episode.
 storage.clear();location.hash='#presentation?step='+encodeURIComponent(main[1].id);api.start({fromHash:true,stepId:main[1].id});await finish();assert.equal(api.getState().stepId,main[1].id);
 assert.equal(api.getState().mode,'architecture','Legacy main URLs infer architecture route');
 // Space must keep its native meaning when a button has keyboard focus.
 const key=event(q('.mp-next'),'keydown',{key:' '});for(const listener of document.listeners.keydown)listener(key);assert(!key.defaultPrevented,'Space on Next remainsnativebuttonactivation');
 api.stop();
 const bareDetail=T.steps.find(s=>s.kind==='detail');api.start({stepId:bareDetail.id});await finish();assert.equal(api.getState().mode,'all','Bare detail request infers full route');assert.equal(api.getState().stepId,bareDetail.id,'Bare detail request opens the actual requested detail');api.stop();
 // Saved format/position is remembered, explicit requests take precedence.
 api.start({mode:'brief',stepId:brief[6].id});await finish();api.stop();api.start();await finish();assert.equal(api.getState().mode,'brief');assert.equal(api.getState().stepId,brief[6].id);api.stop();api.start({full:true});await finish();assert.equal(api.getState().mode,'all','Explicit all-route request overrides saved brief mode');api.stop();
 api.start({mode:'overview',stepId:overview[9].id});await finish();api.stop();api.start();await finish();assert.equal(api.getState().mode,'overview');assert.equal(api.getState().stepId,overview[9].id,'Main overview remembers its own position');api.stop();
 storage.clear();location.hash='#presentation?step='+encodeURIComponent(brief[4].id)+'&mode=brief';api.start({fromHash:true,mode:'brief',stepId:brief[4].id});await finish();assert.equal(api.getState().mode,'brief');assert.equal(api.getState().stepId,brief[4].id);assert.equal(frames.at(-1).spec.audience,'general');api.stop();
 const deepLinkBoot=await testAppDeepLink(),briefDeepLinkBoot=await testAppDeepLink('brief'),bareBriefDeepLinkBoot=await testAppDeepLink('brief',{bare:true}),overviewDeepLinkBoot=await testAppDeepLink('overview'),bareOverviewDeepLinkBoot=await testAppDeepLink('overview',{bare:true}),bareDetailDeepLinkBoot=await testAppDeepLink('all'),appNavigationCommitsOnArrival=await testAppNavigation();
 const report={passed:true,deepLinkBoot,briefDeepLinkBoot,bareBriefDeepLinkBoot,overviewDeepLinkBoot,bareOverviewDeepLinkBoot,bareDetailDeepLinkBoot,appNavigationCommitsOnArrival,realController:true,defaultOverviewSteps:overview.length,optionalBriefSteps:brief.length,architectureSteps:main.length,fullRouteSteps:T.steps.length,coveredSourceSheets:represented.size,manualNarration:true,captionStableDuringTransition:true,rapidNavigationSafe:true,pauseIndependent:true,pauseSurvivesTransition:true,chapterAndEpisodeSelection:true,overviewHasCompleteEpisodeSelector:true,ancestorClickKeepsNarrationAndPause:true,exploreViewRestored:true,externalHashPreserved:true,nativeButtonKeyboard:true,interruptedTransitionRecovered:true,formatRaceSafe:true,cancelledFormatRecovered:true,cancelledAudienceRestored:true,savedModeAndExplicitOverride:true};
 console.log(JSON.stringify(report,null,2));if(process.argv.includes('--report'))fs.writeFileSync(path.join(root,'data/presentation-controller-validation.json'),JSON.stringify(report,null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1;});
