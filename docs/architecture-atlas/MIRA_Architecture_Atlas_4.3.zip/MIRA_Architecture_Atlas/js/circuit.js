/* Local MIRA circuit fragments: exact KiCad symbols, pins and labelled nets. */
(function () {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg', cameras = Object.create(null);
  var prefix = 'mira.circuit.viewport.v1:';
  function list(a) { return Array.isArray(a) ? a : []; }
  function finite(a) { return typeof a === 'number' && isFinite(a); }
  function natural(a,b) { return String(a).localeCompare(String(b),'en',{numeric:true}); }
  function svg(tag, attrs, text) { var n=document.createElementNS(NS,tag); Object.keys(attrs||{}).forEach(function(k){if(attrs[k]!=null)n.setAttribute(k,attrs[k]);});if(text!=null)n.textContent=text;return n; }
  function el(tag,cls,text) { var n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n; }
  function unique(a) { return Array.from(new Set(a)); }
  function title(n,t) { n.appendChild(svg('title',{},t)); }
  function validCamera(c) { return !!c && finite(c.x)&&finite(c.y)&&finite(c.w)&&finite(c.h)&&c.w>0&&c.h>0; }
  function getBox(s) {
    var b=s.box||{}, points=[];list(s.graphics).forEach(function(g){list(g.points).forEach(function(p){points.push(p);});});list(s.pins).forEach(function(p){if(finite(p.x)&&finite(p.y))points.push([p.x,p.y]);});
    if(finite(b.x)&&finite(b.y)&&b.w>0&&b.h>0) points.push([b.x,b.y],[b.x+b.w,b.y+b.h]);
    if(!points.length) return {x:(s.x||0)-4,y:(s.y||0)-3,w:8,h:6};
    var xs=points.map(function(p){return p[0];}),ys=points.map(function(p){return p[1];}),x=Math.min.apply(null,xs),y=Math.min.apply(null,ys);
    return {x:x,y:y,w:Math.max(3,Math.max.apply(null,xs)-x),h:Math.max(3,Math.max.apply(null,ys)-y)};
  }
  function arcPath(points,project) {
    var a=points[0],m=points[1],z=points[2],det=2*(a[0]*(m[1]-z[1])+m[0]*(z[1]-a[1])+z[0]*(a[1]-m[1]));
    if(Math.abs(det)<1e-8)return 'M'+points.map(project).map(function(p){return p.join(' ');}).join(' L');
    var aa=a[0]*a[0]+a[1]*a[1],mm=m[0]*m[0]+m[1]*m[1],zz=z[0]*z[0]+z[1]*z[1];
    var cx=(aa*(m[1]-z[1])+mm*(z[1]-a[1])+zz*(a[1]-m[1]))/det,cy=(aa*(z[0]-m[0])+mm*(a[0]-z[0])+zz*(m[0]-a[0]))/det;
    var start=Math.atan2(a[1]-cy,a[0]-cx),mid=Math.atan2(m[1]-cy,m[0]-cx),end=Math.atan2(z[1]-cy,z[0]-cx),tau=Math.PI*2,delta=(end-start+tau)%tau,midDelta=(mid-start+tau)%tau,sweep=midDelta<=delta?1:0,span=sweep?delta:tau-delta;
    var pa=project(a),pz=project(z),r=Math.hypot(pa[0]-project([cx,cy])[0],pa[1]-project([cx,cy])[1]);
    return 'M'+pa.join(' ')+' A'+r+' '+r+' 0 '+(span>Math.PI?1:0)+' '+sweep+' '+pz.join(' ');
  }
  function graphic(g,project) {
    var p=list(g.points),p0=p.length?project(p[0]):null,p1=p.length>1?project(p[1]):null;if(!p0)return null;
    if(g.type==='polyline')return svg('polyline',{points:p.map(project).map(function(q){return q.join(',');}).join(' '),class:'mc-original-shape'});
    if(g.type==='rectangle'&&p1)return svg('rect',{x:Math.min(p0[0],p1[0]),y:Math.min(p0[1],p1[1]),width:Math.abs(p1[0]-p0[0]),height:Math.abs(p1[1]-p0[1]),class:'mc-original-shape'});
    if(g.type==='circle'&&p1)return svg('ellipse',{cx:(p0[0]+p1[0])/2,cy:(p0[1]+p1[1])/2,rx:Math.abs(p1[0]-p0[0])/2,ry:Math.abs(p1[1]-p0[1])/2,class:'mc-original-shape'});
    if(g.type==='arc'&&p.length>2)return svg('path',{d:arcPath(p,project),class:'mc-original-shape'});
    return null;
  }
  function mount(container,opts) {
    opts=opts||{};var A=opts.atlas||{},scene=opts.scene||{},node=opts.node||null,components=A.components||{},nets=A.nets||{},sheets=A.sheets||{},destroyed=false,events=[],tagged=[],symbolTags=[],drawnPins=[],drawingUnits=[],cardItems=[],selection={},drag=null,observer=null,lastSize=null,box=null,full=null;
    var scopeNodes=node?(list(node.sourceNodes).length?node.sourceNodes:[node]):list(scene.nodes), explicitGroup=node?(node.circuitGroup||null):(scene.circuitGroup||null), refs=unique((explicitGroup&&Array.isArray(explicitGroup.refs)?explicitGroup.refs:scopeNodes.reduce(function(out,n){return out.concat(list(n.refs).map(function(r){return typeof r==='string'?r:r.id||r.component;}));},[]))).filter(function(id){return components[id]&&!components[id].virtual;});
    var refSet=new Set(refs),sheetSet=new Set(), perRefSheets=Object.create(null);
    scopeNodes.forEach(function(n){var sid=n.sheetId||scene.sheetId;list(n.refs).forEach(function(ref){var id=typeof ref==='string'?ref:ref.id||ref.component;if(!id)return;if(!perRefSheets[id])perRefSheets[id]=new Set();if(sid){perRefSheets[id].add(sid);sheetSet.add(sid);}});});
    if(scene.sheetId)sheetSet.add(scene.sheetId);
    refs.forEach(function(id){if(!perRefSheets[id]||!perRefSheets[id].size){var cs=list(components[id].sheets);var matching=cs.filter(function(s){return sheetSet.has(s);});if(!matching.length&&cs.length===1)matching=cs;matching.forEach(function(s){sheetSet.add(s);});perRefSheets[id]=new Set(matching);}});
    var groupUnits=list(explicitGroup&&explicitGroup.units);if(explicitGroup){list(explicitGroup.sheetIds).forEach(function(s){sheetSet.add(s);});groupUnits.forEach(function(u){var sid=u.sheet||u.sheetId;if(sid){sheetSet.add(sid);if(!perRefSheets[u.component])perRefSheets[u.component]=new Set();perRefSheets[u.component].add(sid);}});}
    var seenUnits=new Set();Array.from(sheetSet).sort(natural).forEach(function(sid){var sheet=sheets[sid];if(!sheet)return;list((sheet.drawing||{}).symbols).forEach(function(s){
      if(!refSet.has(s.component))return;if(groupUnits.length&&!groupUnits.some(function(u){return u.component===s.component&&String(u.unit)===String(s.unit)&&(!u.sheet&&!u.sheetId||(u.sheet||u.sheetId)===sid);}))return;var allowed=perRefSheets[s.component];if(allowed&&allowed.size&&!allowed.has(sid))return;
      var key=s.component+'|'+sid+'|'+s.unit+'|'+(s.uuid||'');if(seenUnits.has(key))return;seenUnits.add(key);
      drawingUnits.push({symbol:s,sheetId:sid,component:components[s.component]});
    });});
    // A component shared between several sheets is only shown on the requested
    // source sheet. If explicit net filtering is needed, do not pull in another
    // bank or power unit solely because it has the same reference designator.
    if(node&&list(node.units).length)drawingUnits=drawingUnits.filter(function(u){return list(node.units).some(function(v){return typeof v==='object'?(v.component===u.symbol.component&&String(v.unit)===String(u.symbol.unit)):String(v)===String(u.symbol.unit);});});
    var missing=refs.filter(function(id){return !drawingUnits.some(function(u){return u.symbol.component===id;});});
    var cameraKey=prefix+encodeURIComponent(scene.id||scene.sheetId||'scene')+':'+encodeURIComponent(node?node.id||refs.join(','):'all');
    var root=el('div','mira-circuit');root.dataset.engine='mira-circuit';container.appendChild(root);
    var viewport=el('div','mc-viewport');viewport.tabIndex=0;viewport.setAttribute('aria-label','Схемотехника выбранного блока. Перетаскивайте фон; колесо мыши изменяет масштаб.');root.appendChild(viewport);
    var canvas=svg('svg',{xmlns:NS,class:'mc-canvas',role:'group','aria-label':(node?node.title:scene.title)||'Схемотехника',preserveAspectRatio:'xMidYMid meet'});viewport.appendChild(canvas);var backgroundLayer=svg('g',{class:'mc-card-backgrounds'}),routeLayer=svg('g',{class:'mc-traced-routes','aria-label':'Подсветка электрических связей между совпадающими метками'});canvas.append(backgroundLayer,routeLayer);
    var meta=el('div','mc-caption');meta.append(el('strong','',node?node.title:scene.title||'Схемотехника'),el('span','',drawingUnits.length+' секц. УГО · '+refs.length+' компонентов'));root.appendChild(meta);
    var info=el('div','mc-selection');root.appendChild(info);
    var note=el('div','mc-note','УГО и выводы из KiCad. Пунктир — связь одноимённых меток. ⟨…⟩ — безымянная цепь. Расположение УГО изменено.');root.appendChild(note);
    function listen(t,type,fn,opt){t.addEventListener(type,fn,opt);events.push(function(){t.removeEventListener(type,fn,opt);});}
    function netName(id){var n=nets[id];if(!n)return String(id||'');return /generated/.test(n.nameSource||'')?'⟨'+n.name.replace(/^UNNAMED_/,'')+'⟩':n.name;}
    function netDescription(id){var n=nets[id];if(!n)return '';var ps=list(n.pins).filter(function(p){return !p.virtual;});return n.name+' · '+ps.map(function(p){return (components[p.component]||{}).ref+'.'+(p.pin||p.number||'?')+(p.name?' ('+p.name+')':'');}).join(' ↔ ');}
    function selectNet(id){if(!id)return;setSelection({netIds:[id],pinStates:selection.pinStates||[],pinHighlights:selection.pinHighlights||[]});if(typeof opts.onSelectNet==='function')opts.onSelectNet(id);}
    function tagNet(g,id){if(!id)return;tagged.push({node:g,net:id,component:g.dataset.component});g.dataset.net=id;g.setAttribute('tabindex','0');g.setAttribute('role','button');g.setAttribute('aria-label',netDescription(id));title(g,netDescription(id));listen(g,'click',function(e){e.stopPropagation();selectNet(id);});listen(g,'keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();selectNet(id);}});}
    function renderUnit(unit){
      var pinStart=drawnPins.length,s=unit.symbol,c=unit.component,b=getBox(s),pins=list(s.pins),scale=8.7,body=s.box||b,visible=pins.filter(function(p){return !p.hidden;}),leftNames=0,rightNames=0;
      visible.forEach(function(p){var dx=(p.bodyX==null?s.x:p.bodyX)-p.x,dy=(p.bodyY==null?s.y:p.bodyY)-p.y;if(Math.abs(dx)>=Math.abs(dy)){if(dx>=0)leftNames=Math.max(leftNames,String(p.name||'').length*6.8);else rightNames=Math.max(rightNames,String(p.name||'').length*6.8);}});
      scale=Math.max(scale,(leftNames+rightNames+28)/Math.max(10,body.w||b.w));
      var sides={left:[],right:[],top:[],bottom:[]};visible.forEach(function(p){var dx=(p.bodyX==null?s.x:p.bodyX)-p.x,dy=(p.bodyY==null?s.y:p.bodyY)-p.y;if(Math.abs(dx)>=Math.abs(dy))sides[dx>=0?'left':'right'].push(p.y);else sides[dy>=0?'top':'bottom'].push(p.x);});Object.keys(sides).forEach(function(side){var values=unique(sides[side]).sort(function(a,b){return a-b;});for(var i=1;i<values.length;i++){var gap=values[i]-values[i-1];if(gap>.01)scale=Math.max(scale,(side==='top'||side==='bottom'?18:20)/gap);}});var extLeft=0,extRight=0,extTop=0,extBottom=0;
      visible.forEach(function(p){var dx=(p.bodyX==null?s.x:p.bodyX)-p.x,dy=(p.bodyY==null?s.y:p.bodyY)-p.y,nlen=Math.min(52,netName(p.net).length)*7.4+40;if(Math.abs(dx)>=Math.abs(dy)){if(dx>=0)extLeft=Math.max(extLeft,nlen);else extRight=Math.max(extRight,nlen);}else if(dy>=0)extTop=Math.max(extTop,nlen*.91);else extBottom=Math.max(extBottom,nlen*.91);});
      var left=Math.max(30,extLeft),right=Math.max(30,extRight),top=64+Math.max(25,extTop),bottom=Math.max(30,extBottom),hidden=pins.filter(function(p){return p.hidden;});
      var w=Math.max(360,left+b.w*scale+right+18),h=Math.max(165,top+b.h*scale+bottom+hidden.length*19+20),g=svg('g',{class:'mc-unit','data-component':s.component,'data-unit':s.unit,'data-sheet':unit.sheetId});
      var project=function(p){return [left+(p[0]-b.x)*scale,top+(p[1]-b.y)*scale];};
      var card=svg('rect',{x:0,y:0,width:w,height:h,rx:12,class:'mc-unit-card'});
      var heading=svg('text',{x:22,y:29,class:'mc-ref'},c.ref+(Number(s.unit)>1?' · секция '+s.unit:''));g.appendChild(heading);g.appendChild(svg('text',{x:22,y:49,class:'mc-value'},c.value||''));title(heading,(c.ref||'')+' · '+(c.value||''));
      var originalCount=0;list(s.graphics).forEach(function(shape){var q=graphic(shape,project);if(q){g.appendChild(q);originalCount++;}});
      if(!originalCount){var bp=project([body.x,body.y]);g.appendChild(svg('rect',{x:bp[0],y:bp[1],width:Math.max(20,(body.w||b.w)*scale),height:Math.max(20,(body.h||b.h)*scale),class:'mc-fallback'}));g.appendChild(svg('text',{x:22,y:h-12,class:'mc-missing'},'УГО отсутствует в источнике; выводы точные'));}
      var unitTag={node:g,card:card,component:s.component,nets:unique(pins.map(function(p){return p.net;}).filter(Boolean))};symbolTags.push(unitTag);
      visible.forEach(function(p){
        var at=project([p.x,p.y]),end=project([finite(p.bodyX)?p.bodyX:p.x,finite(p.bodyY)?p.bodyY:p.y]),dx=end[0]-at[0],dy=end[1]-at[1],horizontal=Math.abs(dx)>=Math.abs(dy),dir=horizontal?(dx>=0?1:-1):(dy>=0?1:-1);
        var pg=svg('g',{class:'mc-terminal','data-component':s.component,'data-pin':p.number,'data-unit':s.unit});
        var stem=svg('line',{x1:at[0],y1:at[1],x2:end[0],y2:end[1],class:'mc-pin-stem'});pg.appendChild(stem);pg.appendChild(svg('circle',{cx:at[0],cy:at[1],r:3,class:'mc-pin-end'}));
        var num=svg('text',{x:(at[0]+end[0])/2+(horizontal?0:4),y:(at[1]+end[1])/2+(horizontal?-4:3),'text-anchor':'middle',class:'mc-pin-number'},p.number);if(!horizontal){var nx=at[0]-4,ny=(at[1]+end[1])/2;num.setAttribute('x',nx);num.setAttribute('y',ny);num.setAttribute('transform','rotate(-90 '+nx+' '+ny+')');}pg.appendChild(num);
        if(p.name&&p.name!=='~'){var name=svg('text',{x:end[0]+(horizontal?dir*7:5),y:end[1]+(horizontal?4:dir*14),'text-anchor':horizontal?(dir>0?'start':'end'):'start',class:'mc-pin-name'},p.name);if(!horizontal){var nmx=end[0]+3,nmy=end[1]+dir*8;name.setAttribute('x',nmx);name.setAttribute('y',nmy);name.setAttribute('text-anchor',dir>0?'start':'end');name.setAttribute('transform','rotate(90 '+nmx+' '+nmy+')');}pg.appendChild(name);}
        var labelX=at[0]+(horizontal?-dir*9:0),labelY=at[1]+(horizontal?4:-dir*11),net=netName(p.net),labelAttrs={x:labelX,y:labelY,'text-anchor':horizontal?(dir>0?'end':'start'):(dir>0?'start':'end'),class:'mc-net-label'};
        if(!horizontal)labelAttrs.transform='rotate(-65 '+labelX+' '+labelY+')';
        var componentPin=list(c.pins).find(function(cp){return cp.sheet===unit.sheetId&&String(cp.number)===String(p.number);}),isNC=p.noConnect||(componentPin&&componentPin.noConnect);var label=svg('text',labelAttrs,net||(isNC?'NC':'не подключён'));pg.appendChild(label);var state=svg('text',{x:labelX,y:labelY+16,'text-anchor':labelAttrs['text-anchor'],class:'mc-pin-state'});if(!horizontal)state.setAttribute('transform','rotate(-65 '+labelX+' '+(labelY+16)+')');pg.appendChild(state);
        tagNet(pg,p.net);drawnPins.push({node:pg,state:state,pin:p,component:s.component,unit:s.unit,net:p.net,point:at,horizontal:horizontal,outDir:-dir});g.appendChild(pg);
      });
      hidden.forEach(function(p,i){var pg=svg('g',{class:'mc-terminal mc-hidden-terminal','data-component':s.component,'data-pin':p.number});pg.appendChild(svg('text',{x:22,y:h-18-(hidden.length-i-1)*19,class:'mc-hidden-pin'},'Скрытый вывод '+p.number+(p.name?' '+p.name:'')+' · '+netName(p.net)));var st=svg('text',{x:w-20,y:h-18-(hidden.length-i-1)*19,'text-anchor':'end',class:'mc-pin-state'});pg.appendChild(st);tagNet(pg,p.net);drawnPins.push({node:pg,state:st,pin:p,component:s.component,unit:s.unit,net:p.net});g.appendChild(pg);});
      title(g,c.ref+' · '+(c.value||'')+' · '+(sheets[unit.sheetId]||{}).file+' · секция '+s.unit);
      if(typeof opts.onSelectComponent==='function'){heading.classList.add('mc-component-link');listen(heading,'click',function(e){e.stopPropagation();opts.onSelectComponent(s.component);});}
      return {node:g,card:card,w:w,h:h,unit:unit,pins:drawnPins.slice(pinStart)};
    }
    var initiallyActive=new Set(list(opts.netIds));drawingUnits.sort(function(a,b){var aa=list(a.symbol.pins).some(function(p){return initiallyActive.has(p.net);})?1:0,ba=list(b.symbol.pins).some(function(p){return initiallyActive.has(p.net);})?1:0,ac=list(a.symbol.pins).length,bc=list(b.symbol.pins).length;return ba-aa||bc-ac||natural(a.component.ref,b.component.ref)||Number(a.symbol.unit)-Number(b.symbol.unit);}).forEach(function(u){cardItems.push(renderUnit(u));});
    var columns=cardItems.length<=2?Math.max(1,cardItems.length):(opts.wideLayout&&container.getBoundingClientRect().width>900?Math.min(4,cardItems.length):2),colWidths=[];cardItems.forEach(function(item,i){var col=i%columns;colWidths[col]=Math.max(colWidths[col]||0,item.w);});
    var colX=[28];for(var col=1;col<columns;col++)colX[col]=colX[col-1]+colWidths[col-1]+34;
    var colY=Array(columns).fill(68);cardItems.forEach(function(item,i){var col=i%columns;item.x=colX[col];item.y=colY[col];item.node.setAttribute('transform','translate('+item.x+' '+item.y+')');var bg=svg('g',{transform:'translate('+item.x+' '+item.y+')'});bg.appendChild(item.card);backgroundLayer.appendChild(bg);canvas.appendChild(item.node);item.pins.forEach(function(p){if(!p.point)return;p.world=[item.x+p.point[0],item.y+p.point[1]];p.card=item;p.exit=p.horizontal?[p.outDir<0?item.x-10:item.x+item.w+10,p.world[1]]:[p.world[0],p.outDir<0?item.y-10:item.y+item.h+10];});colY[col]+=item.h+30;});
    var maxW=colWidths.reduce(function(a,b){return a+b;},0)+Math.max(0,columns-1)*34+56,maxH=Math.max.apply(null,colY)+15;
    if(!cardItems.length){var empty=el('div','mc-empty','Для этого блока не заданы УГО. Выберите функциональный модуль или его часть.');root.appendChild(empty);maxW=700;maxH=450;}
    if(missing.length){var missingText=el('div','mc-missing-note','Не найдено размещённое УГО: '+missing.map(function(id){return components[id].ref;}).join(', '));root.appendChild(missingText);}
    full={x:0,y:0,w:Math.max(450,maxW),h:Math.max(260,maxH)};
    function size(){var r=viewport.getBoundingClientRect();return {w:r.width>0?r.width:lastSize?lastSize.w:1000,h:r.height>0?r.height:lastSize?lastSize.h:650};}
    function apply(){if(box)canvas.setAttribute('viewBox',[box.x,box.y,box.w,box.h].join(' '));}
    function getViewport(){if(!box)return null;var d=lastSize||size();return {x:box.x,y:box.y,w:box.w,h:box.h,viewportWidth:d.w,viewportHeight:d.h,view:'circuit'};}
    function remember(){if(opts.persistCamera===false||(typeof opts.persistCamera==='function'&&!opts.persistCamera()))return;var v=getViewport();if(!v)return;cameras[cameraKey]=v;try{window.localStorage.setItem(cameraKey,JSON.stringify(v));}catch(ignore){}}
    function setViewport(c){if(!validCamera(c))return false;var d=size(),scale=c.h/(c.viewportHeight>0?c.viewportHeight:d.h),cx=c.x+c.w/2,cy=c.y+c.h/2;box={x:cx-d.w*scale/2,y:cy-d.h*scale/2,w:d.w*scale,h:d.h*scale};lastSize=d;apply();remember();return true;}
    function fit(){var d=size(),margin=25,w=full.w+margin*2,h=full.h+margin*2,ratio=d.w/d.h;if(w/h<ratio)w=h*ratio;else h=w/ratio;box={x:full.x+full.w/2-w/2,y:full.y+full.h/2-h/2,w:w,h:h};lastSize=d;apply();remember();}
    function initial(){var c=cameras[cameraKey];if(!c)try{c=JSON.parse(window.localStorage.getItem(cameraKey));}catch(ignore){}if(setViewport(c))return;var d=size(),readableScale=.78,w=d.w/readableScale,h=d.h/readableScale;box={x:0,y:0,w:w,h:h};lastSize=d;apply();remember();}
    function zoom(factor,x,y){if(!box||!finite(factor)||factor<=0)return;var w=Math.max(140,Math.min(Math.max(full.w*3,6000),box.w/factor)),h=box.h*w/box.w;x=finite(x)?x:box.x+box.w/2;y=finite(y)?y:box.y+box.h/2;var rx=(x-box.x)/box.w,ry=(y-box.y)/box.h;box={x:x-rx*w,y:y-ry*h,w:w,h:h};apply();remember();}
    function pinStateFor(record,states){
      var ref=(components[record.component]||{}).ref;
      if(Array.isArray(states))return states.find(function(s){var c=s.component||s.componentId||s.ref,p=s.pin!=null?s.pin:s.number;return ((!c&&(s.netId||s.net)===record.net)||((c===record.component||c===ref)&&String(p)===String(record.pin.number)))&&(!s.unit||String(s.unit)===String(record.unit));});
      if(!states||typeof states!=='object')return null;var keys=[record.component+'.'+record.pin.number,ref+'.'+record.pin.number,record.net];for(var i=0;i<keys.length;i++)if(Object.prototype.hasOwnProperty.call(states,keys[i])){var v=states[keys[i]];return typeof v==='object'&&v!==null?v:{value:v};}return null;
    }
    function setSelection(value){
      if(typeof value==='string')value={netIds:[value]};selection=value||{};var ids=unique(list(selection.netIds).map(function(id){if(nets[id])return id;return Object.keys(nets).find(function(k){return nets[k].name===id;})||id;})),chosen=new Set(ids),states=selection.pinStates||[],highlights=selection.pinHighlights||[];var has=ids.length>0||list(selection.componentIds).length>0||(Array.isArray(states)?states.length>0:Object.keys(states).length>0)||list(highlights).length>0,selectedComponents=new Set(list(selection.componentIds));
      var stateNets=new Set();drawnPins.forEach(function(p){var s=pinStateFor(p,states)||pinStateFor(p,highlights);if(s&&p.net)stateNets.add(p.net);});routeLayer.replaceChildren();unique(ids.concat(Array.from(stateNets))).forEach(function(id){var seen=new Set(),ps=drawnPins.filter(function(p){if(p.net!==id||!p.world)return false;var k=p.component+'.'+p.pin.number;if(seen.has(k))return false;seen.add(k);return true;}).sort(function(a,b){return a.card.x-b.card.x||a.world[1]-b.world[1];});for(var i=1;i<ps.length;i++){var a=ps[i-1],b=ps[i];if(a.card===b.card)continue;var start=a.world,end=b.world,exitA=a.exit,exitB=b.exit,midX=(exitA[0]+exitB[0])/2;var d='M'+start.join(' ')+' L'+exitA.join(' ')+' C'+midX+' '+exitA[1]+' '+midX+' '+exitB[1]+' '+exitB.join(' ')+' L'+end.join(' ');var path=svg('path',{d:d,class:'mc-traced-route','data-net':id});title(path,netName(id)+' · электрическая связь; прокладка линии условная');routeLayer.appendChild(path);}});tagged.forEach(function(t){var active=chosen.has(t.net)||stateNets.has(t.net)||selectedComponents.has(t.component);t.node.classList.toggle('is-active',active);t.node.classList.toggle('is-muted',has&&!active);});
      symbolTags.forEach(function(t){var active=selectedComponents.has(t.component)||t.nets.some(function(id){return chosen.has(id)||stateNets.has(id);});t.node.classList.toggle('is-active',active);t.card.classList.toggle('is-active',active);});
      drawnPins.forEach(function(p){var state=pinStateFor(p,states),highlight=pinStateFor(p,highlights),value=state?(state.value!=null?state.value:state.state!=null?state.state:state.label!=null?state.label:''):'';if(!state&&highlight){var direction=highlight.direction||p.pin.type;value=({input:'вход',output:'выход',bidirectional:'вход / выход',power_in:'питание',power_out:'питание',passive:'тракт',tri_state:'выход'})[direction]||'выделен';}p.state.textContent=String(value);p.state.classList.toggle('is-observation',!state&&!!highlight);p.node.classList.toggle('has-state',!!state||!!highlight);p.node.classList.toggle('state-low',!!state&&(value===0||value==='0'));p.node.classList.toggle('state-high',!!state&&(value===1||value==='1'));if(state||highlight)p.node.classList.remove('is-muted');});
      info.replaceChildren();if(ids.length){var inView=ids.filter(function(id){return drawnPins.some(function(p){return p.net===id;});}),visible=(inView.length?inView:ids).slice(0,3);visible.forEach(function(id){var row=el('div','mc-selected-net'),n=el('strong','',netName(id)),ps=list((nets[id]||{}).pins).filter(function(p){return !p.virtual;}),endpoints=ps.map(function(p){return ((components[p.component]||{}).ref||p.component)+'.'+(p.pin||p.number);});row.append(n,el('span','',endpoints.join(' ↔ ')));row.title=netDescription(id);info.appendChild(row);});if(ids.length>3)info.appendChild(el('span','mc-more','Подсвечено цепей: '+ids.length));}else info.appendChild(el('span','','Выберите вывод или имя цепи, чтобы увидеть связанные подключения.'));
      info.classList.toggle('has-selection',!!ids.length);
    }
    initial();setSelection({netIds:list(opts.netIds),pinStates:opts.pinStates||[],pinHighlights:opts.pinHighlights||[],componentIds:list(opts.componentIds)});
    function point(e){var r=canvas.getBoundingClientRect();return {x:box.x+(e.clientX-r.left)/Math.max(1,r.width)*box.w,y:box.y+(e.clientY-r.top)/Math.max(1,r.height)*box.h};}
    listen(canvas,'wheel',function(e){e.preventDefault();var p=point(e);zoom(e.deltaY<0?1.13:1/1.13,p.x,p.y);},{passive:false});
    listen(canvas,'pointerdown',function(e){if(e.button!==0||e.target.closest('.mc-terminal,.mc-component-link'))return;drag={x:e.clientX,y:e.clientY,box:Object.assign({},box),id:e.pointerId,moved:false};});
    listen(canvas,'pointermove',function(e){if(!drag)return;var d=size(),dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>4&&!drag.moved){drag.moved=true;if(canvas.setPointerCapture)canvas.setPointerCapture(drag.id);canvas.classList.add('is-panning');}if(!drag.moved)return;box={x:drag.box.x-dx/d.w*drag.box.w,y:drag.box.y-dy/d.h*drag.box.h,w:drag.box.w,h:drag.box.h};apply();remember();});
    function endDrag(){if(!drag)return;drag=null;canvas.classList.remove('is-panning');}listen(canvas,'pointerup',endDrag);listen(canvas,'pointercancel',endDrag);
    listen(viewport,'keydown',function(e){if(e.target!==viewport)return;if(e.key==='+'||e.key==='='){e.preventDefault();zoom(1.25);}if(e.key==='-'){e.preventDefault();zoom(.8);}if(e.key==='0'){e.preventDefault();fit();}});
    if(window.ResizeObserver){observer=new window.ResizeObserver(function(){if(destroyed||!box)return;var old=lastSize||size(),d=size();if(d.w===old.w&&d.h===old.h)return;var units=box.h/old.h,cx=box.x+box.w/2,cy=box.y+box.h/2;box={x:cx-d.w*units/2,y:cy-d.h*units/2,w:d.w*units,h:d.h*units};lastSize=d;apply();remember();});observer.observe(viewport);}
    function getState(){return {sceneId:scene.id,nodeId:node&&node.id,componentIds:refs.slice(),units:drawingUnits.map(function(u){return {component:u.symbol.component,unit:u.symbol.unit,sheetId:u.sheetId,pinCount:list(u.symbol.pins).length,originalGraphics:list(u.symbol.graphics).length};}),pins:drawnPins.map(function(p){return {component:p.component,pin:p.pin.number,unit:p.unit,net:p.net,state:p.state.textContent};}),selection:selection,camera:getViewport(),missingComponentIds:missing.slice()};}
    return {destroy:function(){if(destroyed)return;remember();destroyed=true;events.forEach(function(fn){fn();});if(observer)observer.disconnect();root.remove();},setSelection:setSelection,fit:fit,zoom:zoom,getViewport:getViewport,setViewport:setViewport,getState:getState};
  }
  window.MiraCircuit={mount:mount};
})();
