/* MIRA Atlas signal microscope. Plain script; file:// compatible. */
(function (global) {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var PAYLOAD = [0x4D, 0x49, 0x52, 0x41];
  var NIBBLES = PAYLOAD.reduce(function (a, b) { return a.concat([b & 15, b >> 4]); }, []);
  var ANALOG = [0,.3,.8,.85,.25,-.45,-.8,-.25,.25,.65,.25,-.15,-.7,-.85,-.35,.4,.85,.65,.1,-.5,-.35,.25,.65,.4,0,-.65,-.9,-.4,.2,.8,.55,0,-.45,-.25,.3,.75,.3,-.4,-.65,-.1,.35,.6,.2,-.3,-.75,-.4,.2,.45,.1];
  function values(x) { return Array.isArray(x) ? x : Object.keys(x || {}).map(function (k) { var v = x[k]; return v && typeof v === 'object' ? Object.assign({ _key: k }, v) : null; }).filter(Boolean); }
  function esc(x) { return String(x == null ? '' : x).replace(/[&<>"']/g, function (c) { return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]; }); }
  function nameOf(n) { return n && (n.name || n.label || n.netName || n._key || n.id) || ''; }
  function idOf(n) { return n && (n.id || n._key || nameOf(n)) || ''; }
  function refOf(c) { return c && (c.ref || c.reference || c.Reference || c._key || c.id) || ''; }
  function sheetOf(o) { return o && (o.sheet || o.sheetId || o.sheet_id) || ''; }
  function hex(n) { return n.toString(16).toUpperCase().padStart(2, '0'); }
  function nib(n) { return n.toString(16).toUpperCase(); }
  function node(tag, attrs, text) { var n = document.createElement(tag); Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); }); if (text != null) n.textContent = text; return n; }

  function mount(container, options) {
    if (!container || !container.appendChild) throw new Error('MiraSignals.mount requires a DOM container.');
    options = options || {};
    var atlas = options.atlas || {}, nets = values(atlas.nets), components = values(atlas.components);
    var byName = {}, byId = {}, byRef = {}, byComponentId = {};
    nets.forEach(function (n) { byId[idOf(n)] = n; if (!byName[nameOf(n)]) byName[nameOf(n)] = n; });
    components.forEach(function (c) { byRef[refOf(c)] = c; byComponentId[c.id || c._key || refOf(c)] = c; });
    var selected = byId[options.netId] || byName[options.netId] || null;
    var relevant = nets.filter(function (n) {
      return !options.sheetId || sheetOf(n) === options.sheetId || (n.sheets || []).indexOf(options.sheetId) >= 0 || (n.pins || []).some(function (p) { return sheetOf(p) === options.sheetId; });
    });
    if (!relevant.length) relevant = nets;
    if (selected && relevant.indexOf(selected) < 0) relevant.unshift(selected);
    relevant.sort(function (a, b) { return nameOf(a).localeCompare(nameOf(b), undefined, { numeric: true }); });
    var ethernetAvailable = !!(byRef.J900 || byRef.T900 || byRef.U902 || byName.PHY_RXC) && (!options.sheetId || relevant.some(function(n){return /^PHY_RX/.test(nameOf(n));}));
    var mode = normalizeMode(options.mode || 'auto');
    function normalizeMode(m) {
      if (m === 'auto' || !m) {
        var n = nameOf(selected);
        if (/^(PHY_|MDI_|ETH_)/i.test(n) || (!n && ethernetAvailable)) return 'ethernet';
        if (selected && ['power','ground'].indexOf(selected.kind)>=0 || /(^\+|^VDD|^VCC|^GND|^AGND|^DGND|V[0-9]|[0-9]V[0-9])/.test(n)) return 'power';
        if (selected && selected.kind==='analog') return 'analog';
        return 'digital';
      }
      if (m === 'voltage' || m === 'current') return 'analog';
      return ['ethernet', 'digital', 'analog', 'power'].indexOf(m) >= 0 ? m : 'digital';
    }
    var stage = 0, probe = 0, timer = null, destroyed = false, resize = null;
    var reduced = global.matchMedia ? global.matchMedia('(prefers-reduced-motion: reduce)').matches : false;
    var uid = 'msig-' + Math.random().toString(36).slice(2, 9);
    var root = node('section', { class: 'msig', 'aria-label': 'Микроскоп сигналов' });
    root.innerHTML = '<header class="msig-header"><div><div class="msig-eyebrow">Наблюдение сигнала</div><h2>Микроскоп сигналов</h2><div class="msig-muted">Проследите соединение и посмотрите условную форму сигнала.</div></div><span class="msig-badge">Учебная модель · не измерение</span></header>' +
      '<div class="msig-toolbar"><label class="msig-field">Вид<select data-sig="mode" aria-label="Вид сигнала"><option value="ethernet">Тракт приёма Ethernet</option><option value="digital">Цифровая цепь</option><option value="analog">Аналоговый сигнал</option><option value="power">Включение питания</option></select></label><label class="msig-field ms-source">Цепь схемы<select data-sig="net" aria-label="Цепь схемы"></select></label><label class="msig-field" data-sig="kindfield">Модель сигнала<select data-sig="kind" aria-label="Модель сигнала"><option value="logic">Логическое состояние</option><option value="clock">Тактирование</option></select></label></div>' +
      '<div class="msig-stages" data-sig="stages" aria-label="Точка наблюдения"></div>' +
      '<div class="msig-panel"><div class="msig-caption"><div><h3 data-sig="heading"></h3><p class="msig-muted" data-sig="location"></p></div><span class="msig-badge" data-sig="tracebadge">Условная форма сигнала</span></div><svg class="msig-plot" data-sig="svg" role="img" aria-label="Условная осциллограмма"></svg><div class="msig-legend" data-sig="legend"></div><div class="msig-controls"><button type="button" class="msig-play" data-sig="play">Воспроизвести</button><button type="button" data-sig="back" aria-label="Предыдущий отсчёт">←</button><button type="button" data-sig="next" aria-label="Следующий отсчёт">→</button><label for="' + uid + '">Курсор<input id="' + uid + '" type="range" min="0" max="7" step="1" value="0" data-sig="probe"></label><span class="msig-position" data-sig="position"></span></div><div class="msig-readout" data-sig="readout" aria-live="polite"></div></div>' +
      '<div class="msig-bytes" data-sig="bytes"></div><p class="msig-explanation" data-sig="explanation"></p><section class="msig-sourcebox"><h4>Соединения из исходной схемы KiCad</h4><p data-sig="sourcecaption"></p><div class="msig-netcards" data-sig="sources"></div></section><footer class="msig-caveat">Соединения и имена выводов ниже взяты из загруженной схемы. Осциллограммы, данные «MIRA», кривые напряжения и моменты событий показаны условно. Здесь не моделируются линейное кодирование Ethernet, реальные задержки, электрические запасы, измеренные сигналы или работа схемы в симуляторе.</footer>';
    container.appendChild(root);
    function q(s) { return root.querySelector('[data-sig="' + s + '"]'); }
    var svg = q('svg'), kind = 'logic';
    q('mode').value = mode;
    q('net').appendChild(node('option', { value: '' }, 'Выберите цепь схемы…'));
    relevant.forEach(function (n, i) { var o = node('option', { value: String(i) }, nameOf(n)); if (n === selected) o.selected = true; q('net').appendChild(o); });
    if (!selected) q('net').value = '';

    function sourceNet(name) { return byName[name] || null; }
    function rxNet(suffix) {
      return sourceNet('PHY_' + suffix) || nets.find(function (n) { return new RegExp('(?:^|[/_])' + suffix + '$', 'i').test(nameOf(n)); }) || null;
    }
    function rxName(suffix) { var n = rxNet(suffix); return n ? nameOf(n) : suffix + ' (модель)'; }
    function actualRef(ref, fallback) { return byRef[ref] ? ref : fallback; }
    function endpointPins(n) {
      if (n.pins && n.pins.length) return n.pins;
      var result = [];
      components.forEach(function (c) { values(c.pins).forEach(function (p) {
        if (p.net === idOf(n) || p.net === nameOf(n) || p.netId === idOf(n)) result.push(Object.assign({ component: refOf(c), sheet: sheetOf(c) }, p));
      }); });
      return result;
    }
    function currentNets() {
      if (mode !== 'ethernet') return selected ? [selected] : [];
      var names = stage === 0 ? ['ETH_A_P', 'ETH_A_N'] : stage === 1 ? ['MDI_A_P', 'MDI_A_N'] : ['RXC', 'RX_CTL', 'RXD0', 'RXD1', 'RXD2', 'RXD3'];
      return names.map(function (n) { return stage < 2 ? sourceNet(n) : rxNet(n); }).filter(Boolean);
    }
    function sources() {
      var list = currentNets(); q('sources').replaceChildren();
      q('sourcecaption').textContent = mode === 'ethernet' ? 'Здесь показаны цепи схемы в выбранной точке наблюдения. Движущаяся осциллограмма — отдельная учебная модель.' : selected ? 'Выбранная цепь и подключённые к ней выводы компонентов взяты из схемы. Осциллограмма — отдельная учебная модель.' : 'Выберите цепь, чтобы рядом с условной осциллограммой увидеть её реальные подключения.';
      if (!list.length) { q('sources').appendChild(node('div', { class: 'msig-no-source' }, 'Для этой точки наблюдения нет соответствующей цепи в загруженной схеме. Имена цепей и подключения выводов не подставляются предположительно.')); return; }
      list.forEach(function (n) {
        var card = node('article', { class: 'msig-netcard' }), button = node('button', { type: 'button', title: 'Открыть эту цепь' }, nameOf(n));
        button.addEventListener('click', function () { if (typeof options.onSelectNet === 'function') options.onSelectNet(idOf(n), n); });
        card.appendChild(button); var listEl = node('ul');
        var pins = endpointPins(n), physical = pins.filter(function (p) { return !p.virtual && !(byComponentId[p.component] || {}).virtual; });
        var virtual = pins.filter(function (p) { return p.virtual || (byComponentId[p.component] || {}).virtual; });
        function pinRow(p) {
          var component = typeof p.component === 'object' ? refOf(p.component) : refOf(byComponentId[p.component]) || p.component || p.ref || p.reference || '';
          var pin = p.pin != null ? p.pin : p.number, pinName = p.name || p.pinName || '';
          var li = node('li'); li.innerHTML = '<b>' + esc(component || 'Компонент') + '</b> · вывод ' + esc(pin == null ? '?' : pin) + (pinName ? ' · ' + esc(pinName) : ''); return li;
        }
        physical.slice(0,12).forEach(function(p){listEl.appendChild(pinRow(p));});
        if (!listEl.children.length) listEl.appendChild(node('li', {}, 'Данные о выводах для этой записи отсутствуют.'));
        card.appendChild(node('div',{class:'msig-muted'},'Выводов компонентов: '+physical.length+' · символов питания: '+virtual.length));
        card.appendChild(listEl);
        if(physical.length>12){var more=node('details'),summary=node('summary',{},'Остальные выводы компонентов: '+(physical.length-12)),ul=node('ul');more.appendChild(summary);physical.slice(12).forEach(function(p){ul.appendChild(pinRow(p));});more.appendChild(ul);card.appendChild(more);}
        if(virtual.length){var virt=node('details'),vs=node('summary',{},'Показать символы питания: '+virtual.length),vu=node('ul');virt.appendChild(vs);virtual.forEach(function(p){vu.appendChild(pinRow(p));});virt.appendChild(vu);card.appendChild(virt);}
        if(n.terminals&&n.terminals.length){var terms=node('details'),ts=node('summary',{},'Показать метки цепи: '+n.terminals.length),tu=node('ul');terms.appendChild(ts);n.terminals.forEach(function(t){var sh=atlas.sheets&&atlas.sheets[t.sheet];tu.appendChild(node('li',{},(t.name||nameOf(n))+' · '+({local:'локальная',global:'глобальная',hierarchical:'иерархическая',power:'питание'}[t.scope]||t.scope||'локальная')+' · '+(sh&&(sh.file||sh.name)||t.sheet||'')+(t.x!=null?' · '+t.x+', '+t.y+' мм':'')));});terms.appendChild(tu);card.appendChild(terms);}
        q('sources').appendChild(card);
      });
    }
    function maxProbe() { return mode === 'ethernet' && stage >= 2 ? 7 : 32; }
    function stop() { if (timer != null) global.clearTimeout(timer); timer = null; q('play').textContent = reduced ? 'Следующий отсчёт' : probe === maxProbe() ? 'Повторить' : 'Воспроизвести'; }
    function selectStage(next) { stop(); stage = next; probe = 0; rebuild(); }
    function stageButtons() {
      var a = [
        [actualRef('J900', 'Разъём'), 'ETH_A_P / ETH_A_N'],
        [actualRef('T900', 'Трансформатор'), 'MDI_A_P / MDI_A_N'],
        [actualRef('U902', 'PHY'), 'Выход RGMII'],
        [actualRef('U500', 'ПЛИС'), 'Приём байта по DDR']
      ];
      q('stages').replaceChildren(); q('stages').hidden = mode !== 'ethernet';
      a.forEach(function (item, i) { var b = node('button', { type: 'button', 'aria-pressed': String(stage === i) }); b.appendChild(node('strong', {}, item[0])); b.appendChild(node('span', {}, item[1])); b.addEventListener('click', function () { selectStage(i); }); q('stages').appendChild(b); });
    }
    function rebuild() {
      q('mode').value = mode; stageButtons();q('net').disabled=mode==='ethernet';q('net').title=mode==='ethernet'?'Цепи схемы определяются выбранной точкой наблюдения Ethernet.':'Выберите цепь схемы, подключения которой хотите посмотреть.';
      q('kindfield').hidden = mode === 'ethernet' || mode === 'power';
      q('kind').replaceChildren();
      (mode === 'analog' ? [['voltage', 'Напряжение'], ['current', 'Ток']] : [['logic', 'Логическое состояние'], ['clock', 'Тактирование']]).forEach(function (x) { q('kind').appendChild(node('option', { value: x[0] }, x[1])); });
      if (mode === 'analog' && ['voltage', 'current'].indexOf(kind) < 0) kind = options.mode === 'current' ? 'current' : 'voltage';
      if (mode === 'digital' && ['logic', 'clock'].indexOf(kind) < 0) kind = /CLK|CLOCK|HSE|OSC|SCK|RXC|TXC/i.test(nameOf(selected)) ? 'clock' : 'logic';
      q('kind').value = kind;
      var headings = ['Напряжения пары на разъёме', 'Напряжения пары после трансформатора', 'Передача принятых данных из PHY в ПЛИС', 'Восстановление байта в ПЛИС'];
      var refs = [actualRef('J900', 'Разъём'), actualRef('T900', 'Трансформатор') + ' → ' + actualRef('U902', 'PHY'), actualRef('U902', 'PHY') + ' → ' + actualRef('U500', 'ПЛИС'), actualRef('U500', 'ПЛИС')];
      q('heading').textContent = mode === 'ethernet' ? headings[stage] : mode === 'power' ? 'Условная последовательность включения' : mode === 'analog' ? 'Условная осциллограмма: ' + (kind === 'current' ? 'ток' : 'напряжение') : kind === 'clock' ? 'Тактирование как логический сигнал' : 'Логические состояния цифрового сигнала';
      q('location').textContent = mode === 'ethernet' ? refs[stage] + (stage < 2 ? ' · показана одна пара' : ' · условный пример RGMII 1 Гбит/с') : nameOf(selected) || 'Выберите цепь, чтобы увидеть подключения выводов';
      q('tracebadge').textContent = mode === 'power' || mode === 'analog' ? 'Нормировано · без физических единиц' : mode === 'ethernet' && stage < 2 ? 'Напряжения пары · без синфазной составляющей' : 'Идеальная логика · без временного масштаба';
      q('bytes').replaceChildren(); q('bytes').hidden = !(mode === 'ethernet' && stage >= 2);
      PAYLOAD.forEach(function (b, i) { var e = node('button', { type: 'button', class: 'msig-byte', 'aria-pressed': String(Math.floor(probe / 2) === i), 'aria-label': 'Посмотреть байт ' + hex(b) + ', буква ' + String.fromCharCode(b) }); e.innerHTML = '<span>0x' + hex(b) + '</span><span>' + String.fromCharCode(b) + '</span>'; e.addEventListener('click', function () { stop(); probe = i * 2; draw(); }); q('bytes').appendChild(e); });
      var text = '';
      if (mode === 'ethernet') text = stage < 2 ? 'Условно показаны нормированные напряжения двух проводников одной пары Ethernet без синфазной составляющей. Осциллограмма со стороны PHY относится к соответствующей обмотке трансформатора, а не к напряжению между его изолированными сторонами. Эта кривая не кодирует байты примера MIRA. Остальные пары, одновременная передача, эквализация и подавление эха не показаны.' : stage === 2 ? 'В этом условном примере приёма RGMII 1 Гбит/с по RXD[3:0] передаётся младшая тетрада по каждому положительному фронту RXC и старшая — по отрицательному. RX_CTL остаётся в единице на всём показанном фрагменте корректных данных без ошибок. Курсор стоит на фронте выборки; реальные сдвиги тактового сигнала относительно данных и требования setup/hold не показаны.' : 'По положительному фронту принимается младшая тетрада, по следующему отрицательному — старшая. Вместе они дают 4D 49 52 41 → MIRA. Эти четыре байта — пример фрагмента полезных данных; преамбула Ethernet, заголовки, FCS и обработка MAC не показаны.';
      else if (mode === 'power') text = 'Общая учебная последовательность: сигнал разрешения модели переходит в единицу, нормированное напряжение растёт до целевого значения, после установления появляется готовность. EN и PG здесь — условные обозначения модели. Это не дополнительные имена цепей платы и не проверенная последовательность запуска выбранной схемы.';
      else if (mode === 'analog') text = 'Нормированный пример ' + (kind === 'current' ? 'тока' : 'напряжения') + ' показывает работу курсора и считывания отсчётов. Амплитуда, форма и ось времени условны. Пример не задаёт реальную реакцию компонентов или рабочее значение выбранной цепи.';
      else text = kind === 'clock' ? 'Идеальный тактовый сигнал чередует низкий и высокий логические уровни. Частота, коэффициент заполнения, напряжения и работа генератора не моделируются. В реальной схеме цепь генератора может нести аналоговый сигнал.' : 'Пример последовательности низких и высоких логических уровней. При выборе цепи показываются её точные подключения. Битовая последовательность не измерена на этой цепи и не выводится из работы прошивки.';
      q('explanation').textContent = text + (reduced ? ' Включено уменьшение анимации: используйте следующий отсчёт или кнопки перемещения курсора.' : '');
      q('probe').max = maxProbe(); q('legend').replaceChildren();
      var legend = mode === 'ethernet' && stage < 2 ? [['blue', 'Проводник P'], ['orange', 'Проводник N']] : mode === 'power' ? [['blue', 'Напряжение / цель'], ['orange', 'EN модели'], ['green', 'PG модели']] : [];
      legend.forEach(function (x) { var l = node('span'); l.innerHTML = '<i class="msig-swatch ' + (x[0] === 'blue' ? '' : x[0]) + '"></i>' + esc(x[1]); q('legend').appendChild(l); });
      sources(); draw(); stop();
    }

    function se(tag, attrs, text) { var e = document.createElementNS(NS, tag); Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); }); if (text != null) e.textContent = text; svg.appendChild(e); return e; }
    function tx(x, y, t, attrs) { return se('text', Object.assign({ x: x, y: y }, attrs || {}), t); }
    function ln(x1, y1, x2, y2, attrs) { return se('line', Object.assign({ x1:x1, y1:y1, x2:x2, y2:y2, stroke:'var(--border,#334357)' }, attrs || {})); }
    function path(d, color, attrs) { return se('path', Object.assign({ d:d, fill:'none', stroke:color || 'var(--sig-blue)', 'stroke-width':2, 'stroke-linejoin':'round' }, attrs || {})); }
    function stepPath(vals, left, top, width, height) { var d = 'M' + left + ',' + (top + (vals[0] ? 0 : height)); vals.forEach(function (v, i) { if (i) d += ' H' + (left + i * width / vals.length) + ' V' + (top + (v ? 0 : height)); d += ' H' + (left + (i + 1) * width / vals.length); }); return d; }
    function cursor(x, top, bottom) { ln(x, top, x, bottom, { stroke:'var(--text,#e8eef8)', 'stroke-dasharray':'3 4', 'stroke-width':1.2 }); se('circle', { cx:x, cy:top, r:3.5, fill:'var(--sig-blue)' }); }
    function analogAt(i) { return ANALOG[Math.round(i / 32 * (ANALOG.length - 1))]; }
    function voltageAt(i) { if (i < 6) return 0; return Math.min(1, (1 - Math.exp(-(i - 6) / 3.8))); }
    function digitalValues() { return Array.from({ length: 32 }, function (_, i) { return kind === 'clock' ? (i % 4 >= 2 ? 1 : 0) : [0,0,0,0,1,1,1,1,1,1,0,0,0,0,1,1,0,0,1,1,1,1,1,1,0,0,0,0,0,1,1,0][i]; }); }
    function draw() {
      if (destroyed) return;
      var w = Math.max(280, Math.round(svg.getBoundingClientRect().width || root.getBoundingClientRect().width || 650));
      var h = mode === 'ethernet' && stage === 2 ? 306 : mode === 'ethernet' && stage === 3 ? 300 : mode === 'power' ? 350 : 286;
      svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h); svg.style.minHeight = h + 'px'; svg.replaceChildren();
      se('title', {}, q('heading').textContent + '. Условные осциллограммы, не измерение.');
      var left = mode === 'ethernet' && stage === 2 ? Math.min(118, w * .35) : 45, right = w - 17, pw = right - left;
      if (mode === 'ethernet' && stage < 2 || mode === 'analog') {
        var mid = 135, amp = 77;
        [-1,0,1].forEach(function (v) { ln(left,mid-v*amp,right,mid-v*amp); tx(left-8,mid-v*amp+4,String(v), { 'text-anchor':'end', class:'sig-axis' }); });
        tx(13,135,'нормировано',{ transform:'rotate(-90 13 135)', 'text-anchor':'middle', class:'sig-axis' });
        var signs = mode === 'ethernet' ? [1,-1] : [1];
        signs.forEach(function (s) { var d = ANALOG.map(function (v, i) { return (i ? 'L' : 'M') + (left + i * pw / (ANALOG.length-1)) + ',' + (mid - s*v*amp); }).join(' '); path(d,s===1?'var(--sig-blue)':'var(--sig-orange)',s===-1?{'stroke-dasharray':'5 3'}:{}); });
        var xp = left + probe / 32 * pw; cursor(xp,35,239); se('circle', { cx:xp,cy:mid-analogAt(probe)*amp,r:4,fill:'var(--sig-blue)' });
        ln(left,250,right,250); tx((left+right)/2,272,'Условный интервал времени',{ 'text-anchor':'middle', class:'sig-axis' });
      } else if (mode === 'ethernet' && stage === 2) {
        var row = 36, base = 26;
        var lanes = [[rxName('RXC'), null], [rxName('RX_CTL'), Array(8).fill(1)]].concat(Array.from({ length:4 }, function (_, i) { return [rxName('RXD'+i), NIBBLES.map(function (n) { return (n >> i) & 1; })]; }));
        lanes.forEach(function (lane, j) {
          var y=base+j*row,label=lane[0], short = label.length > 16 && w < 500 ? label.slice(0,14)+'…' : label;
          var labelNode=tx(left-9,y+13,short,{'text-anchor':'end'}); var title=document.createElementNS(NS,'title');title.textContent=label;labelNode.appendChild(title);
          ln(left,y+20,right,y+20);
          if(j===0){ var d='M'+left+','+(y+20); for(var k=0;k<8;k++){var x=left+(k+.5)*pw/8;d+=' H'+x+' V'+(y+(k%2?20:0));} d+=' H'+right;path(d,'var(--sig-orange)'); }
          else { path(stepPath(lane[1],left,y,pw,20)); if(w>360&&j>=2)lane[1].forEach(function(v,i){tx(left+(i+.5)*pw/8,y+13,String(v),{'text-anchor':'middle',fill:'var(--muted,#9fb0c5)'});}); }
        });
        for(var c=0;c<8;c++){var cx=left+(c+.5)*pw/8;tx(cx,263,c%2?'↓':'↑',{'text-anchor':'middle',fill:'var(--sig-orange)'});tx(cx,282,nib(NIBBLES[c]),{'text-anchor':'middle'});}
        cursor(left+(probe+.5)*pw/8,17,242); tx(left-9,282,'Тетрада (hex)',{'text-anchor':'end',class:'sig-axis'});
      } else if (mode === 'ethernet' && stage === 3) {
        var cols = 4, margin=13, gap=7, cw=(w-2*margin-gap*(cols-1))/cols;
        PAYLOAD.forEach(function(b,i){var x=margin+i*(cw+gap),active=Math.floor(probe/2)===i;se('rect',{x:x,y:24,width:cw,height:245,rx:9,fill:active?'color-mix(in srgb,var(--sig-blue) 12%,var(--panel,#172435))':'var(--bg,#0b1420)',stroke:active?'var(--sig-blue)':'var(--border,#334357)'});tx(x+cw/2,46,'Байт '+(i+1),{'text-anchor':'middle',class:'sig-axis'});tx(x+cw/2,76,'↑ мл.: '+nib(b&15),{'text-anchor':'middle'});tx(x+cw/2,111,'↓ ст.: '+nib(b>>4),{'text-anchor':'middle'});ln(x+8,127,x+cw-8,127);tx(x+cw/2,157,'0x'+hex(b),{'text-anchor':'middle','font-weight':700});tx(x+cw/2,195,String.fromCharCode(b),{'text-anchor':'middle','font-size':24,fill:'var(--sig-green)'});tx(x+cw/2,236,active?(probe%2?'собран':'принята мл.'):i<Math.floor(probe/2)?'собран':'ожидание',{'text-anchor':'middle',class:'sig-axis'});});
        tx(w/2,290,'байт = (ст. << 4) | мл.',{'text-anchor':'middle',class:'sig-axis'});
      } else if (mode === 'power') {
        var ptop=38,ph=144;
        [0,.5,1].forEach(function(v){ln(left,ptop+ph*(1-v),right,ptop+ph*(1-v));tx(left-8,ptop+ph*(1-v)+4,String(v),{'text-anchor':'end',class:'sig-axis'});});
        var vd=Array.from({length:129},function(_,i){return (i?'L':'M')+(left+i*pw/128)+','+(ptop+ph*(1-voltageAt(i/4)));}).join(' ');path(vd);
        [[221,6,'EN модели','var(--sig-orange)'],[269,21,'PG модели','var(--sig-green)']].forEach(function(r){tx(left,r[0]-11,r[2],{class:'sig-axis'});ln(left,r[0]+18,right,r[0]+18);path(stepPath(Array.from({length:32},function(_,i){return i>=r[1]?1:0;}),left,r[0],pw,18),r[3]);});
        cursor(left+probe/32*pw,27,300);tx((left+right)/2,326,'Пуск модели · время условно',{'text-anchor':'middle',class:'sig-axis'});
      } else {
        var vals=digitalValues();
        [0,1].forEach(function(v){var y=183-v*96;ln(left,y,right,y);tx(left-9,y+4,String(v),{'text-anchor':'end'});});
        path(stepPath(vals,left,87,pw,96));cursor(left+probe/32*pw,49,218);tx(left,38,'Логические уровни · условно',{class:'sig-axis'});ln(left,239,right,239);tx((left+right)/2,265,'Условный интервал времени',{'text-anchor':'middle',class:'sig-axis'});
      }
      readout();
    }
    function readout() {
      var text='';
      if(mode==='ethernet'&&stage<2) text='Курсор '+(probe+1)+'/33 · P = '+analogAt(probe).toFixed(2)+' · N = '+(-analogAt(probe)).toFixed(2)+' · нормированные напряжения проводников без синфазной составляющей.';
      else if(mode==='ethernet') { var bi=Math.floor(probe/2), edge=probe%2?'Отрицательный':'Положительный'; text=stage===2?edge+' фронт RXC · RXD[3:0] = '+NIBBLES[probe].toString(2).padStart(4,'0')+' · '+(probe%2?'старшая':'младшая')+' тетрада 0x'+nib(NIBBLES[probe]):edge+' фронт · байт '+(bi+1)+' · мл. = 0x'+nib(PAYLOAD[bi]&15)+' · ст. = 0x'+nib(PAYLOAD[bi]>>4)+(probe%2?' · принято 0x'+hex(PAYLOAD[bi])+' = “'+String.fromCharCode(PAYLOAD[bi])+'”':' · ожидание старшей тетрады'); }
      else if(mode==='power') text='Напряжение / цель = '+voltageAt(probe).toFixed(2)+' · EN модели = '+(probe>=6?'1':'0')+' · PG модели = '+(probe>=21?'1':'0')+' · '+(probe<6?'отключено':probe<21?'запуск / установление':'готово в этом учебном примере');
      else if(mode==='analog') text=(kind==='current'?'Ток':'Напряжение')+' в примере = '+analogAt(probe).toFixed(2)+' нормированных единиц · без вывода о реальных значениях в схеме.';
      else text=(nameOf(selected)||'Условная цифровая цепь')+' · логический уровень в примере '+digitalValues()[Math.min(31,probe)]+' · '+(kind==='clock'?'идеальное тактирование':'пример битовой последовательности');
      q('readout').textContent=text;q('probe').value=probe;q('position').textContent=(probe+1)+' / '+(maxProbe()+1);q('back').disabled=probe<=0;q('next').disabled=probe>=maxProbe();
      Array.from(q('bytes').children).forEach(function(b,i){b.setAttribute('aria-pressed',String(Math.floor(probe/2)===i));});
      if(timer==null)q('play').textContent=reduced?'Следующий отсчёт':probe===maxProbe()?'Повторить':'Воспроизвести';
    }
    function tick(){ if(destroyed)return; if(probe>=maxProbe()){stop();return;} probe++;draw();if(probe>=maxProbe())stop();else timer=global.setTimeout(tick,mode==='ethernet'&&stage>=2?650:180); }
    q('play').addEventListener('click',function(){if(timer!=null){stop();return;}if(reduced){probe=probe>=maxProbe()?0:probe+1;draw();return;}if(probe>=maxProbe())probe=0;q('play').textContent='Пауза';timer=global.setTimeout(tick,mode==='ethernet'&&stage>=2?650:180);draw();});
    q('probe').addEventListener('input',function(e){stop();probe=Number(e.target.value);draw();});
    q('back').addEventListener('click',function(){stop();probe=Math.max(0,probe-1);draw();});q('next').addEventListener('click',function(){stop();probe=Math.min(maxProbe(),probe+1);draw();});
    q('mode').addEventListener('change',function(e){stop();mode=normalizeMode(e.target.value);probe=0;stage=0;rebuild();});
    q('kind').addEventListener('change',function(e){stop();kind=e.target.value;probe=0;rebuild();});
    q('net').addEventListener('change',function(e){stop();selected=e.target.value===''?null:relevant[Number(e.target.value)];probe=0;if(mode==='digital')kind=/CLK|CLOCK|HSE|OSC|SCK|RXC|TXC/i.test(nameOf(selected))?'clock':'logic';rebuild();});
    if(global.ResizeObserver){resize=new ResizeObserver(function(){if(!destroyed)draw();});resize.observe(root);}else global.addEventListener('resize',draw);
    if(mode==='digital'&&/CLK|CLOCK|HSE|OSC|SCK|RXC|TXC/i.test(nameOf(selected)))kind='clock';
    rebuild();
    return { destroy:function(){if(destroyed)return;stop();destroyed=true;if(resize)resize.disconnect();else global.removeEventListener('resize',draw);root.remove();}, setNet:function(netId,requestedMode){if(destroyed)return;stop();selected=byId[netId]||byName[netId]||null;if(selected&&relevant.indexOf(selected)<0){relevant.push(selected);q('net').appendChild(node('option',{value:String(relevant.length-1)},nameOf(selected)));}q('net').value=selected?String(relevant.indexOf(selected)):'';if(requestedMode)mode=normalizeMode(requestedMode);if(mode==='digital')kind=/CLK|CLOCK|HSE|OSC|SCK|RXC|TXC/i.test(nameOf(selected))?'clock':'logic';probe=0;rebuild();}, getState:function(){return{mode:mode,stage:stage,probe:probe,netId:selected?idOf(selected):null,playing:timer!=null};} };
  }
  global.MiraSignals={ mount:mount };
})(window);
