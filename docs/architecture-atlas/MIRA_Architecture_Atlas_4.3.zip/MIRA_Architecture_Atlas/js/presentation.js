/* Guided explanation over the live atlas canvas. Narration advances only by hand. */
(()=>{
'use strict';
const T=window.MIRA_TOUR,B=window.MIRA_BRIEF_TOUR,O=window.MIRA_OVERVIEW_TOUR;if(!T||!window.MiraApp)return;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const saved=()=>{try{return JSON.parse(localStorage.getItem('mira-tour-position-v3')||'null');}catch{return null;}};
let active=false,engine=null,root=null,full=false,tourMode='overview',index=0,pending=null,request=0,signals=true,view='functional',originalHash='',steps=[],resizeObserver=null,committed=null;
const $=s=>root?.querySelector(s);
function general(){return tourMode==='overview'||tourMode==='brief';}
function tour(){return tourMode==='overview'&&O?O:tourMode==='brief'&&B?B:T;}
function routeSteps(){const selected=tour(),source=tourMode==='all'?selected.steps:selected.steps.filter(s=>s.kind!=='detail');return(selected.chapters||[]).flatMap(c=>source.filter(s=>s.chapterId===c.id));}
function setMode(mode){tourMode=['overview','brief','architecture','all'].includes(mode)?mode:'overview';if(tourMode==='overview'&&!O)tourMode=B?'brief':'architecture';if(tourMode==='brief'&&!B)tourMode='architecture';full=tourMode==='all';steps=routeSteps();document.body.classList.toggle('mp-brief',general());document.body.classList.toggle('mp-overview',tourMode==='overview');}
function padding(){const height=$('.mp-caption')?.getBoundingClientRect().height||Math.min(window.innerHeight*.42,380);return{top:window.innerWidth<760?194:168,bottom:height+40,left:window.innerWidth<760?20:44,right:window.innerWidth<760?20:44};}
function remember(){try{localStorage.setItem('mira-tour-position-v3',JSON.stringify({stepId:steps[index]?.id,full,mode:tourMode}));}catch{}}
function hash(){if(!active)return;const p=new URLSearchParams({step:steps[index]?.id||'',mode:tourMode});if(full)p.set('full','1');try{history.replaceState(null,'','#presentation?'+p);}catch{}}
function build(){
 root=document.createElement('section');root.id='mira-presentation';root.setAttribute('aria-label','Презентация MIRA');
 root.innerHTML=`<header class="mp-top"><label class="mp-format"><span>Формат</span><select aria-label="Формат презентации"><option value="overview">Обзор · 10–15 минут</option><option value="brief">Коротко · 4–6 минут</option><option value="architecture">Архитектура · 41 эпизод</option><option value="all">Подробно · все листы</option></select></label><label class="mp-chapters"><span>Глава</span><select aria-label="Глава презентации">${tour().chapters.map(c=>`<option value="${esc(c.id)}">${esc(c.title)}</option>`).join('')}</select></label><label class="mp-episodes"><span>Эпизод</span><select aria-label="Эпизод презентации"></select></label><span class="mp-count"></span><button class="mp-exit" type="button" data-mp="exit">Выйти из показа <span aria-hidden="true">×</span></button><span class="mp-status" role="status" aria-live="polite"></span></header><section class="mp-caption" aria-label="Пояснение к диаграмме"><div class="mp-copy"><div class="mp-eyebrow"></div><h1 class="mp-title" tabindex="-1"></h1><p class="mp-lead"></p><div class="mp-path" aria-label="Путь сигнала"></div><div class="mp-body"></div><p class="mp-why"></p></div><nav class="mp-controls" aria-label="Управление презентацией"><button class="mp-prev" type="button" data-mp="prev" aria-label="Предыдущий эпизод">← Назад</button><button class="mp-next" type="button" data-mp="next" aria-label="Следующий эпизод">Далее →</button><span class="mp-control-spacer"></span><button class="mp-signal" type="button" data-mp="signals" aria-pressed="true">Ⅱ Сигналы</button><button class="mp-schematic" type="button" data-mp="view" aria-pressed="false">Схемотехника</button><button class="mp-full" type="button" data-mp="fit">Показать целиком</button><button class="mp-full" type="button" data-mp="fullscreen" aria-label="Презентация на весь экран">⛶</button></nav></section>`;
 document.body.append(root);
 root.addEventListener('click',e=>{const part=e.target.closest('[data-component-help]');if(part){engine?.showComponentHelp?.(part.dataset.componentHelp);return;}const a=e.target.closest('[data-mp]')?.dataset.mp;if(!a)return;if(a==='exit')stop();else if(a==='prev')go((pending??index)-1);else if(a==='next')go((pending??index)+1);else if(a==='signals'){signals=!signals;engine?.setPresentationSignals(signals);updateSignalButton();}else if(a==='view')changeView();else if(a==='fit'){engine?.setPresentationViewportPadding?.(padding());engine?.fit();}else if(a==='fullscreen'){try{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen();}catch{}}});
 $('.mp-chapters select').addEventListener('change',e=>go(steps.findIndex(s=>s.chapterId===e.target.value)));
 $('.mp-episodes select').addEventListener('change',e=>go(steps.findIndex(s=>s.id===e.target.value)));
 $('.mp-format select').addEventListener('change',e=>{const current=steps[pending??index];setMode(e.target.value);let at=steps.findIndex(s=>s.id===current?.id);if(at<0)at=steps.findIndex(s=>s.sceneId===current?.sceneId);if(at<0)at=steps.findIndex(s=>s.chapterId===current?.chapterId);refreshChapters();go(Math.max(0,at));});
 resizeObserver=new ResizeObserver(()=>{if(active){document.body.style.setProperty('--mp-caption-height',$('.mp-caption').getBoundingClientRect().height+'px');engine?.setPresentationViewportPadding?.(padding());}});resizeObserver.observe($('.mp-caption'));
}
function updateSignalButton(){const button=$('.mp-signal');if(!button)return;button.setAttribute('aria-pressed',String(signals));button.textContent=signals?'Ⅱ Приостановить сигналы':'▶ Оживить сигналы';}
function caption(step){
 const chapter=tour().chapters.find(c=>c.id===step.chapterId),scene=window.MIRA_FUNCTIONAL.scenes[step.sceneId];
 $('.mp-eyebrow').textContent=tourMode==='overview'?'MIRA · '+(chapter?.title||'Обзор архитектуры'):tourMode==='brief'?'MIRA · Архитектура за 5 минут':(chapter?.title||'MIRA')+' · '+(scene?.title||'');
 $('.mp-title').textContent=step.title;$('.mp-lead').textContent=step.lead||'';
 const explain=p=>window.MiraComponentInfo?.format(p,scene?.board)||esc(p);$('.mp-body').innerHTML=(step.body||[]).map(p=>'<p>'+explain(p)+'</p>').join('');
 $('.mp-path').innerHTML=(step.path||[]).map((p,i)=>`<span>${i?'<i aria-hidden="true">→</i>':''}${esc(p)}</span>`).join('');
 $('.mp-why').textContent=step.why?'Зачем так: '+step.why:'';$('.mp-why').hidden=!step.why;$('.mp-copy').scrollTop=0;
 $('.mp-chapters select').value=step.chapterId;
 $('.mp-episodes select').innerHTML=steps.filter(s=>general()||s.chapterId===step.chapterId).map(s=>`<option value="${esc(s.id)}"${s.id===step.id?' selected':''}>${s.kind==='detail'?'↳ ':''}${esc(s.title)}</option>`).join('');
 $('.mp-format select').value=tourMode;$('.mp-count').textContent=(index+1)+' / '+steps.length;
 $('.mp-prev').disabled=index===0;$('.mp-next').disabled=index===steps.length-1;
 $('.mp-next').textContent=index===steps.length-1?'Рассказ завершён':'Далее →';
 const canCircuit=(scene?.nodes||[]).some(n=>n.refs?.length);$('.mp-schematic').disabled=!canCircuit;updateViewButton();updateSignalButton();
}
function refreshChapters(){if(!root)return;$('.mp-chapters select').innerHTML=tour().chapters.map(c=>`<option value="${esc(c.id)}">${esc(c.title)}</option>`).join('');$('.mp-format select').value=tourMode;}
function restoreCommitted(){if(!committed)return;setMode(committed.mode);index=Math.max(0,steps.findIndex(s=>s.id===committed.stepId));pending=null;view=engine?.getState().viewMode||committed.view;engine?.setPresentationAudience?.(general()?'general':'technical');refreshChapters();caption(steps[index]);}
function frame(step){return{audience:general()?'general':'technical',sceneId:step.sceneId,nodeIds:step.nodeIds||[],edgeIds:step.edgeIds||[],edgeDirections:step.edgeDirections||{},scenarioId:step.storyId,stepIndex:step.storyStep||0,circuitNodeId:step.circuitNodeId,viewMode:view,animateSignals:signals,viewportPadding:padding()};}
async function go(at){
 if(!active||!steps.length)return;at=Math.max(0,Math.min(steps.length-1,at));const token=++request;pending=at;view='functional';$('.mp-prev').disabled=at===0;$('.mp-next').disabled=at===steps.length-1;
 $('.mp-status').textContent=steps[at].sceneId!==engine.getState().sceneId?'Раскрываем диаграмму…':'Показываем путь сигнала…';$('.mp-caption').setAttribute('aria-busy','true');
 let statusMessage='';try{const result=await engine.presentFrame(frame(steps[at]));if(!active||token!==request)return;if(result?.completed===false){restoreCommitted();statusMessage='Переход остановлен. Можно осмотреть диаграмму или продолжить стрелками.';return;}engine.setPresentationSignals(signals);index=at;pending=null;committed={mode:tourMode,stepId:steps[index].id,view};caption(steps[index]);hash();remember();}
 catch(error){if(active&&token===request){restoreCommitted();statusMessage='Не удалось открыть эпизод. Выберите другую главу.';console.error(error);}}
 finally{if(active&&token===request){$('.mp-caption').removeAttribute('aria-busy');if(pending===null)$('.mp-status').textContent=statusMessage||'Шаги вручную · линии и блоки можно выбирать';}}
}
function updateViewButton(){const b=$('.mp-schematic');b.setAttribute('aria-pressed',String(view==='circuit'));b.textContent=view==='circuit'?'Функциональная диаграмма':'Схемотехника';}
async function changeView(){if(!active||pending!==null)return;view=engine.getState().viewMode==='circuit'?'functional':'circuit';const token=++request;const result=await engine.presentFrame(frame(steps[index]));if(active&&token===request&&result?.completed!==false){engine.setPresentationSignals(signals);updateViewButton();}}
function start(options={}){
 if(active){if(options.stepId){const at=steps.findIndex(s=>s.id===options.stepId);if(at>=0)go(at);}return;}
 originalHash=location.hash.startsWith('#presentation')?'#overview':location.hash||'#overview';
 engine=window.MiraApp.preparePresentation();if(!engine?.beginPresentation)return;
 active=true;const previous=options.fromHash?null:saved();setMode(options.mode||(options.full||options.stepId?.startsWith('detail-')?'all':options.stepId?.startsWith('main-')?'architecture':options.stepId?.startsWith('brief-')?'brief':(!options.stepId&&previous?.mode)||'overview'));
 if(previous&&!options.stepId&&!options.mode&&options.full===undefined)setMode(previous.mode||'overview');
 index=Math.max(0,steps.findIndex(s=>s.id===(options.stepId||previous?.stepId)));pending=null;signals=true;view='functional';
 document.body.classList.add('mira-presenting');build();caption(steps[index]);committed={mode:tourMode,stepId:steps[index].id,view};engine.beginPresentation({viewportPadding:padding()});go(index);
 $('.mp-exit').focus();
}
function stop({restore=true}={}){
 if(!active)return;++request;pending=null;resizeObserver?.disconnect();resizeObserver=null;root?.remove();root=null;document.body.classList.remove('mira-presenting','mp-brief','mp-overview');document.body.style.removeProperty('--mp-caption-height');engine?.endPresentation();active=false;
 if(restore){try{history.replaceState(null,'',originalHash);}catch{}if(!originalHash.startsWith('#overview'))window.dispatchEvent(new HashChangeEvent('hashchange'));document.querySelector('#presentation-toggle')?.focus();}
 engine=null;
}
function openScene(target){target=window.MIRA_FUNCTIONAL.sheetScenes?.[target]||target;let match=steps.find(s=>s.sceneId===target)||T.steps.find(s=>s.sceneId===target&&s.kind!=='detail')||T.steps.find(s=>s.sceneId===target);if(!match)return false;if(!steps.some(s=>s.id===match.id)){setMode(match.kind==='detail'?'all':'architecture');refreshChapters();}go(steps.findIndex(s=>s.id===match.id));return true;}
document.addEventListener('click',e=>{if(!active)return;const link=e.target.closest('.mf [data-scene]');if(link&&openScene(link.dataset.scene)){e.preventDefault();e.stopPropagation();}},true);
document.addEventListener('dblclick',e=>{if(!active)return;const node=e.target.closest('.mf [data-node]');if(!node)return;const current=window.MIRA_FUNCTIONAL.scenes[engine.getState().sceneId],target=current?.nodes.find(n=>n.id===node.dataset.node);if((target?.sceneId||target?.detailSceneId)&&openScene(target.sceneId||target.detailSceneId)){e.preventDefault();e.stopPropagation();}},true);
document.addEventListener('click',e=>{if(active&&e.target.closest('[data-circuit-node],[data-circuit-edge],[data-circuit-net],[data-component]'))Promise.resolve().then(()=>{if(active){view=engine.getState().viewMode;updateViewButton();}});});
document.querySelector('#presentation-toggle')?.addEventListener('click',()=>start());
document.addEventListener('keydown',e=>{if(!active||e.defaultPrevented||/^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName))return;if(e.key==='Escape'){e.preventDefault();e.stopPropagation();stop();}else if(e.key==='ArrowRight'||e.key==='PageDown'){e.preventDefault();e.stopPropagation();go((pending??index)+1);}else if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();e.stopPropagation();go((pending??index)-1);}else if(e.key===' '&&!/^(BUTTON|A|SUMMARY)$/.test(e.target.tagName)){e.preventDefault();e.stopPropagation();signals=!signals;engine?.setPresentationSignals(signals);updateSignalButton();}},true);
window.MiraPresentation={start,stop,next:()=>go((pending??index)+1),previous:()=>go((pending??index)-1),goTo:id=>{const at=steps.findIndex(s=>s.id===id);if(at>=0)return go(at);},isActive:()=>active,beforeCanvasDestroy:()=>stop({restore:false}),getState:()=>({active,stepId:steps[index]?.id,pendingStepId:pending===null?null:steps[pending]?.id,index,total:steps.length,full,mode:tourMode,signals,view})};
if(location.hash.startsWith('#presentation')){const p=new URLSearchParams(location.hash.split('?')[1]||'');start({fromHash:true,stepId:p.get('step'),full:p.get('full')==='1',mode:p.get('mode')});}
})();
