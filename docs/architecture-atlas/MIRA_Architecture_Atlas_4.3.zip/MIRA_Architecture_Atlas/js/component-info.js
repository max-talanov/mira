/* Human descriptions retain the exact component and board identity from KiCad. */
(()=>{
'use strict';
const A=window.MIRA_ATLAS||{},H=window.MIRA_COMPONENT_HELP||{},C=A.components||{};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function get(value,board){
 let c=typeof value==='object'?value:C[value]||C[board+'_'+value];
 if(!c&&typeof value==='string'){const matches=Object.values(C).filter(c=>c.ref===value&&!c.virtual&&(!board||c.board===board));if(matches.length===1)c=matches[0];}
 if(!c)return null;
 const id=c.id||Object.keys(C).find(id=>C[id]===c),ref=c.ref||id,help=H.components?.[id]||{},prefix=String(ref).match(/^[A-Z]+/)?.[0],generic=H.genericTypes?.[prefix]||{};
 return{id,ref,value:c.value||'',board:c.board||board,name:help.name||generic.name||'Компонент схемы',purpose:help.purpose||generic.purpose||'Назначение этого компонента уточняется в описании функционального узла.'};
}
function format(text,board){
 const source=String(text||''),re=/\b(?:FB|SW|JP|U|Q|J|T|Y|K|L|D|R|C|F)\d+[A-Z]?\b/g;let html='',at=0;
 for(const match of source.matchAll(re)){html+=esc(source.slice(at,match.index));const info=get(match[0],board);if(info){html+=`<button type="button" class="mp-component-mention" data-component-help="${esc(info.id)}" title="${esc(info.purpose)}">${esc(info.ref)}<span> (${esc(info.name)})</span></button>`;}else html+=esc(match[0]);at=match.index+match[0].length;}
 return html+esc(source.slice(at));
}
window.MiraComponentInfo={get,format};
})();
