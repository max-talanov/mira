/* MIRA functional canvas. No dependencies; works directly from file://. */
(()=>{
'use strict';
const NS='http://www.w3.org/2000/svg';
const palette={power:'var(--orange,#df9b47)',data:'var(--blue,#528cff)',control:'var(--purple,#a486ed)',analog:'var(--green,#35b99a)',fault:'var(--red,#e86f78)',external:'var(--blue,#528cff)',matrix:'var(--green,#35b99a)'};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Math.random().toString(36).slice(2,9);
const safeGet=k=>{try{return JSON.parse(localStorage.getItem(k)||'null');}catch{return null;}};
const safeSet=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch{}};
const typeName={power:'Питание',data:'Данные',control:'Управление',analog:'Аналоговый сигнал',fault:'Защита'};
function svg(tag,attrs={},text){const e=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))if(v!==undefined&&v!==null)e.setAttribute(k,String(v));if(text!==undefined)e.textContent=text;return e;}
function words(text,max=23,maxLines=2){const parts=String(text||'').split(/\s+/),lines=[];let line='';for(const p of parts){if(line&&line.length+p.length+1>max){lines.push(line);line=p;}else line+=(line?' ':'')+p;}if(line)lines.push(line);if(lines.length>maxLines){lines.length=maxLines;lines[maxLines-1]=lines[maxLines-1].replace(/\s+\S*$/,'')+'…';}return lines;}
function identifierLines(text,max){let rest=String(text||''),lines=[];while(rest.length>max){let cut=rest.lastIndexOf('_',max-1)+1;if(cut<max/2)cut=max;lines.push(rest.slice(0,cut));rest=rest.slice(cut);}if(rest)lines.push(rest);return lines;}
function multiline(g,text,x,y,cls,max,maxLines,lineHeight){const t=svg('text',{x,y,class:cls});words(text,max,maxLines).forEach((line,i)=>t.append(svg('tspan',{x,dy:i?lineHeight:0},line)));g.append(t);return t;}
function cleanPoints(p){return p.filter((v,i)=>!i||v.x!==p[i-1].x||v.y!==p[i-1].y).filter((v,i,a)=>!i||i===a.length-1||!((a[i-1].x===v.x&&v.x===a[i+1].x)||(a[i-1].y===v.y&&v.y===a[i+1].y)));}
function pathData(points){const p=cleanPoints(points);if(p.length<2)return'';let s=`M ${p[0].x} ${p[0].y}`;for(let i=1;i<p.length;i++){const a=p[i-1],b=p[i],c=p[i+1];if(!c){s+=` L ${b.x} ${b.y}`;continue;}const r=Math.min(14,Math.hypot(b.x-a.x,b.y-a.y)/2,Math.hypot(c.x-b.x,c.y-b.y)/2),l1=Math.hypot(b.x-a.x,b.y-a.y)||1,l2=Math.hypot(c.x-b.x,c.y-b.y)||1;s+=` L ${b.x-(b.x-a.x)/l1*r} ${b.y-(b.y-a.y)/l1*r} Q ${b.x} ${b.y} ${b.x+(c.x-b.x)/l2*r} ${b.y+(c.y-b.y)/l2*r}`;}return s;}
function midpoint(points){const p=cleanPoints(points),segments=p.slice(1).map((v,i)=>({a:p[i],b:v,len:Math.hypot(v.x-p[i].x,v.y-p[i].y)}));const candidates=segments.filter(s=>s.len>80).sort((a,b)=>b.len-a.len);const m=candidates[0]||segments[Math.floor(segments.length/2)];return m?{x:(m.a.x+m.b.x)/2,y:(m.a.y+m.b.y)/2}:{x:0,y:0};}
function placeLabel(points,w,h,blocks,used){
 const overlap=(a,b)=>Math.max(0,Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x))*Math.max(0,Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y)),p=cleanPoints(points),options=[];
 for(let i=1;i<p.length;i++){
  const a=p[i-1],b=p[i],len=Math.hypot(b.x-a.x,b.y-a.y);if(len<30)continue;
  const horizontal=a.y===b.y,offset=horizontal?h/2+12:w/2+12,center=horizontal?(p[0].x+p.at(-1).x)/2:(p[0].y+p.at(-1).y)/2,projection=(center-(horizontal?a.x:a.y))/((horizontal?b.x-a.x:b.y-a.y)||1),fractions=[.5,.25,.75,.1,.9];if(projection>0&&projection<1)fractions.push(projection);
  for(const t of fractions)for(const shift of [0,offset,-offset,offset*2,-offset*2,offset*3,-offset*3,offset*4,-offset*4]){
   const anchor={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};
   options.push({x:anchor.x+(horizontal?0:shift),y:anchor.y+(horizontal?shift:0),anchor:shift?anchor:null,priority:Math.abs(t-.5)*12+1/len+Math.abs(shift)*.12});
  }
 }
 let best=midpoint(points),cost=Infinity;
 for(const c of options){
  const r={x:c.x-w/2,y:c.y-h/2,w,h};
  let v=c.priority+blocks.reduce((n,b)=>n+overlap(r,{x:b.x-6,y:b.y-6,w:b.w+12,h:b.h+12})*20,0)+used.reduce((n,b)=>n+overlap(r,{x:b.x-5,y:b.y-5,w:b.w+10,h:b.h+10})*30,0);
  if(c.anchor)for(const b of blocks)if(intersects(c.anchor,c,{x:b.x-4,y:b.y-4,w:b.w+8,h:b.h+8}))v+=100000;
  if(v<cost){best=c;cost=v;}
 }
 used.push({x:best.x-w/2,y:best.y-h/2,w,h});return best;
}
function intersects(a,b,r){if(a.x===b.x)return a.x>r.x&&a.x<r.x+r.w&&Math.max(a.y,b.y)>r.y&&Math.min(a.y,b.y)<r.y+r.h;return a.y>r.y&&a.y<r.y+r.h&&Math.max(a.x,b.x)>r.x&&Math.min(a.x,b.x)<r.x+r.w;}
// A distant connection keeps its original electrical edge and two labelled ends.
// Only its drawing is split; selection, narration and terminal inspection stay shared.
function portalGeometry(a,b,e,nodes,used,w=186,h=58){
const overlap=(u,v)=>Math.max(0,Math.min(u.x+u.w,v.x+v.w)-Math.max(u.x,v.x))*Math.max(0,Math.min(u.y+u.h,v.y+v.h)-Math.max(u.y,v.y));
const ends=[];
for(const[n,other,hint]of[[a,b,e.fromSide],[b,a,e.toSide]]){
 let best=null,cost=Infinity;
 for(const side of ['right','left','bottom','top'])for(const t of [.5,.25,.75])for(const gap of [28,64,106]){
  const p={x:side==='left'?n.x:side==='right'?n.x+n.w:n.x+n.w*t,y:side==='top'?n.y:side==='bottom'?n.y+n.h:n.y+n.h*t};
  const r={x:side==='right'?p.x+gap:side==='left'?p.x-gap-w:p.x-w/2,y:side==='bottom'?p.y+gap:side==='top'?p.y-gap-h:p.y-h/2,w,h};
  const q={x:side==='left'?r.x+w:side==='right'?r.x:r.x+w/2,y:side==='top'?r.y+h:side==='bottom'?r.y:r.y+h/2};
  let score=gap+Math.abs(t-.5)*50+(hint&&hint!==side?35:0);
  for(const block of nodes){score+=overlap(r,{x:block.x-12,y:block.y-12,w:block.w+24,h:block.h+24})*60;if(block!==n&&intersects(p,q,{x:block.x-8,y:block.y-8,w:block.w+16,h:block.h+16}))score+=100000;}
  for(const block of [...used,...ends.map(end=>end.box)])score+=overlap(r,{x:block.x-8,y:block.y-8,w:block.w+16,h:block.h+16})*80;
  if(score<cost){cost=score;best={point:p,join:q,box:r,side,node:n,other};}
 }
 ends.push(best);
}
const segments=[[ends[0].point,ends[0].join],[ends[1].join,ends[1].point]];
return{ends,segments,points:segments.flat(),d:segments.map(pathData).join(' ')};
}
function routeEdge(a,b,e,nodes,index){const ac={x:a.x+a.w/2,y:a.y+a.h/2},bc={x:b.x+b.w/2,y:b.y+b.h/2},dx=bc.x-ac.x,dy=bc.y-ac.y;
let as=e.fromSide||e.sourceSide,bs=e.toSide||e.targetSide;if(!as)as=Math.abs(dx)>Math.abs(dy)*1.2?(dx>0?'right':'left'):(dy>0?'bottom':'top');if(!bs)bs=({right:'left',left:'right',top:'bottom',bottom:'top'})[as];
const off=e.portOffset||0,point=(n,side)=>({left:{x:n.x,y:n.y+Math.min(n.h-22,Math.max(22,n.h/2+off))},right:{x:n.x+n.w,y:n.y+Math.min(n.h-22,Math.max(22,n.h/2+off))},top:{x:n.x+Math.min(n.w-22,Math.max(22,n.w/2+off)),y:n.y},bottom:{x:n.x+Math.min(n.w-22,Math.max(22,n.w/2+off)),y:n.y+n.h}}[side]||{x:n.x+n.w,y:n.y+n.h/2});
const normal={left:{x:-1,y:0},right:{x:1,y:0},top:{x:0,y:-1},bottom:{x:0,y:1}},p=point(a,as),q=point(b,bs),stub=22,u={x:p.x+normal[as].x*stub,y:p.y+normal[as].y*stub},v={x:q.x+normal[bs].x*stub,y:q.y+normal[bs].y*stub};
if(Array.isArray(e.waypoints)&&e.waypoints.length)return cleanPoints([p,...e.waypoints.map(p=>Array.isArray(p)?{x:p[0],y:p[1]}:p),q]);
const obstacles=nodes.map(n=>({x:n.x-11,y:n.y-11,w:n.w+22,h:n.h+22,id:n.id})),middleX=(u.x+v.x)/2,middleY=(u.y+v.y)/2,lanesX=[middleX,...obstacles.flatMap(r=>[r.x-16,r.x+r.w+16])],lanesY=[middleY,...obstacles.flatMap(r=>[r.y-16,r.y+r.h+16])];
const candidates=[[u,{x:v.x,y:u.y},v],[u,{x:u.x,y:v.y},v],...lanesX.map(x=>[u,{x,y:u.y},{x,y:v.y},v]),...lanesY.map(y=>[u,{x:u.x,y},{x:v.x,y},v])];
let best=candidates[0],score=Infinity;for(const c of candidates){const cp=cleanPoints(c);let cost=cp.length*12;for(let i=1;i<cp.length;i++){cost+=Math.abs(cp[i].x-cp[i-1].x)+Math.abs(cp[i].y-cp[i-1].y);for(const r of obstacles)if(intersects(cp[i-1],cp[i],r))cost+=100000;}if(cost<score){score=cost;best=cp;}}
return cleanPoints([p,...best,q]);}
const iconPaths={power:'M-6-9 L-10 1 H-2 L-5 10 L7-3 H0 L4-9 Z',data:'M-10-5 H9 M4-10 L9-5 L4 0 M10 6 H-9 M-4 1 L-9 6 L-4 11',control:'M-9-9 H9 V9 H-9 Z M-4-3 H4 V3 H-4 Z',analog:'M-11 1 Q-5-14 0 0 T11-1',fault:'M0-11 L11 9 H-11 Z M0-3 V3 M0 6 V7',matrix:'M-9-9 V9 M0-9 V9 M9-9 V9 M-9-9 H9 M-9 0 H9 M-9 9 H9',external:'M-11-8 H11 V6 H-11 Z M0 6 V11 M-6 11 H6'};
function mount(container,opts={}){
const A=opts.atlas||window.MIRA_ATLAS||{},C=opts.content||window.MIRA_CONTENT||{},maps=opts.maps||window.MIRA_FUNCTIONAL||{scenes:{},scenarios:[]},id=uid(),cameraStore='mira-functional-camera-v3',stored=safeGet(cameraStore)||{},cameras={...stored},cameraLayouts=safeGet('mira-functional-camera-layout-v1')||{};
let sceneId='',scene=null,nodes=[],edgeViews=[],nodeViews=new Map(),selection=null,scenario=null,stepIndex=0,playing=false,frame=null,lastTime=0,stepTime=0,signalTime=0,destroyed=false,resizeObserver=null,drag=null,suppressClick=false,hasSized=false,size={w:1200,h:700},cam={x:0,y:0,scale:1},reduced=!!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const storyMemory=safeGet('mira-functional-stories-v3')||{};
let viewMode='functional',circuit=null,circuitNode=null,origin=null;
let presentationActive=false,presentationSnapshot=null,presentationFrame=null,presentationAudience='technical',tourPadding=null,motionToken=0,motionRaf=null,motionResolve=null,navigationActive=false,transitionPath=[],transitionOrigin='',transitionDestination='';
const transitionGhosts=new Set();
container.classList.add('mira-functional-host');container.innerHTML=`<section class="mf" aria-label="Интерактивная функциональная диаграмма"><div class="mf-stage"><svg class="mf-svg" tabindex="0" role="application" aria-label="Перетаскивайте диаграмму, меняйте масштаб колёсиком. Выберите блок для пояснений."><defs><pattern id="mf-dots-${id}" width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" class="mf-dot"/></pattern></defs><rect width="100%" height="100%" fill="url(#mf-dots-${id})" class="mf-grid"/><g class="mf-world"><g class="mf-scene-backdrop"></g><g class="mf-edges"></g><g class="mf-nodes"></g><g class="mf-labels"></g><g class="mf-particles" aria-hidden="true"></g></g></svg><div class="mf-top"><div class="mf-location"><div class="mf-crumbs"></div><h2 class="mf-title"></h2><p class="mf-subtitle"></p></div><div class="mf-view-switch" role="group" aria-label="Способ отображения"><button type="button" data-mode="functional" aria-pressed="true">Диаграмма</button><button type="button" data-mode="circuit" aria-pressed="false">Схемотехника</button></div><div class="mf-tools" role="toolbar" aria-label="Вид диаграммы"><button type="button" data-act="out" title="Уменьшить" aria-label="Уменьшить">−</button><output class="mf-zoom">100%</output><button type="button" data-act="in" title="Увеличить" aria-label="Увеличить">+</button><button type="button" data-act="fit" title="Показать целиком">Вписать</button><button type="button" data-act="full" title="Полный экран" aria-label="Полный экран">⛶</button></div></div><div class="mf-circuit-host" hidden></div><aside class="mf-detail" hidden aria-live="polite"></aside><div class="mf-bottom"><div class="mf-story"></div><div class="mf-hint"><span>Перетаскивайте · масштабируйте колёсиком · выбирайте блоки</span><span class="mf-educational">Учебная иллюстрация сигналов</span></div></div><div class="mf-legend" aria-label="Типы соединений">${['power','data','control','analog','fault'].map(t=>`<span><i style="background:${palette[t]}"></i>${typeName[t]}</span>`).join('')}</div></div></section>`;
const root=container.querySelector('.mf'),stage=container.querySelector('.mf-stage'),svgEl=container.querySelector('.mf-svg'),world=container.querySelector('.mf-world'),edgesEl=container.querySelector('.mf-edges'),nodesEl=container.querySelector('.mf-nodes'),labelsEl=container.querySelector('.mf-labels'),particlesEl=container.querySelector('.mf-particles'),backdrop=container.querySelector('.mf-scene-backdrop'),detail=container.querySelector('.mf-detail'),story=container.querySelector('.mf-story');
const listen=[];const on=(el,event,fn,settings)=>{el.addEventListener(event,fn,settings);listen.push(()=>el.removeEventListener(event,fn,settings));};
function dimensions(){const r=stage.getBoundingClientRect();return{w:r.width||container.clientWidth||1200,h:r.height||container.clientHeight||700};}
function layoutSignature(id){return(maps.scenes[id]?.nodes||[]).map(n=>[n.id,n.x,n.y,n.w,n.h].join(':')).join('|');}
function saveCamera(){if(!sceneId||presentationActive||navigationActive)return;cameras[sceneId]={...cam};cameraLayouts[sceneId]=layoutSignature(sceneId);safeSet(cameraStore,cameras);safeSet('mira-functional-camera-layout-v1',cameraLayouts);}
function applyCamera(save=true){world.setAttribute('transform',`translate(${cam.x} ${cam.y}) scale(${cam.scale})`);container.querySelector('.mf-zoom').textContent=Math.round(cam.scale*100)+'%';if(save)saveCamera();}
function bounds(){if(scene?.bounds&&(!nodes.length||scene.fitBoundsStrict)){const b=scene.bounds;return Array.isArray(b)?{x:b[0],y:b[1],w:b[2],h:b[3]}:{x:b.x||0,y:b.y||0,w:b.w||b.width||1200,h:b.h||b.height||700};}if(!nodes.length)return{x:0,y:0,w:1000,h:600};const boxes=[...nodes,...(scene?.regions||[]),...edgeViews.map(v=>v.labelBounds),...edgeViews.flatMap(v=>v.portalBounds||[]),...edgeViews.flatMap(v=>v.points.map(p=>({x:p.x-8,y:p.y-8,w:16,h:16})))].filter(Boolean),x=Math.min(...boxes.map(n=>n.x)),y=Math.min(...boxes.map(n=>n.y));return{x,y,w:Math.max(...boxes.map(n=>n.x+n.w))-x,h:Math.max(...boxes.map(n=>n.y+n.h))-y};}
function fit(initial=false){size=dimensions();if(presentationActive){if(viewMode==='circuit'){circuit?.fit?.();return;}cam=cameraFor(bounds());applyCamera(false);return;}const b=bounds(),p=opts.viewportPadding||{},left=p.left??(size.w<600?24:65),right=p.right??left,top=p.top??(size.w<600?145:135),bottom=p.bottom??(size.w<600?170:150),s=Math.max(.15,Math.min((size.w-left-right)/Math.max(b.w,1),(size.h-top-bottom)/Math.max(b.h,1),1.3));cam={scale:s,x:left+(size.w-left-right-b.w*s)/2-b.x*s,y:top+(size.h-top-bottom-b.h*s)/2-b.y*s};applyCamera();}
function zoom(factor,point){size=dimensions();const p=point||{x:size.w/2,y:size.h/2},next=Math.min(3,Math.max(.15,cam.scale*factor)),ratio=next/cam.scale;cam={scale:next,x:p.x-(p.x-cam.x)*ratio,y:p.y-(p.y-cam.y)*ratio};applyCamera();}
function refsFor(n){return(n.refs||[]).map(ref=>A.components?.[ref]||Object.values(A.components||{}).find(c=>c.ref===ref&&(!scene?.board||c.board===scene.board))||{ref,id:ref}).filter(Boolean);}
function generalAudience(){return presentationActive&&presentationAudience==='general';}
function nodeTitle(n){
 if(!generalAudience())return n.title;
 if(sceneId==='system'&&n.id==='links')return'Связь с компьютером';
 const names={FPGA:'Быстрое управление',MCU:'Контроллер эксперимента',DAC:'Аналоговые источники',ADC:'Измерение отклика',MATRIX:'Мемристорная матрица',POWER_SYSTEM:'Питание и защита'};
 return names[n.title]||n.explanationTitleRu||(n.sourceSheetName?n.subtitle:'')||n.title;
}
function edgeTitle(e){
 if(!generalAudience())return e.shortLabel||e.label||'';
 const label=[e.shortLabel,e.label].find(label=>/[А-Яа-яЁё]/.test(label||'')&&!/^\d+\s+цеп/.test(label));
 return label||({power:'Питание',data:'Сигнал',control:'Команды управления',analog:'Аналоговый сигнал',fault:'Сигнал защиты'}[e.type])||'Соединение';
}
function componentInfo(value){
 const c=typeof value==='object'?value:A.components?.[value]||Object.values(A.components||{}).find(c=>c.ref===value&&(!scene?.board||c.board===scene.board));
 const info=window.MiraComponentInfo?.get?.(c||value,scene?.board);if(info)return info;
 if(!c)return null;
 const prefix=String(c.ref||'').match(/^[A-Z]+/)?.[0],names={U:'Микросхема',Q:'Транзистор',J:'Разъём',T:'Трансформатор',Y:'Источник тактирования',R:'Резистор',C:'Конденсатор',L:'Индуктивность',D:'Диод',F:'Предохранитель',FB:'Фильтр питания'};
 return{id:c.id||c.ref,ref:c.ref||c.id,value:c.value||'',name:names[prefix]||'Компонент схемы',purpose:'Назначение показано в описании функционального узла.'};
}
function componentHelpButton(info){return`<button type="button" class="mf-component-help" data-component-help="${esc(info.id)}"><span class="mf-component-name">${esc(info.name)}</span><span class="mf-component-ref">${esc(info.ref)}${info.value?' · '+esc(info.value):''}</span><span class="mf-component-purpose">${esc(info.purpose)}</span></button>`;}
function netFor(value){return A.nets?.[value]||Object.values(A.nets||{}).find(n=>n.name===value&&(!scene?.board||n.board===scene.board))||{id:value,name:value,pins:[]};}
function getNavigationPath(target=sceneId){const result=[],seen=new Set();let current=target;while(current&&maps.scenes[current]&&!seen.has(current)){seen.add(current);const s=maps.scenes[current];result.unshift({id:current,title:s.title||current,subtitle:s.subtitle||'',current:current===target});current=parentOf(current);}return result;}
function crumbHtml(target=sceneId){return getNavigationPath(target).map((s,i)=>`${i?'<span class="mf-crumb-arrow" aria-hidden="true">›</span>':''}${s.current?`<span class="mf-crumb-current" aria-current="page" title="${esc(s.subtitle||s.title)}">${esc(s.title)}</span>`:`<button type="button" data-scene="${esc(s.id)}" title="${esc(s.subtitle||s.title)}"><span>${esc(s.title)}</span></button>`}`).join('');}
function updateWayfinding(){let bar=container.querySelector('.mf-wayfinding');if(!bar){bar=document.createElement('nav');bar.className='mf-wayfinding';bar.setAttribute('aria-label','Путь к текущей диаграмме');stage.append(bar);}const moving=transitionPath.length>0,target=moving?transitionDestination:sceneId,s=maps.scenes[target],from=maps.scenes[transitionOrigin];bar.classList.toggle('mf-wayfinding-moving',moving);bar.innerHTML=`<div class="mf-wayfinding-label">${moving?'Переход между диаграммами':'Вы здесь'}${moving?'<span class="mf-wayfinding-progress" aria-hidden="true"></span>':''}</div><div class="mf-wayfinding-path">${crumbHtml(target)}</div><div class="mf-wayfinding-context" role="status">${moving?`${esc(from?.title||'MIRA')} <span aria-hidden="true">→</span> ${esc(s?.title||target)}`:esc(s?.subtitle||'Общая архитектура устройства')}</div>${!moving&&s&&!(s.edges||[]).length?'<p class="mf-no-connections-note">Здесь показаны группы модулей. Откройте модуль, чтобы увидеть соединения и движение сигналов.</p>':''}`;const path=bar.querySelector('.mf-wayfinding-path');if(path)path.scrollLeft=Math.max(0,(path.scrollWidth||0)-(path.clientWidth||0));}
function updateHeader(){container.querySelector('.mf-title').textContent=scene?.title||'MIRA';container.querySelector('.mf-title').classList.toggle('mf-source-title',!!scene?.sourceSheetName);container.querySelector('.mf-subtitle').textContent=scene?.subtitle||'Выбирайте функциональные узлы и прослеживайте соединения.';container.querySelector('.mf-crumbs').innerHTML=crumbHtml();updateWayfinding();let chooser=container.querySelector('.mf-scene-picker');if(!chooser){chooser=document.createElement('label');chooser.className='mf-scene-picker';chooser.innerHTML='<span class="sr-only">Выбрать функциональную диаграмму</span><select data-scene-picker aria-label="Выбрать функциональную диаграмму"></select>';container.querySelector('.mf-location').append(chooser);}const main=Object.values(maps.scenes||{}).filter(s=>['system','power','control'].includes(s.id)),leaves=Object.values(maps.scenes||{}).filter(s=>!s.hidden&&!['system','power','control'].includes(s.id));chooser.querySelector('select').innerHTML=`<optgroup label="Общая структура">${main.map(s=>`<option value="${esc(s.id)}"${s.id===sceneId?' selected':''}>${esc(s.title)}</option>`).join('')}</optgroup>${['power','control'].map(board=>`<optgroup label="${board==='power'?'Модули питания':'Модули управления'}">${leaves.filter(s=>s.board===board).map(s=>`<option value="${esc(s.id)}"${s.id===sceneId?' selected':''}>${esc(s.title)}</option>`).join('')}</optgroup>`).join('')}`;}
function sourceButton(sheetId,netId,label='Схемотехника выбранного узла'){return sheetId?`<button type="button" class="mf-link" data-source="${esc(sheetId)}" data-net="${esc(netId||'')}">${label} <span>↗</span></button>`:'';}
function edgeDetail(e){
const ns=(e.nets||[]).map(netFor),unknown=e.scope==='logical'||e.scope==='functional'||e.logical||!ns.length;
detail.hidden=false;detail.innerHTML=`<button type="button" class="mf-detail-close" data-act="close" aria-label="Закрыть пояснение">×</button><div class="mf-eyebrow" style="color:${palette[e.type]||palette.data}">${esc(typeName[e.type]||'Соединение')}</div><h3>${esc(e.label||'Соединение')}</h3><p>${esc(e.description||`${nodes.find(n=>n.id===e.from)?.title||e.from} → ${nodes.find(n=>n.id===e.to)?.title||e.to}.`)}</p>${e.portal?`<p class="mf-portal-explanation">Переход ${esc(e.portal.code)} соединяет две одинаковые метки на диаграмме: ${esc(nodes.find(n=>n.id===e.from)?.title||e.from)} ↔ ${esc(nodes.find(n=>n.id===e.to)?.title||e.to)}.</p>`:''}${unknown?'<div class="mf-logical">Функциональная связь. Физические соединения указаны в схемотехнике узла.</div>':''}${ns.length?`<div class="mf-exact"><strong class="mf-exact-heading">Цепи из KiCad · ${ns.length}</strong><div class="mf-net-chips">${ns.map(n=>`<button type="button" data-net-detail="${esc(n.id)}" title="Показать точные выводы">${esc(n.name)}</button>`).join('')}</div></div>`:''}<button type="button" class="mf-link" data-circuit-edge="${esc(e.id)}">Показать УГО и выводы этого соединения <span>↗</span></button>`;
}
function nodeDetail(n){
const refs=refsFor(n),mod=C.modules?.[n.sheetId||scene?.sheetId],purpose=n.description||n.purpose||mod?.purpose||n.subtitle||'';
const parts=refs.map(componentInfo).filter(Boolean),notable=parts.filter(c=>/^[UQJTY]\d/.test(c.ref)).slice(0,4);
detail.hidden=false;detail.innerHTML=`<button type="button" class="mf-detail-close" data-act="close" aria-label="Закрыть пояснение">×</button><div class="mf-eyebrow" style="color:${palette[n.role]||palette.control}">Функциональный узел</div><h3>${esc(nodeTitle(n))}</h3>${nodeTitle(n)!==n.title?`<div class="mf-component-ref">Лист KiCad: ${esc(n.title)}</div>`:''}<p>${esc(purpose)}</p>${notable.length?`<div class="mf-component-explanations">${notable.map(componentHelpButton).join('')}</div>`:''}${parts.length?`<details class="mf-exact"><summary>Все компоненты KiCad · ${parts.length}</summary><div class="mf-net-chips">${parts.map(c=>`<button type="button" data-component-help="${esc(c.id)}" title="${esc(c.purpose)}">${esc(c.name)} <span class="mf-component-ref">· ${esc(c.ref)}</span></button>`).join('')}</div></details>`:''}<div class="mf-detail-actions">${(n.sceneId||n.detailSceneId)&&(n.sceneId||n.detailSceneId)!==sceneId?`<button type="button" class="mf-primary" data-scene="${esc(n.sceneId||n.detailSceneId)}">Открыть модуль и его историю <span>→</span></button>`:''}${refs.length?`<button type="button" class="mf-link" data-circuit-node="${esc(n.id)}">УГО и соединения этого узла <span>↗</span></button>`:''}</div>`;
}
function showComponentHelp(id){
 const info=componentInfo(id);if(!info)return false;
 const group=nodes.find(n=>(n.refs||[]).includes(info.id));
 detail.hidden=false;detail.innerHTML=`<button type="button" class="mf-detail-close" data-act="close" aria-label="Закрыть пояснение">×</button><div class="mf-eyebrow">Компонент схемы</div><h3>${esc(info.name)}</h3><div class="mf-component-ref">${esc(info.ref)}${info.value?' · '+esc(info.value):''}</div><p>${esc(info.purpose)}</p>${group?`<p>Входит в узел «${esc(nodeTitle(group))}».</p>`:''}<div class="mf-detail-actions"><button type="button" class="mf-primary" data-component="${esc(info.id)}">Показать УГО и выводы <span>↗</span></button>${group?`<button type="button" class="mf-link" data-node="${esc(group.id)}">Вернуться к описанию узла <span>↩</span></button>`:''}</div>`;return true;
}
function showNet(id){
const n=netFor(id),pins=n.pins||[];
detail.innerHTML=`<button type="button" class="mf-detail-close" data-act="close" aria-label="Закрыть пояснение">×</button><div class="mf-eyebrow">Цепь из KiCad</div><h3 class="mf-net-title">${esc(n.name)}</h3><p>Подключённые выводы: ${pins.length}.</p><div class="mf-terminal-list">${pins.map(p=>{const c=A.components?.[p.component||p.componentId],ref=p.ref||c?.ref||p.component||'?';return`<div><strong>${esc(ref)}.${esc(p.pin||p.number||p.pinNumber||'?')}</strong><span>${esc(p.name||p.pinName||'')}</span></div>`;}).join('')}</div><button type="button" class="mf-link" data-circuit-net="${esc(n.id)}">Показать на УГО <span>↗</span></button>`;detail.hidden=false;
}
function selectNode(id){const n=nodes.find(n=>n.id===id);if(!n)return;selection={type:'node',id};nodeDetail(n);updateHighlights();}
function selectEdge(id){const e=(scene?.edges||[]).find(e=>e.id===id);if(!e)return;selection={type:'edge',id};edgeDetail(e);updateHighlights();}
function selectNet(id){let edge=(scene?.edges||[]).find(e=>(e.nets||[]).some(value=>value===id||netFor(value).name===id));if(!edge){const target=Object.values(maps.scenes||{}).find(s=>s.sheetId&&(s.edges||[]).some(e=>(e.nets||[]).some(value=>value===id||netFor(value).name===id)));if(target){setScene(target.id);edge=(scene?.edges||[]).find(e=>(e.nets||[]).some(value=>value===id||netFor(value).name===id));}}if(edge)selectEdge(edge.id);else showNet(id);}
function clearDetail(){selection=null;detail.hidden=true;updateHighlights();}
function currentStep(){const actual=scenario?.steps?.[stepIndex]||null;return presentationActive&&presentationFrame?{...(actual||{}),nodes:presentationFrame.nodeIds??actual?.nodes??[],edges:presentationFrame.edgeIds??actual?.edges??[]}:actual;}
function activeEdges(){const active=new Set(currentStep()?.edges||[]);if(selection?.type==='edge')active.add(selection.id);if(selection?.type==='node')for(const e of scene?.edges||[])if(e.from===selection.id||e.to===selection.id)active.add(e.id);return active;}
function energizedEdges(){const set=new Set();if(scenario)for(let i=0;i<=stepIndex;i++)for(const edgeId of scenario.steps[i]?.edges||[]){const e=(scene?.edges||[]).find(e=>e.id===edgeId);if(e?.type==='power')set.add(edgeId);}return set;}
function updateHighlights(){const active=activeEdges(),step=currentStep(),energy=energizedEdges(),activeNodes=new Set(step?.nodes||[]);if(selection?.type==='node')activeNodes.add(selection.id);for(const view of edgeViews){const sel=active.has(view.edge.id),isEnergy=energy.has(view.edge.id);view.active=sel;view.energized=isEnergy;view.g.classList.toggle('mf-edge-active',sel);view.g.classList.toggle('mf-edge-energized',isEnergy);view.g.classList.toggle('mf-edge-muted',!!(step||selection)&&!sel&&!isEnergy);view.label?.classList.toggle('mf-label-active',sel);view.particles.forEach(p=>p.style.display=sel?'':'none');}
for(const[id,v]of nodeViews){const relevant=activeNodes.has(id)||[...active].some(eid=>{const e=(scene?.edges||[]).find(e=>e.id===eid);return e&&(e.from===id||e.to===id);});v.classList.toggle('mf-node-active',relevant);v.classList.toggle('mf-node-selected',selection?.type==='node'&&selection.id===id);v.classList.toggle('mf-node-muted',!!(step||selection)&&!relevant);}
root.classList.toggle('mf-has-selection',!!selection||!!step);root.classList.toggle('mf-is-playing',playing);updateCircuitLayout();syncCircuitSelection();}
function scenarioList(){return(maps.scenarios||[]).filter(s=>s.sceneId===sceneId||!s.sceneId);}
function rememberStory(){if(!sceneId||presentationActive||navigationActive)return;storyMemory[sceneId]=scenario?{id:scenario.id,stepIndex}:null;safeSet('mira-functional-stories-v3',storyMemory);}
function updateCircuitLayout(){const host=container.querySelector('.mf-circuit-host');if(!host)return;if(presentationActive){host.style.top=(tourPadding?.top??96)+'px';host.style.bottom=(tourPadding?.bottom??300)+'px';return;}host.style.top='';const h=container.querySelector('.mf-bottom').getBoundingClientRect().height;host.style.bottom=Math.min(260,Math.max(100,h+10))+'px';}
function updateStory(){rememberStory();const available=scenarioList(),step=currentStep();if(!scenario){story.classList.remove('mf-story-active');story.innerHTML=`<div class="mf-story-prompt"><span class="mf-play-symbol" aria-hidden="true">▷</span><div><strong>Как работает этот узел</strong><span>Выберите историю: что приходит на вход, что меняется и куда идёт результат.</span></div><label class="mf-story-picker"><span class="sr-only">Выбрать историю</span><select data-story><option value="">Выбрать историю…</option>${available.map(s=>`<option value="${esc(s.id)}">${esc(s.title)}</option>`).join('')}</select></label></div>`;if(!available.length){story.innerHTML='<div class="mf-story-prompt"><span class="mf-play-symbol" aria-hidden="true">↗</span><div><strong>Проследить соединение</strong><span>Выберите линию, чтобы увидеть её назначение и точные имена цепей.</span></div></div>';}return;}
story.classList.add('mf-story-active');story.innerHTML=`<div class="mf-story-head"><label class="mf-story-picker"><span class="sr-only">Текущая история</span><select data-story>${available.map(s=>`<option value="${esc(s.id)}"${scenario.id===s.id?' selected':''}>${esc(s.title)}</option>`).join('')}${!available.some(s=>s.id===scenario.id)?`<option value="${esc(scenario.id)}" selected>${esc(scenario.title)}</option>`:''}</select></label><span class="mf-story-mode">Шаги переключаются вручную</span><span class="mf-story-count">${stepIndex+1} / ${scenario.steps?.length||1}</span><button type="button" data-act="story-close" class="mf-story-close" aria-label="Закрыть историю">×</button></div><div class="mf-story-main"><div class="mf-story-text"><h3>${esc(step?.title||scenario.title)}</h3><p>${esc(step?.body||step?.text||step?.description||'Следите за подсвеченными соединениями.')}</p></div><div class="mf-playback" role="toolbar" aria-label="Управление историей"><button type="button" data-act="prev" aria-label="Предыдущий шаг"${stepIndex===0?' disabled':''}>←</button><button type="button" data-act="play" class="mf-play-button"${!(scene?.edges||[]).length?' disabled':''} aria-label="${playing?'Приостановить сигналы':'Оживить сигналы'}" title="${playing?'Приостановить сигналы':'Оживить сигналы'} - текущий шаг останется на экране" aria-pressed="${playing}">${playing?'Ⅱ':'▶'}</button><button type="button" data-act="next" aria-label="Следующий шаг"${stepIndex===(scenario.steps?.length||1)-1?' disabled':''}>→</button></div></div><div class="mf-progress">${(scenario.steps||[]).map((s,i)=>`<button type="button" data-step="${i}" class="${i===stepIndex?'current':i<stepIndex?'done':''}" title="${esc(s.title)}" aria-label="Шаг ${i+1}: ${esc(s.title)}"${i===stepIndex?' aria-current="step"':''}></button>`).join('')}</div>`;}
function setScenario(id,{keepScene=false,stepIndex:requestedStep=0}={}){const next=(maps.scenarios||[]).find(s=>s.id===id);playing=false;stepTime=0;if(!next){scenario=null;stepIndex=0;updateStory();updateHighlights();return;}if(next.sceneId&&next.sceneId!==sceneId&&!keepScene)setScene(next.sceneId,{keepScenario:true});scenario=next;stepIndex=Math.max(0,Math.min(next.steps.length-1,Number(requestedStep)||0));selection=null;detail.hidden=true;updateStory();updateHighlights();}
function play(){if(!(scene?.edges||[]).length)return;if(!scenario){const first=scenarioList()[0];if(first)setScenario(first.id);else return;}playing=true;lastTime=0;updateStory();updateHighlights();}
function pause(){playing=false;updateStory();updateHighlights();}
function step(dir){if(!scenario){const first=scenarioList()[0];if(first)setScenario(first.id);else return;}stepIndex=Math.min((scenario.steps?.length||1)-1,Math.max(0,stepIndex+(dir<0?-1:1)));stepTime=0;updateStory();updateHighlights();}
function seek(index){if(!scenario)return;stepIndex=Math.min((scenario.steps?.length||1)-1,Math.max(0,Number(index)||0));stepTime=0;updateStory();updateHighlights();}
function draw(){const placedLabels=[];edgesEl.replaceChildren();nodesEl.replaceChildren();labelsEl.replaceChildren();particlesEl.replaceChildren();backdrop.replaceChildren();edgeViews=[];nodeViews.clear();
for(const region of scene?.regions||[]){const g=svg('g',{class:'mf-region mf-region-'+(region.kind||'primary')});g.append(svg('rect',{x:region.x,y:region.y,width:region.w,height:region.h,rx:24}),svg('text',{x:region.x+22,y:region.y+29,class:'mf-region-title'},region.title||''));if(region.subtitle)g.append(svg('text',{x:region.x+22,y:region.y+49,class:'mf-region-subtitle'},region.subtitle));backdrop.append(g);}
for(const[eindex,e]of(scene?.edges||[]).entries()){
 const a=nodes.find(n=>n.id===e.from),b=nodes.find(n=>n.id===e.to);if(!a||!b)continue;
 const peers=(scene.edges||[]).filter(peer=>peer.from===e.from&&peer.to===e.to||peer.from===e.to&&peer.to===e.from),portOffset=(peers.findIndex(peer=>peer.id===e.id)-(peers.length-1)/2)*28,color=palette[e.type]||palette.data;
 const portal=e.portal?portalGeometry(a,b,e,nodes,placedLabels):null,p=portal?.points||routeEdge(a,b,{...e,portOffset},nodes,eindex),d=portal?.d||pathData(p),g=svg('g',{class:'mf-edge'+(portal?' mf-edge-portal':''),style:`--flow-color:${color}`,'data-edge':e.id});
 const connectionName=`${edgeTitle(e)||e.type||'Соединение'}: ${nodeTitle(a)} ${e.undirected||e.direction==='none'?'связан с':e.bidirectional?'↔':'→'} ${nodeTitle(b)}${portal?'. Переход '+e.portal.code:''}`;
 const path=svg('path',{d,class:'mf-edge-line',fill:'none'}),hit=svg('path',{d,class:'mf-edge-hit',fill:'none',tabindex:0,role:'button','aria-label':connectionName}),flow=svg('path',{d,class:'mf-edge-flow',fill:'none'});g.append(path,flow,hit);
 const last=p.at(-1),prior=p.at(-2),angle=Math.atan2(last.y-prior.y,last.x-prior.x)*180/Math.PI;
 if(!e.undirected&&e.direction!=='none')g.append(svg('path',{d:'M -8 -4 L 0 0 L -8 4',transform:`translate(${last.x} ${last.y}) rotate(${angle})`,class:'mf-edge-arrow',fill:'none'}));
 if(e.bidirectional&&!e.undirected&&e.direction!=='none'){const first=p[0],next=p[1],ang=Math.atan2(first.y-next.y,first.x-next.x)*180/Math.PI;g.append(svg('path',{d:'M -8 -4 L 0 0 L -8 4',transform:`translate(${first.x} ${first.y}) rotate(${ang})`,class:'mf-edge-arrow',fill:'none'}));}edgesEl.append(g);
 let label,labelBounds=null;
 if(portal){
  label=svg('g',{class:'mf-edge-portal',style:`--flow-color:${color}`,'data-edge':e.id});
  for(const end of portal.ends){
   const r=end.box,badge=svg('g',{class:'mf-portal-label mf-portal-badge',transform:`translate(${r.x} ${r.y})`,tabindex:0,role:'button','aria-label':connectionName,'data-edge':e.id});
   const names=(e.netLabels||[]),heading=generalAudience()?edgeTitle(e):e.portal.title||names[0]||e.shortLabel||e.label||'',fullLines=generalAudience()?words(heading,20,2):identifierLines(heading,20),lines=fullLines.slice(0,2).map((line,i)=>i===1&&fullLines.length>2?line.slice(0,19)+'…':line),remote=generalAudience()?nodeTitle(end.other):end.other.subtitle||end.other.title;
   badge.append(svg('title',{},`Переход ${e.portal.code}: ${a.title} ↔ ${b.title}\n${names.join(' · ')||e.label}\nНажмите, чтобы увидеть все цепи и выводы.`),svg('rect',{x:0,y:0,width:r.w,height:r.h,rx:10}),svg('text',{x:10,y:16,class:'mf-portal-code'},e.portal.code+' · '+(e.undirected||e.bidirectional?'↔':end===portal.ends[0]?'→':'←')));
   lines.forEach((line,i)=>badge.append(svg('text',{x:45,y:16+i*13,class:'mf-portal-title'},line)));
   badge.append(svg('text',{x:10,y:r.h-10,class:'mf-portal-destination'},words(remote,25,1)[0]));
   label.append(badge);placedLabels.push({...r});
  }
  labelsEl.append(label);
 }else{
  const labelLines=(generalAudience()?words(edgeTitle(e),24,2):(scene.sheetId||scene.kind==='module')&&e.labelLines?.length?e.labelLines:(scene.kind==='section'?words(e.shortLabel||e.label||'',14,3):[e.shortLabel||e.label||''])).filter(Boolean),lw=Math.max(34,...labelLines.map(t=>String(t).length*7.4+24)),lh=Math.max(24,labelLines.length*17+10),m=placeLabel(p,lw,lh,nodes,placedLabels);
  label=svg('g',{class:'mf-edge-label',transform:`translate(${m.x} ${m.y})`,style:`--flow-color:${color}`,'data-edge':e.id});
  if(labelLines.length){if(m.anchor)label.append(svg('path',{d:`M ${m.anchor.x-m.x} ${m.anchor.y-m.y} L 0 0`,class:'mf-label-leader',fill:'none'}));label.append(svg('title',{},(e.netLabels?.length?e.netLabels:e.labelLines?.length?e.labelLines:[e.label||'']).join(' · ')),svg('rect',{x:-lw/2,y:-lh/2,width:lw,height:lh,rx:7}));labelLines.forEach((line,i)=>label.append(svg('text',{'text-anchor':'middle',y:-((labelLines.length-1)*17)/2+4+i*17,class:!generalAudience()&&e.netLabels?.length?'mf-exact-label':''},line)));labelsEl.append(label);labelBounds={x:m.x-lw/2,y:m.y-lh/2,w:lw,h:lh};}
 }
 const particles=[0,.34,.67].map(()=>{const c=svg('circle',{r:e.type==='power'?4:3.8,class:'mf-particle',fill:color,style:'display:none'});particlesEl.append(c);return c;});
 let length=0;try{length=path.getTotalLength();}catch{}if(!length)for(const segment of portal?.segments||[p])for(let i=1;i<segment.length;i++)length+=Math.hypot(segment[i].x-segment[i-1].x,segment[i].y-segment[i-1].y);
 const signalGroup=svg('g',{class:'mf-inline-signal',style:`--flow-color:${color};display:none`}),signalBox=svg('rect',{x:-30,y:-12,width:60,height:24,rx:6}),signalText=svg('text',{'text-anchor':'middle',y:3.5}),signalWave=svg('path',{fill:'none',class:'mf-inline-wave'}),clock=/CLK|CLOCK|RXC|TXC|RGMII/i.test([e.label,...(e.nets||[]).map(n=>netFor(n).name)].join(' '));signalGroup.append(signalBox,signalText,signalWave);particlesEl.append(signalGroup);
 edgeViews.push({edge:e,g,path,flow,points:p,segments:portal?.segments,length,label,particles,signalGroup,signalText,signalWave,clock,labelBounds,portalBounds:portal?.ends.map(end=>end.box)||[],active:false});
}
for(const n of nodes){
const title=nodeTitle(n),subtitle=generalAudience()&&title===n.subtitle?'':n.subtitle||'',g=svg('g',{class:'mf-node mf-role-'+(n.layoutRole||'primary'),transform:`translate(${n.x} ${n.y})`,style:`--node-color:${palette[n.role]||palette.control}`,tabindex:0,role:'button','aria-label':`${title}. ${subtitle}${n.sceneId?' Открыть пояснение.':''}`,'data-node':n.id}),refNames=refsFor(n).map(r=>r.ref),coded=!generalAudience()&&!!n.sourceSheetName&&n.title.length>18;
g.append(svg('title',{},n.title+(n.subtitle?' — '+n.subtitle:'')),svg('rect',{width:n.w,height:n.h,rx:16,class:'mf-node-shadow'}),svg('rect',{width:n.w,height:n.h,rx:16,class:'mf-node-card'}),svg('rect',{x:0,y:20,width:4,height:n.h-40,rx:2,class:'mf-node-stripe'}));
if(coded){
 let fontSize=n.layoutRole==='support'?15:17,lines=identifierLines(n.title,Math.floor((n.w-34)/(fontSize*.61)));
 while(fontSize>12&&26+(lines.length-1)*(fontSize+4)+20+32>n.h-28){fontSize-=.5;lines=identifierLines(n.title,Math.floor((n.w-34)/(fontSize*.61)));}
 const lineHeight=fontSize+4,t=svg('text',{x:17,y:26,class:'mf-node-sheet-title',style:`font-size:${fontSize}px`});
 lines.forEach((line,i)=>t.append(svg('tspan',{x:17,dy:i?lineHeight:0},line)));g.append(t);
 const subtitleY=Math.max(66,26+(lines.length-1)*lineHeight+20),subtitleLines=Math.max(0,Math.min(2,Math.floor((n.h-30-subtitleY)/16)+1));
 if(subtitleLines)multiline(g,n.subtitle||'',17,subtitleY,'mf-node-subtitle',Math.floor((n.w-34)/6.9),subtitleLines,16);
}else{
 const compact=n.layoutRole==='support',titleFont=compact?18:21,titleLineHeight=compact?22:24,titleWidth=Math.floor((n.w-65)/(titleFont*.54)),titleLines=words(title,titleWidth,3),subtitleY=26+(titleLines.length-1)*titleLineHeight+22,subtitleLines=Math.max(0,Math.min(2,Math.floor((n.h-30-subtitleY)/17)+1));
 g.append(svg('circle',{cx:29,cy:29,r:15,class:'mf-node-icon-bg'}),svg('path',{d:iconPaths[n.role]||iconPaths.control,transform:'translate(29 29) scale(.75)',class:'mf-node-icon',fill:n.role==='power'?'currentColor':'none'}));
 multiline(g,title,54,26,'mf-node-title',titleWidth,3,titleLineHeight).setAttribute('style',`font-size:${titleFont}px`);
 if(subtitleLines)multiline(g,subtitle,17,subtitleY,'mf-node-subtitle',Math.floor((n.w-34)/6.9),subtitleLines,17);
}
if(refNames.length&&!generalAudience()){let count=Math.min(4,refNames.length);while(count>1&&(refNames.slice(0,count).join(' · ')+(refNames.length>count?` +${refNames.length-count}`:'')).length*7.1>n.w-40)count--;const ref=refNames.slice(0,count).join(' · ')+(refNames.length>count?` +${refNames.length-count}`:'');g.append(svg('text',{x:17,y:n.h-14,class:'mf-node-refs'},ref));}
if(n.sceneId&&n.sceneId!==sceneId)g.append(svg('text',{x:n.w-21,y:n.h-14,class:'mf-node-drill','text-anchor':'middle'},'↗'));nodesEl.append(g);nodeViews.set(n.id,g);
}
}
function setScene(nextId,{preserveCamera=false,keepScenario=false,transitioning=false}={}){
if(!transitioning&&navigationActive)cancelPresentationTransition();
nextId=maps.sheetScenes?.[nextId]||nextId;
if(!maps.scenes?.[nextId])nextId=maps.scenes?.system?'system':Object.keys(maps.scenes||{})[0];
if(!nextId){sceneId='';scene=null;container.querySelector('.mf-title').textContent='Диаграмма недоступна';return;}
saveCamera();rememberStory();const same=nextId===sceneId,from=sceneId,fromScenario=scenario;
if(!same&&from&&fromScenario)origin={sceneId:from,title:fromScenario.title};
closeCircuit();sceneId=nextId;scene=maps.scenes[nextId];
if(cameras[nextId]&&cameraLayouts[nextId]!==layoutSignature(nextId))delete cameras[nextId];
nodes=(scene.nodes||[]).map((n,i)=>({w:220,h:128,x:(i%4)*330,y:Math.floor(i/4)*230,...n}));selection=null;detail.hidden=true;
if(!keepScenario){scenario=null;playing=false;stepIndex=0;const saved=storyMemory[nextId];if(saved){const found=(maps.scenarios||[]).find(s=>s.id===saved.id&&s.sceneId===nextId);if(found){scenario=found;stepIndex=Math.max(0,Math.min(found.steps.length-1,saved.stepIndex||0));}}else if(fromScenario&&!same){scenario=(maps.scenarios||[]).find(s=>s.sceneId===nextId)||null;}}
updateHeader();draw();updateStory();updateHighlights();
if(cameras[nextId]){cam={...cameras[nextId]};applyCamera(false);}else if(preserveCamera&&same)applyCamera();else fit(true);if(!transitioning)opts.onSceneChange?.(nextId);
}
// Guided presentation uses this exact canvas and preserves the independent explore view.
function getState(){return{sceneId,selection:selection?{...selection}:null,scenarioId:scenario?.id||'',stepIndex,playing,viewMode,followStory:false,circuitNodeId:circuitNode?.id||null,circuitViewport:circuit?.getViewport?.()||null,camera:{...cam},presentationActive,navigationPath:getNavigationPath(),transitionPath:[...transitionPath],transitioning:root.classList.contains('mf-transitioning')};}
function focusBounds(nodeIds=[],edgeIds=[]){
 const selected=new Set(nodeIds||[]);for(const edge of scene?.edges||[])if((edgeIds||[]).includes(edge.id)){selected.add(edge.from);selected.add(edge.to);}
 const boxes=nodes.filter(n=>selected.has(n.id));
 if(!boxes.length)return bounds();
 for(const view of edgeViews)if((edgeIds||[]).includes(view.edge.id)){if(view.labelBounds)boxes.push(view.labelBounds);boxes.push(...(view.portalBounds||[]));for(const p of view.points)boxes.push({x:p.x-8,y:p.y-8,w:16,h:16});}
 const x=Math.min(...boxes.map(n=>n.x))-28,y=Math.min(...boxes.map(n=>n.y))-28;
 return{x,y,w:Math.max(...boxes.map(n=>n.x+n.w))-x+28,h:Math.max(...boxes.map(n=>n.y+n.h))-y+28};
}
function cameraFor(box,padding=tourPadding||opts.viewportPadding||{},maxScale=1.35){
 const d=dimensions(),left=padding.left??48,right=padding.right??48,top=padding.top??96,bottom=padding.bottom??300,w=Math.max(100,d.w-left-right),h=Math.max(110,d.h-top-bottom),scale=Math.max(.12,Math.min(w/Math.max(1,box.w),h/Math.max(1,box.h),maxScale));
 return{x:left+(w-box.w*scale)/2-box.x*scale,y:top+(h-box.h*scale)/2-box.y*scale,scale};
}
function mixCamera(a,b,t){const scale=Math.exp(Math.log(a.scale)+(Math.log(b.scale)-Math.log(a.scale))*t);return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,scale};}
function clearTransitionVisuals(){for(const ghost of transitionGhosts)ghost.remove();transitionGhosts.clear();world.style.opacity='';svgEl.style.opacity='';const host=container.querySelector('.mf-circuit-host');if(host)host.style.opacity='';root.classList.remove('mf-transitioning');root.querySelectorAll('.mf-node-opening').forEach(n=>n.classList.remove('mf-node-opening'));transitionPath=[];transitionOrigin='';transitionDestination='';updateWayfinding();}
function cancelPresentationTransition(){const exploring=navigationActive;navigationActive=false;motionToken++;if(motionRaf!==null)cancelAnimationFrame(motionRaf);motionRaf=null;if(motionResolve){const resolve=motionResolve;motionResolve=null;resolve(false);}clearTransitionVisuals();if(exploring){tourPadding=null;opts.onSceneChange?.(sceneId);}}
function motion(duration,token,drawFrame){
 if(destroyed||token!==motionToken)return Promise.resolve(false);
 if(reduced||duration<=0){drawFrame(1);return Promise.resolve(true);}
 return new Promise(resolve=>{let start=null;motionResolve=resolve;const animate=t=>{if(destroyed||token!==motionToken){motionResolve=null;resolve(false);return;}if(start===null)start=t;const p=Math.min(1,(t-start)/duration),ease=p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;drawFrame(ease);if(p<1)motionRaf=requestAnimationFrame(animate);else{motionRaf=null;motionResolve=null;resolve(true);}};motionRaf=requestAnimationFrame(animate);});
}
function ghostCanvas(){
 const source=viewMode==='circuit'?container.querySelector('.mf-circuit-host'):svgEl;
 if(!source?.cloneNode)return null;
 const ghost=source.cloneNode(true),r=source.getBoundingClientRect(),sr=stage.getBoundingClientRect();ghost.classList.add('mf-tour-transition');ghost.setAttribute('aria-hidden','true');ghost.removeAttribute('tabindex');
 for(const el of ghost.querySelectorAll('[tabindex]'))el.removeAttribute('tabindex');
 Object.assign(ghost.style,{position:'absolute',top:(r.top-sr.top)+'px',left:(r.left-sr.left)+'px',right:'auto',bottom:'auto',width:r.width+'px',height:r.height+'px',visibility:'visible',pointerEvents:'none',zIndex:'1',opacity:'1'});stage.append(ghost);transitionGhosts.add(ghost);return ghost;
}
function parentOf(id){const s=maps.scenes[id];return s?.parentScene||s?.parent||(id!=='system'?(s?.board&&id!==s.board?s.board:'system'):null);}
function anchorFor(parentId,childId){
 const parent=maps.scenes[parentId],child=maps.scenes[childId];if(!parent||!child)return null;
 const exact=(parent.nodes||[]).filter(n=>(n.sceneId||n.detailSceneId)===childId);
 if(exact.length)return exact[0];
 const source=new Set((child.nodes||[]).flatMap(n=>n.refs||[]));let match=null,score=0;
 for(const n of parent.nodes||[]){const overlap=(n.refs||[]).filter(id=>source.has(id)).length;if(overlap>score){score=overlap;match=n;}}
 return match;
}
function scenePath(from,to){
 if(from===to)return[from];
 const links=new Map(Object.keys(maps.scenes).map(id=>[id,new Set()]));
 const connect=(a,b)=>{if(links.has(a)&&links.has(b)&&a!==b){links.get(a).add(b);links.get(b).add(a);}};
 for(const s of Object.values(maps.scenes)){connect(s.id,parentOf(s.id));for(const n of s.nodes||[])connect(s.id,n.sceneId||n.detailSceneId);}
 const queue=[[from]],seen=new Set([from]);while(queue.length){const path=queue.shift(),last=path.at(-1);for(const next of links.get(last)||[]){if(seen.has(next))continue;const route=[...path,next];if(next===to)return route;seen.add(next);queue.push(route);}}
 return[from,to];
}
function beginPresentation({viewportPadding}={}){
 if(navigationActive)cancelPresentationTransition();
 if(presentationActive){if(viewportPadding)tourPadding={...viewportPadding};return presentationSnapshot?.state;}
 presentationSnapshot={state:getState(),circuitNode,detailHtml:detail.innerHTML,detailHidden:detail.hidden};presentationActive=true;presentationFrame=null;presentationAudience='technical';tourPadding={top:96,bottom:300,left:48,right:48,...viewportPadding};
 root.classList.add('mf-presentation');container.classList.add('mf-presentation');playing=false;detail.hidden=true;updateHighlights();return presentationSnapshot.state;
}
async function switchPresentationScene(nextId,token,duration){
 const exploring=navigationActive,from=sceneId,downAnchor=anchorFor(from,nextId),upAnchor=anchorFor(nextId,from),goingUp=parentOf(from)===nextId||(!downAnchor&&upAnchor),host=container.querySelector('.mf-circuit-host');
 if(viewMode==='circuit'){const old=ghostCanvas();closeCircuit();applyCamera(false);if(old){old.style.opacity='1';if(!await motion(duration*.28,token,p=>old.style.opacity=String(1-p)))return false;old.remove();transitionGhosts.delete(old);}}
 if(downAnchor&&!goingUp){
  nodeViews.get(downAnchor.id)?.classList.add('mf-node-opening');if(!await motion(duration===0?0:220,token,()=>{}))return false;
  const start={...cam},portal=cameraFor({x:downAnchor.x-20,y:downAnchor.y-20,w:downAnchor.w+40,h:downAnchor.h+40},tourPadding,2.7);
  if(!await motion(duration*.42,token,p=>{cam=mixCamera(start,portal,p);applyCamera(false);} ))return false;
  const anchorScreen={x:cam.x+downAnchor.x*cam.scale,y:cam.y+downAnchor.y*cam.scale,w:downAnchor.w*cam.scale,h:downAnchor.h*cam.scale},ghost=ghostCanvas();
  presentationFrame=null;setScene(nextId,{keepScenario:!exploring,transitioning:true});if(!exploring)scenario=null;playing=false;selection=null;updateStory();updateHighlights();
  const target=exploring?{...cam}:cameraFor(bounds()),b=bounds(),startScale=Math.max(.04,Math.min(anchorScreen.w/Math.max(1,b.w),anchorScreen.h/Math.max(1,b.h))),inside={x:anchorScreen.x+anchorScreen.w/2-(b.x+b.w/2)*startScale,y:anchorScreen.y+anchorScreen.h/2-(b.y+b.h/2)*startScale,scale:startScale};
  cam=inside;applyCamera(false);world.style.opacity='0';
  const done=await motion(duration*.58,token,p=>{cam=mixCamera(inside,target,p);applyCamera(false);world.style.opacity=String(p);if(ghost)ghost.style.opacity=String(1-p);});
  if(ghost){ghost.remove();transitionGhosts.delete(ghost);}world.style.opacity='';return done;
 }
 const original={...cam},childBounds=bounds(),ghost=ghostCanvas(),ghostWorld=ghost?.querySelector('.mf-world');
 presentationFrame=null;setScene(nextId,{keepScenario:!exploring,transitioning:true});if(!exploring)scenario=null;playing=false;selection=null;updateStory();updateHighlights();const target=exploring?{...cam}:cameraFor(bounds());cam={...target};applyCamera(false);world.style.opacity='0';if(upAnchor)nodeViews.get(upAnchor.id)?.classList.add('mf-node-opening');
 let collapsed=original;
 if(upAnchor){const screen={x:target.x+upAnchor.x*target.scale,y:target.y+upAnchor.y*target.scale,w:upAnchor.w*target.scale,h:upAnchor.h*target.scale},scale=Math.max(.04,Math.min(screen.w/Math.max(1,childBounds.w),screen.h/Math.max(1,childBounds.h)));collapsed={x:screen.x+screen.w/2-(childBounds.x+childBounds.w/2)*scale,y:screen.y+screen.h/2-(childBounds.y+childBounds.h/2)*scale,scale};}
 const done=await motion(duration,token,p=>{world.style.opacity=String(p);if(ghost){ghost.style.opacity=String(1-p);const c=mixCamera(original,collapsed,p);ghostWorld?.setAttribute('transform',`translate(${c.x} ${c.y}) scale(${c.scale})`);}});
 if(ghost){ghost.remove();transitionGhosts.delete(ghost);}world.style.opacity='';return done;
}
async function navigateScene(nextId,{duration=1200}={}){
 if(presentationActive)return presentFrame({sceneId:nextId,duration,animateSignals:playing});
 nextId=maps.sheetScenes?.[nextId]||nextId;if(!maps.scenes[nextId])return{completed:false,reason:'unknown-scene',sceneId};
 cancelPresentationTransition();if(nextId===sceneId)return{completed:true,sceneId};saveCamera();rememberStory();const wasPlaying=playing,token=motionToken;
 navigationActive=true;transitionOrigin=sceneId;transitionDestination=nextId;transitionPath=scenePath(sceneId,nextId);tourPadding={top:150,bottom:220,left:65,right:65,...opts.viewportPadding};playing=false;root.classList.add('mf-transitioning');detail.hidden=true;updateWayfinding();updateHighlights();
 for(const id of transitionPath.slice(1)){if(!await switchPresentationScene(id,token,duration===0?0:Math.max(1000,Math.min(1400,duration))))return{completed:false,sceneId};}
 if(!await motion(duration===0?0:200,token,()=>{}))return{completed:false,sceneId};
 if(token!==motionToken||destroyed)return{completed:false,sceneId};navigationActive=false;tourPadding=null;playing=wasPlaying&&!!scenario;lastTime=0;updateHighlights();clearTransitionVisuals();saveCamera();rememberStory();opts.onSceneChange?.(sceneId);return{completed:true,sceneId};
}
async function presentFrame(frameSpec={}){
 if(!presentationActive)beginPresentation({viewportPadding:frameSpec.viewportPadding});
 cancelPresentationTransition();const token=motionToken,nextId=maps.sheetScenes?.[frameSpec.sceneId]||frameSpec.sceneId||sceneId;
 if(!maps.scenes[nextId])return{completed:false,reason:'unknown-scene',sceneId};
 setPresentationAudience(frameSpec.audience||presentationAudience);
 if(frameSpec.viewportPadding)tourPadding={...tourPadding,...frameSpec.viewportPadding};
 root.classList.add('mf-transitioning');detail.hidden=true;
 const path=scenePath(sceneId,nextId),duration=frameSpec.duration??1200;transitionOrigin=sceneId;transitionDestination=nextId;transitionPath=path.length>1?[...path]:[];updateWayfinding();
 for(const id of path.slice(1)){if(!await switchPresentationScene(id,token,duration===0?0:Math.max(1000,Math.min(1400,duration))))return{completed:false,sceneId};}
 if(token!==motionToken||destroyed)return{completed:false,sceneId};
 if(frameSpec.scenarioId)setScenario(frameSpec.scenarioId,{keepScene:true,stepIndex:frameSpec.stepIndex||0});else{scenario=null;stepIndex=0;playing=false;}
 presentationFrame={nodeIds:frameSpec.nodeIds,edgeIds:frameSpec.edgeIds,edgeDirections:frameSpec.edgeDirections||{},audience:presentationAudience};selection=null;detail.hidden=true;updateStory();updateHighlights();
 const start={...cam},target=cameraFor(focusBounds(frameSpec.nodeIds||[],frameSpec.edgeIds||[]));
 if(!await motion(path.length>1?Math.min(300,duration*.4):Math.min(600,duration),token,p=>{cam=mixCamera(start,target,p);applyCamera(false);} ))return{completed:false,sceneId};
 if(frameSpec.viewMode==='circuit'){
  const ghost=ghostCanvas();openCircuit({nodeId:frameSpec.circuitNodeId||frameSpec.nodeIds?.[0]});circuit?.fit?.();const circuitHost=container.querySelector('.mf-circuit-host');circuitHost.style.opacity='0';
  if(!await motion(Math.min(300,duration),token,p=>{circuitHost.style.opacity=String(p);if(ghost)ghost.style.opacity=String(1-p);} ))return{completed:false,sceneId};
  circuitHost.style.opacity='';if(ghost){ghost.remove();transitionGhosts.delete(ghost);}
 }else if(viewMode==='circuit'){
  const ghost=ghostCanvas();closeCircuit();applyCamera(false);world.style.opacity='0';
  if(!await motion(Math.min(300,duration),token,p=>{world.style.opacity=String(p);if(ghost)ghost.style.opacity=String(1-p);}))return{completed:false,sceneId};
  world.style.opacity='';if(ghost){ghost.remove();transitionGhosts.delete(ghost);}
 }
 if(path.length>1&&!await motion(duration===0?0:200,token,()=>{}))return{completed:false,sceneId};playing=frameSpec.animateSignals!==false;lastTime=0;stepTime=0;updateHighlights();clearTransitionVisuals();return{completed:true,sceneId,viewMode};
}
function setPresentationAudience(audience){
 if(!presentationActive||destroyed||!['general','technical'].includes(audience)||audience===presentationAudience)return false;
 presentationAudience=audience;if(presentationFrame)presentationFrame={...presentationFrame,audience};
 root.classList.toggle('mf-general-audience',generalAudience());draw();updateHighlights();return true;
}
function setPresentationSignals(value){playing=!!value;lastTime=0;updateHighlights();}
function setPresentationViewportPadding(padding,{refit=false}={}){tourPadding={...(tourPadding||{}),...padding};updateCircuitLayout();if(refit&&presentationActive){cam=cameraFor(focusBounds(presentationFrame?.nodeIds||[],presentationFrame?.edgeIds||[]));applyCamera(false);}}
function endPresentation(){
 const snapshot=presentationSnapshot;if(!presentationActive||!snapshot)return null;cancelPresentationTransition();presentationFrame=null;presentationAudience='technical';root.classList.remove('mf-general-audience');
 const saved=snapshot.state;closeCircuit();setScene(saved.sceneId,{keepScenario:true});scenario=maps.scenarios?.find(s=>s.id===saved.scenarioId)||null;stepIndex=saved.stepIndex;playing=saved.playing;selection=saved.selection?{...saved.selection}:null;cam={...saved.camera};size=dimensions();applyCamera(false);updateStory();updateHighlights();
 if(saved.viewMode==='circuit'){openCircuit({node:snapshot.circuitNode});if(saved.circuitViewport)circuit?.setViewport?.(saved.circuitViewport);selection=saved.selection?{...saved.selection}:null;syncCircuitSelection();}
 detail.innerHTML=snapshot.detailHtml;detail.hidden=snapshot.detailHidden;presentationActive=false;presentationSnapshot=null;tourPadding=null;root.classList.remove('mf-presentation');container.classList.remove('mf-presentation');updateCircuitLayout();saveCamera();rememberStory();return getState();
}

function selectedCircuitNets(){
const ids=new Set(currentStep()?.netIds||currentStep()?.nets||[]);if(selection?.type==='net')ids.add(selection.id);
for(const eid of activeEdges()){const e=(scene?.edges||[]).find(e=>e.id===eid);for(const n of e?.nets||[])ids.add(n);}
return [...ids].map(id=>netFor(id).id).filter(id=>A.nets?.[id]);
}
function syncCircuitSelection(){if(!circuit)return;circuit.setSelection?.({netIds:selectedCircuitNets(),pinStates:currentStep()?.pinStates||[],pinHighlights:currentStep()?.pinHighlights||[],componentIds:selection?.type==='component'?[selection.id]:[]});}
function closeCircuit(){circuit?.destroy?.();circuit=null;circuitNode=null;viewMode='functional';const host=container.querySelector('.mf-circuit-host');if(host){host.hidden=true;host.replaceChildren();}root.classList.remove('mf-circuit-mode');for(const b of container.querySelectorAll('[data-mode]'))b.setAttribute('aria-pressed',String(b.dataset.mode==='functional'));container.querySelector('.mf-circuit-picker')?.remove();}
function openCircuit(target={}){
if(typeof target==='string')target={componentId:target};
let group=target.node||nodes.find(n=>n.id===target.nodeId)||null;
const componentId=target.componentId||target.id;
if(componentId&&!group)group=nodes.find(n=>(n.refs||[]).includes(componentId));
// Resolve an exact source item to its functional module, never to a component page.
if((target.sheetId&&target.sheetId!==scene?.sheetId&&maps.scenes[target.sheetId])||(componentId&&!group)){
const found=Object.values(maps.scenes).find(s=>s.sheetId&&(target.sheetId?s.sheetId===target.sheetId:(s.nodes||[]).some(n=>(n.refs||[]).includes(componentId))));
if(found&&found.id!==sceneId){setScene(found.id);group=componentId?nodes.find(n=>(n.refs||[]).includes(componentId)):null;}}
if(!group&&selection?.type==='node')group=nodes.find(n=>n.id===selection.id);
if(!group&&target.netId){const net=netFor(target.netId),refs=new Set((net.pins||[]).map(p=>p.component));group=nodes.find(n=>(n.refs||[]).some(ref=>refs.has(ref)));}
if(!group)group=nodes.find(n=>(currentStep()?.nodes||[]).includes(n.id)&&(n.refs||[]).length)||nodes.find(n=>(n.refs||[]).length);
if(!group){const drill=nodes.find(n=>maps.scenes[n.sceneId||n.detailSceneId]);if(drill){setScene(drill.sceneId||drill.detailSceneId);return openCircuit(target);}return;}
if(!group.sheetId&&!scene.sheetId&&!group.circuitGroup?.units?.length){
 const candidates=Object.values(maps.scenes).filter(s=>s.sheetId&&(s.nodes||[]).some(n=>(n.refs||[]).some(ref=>group.refs.includes(ref))));
 const exact=target.netId?candidates.find(s=>(A.nets?.[target.netId]?.sheets||[]).includes(s.sheetId)):null;
 const next=exact||candidates.find(s=>s.id===group.sceneId)||candidates[0];
 if(next&&next.id!==sceneId){setScene(next.id);return openCircuit({componentId,netId:target.netId});}
}
if(!window.MiraCircuit)return;
const host=container.querySelector('.mf-circuit-host');circuit?.destroy?.();circuitNode=group;viewMode='circuit';detail.hidden=true;host.hidden=false;root.classList.add('mf-circuit-mode');
for(const b of container.querySelectorAll('[data-mode]'))b.setAttribute('aria-pressed',String(b.dataset.mode==='circuit'));
let picker=container.querySelector('.mf-circuit-picker');if(!picker){picker=document.createElement('label');picker.className='mf-circuit-picker';container.querySelector('.mf-location').append(picker);}
picker.innerHTML=`<span>Схемотехника узла</span><select data-circuit-group aria-label="Выбрать узел для схемотехники">${!nodes.some(n=>n.id===group.id)?`<option value="${esc(group.id)}" selected>${esc(group.title)}</option>`:''}${nodes.filter(n=>(n.refs||[]).length).map(n=>`<option value="${esc(n.id)}"${n.id===group.id?' selected':''}>${esc(n.title)} · ${n.refs.length} комп.</option>`).join('')}</select><span class="mf-circuit-manual">Фрагмент закреплён · выбор узла вручную</span>`;
circuit=window.MiraCircuit.mount(host,{atlas:A,scene,node:group,persistCamera:()=>!presentationActive,wideLayout:presentationActive&&!!presentationFrame,netIds:target.netId?[target.netId]:selectedCircuitNets(),pinStates:currentStep()?.pinStates||[],pinHighlights:currentStep()?.pinHighlights||[],onSelectNet:id=>{const edge=(scene.edges||[]).find(e=>(e.nets||[]).includes(id));if(edge)selection={type:'edge',id:edge.id};else selection={type:'net',id};updateHighlights();circuit?.setSelection?.({netIds:[id],pinStates:currentStep()?.pinStates||[],pinHighlights:currentStep()?.pinHighlights||[]});},onSelectComponent:id=>{selection={type:'component',id};syncCircuitSelection();}});
if(componentId){selection={type:'component',id:componentId};circuit.setSelection?.({netIds:target.netId?[target.netId]:selectedCircuitNets(),componentIds:[componentId],pinStates:currentStep()?.pinStates||[],pinHighlights:currentStep()?.pinHighlights||[]});}
return circuit;
}
function setView(mode){if(mode==='circuit')return openCircuit();closeCircuit();applyCamera(false);}

function handleAction(e){
const el=e.target.closest('[data-act],[data-node],[data-edge],[data-scene],[data-component-help],[data-component],[data-source],[data-net-detail],[data-step],[data-mode],[data-circuit-node],[data-circuit-edge],[data-circuit-net]');
if(!el||!root.contains(el)||suppressClick)return;const a=el.dataset.act;
if(el.dataset.mode){setView(el.dataset.mode);return;}
if(el.dataset.circuitNode){openCircuit({nodeId:el.dataset.circuitNode});return;}
if(el.dataset.circuitEdge){const edge=(scene.edges||[]).find(e=>e.id===el.dataset.circuitEdge),sourceNodes=nodes.filter(n=>n.id===edge?.from||n.id===edge?.to),group={id:'link-'+edge?.id,title:edge?.label||'Соединение',refs:[...new Set(sourceNodes.flatMap(n=>n.refs||[]))],sourceNodes,sheetId:scene.sheetId};openCircuit({node:group,netId:edge?.nets?.[0]});return;}
if(el.dataset.circuitNet){openCircuit({netId:el.dataset.circuitNet});return;}
if(el.dataset.scene){if(presentationActive)presentFrame({sceneId:el.dataset.scene});else navigateScene(el.dataset.scene);return;}
if(el.dataset.node){selectNode(el.dataset.node);return;}
if(el.dataset.edge){selectEdge(el.dataset.edge);return;}
if(el.dataset.componentHelp){showComponentHelp(el.dataset.componentHelp);return;}
if(el.dataset.component){openCircuit({componentId:el.dataset.component});return;}
if(el.dataset.source){openCircuit({sheetId:el.dataset.source,netId:el.dataset.net||''});return;}
if(el.dataset.netDetail){showNet(el.dataset.netDetail);return;}
if(el.hasAttribute('data-step')){seek(Number(el.dataset.step));return;}
if(a==='close')clearDetail();else if(a==='in')viewMode==='circuit'?circuit?.zoom?.(1.2):zoom(1.2);else if(a==='out')viewMode==='circuit'?circuit?.zoom?.(1/1.2):zoom(1/1.2);else if(a==='fit')viewMode==='circuit'?circuit?.fit?.():fit();else if(a==='play')playing?pause():play();else if(a==='next')step(1);else if(a==='prev')step(-1);else if(a==='story-close'){scenario=null;playing=false;updateStory();updateHighlights();}else if(a==='full'){if(document.fullscreenElement)document.exitFullscreen?.();else(root.requestFullscreen?.()||Promise.resolve()).catch?.(()=>{});}
}
on(root,'click',handleAction);
on(root,'change',e=>{if(e.target.matches('[data-story]'))setScenario(e.target.value);else if(e.target.matches('[data-scene-picker]'))presentationActive?presentFrame({sceneId:e.target.value}):navigateScene(e.target.value);else if(e.target.matches('[data-circuit-group]'))openCircuit({nodeId:e.target.value});});
on(svgEl,'dblclick',e=>{const n=e.target.closest('[data-node]');if(n){const node=nodes.find(x=>x.id===n.dataset.node);if(node?.sceneId||node?.detailSceneId){if(presentationActive)presentFrame({sceneId:node.sceneId||node.detailSceneId});else navigateScene(node.sceneId||node.detailSceneId);}else if(node?.refs?.length)openCircuit({nodeId:node.id});}});
on(svgEl,'wheel',e=>{e.preventDefault();if(root.classList.contains('mf-transitioning'))cancelPresentationTransition();const r=svgEl.getBoundingClientRect();zoom(Math.exp(-Math.min(160,Math.max(-160,e.deltaY))*.003),{x:e.clientX-r.left,y:e.clientY-r.top});},{passive:false});
on(svgEl,'pointerdown',e=>{if(e.button!==0)return;if(root.classList.contains('mf-transitioning'))cancelPresentationTransition();drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x:cam.x,y:cam.y,moved:false};});
on(svgEl,'pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;if(!drag.moved&&Math.hypot(dx,dy)<5)return;if(!drag.moved)svgEl.setPointerCapture?.(e.pointerId);drag.moved=true;root.classList.add('mf-panning');cam.x=drag.x+dx;cam.y=drag.y+dy;applyCamera(false);});

function endDrag(e){if(!drag||drag.id!==e.pointerId)return;const moved=drag.moved;drag=null;root.classList.remove('mf-panning');if(moved){svgEl.releasePointerCapture?.(e.pointerId);saveCamera();suppressClick=true;setTimeout(()=>suppressClick=false,0);}}
on(svgEl,'pointerup',endDrag);on(svgEl,'pointercancel',endDrag);
on(root,'keydown',e=>{if(e.defaultPrevented||/^(INPUT|SELECT|TEXTAREA|BUTTON|A|SUMMARY)$/.test(e.target.tagName))return;if(e.key==='Escape'){if(viewMode==='circuit')setView('functional');else clearDetail();return;}const active=e.target.closest('[data-node],[data-edge]');if((e.key==='Enter'||e.key===' ')&&active){e.preventDefault();handleAction({target:active});return;}if(e.key===' '&&!opts.externalPlayback){e.preventDefault();playing?pause():play();}else if(e.key==='ArrowRight'&&scenario&&!opts.externalPlayback){e.preventDefault();step(1);}else if(e.key==='ArrowLeft'&&scenario&&!opts.externalPlayback){e.preventDefault();step(-1);}else if(e.key==='+'||e.key==='='){e.preventDefault();viewMode==='circuit'?circuit?.zoom?.(1.2):zoom(1.2);}else if(e.key==='-'){e.preventDefault();viewMode==='circuit'?circuit?.zoom?.(1/1.2):zoom(1/1.2);}else if(e.key==='0'){e.preventDefault();viewMode==='circuit'?circuit?.fit?.():fit();}});
function resize(){updateCircuitLayout();const next=dimensions();if(!hasSized){size=next;hasSized=true;return;}if(Math.abs(next.w-size.w)<1&&Math.abs(next.h-size.h)<1)return;cam.x+=(next.w-size.w)/2;cam.y+=(next.h-size.h)/2;size=next;applyCamera();}
if(window.ResizeObserver){resizeObserver=new ResizeObserver(resize);resizeObserver.observe(stage);}else on(window,'resize',resize);
function pointOnSegments(segments,t){const lengths=segments.map(points=>points.slice(1).reduce((sum,p,i)=>sum+Math.hypot(p.x-points[i].x,p.y-points[i].y),0)),total=lengths.reduce((sum,l)=>sum+l,0);let target=total*t;for(let i=0;i<segments.length;i++){if(target<=lengths[i])return pointOnPolyline(segments[i],lengths[i]?target/lengths[i]:0);target-=lengths[i];}return segments.at(-1)?.at(-1)||{x:0,y:0};}
function pointOnPolyline(points,t){let length=0;for(let i=1;i<points.length;i++)length+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);let target=length*t;for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],seg=Math.hypot(b.x-a.x,b.y-a.y);if(target<=seg)return{x:a.x+(b.x-a.x)*target/seg,y:a.y+(b.y-a.y)*target/seg};target-=seg;}return points.at(-1)||{x:0,y:0};}
function tick(t){if(destroyed)return;const dt=lastTime?Math.min(100,t-lastTime):0;lastTime=t;if(playing)stepTime+=dt;
const move=(playing||(!presentationActive&&!scenario&&selection))&&!reduced;if(move)signalTime+=dt;for(const v of edgeViews){v.signalGroup.style.display=v.active?'':'none';if(!v.active){if(v.energized){v.flow.setAttribute('stroke-dasharray',`${v.length} 0`);v.flow.style.opacity='.28';v.flow.style.strokeWidth='3';}else{v.flow.removeAttribute('stroke-dasharray');v.flow.style.opacity='';v.flow.style.strokeWidth='';}continue;}const pointAt=phase=>{if(presentationActive&&v.edge.bidirectional&&presentationFrame?.edgeDirections?.[v.edge.id]==='reverse')phase=1-phase;try{return v.path.getPointAtLength?v.path.getPointAtLength(v.length*phase):pointOnSegments(v.segments||[v.points],phase);}catch{return pointOnSegments(v.segments||[v.points],phase);}};for(let i=0;i<v.particles.length;i++){const neutral=v.edge.undirected||v.edge.direction==='none',phase=neutral?.5+.44*Math.sin(signalTime/900+i*2*Math.PI/3):(signalTime/2500+i/3+.15)%1,p=pointAt(phase);v.particles[i].setAttribute('cx',p.x);v.particles[i].setAttribute('cy',p.y);}
const type=v.edge.type,neutral=v.edge.undirected||v.edge.direction==='none',phase=neutral?.5:(.15+(signalTime/4500%1)*.7),p=pointAt(phase),signalLabel=type==='power'?(String(v.edge.label||'').match(/[+−-]?\d+(?:\.\d+)?\s*V/i)?.[0]||'ПИТАНИЕ'):type==='control'?(Math.floor(signalTime/800)%2?'1 · ВКЛ':'0 → 1'):type==='fault'?'ЗАЩИТА':type==='analog'?'АНАЛОГ':v.clock?'1010':v.edge.undirected||v.edge.direction==='none'?'СИГНАЛ':'ДАННЫЕ';v.signalGroup.style.opacity=neutral?String(.72+.28*(.5+.5*Math.sin(signalTime/500))):'1';v.signalGroup.setAttribute('transform',`translate(${p.x} ${p.y-18})`);v.signalText.textContent=signalLabel;v.signalWave.setAttribute('d',type==='analog'?'M-23 6 Q-18-4-13 6 T-3 6 T7 6 T17 6 T27 6':v.clock?'M-22 7 V3 H-15 V7 H-8 V3 H-1 V7 H6 V3 H13 V7 H20':'');if(type==='analog'||v.clock){v.signalText.setAttribute('y','-3');v.signalText.setAttribute('font-size','7');}else{v.signalText.setAttribute('y','3.5');v.signalText.setAttribute('font-size','9');}if(type==='power'){const fill=Math.min(1,stepTime/1800);v.flow.setAttribute('stroke-dasharray',`${Math.max(2,v.length*fill)} ${v.length}`);v.flow.style.opacity='.5';v.flow.style.strokeWidth='3';}else v.flow.removeAttribute('stroke-dasharray');}
frame=requestAnimationFrame(tick);}
setScene(opts.sceneId||'system');hasSized=true;size=dimensions();if(opts.scenarioId)setScenario(opts.scenarioId);frame=requestAnimationFrame(tick);
return{destroy(){if(destroyed)return;cancelPresentationTransition();destroyed=true;saveCamera();rememberStory();circuit?.destroy?.();cancelAnimationFrame(frame);resizeObserver?.disconnect();listen.forEach(f=>f());container.classList.remove('mira-functional-host');container.replaceChildren();},getState,getNavigationPath,navigateScene,beginPresentation,presentFrame,endPresentation,cancelPresentationTransition,setPresentationAudience,setPresentationSignals,setPresentationViewportPadding,setScene,selectNode,showComponentHelp,selectNet,setScenario,seek,play,pause,step,fit,zoom,openCircuit,setView};
}
window.MiraFunctional={mount};
})();
