/* MIRA Atlas diagram engine. No network access or external dependencies. */
(function () {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg';
  var serial = 0;
  // Cameras belong to scenes, not to a particular DOM mount. Selection updates,
  // tabs and presentation steps can rebuild a scene without moving the reader.
  var cameras = Object.create(null), recentCameras = Object.create(null);
  var cameraPrefix = 'mira.diagram.viewport.v2:';
  function copyCamera(value) { return value ? Object.assign({}, value) : null; }
  function validCamera(value, view) {
    if (!value || value.view !== view) return false;
    if (view === 'net') return finite(value.scrollTop) && value.scrollTop >= 0 && finite(value.scrollLeft) && value.scrollLeft >= 0 && finite(value.fontScale) && value.fontScale >= .75 && value.fontScale <= 1.7;
    return finite(value.x) && finite(value.y) && finite(value.w) && value.w > 0 && finite(value.h) && value.h > 0;
  }
  function loadCamera(key, view) {
    if (validCamera(cameras[key], view)) return copyCamera(cameras[key]);
    try {
      var value = JSON.parse(window.localStorage.getItem(key));
      if (validCamera(value, view)) { cameras[key] = value; return copyCamera(value); }
    } catch (ignore) { /* file:// browsers may deny storage; memory still works. */ }
    return null;
  }
  function originalGraphic(graphic) {
    var points = list(graphic.points); if (!points.length) return null;
    if (graphic.type === 'polyline') return svgEl('polyline', { points: points.map(function(p){return p.join(',');}).join(' '), class:'md-original-shape' });
    if (graphic.type === 'rectangle' && points.length > 1) return svgEl('rect',{x:Math.min(points[0][0],points[1][0]),y:Math.min(points[0][1],points[1][1]),width:Math.abs(points[1][0]-points[0][0]),height:Math.abs(points[1][1]-points[0][1]),class:'md-original-shape'});
    if (graphic.type === 'circle' && points.length > 1) return svgEl('circle',{cx:(points[0][0]+points[1][0])/2,cy:(points[0][1]+points[1][1])/2,r:Math.abs(points[1][0]-points[0][0])/2,class:'md-original-shape'});
    if (graphic.type === 'arc' && points.length > 2) {
      var a=points[0], m=points[1], z=points[2], det=2*(a[0]*(m[1]-z[1])+m[0]*(z[1]-a[1])+z[0]*(a[1]-m[1]));
      if(Math.abs(det)<1e-8) return svgEl('polyline',{points:points.map(function(p){return p.join(',');}).join(' '),class:'md-original-shape'});
      var aa=a[0]*a[0]+a[1]*a[1],mm=m[0]*m[0]+m[1]*m[1],zz=z[0]*z[0]+z[1]*z[1];
      var cx=(aa*(m[1]-z[1])+mm*(z[1]-a[1])+zz*(a[1]-m[1]))/det,cy=(aa*(z[0]-m[0])+mm*(a[0]-z[0])+zz*(m[0]-a[0]))/det,r=Math.hypot(a[0]-cx,a[1]-cy);
      var start=Math.atan2(a[1]-cy,a[0]-cx),mid=Math.atan2(m[1]-cy,m[0]-cx),end=Math.atan2(z[1]-cy,z[0]-cx),tau=Math.PI*2,delta=(end-start+tau)%tau,midDelta=(mid-start+tau)%tau,sweep=midDelta<=delta?1:0,span=sweep?delta:tau-delta;
      return svgEl('path',{d:'M'+a.join(' ')+' A'+r+' '+r+' 0 '+(span>Math.PI?1:0)+' '+sweep+' '+z.join(' '),class:'md-original-shape'});
    }
    return null;
  }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function svgEl(tag, attrs, text) { var n = document.createElementNS(NS, tag); Object.keys(attrs || {}).forEach(function (k) { if (attrs[k] != null) n.setAttribute(k, attrs[k]); }); if (text != null) n.textContent = text; return n; }
  function finite(n) { return typeof n === 'number' && isFinite(n); }
  function num(n, fallback) { return finite(Number(n)) ? Number(n) : fallback; }
  function list(v) { return Array.isArray(v) ? v : []; }
  function natural(a, b) { return String(a).localeCompare(String(b), 'en', { numeric: true }); }
  function kindClass(kind) { var k = String(kind || '').toLowerCase(); if (/ground|gnd/.test(k)) return 'ground'; if (/power|supply|rail/.test(k)) return 'power'; if (/clock/.test(k)) return 'clock'; if (/fault|protect|trip/.test(k)) return 'fault'; if (/analog|reference/.test(k)) return 'analog'; if (/data|digital|bus|ethernet|spi/.test(k)) return 'data'; return 'control'; }
  function textTitle(n, text) { n.appendChild(svgEl('title', {}, text)); }
  function button(label, title, fn, cls) { var b = el('button', 'md-button ' + (cls || ''), label); b.type = 'button'; b.title = title || label; b.setAttribute('aria-label', title || label); b.addEventListener('click', fn); return b; }
  function typeLabel(type) { return ({ input: 'вход', output: 'выход', bidirectional: 'двунаправленный', tri_state: 'с третьим состоянием (Hi-Z)', passive: 'пассивный', free: 'свободный', unspecified: 'не задан', power_in: 'вход питания', power_out: 'выход питания', open_collector: 'открытый коллектор', open_emitter: 'открытый эмиттер', no_connect: 'не подключён', power: 'Питание', ground: 'Земля', clock: 'Тактирование', analog: 'Аналоговый сигнал', digital: 'Цифровой сигнал', data: 'Данные', control: 'Управление', fault: 'Авария', reference: 'Опорный сигнал', signal: 'Сигнал', unnamed: 'Без имени' })[type] || type || ''; }
  function componentName(atlas, id) { var c = (atlas.components || {})[id] || {}; return c.ref || id || 'Неизвестный компонент'; }
  function boundsOf(d) {
    var b = d.bounds || {};
    var x = num(b.x, num(b.minX, NaN)), y = num(b.y, num(b.minY, NaN));
    var w = num(b.w, num(b.width, NaN)), h = num(b.h, num(b.height, NaN));
    if (!finite(w) && finite(x)) w = num(b.maxX, NaN) - x;
    if (!finite(h) && finite(y)) h = num(b.maxY, NaN) - y;
    if (finite(x) && finite(y) && w > 0 && h > 0) return { x: x, y: y, w: w, h: h };
    var xs = [], ys = [];
    function pt(px, py) { if (finite(Number(px)) && finite(Number(py))) { xs.push(Number(px)); ys.push(Number(py)); } }
    list(d.wires).forEach(function (v) { pt(v.x1, v.y1); pt(v.x2, v.y2); });
    list(d.symbols).forEach(function (s) { pt(s.x, s.y); list(s.pins).forEach(function (p) { pt(p.x, p.y); }); if (s.box) { pt(s.box.x, s.box.y); pt(num(s.box.x, 0) + num(s.box.w, 0), num(s.box.y, 0) + num(s.box.h, 0)); } });
    list(d.labels).forEach(function (v) { pt(v.x, v.y); });
    if (!xs.length) return { x: 0, y: 0, w: 200, h: 140 };
    var minX = Math.min.apply(null, xs), minY = Math.min.apply(null, ys);
    return { x: minX, y: minY, w: Math.max(30, Math.max.apply(null, xs) - minX), h: Math.max(20, Math.max.apply(null, ys) - minY) };
  }
  function symbolBox(s) {
    var b = s.box || {}; var x = num(b.x, NaN), y = num(b.y, NaN), w = num(b.w, num(b.width, NaN)), h = num(b.h, num(b.height, NaN));
    if (finite(x) && finite(y) && w > 0 && h > 0) return { x: x, y: y, w: w, h: h };
    var pins = list(s.pins), xs = pins.map(function (p) { return num(p.x, num(s.x, 0)); }), ys = pins.map(function (p) { return num(p.y, num(s.y, 0)); });
    return { x: num(s.x, 0) - 3.2, y: num(s.y, 0) - 2.2, w: 6.4, h: 4.4 };
  }
  function mount(container, options) {
    options = options || {}; var atlas = options.atlas || {}, sheets = atlas.sheets || {}, nets = atlas.nets || {}, components = atlas.components || {};
    var root = el('div', 'mira-diagram'); root.dataset.engine = 'mira-diagram'; root.setAttribute('aria-label', 'Интерактивная схема электрических соединений'); container.appendChild(root);
    var destroyed = false, selection = options.netId || null, currentView = options.view === 'net' ? 'net' : 'sheet', svg, viewport, viewBox, fullBounds, resizeObserver, drag = null;
    var sceneKey = cameraPrefix + encodeURIComponent(options.sheetId || '') + ':' + currentView + ':' + (currentView === 'net' ? encodeURIComponent(options.netId || '') : '');
    var familyKey = String(options.sheetId || '') + ':' + currentView, cameraModified = false, lastSize = null, storageTimer = null, fittedWithoutSize = false;
    var initialCamera = validCamera(options.viewport, currentView) ? copyCamera(options.viewport) : loadCamera(sceneKey, currentView);
    if (!initialCamera && recentCameras[familyKey] && recentCameras[familyKey].modified) initialCamera = copyCamera(recentCameras[familyKey]);
    var events = [], tagged = [], symbolTagged = [];
    function listen(target, type, fn, opt) { target.addEventListener(type, fn, opt); events.push(function () { target.removeEventListener(type, fn, opt); }); }
    function selectNet(id) { if (!id) return; setSelection(id); if (typeof options.onSelectNet === 'function') options.onSelectNet(id); }
    function selectComponent(id) { if (id && typeof options.onSelectComponent === 'function') options.onSelectComponent(id); }
    function appendEmpty(title, copy) { var d = el('div', 'md-empty'); d.append(el('span', 'md-eyebrow', 'MIRA ATLAS'), el('h3', '', title), el('p', '', copy)); root.appendChild(d); }
    function toolbar(label, detail) {
      var bar = el('div', 'md-toolbar'); var title = el('div', 'md-toolbar-title'); title.append(el('strong', '', label), el('span', '', detail)); bar.appendChild(title);
      var actions = el('div', 'md-actions'); actions.append(button('−', 'Уменьшить масштаб', function () { zoom(0.8); }), button('+', 'Увеличить масштаб', function () { zoom(1.25); }), button('Вписать', 'Вписать схему в экран', fit)); bar.appendChild(actions); root.appendChild(bar);
      return bar;
    }
    function viewportSize() {
      var r = viewport && viewport.getBoundingClientRect();
      return { width: r && r.width > 0 ? r.width : (lastSize ? lastSize.width : 800), height: r && r.height > 0 ? r.height : (lastSize ? lastSize.height : 600) };
    }
    function applyViewBox() { if (svg && viewBox) svg.setAttribute('viewBox', [viewBox.x, viewBox.y, viewBox.w, viewBox.h].join(' ')); }
    function getViewport() {
      if (currentView === 'net') {
        var scroller = root.querySelector('.md-net-scroll');
        if (!scroller) return null;
        return { view: 'net', scrollTop: scroller.scrollTop || 0, scrollLeft: scroller.scrollLeft || 0, fontScale: Number(root.style.getPropertyValue('--md-net-font')) || 1, modified: cameraModified };
      }
      if (!viewBox) return null;
      var size = lastSize || viewportSize();
      return { view: 'sheet', x: viewBox.x, y: viewBox.y, w: viewBox.w, h: viewBox.h, viewportWidth: size.width, viewportHeight: size.height, modified: cameraModified };
    }
    function flushCamera() {
      if (storageTimer != null) { clearTimeout(storageTimer); storageTimer = null; }
      if (!cameras[sceneKey]) return;
      try { window.localStorage.setItem(sceneKey, JSON.stringify(cameras[sceneKey])); } catch (ignore) { /* Optional persistence only. */ }
    }
    function rememberCamera() {
      var value = getViewport(); if (!value) return;
      cameras[sceneKey] = value; recentCameras[familyKey] = copyCamera(value);
      if (storageTimer != null) clearTimeout(storageTimer);
      storageTimer = setTimeout(flushCamera, 160);
    }
    function setViewport(value) {
      if (!validCamera(value, currentView)) return false;
      cameraModified = value.modified !== false;
      if (currentView === 'net') {
        var scroller = root.querySelector('.md-net-scroll'); if (!scroller) return false;
        root.style.setProperty('--md-net-font', String(value.fontScale));
        scroller.scrollTop = value.scrollTop; scroller.scrollLeft = value.scrollLeft;
      } else {
        if (!svg) return false;
        fittedWithoutSize = false;
        var size = viewportSize(), cx = value.x + value.w / 2, cy = value.y + value.h / 2;
        var oldWidth = num(value.viewportWidth, size.width), oldHeight = num(value.viewportHeight, size.height);
        // World units per screen pixel remain stable when a panel opens or the
        // window changes size. Only the amount of visible surrounding space changes.
        var unitsPerPixel = value.h / (oldHeight > 0 ? oldHeight : size.height);
        if (!(oldWidth > 0)) unitsPerPixel = value.w / size.width;
        viewBox = { x: cx - size.width * unitsPerPixel / 2, y: cy - size.height * unitsPerPixel / 2, w: size.width * unitsPerPixel, h: size.height * unitsPerPixel };
        lastSize = size; applyViewBox();
      }
      rememberCamera(); return true;
    }
    function fit() {
      cameraModified = false;
      if (currentView === 'net') { var scroller = root.querySelector('.md-net-scroll'); if (scroller) { scroller.scrollTop = 0; scroller.scrollLeft = 0; } root.style.setProperty('--md-net-font', '1'); rememberCamera(); return; }
      if (!svg || !fullBounds) return;
      var rect = viewportSize(), ratio = rect.width / rect.height, b = fullBounds, pad = Math.max(b.w, b.h) * .045 + 3;
      var w = b.w + pad * 2, h = b.h + pad * 2;
      if (w / h < ratio) w = h * ratio; else h = w / ratio;
      var measured = viewport.getBoundingClientRect(); fittedWithoutSize = !(measured.width > 0 && measured.height > 0);
      viewBox = { x: b.x + b.w / 2 - w / 2, y: b.y + b.h / 2 - h / 2, w: w, h: h }; lastSize = rect; applyViewBox(); rememberCamera();
    }
    function zoom(factor, cx, cy) {
      if (!finite(factor) || factor <= 0) return;
      cameraModified = true;
      if (currentView === 'net') { var value = Number(root.style.getPropertyValue('--md-net-font')) || 1; root.style.setProperty('--md-net-font', String(Math.max(.75, Math.min(1.7, value * factor)))); rememberCamera(); return; }
      if (!viewBox || !svg) return;
      var w = Math.max(3, Math.min(fullBounds.w * 20 + 200, viewBox.w / factor)), h = viewBox.h * w / viewBox.w;
      cx = finite(cx) ? cx : viewBox.x + viewBox.w / 2; cy = finite(cy) ? cy : viewBox.y + viewBox.h / 2;
      var rx = (cx - viewBox.x) / viewBox.w, ry = (cy - viewBox.y) / viewBox.h;
      viewBox = { x: cx - rx * w, y: cy - ry * h, w: w, h: h }; applyViewBox(); rememberCamera();
    }
    function setSelection(id) {
      selection = id || null;
      tagged.forEach(function (v) { v.node.classList.toggle('is-selected', !!selection && v.net === selection); v.node.classList.toggle('is-dimmed', !!selection && v.net !== selection); });
      symbolTagged.forEach(function (v) { v.node.classList.toggle('is-connected', !!selection && v.nets.indexOf(selection) !== -1); });
      var note = root.querySelector('.md-selection'); if (note) { note.textContent = selection && nets[selection] ? nets[selection].name : 'Нажмите на проводник, метку или вывод, чтобы проследить цепь'; note.classList.toggle('has-selection', !!selection); }
    }
    function netTagged(node, id) { if (!id) return; node.dataset.net = id; tagged.push({ node: node, net: id }); node.addEventListener('click', function (e) { e.stopPropagation(); selectNet(id); }); }
    function renderSheet() {
      var sheet = sheets[options.sheetId]; if (!sheet) { appendEmpty('Выберите лист схемы', 'Выберите модуль, чтобы увидеть его проводники, метки и подключения выводов компонентов.'); return; }
      var d = sheet.drawing || {}; var symbols = list(d.symbols), wires = list(d.wires), labels = list(d.labels);
      toolbar(sheet.title || sheet.file || sheet.id, (sheet.board || '') + ' · ' + (sheet.file || 'Лист схемы'));
      var selectionBar = el('div', 'md-selection-row'); selectionBar.append(el('span', 'md-live-dot'), el('span', 'md-selection', 'Нажмите на проводник, метку или вывод, чтобы проследить цепь')); var clear = button('Сбросить', 'Снять выделение цепи', function () { setSelection(null); }); selectionBar.append(clear); root.appendChild(selectionBar);
      viewport = el('div', 'md-sheet-viewport'); viewport.tabIndex = 0; viewport.setAttribute('aria-label', 'Поле схемы. Перетаскивайте для перемещения. Используйте плюс и минус для изменения масштаба.'); root.appendChild(viewport);
      svg = svgEl('svg', { class: 'md-sheet-svg', role: 'group', 'aria-label': (sheet.title || sheet.file) + ' — электрические соединения', xmlns: NS, preserveAspectRatio: 'xMidYMid meet' }); viewport.appendChild(svg);
      var wireLayer = svgEl('g', { class: 'md-wires' }), bodyLayer = svgEl('g', { class: 'md-symbols' }), pinLayer = svgEl('g', { class: 'md-pins' }), labelLayer = svgEl('g', { class: 'md-labels' }); svg.append(wireLayer, bodyLayer, pinLayer, labelLayer);
      wires.forEach(function (w) {
        var g = svgEl('g', { class: 'md-wire-group md-kind-' + kindClass((nets[w.net] || {}).kind) });
        var hit = svgEl('line', { x1: w.x1, y1: w.y1, x2: w.x2, y2: w.y2, class: 'md-wire-hit' });
        var line = svgEl('line', { x1: w.x1, y1: w.y1, x2: w.x2, y2: w.y2, class: 'md-wire' }); g.append(hit, line); textTitle(g, (nets[w.net] || {}).name || 'Проводник без назначенной цепи'); netTagged(g, w.net); wireLayer.appendChild(g);
      });
      symbols.forEach(function (s, index) {
        var c = components[s.component] || {}, box = symbolBox(s), ref = s.ref || c.ref || s.component || '?';
        var group = svgEl('g', { class: 'md-symbol', tabindex: '0', role: 'button', 'aria-label': ref + ', ' + (c.value || s.value || '') + ', секция ' + (s.unit || 1) });
        var originals = list(s.graphics), original = originals.length > 0;
        var r = svgEl('rect', { x: box.x, y: box.y, width: Math.max(.5, box.w), height: Math.max(.5, box.h), rx: original ? 0 : Math.min(.8, box.h / 8), class: 'md-symbol-body' + (original ? ' md-symbol-hitbox' : '') }); group.appendChild(r);
        originals.forEach(function(graphic){ var shape=originalGraphic(graphic);if(shape)group.appendChild(shape); });
        var maxText = Math.max(9, Math.floor(box.w / 1.05)), value = c.value || s.value || '';
        var fs = original ? 1.8 : Math.max(1.2, Math.min(2.3, box.h / 4.6, box.w / Math.max(4, ref.length) * 1.35));
        var refText = svgEl('text', { x: box.x + box.w / 2, y: original ? box.y - 1 : box.y + box.h / 2 - .25, class: 'md-symbol-ref', 'font-size': fs, 'text-anchor': 'middle' }, c.virtual ? value : ref + (s.unit && Number(s.unit) > 1 ? ' / ' + s.unit : '')); group.appendChild(refText);
        if (!c.virtual && box.h >= 3) group.appendChild(svgEl('text', { x: box.x + box.w / 2, y: original ? box.y + box.h + 2 : box.y + box.h / 2 + fs * .95, class: 'md-symbol-value', 'font-size': fs * .7, 'text-anchor': 'middle' }, value.length > maxText ? value.slice(0, maxText - 1) + '…' : value));
        textTitle(group, ref + ' · ' + value + '\n' + (c.lib || s.lib || '') + '\nНажмите, чтобы посмотреть компонент'); group.addEventListener('click', function (e) { e.stopPropagation(); selectComponent(s.component); }); group.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectComponent(s.component); } });
        symbolTagged.push({ node: group, nets: list(s.pins).map(function (p) { return p.net; }) }); bodyLayer.appendChild(group);
        list(s.pins).forEach(function (p) {
          if (!p.hidden && finite(p.bodyX) && finite(p.bodyY)) {
            var stem=svgEl('line',{x1:p.x,y1:p.y,x2:p.bodyX,y2:p.bodyY,class:'md-pin-stem'});netTagged(stem,p.net);pinLayer.appendChild(stem);
            var dx=p.bodyX-p.x,dy=p.bodyY-p.y;
            if(Math.abs(dx)+Math.abs(dy)>.2){
              var number=svgEl('text',{x:(p.x+p.bodyX)/2,y:(p.y+p.bodyY)/2-.45,'font-size':1.15,'text-anchor':'middle',class:'md-pin-number-svg'},p.number);pinLayer.appendChild(number);
              if(p.name&&p.name!=='~'){
                var horizontal=Math.abs(dx)>=Math.abs(dy),direction=horizontal?(dx>=0?1:-1):(dy>=0?1:-1);
                var pinName=svgEl('text',{x:p.bodyX+(horizontal?direction*.65:.55),y:p.bodyY+(horizontal?.45:direction*1.1),'font-size':1.2,'text-anchor':horizontal?(direction>0?'start':'end'):'start',class:'md-pin-name-svg'},p.name);pinLayer.appendChild(pinName);
              }
            }
          }
          var circle = svgEl('circle', { cx: p.x, cy: p.y, r: .32, class: 'md-pin md-kind-' + kindClass((nets[p.net] || {}).kind), tabindex: p.net ? '0' : null, role: p.net ? 'button' : null, 'aria-label': ref + ' вывод ' + p.number + ' ' + (p.name || '') + ', ' + ((nets[p.net] || {}).name || 'без цепи') });
          textTitle(circle, ref + ' вывод ' + p.number + ' · ' + (p.name || '') + '\n' + ((nets[p.net] || {}).name || 'Нет подключённой цепи') + (p.type ? '\n' + typeLabel(p.type) : '')); netTagged(circle, p.net);
          circle.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && p.net) { e.preventDefault(); selectNet(p.net); } }); pinLayer.appendChild(circle);
        });
      });
      list(d.junctions).forEach(function (j) { var n = svgEl('circle', { cx: j.x, cy: j.y, r: .5, class: 'md-junction' }); netTagged(n, j.net); pinLayer.appendChild(n); });
      labels.forEach(function (l) {
        var g = svgEl('g', { class: 'md-net-label', tabindex: l.net ? '0' : null, role: l.net ? 'button' : null, 'aria-label': 'Цепь ' + l.name });
        var t = svgEl('text', { x: l.x, y: num(l.y, 0) - .8, 'font-size': 1.9, 'paint-order': 'stroke', class: 'md-net-label-text' }, l.name || (nets[l.net] || {}).name || ''); g.appendChild(t); textTitle(g, l.name || 'Метка цепи'); netTagged(g, l.net); g.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectNet(l.net); } }); labelLayer.appendChild(g);
      });
      list(d.noConnects).forEach(function (p) { var x = num(p.x, 0), y = num(p.y, 0); var cross = svgEl('path', { d: 'M' + (x - .55) + ' ' + (y - .55) + 'L' + (x + .55) + ' ' + (y + .55) + 'M' + (x - .55) + ' ' + (y + .55) + 'L' + (x + .55) + ' ' + (y - .55), class: 'md-no-connect' }); textTitle(cross, 'Метка намеренно неподключённого вывода'); pinLayer.appendChild(cross); });
      var footer = el('div', 'md-canvas-footer'); footer.append(el('span', '', symbols.length + ' секций символов · ' + wires.length + ' сегментов проводников · ' + labels.length + ' меток'), el('span', '', 'Исходное расположение и УГО · перетаскивайте для перемещения')); root.appendChild(footer);
      fullBounds = boundsOf(d); if (!setViewport(initialCamera)) fit(); setSelection(selection);
      function point(e) { var rect = svg.getBoundingClientRect(); return { x: viewBox.x + (e.clientX - rect.left) / rect.width * viewBox.w, y: viewBox.y + (e.clientY - rect.top) / rect.height * viewBox.h }; }
      listen(svg, 'wheel', function (e) { e.preventDefault(); var p = point(e); zoom(e.deltaY < 0 ? 1.13 : 1 / 1.13, p.x, p.y); }, { passive: false });
      listen(svg, 'pointerdown', function (e) { if (e.button !== 0 || e.target.closest('.md-symbol,.md-net-label,.md-pin')) return; drag = { x: e.clientX, y: e.clientY, box: Object.assign({}, viewBox), moved: false, pointerId:e.pointerId }; });
      listen(svg, 'pointermove', function (e) { if (!drag) return; var r = svg.getBoundingClientRect(), dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 4 && !drag.moved) { drag.moved = true; svg.setPointerCapture(drag.pointerId); svg.classList.add('is-panning'); } if(!drag.moved || !r.width || !r.height)return; cameraModified = true; viewBox.x = drag.box.x - dx / r.width * drag.box.w; viewBox.y = drag.box.y - dy / r.height * drag.box.h; applyViewBox(); rememberCamera(); });
      function endDrag(e) { if (!drag) return; var moved = drag.moved; drag = null; svg.classList.remove('is-panning'); if (moved) { var stop = function (evt) { evt.stopPropagation(); evt.preventDefault(); }; svg.addEventListener('click', stop, { once: true, capture: true }); } }
      listen(svg, 'pointerup', endDrag); listen(svg, 'pointercancel', endDrag);
      listen(viewport, 'keydown', function (e) { if (e.target !== viewport) return; if (e.key === '+' || e.key === '=') { e.preventDefault(); zoom(1.25); } if (e.key === '-') { e.preventDefault(); zoom(.8); } if (e.key === '0') { e.preventDefault(); fit(); } });
      if (window.ResizeObserver) { resizeObserver = new window.ResizeObserver(function () {
        if (!viewBox || (fittedWithoutSize && !cameraModified)) { fit(); return; }
        var next = viewportSize(); if (lastSize && next.width === lastSize.width && next.height === lastSize.height) return;
        setViewport(getViewport());
      }); resizeObserver.observe(viewport); }
    }
    function renderNet() {
      var net = nets[options.netId]; if (!net) { appendEmpty('Выберите цепь для просмотра', 'Выберите именованную или локальную цепь. Здесь появятся все подключённые к ней выводы компонентов.'); return; }
      var byComponent = new Map();
      list(net.pins).forEach(function (p) {
        var componentId = p.component, key = componentId || p.ref || 'Unknown';
        if (!byComponent.has(key)) byComponent.set(key, { id: componentId, ref: p.ref || componentName(atlas, componentId), pins: new Map(), sheets: new Set() });
        var g = byComponent.get(key), pinKey = String(p.pin != null ? p.pin : p.number != null ? p.number : '?');
        if (!g.pins.has(pinKey)) g.pins.set(pinKey, { number: pinKey, name: p.name || '', type: p.type || '', sources: new Set() });
        var source = sheets[p.sheet] || {}; g.pins.get(pinKey).sources.add((source.title || source.file || p.sheet || 'Неизвестный лист') + (p.unit ? ' · секция ' + p.unit : '')); if (p.sheet) g.sheets.add(p.sheet);
      });
      var groups = Array.from(byComponent.values()).sort(function (a, b) { return natural(a.ref, b.ref); });
      var uniquePins = groups.reduce(function (total, g) { return total + g.pins.size; }, 0);
      var virtualPins = groups.reduce(function(total,g){return total + ((components[g.id]||{}).virtual ? g.pins.size : 0);},0);
      toolbar(net.name || options.netId, (uniquePins-virtualPins) + ' выводов компонентов' + (virtualPins ? ' + ' + virtualPins + ' привязок меток' : '') + ' · ' + groups.length + ' компонентов · ' + list(net.sheets).length + ' листов');
      var info = el('div', 'md-net-explanation'); var badge = el('span', 'md-kind-badge md-kind-' + kindClass(net.kind), typeLabel(net.kind) || 'Электрическая цепь'); info.append(badge, el('span', '', 'Все выводы принадлежат одной электрической цепи. Центральная шина показывает соединение без указания направления сигнала.')); root.appendChild(info);
      var scroller = el('div', 'md-net-scroll'); root.appendChild(scroller);
      var heading = el('div', 'md-topology-heading'); heading.append(el('span', 'md-eyebrow', 'ВСЕ ПОДКЛЮЧЕНИЯ ЦЕПИ'), el('h3', '', net.name || options.netId), el('p', '', 'Выберите компонент, чтобы посмотреть подробности. Под каждым выводом указаны его расположения в исходной схеме.')); scroller.appendChild(heading);
      var grid = el('div', 'md-net-grid'); scroller.appendChild(grid);
      groups.forEach(function (g, idx) {
        var c = components[g.id] || {}, card = el('article', 'md-terminal-card ' + (idx % 2 ? 'md-terminal-right' : 'md-terminal-left')); card.style.setProperty('--md-kind-color', 'var(--md-' + kindClass(net.kind) + ')');
        var header = el('div', 'md-terminal-header'); var ref = button(g.ref, 'Посмотреть ' + g.ref, function () { selectComponent(g.id); }, 'md-component-link'); header.append(ref, el('span', 'md-pin-count', 'Выводов: ' + g.pins.size)); card.appendChild(header); card.appendChild(el('div', 'md-terminal-value', c.value || c.lib || 'Компонент')); if(c.virtual)card.appendChild(el('div','md-virtual-note','Символ питания · логическая привязка метки'));
        var pins = el('ul', 'md-terminal-pins');
        Array.from(g.pins.values()).sort(function (a, b) { return natural(a.number, b.number); }).forEach(function (p) {
          var li = el('li', 'md-terminal-pin'); var line = el('div', 'md-terminal-pin-main'); line.append(el('span', 'md-pin-number', p.number), el('strong', 'md-pin-name', p.name || '(без имени)'), el('span', 'md-pin-type', typeLabel(p.type))); li.appendChild(line);
          Array.from(p.sources).forEach(function (source) { li.appendChild(el('span', 'md-pin-source', source)); }); pins.appendChild(li);
        }); card.appendChild(pins); grid.appendChild(card);
      });
      if (!groups.length) grid.appendChild(el('div', 'md-empty', 'Для этой цепи не извлечены выводы компонентов.'));
      var finish = el('div', 'md-topology-end', 'Все подключения показаны · уникальных выводов: ' + uniquePins); scroller.appendChild(finish);
      var footer = el('div', 'md-canvas-footer'); footer.append(el('span', '', 'Повторные изображения одного вывода в разных секциях объединены; все расположения сохранены. Привязки меток отмечены отдельно.'), el('span', '', 'Прокрутите, чтобы увидеть все ветви')); root.appendChild(footer);
      if (!setViewport(initialCamera)) rememberCamera();
      listen(scroller, 'scroll', function () {
        var old = cameras[sceneKey], now = getViewport();
        if (old && now && old.scrollTop === now.scrollTop && old.scrollLeft === now.scrollLeft && old.fontScale === now.fontScale) return;
        cameraModified = true; rememberCamera();
      }, { passive: true });
    }
    if (currentView === 'net') renderNet(); else renderSheet();
    return { destroy: function () { if (destroyed) return; rememberCamera(); flushCamera(); destroyed = true; events.forEach(function (dispose) { dispose(); }); if (resizeObserver) resizeObserver.disconnect(); root.remove(); }, setSelection: setSelection, fit: fit, zoom: zoom, getViewport: getViewport, setViewport: setViewport };
  }
  window.MiraDiagram = { mount: mount, version: '1.1.0' };
})();
